                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _layer_switch_get_layer
                                     24 	.globl _read_source_keycode_cache
                                     25 	.globl _update_source_layers_cache
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _keymap_key_to_keycode
                                     36 	.globl _rgb_matrix_set_suspend_state
                                     37 	.globl _rgb_matrix_task
                                     38 	.globl _mDelaymS
                                     39 	.globl _ADC_START
                                     40 	.globl _S0_R_FIFO
                                     41 	.globl _S0_T_FIFO
                                     42 	.globl _S0_FREE
                                     43 	.globl _S0_IF_BYTE
                                     44 	.globl _S0_IF_FIRST
                                     45 	.globl _S0_IF_OV
                                     46 	.globl _S0_FST_ACT
                                     47 	.globl _CP_RL2
                                     48 	.globl _C_T2
                                     49 	.globl _TR2
                                     50 	.globl _EXEN2
                                     51 	.globl _TCLK
                                     52 	.globl _RCLK
                                     53 	.globl _EXF2
                                     54 	.globl _CAP1F
                                     55 	.globl _TF2
                                     56 	.globl _RI
                                     57 	.globl _TI
                                     58 	.globl _RB8
                                     59 	.globl _TB8
                                     60 	.globl _REN
                                     61 	.globl _SM2
                                     62 	.globl _SM1
                                     63 	.globl _SM0
                                     64 	.globl _IT0
                                     65 	.globl _IE0
                                     66 	.globl _IT1
                                     67 	.globl _IE1
                                     68 	.globl _TR0
                                     69 	.globl _TF0
                                     70 	.globl _TR1
                                     71 	.globl _TF1
                                     72 	.globl _P4_0
                                     73 	.globl _P4_1
                                     74 	.globl _P4_2
                                     75 	.globl _P4_3
                                     76 	.globl _P4_4
                                     77 	.globl _P4_5
                                     78 	.globl _P4_6
                                     79 	.globl _RXD
                                     80 	.globl _TXD
                                     81 	.globl _INT0
                                     82 	.globl _INT1
                                     83 	.globl _T0
                                     84 	.globl _T1
                                     85 	.globl _MOSI1
                                     86 	.globl _MISO1
                                     87 	.globl _SCK1
                                     88 	.globl _P3_0
                                     89 	.globl _P3_1
                                     90 	.globl _P3_2
                                     91 	.globl _P3_3
                                     92 	.globl _P3_4
                                     93 	.globl _P3_5
                                     94 	.globl _P3_6
                                     95 	.globl _P3_7
                                     96 	.globl _CAP1_
                                     97 	.globl _T2_
                                     98 	.globl _CAP2_
                                     99 	.globl _T2EX_
                                    100 	.globl _RXD1
                                    101 	.globl _TXD1
                                    102 	.globl _P2_0
                                    103 	.globl _P2_1
                                    104 	.globl _P2_2
                                    105 	.globl _P2_3
                                    106 	.globl _P2_4
                                    107 	.globl _P2_5
                                    108 	.globl _P2_6
                                    109 	.globl _P2_7
                                    110 	.globl _AIN0
                                    111 	.globl _AIN1
                                    112 	.globl _AIN2
                                    113 	.globl _AIN3
                                    114 	.globl _AIN4
                                    115 	.globl _AIN5
                                    116 	.globl _AIN6
                                    117 	.globl _AIN7
                                    118 	.globl _CAP1
                                    119 	.globl _T2
                                    120 	.globl _CAP2
                                    121 	.globl _T2EX
                                    122 	.globl _INT0_
                                    123 	.globl _SCS
                                    124 	.globl _MOSI
                                    125 	.globl _MISO
                                    126 	.globl _SCK
                                    127 	.globl _RXD1_
                                    128 	.globl _TXD1_
                                    129 	.globl _P1_0
                                    130 	.globl _P1_1
                                    131 	.globl _P1_2
                                    132 	.globl _P1_3
                                    133 	.globl _P1_4
                                    134 	.globl _P1_5
                                    135 	.globl _P1_6
                                    136 	.globl _P1_7
                                    137 	.globl _AIN8
                                    138 	.globl _AIN9
                                    139 	.globl _AIN10
                                    140 	.globl _AIN11
                                    141 	.globl _AIN12
                                    142 	.globl _AIN13
                                    143 	.globl _RXD_
                                    144 	.globl _TXD_
                                    145 	.globl _SCL0
                                    146 	.globl _SDA0
                                    147 	.globl _P0_0
                                    148 	.globl _P0_1
                                    149 	.globl _P0_2
                                    150 	.globl _P0_3
                                    151 	.globl _P0_4
                                    152 	.globl _P0_5
                                    153 	.globl _P0_6
                                    154 	.globl _P0_7
                                    155 	.globl _IE_SPI0
                                    156 	.globl _IE_USB
                                    157 	.globl _IE_ADC
                                    158 	.globl _IE_UART1
                                    159 	.globl _IE_PWM_I2C
                                    160 	.globl _IE_GPIO
                                    161 	.globl _IE_WDOG
                                    162 	.globl _PX0
                                    163 	.globl _PT0
                                    164 	.globl _PX1
                                    165 	.globl _PT1
                                    166 	.globl _PS
                                    167 	.globl _PT2
                                    168 	.globl _PL_FLAG
                                    169 	.globl _PH_FLAG
                                    170 	.globl _EX0
                                    171 	.globl _ET0
                                    172 	.globl _EX1
                                    173 	.globl _ET1
                                    174 	.globl _ES
                                    175 	.globl _ET2
                                    176 	.globl _E_DIS
                                    177 	.globl _EA
                                    178 	.globl _P
                                    179 	.globl _F1
                                    180 	.globl _OV
                                    181 	.globl _RS0
                                    182 	.globl _RS1
                                    183 	.globl _F0
                                    184 	.globl _AC
                                    185 	.globl _CY
                                    186 	.globl _I2CS_INT_ST
                                    187 	.globl _I2CX_INT
                                    188 	.globl _LED_STATUS
                                    189 	.globl _LED_DMA_H
                                    190 	.globl _LED_DMA_L
                                    191 	.globl _LED_DMA
                                    192 	.globl _LED_PWM_OE
                                    193 	.globl _LED_COMMON
                                    194 	.globl _ADC_CHAN
                                    195 	.globl _ADC_DAT_H
                                    196 	.globl _ADC_DAT_L
                                    197 	.globl _ADC_DAT
                                    198 	.globl _ADC_CTRL
                                    199 	.globl _SPI1_CK_SE
                                    200 	.globl _SPI1_CTRL
                                    201 	.globl _SPI1_DATA
                                    202 	.globl _SPI1_STAT
                                    203 	.globl _SIF1
                                    204 	.globl _SBAUD1
                                    205 	.globl _SBUF1
                                    206 	.globl _SCON1
                                    207 	.globl _SPI0_SETUP
                                    208 	.globl _SPI0_CK_SE
                                    209 	.globl _SPI0_CTRL
                                    210 	.globl _SPI0_DATA
                                    211 	.globl _SPI0_STAT
                                    212 	.globl _T2CAP1H
                                    213 	.globl _T2CAP1L
                                    214 	.globl _T2CAP1
                                    215 	.globl _TH2
                                    216 	.globl _TL2
                                    217 	.globl _T2COUNT
                                    218 	.globl _RCAP2H
                                    219 	.globl _RCAP2L
                                    220 	.globl _RCAP2
                                    221 	.globl _T2MOD
                                    222 	.globl _T2CON
                                    223 	.globl _SBUF
                                    224 	.globl _SCON
                                    225 	.globl _TH1
                                    226 	.globl _TH0
                                    227 	.globl _TL1
                                    228 	.globl _TL0
                                    229 	.globl _TMOD
                                    230 	.globl _TCON
                                    231 	.globl _XBUS_AUX
                                    232 	.globl _P7
                                    233 	.globl _P6_DIR
                                    234 	.globl _P6_OUT_PU
                                    235 	.globl _P6_IN
                                    236 	.globl _P5_DIR
                                    237 	.globl _P5_OUT_PU
                                    238 	.globl _P5_IN
                                    239 	.globl _P4_LED_KEY
                                    240 	.globl _P4_DIR_PU
                                    241 	.globl _P4_MOD_OC
                                    242 	.globl _P4
                                    243 	.globl _P3_DIR_PU
                                    244 	.globl _P3_MOD_OC
                                    245 	.globl _P3
                                    246 	.globl _P2_DIR_PU
                                    247 	.globl _P2_MOD_OC
                                    248 	.globl _P2
                                    249 	.globl _P1_DIR_PU
                                    250 	.globl _P1_MOD_OC
                                    251 	.globl _P1
                                    252 	.globl _P0_DIR_PU
                                    253 	.globl _P0_MOD_OC
                                    254 	.globl _P0
                                    255 	.globl _ROM_CTRL
                                    256 	.globl _ROM_DATA_HH
                                    257 	.globl _ROM_DATA_HL
                                    258 	.globl _ROM_DATA_HI
                                    259 	.globl _ROM_ADDR_H
                                    260 	.globl _ROM_ADDR_L
                                    261 	.globl _ROM_ADDR
                                    262 	.globl _GPIO_IE
                                    263 	.globl _IP_EX
                                    264 	.globl _IE_EX
                                    265 	.globl _IP
                                    266 	.globl _IE
                                    267 	.globl _WDOG_COUNT
                                    268 	.globl _RESET_KEEP
                                    269 	.globl _WAKE_CTRL
                                    270 	.globl _CLOCK_CFG
                                    271 	.globl _POWER_CFG
                                    272 	.globl _PCON
                                    273 	.globl _GLOBAL_CFG
                                    274 	.globl _SAFE_MOD
                                    275 	.globl _DPH
                                    276 	.globl _DPL
                                    277 	.globl _SP
                                    278 	.globl _A_INV
                                    279 	.globl _B
                                    280 	.globl _ACC
                                    281 	.globl _PSW
                                    282 	.globl _process_record_quantum_helper_PARM_2
                                    283 	.globl _get_event_keycode_PARM_1
                                    284 	.globl _get_record_keycode_PARM_2
                                    285 	.globl _post_process_record_user_PARM_2
                                    286 	.globl _post_process_record_kb_PARM_2
                                    287 	.globl _process_record_user_PARM_2
                                    288 	.globl _process_record_kb_PARM_2
                                    289 	.globl _pre_process_record_user_PARM_2
                                    290 	.globl _pre_process_record_kb_PARM_2
                                    291 	.globl _register_code16
                                    292 	.globl _unregister_code16
                                    293 	.globl _pre_process_record_kb
                                    294 	.globl _pre_process_record_user
                                    295 	.globl _process_action_kb
                                    296 	.globl _process_record_kb
                                    297 	.globl _process_record_user
                                    298 	.globl _post_process_record_kb
                                    299 	.globl _post_process_record_user
                                    300 	.globl _reset_keyboard
                                    301 	.globl _soft_reset_keyboard
                                    302 	.globl _get_record_keycode
                                    303 	.globl _get_event_keycode
                                    304 	.globl _pre_process_record_quantum
                                    305 	.globl _post_process_record_quantum
                                    306 	.globl _process_record_quantum
                                    307 	.globl _process_record_quantum_helper
                                    308 	.globl _shutdown_user
                                    309 ;--------------------------------------------------------
                                    310 ; special function registers
                                    311 ;--------------------------------------------------------
                                    312 	.area RSEG    (ABS,DATA)
      000000                        313 	.org 0x0000
                           0000D0   314 _PSW	=	0x00d0
                           0000E0   315 _ACC	=	0x00e0
                           0000F0   316 _B	=	0x00f0
                           0000FD   317 _A_INV	=	0x00fd
                           000081   318 _SP	=	0x0081
                           000082   319 _DPL	=	0x0082
                           000083   320 _DPH	=	0x0083
                           0000A1   321 _SAFE_MOD	=	0x00a1
                           0000B1   322 _GLOBAL_CFG	=	0x00b1
                           000087   323 _PCON	=	0x0087
                           0000BA   324 _POWER_CFG	=	0x00ba
                           0000B9   325 _CLOCK_CFG	=	0x00b9
                           0000A9   326 _WAKE_CTRL	=	0x00a9
                           0000FE   327 _RESET_KEEP	=	0x00fe
                           0000FF   328 _WDOG_COUNT	=	0x00ff
                           0000A8   329 _IE	=	0x00a8
                           0000B8   330 _IP	=	0x00b8
                           0000E8   331 _IE_EX	=	0x00e8
                           0000E9   332 _IP_EX	=	0x00e9
                           0000B2   333 _GPIO_IE	=	0x00b2
                           008584   334 _ROM_ADDR	=	0x8584
                           000084   335 _ROM_ADDR_L	=	0x0084
                           000085   336 _ROM_ADDR_H	=	0x0085
                           008F8E   337 _ROM_DATA_HI	=	0x8f8e
                           00008E   338 _ROM_DATA_HL	=	0x008e
                           00008F   339 _ROM_DATA_HH	=	0x008f
                           000086   340 _ROM_CTRL	=	0x0086
                           000080   341 _P0	=	0x0080
                           0000C4   342 _P0_MOD_OC	=	0x00c4
                           0000C5   343 _P0_DIR_PU	=	0x00c5
                           000090   344 _P1	=	0x0090
                           000092   345 _P1_MOD_OC	=	0x0092
                           000093   346 _P1_DIR_PU	=	0x0093
                           0000A0   347 _P2	=	0x00a0
                           000094   348 _P2_MOD_OC	=	0x0094
                           000095   349 _P2_DIR_PU	=	0x0095
                           0000B0   350 _P3	=	0x00b0
                           000096   351 _P3_MOD_OC	=	0x0096
                           000097   352 _P3_DIR_PU	=	0x0097
                           0000C0   353 _P4	=	0x00c0
                           0000C2   354 _P4_MOD_OC	=	0x00c2
                           0000C3   355 _P4_DIR_PU	=	0x00c3
                           0000C1   356 _P4_LED_KEY	=	0x00c1
                           0000AA   357 _P5_IN	=	0x00aa
                           0000AB   358 _P5_OUT_PU	=	0x00ab
                           0000AC   359 _P5_DIR	=	0x00ac
                           0000AD   360 _P6_IN	=	0x00ad
                           0000AE   361 _P6_OUT_PU	=	0x00ae
                           0000AF   362 _P6_DIR	=	0x00af
                           0000F1   363 _P7	=	0x00f1
                           0000A2   364 _XBUS_AUX	=	0x00a2
                           000088   365 _TCON	=	0x0088
                           000089   366 _TMOD	=	0x0089
                           00008A   367 _TL0	=	0x008a
                           00008B   368 _TL1	=	0x008b
                           00008C   369 _TH0	=	0x008c
                           00008D   370 _TH1	=	0x008d
                           000098   371 _SCON	=	0x0098
                           000099   372 _SBUF	=	0x0099
                           0000C8   373 _T2CON	=	0x00c8
                           0000C9   374 _T2MOD	=	0x00c9
                           00CBCA   375 _RCAP2	=	0xcbca
                           0000CA   376 _RCAP2L	=	0x00ca
                           0000CB   377 _RCAP2H	=	0x00cb
                           00CDCC   378 _T2COUNT	=	0xcdcc
                           0000CC   379 _TL2	=	0x00cc
                           0000CD   380 _TH2	=	0x00cd
                           00CFCE   381 _T2CAP1	=	0xcfce
                           0000CE   382 _T2CAP1L	=	0x00ce
                           0000CF   383 _T2CAP1H	=	0x00cf
                           0000F8   384 _SPI0_STAT	=	0x00f8
                           0000F9   385 _SPI0_DATA	=	0x00f9
                           0000FA   386 _SPI0_CTRL	=	0x00fa
                           0000FB   387 _SPI0_CK_SE	=	0x00fb
                           0000FC   388 _SPI0_SETUP	=	0x00fc
                           0000BC   389 _SCON1	=	0x00bc
                           0000BD   390 _SBUF1	=	0x00bd
                           0000BE   391 _SBAUD1	=	0x00be
                           0000BF   392 _SIF1	=	0x00bf
                           0000B4   393 _SPI1_STAT	=	0x00b4
                           0000B5   394 _SPI1_DATA	=	0x00b5
                           0000B6   395 _SPI1_CTRL	=	0x00b6
                           0000B7   396 _SPI1_CK_SE	=	0x00b7
                           0000F3   397 _ADC_CTRL	=	0x00f3
                           00F5F4   398 _ADC_DAT	=	0xf5f4
                           0000F4   399 _ADC_DAT_L	=	0x00f4
                           0000F5   400 _ADC_DAT_H	=	0x00f5
                           0000F6   401 _ADC_CHAN	=	0x00f6
                           0000A6   402 _LED_COMMON	=	0x00a6
                           0000A7   403 _LED_PWM_OE	=	0x00a7
                           00C7C6   404 _LED_DMA	=	0xc7c6
                           0000C6   405 _LED_DMA_L	=	0x00c6
                           0000C7   406 _LED_DMA_H	=	0x00c7
                           0000F7   407 _LED_STATUS	=	0x00f7
                           0000B3   408 _I2CX_INT	=	0x00b3
                           0000BB   409 _I2CS_INT_ST	=	0x00bb
                                    410 ;--------------------------------------------------------
                                    411 ; special function bits
                                    412 ;--------------------------------------------------------
                                    413 	.area RSEG    (ABS,DATA)
      000000                        414 	.org 0x0000
                           0000D7   415 _CY	=	0x00d7
                           0000D6   416 _AC	=	0x00d6
                           0000D5   417 _F0	=	0x00d5
                           0000D4   418 _RS1	=	0x00d4
                           0000D3   419 _RS0	=	0x00d3
                           0000D2   420 _OV	=	0x00d2
                           0000D1   421 _F1	=	0x00d1
                           0000D0   422 _P	=	0x00d0
                           0000AF   423 _EA	=	0x00af
                           0000AE   424 _E_DIS	=	0x00ae
                           0000AD   425 _ET2	=	0x00ad
                           0000AC   426 _ES	=	0x00ac
                           0000AB   427 _ET1	=	0x00ab
                           0000AA   428 _EX1	=	0x00aa
                           0000A9   429 _ET0	=	0x00a9
                           0000A8   430 _EX0	=	0x00a8
                           0000BF   431 _PH_FLAG	=	0x00bf
                           0000BE   432 _PL_FLAG	=	0x00be
                           0000BD   433 _PT2	=	0x00bd
                           0000BC   434 _PS	=	0x00bc
                           0000BB   435 _PT1	=	0x00bb
                           0000BA   436 _PX1	=	0x00ba
                           0000B9   437 _PT0	=	0x00b9
                           0000B8   438 _PX0	=	0x00b8
                           0000EF   439 _IE_WDOG	=	0x00ef
                           0000EE   440 _IE_GPIO	=	0x00ee
                           0000ED   441 _IE_PWM_I2C	=	0x00ed
                           0000EC   442 _IE_UART1	=	0x00ec
                           0000EB   443 _IE_ADC	=	0x00eb
                           0000E9   444 _IE_USB	=	0x00e9
                           0000E8   445 _IE_SPI0	=	0x00e8
                           000087   446 _P0_7	=	0x0087
                           000086   447 _P0_6	=	0x0086
                           000085   448 _P0_5	=	0x0085
                           000084   449 _P0_4	=	0x0084
                           000083   450 _P0_3	=	0x0083
                           000082   451 _P0_2	=	0x0082
                           000081   452 _P0_1	=	0x0081
                           000080   453 _P0_0	=	0x0080
                           000081   454 _SDA0	=	0x0081
                           000080   455 _SCL0	=	0x0080
                           000083   456 _TXD_	=	0x0083
                           000082   457 _RXD_	=	0x0082
                           000085   458 _AIN13	=	0x0085
                           000084   459 _AIN12	=	0x0084
                           000083   460 _AIN11	=	0x0083
                           000082   461 _AIN10	=	0x0082
                           000081   462 _AIN9	=	0x0081
                           000080   463 _AIN8	=	0x0080
                           000097   464 _P1_7	=	0x0097
                           000096   465 _P1_6	=	0x0096
                           000095   466 _P1_5	=	0x0095
                           000094   467 _P1_4	=	0x0094
                           000093   468 _P1_3	=	0x0093
                           000092   469 _P1_2	=	0x0092
                           000091   470 _P1_1	=	0x0091
                           000090   471 _P1_0	=	0x0090
                           000097   472 _TXD1_	=	0x0097
                           000096   473 _RXD1_	=	0x0096
                           000097   474 _SCK	=	0x0097
                           000096   475 _MISO	=	0x0096
                           000095   476 _MOSI	=	0x0095
                           000094   477 _SCS	=	0x0094
                           000092   478 _INT0_	=	0x0092
                           000091   479 _T2EX	=	0x0091
                           000091   480 _CAP2	=	0x0091
                           000090   481 _T2	=	0x0090
                           000090   482 _CAP1	=	0x0090
                           000097   483 _AIN7	=	0x0097
                           000096   484 _AIN6	=	0x0096
                           000095   485 _AIN5	=	0x0095
                           000094   486 _AIN4	=	0x0094
                           000093   487 _AIN3	=	0x0093
                           000092   488 _AIN2	=	0x0092
                           000091   489 _AIN1	=	0x0091
                           000090   490 _AIN0	=	0x0090
                           0000A7   491 _P2_7	=	0x00a7
                           0000A6   492 _P2_6	=	0x00a6
                           0000A5   493 _P2_5	=	0x00a5
                           0000A4   494 _P2_4	=	0x00a4
                           0000A3   495 _P2_3	=	0x00a3
                           0000A2   496 _P2_2	=	0x00a2
                           0000A1   497 _P2_1	=	0x00a1
                           0000A0   498 _P2_0	=	0x00a0
                           0000A7   499 _TXD1	=	0x00a7
                           0000A6   500 _RXD1	=	0x00a6
                           0000A5   501 _T2EX_	=	0x00a5
                           0000A5   502 _CAP2_	=	0x00a5
                           0000A4   503 _T2_	=	0x00a4
                           0000A4   504 _CAP1_	=	0x00a4
                           0000B7   505 _P3_7	=	0x00b7
                           0000B6   506 _P3_6	=	0x00b6
                           0000B5   507 _P3_5	=	0x00b5
                           0000B4   508 _P3_4	=	0x00b4
                           0000B3   509 _P3_3	=	0x00b3
                           0000B2   510 _P3_2	=	0x00b2
                           0000B1   511 _P3_1	=	0x00b1
                           0000B0   512 _P3_0	=	0x00b0
                           0000B7   513 _SCK1	=	0x00b7
                           0000B6   514 _MISO1	=	0x00b6
                           0000B5   515 _MOSI1	=	0x00b5
                           0000B5   516 _T1	=	0x00b5
                           0000B4   517 _T0	=	0x00b4
                           0000B3   518 _INT1	=	0x00b3
                           0000B2   519 _INT0	=	0x00b2
                           0000B1   520 _TXD	=	0x00b1
                           0000B0   521 _RXD	=	0x00b0
                           0000C6   522 _P4_6	=	0x00c6
                           0000C5   523 _P4_5	=	0x00c5
                           0000C4   524 _P4_4	=	0x00c4
                           0000C3   525 _P4_3	=	0x00c3
                           0000C2   526 _P4_2	=	0x00c2
                           0000C1   527 _P4_1	=	0x00c1
                           0000C0   528 _P4_0	=	0x00c0
                           00008F   529 _TF1	=	0x008f
                           00008E   530 _TR1	=	0x008e
                           00008D   531 _TF0	=	0x008d
                           00008C   532 _TR0	=	0x008c
                           00008B   533 _IE1	=	0x008b
                           00008A   534 _IT1	=	0x008a
                           000089   535 _IE0	=	0x0089
                           000088   536 _IT0	=	0x0088
                           00009F   537 _SM0	=	0x009f
                           00009E   538 _SM1	=	0x009e
                           00009D   539 _SM2	=	0x009d
                           00009C   540 _REN	=	0x009c
                           00009B   541 _TB8	=	0x009b
                           00009A   542 _RB8	=	0x009a
                           000099   543 _TI	=	0x0099
                           000098   544 _RI	=	0x0098
                           0000CF   545 _TF2	=	0x00cf
                           0000CF   546 _CAP1F	=	0x00cf
                           0000CE   547 _EXF2	=	0x00ce
                           0000CD   548 _RCLK	=	0x00cd
                           0000CC   549 _TCLK	=	0x00cc
                           0000CB   550 _EXEN2	=	0x00cb
                           0000CA   551 _TR2	=	0x00ca
                           0000C9   552 _C_T2	=	0x00c9
                           0000C8   553 _CP_RL2	=	0x00c8
                           0000FF   554 _S0_FST_ACT	=	0x00ff
                           0000FE   555 _S0_IF_OV	=	0x00fe
                           0000FD   556 _S0_IF_FIRST	=	0x00fd
                           0000FC   557 _S0_IF_BYTE	=	0x00fc
                           0000FB   558 _S0_FREE	=	0x00fb
                           0000FA   559 _S0_T_FIFO	=	0x00fa
                           0000F8   560 _S0_R_FIFO	=	0x00f8
                           0000F7   561 _ADC_START	=	0x00f7
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable register banks
                                    564 ;--------------------------------------------------------
                                    565 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        566 	.ds 8
                                    567 ;--------------------------------------------------------
                                    568 ; internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area DSEG    (DATA)
                                    571 ;--------------------------------------------------------
                                    572 ; overlayable items in internal ram
                                    573 ;--------------------------------------------------------
                                    574 ;--------------------------------------------------------
                                    575 ; indirectly addressable internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area ISEG    (DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; absolute internal ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area IABS    (ABS,DATA)
                                    582 	.area IABS    (ABS,DATA)
                                    583 ;--------------------------------------------------------
                                    584 ; bit data
                                    585 ;--------------------------------------------------------
                                    586 	.area BSEG    (BIT)
      000025                        587 _pre_process_record_quantum_sloc0_1_0:
      000025                        588 	.ds 1
      000026                        589 _process_ak820_nkro_sloc0_1_0:
      000026                        590 	.ds 1
                                    591 ;--------------------------------------------------------
                                    592 ; paged external ram data
                                    593 ;--------------------------------------------------------
                                    594 	.area PSEG    (PAG,XDATA)
                                    595 ;--------------------------------------------------------
                                    596 ; uninitialized external ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area XSEG    (XDATA)
      000BE8                        599 _extract_mod_bits_code_10000_592:
      000BE8                        600 	.ds 2
      000BEA                        601 _register_code16_code_10000_598:
      000BEA                        602 	.ds 2
      000BEC                        603 _unregister_code16_code_10000_603:
      000BEC                        604 	.ds 2
      000BEE                        605 _pre_process_record_kb_PARM_2:
      000BEE                        606 	.ds 3
      000BF1                        607 _pre_process_record_kb_keycode_10000_617:
      000BF1                        608 	.ds 2
      000BF3                        609 _pre_process_record_user_PARM_2:
      000BF3                        610 	.ds 3
      000BF6                        611 _process_record_kb_PARM_2:
      000BF6                        612 	.ds 3
      000BF9                        613 _process_record_kb_keycode_10000_623:
      000BF9                        614 	.ds 2
      000BFB                        615 _process_record_user_PARM_2:
      000BFB                        616 	.ds 3
      000BFE                        617 _post_process_record_kb_PARM_2:
      000BFE                        618 	.ds 3
      000C01                        619 _post_process_record_kb_keycode_10000_627:
      000C01                        620 	.ds 2
      000C03                        621 _post_process_record_user_PARM_2:
      000C03                        622 	.ds 3
      000C06                        623 _get_record_keycode_PARM_2:
      000C06                        624 	.ds 1
      000C07                        625 _get_record_keycode_record_10000_641:
      000C07                        626 	.ds 3
      000C0A                        627 _get_event_keycode_PARM_1:
      000C0A                        628 	.ds 6
      000C10                        629 _get_event_keycode_update_layer_cache_10000_645:
      000C10                        630 	.ds 1
      000C11                        631 _pre_process_record_quantum_record_10000_651:
      000C11                        632 	.ds 3
      000C14                        633 _post_process_record_quantum_record_10000_653:
      000C14                        634 	.ds 3
      000C17                        635 _process_record_quantum_record_10000_655:
      000C17                        636 	.ds 3
      000C1A                        637 _process_ak820_nkro_PARM_2:
      000C1A                        638 	.ds 3
      000C1D                        639 _process_ak820_nkro_keycode_10000_657:
      000C1D                        640 	.ds 2
      000C1F                        641 _process_record_quantum_helper_PARM_2:
      000C1F                        642 	.ds 3
      000C22                        643 _process_record_quantum_helper_keycode_10000_662:
      000C22                        644 	.ds 2
      000C24                        645 _get_u8_str_buf_10000_688:
      000C24                        646 	.ds 4
      000C28                        647 _get_u8_str_last_num_10000_688:
      000C28                        648 	.ds 1
      000C29                        649 _get_u8_str_last_pad_10000_688:
      000C29                        650 	.ds 1
      000C2A                        651 _get_u16_str_buf_10000_692:
      000C2A                        652 	.ds 6
      000C30                        653 _get_u16_str_last_num_10000_692:
      000C30                        654 	.ds 2
      000C32                        655 _get_u16_str_last_pad_10000_692:
      000C32                        656 	.ds 1
                                    657 ;--------------------------------------------------------
                                    658 ; absolute external ram data
                                    659 ;--------------------------------------------------------
                                    660 	.area XABS    (ABS,XDATA)
                                    661 ;--------------------------------------------------------
                                    662 ; initialized external ram data
                                    663 ;--------------------------------------------------------
                                    664 	.area XISEG   (XDATA)
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'get_u8_str'
                                    684 ;------------------------------------------------------------
                                    685 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    686 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_687'
                                    687 ;buf           Allocated with name '_get_u8_str_buf_10000_688'
                                    688 ;last_num      Allocated with name '_get_u8_str_last_num_10000_688'
                                    689 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_688'
                                    690 ;------------------------------------------------------------
                                    691 ;	quantum/quantum.c:707: static char    buf[4]   = {0};
      003121 90 0C 24         [24]  692 	mov	dptr,#_get_u8_str_buf_10000_688
      003124 E4               [12]  693 	clr	a
      003125 F0               [24]  694 	movx	@dptr,a
      003126 90 0C 25         [24]  695 	mov	dptr,#(_get_u8_str_buf_10000_688 + 0x0001)
      003129 F0               [24]  696 	movx	@dptr,a
      00312A 90 0C 26         [24]  697 	mov	dptr,#(_get_u8_str_buf_10000_688 + 0x0002)
      00312D F0               [24]  698 	movx	@dptr,a
      00312E 90 0C 27         [24]  699 	mov	dptr,#(_get_u8_str_buf_10000_688 + 0x0003)
      003131 F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/quantum.c:708: static uint8_t last_num = 0xFF;
      003132 90 0C 28         [24]  702 	mov	dptr,#_get_u8_str_last_num_10000_688
      003135 14               [12]  703 	dec	a
      003136 F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/quantum.c:709: static char    last_pad = '\0';
      003137 90 0C 29         [24]  706 	mov	dptr,#_get_u8_str_last_pad_10000_688
      00313A E4               [12]  707 	clr	a
      00313B F0               [24]  708 	movx	@dptr,a
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'get_u16_str'
                                    711 ;------------------------------------------------------------
                                    712 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    713 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_691'
                                    714 ;buf           Allocated with name '_get_u16_str_buf_10000_692'
                                    715 ;last_num      Allocated with name '_get_u16_str_last_num_10000_692'
                                    716 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_692'
                                    717 ;------------------------------------------------------------
                                    718 ;	quantum/quantum.c:727: static char     buf[6]   = {0};
      00313C 90 0C 2A         [24]  719 	mov	dptr,#_get_u16_str_buf_10000_692
      00313F E4               [12]  720 	clr	a
      003140 F0               [24]  721 	movx	@dptr,a
      003141 90 0C 2B         [24]  722 	mov	dptr,#(_get_u16_str_buf_10000_692 + 0x0001)
      003144 F0               [24]  723 	movx	@dptr,a
      003145 90 0C 2C         [24]  724 	mov	dptr,#(_get_u16_str_buf_10000_692 + 0x0002)
      003148 F0               [24]  725 	movx	@dptr,a
      003149 90 0C 2D         [24]  726 	mov	dptr,#(_get_u16_str_buf_10000_692 + 0x0003)
      00314C F0               [24]  727 	movx	@dptr,a
      00314D 90 0C 2E         [24]  728 	mov	dptr,#(_get_u16_str_buf_10000_692 + 0x0004)
      003150 F0               [24]  729 	movx	@dptr,a
      003151 90 0C 2F         [24]  730 	mov	dptr,#(_get_u16_str_buf_10000_692 + 0x0005)
      003154 F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/quantum.c:728: static uint16_t last_num = 0xFF;
      003155 90 0C 30         [24]  733 	mov	dptr,#_get_u16_str_last_num_10000_692
      003158 14               [12]  734 	dec	a
      003159 F0               [24]  735 	movx	@dptr,a
      00315A E4               [12]  736 	clr	a
      00315B A3               [24]  737 	inc	dptr
      00315C F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/quantum.c:729: static char     last_pad = '\0';
      00315D 90 0C 32         [24]  740 	mov	dptr,#_get_u16_str_last_pad_10000_692
      003160 F0               [24]  741 	movx	@dptr,a
                                    742 ;--------------------------------------------------------
                                    743 ; Home
                                    744 ;--------------------------------------------------------
                                    745 	.area HOME    (CODE)
                                    746 	.area HOME    (CODE)
                                    747 ;--------------------------------------------------------
                                    748 ; code
                                    749 ;--------------------------------------------------------
                                    750 	.area CSEG    (CODE)
                                    751 ;------------------------------------------------------------
                                    752 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    753 ;------------------------------------------------------------
                                    754 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    757 ;	-----------------------------------------
                           000007   758 	ar7 = 0x07
                           000006   759 	ar6 = 0x06
                           000005   760 	ar5 = 0x05
                           000004   761 	ar4 = 0x04
                           000003   762 	ar3 = 0x03
                           000002   763 	ar2 = 0x02
                           000001   764 	ar1 = 0x01
                           000000   765 	ar0 = 0x00
                                    766 ;	 function extract_mod_bits
                                    767 ;	-----------------------------------------
      00A0A1                        768 _extract_mod_bits:
      00A0A1 12 39 03         [24]  769 	lcall	_ak820_outline_0122
      00A0A4 90 0B E8         [24]  770 	mov	dptr,#_extract_mod_bits_code_10000_592
      00A0A7 12 38 FE         [24]  771 	lcall	_ak820_outline_0121
                                    772 ;	quantum/quantum.c:104: uint8_t mods = (uint8_t)(code >> 8);
      00A0AA 90 0B E8         [24]  773 	mov	dptr,#_extract_mod_bits_code_10000_592
      00A0AD E0               [24]  774 	movx	a,@dptr
      00A0AE A3               [24]  775 	inc	dptr
      00A0AF E0               [24]  776 	movx	a,@dptr
                                    777 ;	quantum/quantum.c:105: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A0B0 FF               [12]  778 	mov	r7,a
      00A0B1 60 05            [24]  779 	jz	00101$
      00A0B3 EF               [12]  780 	mov	a,r7
      00A0B4 24 E0            [12]  781 	add	a,#0xff - 0x1f
      00A0B6 50 04            [24]  782 	jnc	00102$
                                    783 ;	free result
      00A0B8                        784 00101$:
      00A0B8 75 82 00         [24]  785 	mov	dpl, #0x00
      00A0BB 22               [24]  786 	ret
      00A0BC                        787 00102$:
                                    788 ;	quantum/quantum.c:106: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A0BC EF               [12]  789 	mov	a,r7
      00A0BD 30 E4 07         [24]  790 	jnb	acc.4,00106$
      00A0C0 EF               [12]  791 	mov	a,r7
      00A0C1 C4               [12]  792 	swap	a
      00A0C2 54 F0            [12]  793 	anl	a,#0xf0
      00A0C4 FE               [12]  794 	mov	r6,a
      00A0C5 80 02            [24]  795 	sjmp	00107$
      00A0C7                        796 00106$:
      00A0C7 8F 06            [24]  797 	mov	ar6,r7
      00A0C9                        798 00107$:
      00A0C9 8E 82            [24]  799 	mov	dpl, r6
                                    800 ;	quantum/quantum.c:134: }
      00A0CB 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'do_code16'
                                    804 ;------------------------------------------------------------
                                    805 ;f             Allocated with name '_do_code16_PARM_2'
                                    806 ;code          Allocated with name '_do_code16_code_10000_595'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/quantum.c:136: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function register_code16
                                    811 ;	-----------------------------------------
      00A0CC                        812 _register_code16:
      00A0CC 12 39 03         [24]  813 	lcall	_ak820_outline_0122
      00A0CF 90 0B EA         [24]  814 	mov	dptr,#_register_code16_code_10000_598
      00A0D2 12 38 FE         [24]  815 	lcall	_ak820_outline_0121
                                    816 ;	quantum/quantum.c:142: uint8_t mods = extract_mod_bits(code);
      00A0D5 90 0B EA         [24]  817 	mov	dptr,#_register_code16_code_10000_598
      00A0D8 12 38 81         [24]  818 	lcall	_ak820_outline_0010
      00A0DB C0 07            [24]  819 	push	ar7
      00A0DD C0 06            [24]  820 	push	ar6
      00A0DF 12 A0 A1         [24]  821 	lcall	_extract_mod_bits
      00A0E2 AD 82            [24]  822 	mov	r5, dpl
      00A0E4 D0 06            [24]  823 	pop	ar6
      00A0E6 D0 07            [24]  824 	pop	ar7
                                    825 ;	quantum/quantum.c:143: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A0E8 12 9E 55         [24]  826 	lcall	_ak820_outline_0124
      00A0EB 40 07            [24]  827 	jc	00105$
      00A0ED 74 E7            [12]  828 	mov	a,#0xe7
      00A0EF 9E               [12]  829 	subb	a,r6
      00A0F0 E4               [12]  830 	clr	a
      00A0F1 9F               [12]  831 	subb	a,r7
      00A0F2 50 08            [24]  832 	jnc	00101$
                                    833 ;	free result
      00A0F4                        834 00105$:
      00A0F4 90 0B EA         [24]  835 	mov	dptr,#_register_code16_code_10000_598
      00A0F7 12 6E 56         [24]  836 	lcall	_ak820_outline_0041
      00A0FA 70 07            [24]  837 	jnz	00102$
      00A0FC                        838 00101$:
                                    839 ;	quantum/quantum.c:144: register_mods(mods);
      00A0FC 8D 82            [24]  840 	mov	dpl, r5
      00A0FE 12 77 11         [24]  841 	lcall	_register_mods
      00A101 80 05            [24]  842 	sjmp	00103$
      00A103                        843 00102$:
                                    844 ;	quantum/quantum.c:146: register_weak_mods(mods);
      00A103 8D 82            [24]  845 	mov	dpl, r5
      00A105 12 77 39         [24]  846 	lcall	_register_weak_mods
      00A108                        847 00103$:
                                    848 ;	quantum/quantum.c:148: register_code(code);
      00A108 90 0B EA         [24]  849 	mov	dptr,#_register_code16_code_10000_598
      00A10B E0               [24]  850 	movx	a,@dptr
      00A10C F5 82            [12]  851 	mov	dpl,a
                                    852 ;	quantum/quantum.c:158: }
      00A10E 02 75 EE         [24]  853 	ljmp	_register_code
                                    854 ;------------------------------------------------------------
                                    855 ;Allocation info for local variables in function 'unregister_code16'
                                    856 ;------------------------------------------------------------
                                    857 ;code          Allocated with name '_unregister_code16_code_10000_603'
                                    858 ;mods          Allocated with name '_unregister_code16_mods_10000_604'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/quantum.c:160: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function unregister_code16
                                    863 ;	-----------------------------------------
      00A111                        864 _unregister_code16:
      00A111 12 39 03         [24]  865 	lcall	_ak820_outline_0122
      00A114 90 0B EC         [24]  866 	mov	dptr,#_unregister_code16_code_10000_603
      00A117 12 38 FE         [24]  867 	lcall	_ak820_outline_0121
                                    868 ;	quantum/quantum.c:162: uint8_t mods = extract_mod_bits(code);
      00A11A 90 0B EC         [24]  869 	mov	dptr,#_unregister_code16_code_10000_603
      00A11D 12 38 81         [24]  870 	lcall	_ak820_outline_0010
      00A120 C0 07            [24]  871 	push	ar7
      00A122 C0 06            [24]  872 	push	ar6
      00A124 12 A0 A1         [24]  873 	lcall	_extract_mod_bits
      00A127 AD 82            [24]  874 	mov	r5, dpl
      00A129 D0 06            [24]  875 	pop	ar6
                                    876 ;	quantum/quantum.c:163: unregister_code(code);
      00A12B 8E 04            [24]  877 	mov	ar4,r6
      00A12D 8C 82            [24]  878 	mov	dpl, r4
      00A12F C0 06            [24]  879 	push	ar6
      00A131 C0 05            [24]  880 	push	ar5
      00A133 12 76 5B         [24]  881 	lcall	_unregister_code
      00A136 D0 05            [24]  882 	pop	ar5
      00A138 D0 06            [24]  883 	pop	ar6
      00A13A D0 07            [24]  884 	pop	ar7
                                    885 ;	quantum/quantum.c:164: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A13C 12 9E 55         [24]  886 	lcall	_ak820_outline_0124
      00A13F 40 07            [24]  887 	jc	00105$
      00A141 74 E7            [12]  888 	mov	a,#0xe7
      00A143 9E               [12]  889 	subb	a,r6
      00A144 E4               [12]  890 	clr	a
      00A145 9F               [12]  891 	subb	a,r7
      00A146 50 08            [24]  892 	jnc	00101$
                                    893 ;	free result
      00A148                        894 00105$:
      00A148 90 0B EC         [24]  895 	mov	dptr,#_unregister_code16_code_10000_603
      00A14B 12 6E 56         [24]  896 	lcall	_ak820_outline_0041
      00A14E 70 05            [24]  897 	jnz	00102$
      00A150                        898 00101$:
                                    899 ;	quantum/quantum.c:165: unregister_mods(mods);
      00A150 8D 82            [24]  900 	mov	dpl, r5
      00A152 02 77 25         [24]  901 	ljmp	_unregister_mods
      00A155                        902 00102$:
                                    903 ;	quantum/quantum.c:167: unregister_weak_mods(mods);
      00A155 8D 82            [24]  904 	mov	dpl, r5
                                    905 ;	quantum/quantum.c:178: }
      00A157 02 77 4D         [24]  906 	ljmp	_unregister_weak_mods
                                    907 ;------------------------------------------------------------
                                    908 ;Allocation info for local variables in function 'tap_code16_delay'
                                    909 ;------------------------------------------------------------
                                    910 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    911 ;code          Allocated with name '_tap_code16_delay_code_10000_608'
                                    912 ;i             Allocated with name '_tap_code16_delay_i_20000_610'
                                    913 ;i             Allocated with name '_tap_code16_delay_i_50000_613'
                                    914 ;------------------------------------------------------------
                                    915 ;	quantum/quantum.c:185: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function pre_process_record_kb
                                    918 ;	-----------------------------------------
      00A15A                        919 _pre_process_record_kb:
      00A15A 12 39 03         [24]  920 	lcall	_ak820_outline_0122
      00A15D 90 0B F1         [24]  921 	mov	dptr,#_pre_process_record_kb_keycode_10000_617
      00A160 12 38 FE         [24]  922 	lcall	_ak820_outline_0121
                                    923 ;	quantum/quantum.c:202: return pre_process_record_user(keycode, record);
      00A163 90 0B F1         [24]  924 	mov	dptr,#_pre_process_record_kb_keycode_10000_617
      00A166 12 38 C3         [24]  925 	lcall	_ak820_outline_0060
      00A169 90 0B EE         [24]  926 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A16C 12 9E 4C         [24]  927 	lcall	_ak820_outline_0021
      00A16F 90 0B F3         [24]  928 	mov	dptr,#_pre_process_record_user_PARM_2
      00A172 12 A5 1C         [24]  929 	lcall	_ak820_outline_0003
                                    930 ;	quantum/quantum.c:203: }
      00A175 02 A1 78         [24]  931 	ljmp	_pre_process_record_user
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'pre_process_record_user'
                                    934 ;------------------------------------------------------------
                                    935 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    936 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_619'
                                    937 ;------------------------------------------------------------
                                    938 ;	quantum/quantum.c:205: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function pre_process_record_user
                                    941 ;	-----------------------------------------
      00A178                        942 _pre_process_record_user:
                                    943 ;	quantum/quantum.c:206: return true;
      00A178 75 82 01         [24]  944 	mov	dpl, #0x01
                                    945 ;	quantum/quantum.c:207: }
      00A17B 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'process_action_kb'
                                    949 ;------------------------------------------------------------
                                    950 ;record        Allocated with name '_process_action_kb_record_10000_621'
                                    951 ;------------------------------------------------------------
                                    952 ;	quantum/quantum.c:209: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    953 ;	-----------------------------------------
                                    954 ;	 function process_action_kb
                                    955 ;	-----------------------------------------
      00A17C                        956 _process_action_kb:
                                    957 ;	quantum/quantum.c:210: return true;
      00A17C 75 82 01         [24]  958 	mov	dpl, #0x01
                                    959 ;	quantum/quantum.c:211: }
      00A17F 22               [24]  960 	ret
                                    961 ;------------------------------------------------------------
                                    962 ;Allocation info for local variables in function 'process_record_kb'
                                    963 ;------------------------------------------------------------
                                    964 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    965 ;keycode       Allocated with name '_process_record_kb_keycode_10000_623'
                                    966 ;------------------------------------------------------------
                                    967 ;	quantum/quantum.c:213: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function process_record_kb
                                    970 ;	-----------------------------------------
      00A180                        971 _process_record_kb:
      00A180 12 39 03         [24]  972 	lcall	_ak820_outline_0122
      00A183 90 0B F9         [24]  973 	mov	dptr,#_process_record_kb_keycode_10000_623
      00A186 12 38 FE         [24]  974 	lcall	_ak820_outline_0121
                                    975 ;	quantum/quantum.c:214: return process_record_user(keycode, record);
      00A189 90 0B F9         [24]  976 	mov	dptr,#_process_record_kb_keycode_10000_623
      00A18C 12 38 C3         [24]  977 	lcall	_ak820_outline_0060
      00A18F 90 0B F6         [24]  978 	mov	dptr,#_process_record_kb_PARM_2
      00A192 12 9E 4C         [24]  979 	lcall	_ak820_outline_0021
      00A195 90 0B FB         [24]  980 	mov	dptr,#_process_record_user_PARM_2
      00A198 12 A5 1C         [24]  981 	lcall	_ak820_outline_0003
                                    982 ;	quantum/quantum.c:215: }
      00A19B 02 A1 9E         [24]  983 	ljmp	_process_record_user
                                    984 ;------------------------------------------------------------
                                    985 ;Allocation info for local variables in function 'process_record_user'
                                    986 ;------------------------------------------------------------
                                    987 ;record        Allocated with name '_process_record_user_PARM_2'
                                    988 ;keycode       Allocated with name '_process_record_user_keycode_10000_625'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/quantum.c:217: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    991 ;	-----------------------------------------
                                    992 ;	 function process_record_user
                                    993 ;	-----------------------------------------
      00A19E                        994 _process_record_user:
                                    995 ;	quantum/quantum.c:218: return true;
      00A19E 75 82 01         [24]  996 	mov	dpl, #0x01
                                    997 ;	quantum/quantum.c:219: }
      00A1A1 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'post_process_record_kb'
                                   1001 ;------------------------------------------------------------
                                   1002 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                   1003 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_627'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	quantum/quantum.c:221: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function post_process_record_kb
                                   1008 ;	-----------------------------------------
      00A1A2                       1009 _post_process_record_kb:
      00A1A2 12 39 03         [24] 1010 	lcall	_ak820_outline_0122
      00A1A5 90 0C 01         [24] 1011 	mov	dptr,#_post_process_record_kb_keycode_10000_627
      00A1A8 12 38 FE         [24] 1012 	lcall	_ak820_outline_0121
                                   1013 ;	quantum/quantum.c:222: post_process_record_user(keycode, record);
      00A1AB 90 0C 01         [24] 1014 	mov	dptr,#_post_process_record_kb_keycode_10000_627
      00A1AE 12 38 C3         [24] 1015 	lcall	_ak820_outline_0060
      00A1B1 90 0B FE         [24] 1016 	mov	dptr,#_post_process_record_kb_PARM_2
      00A1B4 12 9E 4C         [24] 1017 	lcall	_ak820_outline_0021
      00A1B7 90 0C 03         [24] 1018 	mov	dptr,#_post_process_record_user_PARM_2
      00A1BA 12 A5 1C         [24] 1019 	lcall	_ak820_outline_0003
                                   1020 ;	quantum/quantum.c:223: }
      00A1BD 02 A1 C0         [24] 1021 	ljmp	_post_process_record_user
                                   1022 ;------------------------------------------------------------
                                   1023 ;Allocation info for local variables in function 'post_process_record_user'
                                   1024 ;------------------------------------------------------------
                                   1025 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                   1026 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_629'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/quantum.c:225: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function post_process_record_user
                                   1031 ;	-----------------------------------------
      00A1C0                       1032 _post_process_record_user:
      00A1C0 22               [24] 1033 	ret
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'shutdown_quantum'
                                   1036 ;------------------------------------------------------------
                                   1037 ;i             Allocated with name '_shutdown_quantum_i_30000_635'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	quantum/quantum.c:227: void shutdown_quantum(void) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function shutdown_quantum
                                   1042 ;	-----------------------------------------
      00A1C1                       1043 _shutdown_quantum:
                                   1044 ;	quantum/quantum.c:228: clear_keyboard();
      00A1C1 12 77 61         [24] 1045 	lcall	_clear_keyboard
                                   1046 ;	quantum/quantum.c:243: shutdown_user();
      00A1C4 12 A5 04         [24] 1047 	lcall	_shutdown_user
                                   1048 ;	quantum/quantum.c:244: wait_ms(250);
      00A1C7 7F FA            [12] 1049 	mov	r7,#0xfa
      00A1C9                       1050 00106$:
      00A1C9 EF               [12] 1051 	mov	a,r7
      00A1CA 60 09            [24] 1052 	jz	00108$
      00A1CC 90 00 01         [24] 1053 	mov	dptr,#0x0001
      00A1CF 12 59 96         [24] 1054 	lcall	_mDelaymS
      00A1D2 1F               [12] 1055 	dec	r7
      00A1D3 80 F4            [24] 1056 	sjmp	00106$
      00A1D5                       1057 00108$:
                                   1058 ;	quantum/quantum.c:249: }
      00A1D5 22               [24] 1059 	ret
                                   1060 ;------------------------------------------------------------
                                   1061 ;Allocation info for local variables in function 'reset_keyboard'
                                   1062 ;------------------------------------------------------------
                                   1063 ;	quantum/quantum.c:251: void reset_keyboard(void) {
                                   1064 ;	-----------------------------------------
                                   1065 ;	 function reset_keyboard
                                   1066 ;	-----------------------------------------
      00A1D6                       1067 _reset_keyboard:
                                   1068 ;	quantum/quantum.c:252: shutdown_quantum();
      00A1D6 12 A1 C1         [24] 1069 	lcall	_shutdown_quantum
                                   1070 ;	quantum/quantum.c:253: bootloader_jump();
                                   1071 ;	quantum/quantum.c:254: }
      00A1D9 02 34 92         [24] 1072 	ljmp	_bootloader_jump
                                   1073 ;------------------------------------------------------------
                                   1074 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1075 ;------------------------------------------------------------
                                   1076 ;	quantum/quantum.c:256: void soft_reset_keyboard(void) {
                                   1077 ;	-----------------------------------------
                                   1078 ;	 function soft_reset_keyboard
                                   1079 ;	-----------------------------------------
      00A1DC                       1080 _soft_reset_keyboard:
                                   1081 ;	quantum/quantum.c:257: shutdown_quantum();
      00A1DC 12 A1 C1         [24] 1082 	lcall	_shutdown_quantum
                                   1083 ;	quantum/quantum.c:258: mcu_reset();
                                   1084 ;	quantum/quantum.c:259: }
      00A1DF 02 34 85         [24] 1085 	ljmp	_mcu_reset
                                   1086 ;------------------------------------------------------------
                                   1087 ;Allocation info for local variables in function 'get_record_keycode'
                                   1088 ;------------------------------------------------------------
                                   1089 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1090 ;record        Allocated with name '_get_record_keycode_record_10000_641'
                                   1091 ;------------------------------------------------------------
                                   1092 ;	quantum/quantum.c:262: uint16_t get_record_keycode(keyrecord_t *record, bool update_layer_cache) {
                                   1093 ;	-----------------------------------------
                                   1094 ;	 function get_record_keycode
                                   1095 ;	-----------------------------------------
      00A1E2                       1096 _get_record_keycode:
      00A1E2 12 43 80         [24] 1097 	lcall	_ak820_outline_0036
      00A1E5 90 0C 07         [24] 1098 	mov	dptr,#_get_record_keycode_record_10000_641
      00A1E8 12 38 8B         [24] 1099 	lcall	_ak820_outline_0017
                                   1100 ;	quantum/quantum.c:264: if (record->keycode) {
      00A1EB 90 0C 07         [24] 1101 	mov	dptr,#_get_record_keycode_record_10000_641
      00A1EE 12 4F 61         [24] 1102 	lcall	_ak820_outline_0014
      00A1F1 12 77 CE         [24] 1103 	lcall	_ak820_outline_0069
      00A1F4 12 BC E0         [24] 1104 	lcall	__gptrget
      00A1F7 FB               [12] 1105 	mov	r3,a
      00A1F8 A3               [24] 1106 	inc	dptr
      00A1F9 12 BC E0         [24] 1107 	lcall	__gptrget
      00A1FC FC               [12] 1108 	mov	r4,a
      00A1FD 4B               [12] 1109 	orl	a,r3
      00A1FE 60 04            [24] 1110 	jz	00102$
                                   1111 ;	quantum/quantum.c:265: return record->keycode;
      00A200 12 34 71         [24] 1112 	lcall	_ak820_outline_0129
      00A203 22               [24] 1113 	ret
      00A204                       1114 00102$:
                                   1115 ;	quantum/quantum.c:268: return get_event_keycode(record->event, update_layer_cache);
      00A204 90 0C 06         [24] 1116 	mov	dptr,#_get_record_keycode_PARM_2
      00A207 E0               [24] 1117 	movx	a,@dptr
      00A208 FC               [12] 1118 	mov	r4,a
      00A209 90 0D C2         [24] 1119 	mov	dptr,#___memcpy_PARM_2
      00A20C ED               [12] 1120 	mov	a,r5
      00A20D 12 38 8B         [24] 1121 	lcall	_ak820_outline_0017
      00A210 90 0D C5         [24] 1122 	mov	dptr,#___memcpy_PARM_3
      00A213 74 06            [12] 1123 	mov	a,#0x06
      00A215 12 39 0D         [24] 1124 	lcall	_ak820_outline_0130
      00A218 90 0C 0A         [24] 1125 	mov	dptr,#_get_event_keycode_PARM_1
      00A21B F5 F0            [12] 1126 	mov	b,a
      00A21D C0 04            [24] 1127 	push	ar4
      00A21F 12 BC 07         [24] 1128 	lcall	___memcpy
      00A222 D0 04            [24] 1129 	pop	ar4
      00A224 8C 82            [24] 1130 	mov	dpl, r4
                                   1131 ;	quantum/quantum.c:269: }
      00A226 02 A2 29         [24] 1132 	ljmp	_get_event_keycode
                                   1133 ;------------------------------------------------------------
                                   1134 ;Allocation info for local variables in function 'get_event_keycode'
                                   1135 ;------------------------------------------------------------
                                   1136 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1137 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_645'
                                   1138 ;layer         Allocated with name '_get_event_keycode_layer_30000_648'
                                   1139 ;------------------------------------------------------------
                                   1140 ;	quantum/quantum.c:277: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1141 ;	-----------------------------------------
                                   1142 ;	 function get_event_keycode
                                   1143 ;	-----------------------------------------
      00A229                       1144 _get_event_keycode:
      00A229 E5 82            [12] 1145 	mov	a,dpl
      00A22B 90 0C 10         [24] 1146 	mov	dptr,#_get_event_keycode_update_layer_cache_10000_645
      00A22E F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/quantum.c:280: if (!disable_action_cache) {
      00A22F 90 0D E2         [24] 1149 	mov	dptr,#_disable_action_cache
      00A232 E0               [24] 1150 	movx	a,@dptr
      00A233 70 3E            [24] 1151 	jnz	00105$
                                   1152 ;	quantum/quantum.c:283: if (event.pressed && update_layer_cache) {
      00A235 90 0C 0F         [24] 1153 	mov	dptr,#(_get_event_keycode_PARM_1 + 0x0005)
      00A238 E0               [24] 1154 	movx	a,@dptr
      00A239 60 2A            [24] 1155 	jz	00102$
      00A23B 90 0C 10         [24] 1156 	mov	dptr,#_get_event_keycode_update_layer_cache_10000_645
      00A23E E0               [24] 1157 	movx	a,@dptr
      00A23F 60 24            [24] 1158 	jz	00102$
                                   1159 ;	quantum/quantum.c:284: layer = layer_switch_get_layer(event.key);
      00A241 12 A5 05         [24] 1160 	lcall	_ak820_outline_0001
      00A244 90 09 64         [24] 1161 	mov	dptr,#_layer_switch_get_layer_PARM_1
      00A247 F5 F0            [12] 1162 	mov	b,a
      00A249 12 BC 07         [24] 1163 	lcall	___memcpy
      00A24C 12 7B D9         [24] 1164 	lcall	_layer_switch_get_layer
      00A24F AF 82            [24] 1165 	mov	r7, dpl
                                   1166 ;	quantum/quantum.c:285: update_source_layers_cache(event.key, layer);
      00A251 12 A5 05         [24] 1167 	lcall	_ak820_outline_0001
      00A254 90 09 5C         [24] 1168 	mov	dptr,#_update_source_layers_cache_PARM_1
      00A257 F5 F0            [12] 1169 	mov	b,a
      00A259 C0 07            [24] 1170 	push	ar7
      00A25B 12 BC 07         [24] 1171 	lcall	___memcpy
      00A25E D0 07            [24] 1172 	pop	ar7
      00A260 8F 82            [24] 1173 	mov	dpl, r7
      00A262 12 7A D3         [24] 1174 	lcall	_update_source_layers_cache
      00A265                       1175 00102$:
                                   1176 ;	quantum/quantum.c:288: return read_source_keycode_cache(event.key);
      00A265 12 A5 05         [24] 1177 	lcall	_ak820_outline_0001
      00A268 90 09 5F         [24] 1178 	mov	dptr,#_read_source_keycode_cache_PARM_1
      00A26B F5 F0            [12] 1179 	mov	b,a
      00A26D 12 BC 07         [24] 1180 	lcall	___memcpy
      00A270 02 7B 28         [24] 1181 	ljmp	_read_source_keycode_cache
      00A273                       1182 00105$:
                                   1183 ;	quantum/quantum.c:300: return keymap_key_to_keycode(layer_switch_get_layer(event.key), event.key);
      00A273 12 A5 05         [24] 1184 	lcall	_ak820_outline_0001
      00A276 90 09 64         [24] 1185 	mov	dptr,#_layer_switch_get_layer_PARM_1
      00A279 F5 F0            [12] 1186 	mov	b,a
      00A27B 12 BC 07         [24] 1187 	lcall	___memcpy
      00A27E 12 7B D9         [24] 1188 	lcall	_layer_switch_get_layer
      00A281 AF 82            [24] 1189 	mov	r7, dpl
      00A283 12 A5 05         [24] 1190 	lcall	_ak820_outline_0001
      00A286 90 0B A7         [24] 1191 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      00A289 F5 F0            [12] 1192 	mov	b,a
      00A28B C0 07            [24] 1193 	push	ar7
      00A28D 12 BC 07         [24] 1194 	lcall	___memcpy
      00A290 D0 07            [24] 1195 	pop	ar7
      00A292 8F 82            [24] 1196 	mov	dpl, r7
                                   1197 ;	quantum/quantum.c:301: }
      00A294 02 98 36         [24] 1198 	ljmp	_keymap_key_to_keycode
                                   1199 ;------------------------------------------------------------
                                   1200 ;Allocation info for local variables in function 'pre_process_record_quantum'
                                   1201 ;------------------------------------------------------------
                                   1202 ;record        Allocated with name '_pre_process_record_quantum_record_10000_651'
                                   1203 ;keycode       Allocated with name '_pre_process_record_quantum_keycode_10000_652'
                                   1204 ;------------------------------------------------------------
                                   1205 ;	quantum/quantum.c:304: bool pre_process_record_quantum(keyrecord_t *record) {
                                   1206 ;	-----------------------------------------
                                   1207 ;	 function pre_process_record_quantum
                                   1208 ;	-----------------------------------------
      00A297                       1209 _pre_process_record_quantum:
      00A297 12 43 80         [24] 1210 	lcall	_ak820_outline_0036
      00A29A 90 0C 11         [24] 1211 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A29D 12 38 8B         [24] 1212 	lcall	_ak820_outline_0017
                                   1213 ;	quantum/quantum.c:305: uint16_t keycode = get_record_keycode(record, true);
      00A2A0 90 0C 11         [24] 1214 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A2A3 12 4F 61         [24] 1215 	lcall	_ak820_outline_0014
      00A2A6 90 0C 06         [24] 1216 	mov	dptr,#_get_record_keycode_PARM_2
      00A2A9 74 01            [12] 1217 	mov	a,#0x01
      00A2AB 12 4F 6A         [24] 1218 	lcall	_ak820_outline_0033
      00A2AE 12 A1 E2         [24] 1219 	lcall	_get_record_keycode
      00A2B1 12 43 D5         [24] 1220 	lcall	_ak820_outline_0131
                                   1221 ;	quantum/quantum.c:307: record->keycode = keycode;
      00A2B4 90 0C 11         [24] 1222 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A2B7 12 9E 4C         [24] 1223 	lcall	_ak820_outline_0021
      00A2BA 74 07            [12] 1224 	mov	a,#0x07
      00A2BC 2B               [12] 1225 	add	a, r3
      00A2BD F8               [12] 1226 	mov	r0,a
      00A2BE E4               [12] 1227 	clr	a
      00A2BF 3C               [12] 1228 	addc	a, r4
      00A2C0 F9               [12] 1229 	mov	r1,a
      00A2C1 8D 02            [24] 1230 	mov	ar2,r5
      00A2C3 12 49 06         [24] 1231 	lcall	_ak820_outline_0084
      00A2C6 EE               [12] 1232 	mov	a,r6
      00A2C7 12 BC A5         [24] 1233 	lcall	__gptrput
      00A2CA A3               [24] 1234 	inc	dptr
      00A2CB EF               [12] 1235 	mov	a,r7
      00A2CC 12 BC A5         [24] 1236 	lcall	__gptrput
                                   1237 ;	quantum/quantum.c:309: return pre_process_record_kb(keycode, record) &&
      00A2CF 90 0B EE         [24] 1238 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A2D2 12 A5 1C         [24] 1239 	lcall	_ak820_outline_0003
      00A2D5 12 A1 5A         [24] 1240 	lcall	_pre_process_record_kb
      00A2D8 E5 82            [12] 1241 	mov	a, dpl
      00A2DA 60 0D            [24] 1242 	jz	00103$
                                   1243 ;	quantum/quantum.c:312: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A2DC 90 0C 11         [24] 1244 	mov	dptr,#_pre_process_record_quantum_record_10000_651
      00A2DF 12 38 81         [24] 1245 	lcall	_ak820_outline_0010
      00A2E2 12 36 BD         [24] 1246 	lcall	_ak820_combo_process
      00A2E5 E5 82            [12] 1247 	mov	a, dpl
      00A2E7 70 04            [24] 1248 	jnz	00104$
                                   1249 ;	quantum/quantum.c:317: true;
      00A2E9                       1250 00103$:
                                   1251 ;	assignBit
      00A2E9 C2 25            [12] 1252 	clr	_pre_process_record_quantum_sloc0_1_0
      00A2EB 80 02            [24] 1253 	sjmp	00105$
      00A2ED                       1254 00104$:
                                   1255 ;	assignBit
      00A2ED D2 25            [12] 1256 	setb	_pre_process_record_quantum_sloc0_1_0
      00A2EF                       1257 00105$:
      00A2EF A2 25            [12] 1258 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A2F1 12 39 33         [24] 1259 	lcall	_ak820_outline_0163
                                   1260 ;	quantum/quantum.c:318: }
      00A2F4 22               [24] 1261 	ret
                                   1262 ;------------------------------------------------------------
                                   1263 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1264 ;------------------------------------------------------------
                                   1265 ;record        Allocated with name '_post_process_record_quantum_record_10000_653'
                                   1266 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_654'
                                   1267 ;------------------------------------------------------------
                                   1268 ;	quantum/quantum.c:321: void post_process_record_quantum(keyrecord_t *record) {
                                   1269 ;	-----------------------------------------
                                   1270 ;	 function post_process_record_quantum
                                   1271 ;	-----------------------------------------
      00A2F5                       1272 _post_process_record_quantum:
      00A2F5 12 43 80         [24] 1273 	lcall	_ak820_outline_0036
      00A2F8 90 0C 14         [24] 1274 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A2FB 12 38 8B         [24] 1275 	lcall	_ak820_outline_0017
                                   1276 ;	quantum/quantum.c:322: uint16_t keycode = get_record_keycode(record, false);
      00A2FE 90 0C 14         [24] 1277 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A301 12 4F 61         [24] 1278 	lcall	_ak820_outline_0014
      00A304 90 0C 06         [24] 1279 	mov	dptr,#_get_record_keycode_PARM_2
      00A307 E4               [12] 1280 	clr	a
      00A308 12 4F 6A         [24] 1281 	lcall	_ak820_outline_0033
      00A30B 12 A1 E2         [24] 1282 	lcall	_get_record_keycode
      00A30E 12 43 D5         [24] 1283 	lcall	_ak820_outline_0131
                                   1284 ;	quantum/quantum.c:323: post_process_record_kb(keycode, record);
      00A311 90 0C 14         [24] 1285 	mov	dptr,#_post_process_record_quantum_record_10000_653
      00A314 12 9E 4C         [24] 1286 	lcall	_ak820_outline_0021
      00A317 90 0B FE         [24] 1287 	mov	dptr,#_post_process_record_kb_PARM_2
      00A31A 12 A5 1C         [24] 1288 	lcall	_ak820_outline_0003
                                   1289 ;	quantum/quantum.c:324: }
      00A31D 02 A1 A2         [24] 1290 	ljmp	_post_process_record_kb
                                   1291 ;------------------------------------------------------------
                                   1292 ;Allocation info for local variables in function 'process_record_quantum'
                                   1293 ;------------------------------------------------------------
                                   1294 ;record        Allocated with name '_process_record_quantum_record_10000_655'
                                   1295 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_656'
                                   1296 ;------------------------------------------------------------
                                   1297 ;	quantum/quantum.c:326: bool process_record_quantum(keyrecord_t *record) {
                                   1298 ;	-----------------------------------------
                                   1299 ;	 function process_record_quantum
                                   1300 ;	-----------------------------------------
      00A320                       1301 _process_record_quantum:
      00A320 12 43 80         [24] 1302 	lcall	_ak820_outline_0036
      00A323 90 0C 17         [24] 1303 	mov	dptr,#_process_record_quantum_record_10000_655
      00A326 12 38 8B         [24] 1304 	lcall	_ak820_outline_0017
                                   1305 ;	quantum/quantum.c:328: uint16_t keycode = get_record_keycode(record, false);
      00A329 90 0C 17         [24] 1306 	mov	dptr,#_process_record_quantum_record_10000_655
      00A32C 12 4F 61         [24] 1307 	lcall	_ak820_outline_0014
      00A32F 90 0C 06         [24] 1308 	mov	dptr,#_get_record_keycode_PARM_2
      00A332 E4               [12] 1309 	clr	a
      00A333 12 4F 6A         [24] 1310 	lcall	_ak820_outline_0033
      00A336 12 A1 E2         [24] 1311 	lcall	_get_record_keycode
      00A339 12 43 D5         [24] 1312 	lcall	_ak820_outline_0131
                                   1313 ;	quantum/quantum.c:332: return process_record_quantum_helper(keycode, record);
      00A33C 90 0C 17         [24] 1314 	mov	dptr,#_process_record_quantum_record_10000_655
      00A33F 12 9E 4C         [24] 1315 	lcall	_ak820_outline_0021
      00A342 90 0C 1F         [24] 1316 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A345 12 A5 1C         [24] 1317 	lcall	_ak820_outline_0003
                                   1318 ;	quantum/quantum.c:333: }
      00A348 02 A3 C0         [24] 1319 	ljmp	_process_record_quantum_helper
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1322 ;------------------------------------------------------------
                                   1323 ;record        Allocated with name '_process_ak820_nkro_PARM_2'
                                   1324 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_657'
                                   1325 ;------------------------------------------------------------
                                   1326 ;	quantum/quantum.c:340: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record) {
                                   1327 ;	-----------------------------------------
                                   1328 ;	 function process_ak820_nkro
                                   1329 ;	-----------------------------------------
      00A34B                       1330 _process_ak820_nkro:
      00A34B 12 39 03         [24] 1331 	lcall	_ak820_outline_0122
      00A34E 90 0C 1D         [24] 1332 	mov	dptr,#_process_ak820_nkro_keycode_10000_657
      00A351 12 38 FE         [24] 1333 	lcall	_ak820_outline_0121
                                   1334 ;	quantum/quantum.c:341: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A354 90 0C 1D         [24] 1335 	mov	dptr,#_process_ak820_nkro_keycode_10000_657
      00A357 12 38 C3         [24] 1336 	lcall	_ak820_outline_0060
      00A35A C3               [12] 1337 	clr	c
      00A35B EE               [12] 1338 	mov	a,r6
      00A35C 94 11            [12] 1339 	subb	a,#0x11
      00A35E EF               [12] 1340 	mov	a,r7
      00A35F 94 70            [12] 1341 	subb	a,#0x70
      00A361 40 08            [24] 1342 	jc	00101$
      00A363 74 13            [12] 1343 	mov	a,#0x13
      00A365 9E               [12] 1344 	subb	a,r6
      00A366 74 70            [12] 1345 	mov	a,#0x70
      00A368 9F               [12] 1346 	subb	a,r7
      00A369 50 04            [24] 1347 	jnc	00102$
                                   1348 ;	free result
      00A36B                       1349 00101$:
      00A36B 75 82 01         [24] 1350 	mov	dpl, #0x01
      00A36E 22               [24] 1351 	ret
      00A36F                       1352 00102$:
                                   1353 ;	quantum/quantum.c:342: if (record->event.pressed) {
      00A36F 90 0C 1A         [24] 1354 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A372 12 9E 4C         [24] 1355 	lcall	_ak820_outline_0021
      00A375 74 05            [12] 1356 	mov	a,#0x05
      00A377 2B               [12] 1357 	add	a, r3
      00A378 FB               [12] 1358 	mov	r3,a
      00A379 E4               [12] 1359 	clr	a
      00A37A 3C               [12] 1360 	addc	a, r4
      00A37B FC               [12] 1361 	mov	r4,a
      00A37C 12 70 8D         [24] 1362 	lcall	_ak820_outline_0102
      00A37F 12 BC E0         [24] 1363 	lcall	__gptrget
      00A382 60 38            [24] 1364 	jz	00105$
                                   1365 ;	quantum/quantum.c:343: clear_keyboard();
      00A384 C0 07            [24] 1366 	push	ar7
      00A386 C0 06            [24] 1367 	push	ar6
      00A388 12 77 61         [24] 1368 	lcall	_clear_keyboard
      00A38B D0 06            [24] 1369 	pop	ar6
      00A38D D0 07            [24] 1370 	pop	ar7
                                   1371 ;	quantum/quantum.c:344: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A38F BE 13 14         [24] 1372 	cjne	r6,#0x13,00108$
      00A392 BF 70 11         [24] 1373 	cjne	r7,#0x70,00108$
      00A395 90 0A B7         [24] 1374 	mov	dptr,#_keymap_config
      00A398 E0               [24] 1375 	movx	a,@dptr
      00A399 23               [12] 1376 	rl	a
      00A39A 54 01            [12] 1377 	anl	a,#0x01
      00A39C B4 01 00         [24] 1378 	cjne	a,#0x01,00136$
      00A39F                       1379 00136$:
      00A39F 92 26            [24] 1380 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A3A1 E4               [12] 1381 	clr	a
      00A3A2 33               [12] 1382 	rlc	a
      00A3A3 FD               [12] 1383 	mov	r5,a
      00A3A4 80 09            [24] 1384 	sjmp	00109$
      00A3A6                       1385 00108$:
      00A3A6 E4               [12] 1386 	clr	a
      00A3A7 BE 11 04         [24] 1387 	cjne	r6,#0x11,00137$
      00A3AA BF 70 01         [24] 1388 	cjne	r7,#0x70,00137$
      00A3AD 04               [12] 1389 	inc	a
      00A3AE                       1390 00137$:
      00A3AE FD               [12] 1391 	mov	r5,a
      00A3AF                       1392 00109$:
                                   1393 ;	assignBit
      00A3AF ED               [12] 1394 	mov	a,r5
      00A3B0 24 FF            [12] 1395 	add	a,#0xff
      00A3B2 E4               [12] 1396 	clr	a
      00A3B3 33               [12] 1397 	rlc	a
      00A3B4 90 0A B7         [24] 1398 	mov	dptr,#_keymap_config
      00A3B7 13               [12] 1399 	rrc	a
      00A3B8 E0               [24] 1400 	movx	a,@dptr
      00A3B9 92 E7            [24] 1401 	mov	acc.7,c
      00A3BB F0               [24] 1402 	movx	@dptr,a
      00A3BC                       1403 00105$:
                                   1404 ;	quantum/quantum.c:346: return false;
      00A3BC 75 82 00         [24] 1405 	mov	dpl, #0x00
                                   1406 ;	quantum/quantum.c:347: }
      00A3BF 22               [24] 1407 	ret
                                   1408 ;------------------------------------------------------------
                                   1409 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1410 ;------------------------------------------------------------
                                   1411 ;record        Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1412 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_662'
                                   1413 ;------------------------------------------------------------
                                   1414 ;	quantum/quantum.c:350: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record) {
                                   1415 ;	-----------------------------------------
                                   1416 ;	 function process_record_quantum_helper
                                   1417 ;	-----------------------------------------
      00A3C0                       1418 _process_record_quantum_helper:
      00A3C0 12 39 03         [24] 1419 	lcall	_ak820_outline_0122
      00A3C3 90 0C 22         [24] 1420 	mov	dptr,#_process_record_quantum_helper_keycode_10000_662
      00A3C6 12 38 FE         [24] 1421 	lcall	_ak820_outline_0121
                                   1422 ;	quantum/quantum.c:387: process_ak820_nkro(keycode, record) &&
      00A3C9 90 0C 22         [24] 1423 	mov	dptr,#_process_record_quantum_helper_keycode_10000_662
      00A3CC 12 38 C3         [24] 1424 	lcall	_ak820_outline_0060
      00A3CF 12 A5 29         [24] 1425 	lcall	_ak820_outline_0007
      00A3D2 90 0C 1A         [24] 1426 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A3D5 12 A5 1C         [24] 1427 	lcall	_ak820_outline_0003
      00A3D8 C0 07            [24] 1428 	push	ar7
      00A3DA C0 06            [24] 1429 	push	ar6
      00A3DC 12 A3 4B         [24] 1430 	lcall	_process_ak820_nkro
      00A3DF E5 82            [12] 1431 	mov	a, dpl
      00A3E1 D0 06            [24] 1432 	pop	ar6
      00A3E3 D0 07            [24] 1433 	pop	ar7
      00A3E5 70 03            [24] 1434 	jnz	00204$
      00A3E7 02 A4 B6         [24] 1435 	ljmp	00101$
      00A3EA                       1436 00204$:
                                   1437 ;	quantum/quantum.c:398: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A3EA 12 A5 29         [24] 1438 	lcall	_ak820_outline_0007
      00A3ED 90 0B D1         [24] 1439 	mov	dptr,#_process_last_key_PARM_2
      00A3F0 12 A5 1C         [24] 1440 	lcall	_ak820_outline_0003
      00A3F3 C0 07            [24] 1441 	push	ar7
      00A3F5 C0 06            [24] 1442 	push	ar6
      00A3F7 12 9D 74         [24] 1443 	lcall	_process_last_key
      00A3FA E5 82            [12] 1444 	mov	a, dpl
      00A3FC D0 06            [24] 1445 	pop	ar6
      00A3FE D0 07            [24] 1446 	pop	ar7
      00A400 70 03            [24] 1447 	jnz	00205$
      00A402 02 A4 B6         [24] 1448 	ljmp	00101$
      00A405                       1449 00205$:
      00A405 12 A5 29         [24] 1450 	lcall	_ak820_outline_0007
      00A408 90 0B D7         [24] 1451 	mov	dptr,#_process_repeat_key_PARM_2
      00A40B 12 A5 1C         [24] 1452 	lcall	_ak820_outline_0003
      00A40E C0 07            [24] 1453 	push	ar7
      00A410 C0 06            [24] 1454 	push	ar6
      00A412 12 9D ED         [24] 1455 	lcall	_process_repeat_key
      00A415 E5 82            [12] 1456 	mov	a, dpl
      00A417 D0 06            [24] 1457 	pop	ar6
      00A419 D0 07            [24] 1458 	pop	ar7
      00A41B 70 03            [24] 1459 	jnz	00206$
      00A41D 02 A4 B6         [24] 1460 	ljmp	00101$
      00A420                       1461 00206$:
                                   1462 ;	quantum/quantum.c:407: process_record_via(keycode, record) &&
      00A420 12 A5 29         [24] 1463 	lcall	_ak820_outline_0007
      00A423 90 0C 6B         [24] 1464 	mov	dptr,#_process_record_via_PARM_2
      00A426 12 A5 1C         [24] 1465 	lcall	_ak820_outline_0003
      00A429 C0 07            [24] 1466 	push	ar7
      00A42B C0 06            [24] 1467 	push	ar6
      00A42D 12 AA 28         [24] 1468 	lcall	_process_record_via
      00A430 E5 82            [12] 1469 	mov	a, dpl
      00A432 D0 06            [24] 1470 	pop	ar6
      00A434 D0 07            [24] 1471 	pop	ar7
      00A436 70 03            [24] 1472 	jnz	00207$
      00A438 02 A4 B6         [24] 1473 	ljmp	00101$
      00A43B                       1474 00207$:
                                   1475 ;	quantum/quantum.c:417: process_record_kb(keycode, record) &&
      00A43B 12 A5 29         [24] 1476 	lcall	_ak820_outline_0007
      00A43E 90 0B F6         [24] 1477 	mov	dptr,#_process_record_kb_PARM_2
      00A441 12 A5 1C         [24] 1478 	lcall	_ak820_outline_0003
      00A444 C0 07            [24] 1479 	push	ar7
      00A446 C0 06            [24] 1480 	push	ar6
      00A448 12 A1 80         [24] 1481 	lcall	_process_record_kb
      00A44B E5 82            [12] 1482 	mov	a, dpl
      00A44D D0 06            [24] 1483 	pop	ar6
      00A44F D0 07            [24] 1484 	pop	ar7
      00A451 70 03            [24] 1485 	jnz	00208$
      00A453 02 A4 B6         [24] 1486 	ljmp	00101$
      00A456                       1487 00208$:
                                   1488 ;	quantum/quantum.c:440: process_caps_word(keycode, record) &&
      00A456 12 A5 29         [24] 1489 	lcall	_ak820_outline_0007
      00A459 90 0B B9         [24] 1490 	mov	dptr,#_process_caps_word_PARM_2
      00A45C 12 A5 1C         [24] 1491 	lcall	_ak820_outline_0003
      00A45F C0 07            [24] 1492 	push	ar7
      00A461 C0 06            [24] 1493 	push	ar6
      00A463 12 9A 55         [24] 1494 	lcall	_process_caps_word
      00A466 E5 82            [12] 1495 	mov	a, dpl
      00A468 D0 06            [24] 1496 	pop	ar6
      00A46A D0 07            [24] 1497 	pop	ar7
      00A46C 60 48            [24] 1498 	jz	00101$
                                   1499 ;	quantum/quantum.c:467: process_grave_esc(keycode, record) &&
      00A46E 12 A5 29         [24] 1500 	lcall	_ak820_outline_0007
      00A471 90 0B BE         [24] 1501 	mov	dptr,#_process_grave_esc_PARM_2
      00A474 12 A5 1C         [24] 1502 	lcall	_ak820_outline_0003
      00A477 C0 07            [24] 1503 	push	ar7
      00A479 C0 06            [24] 1504 	push	ar6
      00A47B 12 9B 68         [24] 1505 	lcall	_process_grave_esc
      00A47E E5 82            [12] 1506 	mov	a, dpl
      00A480 D0 06            [24] 1507 	pop	ar6
      00A482 D0 07            [24] 1508 	pop	ar7
      00A484 60 30            [24] 1509 	jz	00101$
                                   1510 ;	quantum/quantum.c:470: process_rgb(keycode, record) &&
      00A486 12 A5 29         [24] 1511 	lcall	_ak820_outline_0007
      00A489 90 0B DC         [24] 1512 	mov	dptr,#_process_rgb_PARM_2
      00A48C 12 A5 1C         [24] 1513 	lcall	_ak820_outline_0003
      00A48F C0 07            [24] 1514 	push	ar7
      00A491 C0 06            [24] 1515 	push	ar6
      00A493 12 9E 62         [24] 1516 	lcall	_process_rgb
      00A496 E5 82            [12] 1517 	mov	a, dpl
      00A498 D0 06            [24] 1518 	pop	ar6
      00A49A D0 07            [24] 1519 	pop	ar7
      00A49C 60 18            [24] 1520 	jz	00101$
                                   1521 ;	quantum/quantum.c:482: process_tri_layer(keycode, record) &&
      00A49E 12 A5 29         [24] 1522 	lcall	_ak820_outline_0007
      00A4A1 90 0B E2         [24] 1523 	mov	dptr,#_process_tri_layer_PARM_2
      00A4A4 12 A5 1C         [24] 1524 	lcall	_ak820_outline_0003
      00A4A7 C0 07            [24] 1525 	push	ar7
      00A4A9 C0 06            [24] 1526 	push	ar6
      00A4AB 12 9F 83         [24] 1527 	lcall	_process_tri_layer
      00A4AE E5 82            [12] 1528 	mov	a, dpl
      00A4B0 D0 06            [24] 1529 	pop	ar6
      00A4B2 D0 07            [24] 1530 	pop	ar7
      00A4B4 70 04            [24] 1531 	jnz	00102$
                                   1532 ;	quantum/quantum.c:484: true)) {
      00A4B6                       1533 00101$:
                                   1534 ;	quantum/quantum.c:485: return false;
      00A4B6 75 82 00         [24] 1535 	mov	dpl, #0x00
      00A4B9 22               [24] 1536 	ret
      00A4BA                       1537 00102$:
                                   1538 ;	quantum/quantum.c:488: if (record->event.pressed) {
      00A4BA 12 A5 29         [24] 1539 	lcall	_ak820_outline_0007
      00A4BD 74 05            [12] 1540 	mov	a,#0x05
      00A4BF 2B               [12] 1541 	add	a, r3
      00A4C0 F8               [12] 1542 	mov	r0,a
      00A4C1 E4               [12] 1543 	clr	a
      00A4C2 3C               [12] 1544 	addc	a, r4
      00A4C3 F9               [12] 1545 	mov	r1,a
      00A4C4 8D 02            [24] 1546 	mov	ar2,r5
      00A4C6 12 49 06         [24] 1547 	lcall	_ak820_outline_0084
      00A4C9 12 BC E0         [24] 1548 	lcall	__gptrget
      00A4CC 60 30            [24] 1549 	jz	00117$
                                   1550 ;	quantum/quantum.c:489: switch (keycode) {
      00A4CE BE 00 05         [24] 1551 	cjne	r6,#0x00,00214$
      00A4D1 BF 7C 02         [24] 1552 	cjne	r7,#0x7c,00214$
      00A4D4 80 10            [24] 1553 	sjmp	00112$
      00A4D6                       1554 00214$:
      00A4D6 BE 01 05         [24] 1555 	cjne	r6,#0x01,00215$
      00A4D9 BF 7C 02         [24] 1556 	cjne	r7,#0x7c,00215$
      00A4DC 80 0F            [24] 1557 	sjmp	00113$
      00A4DE                       1558 00215$:
                                   1559 ;	quantum/quantum.c:491: case QK_BOOTLOADER:
      00A4DE BE 03 1D         [24] 1560 	cjne	r6,#0x03,00117$
      00A4E1 BF 7C 1A         [24] 1561 	cjne	r7,#0x7c,00117$
      00A4E4 80 0E            [24] 1562 	sjmp	00114$
      00A4E6                       1563 00112$:
                                   1564 ;	quantum/quantum.c:492: reset_keyboard();
      00A4E6 12 A1 D6         [24] 1565 	lcall	_reset_keyboard
                                   1566 ;	quantum/quantum.c:493: return false;
      00A4E9 75 82 00         [24] 1567 	mov	dpl, #0x00
                                   1568 ;	quantum/quantum.c:494: case QK_REBOOT:
      00A4EC 22               [24] 1569 	ret
      00A4ED                       1570 00113$:
                                   1571 ;	quantum/quantum.c:495: soft_reset_keyboard();
      00A4ED 12 A1 DC         [24] 1572 	lcall	_soft_reset_keyboard
                                   1573 ;	quantum/quantum.c:496: return false;
      00A4F0 75 82 00         [24] 1574 	mov	dpl, #0x00
                                   1575 ;	quantum/quantum.c:508: case QK_CLEAR_EEPROM:
      00A4F3 22               [24] 1576 	ret
      00A4F4                       1577 00114$:
                                   1578 ;	quantum/quantum.c:515: eeconfig_disable();
      00A4F4 12 90 98         [24] 1579 	lcall	_eeconfig_disable
                                   1580 ;	quantum/quantum.c:516: soft_reset_keyboard();
      00A4F7 12 A1 DC         [24] 1581 	lcall	_soft_reset_keyboard
                                   1582 ;	quantum/quantum.c:518: return false;
      00A4FA 75 82 00         [24] 1583 	mov	dpl, #0x00
                                   1584 ;	quantum/quantum.c:573: }
      00A4FD 22               [24] 1585 	ret
      00A4FE                       1586 00117$:
                                   1587 ;	quantum/quantum.c:576: return process_action_kb(record);
      00A4FE 12 70 8D         [24] 1588 	lcall	_ak820_outline_0102
                                   1589 ;	quantum/quantum.c:577: }
      00A501 02 A1 7C         [24] 1590 	ljmp	_process_action_kb
                                   1591 ;------------------------------------------------------------
                                   1592 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1593 ;------------------------------------------------------------
                                   1594 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_670'
                                   1595 ;------------------------------------------------------------
                                   1596 ;	quantum/quantum.c:579: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1597 ;	-----------------------------------------
                                   1598 ;	 function shutdown_user
                                   1599 ;	-----------------------------------------
      00A504                       1600 _shutdown_user:
      00A504 22               [24] 1601 	ret
                                   1602 ;------------------------------------------------------------
                                   1603 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1604 ;------------------------------------------------------------
                                   1605 ;	quantum/quantum.c:595: void suspend_power_down_quantum(void) {
                                   1606 ;	-----------------------------------------
                                   1607 	.area CSEG    (CODE)
                                   1608 	.area CONST   (CODE)
                                   1609 	.area XINIT   (CODE)
                                   1610 	.area CABS    (ABS,CODE)
                                   1611 
                                   1612 ; Experimental exact instruction outlining.
                                   1613 	.globl _ak820_outline_0001
                                   1614 	.globl _ak820_outline_0003
                                   1615 	.globl _ak820_outline_0007
                                   1616 	.globl _ak820_outline_0010
                                   1617 	.globl _ak820_outline_0014
                                   1618 	.globl _ak820_outline_0017
                                   1619 	.globl _ak820_outline_0021
                                   1620 	.globl _ak820_outline_0033
                                   1621 	.globl _ak820_outline_0036
                                   1622 	.globl _ak820_outline_0041
                                   1623 	.globl _ak820_outline_0060
                                   1624 	.globl _ak820_outline_0069
                                   1625 	.globl _ak820_outline_0084
                                   1626 	.globl _ak820_outline_0102
                                   1627 	.globl _ak820_outline_0121
                                   1628 	.globl _ak820_outline_0122
                                   1629 	.globl _ak820_outline_0124
                                   1630 	.globl _ak820_outline_0129
                                   1631 	.globl _ak820_outline_0130
                                   1632 	.globl _ak820_outline_0131
                                   1633 	.globl _ak820_outline_0163
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0001
      00A505                       1637 _ak820_outline_0001:
      00A505 90 0D C2         [24] 1638 	mov	dptr,#___memcpy_PARM_2
      00A508 74 0A            [12] 1639 	mov	a,#_get_event_keycode_PARM_1
      00A50A F0               [24] 1640 	movx	@dptr,a
      00A50B 74 0C            [12] 1641 	mov	a,#(_get_event_keycode_PARM_1>>8)
      00A50D A3               [24] 1642 	inc	dptr
      00A50E F0               [24] 1643 	movx	@dptr,a
      00A50F E4               [12] 1644 	clr	a
      00A510 A3               [24] 1645 	inc	dptr
      00A511 F0               [24] 1646 	movx	@dptr,a
      00A512 90 0D C5         [24] 1647 	mov	dptr,#___memcpy_PARM_3
      00A515 74 02            [12] 1648 	mov	a,#0x02
      00A517 F0               [24] 1649 	movx	@dptr,a
      00A518 E4               [12] 1650 	clr	a
      00A519 A3               [24] 1651 	inc	dptr
      00A51A F0               [24] 1652 	movx	@dptr,a
      00A51B 22               [24] 1653 	ret
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0003
      00A51C                       1657 _ak820_outline_0003:
      00A51C EB               [12] 1658 	mov	a,r3
      00A51D F0               [24] 1659 	movx	@dptr,a
      00A51E EC               [12] 1660 	mov	a,r4
      00A51F A3               [24] 1661 	inc	dptr
      00A520 F0               [24] 1662 	movx	@dptr,a
      00A521 ED               [12] 1663 	mov	a,r5
      00A522 A3               [24] 1664 	inc	dptr
      00A523 F0               [24] 1665 	movx	@dptr,a
      00A524 8E 82            [24] 1666 	mov	dpl,r6
      00A526 8F 83            [24] 1667 	mov	dph,r7
      00A528 22               [24] 1668 	ret
                                   1669 
                                   1670 	.area CSEG (CODE)
                                   1671 ; function ak820_outline_0007
      00A529                       1672 _ak820_outline_0007:
      00A529 90 0C 1F         [24] 1673 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A52C E0               [24] 1674 	movx	a,@dptr
      00A52D FB               [12] 1675 	mov	r3,a
      00A52E A3               [24] 1676 	inc	dptr
      00A52F E0               [24] 1677 	movx	a,@dptr
      00A530 FC               [12] 1678 	mov	r4,a
      00A531 A3               [24] 1679 	inc	dptr
      00A532 E0               [24] 1680 	movx	a,@dptr
      00A533 FD               [12] 1681 	mov	r5,a
      00A534 22               [24] 1682 	ret
