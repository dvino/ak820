                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004D                        535 _fast_set_leds_sloc0_1_0:
      00004D                        536 	.ds 2
      00004F                        537 _fast_set_leds_sloc1_1_0:
      00004F                        538 	.ds 2
      000051                        539 _vialrgb_get_value_sloc0_1_0:
      000051                        540 	.ds 2
      000053                        541 _vialrgb_get_value_sloc1_1_0:
      000053                        542 	.ds 2
      000055                        543 _vialrgb_set_value_sloc0_1_0:
      000055                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CAE                        569 _g_direct_mode_colors::
      000CAE                        570 	.ds 246
      000DA4                        571 _get_supported_PARM_2:
      000DA4                        572 	.ds 1
      000DA5                        573 _get_supported_args_10000_252:
      000DA5                        574 	.ds 2
      000DA7                        575 _qmk_id_to_vialrgb_id_id_10000_259:
      000DA7                        576 	.ds 2
      000DA9                        577 _vialrgb_id_to_qmk_id_id_10000_264:
      000DA9                        578 	.ds 2
      000DAB                        579 _set_mode_mode_10000_272:
      000DAB                        580 	.ds 2
      000DAD                        581 _get_matrix_pos_for_led_PARM_2:
      000DAD                        582 	.ds 2
      000DAF                        583 _get_matrix_pos_for_led_led_10000_277:
      000DAF                        584 	.ds 2
      000DB1                        585 _fast_set_leds_PARM_2:
      000DB1                        586 	.ds 1
      000DB2                        587 _fast_set_leds_args_10000_279:
      000DB2                        588 	.ds 2
      000DB4                        589 _fast_set_leds_first_index_10001_282:
      000DB4                        590 	.ds 2
      000DB6                        591 _fast_set_leds_num_leds_10001_282:
      000DB6                        592 	.ds 1
      000DB7                        593 _vialrgb_get_value_PARM_2:
      000DB7                        594 	.ds 1
      000DB8                        595 _vialrgb_get_value_data_10000_288:
      000DB8                        596 	.ds 3
      000DBB                        597 _vialrgb_set_value_PARM_2:
      000DBB                        598 	.ds 1
      000DBC                        599 _vialrgb_set_value_data_10000_299:
      000DBC                        600 	.ds 3
      000DBF                        601 _vialrgb_save_PARM_2:
      000DBF                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B65F                        654 _get_supported:
      00B65F 12 39 03         [24]  655 	lcall	_ak820_outline_0122
      00B662 90 0D A5         [24]  656 	mov	dptr,#_get_supported_args_10000_252
      00B665 12 38 FE         [24]  657 	lcall	_ak820_outline_0121
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B668 90 0D A5         [24]  659 	mov	dptr,#_get_supported_args_10000_252
      00B66B 12 38 81         [24]  660 	lcall	_ak820_outline_0010
      00B66E E0               [24]  661 	movx	a,@dptr
      00B66F FD               [12]  662 	mov	r5,a
      00B670 7C 00            [12]  663 	mov	r4,#0x00
      00B672 12 39 08         [24]  664 	lcall	_ak820_outline_0123
      00B675 A3               [24]  665 	inc	dptr
      00B676 12 43 EB         [24]  666 	lcall	_ak820_outline_0190
                                    667 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B679 90 0D A4         [24]  668 	mov	dptr,#_get_supported_PARM_2
      00B67C E0               [24]  669 	movx	a,@dptr
      00B67D FB               [12]  670 	mov	r3,a
      00B67E 7A 00            [12]  671 	mov	r2,#0x00
      00B680                        672 00107$:
      00B680 C3               [12]  673 	clr	c
      00B681 EA               [12]  674 	mov	a,r2
      00B682 9B               [12]  675 	subb	a,r3
      00B683 50 0A            [24]  676 	jnc	00101$
      00B685 EA               [12]  677 	mov	a,r2
      00B686 12 38 BB         [24]  678 	lcall	_ak820_outline_0045
      00B689 74 FF            [12]  679 	mov	a,#0xff
      00B68B F0               [24]  680 	movx	@dptr,a
      00B68C 0A               [12]  681 	inc	r2
      00B68D 80 F1            [24]  682 	sjmp	00107$
      00B68F                        683 00101$:
                                    684 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B68F 8D 06            [24]  685 	mov	ar6,r5
      00B691 8C 07            [24]  686 	mov	ar7,r4
      00B693 8B 05            [24]  687 	mov	ar5,r3
      00B695 90 0D A5         [24]  688 	mov	dptr,#_get_supported_args_10000_252
      00B698 12 39 28         [24]  689 	lcall	_ak820_outline_0147
      00B69B 7A 00            [12]  690 	mov	r2,#0x00
      00B69D                        691 00110$:
      00B69D BA 07 00         [24]  692 	cjne	r2,#0x07,00159$
      00B6A0                        693 00159$:
      00B6A0 50 46            [24]  694 	jnc	00127$
                                    695 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B6A2 EA               [12]  696 	mov	a,r2
      00B6A3 75 F0 02         [24]  697 	mov	b,#0x02
      00B6A6 A4               [48]  698 	mul	ab
      00B6A7 24 0E            [12]  699 	add	a, #_supported_modes
      00B6A9 F5 82            [12]  700 	mov	dpl,a
      00B6AB 74 C3            [12]  701 	mov	a,#(_supported_modes >> 8)
      00B6AD 12 57 EE         [24]  702 	lcall	_ak820_outline_0156
      00B6B0 F8               [12]  703 	mov	r0,a
      00B6B1 79 00            [12]  704 	mov	r1,#0x00
                                    705 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B6B3 C3               [12]  706 	clr	c
      00B6B4 EE               [12]  707 	mov	a,r6
      00B6B5 98               [12]  708 	subb	a,r0
      00B6B6 EF               [12]  709 	mov	a,r7
      00B6B7 99               [12]  710 	subb	a,r1
      00B6B8 50 2B            [24]  711 	jnc	00111$
                                    712 ;	free result
      00B6BA BD 02 00         [24]  713 	cjne	r5,#0x02,00162$
      00B6BD                        714 00162$:
      00B6BD 40 26            [24]  715 	jc	00111$
                                    716 ;	quantum/vialrgb.c:49: args[0] = id;
      00B6BF C0 06            [24]  717 	push	ar6
      00B6C1 C0 07            [24]  718 	push	ar7
      00B6C3 88 07            [24]  719 	mov	ar7,r0
      00B6C5 12 34 71         [24]  720 	lcall	_ak820_outline_0129
      00B6C8 EF               [12]  721 	mov	a,r7
      00B6C9 F0               [24]  722 	movx	@dptr,a
                                    723 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B6CA 12 34 71         [24]  724 	lcall	_ak820_outline_0129
      00B6CD A3               [24]  725 	inc	dptr
      00B6CE 89 00            [24]  726 	mov	ar0,r1
      00B6D0 E8               [12]  727 	mov	a,r0
      00B6D1 F0               [24]  728 	movx	@dptr,a
                                    729 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B6D2 1D               [12]  730 	dec	r5
      00B6D3 1D               [12]  731 	dec	r5
                                    732 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B6D4 74 02            [12]  733 	mov	a,#0x02
      00B6D6 2B               [12]  734 	add	a, r3
      00B6D7 FB               [12]  735 	mov	r3,a
      00B6D8 E4               [12]  736 	clr	a
      00B6D9 3C               [12]  737 	addc	a, r4
      00B6DA FC               [12]  738 	mov	r4,a
      00B6DB 90 0D A5         [24]  739 	mov	dptr,#_get_supported_args_10000_252
      00B6DE 12 38 F2         [24]  740 	lcall	_ak820_outline_0103
                                    741 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B6E1 D0 07            [24]  742 	pop	ar7
      00B6E3 D0 06            [24]  743 	pop	ar6
                                    744 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B6E5                        745 00111$:
                                    746 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B6E5 0A               [12]  747 	inc	r2
      00B6E6 80 B5            [24]  748 	sjmp	00110$
      00B6E8                        749 00127$:
      00B6E8 90 0D A5         [24]  750 	mov	dptr,#_get_supported_args_10000_252
      00B6EB 12 38 F2         [24]  751 	lcall	_ak820_outline_0103
                                    752 ;	quantum/vialrgb.c:55: }
      00B6EE 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    756 ;------------------------------------------------------------
                                    757 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_259'
                                    758 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_261'
                                    759 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_262'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function qmk_id_to_vialrgb_id
                                    764 ;	-----------------------------------------
      00B6EF                        765 _qmk_id_to_vialrgb_id:
      00B6EF 12 39 03         [24]  766 	lcall	_ak820_outline_0122
      00B6F2 90 0D A7         [24]  767 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_259
      00B6F5 12 38 FE         [24]  768 	lcall	_ak820_outline_0121
                                    769 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B6F8 90 0D A7         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_259
      00B6FB 12 38 C3         [24]  771 	lcall	_ak820_outline_0060
      00B6FE 7D 00            [12]  772 	mov	r5,#0x00
      00B700                        773 00105$:
      00B700 BD 07 00         [24]  774 	cjne	r5,#0x07,00130$
      00B703                        775 00130$:
      00B703 50 19            [24]  776 	jnc	00103$
                                    777 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B705 12 BB 28         [24]  778 	lcall	_ak820_outline_0053
      00B708 A3               [24]  779 	inc	dptr
      00B709 E4               [12]  780 	clr	a
      00B70A 93               [24]  781 	movc	a,@a+dptr
                                    782 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B70B 7A 00            [12]  783 	mov	r2,#0x00
      00B70D B5 06 0B         [24]  784 	cjne	a,ar6,00106$
      00B710 EA               [12]  785 	mov	a,r2
      00B711 B5 07 07         [24]  786 	cjne	a,ar7,00106$
                                    787 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B714 12 34 71         [24]  788 	lcall	_ak820_outline_0129
      00B717 12 BB 54         [24]  789 	lcall	_ak820_outline_0149
      00B71A 22               [24]  790 	ret
      00B71B                        791 00106$:
                                    792 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B71B 0D               [12]  793 	inc	r5
      00B71C 80 E2            [24]  794 	sjmp	00105$
      00B71E                        795 00103$:
                                    796 ;	quantum/vialrgb.c:63: return 0;
      00B71E 90 00 00         [24]  797 	mov	dptr,#0x0000
                                    798 ;	quantum/vialrgb.c:64: }
      00B721 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    802 ;------------------------------------------------------------
                                    803 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_264'
                                    804 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_266'
                                    805 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_267'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function vialrgb_id_to_qmk_id
                                    810 ;	-----------------------------------------
      00B722                        811 _vialrgb_id_to_qmk_id:
      00B722 12 39 03         [24]  812 	lcall	_ak820_outline_0122
      00B725 90 0D A9         [24]  813 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_264
      00B728 12 38 FE         [24]  814 	lcall	_ak820_outline_0121
                                    815 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B72B 90 0D A9         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_264
      00B72E 12 38 C3         [24]  817 	lcall	_ak820_outline_0060
      00B731 7D 00            [12]  818 	mov	r5,#0x00
      00B733                        819 00105$:
      00B733 BD 07 00         [24]  820 	cjne	r5,#0x07,00130$
      00B736                        821 00130$:
      00B736 50 19            [24]  822 	jnc	00103$
                                    823 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B738 12 BB 28         [24]  824 	lcall	_ak820_outline_0053
      00B73B E4               [12]  825 	clr	a
      00B73C 93               [24]  826 	movc	a,@a+dptr
                                    827 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B73D 7A 00            [12]  828 	mov	r2,#0x00
      00B73F B5 06 0C         [24]  829 	cjne	a,ar6,00106$
      00B742 EA               [12]  830 	mov	a,r2
      00B743 B5 07 08         [24]  831 	cjne	a,ar7,00106$
                                    832 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B746 12 34 71         [24]  833 	lcall	_ak820_outline_0129
      00B749 A3               [24]  834 	inc	dptr
      00B74A 12 BB 54         [24]  835 	lcall	_ak820_outline_0149
      00B74D 22               [24]  836 	ret
      00B74E                        837 00106$:
                                    838 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B74E 0D               [12]  839 	inc	r5
      00B74F 80 E2            [24]  840 	sjmp	00105$
      00B751                        841 00103$:
                                    842 ;	quantum/vialrgb.c:72: return 0;
      00B751 90 00 00         [24]  843 	mov	dptr,#0x0000
                                    844 ;	quantum/vialrgb.c:73: }
      00B754 22               [24]  845 	ret
                                    846 ;------------------------------------------------------------
                                    847 ;Allocation info for local variables in function 'get_mode'
                                    848 ;------------------------------------------------------------
                                    849 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    850 ;	-----------------------------------------
                                    851 ;	 function get_mode
                                    852 ;	-----------------------------------------
      00B755                        853 _get_mode:
                                    854 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B755 12 55 CE         [24]  855 	lcall	_rgb_matrix_is_enabled
      00B758 E5 82            [12]  856 	mov	a, dpl
      00B75A 70 04            [24]  857 	jnz	00102$
                                    858 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B75C 90 00 00         [24]  859 	mov	dptr,#0x0000
      00B75F 22               [24]  860 	ret
      00B760                        861 00102$:
                                    862 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B760 12 55 D4         [24]  863 	lcall	_rgb_matrix_get_mode
      00B763 7E 00            [12]  864 	mov	r6,#0x00
      00B765 8E 83            [24]  865 	mov	dph, r6
                                    866 ;	quantum/vialrgb.c:80: }
      00B767 02 B6 EF         [24]  867 	ljmp	_qmk_id_to_vialrgb_id
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'set_mode'
                                    870 ;------------------------------------------------------------
                                    871 ;mode          Allocated with name '_set_mode_mode_10000_272'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function set_mode
                                    876 ;	-----------------------------------------
      00B76A                        877 _set_mode:
      00B76A 12 39 03         [24]  878 	lcall	_ak820_outline_0122
      00B76D 90 0D AB         [24]  879 	mov	dptr,#_set_mode_mode_10000_272
      00B770 12 38 FE         [24]  880 	lcall	_ak820_outline_0121
                                    881 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B773 90 0D AB         [24]  882 	mov	dptr,#_set_mode_mode_10000_272
      00B776 12 38 C3         [24]  883 	lcall	_ak820_outline_0060
      00B779 90 0D AB         [24]  884 	mov	dptr,#_set_mode_mode_10000_272
      00B77C 12 6E 56         [24]  885 	lcall	_ak820_outline_0041
      00B77F 70 03            [24]  886 	jnz	00102$
                                    887 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B781 02 56 21         [24]  888 	ljmp	_rgb_matrix_disable_noeeprom
      00B784                        889 00102$:
                                    890 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B784 C0 07            [24]  891 	push	ar7
      00B786 C0 06            [24]  892 	push	ar6
      00B788 12 56 10         [24]  893 	lcall	_rgb_matrix_enable_noeeprom
      00B78B D0 06            [24]  894 	pop	ar6
      00B78D D0 07            [24]  895 	pop	ar7
                                    896 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B78F 12 39 08         [24]  897 	lcall	_ak820_outline_0123
      00B792 12 B7 22         [24]  898 	lcall	_vialrgb_id_to_qmk_id
                                    899 ;	quantum/vialrgb.c:90: }
      00B795 02 56 2A         [24]  900 	ljmp	_rgb_matrix_mode_noeeprom
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    903 ;------------------------------------------------------------
                                    904 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    905 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_277'
                                    906 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_278'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function get_matrix_pos_for_led
                                    911 ;	-----------------------------------------
      00B798                        912 _get_matrix_pos_for_led:
      00B798 12 39 03         [24]  913 	lcall	_ak820_outline_0122
      00B79B 90 0D AF         [24]  914 	mov	dptr,#_get_matrix_pos_for_led_led_10000_277
      00B79E 12 38 FE         [24]  915 	lcall	_ak820_outline_0121
                                    916 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B7A1 90 0D AF         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_277
      00B7A4 12 38 C3         [24]  918 	lcall	_ak820_outline_0060
      00B7A7 EE               [12]  919 	mov	a,r6
      00B7A8 24 10            [12]  920 	add	a, #_ak820_rgb_slots
      00B7AA F5 82            [12]  921 	mov	dpl,a
      00B7AC EF               [12]  922 	mov	a,r7
      00B7AD 34 BD            [12]  923 	addc	a, #(_ak820_rgb_slots >> 8)
      00B7AF F5 83            [12]  924 	mov	dph,a
      00B7B1 E4               [12]  925 	clr	a
      00B7B2 93               [24]  926 	movc	a,@a+dptr
      00B7B3 FF               [12]  927 	mov	r7,a
                                    928 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B7B4 90 0D AD         [24]  929 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B7B7 12 38 EC         [24]  930 	lcall	_ak820_outline_0089
      00B7BA EF               [12]  931 	mov	a,r7
      00B7BB 12 58 17         [24]  932 	lcall	_ak820_outline_0196
      00B7BE 12 82 2E         [24]  933 	lcall	_ak820_outline_0128
                                    934 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B7C1 12 39 17         [24]  935 	lcall	_ak820_outline_0141
      00B7C4 A3               [24]  936 	inc	dptr
      00B7C5 53 07 07         [24]  937 	anl	ar7,#0x07
      00B7C8 EF               [12]  938 	mov	a,r7
      00B7C9 F0               [24]  939 	movx	@dptr,a
                                    940 ;	quantum/vialrgb.c:110: }
      00B7CA 22               [24]  941 	ret
                                    942 ;------------------------------------------------------------
                                    943 ;Allocation info for local variables in function 'fast_set_leds'
                                    944 ;------------------------------------------------------------
                                    945 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    946 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    947 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    948 ;args          Allocated with name '_fast_set_leds_args_10000_279'
                                    949 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_282'
                                    950 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_282'
                                    951 ;i             Allocated with name '_fast_set_leds_i_20001_285'
                                    952 ;color         Allocated with name '_fast_set_leds_color_30001_286'
                                    953 ;val           Allocated with name '_fast_set_leds_val_30002_287'
                                    954 ;------------------------------------------------------------
                                    955 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function fast_set_leds
                                    958 ;	-----------------------------------------
      00B7CB                        959 _fast_set_leds:
      00B7CB 12 39 03         [24]  960 	lcall	_ak820_outline_0122
      00B7CE 90 0D B2         [24]  961 	mov	dptr,#_fast_set_leds_args_10000_279
      00B7D1 12 38 FE         [24]  962 	lcall	_ak820_outline_0121
                                    963 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B7D4 90 0D B1         [24]  964 	mov	dptr,#_fast_set_leds_PARM_2
      00B7D7 E0               [24]  965 	movx	a,@dptr
      00B7D8 FF               [12]  966 	mov	r7,a
      00B7D9 BF 03 00         [24]  967 	cjne	r7,#0x03,00159$
      00B7DC                        968 00159$:
      00B7DC 50 01            [24]  969 	jnc	00102$
      00B7DE 22               [24]  970 	ret
      00B7DF                        971 00102$:
                                    972 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B7DF 90 0D B2         [24]  973 	mov	dptr,#_fast_set_leds_args_10000_279
      00B7E2 12 38 EC         [24]  974 	lcall	_ak820_outline_0089
      00B7E5 12 49 0D         [24]  975 	lcall	_ak820_outline_0085
      00B7E8 7B 00            [12]  976 	mov	r3,#0x00
      00B7EA 12 39 17         [24]  977 	lcall	_ak820_outline_0141
      00B7ED A3               [24]  978 	inc	dptr
      00B7EE E0               [24]  979 	movx	a,@dptr
      00B7EF FA               [12]  980 	mov	r2,a
      00B7F0 79 00            [12]  981 	mov	r1,#0x00
      00B7F2 90 0D B4         [24]  982 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B7F5 E9               [12]  983 	mov	a,r1
      00B7F6 4C               [12]  984 	orl	a,r4
      00B7F7 F0               [24]  985 	movx	@dptr,a
      00B7F8 EA               [12]  986 	mov	a,r2
      00B7F9 4B               [12]  987 	orl	a,r3
      00B7FA A3               [24]  988 	inc	dptr
      00B7FB F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B7FC 12 39 17         [24]  991 	lcall	_ak820_outline_0141
      00B7FF A3               [24]  992 	inc	dptr
      00B800 A3               [24]  993 	inc	dptr
      00B801 E0               [24]  994 	movx	a,@dptr
      00B802 90 0D B6         [24]  995 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B805 F0               [24]  996 	movx	@dptr,a
                                    997 ;	quantum/vialrgb.c:119: length -= 3;
      00B806 EF               [12]  998 	mov	a,r7
      00B807 24 FD            [12]  999 	add	a,#0xfd
      00B809 90 0D B1         [24] 1000 	mov	dptr,#_fast_set_leds_PARM_2
      00B80C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:120: args += 3;
      00B80D 90 0D B2         [24] 1003 	mov	dptr,#_fast_set_leds_args_10000_279
      00B810 74 03            [12] 1004 	mov	a,#0x03
      00B812 2D               [12] 1005 	add	a, r5
      00B813 F0               [24] 1006 	movx	@dptr,a
      00B814 E4               [12] 1007 	clr	a
      00B815 3E               [12] 1008 	addc	a, r6
      00B816 A3               [24] 1009 	inc	dptr
      00B817 F0               [24] 1010 	movx	@dptr,a
                                   1011 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B818 90 0D B6         [24] 1012 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B81B E0               [24] 1013 	movx	a,@dptr
      00B81C FF               [12] 1014 	mov	r7,a
      00B81D 75 F0 03         [24] 1015 	mov	b,#0x03
      00B820 A4               [48] 1016 	mul	ab
      00B821 FE               [12] 1017 	mov	r6,a
      00B822 AD F0            [24] 1018 	mov	r5,b
      00B824 90 0D B1         [24] 1019 	mov	dptr,#_fast_set_leds_PARM_2
      00B827 E0               [24] 1020 	movx	a,@dptr
      00B828 FB               [12] 1021 	mov	r3,a
      00B829 7C 00            [12] 1022 	mov	r4,#0x00
      00B82B C3               [12] 1023 	clr	c
      00B82C EB               [12] 1024 	mov	a,r3
      00B82D 9E               [12] 1025 	subb	a,r6
      00B82E EC               [12] 1026 	mov	a,r4
      00B82F 9D               [12] 1027 	subb	a,r5
      00B830 40 13            [24] 1028 	jc	00103$
                                   1029 ;	free result
      00B832 90 0D B4         [24] 1030 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B835 12 38 EC         [24] 1031 	lcall	_ak820_outline_0089
      00B838 8D 03            [24] 1032 	mov	ar3,r5
      00B83A 8E 04            [24] 1033 	mov	ar4,r6
      00B83C C3               [12] 1034 	clr	c
      00B83D EB               [12] 1035 	mov	a,r3
      00B83E 94 52            [12] 1036 	subb	a,#0x52
      00B840 EC               [12] 1037 	mov	a,r4
      00B841 94 00            [12] 1038 	subb	a,#0x00
      00B843 40 01            [24] 1039 	jc	00104$
      00B845                       1040 00103$:
      00B845 22               [24] 1041 	ret
      00B846                       1042 00104$:
                                   1043 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B846 74 52            [12] 1044 	mov	a,#0x52
      00B848 C3               [12] 1045 	clr	c
      00B849 9D               [12] 1046 	subb	a,r5
      00B84A FB               [12] 1047 	mov	r3,a
      00B84B E4               [12] 1048 	clr	a
      00B84C 9E               [12] 1049 	subb	a,r6
      00B84D FC               [12] 1050 	mov	r4,a
      00B84E 7A 00            [12] 1051 	mov	r2,#0x00
      00B850 C3               [12] 1052 	clr	c
      00B851 EB               [12] 1053 	mov	a,r3
      00B852 9F               [12] 1054 	subb	a,r7
      00B853 EC               [12] 1055 	mov	a,r4
      00B854 9A               [12] 1056 	subb	a,r2
      00B855 50 08            [24] 1057 	jnc	00127$
                                   1058 ;	free result
      00B857 90 0D B6         [24] 1059 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B85A 74 52            [12] 1060 	mov	a,#0x52
      00B85C C3               [12] 1061 	clr	c
      00B85D 9D               [12] 1062 	subb	a,r5
      00B85E F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B85F                       1065 00127$:
      00B85F 90 0D B6         [24] 1066 	mov	dptr,#_fast_set_leds_num_leds_10001_282
      00B862 E0               [24] 1067 	movx	a,@dptr
      00B863 FF               [12] 1068 	mov	r7,a
      00B864 90 0D B4         [24] 1069 	mov	dptr,#_fast_set_leds_first_index_10001_282
      00B867 12 38 EC         [24] 1070 	lcall	_ak820_outline_0089
      00B86A 7C 00            [12] 1071 	mov	r4,#0x00
      00B86C                       1072 00110$:
      00B86C C3               [12] 1073 	clr	c
      00B86D EC               [12] 1074 	mov	a,r4
      00B86E 9F               [12] 1075 	subb	a,r7
      00B86F 40 01            [24] 1076 	jc	00164$
      00B871 22               [24] 1077 	ret
      00B872                       1078 00164$:
                                   1079 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B872 C0 07            [24] 1080 	push	ar7
      00B874 90 0D CE         [24] 1081 	mov	dptr,#__mulint_PARM_2
      00B877 12 43 C9         [24] 1082 	lcall	_ak820_outline_0126
      00B87A 90 00 03         [24] 1083 	mov	dptr,#0x0003
      00B87D C0 07            [24] 1084 	push	ar7
      00B87F C0 06            [24] 1085 	push	ar6
      00B881 C0 05            [24] 1086 	push	ar5
      00B883 C0 04            [24] 1087 	push	ar4
      00B885 12 BC C0         [24] 1088 	lcall	__mulint
      00B888 AA 82            [24] 1089 	mov	r2, dpl
      00B88A AB 83            [24] 1090 	mov	r3, dph
      00B88C D0 04            [24] 1091 	pop	ar4
      00B88E D0 05            [24] 1092 	pop	ar5
      00B890 D0 06            [24] 1093 	pop	ar6
      00B892 D0 07            [24] 1094 	pop	ar7
      00B894 0D               [12] 1095 	inc	r5
      00B895 BD 00 01         [24] 1096 	cjne	r5,#0x00,00165$
      00B898 0E               [12] 1097 	inc	r6
      00B899                       1098 00165$:
      00B899 EA               [12] 1099 	mov	a,r2
      00B89A 24 AE            [12] 1100 	add	a, #_g_direct_mode_colors
      00B89C FA               [12] 1101 	mov	r2,a
      00B89D EB               [12] 1102 	mov	a,r3
      00B89E 34 0C            [12] 1103 	addc	a, #(_g_direct_mode_colors >> 8)
      00B8A0 FB               [12] 1104 	mov	r3,a
                                   1105 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B8A1 8A 4D            [24] 1106 	mov	_fast_set_leds_sloc0_1_0,r2
      00B8A3 8B 4E            [24] 1107 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B8A5 12 BB 3A         [24] 1108 	lcall	_ak820_outline_0092
      00B8A8 F8               [12] 1109 	mov	r0,a
      00B8A9 12 BB 48         [24] 1110 	lcall	_ak820_outline_0113
      00B8AC 85 4D 82         [24] 1111 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B8AF 85 4E 83         [24] 1112 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B8B2 E8               [12] 1113 	mov	a,r0
      00B8B3 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B8B4 74 01            [12] 1116 	mov	a,#0x01
      00B8B6 2A               [12] 1117 	add	a, r2
      00B8B7 F5 4D            [12] 1118 	mov	_fast_set_leds_sloc0_1_0,a
      00B8B9 E4               [12] 1119 	clr	a
      00B8BA 3B               [12] 1120 	addc	a, r3
      00B8BB F5 4E            [12] 1121 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B8BD 90 0D B2         [24] 1122 	mov	dptr,#_fast_set_leds_args_10000_279
      00B8C0 E0               [24] 1123 	movx	a,@dptr
      00B8C1 F8               [12] 1124 	mov	r0,a
      00B8C2 A3               [24] 1125 	inc	dptr
      00B8C3 E0               [24] 1126 	movx	a,@dptr
      00B8C4 FF               [12] 1127 	mov	r7,a
      00B8C5 88 82            [24] 1128 	mov	dpl,r0
      00B8C7 8F 83            [24] 1129 	mov	dph,r7
      00B8C9 E0               [24] 1130 	movx	a,@dptr
      00B8CA F9               [12] 1131 	mov	r1,a
      00B8CB 90 0D B2         [24] 1132 	mov	dptr,#_fast_set_leds_args_10000_279
      00B8CE 74 01            [12] 1133 	mov	a,#0x01
      00B8D0 28               [12] 1134 	add	a, r0
      00B8D1 F0               [24] 1135 	movx	@dptr,a
      00B8D2 E4               [12] 1136 	clr	a
      00B8D3 3F               [12] 1137 	addc	a, r7
      00B8D4 A3               [24] 1138 	inc	dptr
      00B8D5 F0               [24] 1139 	movx	@dptr,a
      00B8D6 85 4D 82         [24] 1140 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B8D9 85 4E 83         [24] 1141 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B8DC E9               [12] 1142 	mov	a,r1
      00B8DD F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B8DE 12 BB 3A         [24] 1145 	lcall	_ak820_outline_0092
      00B8E1 F5 4D            [12] 1146 	mov	_fast_set_leds_sloc0_1_0,a
      00B8E3 12 BB 48         [24] 1147 	lcall	_ak820_outline_0113
                                   1148 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B8E6 74 02            [12] 1149 	mov	a,#0x02
      00B8E8 2A               [12] 1150 	add	a, r2
      00B8E9 F5 4F            [12] 1151 	mov	_fast_set_leds_sloc1_1_0,a
      00B8EB E4               [12] 1152 	clr	a
      00B8EC 3B               [12] 1153 	addc	a, r3
      00B8ED F5 50            [12] 1154 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B8EF C3               [12] 1155 	clr	c
      00B8F0 74 A0            [12] 1156 	mov	a,#0xa0
      00B8F2 95 4D            [12] 1157 	subb	a,_fast_set_leds_sloc0_1_0
      00B8F4 D0 07            [24] 1158 	pop	ar7
      00B8F6 50 04            [24] 1159 	jnc	00114$
                                   1160 ;	free result
      00B8F8 7B A0            [12] 1161 	mov	r3,#0xa0
      00B8FA 80 04            [24] 1162 	sjmp	00115$
      00B8FC                       1163 00114$:
      00B8FC AA 4D            [24] 1164 	mov	r2,_fast_set_leds_sloc0_1_0
      00B8FE 8A 03            [24] 1165 	mov	ar3,r2
      00B900                       1166 00115$:
      00B900 85 4F 82         [24] 1167 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B903 85 50 83         [24] 1168 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B906 EB               [12] 1169 	mov	a,r3
      00B907 F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B908 0C               [12] 1172 	inc	r4
                                   1173 ;	quantum/vialrgb.c:133: }
      00B909 02 B8 6C         [24] 1174 	ljmp	00110$
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1179 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1180 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1181 ;data          Allocated with name '_vialrgb_get_value_data_10000_288'
                                   1182 ;args          Allocated with name '_vialrgb_get_value_args_10001_291'
                                   1183 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_291'
                                   1184 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_294'
                                   1185 ;led           Allocated with name '_vialrgb_get_value_led_40001_297'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function vialrgb_get_value
                                   1190 ;	-----------------------------------------
      00B90C                       1191 _vialrgb_get_value:
      00B90C 12 43 80         [24] 1192 	lcall	_ak820_outline_0036
      00B90F 90 0D B8         [24] 1193 	mov	dptr,#_vialrgb_get_value_data_10000_288
      00B912 12 38 8B         [24] 1194 	lcall	_ak820_outline_0017
                                   1195 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B915 90 0D B7         [24] 1196 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B918 E0               [24] 1197 	movx	a,@dptr
      00B919 FF               [12] 1198 	mov	r7,a
      00B91A BF 20 02         [24] 1199 	cjne	r7,#0x20,00162$
      00B91D 80 01            [24] 1200 	sjmp	00102$
      00B91F                       1201 00162$:
      00B91F 22               [24] 1202 	ret
      00B920                       1203 00102$:
                                   1204 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B920 90 0D B8         [24] 1205 	mov	dptr,#_vialrgb_get_value_data_10000_288
      00B923 12 BB 14         [24] 1206 	lcall	_ak820_outline_0051
                                   1207 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1208 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B926 BA 40 02         [24] 1209 	cjne	r2,#0x40,00163$
      00B929 80 18            [24] 1210 	sjmp	00103$
      00B92B                       1211 00163$:
      00B92B BA 41 02         [24] 1212 	cjne	r2,#0x41,00164$
      00B92E 80 26            [24] 1213 	sjmp	00104$
      00B930                       1214 00164$:
      00B930 BA 42 03         [24] 1215 	cjne	r2,#0x42,00165$
      00B933 02 B9 E8         [24] 1216 	ljmp	00105$
      00B936                       1217 00165$:
      00B936 BA 43 03         [24] 1218 	cjne	r2,#0x43,00166$
      00B939 02 B9 F5         [24] 1219 	ljmp	00106$
      00B93C                       1220 00166$:
      00B93C BA 44 03         [24] 1221 	cjne	r2,#0x44,00167$
      00B93F 02 BA 01         [24] 1222 	ljmp	00107$
      00B942                       1223 00167$:
      00B942 22               [24] 1224 	ret
                                   1225 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B943                       1226 00103$:
                                   1227 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B943 12 34 71         [24] 1228 	lcall	_ak820_outline_0129
      00B946 74 01            [12] 1229 	mov	a,#0x01
      00B948 F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B949 12 BB 0C         [24] 1232 	lcall	_ak820_outline_0040
      00B94C E4               [12] 1233 	clr	a
      00B94D F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B94E 12 BB 0C         [24] 1236 	lcall	_ak820_outline_0040
      00B951 A3               [24] 1237 	inc	dptr
      00B952 74 A0            [12] 1238 	mov	a,#0xa0
      00B954 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:147: break;
      00B955 22               [24] 1241 	ret
                                   1242 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B956                       1243 00104$:
                                   1244 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B956 C0 06            [24] 1245 	push	ar6
      00B958 C0 05            [24] 1246 	push	ar5
      00B95A C0 04            [24] 1247 	push	ar4
      00B95C C0 03            [24] 1248 	push	ar3
      00B95E 12 B7 55         [24] 1249 	lcall	_get_mode
      00B961 A9 82            [24] 1250 	mov	r1, dpl
      00B963 AA 83            [24] 1251 	mov	r2, dph
      00B965 D0 03            [24] 1252 	pop	ar3
      00B967 D0 04            [24] 1253 	pop	ar4
      00B969 D0 05            [24] 1254 	pop	ar5
      00B96B D0 06            [24] 1255 	pop	ar6
                                   1256 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B96D 89 00            [24] 1257 	mov	ar0,r1
      00B96F 12 34 71         [24] 1258 	lcall	_ak820_outline_0129
      00B972 E8               [12] 1259 	mov	a,r0
      00B973 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B974 12 BB 0C         [24] 1262 	lcall	_ak820_outline_0040
      00B977 8A 01            [24] 1263 	mov	ar1,r2
      00B979 E9               [12] 1264 	mov	a,r1
      00B97A F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B97B 74 04            [12] 1267 	mov	a,#0x04
      00B97D 12 8F 89         [24] 1268 	lcall	_ak820_outline_0142
      00B980 C0 06            [24] 1269 	push	ar6
      00B982 C0 05            [24] 1270 	push	ar5
      00B984 C0 02            [24] 1271 	push	ar2
      00B986 C0 01            [24] 1272 	push	ar1
      00B988 12 55 EF         [24] 1273 	lcall	_rgb_matrix_get_speed
      00B98B A8 82            [24] 1274 	mov	r0, dpl
      00B98D D0 01            [24] 1275 	pop	ar1
      00B98F D0 02            [24] 1276 	pop	ar2
      00B991 D0 05            [24] 1277 	pop	ar5
      00B993 D0 06            [24] 1278 	pop	ar6
      00B995 12 82 07         [24] 1279 	lcall	_ak820_outline_0072
                                   1280 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B998 74 05            [12] 1281 	mov	a,#0x05
      00B99A 12 8F 89         [24] 1282 	lcall	_ak820_outline_0142
      00B99D C0 06            [24] 1283 	push	ar6
      00B99F C0 05            [24] 1284 	push	ar5
      00B9A1 C0 02            [24] 1285 	push	ar2
      00B9A3 C0 01            [24] 1286 	push	ar1
      00B9A5 12 55 DA         [24] 1287 	lcall	_rgb_matrix_get_hue
      00B9A8 A8 82            [24] 1288 	mov	r0, dpl
      00B9AA D0 01            [24] 1289 	pop	ar1
      00B9AC D0 02            [24] 1290 	pop	ar2
      00B9AE D0 05            [24] 1291 	pop	ar5
      00B9B0 D0 06            [24] 1292 	pop	ar6
      00B9B2 12 82 07         [24] 1293 	lcall	_ak820_outline_0072
                                   1294 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B9B5 74 06            [12] 1295 	mov	a,#0x06
      00B9B7 12 8F 89         [24] 1296 	lcall	_ak820_outline_0142
      00B9BA C0 06            [24] 1297 	push	ar6
      00B9BC C0 05            [24] 1298 	push	ar5
      00B9BE C0 02            [24] 1299 	push	ar2
      00B9C0 C0 01            [24] 1300 	push	ar1
      00B9C2 12 55 E1         [24] 1301 	lcall	_rgb_matrix_get_sat
      00B9C5 A8 82            [24] 1302 	mov	r0, dpl
      00B9C7 D0 01            [24] 1303 	pop	ar1
      00B9C9 D0 02            [24] 1304 	pop	ar2
      00B9CB D0 05            [24] 1305 	pop	ar5
      00B9CD D0 06            [24] 1306 	pop	ar6
      00B9CF 12 82 07         [24] 1307 	lcall	_ak820_outline_0072
                                   1308 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B9D2 74 07            [12] 1309 	mov	a,#0x07
      00B9D4 12 8F 89         [24] 1310 	lcall	_ak820_outline_0142
      00B9D7 C0 02            [24] 1311 	push	ar2
      00B9D9 C0 01            [24] 1312 	push	ar1
      00B9DB 12 55 E8         [24] 1313 	lcall	_rgb_matrix_get_val
      00B9DE A8 82            [24] 1314 	mov	r0, dpl
      00B9E0 D0 01            [24] 1315 	pop	ar1
      00B9E2 D0 02            [24] 1316 	pop	ar2
      00B9E4 12 82 07         [24] 1317 	lcall	_ak820_outline_0072
                                   1318 ;	quantum/vialrgb.c:156: break;
      00B9E7 22               [24] 1319 	ret
                                   1320 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B9E8                       1321 00105$:
                                   1322 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B9E8 EF               [12] 1323 	mov	a,r7
      00B9E9 24 FE            [12] 1324 	add	a,#0xfe
      00B9EB 90 0D A4         [24] 1325 	mov	dptr,#_get_supported_PARM_2
      00B9EE F0               [24] 1326 	movx	@dptr,a
      00B9EF 12 34 71         [24] 1327 	lcall	_ak820_outline_0129
                                   1328 ;	quantum/vialrgb.c:160: break;
      00B9F2 02 B6 5F         [24] 1329 	ljmp	_get_supported
                                   1330 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B9F5                       1331 00106$:
                                   1332 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B9F5 12 34 71         [24] 1333 	lcall	_ak820_outline_0129
      00B9F8 74 52            [12] 1334 	mov	a,#0x52
      00B9FA F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B9FB 12 BB 0C         [24] 1337 	lcall	_ak820_outline_0040
      00B9FE E4               [12] 1338 	clr	a
      00B9FF F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:166: break;
      00BA00 22               [24] 1341 	ret
                                   1342 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BA01                       1343 00107$:
                                   1344 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BA01 12 34 71         [24] 1345 	lcall	_ak820_outline_0129
      00BA04 E0               [24] 1346 	movx	a,@dptr
      00BA05 FF               [12] 1347 	mov	r7,a
      00BA06 7A 00            [12] 1348 	mov	r2,#0x00
      00BA08 74 03            [12] 1349 	mov	a,#0x03
      00BA0A 2D               [12] 1350 	add	a, r5
      00BA0B F8               [12] 1351 	mov	r0,a
      00BA0C E4               [12] 1352 	clr	a
      00BA0D 3E               [12] 1353 	addc	a, r6
      00BA0E F9               [12] 1354 	mov	r1,a
      00BA0F C0 03            [24] 1355 	push	ar3
      00BA11 C0 04            [24] 1356 	push	ar4
      00BA13 12 39 2E         [24] 1357 	lcall	_ak820_outline_0155
      00BA16 E0               [24] 1358 	movx	a,@dptr
      00BA17 FB               [12] 1359 	mov	r3,a
      00BA18 E4               [12] 1360 	clr	a
      00BA19 4F               [12] 1361 	orl	a,r7
      00BA1A F5 51            [12] 1362 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BA1C EB               [12] 1363 	mov	a,r3
      00BA1D 4A               [12] 1364 	orl	a,r2
      00BA1E F5 52            [12] 1365 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1366 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BA20 AC 51            [24] 1367 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BA22 AF 52            [24] 1368 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BA24 C3               [12] 1369 	clr	c
      00BA25 EC               [12] 1370 	mov	a,r4
      00BA26 94 52            [12] 1371 	subb	a,#0x52
      00BA28 EF               [12] 1372 	mov	a,r7
      00BA29 94 00            [12] 1373 	subb	a,#0x00
      00BA2B D0 04            [24] 1374 	pop	ar4
      00BA2D D0 03            [24] 1375 	pop	ar3
      00BA2F 40 01            [24] 1376 	jc	00109$
      00BA31 22               [24] 1377 	ret
      00BA32                       1378 00109$:
                                   1379 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BA32 E5 51            [12] 1380 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BA34 25 51            [12] 1381 	add	a,_vialrgb_get_value_sloc0_1_0
      00BA36 FA               [12] 1382 	mov	r2,a
      00BA37 E5 52            [12] 1383 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BA39 33               [12] 1384 	rlc	a
      00BA3A FF               [12] 1385 	mov	r7,a
      00BA3B EA               [12] 1386 	mov	a,r2
      00BA3C 24 D2            [12] 1387 	add	a, #_ak820_led_points
      00BA3E F5 53            [12] 1388 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BA40 EF               [12] 1389 	mov	a,r7
      00BA41 34 BF            [12] 1390 	addc	a, #(_ak820_led_points >> 8)
      00BA43 F5 54            [12] 1391 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BA45 85 53 82         [24] 1392 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BA48 85 54 83         [24] 1393 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BA4B E4               [12] 1394 	clr	a
      00BA4C 93               [24] 1395 	movc	a,@a+dptr
      00BA4D 12 34 71         [24] 1396 	lcall	_ak820_outline_0129
      00BA50 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BA51 85 53 82         [24] 1399 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BA54 85 54 83         [24] 1400 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BA57 A3               [24] 1401 	inc	dptr
      00BA58 E4               [12] 1402 	clr	a
      00BA59 93               [24] 1403 	movc	a,@a+dptr
      00BA5A 12 39 2E         [24] 1404 	lcall	_ak820_outline_0155
      00BA5D F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BA5E 12 BB 0C         [24] 1407 	lcall	_ak820_outline_0040
      00BA61 A3               [24] 1408 	inc	dptr
      00BA62 74 04            [12] 1409 	mov	a,#0x04
      00BA64 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BA65 90 0D AD         [24] 1412 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BA68 04               [12] 1413 	inc	a
      00BA69 2D               [12] 1414 	add	a, r5
      00BA6A F0               [24] 1415 	movx	@dptr,a
      00BA6B E4               [12] 1416 	clr	a
      00BA6C 3E               [12] 1417 	addc	a, r6
      00BA6D A3               [24] 1418 	inc	dptr
      00BA6E F0               [24] 1419 	movx	@dptr,a
      00BA6F 85 51 82         [24] 1420 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BA72 85 52 83         [24] 1421 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1422 ;	quantum/vialrgb.c:187: }
                                   1423 ;	quantum/vialrgb.c:188: }
      00BA75 02 B7 98         [24] 1424 	ljmp	_get_matrix_pos_for_led
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1427 ;------------------------------------------------------------
                                   1428 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1429 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1430 ;data          Allocated with name '_vialrgb_set_value_data_10000_299'
                                   1431 ;args          Allocated with name '_vialrgb_set_value_args_10001_302'
                                   1432 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_302'
                                   1433 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_305'
                                   1434 ;------------------------------------------------------------
                                   1435 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1436 ;	-----------------------------------------
                                   1437 ;	 function vialrgb_set_value
                                   1438 ;	-----------------------------------------
      00BA78                       1439 _vialrgb_set_value:
      00BA78 12 43 80         [24] 1440 	lcall	_ak820_outline_0036
      00BA7B 90 0D BC         [24] 1441 	mov	dptr,#_vialrgb_set_value_data_10000_299
      00BA7E 12 38 8B         [24] 1442 	lcall	_ak820_outline_0017
                                   1443 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BA81 90 0D BB         [24] 1444 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BA84 E0               [24] 1445 	movx	a,@dptr
      00BA85 FF               [12] 1446 	mov	r7,a
      00BA86 BF 20 02         [24] 1447 	cjne	r7,#0x20,00129$
      00BA89 80 01            [24] 1448 	sjmp	00102$
      00BA8B                       1449 00129$:
      00BA8B 22               [24] 1450 	ret
      00BA8C                       1451 00102$:
                                   1452 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA8C 90 0D BC         [24] 1453 	mov	dptr,#_vialrgb_set_value_data_10000_299
      00BA8F 12 BB 14         [24] 1454 	lcall	_ak820_outline_0051
                                   1455 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1456 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BA92 BA 41 02         [24] 1457 	cjne	r2,#0x41,00130$
      00BA95 80 06            [24] 1458 	sjmp	00103$
      00BA97                       1459 00130$:
      00BA97 BA 42 02         [24] 1460 	cjne	r2,#0x42,00131$
      00BA9A 80 60            [24] 1461 	sjmp	00104$
      00BA9C                       1462 00131$:
      00BA9C 22               [24] 1463 	ret
                                   1464 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BA9D                       1465 00103$:
                                   1466 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BA9D 12 34 71         [24] 1467 	lcall	_ak820_outline_0129
      00BAA0 E0               [24] 1468 	movx	a,@dptr
      00BAA1 FA               [12] 1469 	mov	r2,a
      00BAA2 12 BB 0C         [24] 1470 	lcall	_ak820_outline_0040
      00BAA5 E0               [24] 1471 	movx	a,@dptr
      00BAA6 F8               [12] 1472 	mov	r0,a
      00BAA7 79 00            [12] 1473 	mov	r1,#0x00
      00BAA9 88 56            [24] 1474 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BAAB 89 55            [24] 1475 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BAAD 8A 01            [24] 1476 	mov	ar1,r2
      00BAAF 7A 00            [12] 1477 	mov	r2,#0x00
      00BAB1 E5 56            [12] 1478 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BAB3 42 02            [12] 1479 	orl	ar2,a
                                   1480 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BAB5 89 82            [24] 1481 	mov	dpl, r1
      00BAB7 8A 83            [24] 1482 	mov	dph, r2
      00BAB9 C0 06            [24] 1483 	push	ar6
      00BABB C0 05            [24] 1484 	push	ar5
      00BABD 12 B7 6A         [24] 1485 	lcall	_set_mode
      00BAC0 D0 05            [24] 1486 	pop	ar5
      00BAC2 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BAC4 12 BB 0C         [24] 1489 	lcall	_ak820_outline_0040
      00BAC7 A3               [24] 1490 	inc	dptr
      00BAC8 E0               [24] 1491 	movx	a,@dptr
      00BAC9 F5 82            [12] 1492 	mov	dpl,a
      00BACB C0 06            [24] 1493 	push	ar6
      00BACD C0 05            [24] 1494 	push	ar5
      00BACF 12 56 BD         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BAD2 D0 05            [24] 1496 	pop	ar5
      00BAD4 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BAD6 12 BB 0C         [24] 1499 	lcall	_ak820_outline_0040
      00BAD9 A3               [24] 1500 	inc	dptr
      00BADA A3               [24] 1501 	inc	dptr
      00BADB E0               [24] 1502 	movx	a,@dptr
      00BADC F9               [12] 1503 	mov	r1,a
      00BADD 7A 00            [12] 1504 	mov	r2,#0x00
      00BADF 74 06            [12] 1505 	mov	a,#0x06
      00BAE1 12 BB 5E         [24] 1506 	lcall	_ak820_outline_0176
      00BAE4 F8               [12] 1507 	mov	r0,a
      00BAE5 74 07            [12] 1508 	mov	a,#0x07
      00BAE7 12 BB 5E         [24] 1509 	lcall	_ak820_outline_0176
      00BAEA FE               [12] 1510 	mov	r6,a
      00BAEB 90 07 29         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BAEE E8               [12] 1512 	mov	a,r0
      00BAEF F0               [24] 1513 	movx	@dptr,a
      00BAF0 90 07 2A         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BAF3 EE               [12] 1515 	mov	a,r6
      00BAF4 F0               [24] 1516 	movx	@dptr,a
      00BAF5 89 82            [24] 1517 	mov	dpl, r1
      00BAF7 8A 83            [24] 1518 	mov	dph, r2
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BAF9 02 56 8E         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BAFC                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BAFC EF               [12] 1524 	mov	a,r7
      00BAFD 24 FE            [12] 1525 	add	a,#0xfe
      00BAFF 90 0D B1         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00BB02 F0               [24] 1527 	movx	@dptr,a
      00BB03 12 34 71         [24] 1528 	lcall	_ak820_outline_0129
                                   1529 ;	quantum/vialrgb.c:210: }
                                   1530 ;	quantum/vialrgb.c:211: }
      00BB06 02 B7 CB         [24] 1531 	ljmp	_fast_set_leds
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'vialrgb_save'
                                   1534 ;------------------------------------------------------------
                                   1535 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1536 ;data          Allocated with name '_vialrgb_save_data_10000_307'
                                   1537 ;------------------------------------------------------------
                                   1538 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1539 ;	-----------------------------------------
                                   1540 ;	 function vialrgb_save
                                   1541 ;	-----------------------------------------
      00BB09                       1542 _vialrgb_save:
                                   1543 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1544 ;	quantum/vialrgb.c:218: }
      00BB09 02 50 A4         [24] 1545 	ljmp	_eeconfig_update_rgb_matrix
                                   1546 	.area CSEG    (CODE)
                                   1547 	.area CONST   (CODE)
                                   1548 	.area CONST   (CODE)
      00C30E                       1549 _supported_modes:
      00C30E 00                    1550 	.db #0x00	; 0
      00C30F 00                    1551 	.db #0x00	; 0
      00C310 01                    1552 	.db #0x01	; 1
      00C311 05                    1553 	.db #0x05	; 5
      00C312 02                    1554 	.db #0x02	; 2
      00C313 01                    1555 	.db #0x01	; 1
      00C314 06                    1556 	.db #0x06	; 6
      00C315 02                    1557 	.db #0x02	; 2
      00C316 0D                    1558 	.db #0x0d	; 13
      00C317 03                    1559 	.db #0x03	; 3
      00C318 0E                    1560 	.db #0x0e	; 14
      00C319 04                    1561 	.db #0x04	; 4
      00C31A 1F                    1562 	.db #0x1f	; 31
      00C31B 06                    1563 	.db #0x06	; 6
                                   1564 	.area CSEG    (CODE)
                                   1565 	.area XINIT   (CODE)
                                   1566 	.area CABS    (ABS,CODE)
                                   1567 
                                   1568 ; Experimental exact instruction outlining.
                                   1569 	.globl _ak820_outline_0010
                                   1570 	.globl _ak820_outline_0017
                                   1571 	.globl _ak820_outline_0036
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0041
                                   1574 	.globl _ak820_outline_0045
                                   1575 	.globl _ak820_outline_0051
                                   1576 	.globl _ak820_outline_0053
                                   1577 	.globl _ak820_outline_0060
                                   1578 	.globl _ak820_outline_0072
                                   1579 	.globl _ak820_outline_0085
                                   1580 	.globl _ak820_outline_0089
                                   1581 	.globl _ak820_outline_0092
                                   1582 	.globl _ak820_outline_0103
                                   1583 	.globl _ak820_outline_0113
                                   1584 	.globl _ak820_outline_0121
                                   1585 	.globl _ak820_outline_0122
                                   1586 	.globl _ak820_outline_0123
                                   1587 	.globl _ak820_outline_0126
                                   1588 	.globl _ak820_outline_0128
                                   1589 	.globl _ak820_outline_0129
                                   1590 	.globl _ak820_outline_0141
                                   1591 	.globl _ak820_outline_0142
                                   1592 	.globl _ak820_outline_0147
                                   1593 	.globl _ak820_outline_0149
                                   1594 	.globl _ak820_outline_0155
                                   1595 	.globl _ak820_outline_0156
                                   1596 	.globl _ak820_outline_0176
                                   1597 	.globl _ak820_outline_0190
                                   1598 	.globl _ak820_outline_0196
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0040
      00BB0C                       1602 _ak820_outline_0040:
      00BB0C 8D 82            [24] 1603 	mov	dpl,r5
      00BB0E 8E 83            [24] 1604 	mov	dph,r6
      00BB10 A3               [24] 1605 	inc	dptr
      00BB11 A3               [24] 1606 	inc	dptr
      00BB12 A3               [24] 1607 	inc	dptr
      00BB13 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0051
      00BB14                       1612 _ak820_outline_0051:
      00BB14 E0               [24] 1613 	movx	a,@dptr
      00BB15 FD               [12] 1614 	mov	r5,a
      00BB16 A3               [24] 1615 	inc	dptr
      00BB17 E0               [24] 1616 	movx	a,@dptr
      00BB18 FE               [12] 1617 	mov	r6,a
      00BB19 74 02            [12] 1618 	mov	a,#0x02
      00BB1B 2D               [12] 1619 	add	a,r5
      00BB1C FB               [12] 1620 	mov	r3,a
      00BB1D E4               [12] 1621 	clr	a
      00BB1E 3E               [12] 1622 	addc	a,r6
      00BB1F FC               [12] 1623 	mov	r4,a
      00BB20 8D 82            [24] 1624 	mov	dpl,r5
      00BB22 8E 83            [24] 1625 	mov	dph,r6
      00BB24 A3               [24] 1626 	inc	dptr
      00BB25 E0               [24] 1627 	movx	a,@dptr
      00BB26 FA               [12] 1628 	mov	r2,a
      00BB27 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0053
      00BB28                       1633 _ak820_outline_0053:
      00BB28 ED               [12] 1634 	mov	a,r5
      00BB29 75 F0 02         [24] 1635 	mov	b,#0x02
      00BB2C A4               [48] 1636 	mul	ab
      00BB2D 24 0E            [12] 1637 	add	a,#_supported_modes
      00BB2F FB               [12] 1638 	mov	r3,a
      00BB30 74 C3            [12] 1639 	mov	a,#(_supported_modes>>8)
      00BB32 35 F0            [12] 1640 	addc	a,b
      00BB34 FC               [12] 1641 	mov	r4,a
      00BB35 8B 82            [24] 1642 	mov	dpl,r3
      00BB37 8C 83            [24] 1643 	mov	dph,r4
      00BB39 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0092
      00BB3A                       1648 _ak820_outline_0092:
      00BB3A 90 0D B2         [24] 1649 	mov	dptr,#_fast_set_leds_args_10000_279
      00BB3D E0               [24] 1650 	movx	a,@dptr
      00BB3E F9               [12] 1651 	mov	r1,a
      00BB3F A3               [24] 1652 	inc	dptr
      00BB40 E0               [24] 1653 	movx	a,@dptr
      00BB41 FF               [12] 1654 	mov	r7,a
      00BB42 89 82            [24] 1655 	mov	dpl,r1
      00BB44 8F 83            [24] 1656 	mov	dph,r7
      00BB46 E0               [24] 1657 	movx	a,@dptr
      00BB47 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0113
      00BB48                       1662 _ak820_outline_0113:
      00BB48 90 0D B2         [24] 1663 	mov	dptr,#_fast_set_leds_args_10000_279
      00BB4B 74 01            [12] 1664 	mov	a,#0x01
      00BB4D 29               [12] 1665 	add	a,r1
      00BB4E F0               [24] 1666 	movx	@dptr,a
      00BB4F E4               [12] 1667 	clr	a
      00BB50 3F               [12] 1668 	addc	a,r7
      00BB51 A3               [24] 1669 	inc	dptr
      00BB52 F0               [24] 1670 	movx	@dptr,a
      00BB53 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0149
      00BB54                       1675 _ak820_outline_0149:
      00BB54 E4               [12] 1676 	clr	a
      00BB55 93               [24] 1677 	movc	a,@a+dptr
      00BB56 FC               [12] 1678 	mov	r4,a
      00BB57 7B 00            [12] 1679 	mov	r3,#0x00
      00BB59 8C 82            [24] 1680 	mov	dpl,r4
      00BB5B 8B 83            [24] 1681 	mov	dph,r3
      00BB5D 22               [24] 1682 	ret
                                   1683 
                                   1684 	.area CSEG (CODE)
                                   1685 ; function ak820_outline_0176
      00BB5E                       1686 _ak820_outline_0176:
      00BB5E 2D               [12] 1687 	add	a,r5
      00BB5F F5 82            [12] 1688 	mov	dpl,a
      00BB61 E4               [12] 1689 	clr	a
      00BB62 3E               [12] 1690 	addc	a,r6
      00BB63 F5 83            [12] 1691 	mov	dph,a
      00BB65 E0               [24] 1692 	movx	a,@dptr
      00BB66 22               [24] 1693 	ret
