                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_weak_mods
                                     12 	.globl _get_mods
                                     13 	.globl _alt_repeat_key_invoke
                                     14 	.globl _repeat_key_invoke
                                     15 	.globl _get_repeat_key_count
                                     16 	.globl _set_last_record
                                     17 	.globl _set_last_mods
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _process_repeat_key_PARM_2
                                    262 	.globl _process_last_key_PARM_2
                                    263 	.globl _remember_last_key_user_PARM_3
                                    264 	.globl _remember_last_key_user_PARM_2
                                    265 	.globl _remember_last_key_user
                                    266 	.globl _process_last_key
                                    267 	.globl _process_repeat_key
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000BC3                        554 _remember_last_key_user_PARM_2:
      000BC3                        555 	.ds 3
      000BC6                        556 _remember_last_key_user_PARM_3:
      000BC6                        557 	.ds 3
      000BC9                        558 _remember_last_key_PARM_2:
      000BC9                        559 	.ds 3
      000BCC                        560 _remember_last_key_PARM_3:
      000BCC                        561 	.ds 3
      000BCF                        562 _remember_last_key_keycode_10000_238:
      000BCF                        563 	.ds 2
      000BD1                        564 _process_last_key_PARM_2:
      000BD1                        565 	.ds 3
      000BD4                        566 _process_last_key_keycode_10000_241:
      000BD4                        567 	.ds 2
      000BD6                        568 _process_last_key_remembered_mods_30000_246:
      000BD6                        569 	.ds 1
      000BD7                        570 _process_repeat_key_PARM_2:
      000BD7                        571 	.ds 3
      000BDA                        572 _process_repeat_key_keycode_10000_249:
      000BDA                        573 	.ds 2
                                    574 ;--------------------------------------------------------
                                    575 ; absolute external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area XABS    (ABS,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; initialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XISEG   (XDATA)
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    610 ;------------------------------------------------------------
                                    611 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_164'
                                    612 ;------------------------------------------------------------
                                    613 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function remember_last_key_user
                                    624 ;	-----------------------------------------
      009C52                        625 _remember_last_key_user:
                                    626 ;	quantum/process_keycode/process_repeat_key.c:23: return true;
      009C52 75 82 01         [24]  627 	mov	dpl, #0x01
                                    628 ;	quantum/process_keycode/process_repeat_key.c:24: }
      009C55 22               [24]  629 	ret
                                    630 ;------------------------------------------------------------
                                    631 ;Allocation info for local variables in function 'remember_last_key'
                                    632 ;------------------------------------------------------------
                                    633 ;record        Allocated with name '_remember_last_key_PARM_2'
                                    634 ;remembered_mods Allocated with name '_remember_last_key_PARM_3'
                                    635 ;keycode       Allocated with name '_remember_last_key_keycode_10000_238'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/process_keycode/process_repeat_key.c:26: static bool remember_last_key(uint16_t keycode, keyrecord_t* record, uint8_t* remembered_mods) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function remember_last_key
                                    640 ;	-----------------------------------------
      009C56                        641 _remember_last_key:
      009C56 12 39 03         [24]  642 	lcall	_ak820_outline_0122
      009C59 90 0B CF         [24]  643 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C5C 12 38 FE         [24]  644 	lcall	_ak820_outline_0121
                                    645 ;	quantum/process_keycode/process_repeat_key.c:29: if (keycode == KC_NO || keycode == KC_TRANSPARENT ||
      009C5F 90 0B CF         [24]  646 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C62 12 38 C3         [24]  647 	lcall	_ak820_outline_0060
      009C65 90 0B CF         [24]  648 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C68 12 6E 56         [24]  649 	lcall	_ak820_outline_0041
      009C6B 70 03            [24]  650 	jnz	00242$
      009C6D 02 9D 48         [24]  651 	ljmp	00101$
      009C70                        652 00242$:
      009C70 BE 01 06         [24]  653 	cjne	r6,#0x01,00243$
      009C73 BF 00 03         [24]  654 	cjne	r7,#0x00,00243$
      009C76 02 9D 48         [24]  655 	ljmp	00101$
      009C79                        656 00243$:
                                    657 ;	quantum/process_keycode/process_repeat_key.c:30: (keycode >= QK_MOMENTARY && keycode <= QK_MOMENTARY_MAX) ||
      009C79 C3               [12]  658 	clr	c
      009C7A EE               [12]  659 	mov	a,r6
      009C7B 94 20            [12]  660 	subb	a,#0x20
      009C7D EF               [12]  661 	mov	a,r7
      009C7E 94 52            [12]  662 	subb	a,#0x52
      009C80 40 0A            [24]  663 	jc	00107$
      009C82 74 3F            [12]  664 	mov	a,#0x3f
      009C84 12 9E 5D         [24]  665 	lcall	_ak820_outline_0195
      009C87 40 03            [24]  666 	jc	00245$
      009C89 02 9D 48         [24]  667 	ljmp	00101$
      009C8C                        668 00245$:
                                    669 ;	free result
      009C8C                        670 00107$:
                                    671 ;	quantum/process_keycode/process_repeat_key.c:31: (keycode >= QK_LAYER_MOD && keycode <= QK_LAYER_MOD_MAX) ||
      009C8C 90 0B CF         [24]  672 	mov	dptr,#_remember_last_key_keycode_10000_238
      009C8F 12 38 C3         [24]  673 	lcall	_ak820_outline_0060
      009C92 C3               [12]  674 	clr	c
      009C93 94 50            [12]  675 	subb	a,#0x50
      009C95 40 0B            [24]  676 	jc	00109$
      009C97 74 FF            [12]  677 	mov	a,#0xff
      009C99 9E               [12]  678 	subb	a,r6
      009C9A 74 51            [12]  679 	mov	a,#0x51
      009C9C 9F               [12]  680 	subb	a,r7
      009C9D 40 03            [24]  681 	jc	00247$
      009C9F 02 9D 48         [24]  682 	ljmp	00101$
      009CA2                        683 00247$:
                                    684 ;	free result
      009CA2                        685 00109$:
                                    686 ;	quantum/process_keycode/process_repeat_key.c:32: (keycode >= QK_DEF_LAYER && keycode <= QK_DEF_LAYER_MAX) ||
      009CA2 C3               [12]  687 	clr	c
      009CA3 EE               [12]  688 	mov	a,r6
      009CA4 94 40            [12]  689 	subb	a,#0x40
      009CA6 EF               [12]  690 	mov	a,r7
      009CA7 94 52            [12]  691 	subb	a,#0x52
      009CA9 40 0A            [24]  692 	jc	00111$
      009CAB 74 5F            [12]  693 	mov	a,#0x5f
      009CAD 12 9E 5D         [24]  694 	lcall	_ak820_outline_0195
      009CB0 40 03            [24]  695 	jc	00249$
      009CB2 02 9D 48         [24]  696 	ljmp	00101$
      009CB5                        697 00249$:
                                    698 ;	free result
      009CB5                        699 00111$:
                                    700 ;	quantum/process_keycode/process_repeat_key.c:33: (keycode >= QK_TO && keycode <= QK_TO_MAX) ||
      009CB5 74 AE            [12]  701 	mov	a,#0x100 - 0x52
      009CB7 2F               [12]  702 	add	a,r7
      009CB8 50 0B            [24]  703 	jnc	00113$
      009CBA C3               [12]  704 	clr	c
      009CBB 74 1F            [12]  705 	mov	a,#0x1f
      009CBD 12 9E 5D         [24]  706 	lcall	_ak820_outline_0195
      009CC0 40 03            [24]  707 	jc	00251$
      009CC2 02 9D 48         [24]  708 	ljmp	00101$
      009CC5                        709 00251$:
                                    710 ;	free result
      009CC5                        711 00113$:
                                    712 ;	quantum/process_keycode/process_repeat_key.c:34: (keycode >= QK_TOGGLE_LAYER && keycode <= QK_TOGGLE_LAYER_MAX) ||
      009CC5 C3               [12]  713 	clr	c
      009CC6 EE               [12]  714 	mov	a,r6
      009CC7 94 60            [12]  715 	subb	a,#0x60
      009CC9 EF               [12]  716 	mov	a,r7
      009CCA 94 52            [12]  717 	subb	a,#0x52
      009CCC 40 0A            [24]  718 	jc	00115$
      009CCE 74 7F            [12]  719 	mov	a,#0x7f
      009CD0 12 9E 5D         [24]  720 	lcall	_ak820_outline_0195
      009CD3 40 03            [24]  721 	jc	00253$
      009CD5 02 9D 48         [24]  722 	ljmp	00101$
      009CD8                        723 00253$:
                                    724 ;	free result
      009CD8                        725 00115$:
                                    726 ;	quantum/process_keycode/process_repeat_key.c:35: (keycode >= QK_LAYER_TAP_TOGGLE && keycode <= QK_LAYER_TAP_TOGGLE_MAX) ||
      009CD8 C3               [12]  727 	clr	c
      009CD9 EE               [12]  728 	mov	a,r6
      009CDA 94 C0            [12]  729 	subb	a,#0xc0
      009CDC EF               [12]  730 	mov	a,r7
      009CDD 94 52            [12]  731 	subb	a,#0x52
      009CDF 40 07            [24]  732 	jc	00117$
      009CE1 74 DF            [12]  733 	mov	a,#0xdf
      009CE3 12 9E 5D         [24]  734 	lcall	_ak820_outline_0195
      009CE6 50 60            [24]  735 	jnc	00101$
                                    736 ;	free result
      009CE8                        737 00117$:
                                    738 ;	quantum/process_keycode/process_repeat_key.c:36: (keycode >= KC_LCTL && keycode <= KC_RGUI) ||
      009CE8 12 9E 55         [24]  739 	lcall	_ak820_outline_0124
      009CEB 40 07            [24]  740 	jc	00118$
      009CED 74 E7            [12]  741 	mov	a,#0xe7
      009CEF 9E               [12]  742 	subb	a,r6
      009CF0 E4               [12]  743 	clr	a
      009CF1 9F               [12]  744 	subb	a,r7
      009CF2 50 54            [24]  745 	jnc	00101$
                                    746 ;	free result
      009CF4                        747 00118$:
                                    748 ;	quantum/process_keycode/process_repeat_key.c:37: keycode == KC_HYPR || keycode == KC_MEH || keycode == QK_REPEAT_KEY
      009CF4 BE 00 05         [24]  749 	cjne	r6,#0x00,00258$
      009CF7 BF 0F 02         [24]  750 	cjne	r7,#0x0f,00258$
      009CFA 80 4C            [24]  751 	sjmp	00101$
      009CFC                        752 00258$:
      009CFC BE 00 05         [24]  753 	cjne	r6,#0x00,00259$
      009CFF BF 07 02         [24]  754 	cjne	r7,#0x07,00259$
      009D02 80 44            [24]  755 	sjmp	00101$
      009D04                        756 00259$:
                                    757 ;	quantum/process_keycode/process_repeat_key.c:39: || keycode == QK_ALT_REPEAT_KEY
      009D04 BE 79 05         [24]  758 	cjne	r6,#0x79,00260$
      009D07 BF 7C 02         [24]  759 	cjne	r7,#0x7c,00260$
      009D0A 80 3C            [24]  760 	sjmp	00101$
      009D0C                        761 00260$:
                                    762 ;	quantum/process_keycode/process_repeat_key.c:42: || (keycode >= QK_ONE_SHOT_LAYER && keycode <= QK_ONE_SHOT_LAYER_MAX)
      009D0C BE 7A 05         [24]  763 	cjne	r6,#0x7a,00261$
      009D0F BF 7C 02         [24]  764 	cjne	r7,#0x7c,00261$
      009D12 80 34            [24]  765 	sjmp	00101$
      009D14                        766 00261$:
      009D14 C3               [12]  767 	clr	c
      009D15 EE               [12]  768 	mov	a,r6
      009D16 94 80            [12]  769 	subb	a,#0x80
      009D18 EF               [12]  770 	mov	a,r7
      009D19 94 52            [12]  771 	subb	a,#0x52
      009D1B 40 07            [24]  772 	jc	00125$
      009D1D 74 9F            [12]  773 	mov	a,#0x9f
      009D1F 12 9E 5D         [24]  774 	lcall	_ak820_outline_0195
      009D22 50 24            [24]  775 	jnc	00101$
                                    776 ;	free result
      009D24                        777 00125$:
                                    778 ;	quantum/process_keycode/process_repeat_key.c:43: || (keycode >= QK_ONE_SHOT_MOD && keycode <= QK_ONE_SHOT_MOD_MAX)
      009D24 C3               [12]  779 	clr	c
      009D25 EE               [12]  780 	mov	a,r6
      009D26 94 A0            [12]  781 	subb	a,#0xa0
      009D28 EF               [12]  782 	mov	a,r7
      009D29 94 52            [12]  783 	subb	a,#0x52
      009D2B 40 07            [24]  784 	jc	00126$
      009D2D 74 BF            [12]  785 	mov	a,#0xbf
      009D2F 12 9E 5D         [24]  786 	lcall	_ak820_outline_0195
      009D32 50 14            [24]  787 	jnc	00101$
                                    788 ;	free result
      009D34                        789 00126$:
                                    790 ;	quantum/process_keycode/process_repeat_key.c:46: || keycode == QK_TRI_LAYER_LOWER || keycode == QK_TRI_LAYER_UPPER
      009D34 90 0B CF         [24]  791 	mov	dptr,#_remember_last_key_keycode_10000_238
      009D37 12 48 9E         [24]  792 	lcall	_ak820_outline_0013
      009D3A BC 77 05         [24]  793 	cjne	r4,#0x77,00266$
      009D3D BD 7C 02         [24]  794 	cjne	r5,#0x7c,00266$
      009D40 80 06            [24]  795 	sjmp	00101$
      009D42                        796 00266$:
                                    797 ;	quantum/process_keycode/process_repeat_key.c:48: ) return false;
      009D42 BC 78 07         [24]  798 	cjne	r4,#0x78,00102$
      009D45 BD 7C 04         [24]  799 	cjne	r5,#0x7c,00102$
      009D48                        800 00101$:
      009D48 75 82 00         [24]  801 	mov	dpl, #0x00
      009D4B 22               [24]  802 	ret
      009D4C                        803 00102$:
                                    804 ;	quantum/process_keycode/process_repeat_key.c:61: return remember_last_key_user(keycode, record, remembered_mods);
      009D4C 90 0B C9         [24]  805 	mov	dptr,#_remember_last_key_PARM_2
      009D4F 12 9E 4C         [24]  806 	lcall	_ak820_outline_0021
      009D52 90 0B CC         [24]  807 	mov	dptr,#_remember_last_key_PARM_3
      009D55 12 38 F8         [24]  808 	lcall	_ak820_outline_0109
      009D58 A3               [24]  809 	inc	dptr
      009D59 E0               [24]  810 	movx	a,@dptr
      009D5A FA               [12]  811 	mov	r2,a
      009D5B 90 0B C3         [24]  812 	mov	dptr,#_remember_last_key_user_PARM_2
      009D5E 12 38 F2         [24]  813 	lcall	_ak820_outline_0103
      009D61 ED               [12]  814 	mov	a,r5
      009D62 A3               [24]  815 	inc	dptr
      009D63 F0               [24]  816 	movx	@dptr,a
      009D64 90 0B C6         [24]  817 	mov	dptr,#_remember_last_key_user_PARM_3
      009D67 E8               [12]  818 	mov	a,r0
      009D68 F0               [24]  819 	movx	@dptr,a
      009D69 E9               [12]  820 	mov	a,r1
      009D6A A3               [24]  821 	inc	dptr
      009D6B F0               [24]  822 	movx	@dptr,a
      009D6C EA               [12]  823 	mov	a,r2
      009D6D A3               [24]  824 	inc	dptr
      009D6E 12 43 AB         [24]  825 	lcall	_ak820_outline_0088
                                    826 ;	quantum/process_keycode/process_repeat_key.c:62: }
      009D71 02 9C 52         [24]  827 	ljmp	_remember_last_key_user
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'process_last_key'
                                    830 ;------------------------------------------------------------
                                    831 ;record        Allocated with name '_process_last_key_PARM_2'
                                    832 ;keycode       Allocated with name '_process_last_key_keycode_10000_241'
                                    833 ;remembered_mods Allocated with name '_process_last_key_remembered_mods_30000_246'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/process_keycode/process_repeat_key.c:64: bool process_last_key(uint16_t keycode, keyrecord_t* record) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function process_last_key
                                    838 ;	-----------------------------------------
      009D74                        839 _process_last_key:
      009D74 12 39 03         [24]  840 	lcall	_ak820_outline_0122
      009D77 90 0B D4         [24]  841 	mov	dptr,#_process_last_key_keycode_10000_241
      009D7A 12 38 FE         [24]  842 	lcall	_ak820_outline_0121
                                    843 ;	quantum/process_keycode/process_repeat_key.c:65: if (get_repeat_key_count()) {
      009D7D 12 A5 C9         [24]  844 	lcall	_get_repeat_key_count
      009D80 E5 82            [12]  845 	mov	a, dpl
      009D82 60 04            [24]  846 	jz	00102$
                                    847 ;	quantum/process_keycode/process_repeat_key.c:66: return true;
      009D84 75 82 01         [24]  848 	mov	dpl, #0x01
      009D87 22               [24]  849 	ret
      009D88                        850 00102$:
                                    851 ;	quantum/process_keycode/process_repeat_key.c:69: if (record->event.pressed) {
      009D88 90 0B D1         [24]  852 	mov	dptr,#_process_last_key_PARM_2
      009D8B 12 9E 34         [24]  853 	lcall	_ak820_outline_0006
      009D8E 12 BC E0         [24]  854 	lcall	__gptrget
      009D91 60 56            [24]  855 	jz	00106$
                                    856 ;	quantum/process_keycode/process_repeat_key.c:70: uint8_t remembered_mods = get_mods() | get_weak_mods();
      009D93 12 81 A6         [24]  857 	lcall	_get_mods
      009D96 AC 82            [24]  858 	mov	r4, dpl
      009D98 12 81 BC         [24]  859 	lcall	_get_weak_mods
      009D9B AB 82            [24]  860 	mov	r3, dpl
      009D9D 90 0B D6         [24]  861 	mov	dptr,#_process_last_key_remembered_mods_30000_246
      009DA0 EB               [12]  862 	mov	a,r3
      009DA1 4C               [12]  863 	orl	a,r4
      009DA2 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/process_keycode/process_repeat_key.c:75: if (remember_last_key(keycode, record, &remembered_mods)) {
      009DA3 90 0B D4         [24]  866 	mov	dptr,#_process_last_key_keycode_10000_241
      009DA6 12 39 28         [24]  867 	lcall	_ak820_outline_0147
      009DA9 90 0B C9         [24]  868 	mov	dptr,#_remember_last_key_PARM_2
      009DAC ED               [12]  869 	mov	a,r5
      009DAD 12 38 8B         [24]  870 	lcall	_ak820_outline_0017
      009DB0 90 0B CC         [24]  871 	mov	dptr,#_remember_last_key_PARM_3
      009DB3 74 D6            [12]  872 	mov	a,#_process_last_key_remembered_mods_30000_246
      009DB5 F0               [24]  873 	movx	@dptr,a
      009DB6 74 0B            [12]  874 	mov	a,#(_process_last_key_remembered_mods_30000_246 >> 8)
      009DB8 12 38 E0         [24]  875 	lcall	_ak820_outline_0081
      009DBB 12 34 71         [24]  876 	lcall	_ak820_outline_0129
      009DBE C0 04            [24]  877 	push	ar4
      009DC0 C0 03            [24]  878 	push	ar3
      009DC2 12 9C 56         [24]  879 	lcall	_remember_last_key
      009DC5 E5 82            [12]  880 	mov	a, dpl
      009DC7 D0 03            [24]  881 	pop	ar3
      009DC9 D0 04            [24]  882 	pop	ar4
      009DCB 60 1C            [24]  883 	jz	00106$
                                    884 ;	quantum/process_keycode/process_repeat_key.c:76: set_last_record(keycode, record);
      009DCD 90 0B D1         [24]  885 	mov	dptr,#_process_last_key_PARM_2
      009DD0 12 4F 61         [24]  886 	lcall	_ak820_outline_0014
      009DD3 90 0C 49         [24]  887 	mov	dptr,#_set_last_record_PARM_2
      009DD6 ED               [12]  888 	mov	a,r5
      009DD7 12 38 8B         [24]  889 	lcall	_ak820_outline_0017
      009DDA 12 34 71         [24]  890 	lcall	_ak820_outline_0129
      009DDD 12 A5 48         [24]  891 	lcall	_set_last_record
                                    892 ;	quantum/process_keycode/process_repeat_key.c:77: set_last_mods(remembered_mods);
      009DE0 90 0B D6         [24]  893 	mov	dptr,#_process_last_key_remembered_mods_30000_246
      009DE3 E0               [24]  894 	movx	a,@dptr
      009DE4 F5 82            [12]  895 	mov	dpl,a
      009DE6 12 A5 3C         [24]  896 	lcall	_set_last_mods
      009DE9                        897 00106$:
                                    898 ;	quantum/process_keycode/process_repeat_key.c:81: return true;
      009DE9 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/process_keycode/process_repeat_key.c:82: }
      009DEC 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_repeat_key'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_repeat_key_PARM_2'
                                    906 ;keycode       Allocated with name '_process_repeat_key_keycode_10000_249'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/process_keycode/process_repeat_key.c:84: bool process_repeat_key(uint16_t keycode, keyrecord_t* record) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function process_repeat_key
                                    911 ;	-----------------------------------------
      009DED                        912 _process_repeat_key:
      009DED 12 39 03         [24]  913 	lcall	_ak820_outline_0122
      009DF0 90 0B DA         [24]  914 	mov	dptr,#_process_repeat_key_keycode_10000_249
      009DF3 12 38 FE         [24]  915 	lcall	_ak820_outline_0121
                                    916 ;	quantum/process_keycode/process_repeat_key.c:85: if (get_repeat_key_count()) {
      009DF6 12 A5 C9         [24]  917 	lcall	_get_repeat_key_count
      009DF9 E5 82            [12]  918 	mov	a, dpl
      009DFB 60 04            [24]  919 	jz	00102$
                                    920 ;	quantum/process_keycode/process_repeat_key.c:86: return true;
      009DFD 75 82 01         [24]  921 	mov	dpl, #0x01
      009E00 22               [24]  922 	ret
      009E01                        923 00102$:
                                    924 ;	quantum/process_keycode/process_repeat_key.c:89: if (keycode == QK_REPEAT_KEY) {
      009E01 90 0B DA         [24]  925 	mov	dptr,#_process_repeat_key_keycode_10000_249
      009E04 12 38 C3         [24]  926 	lcall	_ak820_outline_0060
      009E07 BE 79 13         [24]  927 	cjne	r6,#0x79,00106$
      009E0A BF 7C 10         [24]  928 	cjne	r7,#0x7c,00106$
                                    929 ;	quantum/process_keycode/process_repeat_key.c:90: repeat_key_invoke(&record->event);
      009E0D 90 0B D7         [24]  930 	mov	dptr,#_process_repeat_key_PARM_2
      009E10 12 9E 4C         [24]  931 	lcall	_ak820_outline_0021
      009E13 12 70 8D         [24]  932 	lcall	_ak820_outline_0102
      009E16 12 A6 EA         [24]  933 	lcall	_repeat_key_invoke
                                    934 ;	quantum/process_keycode/process_repeat_key.c:91: return false;
      009E19 75 82 00         [24]  935 	mov	dpl, #0x00
      009E1C 22               [24]  936 	ret
      009E1D                        937 00106$:
                                    938 ;	quantum/process_keycode/process_repeat_key.c:93: } else if (keycode == QK_ALT_REPEAT_KEY) {
      009E1D BE 7A 10         [24]  939 	cjne	r6,#0x7a,00107$
      009E20 BF 7C 0D         [24]  940 	cjne	r7,#0x7c,00107$
                                    941 ;	quantum/process_keycode/process_repeat_key.c:94: alt_repeat_key_invoke(&record->event);
      009E23 90 0B D7         [24]  942 	mov	dptr,#_process_repeat_key_PARM_2
      009E26 12 4F 3B         [24]  943 	lcall	_ak820_outline_0004
      009E29 12 A8 59         [24]  944 	lcall	_alt_repeat_key_invoke
                                    945 ;	quantum/process_keycode/process_repeat_key.c:95: return false;
      009E2C 75 82 00         [24]  946 	mov	dpl, #0x00
      009E2F 22               [24]  947 	ret
      009E30                        948 00107$:
                                    949 ;	quantum/process_keycode/process_repeat_key.c:99: return true;
      009E30 75 82 01         [24]  950 	mov	dpl, #0x01
                                    951 ;	quantum/process_keycode/process_repeat_key.c:100: }
      009E33 22               [24]  952 	ret
                                    953 	.area CSEG    (CODE)
                                    954 	.area CONST   (CODE)
                                    955 	.area XINIT   (CODE)
                                    956 	.area CABS    (ABS,CODE)
                                    957 
                                    958 ; Experimental exact instruction outlining.
                                    959 	.globl _ak820_outline_0004
                                    960 	.globl _ak820_outline_0006
                                    961 	.globl _ak820_outline_0013
                                    962 	.globl _ak820_outline_0014
                                    963 	.globl _ak820_outline_0017
                                    964 	.globl _ak820_outline_0021
                                    965 	.globl _ak820_outline_0041
                                    966 	.globl _ak820_outline_0060
                                    967 	.globl _ak820_outline_0081
                                    968 	.globl _ak820_outline_0088
                                    969 	.globl _ak820_outline_0102
                                    970 	.globl _ak820_outline_0103
                                    971 	.globl _ak820_outline_0109
                                    972 	.globl _ak820_outline_0121
                                    973 	.globl _ak820_outline_0122
                                    974 	.globl _ak820_outline_0124
                                    975 	.globl _ak820_outline_0129
                                    976 	.globl _ak820_outline_0147
                                    977 	.globl _ak820_outline_0195
                                    978 
                                    979 	.area CSEG (CODE)
                                    980 ; function ak820_outline_0006
      009E34                        981 _ak820_outline_0006:
      009E34 E0               [24]  982 	movx	a,@dptr
      009E35 FD               [12]  983 	mov	r5,a
      009E36 A3               [24]  984 	inc	dptr
      009E37 E0               [24]  985 	movx	a,@dptr
      009E38 FE               [12]  986 	mov	r6,a
      009E39 A3               [24]  987 	inc	dptr
      009E3A E0               [24]  988 	movx	a,@dptr
      009E3B FF               [12]  989 	mov	r7,a
      009E3C 74 05            [12]  990 	mov	a,#0x05
      009E3E 2D               [12]  991 	add	a,r5
      009E3F FA               [12]  992 	mov	r2,a
      009E40 E4               [12]  993 	clr	a
      009E41 3E               [12]  994 	addc	a,r6
      009E42 FB               [12]  995 	mov	r3,a
      009E43 8F 04            [24]  996 	mov	ar4,r7
      009E45 8A 82            [24]  997 	mov	dpl,r2
      009E47 8B 83            [24]  998 	mov	dph,r3
      009E49 8C F0            [24]  999 	mov	b,r4
      009E4B 22               [24] 1000 	ret
                                   1001 
                                   1002 	.area CSEG (CODE)
                                   1003 ; function ak820_outline_0021
      009E4C                       1004 _ak820_outline_0021:
      009E4C E0               [24] 1005 	movx	a,@dptr
      009E4D FB               [12] 1006 	mov	r3,a
      009E4E A3               [24] 1007 	inc	dptr
      009E4F E0               [24] 1008 	movx	a,@dptr
      009E50 FC               [12] 1009 	mov	r4,a
      009E51 A3               [24] 1010 	inc	dptr
      009E52 E0               [24] 1011 	movx	a,@dptr
      009E53 FD               [12] 1012 	mov	r5,a
      009E54 22               [24] 1013 	ret
                                   1014 
                                   1015 	.area CSEG (CODE)
                                   1016 ; function ak820_outline_0124
      009E55                       1017 _ak820_outline_0124:
      009E55 C3               [12] 1018 	clr	c
      009E56 EE               [12] 1019 	mov	a,r6
      009E57 94 E0            [12] 1020 	subb	a,#0xe0
      009E59 EF               [12] 1021 	mov	a,r7
      009E5A 94 00            [12] 1022 	subb	a,#0x00
      009E5C 22               [24] 1023 	ret
                                   1024 
                                   1025 	.area CSEG (CODE)
                                   1026 ; function ak820_outline_0195
      009E5D                       1027 _ak820_outline_0195:
      009E5D 9E               [12] 1028 	subb	a,r6
      009E5E 74 52            [12] 1029 	mov	a,#0x52
      009E60 9F               [12] 1030 	subb	a,r7
      009E61 22               [24] 1031 	ret
