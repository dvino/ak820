                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_step
                                     12 	.globl _rgb_matrix_get_mode
                                     13 	.globl _rgb_matrix_mode
                                     14 	.globl _rgb_matrix_toggle
                                     15 	.globl _get_mods
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _process_rgb_PARM_2
                                    260 	.globl _process_rgb
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      000BDC                        547 _process_rgb_PARM_2:
      000BDC                        548 	.ds 3
      000BDF                        549 _process_rgb_keycode_10000_275:
      000BDF                        550 	.ds 2
      000BE1                        551 _process_rgb_action_50000_280:
      000BE1                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; absolute external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XABS    (ABS,XDATA)
                                    557 ;--------------------------------------------------------
                                    558 ; initialized external ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area XISEG   (XDATA)
                                    561 	.area HOME    (CODE)
                                    562 	.area GSINIT0 (CODE)
                                    563 	.area GSINIT1 (CODE)
                                    564 	.area GSINIT2 (CODE)
                                    565 	.area GSINIT3 (CODE)
                                    566 	.area GSINIT4 (CODE)
                                    567 	.area GSINIT5 (CODE)
                                    568 	.area GSINIT  (CODE)
                                    569 	.area GSFINAL (CODE)
                                    570 	.area CSEG    (CODE)
                                    571 ;--------------------------------------------------------
                                    572 ; global & static initialisations
                                    573 ;--------------------------------------------------------
                                    574 	.area HOME    (CODE)
                                    575 	.area GSINIT  (CODE)
                                    576 	.area GSFINAL (CODE)
                                    577 	.area GSINIT  (CODE)
                                    578 ;--------------------------------------------------------
                                    579 ; Home
                                    580 ;--------------------------------------------------------
                                    581 	.area HOME    (CODE)
                                    582 	.area HOME    (CODE)
                                    583 ;--------------------------------------------------------
                                    584 ; code
                                    585 ;--------------------------------------------------------
                                    586 	.area CSEG    (CODE)
                                    587 ;------------------------------------------------------------
                                    588 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    589 ;------------------------------------------------------------
                                    590 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_122'
                                    591 ;------------------------------------------------------------
                                    592 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    593 ;	-----------------------------------------
                           000007   594 	ar7 = 0x07
                           000006   595 	ar6 = 0x06
                           000005   596 	ar5 = 0x05
                           000004   597 	ar4 = 0x04
                           000003   598 	ar3 = 0x03
                           000002   599 	ar2 = 0x02
                           000001   600 	ar1 = 0x01
                           000000   601 	ar0 = 0x00
                                    602 ;	 function process_rgb
                                    603 ;	-----------------------------------------
      009E62                        604 _process_rgb:
      009E62 12 39 03         [24]  605 	lcall	_ak820_outline_0122
      009E65 90 0B DF         [24]  606 	mov	dptr,#_process_rgb_keycode_10000_275
      009E68 12 38 FE         [24]  607 	lcall	_ak820_outline_0121
                                    608 ;	quantum/process_keycode/process_rgb.c:88: if (!record->event.pressed) {
      009E6B 90 0B DC         [24]  609 	mov	dptr,#_process_rgb_PARM_2
      009E6E 12 4F 61         [24]  610 	lcall	_ak820_outline_0014
      009E71 74 05            [12]  611 	mov	a,#0x05
      009E73 12 39 1C         [24]  612 	lcall	_ak820_outline_0143
      009E76 12 6E 5E         [24]  613 	lcall	_ak820_outline_0052
      009E79 12 BC E0         [24]  614 	lcall	__gptrget
      009E7C 60 03            [24]  615 	jz	00164$
      009E7E 02 9F 74         [24]  616 	ljmp	00119$
      009E81                        617 00164$:
                                    618 ;	quantum/process_keycode/process_rgb.c:93: uint8_t shifted = get_mods() & MOD_MASK_SHIFT;
      009E81 12 81 A6         [24]  619 	lcall	_get_mods
      009E84 E5 82            [12]  620 	mov	a, dpl
      009E86 54 22            [12]  621 	anl	a,#0x22
      009E88 FF               [12]  622 	mov	r7,a
                                    623 ;	quantum/process_keycode/process_rgb.c:96: if (keycode >= RGB_MODE_FORWARD && keycode <= RGB_SPD) {
      009E89 90 0B DF         [24]  624 	mov	dptr,#_process_rgb_keycode_10000_275
      009E8C 12 38 EC         [24]  625 	lcall	_ak820_outline_0089
      009E8F 8D 03            [24]  626 	mov	ar3,r5
      009E91 8E 04            [24]  627 	mov	ar4,r6
      009E93 C3               [12]  628 	clr	c
      009E94 EB               [12]  629 	mov	a,r3
      009E95 94 21            [12]  630 	subb	a,#0x21
      009E97 EC               [12]  631 	mov	a,r4
      009E98 94 78            [12]  632 	subb	a,#0x78
      009E9A 40 41            [24]  633 	jc	00104$
      009E9C 74 2A            [12]  634 	mov	a,#0x2a
      009E9E 9B               [12]  635 	subb	a,r3
      009E9F 74 78            [12]  636 	mov	a,#0x78
      009EA1 9C               [12]  637 	subb	a,r4
      009EA2 40 39            [24]  638 	jc	00104$
                                    639 ;	free result
                                    640 ;	quantum/process_keycode/process_rgb.c:97: uint8_t action = (uint8_t)(keycode - RGB_MODE_FORWARD);
      009EA4 ED               [12]  641 	mov	a,r5
      009EA5 24 DF            [12]  642 	add	a,#0xdf
      009EA7 FD               [12]  643 	mov	r5,a
      009EA8 90 0B E1         [24]  644 	mov	dptr,#_process_rgb_action_50000_280
      009EAB F0               [24]  645 	movx	@dptr,a
                                    646 ;	quantum/process_keycode/process_rgb.c:98: if (shifted) action ^= 1;
      009EAC EF               [12]  647 	mov	a,r7
      009EAD 60 07            [24]  648 	jz	00102$
      009EAF 90 0B E1         [24]  649 	mov	dptr,#_process_rgb_action_50000_280
      009EB2 74 01            [12]  650 	mov	a,#0x01
      009EB4 6D               [12]  651 	xrl	a,r5
      009EB5 F0               [24]  652 	movx	@dptr,a
      009EB6                        653 00102$:
                                    654 ;	quantum/process_keycode/process_rgb.c:99: ak820_rgb_actions[action]();
      009EB6 90 0B E1         [24]  655 	mov	dptr,#_process_rgb_action_50000_280
      009EB9 E0               [24]  656 	movx	a,@dptr
      009EBA 75 F0 02         [24]  657 	mov	b,#0x02
      009EBD A4               [48]  658 	mul	ab
      009EBE 24 96            [12]  659 	add	a, #_ak820_rgb_actions
      009EC0 F5 82            [12]  660 	mov	dpl,a
      009EC2 74 C0            [12]  661 	mov	a,#(_ak820_rgb_actions >> 8)
      009EC4 35 F0            [12]  662 	addc	a, b
      009EC6 F5 83            [12]  663 	mov	dph,a
      009EC8 12 57 A9         [24]  664 	lcall	_ak820_outline_0046
      009ECB C0 07            [24]  665 	push	ar7
      009ECD C0 06            [24]  666 	push	ar6
      009ECF 12 39 08         [24]  667 	lcall	_ak820_outline_0123
      009ED2 12 30 75         [24]  668 	lcall	__sdcc_call_dptr
      009ED5 D0 06            [24]  669 	pop	ar6
      009ED7 D0 07            [24]  670 	pop	ar7
                                    671 ;	quantum/process_keycode/process_rgb.c:100: return false;
      009ED9 75 82 00         [24]  672 	mov	dpl, #0x00
      009EDC 22               [24]  673 	ret
      009EDD                        674 00104$:
                                    675 ;	quantum/process_keycode/process_rgb.c:103: switch (keycode) {
      009EDD 90 0B DF         [24]  676 	mov	dptr,#_process_rgb_keycode_10000_275
      009EE0 12 38 C3         [24]  677 	lcall	_ak820_outline_0060
      009EE3 C3               [12]  678 	clr	c
      009EE4 EE               [12]  679 	mov	a,r6
      009EE5 94 20            [12]  680 	subb	a,#0x20
      009EE7 EF               [12]  681 	mov	a,r7
      009EE8 94 78            [12]  682 	subb	a,#0x78
      009EEA 50 03            [24]  683 	jnc	00168$
      009EEC 02 9F 74         [24]  684 	ljmp	00119$
      009EEF                        685 00168$:
      009EEF C3               [12]  686 	clr	c
      009EF0 74 34            [12]  687 	mov	a,#0x34
      009EF2 9E               [12]  688 	subb	a,r6
      009EF3 74 78            [12]  689 	mov	a,#0x78
      009EF5 9F               [12]  690 	subb	a,r7
      009EF6 40 7C            [24]  691 	jc	00119$
                                    692 ;	free result
      009EF8 EE               [12]  693 	mov	a,r6
      009EF9 24 E0            [12]  694 	add	a,#0xe0
      009EFB FE               [12]  695 	mov	r6,a
      009EFC 24 0A            [12]  696 	add	a,#(00170$-3-.)
      009EFE 83               [24]  697 	movc	a,@a+pc
      009EFF F5 82            [12]  698 	mov	dpl,a
      009F01 EE               [12]  699 	mov	a,r6
      009F02 24 19            [12]  700 	add	a,#(00171$-3-.)
      009F04 83               [24]  701 	movc	a,@a+pc
      009F05 F5 83            [12]  702 	mov	dph,a
      009F07 E4               [12]  703 	clr	a
      009F08 73               [24]  704 	jmp	@a+dptr
      009F09                        705 00170$:
      009F09 33                     706 	.db	00106$
      009F0A 74                     707 	.db	00119$
      009F0B 74                     708 	.db	00119$
      009F0C 74                     709 	.db	00119$
      009F0D 74                     710 	.db	00119$
      009F0E 74                     711 	.db	00119$
      009F0F 74                     712 	.db	00119$
      009F10 74                     713 	.db	00119$
      009F11 74                     714 	.db	00119$
      009F12 74                     715 	.db	00119$
      009F13 74                     716 	.db	00119$
      009F14 3A                     717 	.db	00107$
      009F15 44                     718 	.db	00108$
      009F16 4E                     719 	.db	00109$
      009F17 58                     720 	.db	00110$
      009F18 5C                     721 	.db	00111$
      009F19 60                     722 	.db	00112$
      009F1A 64                     723 	.db	00113$
      009F1B 68                     724 	.db	00114$
      009F1C 6C                     725 	.db	00115$
      009F1D 70                     726 	.db	00116$
      009F1E                        727 00171$:
      009F1E 9F                     728 	.db	00106$>>8
      009F1F 9F                     729 	.db	00119$>>8
      009F20 9F                     730 	.db	00119$>>8
      009F21 9F                     731 	.db	00119$>>8
      009F22 9F                     732 	.db	00119$>>8
      009F23 9F                     733 	.db	00119$>>8
      009F24 9F                     734 	.db	00119$>>8
      009F25 9F                     735 	.db	00119$>>8
      009F26 9F                     736 	.db	00119$>>8
      009F27 9F                     737 	.db	00119$>>8
      009F28 9F                     738 	.db	00119$>>8
      009F29 9F                     739 	.db	00107$>>8
      009F2A 9F                     740 	.db	00108$>>8
      009F2B 9F                     741 	.db	00109$>>8
      009F2C 9F                     742 	.db	00110$>>8
      009F2D 9F                     743 	.db	00111$>>8
      009F2E 9F                     744 	.db	00112$>>8
      009F2F 9F                     745 	.db	00113$>>8
      009F30 9F                     746 	.db	00114$>>8
      009F31 9F                     747 	.db	00115$>>8
      009F32 9F                     748 	.db	00116$>>8
                                    749 ;	quantum/process_keycode/process_rgb.c:104: case RGB_TOG:
      009F33                        750 00106$:
                                    751 ;	quantum/process_keycode/process_rgb.c:109: rgb_matrix_toggle();
      009F33 12 57 50         [24]  752 	lcall	_rgb_matrix_toggle
                                    753 ;	quantum/process_keycode/process_rgb.c:111: return false;
      009F36 75 82 00         [24]  754 	mov	dpl, #0x00
                                    755 ;	quantum/process_keycode/process_rgb.c:194: case RGB_MODE_PLAIN:
      009F39 22               [24]  756 	ret
      009F3A                        757 00107$:
                                    758 ;	quantum/process_keycode/process_rgb.c:199: rgb_matrix_mode(RGB_MATRIX_SOLID_COLOR);
      009F3A 75 82 01         [24]  759 	mov	dpl, #0x01
      009F3D 12 57 92         [24]  760 	lcall	_rgb_matrix_mode
                                    761 ;	quantum/process_keycode/process_rgb.c:201: return false;
      009F40 75 82 00         [24]  762 	mov	dpl, #0x00
                                    763 ;	quantum/process_keycode/process_rgb.c:202: case RGB_MODE_BREATHE:
      009F43 22               [24]  764 	ret
      009F44                        765 00108$:
                                    766 ;	quantum/process_keycode/process_rgb.c:207: rgb_matrix_mode(RGB_MATRIX_BREATHING);
      009F44 75 82 02         [24]  767 	mov	dpl, #0x02
      009F47 12 57 92         [24]  768 	lcall	_rgb_matrix_mode
                                    769 ;	quantum/process_keycode/process_rgb.c:209: return false;
      009F4A 75 82 00         [24]  770 	mov	dpl, #0x00
                                    771 ;	quantum/process_keycode/process_rgb.c:210: case RGB_MODE_RAINBOW:
      009F4D 22               [24]  772 	ret
      009F4E                        773 00109$:
                                    774 ;	quantum/process_keycode/process_rgb.c:215: rgb_matrix_mode(RGB_MATRIX_CYCLE_LEFT_RIGHT);
      009F4E 75 82 04         [24]  775 	mov	dpl, #0x04
      009F51 12 57 92         [24]  776 	lcall	_rgb_matrix_mode
                                    777 ;	quantum/process_keycode/process_rgb.c:217: return false;
      009F54 75 82 00         [24]  778 	mov	dpl, #0x00
                                    779 ;	quantum/process_keycode/process_rgb.c:218: case RGB_MODE_SWIRL:
      009F57 22               [24]  780 	ret
      009F58                        781 00110$:
                                    782 ;	quantum/process_keycode/process_rgb.c:225: return false;
      009F58 75 82 00         [24]  783 	mov	dpl, #0x00
                                    784 ;	quantum/process_keycode/process_rgb.c:226: case RGB_MODE_SNAKE:
      009F5B 22               [24]  785 	ret
      009F5C                        786 00111$:
                                    787 ;	quantum/process_keycode/process_rgb.c:230: return false;
      009F5C 75 82 00         [24]  788 	mov	dpl, #0x00
                                    789 ;	quantum/process_keycode/process_rgb.c:231: case RGB_MODE_KNIGHT:
      009F5F 22               [24]  790 	ret
      009F60                        791 00112$:
                                    792 ;	quantum/process_keycode/process_rgb.c:235: return false;
      009F60 75 82 00         [24]  793 	mov	dpl, #0x00
                                    794 ;	quantum/process_keycode/process_rgb.c:236: case RGB_MODE_XMAS:
      009F63 22               [24]  795 	ret
      009F64                        796 00113$:
                                    797 ;	quantum/process_keycode/process_rgb.c:240: return false;
      009F64 75 82 00         [24]  798 	mov	dpl, #0x00
                                    799 ;	quantum/process_keycode/process_rgb.c:241: case RGB_MODE_GRADIENT:
      009F67 22               [24]  800 	ret
      009F68                        801 00114$:
                                    802 ;	quantum/process_keycode/process_rgb.c:245: return false;
      009F68 75 82 00         [24]  803 	mov	dpl, #0x00
                                    804 ;	quantum/process_keycode/process_rgb.c:246: case RGB_MODE_RGBTEST:
      009F6B 22               [24]  805 	ret
      009F6C                        806 00115$:
                                    807 ;	quantum/process_keycode/process_rgb.c:250: return false;
      009F6C 75 82 00         [24]  808 	mov	dpl, #0x00
                                    809 ;	quantum/process_keycode/process_rgb.c:251: case RGB_MODE_TWINKLE:
      009F6F 22               [24]  810 	ret
      009F70                        811 00116$:
                                    812 ;	quantum/process_keycode/process_rgb.c:255: return false;
      009F70 75 82 00         [24]  813 	mov	dpl, #0x00
                                    814 ;	quantum/process_keycode/process_rgb.c:256: }
      009F73 22               [24]  815 	ret
      009F74                        816 00119$:
                                    817 ;	quantum/process_keycode/process_rgb.c:259: return true;
      009F74 75 82 01         [24]  818 	mov	dpl, #0x01
                                    819 ;	quantum/process_keycode/process_rgb.c:260: }
      009F77 22               [24]  820 	ret
                                    821 	.area CSEG    (CODE)
                                    822 	.area CONST   (CODE)
                                    823 	.area CONST   (CODE)
      00C096                        824 _ak820_rgb_actions:
      00C096 56 57                  825 	.byte _rgb_matrix_step, (_rgb_matrix_step >> 8)
      00C098 5C 57                  826 	.byte _rgb_matrix_step_reverse, (_rgb_matrix_step_reverse >> 8)
      00C09A 62 57                  827 	.byte _rgb_matrix_increase_hue, (_rgb_matrix_increase_hue >> 8)
      00C09C 68 57                  828 	.byte _rgb_matrix_decrease_hue, (_rgb_matrix_decrease_hue >> 8)
      00C09E 6E 57                  829 	.byte _rgb_matrix_increase_sat, (_rgb_matrix_increase_sat >> 8)
      00C0A0 74 57                  830 	.byte _rgb_matrix_decrease_sat, (_rgb_matrix_decrease_sat >> 8)
      00C0A2 7A 57                  831 	.byte _rgb_matrix_increase_val, (_rgb_matrix_increase_val >> 8)
      00C0A4 80 57                  832 	.byte _rgb_matrix_decrease_val, (_rgb_matrix_decrease_val >> 8)
      00C0A6 86 57                  833 	.byte _rgb_matrix_increase_speed, (_rgb_matrix_increase_speed >> 8)
      00C0A8 8C 57                  834 	.byte _rgb_matrix_decrease_speed, (_rgb_matrix_decrease_speed >> 8)
                                    835 	.area CSEG    (CODE)
                                    836 	.area XINIT   (CODE)
                                    837 	.area CABS    (ABS,CODE)
                                    838 
                                    839 ; Experimental exact instruction outlining.
                                    840 	.globl _ak820_outline_0014
                                    841 	.globl _ak820_outline_0046
                                    842 	.globl _ak820_outline_0052
                                    843 	.globl _ak820_outline_0060
                                    844 	.globl _ak820_outline_0089
                                    845 	.globl _ak820_outline_0121
                                    846 	.globl _ak820_outline_0122
                                    847 	.globl _ak820_outline_0123
                                    848 	.globl _ak820_outline_0143
