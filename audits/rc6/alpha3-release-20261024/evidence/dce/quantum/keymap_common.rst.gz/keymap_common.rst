                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keymap_common
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _KEYCODE2CONSUMER
                                     12 	.globl _keycode_at_encodermap_location
                                     13 	.globl _keycode_at_keymap_location
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _keymap_key_to_keycode_PARM_2
                                    258 	.globl _action_for_key_PARM_2
                                    259 	.globl _action_for_key
                                    260 	.globl _action_for_keycode
                                    261 	.globl _keymap_key_to_keycode
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
                                    540 ;--------------------------------------------------------
                                    541 ; paged external ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area PSEG    (PAG,XDATA)
                                    544 ;--------------------------------------------------------
                                    545 ; uninitialized external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area XSEG    (XDATA)
      000B9D                        548 _action_for_key_PARM_2:
      000B9D                        549 	.ds 2
      000B9F                        550 _action_for_key_layer_10000_304:
      000B9F                        551 	.ds 1
      000BA0                        552 _action_for_keycode_keycode_10000_306:
      000BA0                        553 	.ds 2
      000BA2                        554 _action_for_keycode_kind_10000_307:
      000BA2                        555 	.ds 1
      000BA3                        556 _action_for_keycode_mods_10000_307:
      000BA3                        557 	.ds 1
      000BA4                        558 _action_for_keycode___400000077_40000_309:
      000BA4                        559 	.ds 2
      000BA6                        560 _action_for_keycode_key_60000_324:
      000BA6                        561 	.ds 1
      000BA7                        562 _keymap_key_to_keycode_PARM_2:
      000BA7                        563 	.ds 2
      000BA9                        564 _keymap_key_to_keycode_layer_10000_326:
      000BA9                        565 	.ds 1
                                    566 ;--------------------------------------------------------
                                    567 ; absolute external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area XABS    (ABS,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; initialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XISEG   (XDATA)
                                    574 	.area HOME    (CODE)
                                    575 	.area GSINIT0 (CODE)
                                    576 	.area GSINIT1 (CODE)
                                    577 	.area GSINIT2 (CODE)
                                    578 	.area GSINIT3 (CODE)
                                    579 	.area GSINIT4 (CODE)
                                    580 	.area GSINIT5 (CODE)
                                    581 	.area GSINIT  (CODE)
                                    582 	.area GSFINAL (CODE)
                                    583 	.area CSEG    (CODE)
                                    584 ;--------------------------------------------------------
                                    585 ; global & static initialisations
                                    586 ;--------------------------------------------------------
                                    587 	.area HOME    (CODE)
                                    588 	.area GSINIT  (CODE)
                                    589 	.area GSFINAL (CODE)
                                    590 	.area GSINIT  (CODE)
                                    591 ;--------------------------------------------------------
                                    592 ; Home
                                    593 ;--------------------------------------------------------
                                    594 	.area HOME    (CODE)
                                    595 	.area HOME    (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; code
                                    598 ;--------------------------------------------------------
                                    599 	.area CSEG    (CODE)
                                    600 ;------------------------------------------------------------
                                    601 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    602 ;------------------------------------------------------------
                                    603 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_107'
                                    604 ;------------------------------------------------------------
                                    605 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    606 ;	-----------------------------------------
                           000007   607 	ar7 = 0x07
                           000006   608 	ar6 = 0x06
                           000005   609 	ar5 = 0x05
                           000004   610 	ar4 = 0x04
                           000003   611 	ar3 = 0x03
                           000002   612 	ar2 = 0x02
                           000001   613 	ar1 = 0x01
                           000000   614 	ar0 = 0x00
                                    615 ;	 function action_for_key
                                    616 ;	-----------------------------------------
      0096A1                        617 _action_for_key:
      0096A1 E5 82            [12]  618 	mov	a,dpl
      0096A3 90 0B 9F         [24]  619 	mov	dptr,#_action_for_key_layer_10000_304
      0096A6 F0               [24]  620 	movx	@dptr,a
                                    621 ;	quantum/keymap_common.c:59: uint16_t keycode = keymap_key_to_keycode(layer, key);
      0096A7 E0               [24]  622 	movx	a,@dptr
      0096A8 FF               [12]  623 	mov	r7,a
      0096A9 90 0D C2         [24]  624 	mov	dptr,#___memcpy_PARM_2
      0096AC 74 9D            [12]  625 	mov	a,#_action_for_key_PARM_2
      0096AE F0               [24]  626 	movx	@dptr,a
      0096AF 74 0B            [12]  627 	mov	a,#(_action_for_key_PARM_2 >> 8)
      0096B1 12 38 E0         [24]  628 	lcall	_ak820_outline_0081
      0096B4 90 0D C5         [24]  629 	mov	dptr,#___memcpy_PARM_3
      0096B7 12 4F 8C         [24]  630 	lcall	_ak820_outline_0067
      0096BA 90 0B A7         [24]  631 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      0096BD F5 F0            [12]  632 	mov	b,a
      0096BF C0 07            [24]  633 	push	ar7
      0096C1 12 BC 07         [24]  634 	lcall	___memcpy
      0096C4 D0 07            [24]  635 	pop	ar7
      0096C6 8F 82            [24]  636 	mov	dpl, r7
      0096C8 12 98 36         [24]  637 	lcall	_keymap_key_to_keycode
                                    638 ;	quantum/keymap_common.c:61: return action_for_keycode(keycode);
      0096CB AF 83            [24]  639 	mov  r7,dph
                                    640 ;	quantum/keymap_common.c:62: }
      0096CD 02 96 D0         [24]  641 	ljmp	_action_for_keycode
                                    642 ;------------------------------------------------------------
                                    643 ;Allocation info for local variables in function 'action_for_keycode'
                                    644 ;------------------------------------------------------------
                                    645 ;keycode       Allocated with name '_action_for_keycode_keycode_10000_306'
                                    646 ;kind          Allocated with name '_action_for_keycode_kind_10000_307'
                                    647 ;key           Allocated with name '_action_for_keycode_key_10000_307'
                                    648 ;mods          Allocated with name '_action_for_keycode_mods_10000_307'
                                    649 ;__400000077   Allocated with name '_action_for_keycode___400000077_40000_309'
                                    650 ;__500000078   Allocated with name '_action_for_keycode___500000078_50000_323'
                                    651 ;key           Allocated with name '_action_for_keycode_key_60000_324'
                                    652 ;layer         Allocated with name '_action_for_keycode_layer_30000_318'
                                    653 ;------------------------------------------------------------
                                    654 ;	quantum/keymap_common.c:64: uint16_t action_for_keycode(uint16_t keycode) {
                                    655 ;	-----------------------------------------
                                    656 ;	 function action_for_keycode
                                    657 ;	-----------------------------------------
      0096D0                        658 _action_for_keycode:
      0096D0 12 39 03         [24]  659 	lcall	_ak820_outline_0122
      0096D3 90 0B A0         [24]  660 	mov	dptr,#_action_for_keycode_keycode_10000_306
      0096D6 12 38 FE         [24]  661 	lcall	_ak820_outline_0121
                                    662 ;	quantum/keymap_common.c:87: uint8_t kind = (uint8_t)(keycode >> 8);
      0096D9 90 0B A0         [24]  663 	mov	dptr,#_action_for_keycode_keycode_10000_306
      0096DC 12 38 C3         [24]  664 	lcall	_ak820_outline_0060
                                    665 ;	quantum/keymap_common.c:88: uint8_t key = (uint8_t)keycode;
                                    666 ;	quantum/keymap_common.c:90: if (!kind) {
      0096DF FD               [12]  667 	mov	r5,a
      0096E0 8E 04            [24]  668 	mov	ar4,r6
      0096E2 70 74            [24]  669 	jnz	00117$
                                    670 ;	quantum/keymap_common.c:91: if ((key >= KC_A && key <= KC_EXSEL) ||
      0096E4 BC 04 00         [24]  671 	cjne	r4,#0x04,00251$
      0096E7                        672 00251$:
      0096E7 40 05            [24]  673 	jc	00105$
      0096E9 EC               [12]  674 	mov	a,r4
      0096EA 24 5B            [12]  675 	add	a,#0xff - 0xa4
      0096EC 50 0D            [24]  676 	jnc	00101$
                                    677 ;	free result
      0096EE                        678 00105$:
                                    679 ;	quantum/keymap_common.c:92: (key >= KC_LEFT_CTRL && key <= KC_RIGHT_GUI) || key == KC_TRANSPARENT)
      0096EE BC E0 00         [24]  680 	cjne	r4,#0xe0,00254$
      0096F1                        681 00254$:
      0096F1 40 05            [24]  682 	jc	00106$
      0096F3 EC               [12]  683 	mov	a,r4
      0096F4 24 18            [12]  684 	add	a,#0xff - 0xe7
      0096F6 50 03            [24]  685 	jnc	00101$
                                    686 ;	free result
      0096F8                        687 00106$:
      0096F8 BC 01 08         [24]  688 	cjne	r4,#0x01,00102$
      0096FB                        689 00101$:
                                    690 ;	quantum/keymap_common.c:93: return ACTION_KEY(key);
      0096FB 8C 02            [24]  691 	mov	ar2,r4
      0096FD 7B 00            [12]  692 	mov	r3,#0x00
      0096FF 12 39 12         [24]  693 	lcall	_ak820_outline_0140
      009702 22               [24]  694 	ret
      009703                        695 00102$:
                                    696 ;	quantum/keymap_common.c:95: if (key >= KC_SYSTEM_POWER && key <= KC_SYSTEM_WAKE)
      009703 BC A5 00         [24]  697 	cjne	r4,#0xa5,00259$
      009706                        698 00259$:
      009706 40 1D            [24]  699 	jc	00108$
      009708 EC               [12]  700 	mov	a,r4
      009709 24 58            [12]  701 	add	a,#0xff - 0xa7
      00970B 40 18            [24]  702 	jc	00108$
                                    703 ;	free result
                                    704 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      00970D 8C 03            [24]  705 	mov	ar3,r4
      00970F 74 DC            [12]  706 	mov	a,#0xdc
      009711 2B               [12]  707 	add	a, r3
      009712 90 0B A4         [24]  708 	mov	dptr,#_action_for_keycode___400000077_40000_309
      009715 12 39 0D         [24]  709 	lcall	_ak820_outline_0130
                                    710 ;	quantum/keymap_common.c:96: return ACTION_USAGE_SYSTEM(KEYCODE2SYSTEM(key));
      009718 90 0B A4         [24]  711 	mov	dptr,#_action_for_keycode___400000077_40000_309
      00971B 12 43 B7         [24]  712 	lcall	_ak820_outline_0110
      00971E 43 03 40         [24]  713 	orl	ar3,#0x40
      009721 12 39 12         [24]  714 	lcall	_ak820_outline_0140
      009724 22               [24]  715 	ret
      009725                        716 00108$:
                                    717 ;	quantum/keymap_common.c:97: if (key >= KC_AUDIO_MUTE && key <= KC_LAUNCHPAD)
      009725 BC A8 00         [24]  718 	cjne	r4,#0xa8,00262$
      009728                        719 00262$:
      009728 40 15            [24]  720 	jc	00111$
      00972A EC               [12]  721 	mov	a,r4
      00972B 24 3D            [12]  722 	add	a,#0xff - 0xc2
      00972D 40 10            [24]  723 	jc	00111$
                                    724 ;	free result
                                    725 ;	quantum/keymap_common.c:98: return ACTION_USAGE_CONSUMER(KEYCODE2CONSUMER(key));
      00972F 8C 82            [24]  726 	mov	dpl, r4
      009731 12 6E 65         [24]  727 	lcall	_KEYCODE2CONSUMER
      009734 AA 82            [24]  728 	mov	r2, dpl
      009736 AB 83            [24]  729 	mov	r3, dph
      009738 43 03 44         [24]  730 	orl	ar3,#0x44
      00973B 12 39 12         [24]  731 	lcall	_ak820_outline_0140
      00973E 22               [24]  732 	ret
      00973F                        733 00111$:
                                    734 ;	quantum/keymap_common.c:100: if (key >= KC_MS_UP && key <= KC_MS_ACCEL2) return ACTION_MOUSEKEY(key);
      00973F BC CD 00         [24]  735 	cjne	r4,#0xcd,00265$
      009742                        736 00265$:
      009742 40 10            [24]  737 	jc	00114$
      009744 EC               [12]  738 	mov	a,r4
      009745 24 20            [12]  739 	add	a,#0xff - 0xdf
      009747 40 0B            [24]  740 	jc	00114$
                                    741 ;	free result
      009749 8C 02            [24]  742 	mov	ar2,r4
      00974B 7B 00            [12]  743 	mov	r3,#0x00
      00974D 43 03 50         [24]  744 	orl	ar3,#0x50
      009750 12 39 12         [24]  745 	lcall	_ak820_outline_0140
      009753 22               [24]  746 	ret
      009754                        747 00114$:
                                    748 ;	quantum/keymap_common.c:101: return ACTION_NO;
      009754 90 00 00         [24]  749 	mov	dptr,#0x0000
      009757 22               [24]  750 	ret
      009758                        751 00117$:
                                    752 ;	quantum/keymap_common.c:103: if (kind < 0x20) return keycode; /* Encoded modifier+basic actions. */
      009758 BD 20 00         [24]  753 	cjne	r5,#0x20,00268$
      00975B                        754 00268$:
      00975B 50 04            [24]  755 	jnc	00119$
      00975D 12 39 08         [24]  756 	lcall	_ak820_outline_0123
      009760 22               [24]  757 	ret
      009761                        758 00119$:
                                    759 ;	quantum/keymap_common.c:104: if (kind < 0x50) {
      009761 BD 50 00         [24]  760 	cjne	r5,#0x50,00270$
      009764                        761 00270$:
      009764 50 04            [24]  762 	jnc	00121$
                                    763 ;	quantum/keymap_common.c:108: return ACTION_NO;
      009766 90 00 00         [24]  764 	mov	dptr,#0x0000
      009769 22               [24]  765 	ret
      00976A                        766 00121$:
                                    767 ;	quantum/keymap_common.c:113: if (kind < 0x52) {
      00976A BD 52 00         [24]  768 	cjne	r5,#0x52,00272$
      00976D                        769 00272$:
      00976D 50 39            [24]  770 	jnc	00125$
                                    771 ;	quantum/keymap_common.c:114: uint8_t layer = ((kind & 1u) << 3) | (key >> 5);
      00976F 74 01            [12]  772 	mov	a,#0x01
      009771 5D               [12]  773 	anl	a,r5
      009772 C4               [12]  774 	swap	a
      009773 03               [12]  775 	rr	a
      009774 54 F8            [12]  776 	anl	a,#0xf8
      009776 FF               [12]  777 	mov	r7,a
      009777 EC               [12]  778 	mov	a,r4
      009778 C4               [12]  779 	swap	a
      009779 03               [12]  780 	rr	a
      00977A 54 07            [12]  781 	anl	a,#0x07
      00977C 42 07            [12]  782 	orl	ar7,a
                                    783 ;	quantum/keymap_common.c:115: mods = key & 0x1f;
      00977E 74 1F            [12]  784 	mov	a,#0x1f
      009780 5C               [12]  785 	anl	a,r4
      009781 FE               [12]  786 	mov	r6,a
      009782 90 0B A3         [24]  787 	mov	dptr,#_action_for_keycode_mods_10000_307
      009785 F0               [24]  788 	movx	@dptr,a
                                    789 ;	quantum/keymap_common.c:116: if (mods & 0x10) mods <<= 4; /* Discard the 5-bit right-mod marker. */
      009786 EE               [12]  790 	mov	a,r6
      009787 30 E4 08         [24]  791 	jnb	acc.4,00123$
      00978A EE               [12]  792 	mov	a,r6
      00978B C4               [12]  793 	swap	a
      00978C 54 F0            [12]  794 	anl	a,#0xf0
      00978E 90 0B A3         [24]  795 	mov	dptr,#_action_for_keycode_mods_10000_307
      009791 F0               [24]  796 	movx	@dptr,a
      009792                        797 00123$:
                                    798 ;	quantum/keymap_common.c:117: return ACTION_LAYER_MODS(layer, mods);
      009792 8F 06            [24]  799 	mov	ar6,r7
      009794 7F 00            [12]  800 	mov	r7,#0x00
      009796 90 0B A3         [24]  801 	mov	dptr,#_action_for_keycode_mods_10000_307
      009799 E0               [24]  802 	movx	a,@dptr
      00979A 7B 00            [12]  803 	mov	r3,#0x00
      00979C 42 07            [12]  804 	orl	ar7,a
      00979E EB               [12]  805 	mov	a,r3
      00979F 42 06            [12]  806 	orl	ar6,a
      0097A1 43 06 90         [24]  807 	orl	ar6,#0x90
      0097A4 12 43 E0         [24]  808 	lcall	_ak820_outline_0164
      0097A7 22               [24]  809 	ret
      0097A8                        810 00125$:
                                    811 ;	quantum/keymap_common.c:119: if (kind != 0x52) return ACTION_NO;
      0097A8 BD 52 02         [24]  812 	cjne	r5,#0x52,00275$
      0097AB 80 04            [24]  813 	sjmp	00127$
      0097AD                        814 00275$:
      0097AD 90 00 00         [24]  815 	mov	dptr,#0x0000
      0097B0 22               [24]  816 	ret
      0097B1                        817 00127$:
                                    818 ;	quantum/keymap_common.c:120: mods = key & 0x1f;
      0097B1 74 1F            [12]  819 	mov	a,#0x1f
      0097B3 5C               [12]  820 	anl	a,r4
      0097B4 FF               [12]  821 	mov	r7,a
                                    822 ;	quantum/keymap_common.c:121: switch (key >> 5) {
      0097B5 EC               [12]  823 	mov	a,r4
      0097B6 C4               [12]  824 	swap	a
      0097B7 03               [12]  825 	rr	a
      0097B8 54 07            [12]  826 	anl	a,#0x07
      0097BA FE               [12]  827 	mov  r6,a
      0097BB 24 F9            [12]  828 	add	a,#0xff - 0x06
      0097BD 40 47            [24]  829 	jc	00134$
                                    830 ;	free result
      0097BF EE               [12]  831 	mov	a,r6
      0097C0 2E               [12]  832 	add	a,r6
                                    833 ;	quantum/keymap_common.c:122: case 0: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2) | ON_PRESS; break;
      0097C1 90 97 C5         [24]  834 	mov	dptr,#00277$
      0097C4 73               [24]  835 	jmp	@a+dptr
      0097C5                        836 00277$:
      0097C5 80 0C            [24]  837 	sjmp	00128$
      0097C7 80 12            [24]  838 	sjmp	00129$
      0097C9 80 20            [24]  839 	sjmp	00130$
      0097CB 80 26            [24]  840 	sjmp	00132$
      0097CD 80 37            [24]  841 	sjmp	00134$
      0097CF 80 2A            [24]  842 	sjmp	00133$
      0097D1 80 20            [24]  843 	sjmp	00132$
      0097D3                        844 00128$:
      0097D3 90 0B A2         [24]  845 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097D6 74 8D            [12]  846 	mov	a,#0x8d
      0097D8 F0               [24]  847 	movx	@dptr,a
                                    848 ;	quantum/keymap_common.c:123: case 1: return ACTION_LAYER_MOMENTARY(mods);
      0097D9 80 2F            [24]  849 	sjmp	00135$
      0097DB                        850 00129$:
      0097DB 8F 05            [24]  851 	mov	ar5,r7
      0097DD 8D 06            [24]  852 	mov	ar6,r5
      0097DF 7D 00            [12]  853 	mov	r5,#0x00
      0097E1 43 05 F1         [24]  854 	orl	ar5,#0xf1
      0097E4 43 06 A0         [24]  855 	orl	ar6,#0xa0
      0097E7 12 39 17         [24]  856 	lcall	_ak820_outline_0141
                                    857 ;	quantum/keymap_common.c:124: case 2: kind = (ACT_LAYER << 4) | (OP_BIT_SET << 2); break;
      0097EA 22               [24]  858 	ret
      0097EB                        859 00130$:
      0097EB 90 0B A2         [24]  860 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097EE 74 8C            [12]  861 	mov	a,#0x8c
      0097F0 F0               [24]  862 	movx	@dptr,a
                                    863 ;	quantum/keymap_common.c:126: case 6: kind = (ACT_LAYER << 4) | (OP_BIT_XOR << 2) | ON_RELEASE; break;
      0097F1 80 17            [24]  864 	sjmp	00135$
      0097F3                        865 00132$:
      0097F3 90 0B A2         [24]  866 	mov	dptr,#_action_for_keycode_kind_10000_307
      0097F6 74 8A            [12]  867 	mov	a,#0x8a
      0097F8 F0               [24]  868 	movx	@dptr,a
                                    869 ;	quantum/keymap_common.c:127: case 5: return ACTION_MODS(mods); /* Existing held-mod fallback for OSM. */
      0097F9 80 0F            [24]  870 	sjmp	00135$
      0097FB                        871 00133$:
      0097FB 53 07 1F         [24]  872 	anl	ar7,#0x1f
      0097FE 8F 06            [24]  873 	mov	ar6,r7
      009800 7F 00            [12]  874 	mov	r7,#0x00
      009802 12 43 E0         [24]  875 	lcall	_ak820_outline_0164
                                    876 ;	quantum/keymap_common.c:128: default: return ACTION_NO;
      009805 22               [24]  877 	ret
      009806                        878 00134$:
      009806 90 00 00         [24]  879 	mov	dptr,#0x0000
                                    880 ;	quantum/keymap_common.c:129: }
      009809 22               [24]  881 	ret
      00980A                        882 00135$:
                                    883 ;	quantum/keymap_common.c:131: key = ((key & 0x1c) << 3) | (1u << (key & 3));
      00980A 8C 07            [24]  884 	mov	ar7,r4
      00980C 53 07 1C         [24]  885 	anl	ar7,#0x1c
      00980F EF               [12]  886 	mov	a,r7
      009810 C4               [12]  887 	swap	a
      009811 03               [12]  888 	rr	a
      009812 54 F8            [12]  889 	anl	a,#0xf8
      009814 FF               [12]  890 	mov	r7,a
      009815 74 03            [12]  891 	mov	a,#0x03
      009817 5C               [12]  892 	anl	a,r4
      009818 12 77 DE         [24]  893 	lcall	_ak820_outline_0071
      00981B 80 02            [24]  894 	sjmp	00279$
      00981D                        895 00278$:
      00981D 25 E0            [12]  896 	add	a,acc
      00981F                        897 00279$:
      00981F D5 F0 FB         [24]  898 	djnz	b,00278$
      009822 42 07            [12]  899 	orl	ar7,a
                                    900 ;	quantum/keymap_common.c:132: return ((uint16_t)kind << 8) | key;
      009824 90 0B A2         [24]  901 	mov	dptr,#_action_for_keycode_kind_10000_307
      009827 E0               [24]  902 	movx	a,@dptr
      009828 FE               [12]  903 	mov	r6,a
      009829 E4               [12]  904 	clr	a
      00982A FD               [12]  905 	mov	r5,a
      00982B FC               [12]  906 	mov	r4,a
      00982C EF               [12]  907 	mov	a,r7
      00982D 42 05            [12]  908 	orl	ar5,a
      00982F EC               [12]  909 	mov	a,r4
      009830 42 06            [12]  910 	orl	ar6,a
      009832 12 39 17         [24]  911 	lcall	_ak820_outline_0141
                                    912 ;	quantum/keymap_common.c:277: }
      009835 22               [24]  913 	ret
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'keymap_key_to_keycode'
                                    916 ;------------------------------------------------------------
                                    917 ;key           Allocated with name '_keymap_key_to_keycode_PARM_2'
                                    918 ;layer         Allocated with name '_keymap_key_to_keycode_layer_10000_326'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/keymap_common.c:280: __attribute__((weak)) uint16_t keymap_key_to_keycode(uint8_t layer, keypos_t key) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function keymap_key_to_keycode
                                    923 ;	-----------------------------------------
      009836                        924 _keymap_key_to_keycode:
      009836 E5 82            [12]  925 	mov	a,dpl
      009838 90 0B A9         [24]  926 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      00983B F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/keymap_common.c:285: if (vial_unlock_in_progress) {
      00983C 90 0E 43         [24]  929 	mov	dptr,#_vial_unlock_in_progress
      00983F E0               [24]  930 	movx	a,@dptr
      009840 60 04            [24]  931 	jz	00102$
                                    932 ;	quantum/keymap_common.c:286: return KC_NO;
      009842 90 00 00         [24]  933 	mov	dptr,#0x0000
      009845 22               [24]  934 	ret
      009846                        935 00102$:
                                    936 ;	quantum/keymap_common.c:288: if (key.row == VIAL_MATRIX_MAGIC && key.col == VIAL_MATRIX_MAGIC) {
      009846 90 0B A8         [24]  937 	mov	dptr,#(_keymap_key_to_keycode_PARM_2 + 0x0001)
      009849 E0               [24]  938 	movx	a,@dptr
      00984A FF               [12]  939 	mov	r7,a
      00984B BF F0 12         [24]  940 	cjne	r7,#0xf0,00104$
      00984E 90 0B A7         [24]  941 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      009851 E0               [24]  942 	movx	a,@dptr
      009852 FE               [12]  943 	mov	r6,a
      009853 BE F0 0A         [24]  944 	cjne	r6,#0xf0,00104$
                                    945 ;	quantum/keymap_common.c:289: return g_vial_magic_keycode_override;
      009856 90 0C 9A         [24]  946 	mov	dptr,#_g_vial_magic_keycode_override
      009859 12 38 EC         [24]  947 	lcall	_ak820_outline_0089
      00985C 12 39 17         [24]  948 	lcall	_ak820_outline_0141
      00985F 22               [24]  949 	ret
      009860                        950 00104$:
                                    951 ;	quantum/keymap_common.c:292: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) {
      009860 BF 10 00         [24]  952 	cjne	r7,#0x10,00187$
      009863                        953 00187$:
      009863 50 1E            [24]  954 	jnc	00114$
      009865 90 0B A7         [24]  955 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      009868 E0               [24]  956 	movx	a,@dptr
      009869 FE               [12]  957 	mov	r6,a
      00986A BE 08 00         [24]  958 	cjne	r6,#0x08,00189$
      00986D                        959 00189$:
      00986D 50 14            [24]  960 	jnc	00114$
                                    961 ;	quantum/keymap_common.c:294: return keycode_at_keymap_location(layer, key.row, key.col);
      00986F 90 0B A9         [24]  962 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      009872 E0               [24]  963 	movx	a,@dptr
      009873 FD               [12]  964 	mov	r5,a
      009874 90 0B 20         [24]  965 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009877 EF               [12]  966 	mov	a,r7
      009878 F0               [24]  967 	movx	@dptr,a
      009879 90 0B 21         [24]  968 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00987C EE               [12]  969 	mov	a,r6
      00987D F0               [24]  970 	movx	@dptr,a
      00987E 8D 82            [24]  971 	mov	dpl, r5
      009880 02 8B 80         [24]  972 	ljmp	_keycode_at_keymap_location
      009883                        973 00114$:
                                    974 ;	quantum/keymap_common.c:297: else if (key.row == KEYLOC_ENCODER_CW && key.col < NUM_ENCODERS) {
      009883 BF FD 19         [24]  975 	cjne	r7,#0xfd,00110$
      009886 90 0B A7         [24]  976 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      009889 E0               [24]  977 	movx	a,@dptr
      00988A FE               [12]  978 	mov	r6,a
      00988B BE 01 00         [24]  979 	cjne	r6,#0x01,00193$
      00988E                        980 00193$:
      00988E 50 0F            [24]  981 	jnc	00110$
                                    982 ;	quantum/keymap_common.c:298: return keycode_at_encodermap_location(layer, key.col, true);
      009890 90 0B A9         [24]  983 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      009893 E0               [24]  984 	movx	a,@dptr
      009894 FE               [12]  985 	mov	r6,a
      009895 12 98 BE         [24]  986 	lcall	_ak820_outline_0185
      009898 04               [12]  987 	inc	a
      009899 F0               [24]  988 	movx	@dptr,a
      00989A 8E 82            [24]  989 	mov	dpl, r6
      00989C 02 8B B4         [24]  990 	ljmp	_keycode_at_encodermap_location
      00989F                        991 00110$:
                                    992 ;	quantum/keymap_common.c:299: } else if (key.row == KEYLOC_ENCODER_CCW && key.col < NUM_ENCODERS) {
      00989F BF FC 18         [24]  993 	cjne	r7,#0xfc,00115$
      0098A2 90 0B A7         [24]  994 	mov	dptr,#_keymap_key_to_keycode_PARM_2
      0098A5 E0               [24]  995 	movx	a,@dptr
      0098A6 FF               [12]  996 	mov	r7,a
      0098A7 BF 01 00         [24]  997 	cjne	r7,#0x01,00197$
      0098AA                        998 00197$:
      0098AA 50 0E            [24]  999 	jnc	00115$
                                   1000 ;	quantum/keymap_common.c:300: return keycode_at_encodermap_location(layer, key.col, false);
      0098AC 90 0B A9         [24] 1001 	mov	dptr,#_keymap_key_to_keycode_layer_10000_326
      0098AF E0               [24] 1002 	movx	a,@dptr
      0098B0 FF               [12] 1003 	mov	r7,a
      0098B1 12 98 BE         [24] 1004 	lcall	_ak820_outline_0185
      0098B4 F0               [24] 1005 	movx	@dptr,a
      0098B5 8F 82            [24] 1006 	mov	dpl, r7
      0098B7 02 8B B4         [24] 1007 	ljmp	_keycode_at_encodermap_location
      0098BA                       1008 00115$:
                                   1009 ;	quantum/keymap_common.c:303: return KC_NO;
      0098BA 90 00 00         [24] 1010 	mov	dptr,#0x0000
                                   1011 ;	quantum/keymap_common.c:304: }
      0098BD 22               [24] 1012 	ret
                                   1013 	.area CSEG    (CODE)
                                   1014 	.area CONST   (CODE)
                                   1015 	.area XINIT   (CODE)
                                   1016 	.area CABS    (ABS,CODE)
                                   1017 
                                   1018 ; Experimental exact instruction outlining.
                                   1019 	.globl _ak820_outline_0060
                                   1020 	.globl _ak820_outline_0067
                                   1021 	.globl _ak820_outline_0071
                                   1022 	.globl _ak820_outline_0081
                                   1023 	.globl _ak820_outline_0089
                                   1024 	.globl _ak820_outline_0110
                                   1025 	.globl _ak820_outline_0121
                                   1026 	.globl _ak820_outline_0122
                                   1027 	.globl _ak820_outline_0123
                                   1028 	.globl _ak820_outline_0130
                                   1029 	.globl _ak820_outline_0140
                                   1030 	.globl _ak820_outline_0141
                                   1031 	.globl _ak820_outline_0164
                                   1032 	.globl _ak820_outline_0185
                                   1033 
                                   1034 	.area CSEG (CODE)
                                   1035 ; function ak820_outline_0185
      0098BE                       1036 _ak820_outline_0185:
      0098BE 90 0B 23         [24] 1037 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0098C1 E4               [12] 1038 	clr	a
      0098C2 F0               [24] 1039 	movx	@dptr,a
      0098C3 90 0B 24         [24] 1040 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0098C6 22               [24] 1041 	ret
