                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoder
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _encoder_wait_pullup_charge
                                     12 	.globl _tap_code_delay
                                     13 	.globl _action_exec
                                     14 	.globl _is_keyboard_master
                                     15 	.globl _timer_read
                                     16 	.globl _mDelayuS
                                     17 	.globl _readPin
                                     18 	.globl _pinModeInputHighQMK
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _encoder_init
                                    263 	.globl _encoder_read
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000B50                        550 _thisCount:
      000B50                        551 	.ds 1
      000B51                        552 _encoder_exec_mapping_PARM_2:
      000B51                        553 	.ds 1
      000B52                        554 _encoder_exec_mapping_index_10000_165:
      000B52                        555 	.ds 1
      000B53                        556 _encoder_exec_mapping_dummy_event_30000_168:
      000B53                        557 	.ds 6
      000B59                        558 _encoder_exec_mapping_dummy_event_30000_169:
      000B59                        559 	.ds 6
      000B5F                        560 _encoder_exec_mapping_dummy_event_30000_171:
      000B5F                        561 	.ds 6
      000B65                        562 _encoder_exec_mapping_dummy_event_30000_172:
      000B65                        563 	.ds 6
      000B6B                        564 _encoder_update_PARM_2:
      000B6B                        565 	.ds 1
      000B6C                        566 _encoder_update_index_10000_173:
      000B6C                        567 	.ds 1
      000B6D                        568 _encoder_update_changed_10000_174:
      000B6D                        569 	.ds 1
      000B6E                        570 _encoder_read_changed_10000_180:
      000B6E                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000E0B                        580 _encoders_pad_a:
      000E0B                        581 	.ds 1
      000E0C                        582 _encoders_pad_b:
      000E0C                        583 	.ds 1
      000E0D                        584 _encoder_LUT:
      000E0D                        585 	.ds 16
      000E1D                        586 _encoder_state:
      000E1D                        587 	.ds 1
      000E1E                        588 _encoder_pulses:
      000E1E                        589 	.ds 1
      000E1F                        590 _encoder_value:
      000E1F                        591 	.ds 1
                                    592 	.area HOME    (CODE)
                                    593 	.area GSINIT0 (CODE)
                                    594 	.area GSINIT1 (CODE)
                                    595 	.area GSINIT2 (CODE)
                                    596 	.area GSINIT3 (CODE)
                                    597 	.area GSINIT4 (CODE)
                                    598 	.area GSINIT5 (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area CSEG    (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; global & static initialisations
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area GSINIT  (CODE)
                                    607 	.area GSFINAL (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 ;--------------------------------------------------------
                                    610 ; Home
                                    611 ;--------------------------------------------------------
                                    612 	.area HOME    (CODE)
                                    613 	.area HOME    (CODE)
                                    614 ;--------------------------------------------------------
                                    615 ; code
                                    616 ;--------------------------------------------------------
                                    617 	.area CSEG    (CODE)
                                    618 ;------------------------------------------------------------
                                    619 ;Allocation info for local variables in function 'encoder_wait_pullup_charge'
                                    620 ;------------------------------------------------------------
                                    621 ;i             Allocated with name '_encoder_wait_pullup_charge_i_30000_146'
                                    622 ;------------------------------------------------------------
                                    623 ;	quantum/encoder.c:77: __attribute__((weak)) void encoder_wait_pullup_charge(void) {
                                    624 ;	-----------------------------------------
                                    625 ;	 function encoder_wait_pullup_charge
                                    626 ;	-----------------------------------------
      009165                        627 _encoder_wait_pullup_charge:
                           000007   628 	ar7 = 0x07
                           000006   629 	ar6 = 0x06
                           000005   630 	ar5 = 0x05
                           000004   631 	ar4 = 0x04
                           000003   632 	ar3 = 0x03
                           000002   633 	ar2 = 0x02
                           000001   634 	ar1 = 0x01
                           000000   635 	ar0 = 0x00
                                    636 ;	quantum/encoder.c:78: wait_us(100);
      009165 7F 64            [12]  637 	mov	r7,#0x64
      009167                        638 00106$:
      009167 EF               [12]  639 	mov	a,r7
      009168 60 0D            [24]  640 	jz	00108$
      00916A 90 00 01         [24]  641 	mov	dptr,#0x0001
      00916D C0 07            [24]  642 	push	ar7
      00916F 12 59 5A         [24]  643 	lcall	_mDelayuS
      009172 D0 07            [24]  644 	pop	ar7
      009174 1F               [12]  645 	dec	r7
      009175 80 F0            [24]  646 	sjmp	00106$
      009177                        647 00108$:
                                    648 ;	quantum/encoder.c:79: }
      009177 22               [24]  649 	ret
                                    650 ;------------------------------------------------------------
                                    651 ;Allocation info for local variables in function 'encoder_update_user'
                                    652 ;------------------------------------------------------------
                                    653 ;clockwise     Allocated with name '_encoder_update_user_PARM_2'
                                    654 ;index         Allocated with name '_encoder_update_user_index_10000_148'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/encoder.c:81: __attribute__((weak)) bool encoder_update_user(uint8_t index, bool clockwise) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function encoder_init
                                    659 ;	-----------------------------------------
      009178                        660 _encoder_init:
                                    661 ;	quantum/encoder.c:122: thisCount                = NUM_ENCODERS;
      009178 90 0B 50         [24]  662 	mov	dptr,#_thisCount
      00917B 74 01            [12]  663 	mov	a,#0x01
      00917D F0               [24]  664 	movx	@dptr,a
                                    665 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      00917E 7F 00            [12]  666 	mov	r7,#0x00
      009180                        667 00104$:
      009180 12 94 14         [24]  668 	lcall	_ak820_outline_0097
      009183 50 17            [24]  669 	jnc	00101$
                                    670 ;	quantum/encoder.c:166: setPinInputHigh(encoders_pad_a[i]);
      009185 12 93 E8         [24]  671 	lcall	_ak820_outline_0029
      009188 C0 07            [24]  672 	push	ar7
      00918A 12 58 1C         [24]  673 	lcall	_pinModeInputHighQMK
      00918D D0 07            [24]  674 	pop	ar7
                                    675 ;	quantum/encoder.c:167: setPinInputHigh(encoders_pad_b[i]);
      00918F 12 93 F6         [24]  676 	lcall	_ak820_outline_0030
      009192 C0 07            [24]  677 	push	ar7
      009194 12 58 1C         [24]  678 	lcall	_pinModeInputHighQMK
      009197 D0 07            [24]  679 	pop	ar7
                                    680 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      009199 0F               [12]  681 	inc	r7
      00919A 80 E4            [24]  682 	sjmp	00104$
      00919C                        683 00101$:
                                    684 ;	quantum/encoder.c:169: encoder_wait_pullup_charge();
      00919C 12 91 65         [24]  685 	lcall	_encoder_wait_pullup_charge
                                    686 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      00919F 7F 00            [12]  687 	mov	r7,#0x00
      0091A1                        688 00107$:
      0091A1 12 94 14         [24]  689 	lcall	_ak820_outline_0097
      0091A4 50 22            [24]  690 	jnc	00109$
                                    691 ;	quantum/encoder.c:171: encoder_state[i] = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      0091A6 EF               [12]  692 	mov	a,r7
      0091A7 24 1D            [12]  693 	add	a, #_encoder_state
      0091A9 FD               [12]  694 	mov	r5,a
      0091AA E4               [12]  695 	clr	a
      0091AB 34 0E            [12]  696 	addc	a, #(_encoder_state >> 8)
      0091AD FE               [12]  697 	mov	r6,a
      0091AE 12 93 E8         [24]  698 	lcall	_ak820_outline_0029
      0091B1 12 58 68         [24]  699 	lcall	_readPin
      0091B4 AC 82            [24]  700 	mov	r4, dpl
      0091B6 12 93 F6         [24]  701 	lcall	_ak820_outline_0030
      0091B9 12 58 68         [24]  702 	lcall	_readPin
      0091BC E5 82            [12]  703 	mov	a,dpl
      0091BE 25 82            [12]  704 	add	a,dpl
      0091C0 42 04            [12]  705 	orl	ar4,a
      0091C2 12 43 A4         [24]  706 	lcall	_ak820_outline_0074
                                    707 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      0091C5 0F               [12]  708 	inc	r7
      0091C6 80 D9            [24]  709 	sjmp	00107$
      0091C8                        710 00109$:
                                    711 ;	quantum/encoder.c:173: }
      0091C8 22               [24]  712 	ret
                                    713 ;------------------------------------------------------------
                                    714 ;Allocation info for local variables in function 'encoder_exec_mapping'
                                    715 ;------------------------------------------------------------
                                    716 ;clockwise     Allocated with name '_encoder_exec_mapping_PARM_2'
                                    717 ;index         Allocated with name '_encoder_exec_mapping_index_10000_165'
                                    718 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_168'
                                    719 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_169'
                                    720 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_171'
                                    721 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_172'
                                    722 ;------------------------------------------------------------
                                    723 ;	quantum/encoder.c:176: static void encoder_exec_mapping(uint8_t index, bool clockwise) {
                                    724 ;	-----------------------------------------
                                    725 ;	 function encoder_exec_mapping
                                    726 ;	-----------------------------------------
      0091C9                        727 _encoder_exec_mapping:
      0091C9 E5 82            [12]  728 	mov	a,dpl
      0091CB 90 0B 52         [24]  729 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      0091CE F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/encoder.c:179: if (clockwise) {
      0091CF 90 0B 51         [24]  732 	mov	dptr,#_encoder_exec_mapping_PARM_2
      0091D2 E0               [24]  733 	movx	a,@dptr
      0091D3 FF               [12]  734 	mov	r7,a
      0091D4 E0               [24]  735 	movx	a,@dptr
      0091D5 60 3D            [24]  736 	jz	00102$
                                    737 ;	quantum/encoder.c:180: MAKE_ENCODER_CW_EVENT(index, true);
      0091D7 90 0B 52         [24]  738 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      0091DA E0               [24]  739 	movx	a,@dptr
      0091DB 90 0B 53         [24]  740 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_168
      0091DE F0               [24]  741 	movx	@dptr,a
      0091DF 90 0B 54         [24]  742 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0001)
      0091E2 74 FD            [12]  743 	mov	a,#0xfd
      0091E4 F0               [24]  744 	movx	@dptr,a
      0091E5 12 49 A8         [24]  745 	lcall	_timer_read
      0091E8 AD 82            [24]  746 	mov	r5, dpl
      0091EA AE 83            [24]  747 	mov	r6, dph
      0091EC 90 0B 55         [24]  748 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0002)
      0091EF 12 43 C9         [24]  749 	lcall	_ak820_outline_0126
      0091F2 90 0B 57         [24]  750 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0004)
      0091F5 74 02            [12]  751 	mov	a,#0x02
      0091F7 F0               [24]  752 	movx	@dptr,a
      0091F8 90 0B 58         [24]  753 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_168 + 0x0005)
      0091FB 14               [12]  754 	dec	a
      0091FC F0               [24]  755 	movx	@dptr,a
                                    756 ;	quantum/encoder.c:181: action_exec(dummy_event);
      0091FD 90 0D C2         [24]  757 	mov	dptr,#___memcpy_PARM_2
      009200 74 53            [12]  758 	mov	a,#_encoder_exec_mapping_dummy_event_30000_168
      009202 F0               [24]  759 	movx	@dptr,a
      009203 74 0B            [12]  760 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_168 >> 8)
      009205 12 93 D4         [24]  761 	lcall	_ak820_outline_0005
      009208 C0 07            [24]  762 	push	ar7
      00920A 12 BC 07         [24]  763 	lcall	___memcpy
      00920D 12 71 15         [24]  764 	lcall	_action_exec
      009210 D0 07            [24]  765 	pop	ar7
      009212 80 3C            [24]  766 	sjmp	00103$
      009214                        767 00102$:
                                    768 ;	quantum/encoder.c:183: MAKE_ENCODER_CCW_EVENT(index, true);
      009214 90 0B 52         [24]  769 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      009217 E0               [24]  770 	movx	a,@dptr
      009218 90 0B 59         [24]  771 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_169
      00921B F0               [24]  772 	movx	@dptr,a
      00921C 90 0B 5A         [24]  773 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0001)
      00921F 74 FC            [12]  774 	mov	a,#0xfc
      009221 F0               [24]  775 	movx	@dptr,a
      009222 12 49 A8         [24]  776 	lcall	_timer_read
      009225 AD 82            [24]  777 	mov	r5, dpl
      009227 AE 83            [24]  778 	mov	r6, dph
      009229 90 0B 5B         [24]  779 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0002)
      00922C 12 43 C9         [24]  780 	lcall	_ak820_outline_0126
      00922F 90 0B 5D         [24]  781 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0004)
      009232 74 03            [12]  782 	mov	a,#0x03
      009234 F0               [24]  783 	movx	@dptr,a
      009235 90 0B 5E         [24]  784 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0005)
      009238 74 01            [12]  785 	mov	a,#0x01
      00923A F0               [24]  786 	movx	@dptr,a
                                    787 ;	quantum/encoder.c:184: action_exec(dummy_event);
      00923B 90 0D C2         [24]  788 	mov	dptr,#___memcpy_PARM_2
      00923E 74 59            [12]  789 	mov	a,#_encoder_exec_mapping_dummy_event_30000_169
      009240 F0               [24]  790 	movx	@dptr,a
      009241 74 0B            [12]  791 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_169 >> 8)
      009243 12 93 D4         [24]  792 	lcall	_ak820_outline_0005
      009246 C0 07            [24]  793 	push	ar7
      009248 12 BC 07         [24]  794 	lcall	___memcpy
      00924B 12 71 15         [24]  795 	lcall	_action_exec
      00924E D0 07            [24]  796 	pop	ar7
      009250                        797 00103$:
                                    798 ;	quantum/encoder.c:191: if (clockwise) {
      009250 EF               [12]  799 	mov	a,r7
      009251 60 36            [24]  800 	jz	00105$
                                    801 ;	quantum/encoder.c:192: MAKE_ENCODER_CW_EVENT(index, false);
      009253 90 0B 52         [24]  802 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      009256 E0               [24]  803 	movx	a,@dptr
      009257 90 0B 5F         [24]  804 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_171
      00925A F0               [24]  805 	movx	@dptr,a
      00925B 90 0B 60         [24]  806 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0001)
      00925E 74 FD            [12]  807 	mov	a,#0xfd
      009260 F0               [24]  808 	movx	@dptr,a
      009261 12 49 A8         [24]  809 	lcall	_timer_read
      009264 12 43 D5         [24]  810 	lcall	_ak820_outline_0131
      009267 90 0B 61         [24]  811 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0002)
      00926A 12 48 F9         [24]  812 	lcall	_ak820_outline_0068
      00926D 90 0B 63         [24]  813 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0004)
      009270 74 02            [12]  814 	mov	a,#0x02
      009272 F0               [24]  815 	movx	@dptr,a
      009273 90 0B 64         [24]  816 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_171 + 0x0005)
      009276 E4               [12]  817 	clr	a
      009277 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/encoder.c:193: action_exec(dummy_event);
      009278 90 0D C2         [24]  820 	mov	dptr,#___memcpy_PARM_2
      00927B 74 5F            [12]  821 	mov	a,#_encoder_exec_mapping_dummy_event_30000_171
      00927D F0               [24]  822 	movx	@dptr,a
      00927E 74 0B            [12]  823 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_171 >> 8)
      009280 12 93 D4         [24]  824 	lcall	_ak820_outline_0005
      009283 12 BC 07         [24]  825 	lcall	___memcpy
      009286 02 71 15         [24]  826 	ljmp	_action_exec
      009289                        827 00105$:
                                    828 ;	quantum/encoder.c:195: MAKE_ENCODER_CCW_EVENT(index, false);
      009289 90 0B 52         [24]  829 	mov	dptr,#_encoder_exec_mapping_index_10000_165
      00928C E0               [24]  830 	movx	a,@dptr
      00928D 90 0B 65         [24]  831 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_172
      009290 F0               [24]  832 	movx	@dptr,a
      009291 90 0B 66         [24]  833 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0001)
      009294 74 FC            [12]  834 	mov	a,#0xfc
      009296 F0               [24]  835 	movx	@dptr,a
      009297 12 49 A8         [24]  836 	lcall	_timer_read
      00929A 12 43 D5         [24]  837 	lcall	_ak820_outline_0131
      00929D 90 0B 67         [24]  838 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0002)
      0092A0 12 48 F9         [24]  839 	lcall	_ak820_outline_0068
      0092A3 90 0B 69         [24]  840 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0004)
      0092A6 74 03            [12]  841 	mov	a,#0x03
      0092A8 F0               [24]  842 	movx	@dptr,a
      0092A9 90 0B 6A         [24]  843 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0005)
      0092AC E4               [12]  844 	clr	a
      0092AD F0               [24]  845 	movx	@dptr,a
                                    846 ;	quantum/encoder.c:196: action_exec(dummy_event);
      0092AE 90 0D C2         [24]  847 	mov	dptr,#___memcpy_PARM_2
      0092B1 74 65            [12]  848 	mov	a,#_encoder_exec_mapping_dummy_event_30000_172
      0092B3 F0               [24]  849 	movx	@dptr,a
      0092B4 74 0B            [12]  850 	mov	a,#(_encoder_exec_mapping_dummy_event_30000_172 >> 8)
      0092B6 12 93 D4         [24]  851 	lcall	_ak820_outline_0005
      0092B9 12 BC 07         [24]  852 	lcall	___memcpy
                                    853 ;	quantum/encoder.c:201: }
      0092BC 02 71 15         [24]  854 	ljmp	_action_exec
                                    855 ;------------------------------------------------------------
                                    856 ;Allocation info for local variables in function 'encoder_update'
                                    857 ;------------------------------------------------------------
                                    858 ;state         Allocated with name '_encoder_update_PARM_2'
                                    859 ;index         Allocated with name '_encoder_update_index_10000_173'
                                    860 ;changed       Allocated with name '_encoder_update_changed_10000_174'
                                    861 ;i             Allocated with name '_encoder_update_i_10000_174'
                                    862 ;resolution    Allocated with name '_encoder_update_resolution_10000_174'
                                    863 ;------------------------------------------------------------
                                    864 ;	quantum/encoder.c:204: static bool encoder_update(uint8_t index, uint8_t state) {
                                    865 ;	-----------------------------------------
                                    866 ;	 function encoder_update
                                    867 ;	-----------------------------------------
      0092BF                        868 _encoder_update:
      0092BF E5 82            [12]  869 	mov	a,dpl
      0092C1 90 0B 6C         [24]  870 	mov	dptr,#_encoder_update_index_10000_173
      0092C4 F0               [24]  871 	movx	@dptr,a
                                    872 ;	quantum/encoder.c:205: bool    changed = false;
      0092C5 90 0B 6D         [24]  873 	mov	dptr,#_encoder_update_changed_10000_174
      0092C8 E4               [12]  874 	clr	a
      0092C9 F0               [24]  875 	movx	@dptr,a
                                    876 ;	quantum/encoder.c:206: uint8_t i       = index;
      0092CA 90 0B 6C         [24]  877 	mov	dptr,#_encoder_update_index_10000_173
      0092CD E0               [24]  878 	movx	a,@dptr
                                    879 ;	quantum/encoder.c:217: encoder_pulses[i] += encoder_LUT[state & 0xF];
      0092CE FF               [12]  880 	mov	r7,a
      0092CF 24 1E            [12]  881 	add	a, #_encoder_pulses
      0092D1 FD               [12]  882 	mov	r5,a
      0092D2 E4               [12]  883 	clr	a
      0092D3 34 0E            [12]  884 	addc	a, #(_encoder_pulses >> 8)
      0092D5 FE               [12]  885 	mov	r6,a
      0092D6 12 49 0D         [24]  886 	lcall	_ak820_outline_0085
      0092D9 90 0B 6B         [24]  887 	mov	dptr,#_encoder_update_PARM_2
      0092DC E0               [24]  888 	movx	a,@dptr
      0092DD FB               [12]  889 	mov	r3,a
      0092DE 74 0F            [12]  890 	mov	a,#0x0f
      0092E0 5B               [12]  891 	anl	a,r3
      0092E1 24 0D            [12]  892 	add	a, #_encoder_LUT
      0092E3 F5 82            [12]  893 	mov	dpl,a
      0092E5 E4               [12]  894 	clr	a
      0092E6 34 0E            [12]  895 	addc	a,#(_encoder_LUT >> 8)
      0092E8 F5 83            [12]  896 	mov	dph,a
      0092EA E0               [24]  897 	movx	a,@dptr
      0092EB 2C               [12]  898 	add	a, r4
      0092EC FC               [12]  899 	mov	r4,a
      0092ED 12 82 2E         [24]  900 	lcall	_ak820_outline_0128
                                    901 ;	quantum/encoder.c:223: if (encoder_pulses[i] >= resolution) {
      0092F0 EC               [12]  902 	mov	a,r4
      0092F1 33               [12]  903 	rlc	a
      0092F2 95 E0            [12]  904 	subb	a,acc
      0092F4 FB               [12]  905 	mov	r3,a
      0092F5 C3               [12]  906 	clr	c
      0092F6 EC               [12]  907 	mov	a,r4
      0092F7 94 02            [12]  908 	subb	a,#0x02
      0092F9 EB               [12]  909 	mov	a,r3
      0092FA 64 80            [12]  910 	xrl	a,#0x80
      0092FC 94 80            [12]  911 	subb	a,#0x80
      0092FE 40 1D            [24]  912 	jc	00102$
                                    913 ;	quantum/encoder.c:226: encoder_value[index]++;
      009300 EF               [12]  914 	mov	a,r7
      009301 24 1F            [12]  915 	add	a, #_encoder_value
      009303 FB               [12]  916 	mov	r3,a
      009304 E4               [12]  917 	clr	a
      009305 34 0E            [12]  918 	addc	a, #(_encoder_value >> 8)
      009307 12 48 F1         [24]  919 	lcall	_ak820_outline_0063
      00930A 0A               [12]  920 	inc	r2
      00930B 12 94 04         [24]  921 	lcall	_ak820_outline_0070
                                    922 ;	quantum/encoder.c:227: changed = true;
                                    923 ;	quantum/encoder.c:232: encoder_exec_mapping(index, ENCODER_COUNTER_CLOCKWISE);
      00930E E4               [12]  924 	clr	a
      00930F F0               [24]  925 	movx	@dptr,a
      009310 8F 82            [24]  926 	mov	dpl, r7
      009312 C0 06            [24]  927 	push	ar6
      009314 C0 05            [24]  928 	push	ar5
      009316 12 91 C9         [24]  929 	lcall	_encoder_exec_mapping
      009319 D0 05            [24]  930 	pop	ar5
      00931B D0 06            [24]  931 	pop	ar6
      00931D                        932 00102$:
                                    933 ;	quantum/encoder.c:241: if (encoder_pulses[i] <= -resolution) { // direction is arbitrary here, but this clockwise
      00931D 12 39 17         [24]  934 	lcall	_ak820_outline_0141
      009320 E0               [24]  935 	movx	a,@dptr
      009321 FF               [12]  936 	mov	r7,a
      009322 33               [12]  937 	rlc	a
      009323 95 E0            [12]  938 	subb	a,acc
      009325 FC               [12]  939 	mov	r4,a
      009326 C3               [12]  940 	clr	c
      009327 74 FE            [12]  941 	mov	a,#0xfe
      009329 9F               [12]  942 	subb	a,r7
      00932A 74 7F            [12]  943 	mov	a,#(0xff ^ 0x80)
      00932C 8C F0            [24]  944 	mov	b,r4
      00932E 63 F0 80         [24]  945 	xrl	b,#0x80
      009331 95 F0            [12]  946 	subb	a,b
      009333 40 20            [24]  947 	jc	00104$
                                    948 ;	free result
                                    949 ;	quantum/encoder.c:243: encoder_value[index]--;
      009335 90 0B 6C         [24]  950 	mov	dptr,#_encoder_update_index_10000_173
      009338 E0               [24]  951 	movx	a,@dptr
      009339 FF               [12]  952 	mov	r7,a
      00933A 24 1F            [12]  953 	add	a, #_encoder_value
      00933C FB               [12]  954 	mov	r3,a
      00933D E4               [12]  955 	clr	a
      00933E 34 0E            [12]  956 	addc	a, #(_encoder_value >> 8)
      009340 12 48 F1         [24]  957 	lcall	_ak820_outline_0063
      009343 1A               [12]  958 	dec	r2
      009344 12 94 04         [24]  959 	lcall	_ak820_outline_0070
                                    960 ;	quantum/encoder.c:244: changed = true;
                                    961 ;	quantum/encoder.c:249: encoder_exec_mapping(index, ENCODER_CLOCKWISE);
      009347 F0               [24]  962 	movx	@dptr,a
      009348 8F 82            [24]  963 	mov	dpl, r7
      00934A C0 06            [24]  964 	push	ar6
      00934C C0 05            [24]  965 	push	ar5
      00934E 12 91 C9         [24]  966 	lcall	_encoder_exec_mapping
      009351 D0 05            [24]  967 	pop	ar5
      009353 D0 06            [24]  968 	pop	ar6
      009355                        969 00104$:
                                    970 ;	quantum/encoder.c:254: encoder_pulses[i] %= resolution;
      009355 12 39 17         [24]  971 	lcall	_ak820_outline_0141
      009358 E0               [24]  972 	movx	a,@dptr
      009359 A2 E7            [12]  973 	mov	c,acc.7
      00935B 54 01            [12]  974 	anl	a,#0x01
      00935D 60 04            [24]  975 	jz	00123$
      00935F 50 02            [24]  976 	jnc	00123$
      009361 44 FE            [12]  977 	orl	a,#0xfe
      009363                        978 00123$:
      009363 12 82 2E         [24]  979 	lcall	_ak820_outline_0128
                                    980 ;	quantum/encoder.c:259: return changed;
      009366 90 0B 6D         [24]  981 	mov	dptr,#_encoder_update_changed_10000_174
      009369 E0               [24]  982 	movx	a,@dptr
                                    983 ;	quantum/encoder.c:260: }
      00936A F5 82            [12]  984 	mov	dpl,a
      00936C 22               [24]  985 	ret
                                    986 ;------------------------------------------------------------
                                    987 ;Allocation info for local variables in function 'encoder_read'
                                    988 ;------------------------------------------------------------
                                    989 ;changed       Allocated with name '_encoder_read_changed_10000_180'
                                    990 ;i             Allocated with name '_encoder_read_i_20000_181'
                                    991 ;new_status    Allocated with name '_encoder_read_new_status_30000_182'
                                    992 ;------------------------------------------------------------
                                    993 ;	quantum/encoder.c:262: bool encoder_read(void) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function encoder_read
                                    996 ;	-----------------------------------------
      00936D                        997 _encoder_read:
                                    998 ;	quantum/encoder.c:263: bool changed = false;
      00936D 90 0B 6E         [24]  999 	mov	dptr,#_encoder_read_changed_10000_180
      009370 E4               [12] 1000 	clr	a
      009371 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      009372 FF               [12] 1003 	mov	r7,a
      009373                       1004 00105$:
      009373 12 94 14         [24] 1005 	lcall	_ak820_outline_0097
      009376 50 55            [24] 1006 	jnc	00103$
                                   1007 ;	quantum/encoder.c:265: uint8_t new_status = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009378 12 93 E8         [24] 1008 	lcall	_ak820_outline_0029
      00937B 12 58 68         [24] 1009 	lcall	_readPin
      00937E AE 82            [24] 1010 	mov	r6, dpl
      009380 12 93 F6         [24] 1011 	lcall	_ak820_outline_0030
      009383 12 58 68         [24] 1012 	lcall	_readPin
      009386 E5 82            [12] 1013 	mov	a,dpl
      009388 25 82            [12] 1014 	add	a,dpl
      00938A 42 06            [12] 1015 	orl	ar6,a
                                   1016 ;	quantum/encoder.c:266: if ((encoder_state[i] & 0x3) != new_status) {
      00938C EF               [12] 1017 	mov	a,r7
      00938D 24 1D            [12] 1018 	add	a, #_encoder_state
      00938F FC               [12] 1019 	mov	r4,a
      009390 E4               [12] 1020 	clr	a
      009391 34 0E            [12] 1021 	addc	a, #(_encoder_state >> 8)
      009393 FD               [12] 1022 	mov	r5,a
      009394 12 43 B1         [24] 1023 	lcall	_ak820_outline_0104
      009397 FB               [12] 1024 	mov	r3,a
      009398 FA               [12] 1025 	mov	r2,a
      009399 53 02 03         [24] 1026 	anl	ar2,#0x03
      00939C 8E 01            [24] 1027 	mov	ar1,r6
      00939E EA               [12] 1028 	mov	a,r2
      00939F B5 01 02         [24] 1029 	cjne	a,ar1,00132$
      0093A2 80 26            [24] 1030 	sjmp	00106$
      0093A4                       1031 00132$:
                                   1032 ;	quantum/encoder.c:267: encoder_state[i] <<= 2;
      0093A4 EB               [12] 1033 	mov	a,r3
      0093A5 2B               [12] 1034 	add	a,r3
      0093A6 25 E0            [12] 1035 	add	a,acc
      0093A8 FB               [12] 1036 	mov	r3,a
      0093A9 12 43 CF         [24] 1037 	lcall	_ak820_outline_0127
                                   1038 ;	quantum/encoder.c:268: encoder_state[i] |= new_status;
      0093AC EB               [12] 1039 	mov	a,r3
      0093AD 42 06            [12] 1040 	orl	ar6,a
      0093AF 12 34 76         [24] 1041 	lcall	_ak820_outline_0132
      0093B2 EE               [12] 1042 	mov	a,r6
      0093B3 F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	quantum/encoder.c:269: changed |= encoder_update(i, encoder_state[i]);
      0093B4 90 0B 6B         [24] 1045 	mov	dptr,#_encoder_update_PARM_2
      0093B7 EE               [12] 1046 	mov	a,r6
      0093B8 F0               [24] 1047 	movx	@dptr,a
      0093B9 8F 82            [24] 1048 	mov	dpl, r7
      0093BB C0 07            [24] 1049 	push	ar7
      0093BD 12 92 BF         [24] 1050 	lcall	_encoder_update
      0093C0 AE 82            [24] 1051 	mov	r6, dpl
      0093C2 D0 07            [24] 1052 	pop	ar7
      0093C4 90 0B 6E         [24] 1053 	mov	dptr,#_encoder_read_changed_10000_180
      0093C7 E0               [24] 1054 	movx	a,@dptr
      0093C8 4E               [12] 1055 	orl	a,r6
      0093C9 F0               [24] 1056 	movx	@dptr,a
      0093CA                       1057 00106$:
                                   1058 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      0093CA 0F               [12] 1059 	inc	r7
      0093CB 80 A6            [24] 1060 	sjmp	00105$
      0093CD                       1061 00103$:
                                   1062 ;	quantum/encoder.c:272: return changed;
      0093CD 90 0B 6E         [24] 1063 	mov	dptr,#_encoder_read_changed_10000_180
      0093D0 E0               [24] 1064 	movx	a,@dptr
                                   1065 ;	quantum/encoder.c:273: }
      0093D1 F5 82            [12] 1066 	mov	dpl,a
      0093D3 22               [24] 1067 	ret
                                   1068 	.area CSEG    (CODE)
                                   1069 	.area CONST   (CODE)
                                   1070 	.area XINIT   (CODE)
      00C505                       1071 __xinit__encoders_pad_a:
      00C505 39                    1072 	.db #0x39	; 57	'9'
      00C506                       1073 __xinit__encoders_pad_b:
      00C506 38                    1074 	.db #0x38	; 56	'8'
      00C507                       1075 __xinit__encoder_LUT:
      00C507 00                    1076 	.db #0x00	;  0
      00C508 FF                    1077 	.db #0xff	; -1
      00C509 01                    1078 	.db #0x01	;  1
      00C50A 00                    1079 	.db #0x00	;  0
      00C50B 01                    1080 	.db #0x01	;  1
      00C50C 00                    1081 	.db #0x00	;  0
      00C50D 00                    1082 	.db #0x00	;  0
      00C50E FF                    1083 	.db #0xff	; -1
      00C50F FF                    1084 	.db #0xff	; -1
      00C510 00                    1085 	.db #0x00	;  0
      00C511 00                    1086 	.db #0x00	;  0
      00C512 01                    1087 	.db #0x01	;  1
      00C513 00                    1088 	.db #0x00	;  0
      00C514 01                    1089 	.db #0x01	;  1
      00C515 FF                    1090 	.db #0xff	; -1
      00C516 00                    1091 	.db #0x00	;  0
      00C517                       1092 __xinit__encoder_state:
      00C517 00                    1093 	.db #0x00	; 0
      00C518                       1094 __xinit__encoder_pulses:
      00C518 00                    1095 	.db #0x00	;  0
      00C519                       1096 __xinit__encoder_value:
      00C519 00                    1097 	.db #0x00	; 0
                                   1098 	.area CABS    (ABS,CODE)
                                   1099 
                                   1100 ; Experimental exact instruction outlining.
                                   1101 	.globl _ak820_outline_0005
                                   1102 	.globl _ak820_outline_0029
                                   1103 	.globl _ak820_outline_0030
                                   1104 	.globl _ak820_outline_0063
                                   1105 	.globl _ak820_outline_0068
                                   1106 	.globl _ak820_outline_0070
                                   1107 	.globl _ak820_outline_0074
                                   1108 	.globl _ak820_outline_0085
                                   1109 	.globl _ak820_outline_0097
                                   1110 	.globl _ak820_outline_0104
                                   1111 	.globl _ak820_outline_0126
                                   1112 	.globl _ak820_outline_0127
                                   1113 	.globl _ak820_outline_0128
                                   1114 	.globl _ak820_outline_0131
                                   1115 	.globl _ak820_outline_0132
                                   1116 	.globl _ak820_outline_0141
                                   1117 
                                   1118 	.area CSEG (CODE)
                                   1119 ; function ak820_outline_0005
      0093D4                       1120 _ak820_outline_0005:
      0093D4 A3               [24] 1121 	inc	dptr
      0093D5 F0               [24] 1122 	movx	@dptr,a
      0093D6 E4               [12] 1123 	clr	a
      0093D7 A3               [24] 1124 	inc	dptr
      0093D8 F0               [24] 1125 	movx	@dptr,a
      0093D9 90 0D C5         [24] 1126 	mov	dptr,#___memcpy_PARM_3
      0093DC 74 06            [12] 1127 	mov	a,#0x06
      0093DE F0               [24] 1128 	movx	@dptr,a
      0093DF E4               [12] 1129 	clr	a
      0093E0 A3               [24] 1130 	inc	dptr
      0093E1 F0               [24] 1131 	movx	@dptr,a
      0093E2 90 08 10         [24] 1132 	mov	dptr,#_action_exec_PARM_1
      0093E5 F5 F0            [12] 1133 	mov	b,a
      0093E7 22               [24] 1134 	ret
                                   1135 
                                   1136 	.area CSEG (CODE)
                                   1137 ; function ak820_outline_0029
      0093E8                       1138 _ak820_outline_0029:
      0093E8 EF               [12] 1139 	mov	a,r7
      0093E9 24 0B            [12] 1140 	add	a,#_encoders_pad_a
      0093EB F5 82            [12] 1141 	mov	dpl,a
      0093ED E4               [12] 1142 	clr	a
      0093EE 34 0E            [12] 1143 	addc	a,#(_encoders_pad_a>>8)
      0093F0 F5 83            [12] 1144 	mov	dph,a
      0093F2 E0               [24] 1145 	movx	a,@dptr
      0093F3 F5 82            [12] 1146 	mov	dpl,a
      0093F5 22               [24] 1147 	ret
                                   1148 
                                   1149 	.area CSEG (CODE)
                                   1150 ; function ak820_outline_0030
      0093F6                       1151 _ak820_outline_0030:
      0093F6 EF               [12] 1152 	mov	a,r7
      0093F7 24 0C            [12] 1153 	add	a,#_encoders_pad_b
      0093F9 F5 82            [12] 1154 	mov	dpl,a
      0093FB E4               [12] 1155 	clr	a
      0093FC 34 0E            [12] 1156 	addc	a,#(_encoders_pad_b>>8)
      0093FE F5 83            [12] 1157 	mov	dph,a
      009400 E0               [24] 1158 	movx	a,@dptr
      009401 F5 82            [12] 1159 	mov	dpl,a
      009403 22               [24] 1160 	ret
                                   1161 
                                   1162 	.area CSEG (CODE)
                                   1163 ; function ak820_outline_0070
      009404                       1164 _ak820_outline_0070:
      009404 8B 82            [24] 1165 	mov	dpl,r3
      009406 8C 83            [24] 1166 	mov	dph,r4
      009408 EA               [12] 1167 	mov	a,r2
      009409 F0               [24] 1168 	movx	@dptr,a
      00940A 90 0B 6D         [24] 1169 	mov	dptr,#_encoder_update_changed_10000_174
      00940D 74 01            [12] 1170 	mov	a,#0x01
      00940F F0               [24] 1171 	movx	@dptr,a
      009410 90 0B 51         [24] 1172 	mov	dptr,#_encoder_exec_mapping_PARM_2
      009413 22               [24] 1173 	ret
                                   1174 
                                   1175 	.area CSEG (CODE)
                                   1176 ; function ak820_outline_0097
      009414                       1177 _ak820_outline_0097:
      009414 90 0B 50         [24] 1178 	mov	dptr,#_thisCount
      009417 E0               [24] 1179 	movx	a,@dptr
      009418 FE               [12] 1180 	mov	r6,a
      009419 C3               [12] 1181 	clr	c
      00941A EF               [12] 1182 	mov	a,r7
      00941B 9E               [12] 1183 	subb	a,r6
      00941C 22               [24] 1184 	ret
