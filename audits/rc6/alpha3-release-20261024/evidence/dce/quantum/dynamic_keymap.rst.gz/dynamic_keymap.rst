                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
      000034                        601 _dynamic_keymap_macro_send_sloc0_1_0:
      000034                        602 	.ds 3
                                    603 ;--------------------------------------------------------
                                    604 ; overlayable items in internal ram
                                    605 ;--------------------------------------------------------
                                    606 ;--------------------------------------------------------
                                    607 ; indirectly addressable internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area ISEG    (DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; absolute internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area IABS    (ABS,DATA)
                                    614 	.area IABS    (ABS,DATA)
                                    615 ;--------------------------------------------------------
                                    616 ; bit data
                                    617 ;--------------------------------------------------------
                                    618 	.area BSEG    (BIT)
      000024                        619 _dynamic_keymap_macro_send_sloc1_1_0:
      000024                        620 	.ds 1
                                    621 ;--------------------------------------------------------
                                    622 ; paged external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area PSEG    (PAG,XDATA)
                                    625 ;--------------------------------------------------------
                                    626 ; uninitialized external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area XSEG    (XDATA)
      000AD1                        629 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD1                        630 	.ds 1
      000AD2                        631 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD2                        632 	.ds 1
      000AD3                        633 _dynamic_keymap_key_to_eeprom_address_layer_10000_363:
      000AD3                        634 	.ds 1
      000AD4                        635 _dynamic_keymap_get_keycode_PARM_2:
      000AD4                        636 	.ds 1
      000AD5                        637 _dynamic_keymap_get_keycode_PARM_3:
      000AD5                        638 	.ds 1
      000AD6                        639 _dynamic_keymap_get_keycode_layer_10000_365:
      000AD6                        640 	.ds 1
      000AD7                        641 _dynamic_keymap_set_keycode_PARM_2:
      000AD7                        642 	.ds 1
      000AD8                        643 _dynamic_keymap_set_keycode_PARM_3:
      000AD8                        644 	.ds 1
      000AD9                        645 _dynamic_keymap_set_keycode_PARM_4:
      000AD9                        646 	.ds 2
      000ADB                        647 _dynamic_keymap_set_keycode_layer_10000_369:
      000ADB                        648 	.ds 1
      000ADC                        649 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000ADC                        650 	.ds 1
      000ADD                        651 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_373:
      000ADD                        652 	.ds 1
      000ADE                        653 _dynamic_keymap_get_encoder_PARM_2:
      000ADE                        654 	.ds 1
      000ADF                        655 _dynamic_keymap_get_encoder_PARM_3:
      000ADF                        656 	.ds 1
      000AE0                        657 _dynamic_keymap_get_encoder_layer_10000_375:
      000AE0                        658 	.ds 1
      000AE1                        659 _dynamic_keymap_set_encoder_PARM_2:
      000AE1                        660 	.ds 1
      000AE2                        661 _dynamic_keymap_set_encoder_PARM_3:
      000AE2                        662 	.ds 1
      000AE3                        663 _dynamic_keymap_set_encoder_PARM_4:
      000AE3                        664 	.ds 2
      000AE5                        665 _dynamic_keymap_set_encoder_layer_10000_379:
      000AE5                        666 	.ds 1
      000AE6                        667 _dynamic_keymap_get_combo_PARM_2:
      000AE6                        668 	.ds 3
      000AE9                        669 _dynamic_keymap_get_combo_index_10000_383:
      000AE9                        670 	.ds 1
      000AEA                        671 _dynamic_keymap_set_combo_PARM_2:
      000AEA                        672 	.ds 3
      000AED                        673 _dynamic_keymap_set_combo_index_10000_389:
      000AED                        674 	.ds 1
      000AEE                        675 _dynamic_keymap_set_combo_stored_10002_394:
      000AEE                        676 	.ds 10
      000AF8                        677 _dynamic_keymap_reset_vial_unlocked_prev_10000_397:
      000AF8                        678 	.ds 1
      000AF9                        679 _dynamic_keymap_reset_combo_10001_406:
      000AF9                        680 	.ds 10
      000B03                        681 _ak820_dynamic_read_buffer_PARM_2:
      000B03                        682 	.ds 2
      000B05                        683 _ak820_dynamic_read_buffer_PARM_3:
      000B05                        684 	.ds 2
      000B07                        685 _ak820_dynamic_read_buffer_PARM_4:
      000B07                        686 	.ds 2
      000B09                        687 _ak820_dynamic_read_buffer_PARM_5:
      000B09                        688 	.ds 3
      000B0C                        689 _ak820_dynamic_read_buffer_base_10000_408:
      000B0C                        690 	.ds 2
      000B0E                        691 _ak820_dynamic_read_buffer_available_10000_409:
      000B0E                        692 	.ds 1
      000B0F                        693 _dynamic_keymap_get_buffer_PARM_2:
      000B0F                        694 	.ds 2
      000B11                        695 _dynamic_keymap_get_buffer_PARM_3:
      000B11                        696 	.ds 3
      000B14                        697 _dynamic_keymap_get_buffer_offset_10000_415:
      000B14                        698 	.ds 2
      000B16                        699 _dynamic_keymap_set_buffer_PARM_2:
      000B16                        700 	.ds 2
      000B18                        701 _dynamic_keymap_set_buffer_PARM_3:
      000B18                        702 	.ds 3
      000B1B                        703 _dynamic_keymap_set_buffer_offset_10000_417:
      000B1B                        704 	.ds 2
      000B1D                        705 _dynamic_keymap_set_buffer_chk_offset_30001_424:
      000B1D                        706 	.ds 1
      000B1E                        707 _dynamic_keymap_set_buffer_chk_sz_30001_424:
      000B1E                        708 	.ds 1
      000B1F                        709 _dynamic_keymap_set_buffer_i_40001_431:
      000B1F                        710 	.ds 1
      000B20                        711 _keycode_at_keymap_location_PARM_2:
      000B20                        712 	.ds 1
      000B21                        713 _keycode_at_keymap_location_PARM_3:
      000B21                        714 	.ds 1
      000B22                        715 _keycode_at_keymap_location_layer_num_10000_435:
      000B22                        716 	.ds 1
      000B23                        717 _keycode_at_encodermap_location_PARM_2:
      000B23                        718 	.ds 1
      000B24                        719 _keycode_at_encodermap_location_PARM_3:
      000B24                        720 	.ds 1
      000B25                        721 _keycode_at_encodermap_location_layer_num_10000_439:
      000B25                        722 	.ds 1
      000B26                        723 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B26                        724 	.ds 2
      000B28                        725 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B28                        726 	.ds 3
      000B2B                        727 _dynamic_keymap_macro_get_buffer_offset_10000_447:
      000B2B                        728 	.ds 2
      000B2D                        729 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2D                        730 	.ds 2
      000B2F                        731 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B2F                        732 	.ds 3
      000B32                        733 _dynamic_keymap_macro_set_buffer_offset_10000_449:
      000B32                        734 	.ds 2
      000B34                        735 _decode_keycode_kc_10000_453:
      000B34                        736 	.ds 2
      000B36                        737 _dynamic_keymap_macro_send_id_10000_456:
      000B36                        738 	.ds 1
      000B37                        739 _dynamic_keymap_macro_send_sending_10000_457:
      000B37                        740 	.ds 1
      000B38                        741 _dynamic_keymap_macro_send_p_10001_462:
      000B38                        742 	.ds 3
      000B3B                        743 _dynamic_keymap_macro_send_data_10003_469:
      000B3B                        744 	.ds 4
                                    745 ;--------------------------------------------------------
                                    746 ; absolute external ram data
                                    747 ;--------------------------------------------------------
                                    748 	.area XABS    (ABS,XDATA)
                                    749 ;--------------------------------------------------------
                                    750 ; initialized external ram data
                                    751 ;--------------------------------------------------------
                                    752 	.area XISEG   (XDATA)
                                    753 	.area HOME    (CODE)
                                    754 	.area GSINIT0 (CODE)
                                    755 	.area GSINIT1 (CODE)
                                    756 	.area GSINIT2 (CODE)
                                    757 	.area GSINIT3 (CODE)
                                    758 	.area GSINIT4 (CODE)
                                    759 	.area GSINIT5 (CODE)
                                    760 	.area GSINIT  (CODE)
                                    761 	.area GSFINAL (CODE)
                                    762 	.area CSEG    (CODE)
                                    763 ;--------------------------------------------------------
                                    764 ; global & static initialisations
                                    765 ;--------------------------------------------------------
                                    766 	.area HOME    (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 	.area GSFINAL (CODE)
                                    769 	.area GSINIT  (CODE)
                                    770 ;--------------------------------------------------------
                                    771 ; Home
                                    772 ;--------------------------------------------------------
                                    773 	.area HOME    (CODE)
                                    774 	.area HOME    (CODE)
                                    775 ;--------------------------------------------------------
                                    776 ; code
                                    777 ;--------------------------------------------------------
                                    778 	.area CSEG    (CODE)
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    781 ;------------------------------------------------------------
                                    782 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_229'
                                    783 ;------------------------------------------------------------
                                    784 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    785 ;	-----------------------------------------
                           000007   786 	ar7 = 0x07
                           000006   787 	ar6 = 0x06
                           000005   788 	ar5 = 0x05
                           000004   789 	ar4 = 0x04
                           000003   790 	ar3 = 0x03
                           000002   791 	ar2 = 0x02
                           000001   792 	ar1 = 0x01
                           000000   793 	ar0 = 0x00
                                    794 ;	 function dynamic_keymap_get_layer_count
                                    795 ;	-----------------------------------------
      0084E0                        796 _dynamic_keymap_get_layer_count:
                                    797 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0084E0 75 82 06         [24]  798 	mov	dpl, #0x06
                                    799 ;	quantum/dynamic_keymap.c:179: }
      0084E3 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    803 ;------------------------------------------------------------
                                    804 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    805 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    806 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_363'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function dynamic_keymap_key_to_eeprom_address
                                    811 ;	-----------------------------------------
      0084E4                        812 _dynamic_keymap_key_to_eeprom_address:
      0084E4 E5 82            [12]  813 	mov	a,dpl
      0084E6 90 0A D3         [24]  814 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_363
      0084E9 F0               [24]  815 	movx	@dptr,a
                                    816 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0084EA E0               [24]  817 	movx	a,@dptr
      0084EB FF               [12]  818 	mov	r7,a
      0084EC 7E 00            [12]  819 	mov	r6,#0x00
      0084EE 74 40            [12]  820 	mov	a,#0x40
      0084F0 12 43 DA         [24]  821 	lcall	_ak820_outline_0144
      0084F3 7D 00            [12]  822 	mov	r5,#0x00
      0084F5 90 0A D1         [24]  823 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0084F8 E0               [24]  824 	movx	a,@dptr
      0084F9 75 F0 10         [24]  825 	mov	b,#0x10
      0084FC A4               [48]  826 	mul	ab
      0084FD 2E               [12]  827 	add	a, r6
      0084FE FE               [12]  828 	mov	r6,a
      0084FF EF               [12]  829 	mov	a,r7
      008500 35 F0            [12]  830 	addc	a, b
      008502 FF               [12]  831 	mov	r7,a
      008503 90 0A D2         [24]  832 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008506 E0               [24]  833 	movx	a,@dptr
      008507 7C 00            [12]  834 	mov	r4,#0x00
      008509 25 E0            [12]  835 	add	a,acc
      00850B FB               [12]  836 	mov	r3,a
      00850C EC               [12]  837 	mov	a,r4
      00850D 33               [12]  838 	rlc	a
      00850E FC               [12]  839 	mov	r4,a
      00850F EB               [12]  840 	mov	a,r3
      008510 2E               [12]  841 	add	a, r6
      008511 FE               [12]  842 	mov	r6,a
      008512 EC               [12]  843 	mov	a,r4
      008513 3F               [12]  844 	addc	a, r7
      008514 FF               [12]  845 	mov	r7,a
      008515 12 39 08         [24]  846 	lcall	_ak820_outline_0123
      008518 8D F0            [24]  847 	mov	b, r5
                                    848 ;	quantum/dynamic_keymap.c:184: }
      00851A 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    852 ;------------------------------------------------------------
                                    853 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    854 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    855 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_365'
                                    856 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_368'
                                    857 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_368'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function dynamic_keymap_get_keycode
                                    862 ;	-----------------------------------------
      00851B                        863 _dynamic_keymap_get_keycode:
      00851B E5 82            [12]  864 	mov	a,dpl
      00851D 90 0A D6         [24]  865 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_365
      008520 F0               [24]  866 	movx	@dptr,a
                                    867 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008521 E0               [24]  868 	movx	a,@dptr
      008522 FF               [12]  869 	mov	r7,a
      008523 BF 06 00         [24]  870 	cjne	r7,#0x06,00121$
      008526                        871 00121$:
      008526 50 14            [24]  872 	jnc	00101$
      008528 90 0A D4         [24]  873 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00852B E0               [24]  874 	movx	a,@dptr
      00852C FE               [12]  875 	mov	r6,a
      00852D BE 10 00         [24]  876 	cjne	r6,#0x10,00123$
      008530                        877 00123$:
      008530 50 0A            [24]  878 	jnc	00101$
      008532 90 0A D5         [24]  879 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008535 E0               [24]  880 	movx	a,@dptr
      008536 FD               [12]  881 	mov	r5,a
      008537 BD 08 00         [24]  882 	cjne	r5,#0x08,00125$
      00853A                        883 00125$:
      00853A 40 04            [24]  884 	jc	00102$
      00853C                        885 00101$:
      00853C 90 00 00         [24]  886 	mov	dptr,#0x0000
      00853F 22               [24]  887 	ret
      008540                        888 00102$:
                                    889 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008540 12 8F 63         [24]  890 	lcall	_ak820_outline_0107
      008543 12 84 E4         [24]  891 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    892 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008546 12 8F 77         [24]  893 	lcall	_ak820_outline_0118
      008549 12 40 E1         [24]  894 	lcall	_eeprom_read_byte
      00854C AB 82            [24]  895 	mov	r3,dpl
      00854E 7C 00            [12]  896 	mov	r4,#0x00
                                    897 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008550 0D               [12]  898 	inc	r5
      008551 BD 00 01         [24]  899 	cjne	r5,#0x00,00127$
      008554 0E               [12]  900 	inc	r6
      008555                        901 00127$:
      008555 12 6E 5E         [24]  902 	lcall	_ak820_outline_0052
      008558 12 40 E1         [24]  903 	lcall	_eeprom_read_byte
      00855B AF 82            [24]  904 	mov	r7, dpl
      00855D 7E 00            [12]  905 	mov	r6,#0x00
      00855F EF               [12]  906 	mov	a,r7
      008560 42 04            [12]  907 	orl	ar4,a
      008562 EE               [12]  908 	mov	a,r6
      008563 42 03            [12]  909 	orl	ar3,a
                                    910 ;	quantum/dynamic_keymap.c:192: return keycode;
      008565 12 43 F9         [24]  911 	lcall	_ak820_outline_0197
                                    912 ;	quantum/dynamic_keymap.c:193: }
      008568 22               [24]  913 	ret
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    916 ;------------------------------------------------------------
                                    917 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    918 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    919 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    920 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_369'
                                    921 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_372'
                                    922 ;------------------------------------------------------------
                                    923 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function dynamic_keymap_set_keycode
                                    926 ;	-----------------------------------------
      008569                        927 _dynamic_keymap_set_keycode:
      008569 E5 82            [12]  928 	mov	a,dpl
      00856B 90 0A DB         [24]  929 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_369
      00856E F0               [24]  930 	movx	@dptr,a
                                    931 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00856F E0               [24]  932 	movx	a,@dptr
      008570 FF               [12]  933 	mov	r7,a
      008571 BF 06 00         [24]  934 	cjne	r7,#0x06,00121$
      008574                        935 00121$:
      008574 50 14            [24]  936 	jnc	00101$
      008576 90 0A D7         [24]  937 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008579 E0               [24]  938 	movx	a,@dptr
      00857A FE               [12]  939 	mov	r6,a
      00857B BE 10 00         [24]  940 	cjne	r6,#0x10,00123$
      00857E                        941 00123$:
      00857E 50 0A            [24]  942 	jnc	00101$
      008580 90 0A D8         [24]  943 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008583 E0               [24]  944 	movx	a,@dptr
      008584 FD               [12]  945 	mov	r5,a
      008585 BD 08 00         [24]  946 	cjne	r5,#0x08,00125$
      008588                        947 00125$:
      008588 40 01            [24]  948 	jc	00102$
      00858A                        949 00101$:
      00858A 22               [24]  950 	ret
      00858B                        951 00102$:
                                    952 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00858B 12 8F 63         [24]  953 	lcall	_ak820_outline_0107
      00858E 12 84 E4         [24]  954 	lcall	_dynamic_keymap_key_to_eeprom_address
      008591 12 8F 77         [24]  955 	lcall	_ak820_outline_0118
                                    956 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008594 90 0A D9         [24]  957 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008597 E0               [24]  958 	movx	a,@dptr
      008598 FB               [12]  959 	mov	r3,a
      008599 A3               [24]  960 	inc	dptr
      00859A E0               [24]  961 	movx	a,@dptr
      00859B 90 06 94         [24]  962 	mov	dptr,#_eeprom_update_byte_PARM_2
      00859E 12 4F 6A         [24]  963 	lcall	_ak820_outline_0033
      0085A1 12 4E 54         [24]  964 	lcall	_eeprom_update_byte
                                    965 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0085A4 0D               [12]  966 	inc	r5
      0085A5 BD 00 01         [24]  967 	cjne	r5,#0x00,00127$
      0085A8 0E               [12]  968 	inc	r6
      0085A9                        969 00127$:
      0085A9 90 06 94         [24]  970 	mov	dptr,#_eeprom_update_byte_PARM_2
      0085AC EB               [12]  971 	mov	a,r3
      0085AD 12 4F 6A         [24]  972 	lcall	_ak820_outline_0033
                                    973 ;	quantum/dynamic_keymap.c:201: }
      0085B0 02 4E 54         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_373'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      0085B3                        985 _dynamic_keymap_encoder_to_eeprom_address:
      0085B3 E5 82            [12]  986 	mov	a,dpl
      0085B5 90 0A DD         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_373
      0085B8 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0085B9 E0               [24]  990 	movx	a,@dptr
      0085BA 75 F0 04         [24]  991 	mov	b,#0x04
      0085BD A4               [48]  992 	mul	ab
      0085BE 24 40            [12]  993 	add	a, #0x40
      0085C0 FD               [12]  994 	mov	r5,a
      0085C1 74 06            [12]  995 	mov	a,#0x06
      0085C3 35 F0            [12]  996 	addc	a, b
      0085C5 FE               [12]  997 	mov	r6,a
      0085C6 7F 00            [12]  998 	mov	r7,#0x00
      0085C8 90 0A DC         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0085CB E0               [24] 1000 	movx	a,@dptr
      0085CC 75 F0 04         [24] 1001 	mov	b,#0x04
      0085CF A4               [48] 1002 	mul	ab
      0085D0 2D               [12] 1003 	add	a, r5
      0085D1 FD               [12] 1004 	mov	r5,a
      0085D2 EE               [12] 1005 	mov	a,r6
      0085D3 35 F0            [12] 1006 	addc	a, b
      0085D5 FE               [12] 1007 	mov	r6,a
      0085D6 12 6E 5E         [24] 1008 	lcall	_ak820_outline_0052
                                   1009 ;	quantum/dynamic_keymap.c:206: }
      0085D9 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_375'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_378'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_378'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      0085DA                       1024 _dynamic_keymap_get_encoder:
      0085DA E5 82            [12] 1025 	mov	a,dpl
      0085DC 90 0A E0         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_375
      0085DF F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0085E0 E0               [24] 1029 	movx	a,@dptr
      0085E1 FF               [12] 1030 	mov	r7,a
      0085E2 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      0085E5                       1032 00131$:
      0085E5 50 0A            [24] 1033 	jnc	00101$
      0085E7 90 0A DE         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0085EA E0               [24] 1035 	movx	a,@dptr
      0085EB FE               [12] 1036 	mov	r6,a
      0085EC BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      0085EF                       1038 00133$:
      0085EF 40 04            [24] 1039 	jc	00102$
      0085F1                       1040 00101$:
      0085F1 90 00 00         [24] 1041 	mov	dptr,#0x0000
      0085F4 22               [24] 1042 	ret
      0085F5                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0085F5 90 0A DC         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0085F8 E4               [12] 1046 	clr	a
      0085F9 F0               [24] 1047 	movx	@dptr,a
      0085FA 8F 82            [24] 1048 	mov	dpl, r7
      0085FC 12 85 B3         [24] 1049 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0085FF 12 8F 77         [24] 1050 	lcall	_ak820_outline_0118
                                   1051 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008602 90 0A DF         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008605 E0               [24] 1053 	movx	a,@dptr
      008606 FC               [12] 1054 	mov	r4,a
      008607 E0               [24] 1055 	movx	a,@dptr
      008608 60 04            [24] 1056 	jz	00106$
      00860A 7B 00            [12] 1057 	mov	r3,#0x00
      00860C 80 02            [24] 1058 	sjmp	00107$
      00860E                       1059 00106$:
      00860E 7B 02            [12] 1060 	mov	r3,#0x02
      008610                       1061 00107$:
      008610 EB               [12] 1062 	mov	a,r3
      008611 12 77 A9         [24] 1063 	lcall	_ak820_outline_0015
      008614 12 40 E1         [24] 1064 	lcall	_eeprom_read_byte
      008617 AA 82            [24] 1065 	mov	r2,dpl
      008619 7B 00            [12] 1066 	mov	r3,#0x00
                                   1067 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00861B EC               [12] 1068 	mov	a,r4
      00861C 60 04            [24] 1069 	jz	00108$
      00861E 7C 00            [12] 1070 	mov	r4,#0x00
      008620 80 02            [24] 1071 	sjmp	00109$
      008622                       1072 00108$:
      008622 7C 02            [12] 1073 	mov	r4,#0x02
      008624                       1074 00109$:
      008624 EC               [12] 1075 	mov	a,r4
      008625 12 39 1C         [24] 1076 	lcall	_ak820_outline_0143
      008628 0D               [12] 1077 	inc	r5
      008629 BD 00 01         [24] 1078 	cjne	r5,#0x00,00137$
      00862C 0E               [12] 1079 	inc	r6
      00862D                       1080 00137$:
      00862D 12 6E 5E         [24] 1081 	lcall	_ak820_outline_0052
      008630 12 40 E1         [24] 1082 	lcall	_eeprom_read_byte
      008633 AF 82            [24] 1083 	mov	r7, dpl
      008635 7E 00            [12] 1084 	mov	r6,#0x00
      008637 EF               [12] 1085 	mov	a,r7
      008638 42 03            [12] 1086 	orl	ar3,a
      00863A EE               [12] 1087 	mov	a,r6
      00863B 42 02            [12] 1088 	orl	ar2,a
                                   1089 ;	quantum/dynamic_keymap.c:214: return keycode;
      00863D 8B 82            [24] 1090 	mov	dpl, r3
      00863F 8A 83            [24] 1091 	mov	dph, r2
                                   1092 ;	quantum/dynamic_keymap.c:215: }
      008641 22               [24] 1093 	ret
                                   1094 ;------------------------------------------------------------
                                   1095 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1096 ;------------------------------------------------------------
                                   1097 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1098 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1099 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1100 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1101 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_379'
                                   1102 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_382'
                                   1103 ;------------------------------------------------------------
                                   1104 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1105 ;	-----------------------------------------
                                   1106 ;	 function dynamic_keymap_set_encoder
                                   1107 ;	-----------------------------------------
      008642                       1108 _dynamic_keymap_set_encoder:
      008642 E5 82            [12] 1109 	mov	a,dpl
      008644 90 0A E5         [24] 1110 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_379
      008647 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008648 E0               [24] 1113 	movx	a,@dptr
      008649 FF               [12] 1114 	mov	r7,a
      00864A BF 06 00         [24] 1115 	cjne	r7,#0x06,00131$
      00864D                       1116 00131$:
      00864D 50 0A            [24] 1117 	jnc	00101$
      00864F 90 0A E1         [24] 1118 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008652 E0               [24] 1119 	movx	a,@dptr
      008653 FE               [12] 1120 	mov	r6,a
      008654 BE 01 00         [24] 1121 	cjne	r6,#0x01,00133$
      008657                       1122 00133$:
      008657 40 01            [24] 1123 	jc	00102$
      008659                       1124 00101$:
      008659 22               [24] 1125 	ret
      00865A                       1126 00102$:
                                   1127 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00865A 90 0A DC         [24] 1128 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00865D E4               [12] 1129 	clr	a
      00865E F0               [24] 1130 	movx	@dptr,a
      00865F 8F 82            [24] 1131 	mov	dpl, r7
      008661 12 85 B3         [24] 1132 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008664 12 8F 77         [24] 1133 	lcall	_ak820_outline_0118
                                   1134 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008667 90 0A E2         [24] 1135 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00866A E0               [24] 1136 	movx	a,@dptr
      00866B FC               [12] 1137 	mov	r4,a
      00866C E0               [24] 1138 	movx	a,@dptr
      00866D 60 04            [24] 1139 	jz	00106$
      00866F 7B 00            [12] 1140 	mov	r3,#0x00
      008671 80 02            [24] 1141 	sjmp	00107$
      008673                       1142 00106$:
      008673 7B 02            [12] 1143 	mov	r3,#0x02
      008675                       1144 00107$:
      008675 EB               [12] 1145 	mov	a,r3
      008676 12 8F 89         [24] 1146 	lcall	_ak820_outline_0142
      008679 8F 03            [24] 1147 	mov	ar3,r7
      00867B 90 0A E3         [24] 1148 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00867E E0               [24] 1149 	movx	a,@dptr
      00867F F5 29            [12] 1150 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008681 A3               [24] 1151 	inc	dptr
      008682 E0               [24] 1152 	movx	a,@dptr
      008683 F5 2A            [12] 1153 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008685 90 06 94         [24] 1154 	mov	dptr,#_eeprom_update_byte_PARM_2
      008688 F0               [24] 1155 	movx	@dptr,a
      008689 12 8F 70         [24] 1156 	lcall	_ak820_outline_0114
      00868C 12 4E 54         [24] 1157 	lcall	_eeprom_update_byte
                                   1158 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      00868F EC               [12] 1159 	mov	a,r4
      008690 60 04            [24] 1160 	jz	00108$
      008692 7C 00            [12] 1161 	mov	r4,#0x00
      008694 80 02            [24] 1162 	sjmp	00109$
      008696                       1163 00108$:
      008696 7C 02            [12] 1164 	mov	r4,#0x02
      008698                       1165 00109$:
      008698 EC               [12] 1166 	mov	a,r4
      008699 12 39 1C         [24] 1167 	lcall	_ak820_outline_0143
      00869C 0D               [12] 1168 	inc	r5
      00869D BD 00 01         [24] 1169 	cjne	r5,#0x00,00137$
      0086A0 0E               [12] 1170 	inc	r6
      0086A1                       1171 00137$:
      0086A1 90 06 94         [24] 1172 	mov	dptr,#_eeprom_update_byte_PARM_2
      0086A4 E5 29            [12] 1173 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0086A6 12 4F 6A         [24] 1174 	lcall	_ak820_outline_0033
                                   1175 ;	quantum/dynamic_keymap.c:223: }
      0086A9 02 4E 54         [24] 1176 	ljmp	_eeprom_update_byte
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1179 ;------------------------------------------------------------
                                   1180 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1181 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1182 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_383'
                                   1183 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_384'
                                   1184 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_386'
                                   1185 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_387'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function dynamic_keymap_get_combo
                                   1190 ;	-----------------------------------------
      0086AC                       1191 _dynamic_keymap_get_combo:
      0086AC E5 82            [12] 1192 	mov	a,dpl
      0086AE 90 0A E9         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_383
      0086B1 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0086B2 90 0A E6         [24] 1196 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0086B5 12 38 C3         [24] 1197 	lcall	_ak820_outline_0060
                                   1198 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      0086B8 90 0A E9         [24] 1199 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_383
      0086BB E0               [24] 1200 	movx	a,@dptr
      0086BC FD               [12] 1201 	mov	r5,a
      0086BD BD 08 00         [24] 1202 	cjne	r5,#0x08,00132$
      0086C0                       1203 00132$:
      0086C0 40 04            [24] 1204 	jc	00102$
                                   1205 ;	quantum/dynamic_keymap.c:275: return -1;
      0086C2 90 FF FF         [24] 1206 	mov	dptr,#0xffff
      0086C5 22               [24] 1207 	ret
      0086C6                       1208 00102$:
                                   1209 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0086C6 12 8F 48         [24] 1210 	lcall	_ak820_outline_0091
                                   1211 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0086C9 8E 02            [24] 1212 	mov	ar2,r6
      0086CB 8F 03            [24] 1213 	mov	ar3,r7
      0086CD 90 05 7E         [24] 1214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0086D0 EC               [12] 1215 	mov	a,r4
      0086D1 F0               [24] 1216 	movx	@dptr,a
      0086D2 ED               [12] 1217 	mov	a,r5
      0086D3 12 38 E0         [24] 1218 	lcall	_ak820_outline_0081
      0086D6 90 05 81         [24] 1219 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0086D9 12 8F 5C         [24] 1220 	lcall	_ak820_outline_0101
      0086DC 12 39 12         [24] 1221 	lcall	_ak820_outline_0140
      0086DF C0 07            [24] 1222 	push	ar7
      0086E1 C0 06            [24] 1223 	push	ar6
      0086E3 12 41 1C         [24] 1224 	lcall	_ak820_eeprom_read_block_xdata
      0086E6 D0 06            [24] 1225 	pop	ar6
      0086E8 D0 07            [24] 1226 	pop	ar7
                                   1227 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0086EA 74 04            [12] 1228 	mov	a,#0x04
      0086EC 12 48 E6         [24] 1229 	lcall	_ak820_outline_0055
      0086EF FA               [12] 1230 	mov	r2,a
      0086F0 A3               [24] 1231 	inc	dptr
      0086F1 E0               [24] 1232 	movx	a,@dptr
      0086F2 FB               [12] 1233 	mov	r3,a
      0086F3 BA 20 14         [24] 1234 	cjne	r2,#0x20,00108$
      0086F6 BB 08 11         [24] 1235 	cjne	r3,#0x08,00108$
      0086F9 74 06            [12] 1236 	mov	a,#0x06
      0086FB 12 38 9D         [24] 1237 	lcall	_ak820_outline_0023
      0086FE FA               [12] 1238 	mov	r2,a
      0086FF A3               [24] 1239 	inc	dptr
      008700 E0               [24] 1240 	movx	a,@dptr
      008701 FB               [12] 1241 	mov	r3,a
      008702 BA 01 05         [24] 1242 	cjne	r2,#0x01,00136$
      008705 BB 00 02         [24] 1243 	cjne	r3,#0x00,00136$
      008708 80 05            [24] 1244 	sjmp	00109$
      00870A                       1245 00136$:
      00870A                       1246 00108$:
      00870A 75 2B 00         [24] 1247 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00870D 80 03            [24] 1248 	sjmp	00110$
      00870F                       1249 00109$:
      00870F 75 2B 01         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008712                       1251 00110$:
                                   1252 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008712 74 06            [12] 1253 	mov	a,#0x06
      008714 12 38 BB         [24] 1254 	lcall	_ak820_outline_0045
      008717 12 4F B3         [24] 1255 	lcall	_ak820_outline_0174
      00871A 12 43 CF         [24] 1256 	lcall	_ak820_outline_0127
      00871D A3               [24] 1257 	inc	dptr
      00871E F0               [24] 1258 	movx	@dptr,a
                                   1259 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      00871F E5 2B            [12] 1260 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008721 60 12            [24] 1261 	jz	00103$
      008723 12 39 08         [24] 1262 	lcall	_ak820_outline_0123
      008726 C0 07            [24] 1263 	push	ar7
      008728 C0 06            [24] 1264 	push	ar6
      00872A 12 35 55         [24] 1265 	lcall	_ak820_combo_valid
      00872D E5 82            [12] 1266 	mov	a, dpl
      00872F D0 06            [24] 1267 	pop	ar6
      008731 D0 07            [24] 1268 	pop	ar7
      008733 70 15            [24] 1269 	jnz	00104$
      008735                       1270 00103$:
      008735 7D 00            [12] 1271 	mov	r5,#0x00
      008737 90 0D CA         [24] 1272 	mov	dptr,#_memset_PARM_2
      00873A E4               [12] 1273 	clr	a
      00873B F0               [24] 1274 	movx	@dptr,a
      00873C 90 0D CB         [24] 1275 	mov	dptr,#_memset_PARM_3
      00873F 74 0A            [12] 1276 	mov	a,#0x0a
      008741 F0               [24] 1277 	movx	@dptr,a
      008742 E4               [12] 1278 	clr	a
      008743 A3               [24] 1279 	inc	dptr
      008744 12 70 85         [24] 1280 	lcall	_ak820_outline_0065
      008747 12 BC 7D         [24] 1281 	lcall	_memset
      00874A                       1282 00104$:
                                   1283 ;	quantum/dynamic_keymap.c:289: return 0;
      00874A 90 00 00         [24] 1284 	mov	dptr,#0x0000
                                   1285 ;	quantum/dynamic_keymap.c:290: }
      00874D 22               [24] 1286 	ret
                                   1287 ;------------------------------------------------------------
                                   1288 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1289 ;------------------------------------------------------------
                                   1290 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1291 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_389'
                                   1292 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_390'
                                   1293 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_393'
                                   1294 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_394'
                                   1295 ;------------------------------------------------------------
                                   1296 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1297 ;	-----------------------------------------
                                   1298 ;	 function dynamic_keymap_set_combo
                                   1299 ;	-----------------------------------------
      00874E                       1300 _dynamic_keymap_set_combo:
      00874E E5 82            [12] 1301 	mov	a,dpl
      008750 90 0A ED         [24] 1302 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_389
      008753 F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008754 90 0A EA         [24] 1305 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008757 12 38 81         [24] 1306 	lcall	_ak820_outline_0010
                                   1307 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      00875A C0 07            [24] 1308 	push	ar7
      00875C C0 06            [24] 1309 	push	ar6
      00875E 12 35 55         [24] 1310 	lcall	_ak820_combo_valid
      008761 E5 82            [12] 1311 	mov	a, dpl
      008763 D0 06            [24] 1312 	pop	ar6
      008765 D0 07            [24] 1313 	pop	ar7
      008767 60 07            [24] 1314 	jz	00101$
      008769 12 3E 87         [24] 1315 	lcall	_ak820_nvm_ok
      00876C E5 82            [12] 1316 	mov	a, dpl
      00876E 70 04            [24] 1317 	jnz	00102$
      008770                       1318 00101$:
      008770 90 FF FF         [24] 1319 	mov	dptr,#0xffff
      008773 22               [24] 1320 	ret
      008774                       1321 00102$:
                                   1322 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008774 90 0A ED         [24] 1323 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_389
      008777 E0               [24] 1324 	movx	a,@dptr
      008778 FD               [12] 1325 	mov	r5,a
      008779 BD 08 00         [24] 1326 	cjne	r5,#0x08,00133$
      00877C                       1327 00133$:
      00877C 40 04            [24] 1328 	jc	00105$
                                   1329 ;	quantum/dynamic_keymap.c:302: return -1;
      00877E 90 FF FF         [24] 1330 	mov	dptr,#0xffff
      008781 22               [24] 1331 	ret
      008782                       1332 00105$:
                                   1333 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008782 12 8F 48         [24] 1334 	lcall	_ak820_outline_0091
                                   1335 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008785 C0 07            [24] 1336 	push	ar7
      008787 C0 06            [24] 1337 	push	ar6
      008789 C0 05            [24] 1338 	push	ar5
      00878B C0 04            [24] 1339 	push	ar4
      00878D 12 77 61         [24] 1340 	lcall	_clear_keyboard
      008790 D0 04            [24] 1341 	pop	ar4
      008792 D0 05            [24] 1342 	pop	ar5
      008794 D0 06            [24] 1343 	pop	ar6
      008796 D0 07            [24] 1344 	pop	ar7
                                   1345 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008798 90 0D C2         [24] 1346 	mov	dptr,#___memcpy_PARM_2
      00879B 12 48 F9         [24] 1347 	lcall	_ak820_outline_0068
      00879E E4               [12] 1348 	clr	a
      00879F A3               [24] 1349 	inc	dptr
      0087A0 F0               [24] 1350 	movx	@dptr,a
      0087A1 90 0D C5         [24] 1351 	mov	dptr,#___memcpy_PARM_3
      0087A4 12 8F 5C         [24] 1352 	lcall	_ak820_outline_0101
      0087A7 90 0A EE         [24] 1353 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_394
      0087AA F5 F0            [12] 1354 	mov	b,a
      0087AC C0 05            [24] 1355 	push	ar5
      0087AE C0 04            [24] 1356 	push	ar4
      0087B0 12 BC 07         [24] 1357 	lcall	___memcpy
      0087B3 D0 04            [24] 1358 	pop	ar4
      0087B5 D0 05            [24] 1359 	pop	ar5
                                   1360 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      0087B7 90 0A F2         [24] 1361 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_394 + 0x0004)
      0087BA 74 20            [12] 1362 	mov	a,#0x20
      0087BC F0               [24] 1363 	movx	@dptr,a
      0087BD 74 08            [12] 1364 	mov	a,#0x08
      0087BF A3               [24] 1365 	inc	dptr
      0087C0 F0               [24] 1366 	movx	@dptr,a
                                   1367 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      0087C1 90 0A F4         [24] 1368 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_394 + 0x0006)
      0087C4 74 01            [12] 1369 	mov	a,#0x01
      0087C6 12 39 0D         [24] 1370 	lcall	_ak820_outline_0130
                                   1371 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      0087C9 90 05 87         [24] 1372 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0087CC EC               [12] 1373 	mov	a,r4
      0087CD F0               [24] 1374 	movx	@dptr,a
      0087CE ED               [12] 1375 	mov	a,r5
      0087CF 12 38 E0         [24] 1376 	lcall	_ak820_outline_0081
      0087D2 90 05 8A         [24] 1377 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0087D5 12 8F 5C         [24] 1378 	lcall	_ak820_outline_0101
      0087D8 90 0A EE         [24] 1379 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_394
      0087DB 12 41 A8         [24] 1380 	lcall	_ak820_eeprom_write_block_xdata
                                   1381 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      0087DE 12 3E 96         [24] 1382 	lcall	_ak820_nvm_flush
                                   1383 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      0087E1 12 3E 87         [24] 1384 	lcall	_ak820_nvm_ok
      0087E4 E5 82            [12] 1385 	mov	a, dpl
      0087E6 70 04            [24] 1386 	jnz	00107$
      0087E8 90 FF FF         [24] 1387 	mov	dptr,#0xffff
      0087EB 22               [24] 1388 	ret
      0087EC                       1389 00107$:
                                   1390 ;	quantum/dynamic_keymap.c:320: return 0;
      0087EC 90 00 00         [24] 1391 	mov	dptr,#0x0000
                                   1392 ;	quantum/dynamic_keymap.c:321: }
      0087EF 22               [24] 1393 	ret
                                   1394 ;------------------------------------------------------------
                                   1395 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1396 ;------------------------------------------------------------
                                   1397 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_397'
                                   1398 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_398'
                                   1399 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_400'
                                   1400 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_402'
                                   1401 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_404'
                                   1402 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_406'
                                   1403 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_407'
                                   1404 ;------------------------------------------------------------
                                   1405 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1406 ;	-----------------------------------------
                                   1407 ;	 function dynamic_keymap_reset
                                   1408 ;	-----------------------------------------
      0087F0                       1409 _dynamic_keymap_reset:
                                   1410 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      0087F0 90 0E 42         [24] 1411 	mov	dptr,#_vial_unlocked
      0087F3 E0               [24] 1412 	movx	a,@dptr
      0087F4 90 0A F8         [24] 1413 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_397
      0087F7 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      0087F8 90 0E 42         [24] 1416 	mov	dptr,#_vial_unlocked
      0087FB 74 01            [12] 1417 	mov	a,#0x01
      0087FD F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0087FE 7F 00            [12] 1420 	mov	r7,#0x00
      008800                       1421 00116$:
      008800 BF 06 00         [24] 1422 	cjne	r7,#0x06,00198$
      008803                       1423 00198$:
      008803 40 03            [24] 1424 	jc	00199$
      008805 02 88 B3         [24] 1425 	ljmp	00104$
      008808                       1426 00199$:
                                   1427 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008808 7E 00            [12] 1428 	mov	r6,#0x00
      00880A                       1429 00110$:
      00880A BE 10 00         [24] 1430 	cjne	r6,#0x10,00200$
      00880D                       1431 00200$:
      00880D 50 4D            [24] 1432 	jnc	00102$
                                   1433 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00880F 7D 00            [12] 1434 	mov	r5,#0x00
      008811                       1435 00107$:
      008811 BD 08 00         [24] 1436 	cjne	r5,#0x08,00202$
      008814                       1437 00202$:
      008814 50 43            [24] 1438 	jnc	00111$
                                   1439 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008816 90 0B AA         [24] 1440 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008819 EE               [12] 1441 	mov	a,r6
      00881A F0               [24] 1442 	movx	@dptr,a
      00881B 90 0B AB         [24] 1443 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      00881E ED               [12] 1444 	mov	a,r5
      00881F F0               [24] 1445 	movx	@dptr,a
      008820 8F 82            [24] 1446 	mov	dpl, r7
      008822 C0 07            [24] 1447 	push	ar7
      008824 C0 06            [24] 1448 	push	ar6
      008826 C0 05            [24] 1449 	push	ar5
      008828 12 98 C8         [24] 1450 	lcall	_keycode_at_keymap_location_raw
      00882B AB 82            [24] 1451 	mov	r3, dpl
      00882D AC 83            [24] 1452 	mov	r4, dph
      00882F D0 05            [24] 1453 	pop	ar5
      008831 D0 06            [24] 1454 	pop	ar6
      008833 D0 07            [24] 1455 	pop	ar7
      008835 90 0A D7         [24] 1456 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008838 EE               [12] 1457 	mov	a,r6
      008839 F0               [24] 1458 	movx	@dptr,a
      00883A 90 0A D8         [24] 1459 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00883D ED               [12] 1460 	mov	a,r5
      00883E F0               [24] 1461 	movx	@dptr,a
      00883F 90 0A D9         [24] 1462 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008842 12 38 F2         [24] 1463 	lcall	_ak820_outline_0103
      008845 8F 82            [24] 1464 	mov	dpl, r7
      008847 C0 07            [24] 1465 	push	ar7
      008849 C0 06            [24] 1466 	push	ar6
      00884B C0 05            [24] 1467 	push	ar5
      00884D 12 85 69         [24] 1468 	lcall	_dynamic_keymap_set_keycode
      008850 D0 05            [24] 1469 	pop	ar5
      008852 D0 06            [24] 1470 	pop	ar6
      008854 D0 07            [24] 1471 	pop	ar7
                                   1472 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008856 0D               [12] 1473 	inc	r5
      008857 80 B8            [24] 1474 	sjmp	00107$
      008859                       1475 00111$:
                                   1476 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008859 0E               [12] 1477 	inc	r6
      00885A 80 AE            [24] 1478 	sjmp	00110$
      00885C                       1479 00102$:
                                   1480 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00885C 7E 00            [12] 1481 	mov	r6,#0x00
      00885E                       1482 00113$:
      00885E BE 01 00         [24] 1483 	cjne	r6,#0x01,00204$
      008861                       1484 00204$:
      008861 50 4C            [24] 1485 	jnc	00117$
                                   1486 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008863 12 8F A5         [24] 1487 	lcall	_ak820_outline_0186
      008866 04               [12] 1488 	inc	a
      008867 F0               [24] 1489 	movx	@dptr,a
      008868 8F 82            [24] 1490 	mov	dpl, r7
      00886A C0 07            [24] 1491 	push	ar7
      00886C 12 99 12         [24] 1492 	lcall	_keycode_at_encodermap_location_raw
      00886F 12 43 F4         [24] 1493 	lcall	_ak820_outline_0193
      008872 D0 07            [24] 1494 	pop	ar7
      008874 12 8F 9C         [24] 1495 	lcall	_ak820_outline_0184
      008877 04               [12] 1496 	inc	a
      008878 F0               [24] 1497 	movx	@dptr,a
      008879 90 0A E3         [24] 1498 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00887C 12 38 E6         [24] 1499 	lcall	_ak820_outline_0087
      00887F 8F 82            [24] 1500 	mov	dpl, r7
      008881 C0 07            [24] 1501 	push	ar7
      008883 12 86 42         [24] 1502 	lcall	_dynamic_keymap_set_encoder
      008886 D0 07            [24] 1503 	pop	ar7
                                   1504 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008888 12 8F A5         [24] 1505 	lcall	_ak820_outline_0186
      00888B F0               [24] 1506 	movx	@dptr,a
      00888C 8F 82            [24] 1507 	mov	dpl, r7
      00888E C0 07            [24] 1508 	push	ar7
      008890 12 99 12         [24] 1509 	lcall	_keycode_at_encodermap_location_raw
      008893 12 43 F4         [24] 1510 	lcall	_ak820_outline_0193
      008896 D0 07            [24] 1511 	pop	ar7
      008898 12 8F 9C         [24] 1512 	lcall	_ak820_outline_0184
      00889B F0               [24] 1513 	movx	@dptr,a
      00889C 90 0A E3         [24] 1514 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00889F 12 38 E6         [24] 1515 	lcall	_ak820_outline_0087
      0088A2 8F 82            [24] 1516 	mov	dpl, r7
      0088A4 C0 07            [24] 1517 	push	ar7
      0088A6 12 86 42         [24] 1518 	lcall	_dynamic_keymap_set_encoder
      0088A9 D0 07            [24] 1519 	pop	ar7
                                   1520 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0088AB 7E 01            [12] 1521 	mov	r6,#0x01
      0088AD 80 AF            [24] 1522 	sjmp	00113$
      0088AF                       1523 00117$:
                                   1524 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0088AF 0F               [12] 1525 	inc	r7
      0088B0 02 88 00         [24] 1526 	ljmp	00116$
      0088B3                       1527 00104$:
                                   1528 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      0088B3 90 0A F9         [24] 1529 	mov	dptr,#_dynamic_keymap_reset_combo_10001_406
      0088B6 12 4F B3         [24] 1530 	lcall	_ak820_outline_0174
      0088B9 90 0A FB         [24] 1531 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0002)
      0088BC F0               [24] 1532 	movx	@dptr,a
      0088BD A3               [24] 1533 	inc	dptr
      0088BE F0               [24] 1534 	movx	@dptr,a
      0088BF 90 0A FD         [24] 1535 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0004)
      0088C2 F0               [24] 1536 	movx	@dptr,a
      0088C3 A3               [24] 1537 	inc	dptr
      0088C4 F0               [24] 1538 	movx	@dptr,a
      0088C5 90 0A FF         [24] 1539 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0006)
      0088C8 F0               [24] 1540 	movx	@dptr,a
      0088C9 A3               [24] 1541 	inc	dptr
      0088CA F0               [24] 1542 	movx	@dptr,a
      0088CB 90 0B 01         [24] 1543 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_406 + 0x0008)
      0088CE F0               [24] 1544 	movx	@dptr,a
      0088CF A3               [24] 1545 	inc	dptr
      0088D0 F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0088D1 FF               [12] 1548 	mov	r7,a
      0088D2                       1549 00119$:
      0088D2 BF 08 00         [24] 1550 	cjne	r7,#0x08,00206$
      0088D5                       1551 00206$:
      0088D5 50 19            [24] 1552 	jnc	00105$
                                   1553 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      0088D7 8F 06            [24] 1554 	mov	ar6,r7
      0088D9 90 0A EA         [24] 1555 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0088DC 74 F9            [12] 1556 	mov	a,#_dynamic_keymap_reset_combo_10001_406
      0088DE F0               [24] 1557 	movx	@dptr,a
      0088DF 74 0A            [12] 1558 	mov	a,#(_dynamic_keymap_reset_combo_10001_406 >> 8)
      0088E1 12 38 E0         [24] 1559 	lcall	_ak820_outline_0081
      0088E4 8E 82            [24] 1560 	mov	dpl, r6
      0088E6 C0 07            [24] 1561 	push	ar7
      0088E8 12 87 4E         [24] 1562 	lcall	_dynamic_keymap_set_combo
      0088EB D0 07            [24] 1563 	pop	ar7
                                   1564 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0088ED 0F               [12] 1565 	inc	r7
      0088EE 80 E2            [24] 1566 	sjmp	00119$
      0088F0                       1567 00105$:
                                   1568 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      0088F0 90 0A F8         [24] 1569 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_397
      0088F3 E0               [24] 1570 	movx	a,@dptr
      0088F4 90 0E 42         [24] 1571 	mov	dptr,#_vial_unlocked
      0088F7 F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/dynamic_keymap.c:405: }
      0088F8 22               [24] 1574 	ret
                                   1575 ;------------------------------------------------------------
                                   1576 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1577 ;------------------------------------------------------------
                                   1578 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1579 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1580 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1581 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1582 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1583 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_408'
                                   1584 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_409'
                                   1585 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_409'
                                   1586 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_412'
                                   1587 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_414'
                                   1588 ;------------------------------------------------------------
                                   1589 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1590 ;	-----------------------------------------
                                   1591 ;	 function ak820_dynamic_read_buffer
                                   1592 ;	-----------------------------------------
      0088F9                       1593 _ak820_dynamic_read_buffer:
      0088F9 12 39 03         [24] 1594 	lcall	_ak820_outline_0122
      0088FC 90 0B 0C         [24] 1595 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_408
      0088FF 12 38 FE         [24] 1596 	lcall	_ak820_outline_0121
                                   1597 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008902 90 0B 09         [24] 1598 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008905 12 38 C3         [24] 1599 	lcall	_ak820_outline_0060
                                   1600 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008908 90 0B 0E         [24] 1601 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      00890B E4               [12] 1602 	clr	a
      00890C F0               [24] 1603 	movx	@dptr,a
                                   1604 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      00890D 90 0B 07         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008910 12 38 DA         [24] 1606 	lcall	_ak820_outline_0076
      008913 8C 02            [24] 1607 	mov	ar2,r4
      008915 8D 03            [24] 1608 	mov	ar3,r5
      008917 C3               [12] 1609 	clr	c
      008918 74 1C            [12] 1610 	mov	a,#0x1c
      00891A 9A               [12] 1611 	subb	a,r2
      00891B E4               [12] 1612 	clr	a
      00891C 9B               [12] 1613 	subb	a,r3
      00891D 50 01            [24] 1614 	jnc	00102$
                                   1615 ;	free result
      00891F 22               [24] 1616 	ret
      008920                       1617 00102$:
                                   1618 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008920 90 0B 05         [24] 1619 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008923 12 43 B7         [24] 1620 	lcall	_ak820_outline_0110
      008926 90 0B 03         [24] 1621 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008929 12 38 F8         [24] 1622 	lcall	_ak820_outline_0109
      00892C C3               [12] 1623 	clr	c
      00892D EA               [12] 1624 	mov	a,r2
      00892E 98               [12] 1625 	subb	a,r0
      00892F EB               [12] 1626 	mov	a,r3
      008930 99               [12] 1627 	subb	a,r1
      008931 50 17            [24] 1628 	jnc	00104$
                                   1629 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008933 E8               [12] 1630 	mov	a,r0
      008934 C3               [12] 1631 	clr	c
      008935 9A               [12] 1632 	subb	a,r2
      008936 F8               [12] 1633 	mov	r0,a
      008937 E9               [12] 1634 	mov	a,r1
      008938 9B               [12] 1635 	subb	a,r3
      008939 F9               [12] 1636 	mov	r1,a
                                   1637 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      00893A C3               [12] 1638 	clr	c
      00893B E8               [12] 1639 	mov	a,r0
      00893C 9C               [12] 1640 	subb	a,r4
      00893D E9               [12] 1641 	mov	a,r1
      00893E 9D               [12] 1642 	subb	a,r5
      00893F 40 04            [24] 1643 	jc	00114$
      008941 8C 00            [24] 1644 	mov	ar0,r4
      008943 8D 01            [24] 1645 	mov	ar1,r5
      008945                       1646 00114$:
      008945 90 0B 0E         [24] 1647 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      008948 E8               [12] 1648 	mov	a,r0
      008949 F0               [24] 1649 	movx	@dptr,a
      00894A                       1650 00104$:
                                   1651 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00894A 90 0B 0E         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      00894D E0               [24] 1653 	movx	a,@dptr
      00894E F5 2C            [12] 1654 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008950 E0               [24] 1655 	movx	a,@dptr
      008951 60 42            [24] 1656 	jz	00106$
      008953 C0 04            [24] 1657 	push	ar4
      008955 C0 05            [24] 1658 	push	ar5
      008957 8E 00            [24] 1659 	mov	ar0,r6
      008959 8F 05            [24] 1660 	mov	ar5,r7
      00895B 90 0B 0C         [24] 1661 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_408
      00895E E0               [24] 1662 	movx	a,@dptr
      00895F F9               [12] 1663 	mov	r1,a
      008960 A3               [24] 1664 	inc	dptr
      008961 E0               [24] 1665 	movx	a,@dptr
      008962 FC               [12] 1666 	mov	r4,a
      008963 EA               [12] 1667 	mov	a,r2
      008964 29               [12] 1668 	add	a, r1
      008965 FA               [12] 1669 	mov	r2,a
      008966 EB               [12] 1670 	mov	a,r3
      008967 3C               [12] 1671 	addc	a, r4
      008968 FB               [12] 1672 	mov	r3,a
      008969 90 05 7E         [24] 1673 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00896C EA               [12] 1674 	mov	a,r2
      00896D F0               [24] 1675 	movx	@dptr,a
      00896E EB               [12] 1676 	mov	a,r3
      00896F 12 38 E0         [24] 1677 	lcall	_ak820_outline_0081
      008972 90 05 81         [24] 1678 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008975 E5 2C            [12] 1679 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008977 12 39 0D         [24] 1680 	lcall	_ak820_outline_0130
      00897A 88 82            [24] 1681 	mov	dpl, r0
      00897C 8D 83            [24] 1682 	mov	dph, r5
      00897E C0 07            [24] 1683 	push	ar7
      008980 C0 06            [24] 1684 	push	ar6
      008982 C0 05            [24] 1685 	push	ar5
      008984 C0 04            [24] 1686 	push	ar4
      008986 12 41 1C         [24] 1687 	lcall	_ak820_eeprom_read_block_xdata
      008989 D0 04            [24] 1688 	pop	ar4
      00898B D0 05            [24] 1689 	pop	ar5
      00898D D0 06            [24] 1690 	pop	ar6
      00898F D0 07            [24] 1691 	pop	ar7
                                   1692 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008991 D0 05            [24] 1693 	pop	ar5
      008993 D0 04            [24] 1694 	pop	ar4
                                   1695 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008995                       1696 00106$:
                                   1697 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008995 90 0B 0E         [24] 1698 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_409
      008998 E0               [24] 1699 	movx	a,@dptr
      008999 FB               [12] 1700 	mov	r3,a
      00899A                       1701 00109$:
      00899A 8B 01            [24] 1702 	mov	ar1,r3
      00899C 7A 00            [12] 1703 	mov	r2,#0x00
      00899E C3               [12] 1704 	clr	c
      00899F E9               [12] 1705 	mov	a,r1
      0089A0 9C               [12] 1706 	subb	a,r4
      0089A1 EA               [12] 1707 	mov	a,r2
      0089A2 9D               [12] 1708 	subb	a,r5
      0089A3 50 09            [24] 1709 	jnc	00111$
      0089A5 EB               [12] 1710 	mov	a,r3
      0089A6 12 38 BB         [24] 1711 	lcall	_ak820_outline_0045
      0089A9 E4               [12] 1712 	clr	a
      0089AA F0               [24] 1713 	movx	@dptr,a
      0089AB 0B               [12] 1714 	inc	r3
      0089AC 80 EC            [24] 1715 	sjmp	00109$
      0089AE                       1716 00111$:
                                   1717 ;	quantum/dynamic_keymap.c:420: }
      0089AE 22               [24] 1718 	ret
                                   1719 ;------------------------------------------------------------
                                   1720 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1721 ;------------------------------------------------------------
                                   1722 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1723 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1724 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_415'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1727 ;	-----------------------------------------
                                   1728 ;	 function dynamic_keymap_get_buffer
                                   1729 ;	-----------------------------------------
      0089AF                       1730 _dynamic_keymap_get_buffer:
      0089AF 12 39 03         [24] 1731 	lcall	_ak820_outline_0122
      0089B2 90 0B 14         [24] 1732 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_415
      0089B5 12 38 FE         [24] 1733 	lcall	_ak820_outline_0121
                                   1734 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      0089B8 90 0B 14         [24] 1735 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_415
      0089BB 12 38 C3         [24] 1736 	lcall	_ak820_outline_0060
      0089BE 90 0B 0F         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0089C1 12 38 DA         [24] 1738 	lcall	_ak820_outline_0076
      0089C4 90 0B 11         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0089C7 12 4F 9A         [24] 1740 	lcall	_ak820_outline_0098
      0089CA 90 0B 03         [24] 1741 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0089CD E4               [12] 1742 	clr	a
      0089CE F0               [24] 1743 	movx	@dptr,a
      0089CF 74 06            [12] 1744 	mov	a,#0x06
      0089D1 A3               [24] 1745 	inc	dptr
      0089D2 F0               [24] 1746 	movx	@dptr,a
      0089D3 90 0B 05         [24] 1747 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0089D6 12 48 F9         [24] 1748 	lcall	_ak820_outline_0068
      0089D9 90 0B 07         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0089DC 12 38 E6         [24] 1750 	lcall	_ak820_outline_0087
      0089DF 90 0B 09         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0089E2 E9               [12] 1752 	mov	a,r1
      0089E3 12 4F AC         [24] 1753 	lcall	_ak820_outline_0119
      0089E6 F0               [24] 1754 	movx	@dptr,a
      0089E7 90 00 40         [24] 1755 	mov	dptr,#0x0040
                                   1756 ;	quantum/dynamic_keymap.c:448: }
      0089EA 02 88 F9         [24] 1757 	ljmp	_ak820_dynamic_read_buffer
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1760 ;------------------------------------------------------------
                                   1761 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1762 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1763 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1764 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1765 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1766 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_417'
                                   1767 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_418'
                                   1768 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_418'
                                   1769 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_418'
                                   1770 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_421'
                                   1771 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_424'
                                   1772 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_424'
                                   1773 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_426'
                                   1774 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
                                   1775 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_431'
                                   1776 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
                                   1777 ;------------------------------------------------------------
                                   1778 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1779 ;	-----------------------------------------
                                   1780 ;	 function dynamic_keymap_set_buffer
                                   1781 ;	-----------------------------------------
      0089ED                       1782 _dynamic_keymap_set_buffer:
      0089ED 12 39 03         [24] 1783 	lcall	_ak820_outline_0122
      0089F0 90 0B 1B         [24] 1784 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      0089F3 12 38 FE         [24] 1785 	lcall	_ak820_outline_0121
                                   1786 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0089F6 90 0B 1B         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      0089F9 12 48 9E         [24] 1788 	lcall	_ak820_outline_0013
      0089FC 74 40            [12] 1789 	mov	a,#0x40
      0089FE 2C               [12] 1790 	add	a, r4
      0089FF FA               [12] 1791 	mov	r2,a
      008A00 E4               [12] 1792 	clr	a
      008A01 3D               [12] 1793 	addc	a, r5
      008A02 FB               [12] 1794 	mov	r3,a
                                   1795 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008A03 90 0B 18         [24] 1796 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008A06 12 38 F8         [24] 1797 	lcall	_ak820_outline_0109
                                   1798 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008A09 90 0B 16         [24] 1799 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008A0C E0               [24] 1800 	movx	a,@dptr
      008A0D F5 2D            [12] 1801 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008A0F A3               [24] 1802 	inc	dptr
      008A10 E0               [24] 1803 	movx	a,@dptr
      008A11 F5 2E            [12] 1804 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008A13 E5 2D            [12] 1805 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A15 45 2E            [12] 1806 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A17 70 01            [24] 1807 	jnz	00102$
      008A19 22               [24] 1808 	ret
      008A1A                       1809 00102$:
                                   1810 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008A1A 85 2D 2F         [24] 1811 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008A1D 85 2E 30         [24] 1812 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A20 C3               [12] 1813 	clr	c
      008A21 74 1C            [12] 1814 	mov	a,#0x1c
      008A23 95 2F            [12] 1815 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008A25 E4               [12] 1816 	clr	a
      008A26 95 30            [12] 1817 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008A28 50 01            [24] 1818 	jnc	00104$
                                   1819 ;	free result
      008A2A 22               [24] 1820 	ret
      008A2B                       1821 00104$:
                                   1822 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008A2B 85 2D 31         [24] 1823 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1824 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008A2E 74 FA            [12] 1825 	mov	a,#0x100 - 0x06
      008A30 2F               [12] 1826 	add	a,r7
      008A31 40 11            [24] 1827 	jc	00105$
      008A33 E4               [12] 1828 	clr	a
      008A34 C3               [12] 1829 	clr	c
      008A35 9E               [12] 1830 	subb	a,r6
      008A36 FE               [12] 1831 	mov	r6,a
      008A37 74 06            [12] 1832 	mov	a,#0x06
      008A39 9F               [12] 1833 	subb	a,r7
      008A3A FF               [12] 1834 	mov	r7,a
      008A3B C3               [12] 1835 	clr	c
      008A3C EE               [12] 1836 	mov	a,r6
      008A3D 95 2D            [12] 1837 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A3F EF               [12] 1838 	mov	a,r7
      008A40 95 2E            [12] 1839 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A42 50 01            [24] 1840 	jnc	00106$
      008A44                       1841 00105$:
                                   1842 ;	quantum/dynamic_keymap.c:466: return;
      008A44 22               [24] 1843 	ret
      008A45                       1844 00106$:
                                   1845 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008A45 90 0E 42         [24] 1846 	mov	dptr,#_vial_unlocked
      008A48 E0               [24] 1847 	movx	a,@dptr
      008A49 60 03            [24] 1848 	jz	00207$
      008A4B 02 8B 5C         [24] 1849 	ljmp	00120$
      008A4E                       1850 00207$:
                                   1851 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008A4E 90 0B 1D         [24] 1852 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      008A51 E4               [12] 1853 	clr	a
      008A52 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008A53 90 0B 1E         [24] 1856 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      008A56 E5 31            [12] 1857 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A58 F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008A59 EC               [12] 1860 	mov	a,r4
      008A5A 30 E0 33         [24] 1861 	jnb	acc.0,00111$
                                   1862 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008A5D EA               [12] 1863 	mov	a,r2
      008A5E 24 FF            [12] 1864 	add	a,#0xff
      008A60 FE               [12] 1865 	mov	r6,a
      008A61 EB               [12] 1866 	mov	a,r3
      008A62 34 FF            [12] 1867 	addc	a,#0xff
      008A64 FF               [12] 1868 	mov	r7,a
      008A65 7D 00            [12] 1869 	mov	r5,#0x00
      008A67 12 39 08         [24] 1870 	lcall	_ak820_outline_0123
      008A6A 8D F0            [24] 1871 	mov	b, r5
      008A6C 12 40 E1         [24] 1872 	lcall	_eeprom_read_byte
      008A6F AE 82            [24] 1873 	mov	r6,dpl
      008A71 7F 00            [12] 1874 	mov	r7,#0x00
      008A73 12 39 2E         [24] 1875 	lcall	_ak820_outline_0155
      008A76 E0               [24] 1876 	movx	a,@dptr
      008A77 7C 00            [12] 1877 	mov	r4,#0x00
      008A79 42 07            [12] 1878 	orl	ar7,a
      008A7B EC               [12] 1879 	mov	a,r4
      008A7C 42 06            [12] 1880 	orl	ar6,a
                                   1881 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008A7E BF 00 09         [24] 1882 	cjne	r7,#0x00,00109$
      008A81 BE 7C 06         [24] 1883 	cjne	r6,#0x7c,00109$
                                   1884 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008A84 12 39 2E         [24] 1885 	lcall	_ak820_outline_0155
      008A87 74 FF            [12] 1886 	mov	a,#0xff
      008A89 F0               [24] 1887 	movx	@dptr,a
      008A8A                       1888 00109$:
                                   1889 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008A8A 90 0B 1D         [24] 1890 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      008A8D 74 01            [12] 1891 	mov	a,#0x01
      008A8F F0               [24] 1892 	movx	@dptr,a
      008A90                       1893 00111$:
                                   1894 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008A90 90 0B 1B         [24] 1895 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      008A93 12 38 C3         [24] 1896 	lcall	_ak820_outline_0060
      008A96 E5 2D            [12] 1897 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A98 2E               [12] 1898 	add	a, r6
      008A99 FE               [12] 1899 	mov	r6,a
      008A9A E5 2E            [12] 1900 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A9C 3F               [12] 1901 	addc	a, r7
      008A9D EE               [12] 1902 	mov	a,r6
      008A9E 30 E0 5C         [24] 1903 	jnb	acc.0,00115$
                                   1904 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008AA1 AE 31            [24] 1905 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008AA3 7F 00            [12] 1906 	mov	r7,#0x00
      008AA5 EE               [12] 1907 	mov	a,r6
      008AA6 24 FF            [12] 1908 	add	a,#0xff
      008AA8 FC               [12] 1909 	mov	r4,a
      008AA9 EF               [12] 1910 	mov	a,r7
      008AAA 34 FF            [12] 1911 	addc	a,#0xff
      008AAC FD               [12] 1912 	mov	r5,a
      008AAD EC               [12] 1913 	mov	a,r4
      008AAE 28               [12] 1914 	add	a, r0
      008AAF F5 82            [12] 1915 	mov	dpl,a
      008AB1 ED               [12] 1916 	mov	a,r5
      008AB2 39               [12] 1917 	addc	a, r1
      008AB3 F5 83            [12] 1918 	mov	dph,a
      008AB5 E0               [24] 1919 	movx	a,@dptr
      008AB6 FC               [12] 1920 	mov	r4,a
      008AB7 7D 00            [12] 1921 	mov	r5,#0x00
      008AB9 E5 31            [12] 1922 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008ABB 2A               [12] 1923 	add	a, r2
      008ABC FA               [12] 1924 	mov	r2,a
      008ABD E4               [12] 1925 	clr	a
      008ABE 3B               [12] 1926 	addc	a, r3
      008ABF FB               [12] 1927 	mov	r3,a
      008AC0 C0 00            [24] 1928 	push	ar0
      008AC2 C0 01            [24] 1929 	push	ar1
      008AC4 8B 01            [24] 1930 	mov	ar1,r3
      008AC6 7B 00            [12] 1931 	mov	r3,#0x00
      008AC8 8A 82            [24] 1932 	mov	dpl, r2
      008ACA 89 83            [24] 1933 	mov	dph, r1
      008ACC 8B F0            [24] 1934 	mov	b, r3
      008ACE 12 40 E1         [24] 1935 	lcall	_eeprom_read_byte
      008AD1 AB 82            [24] 1936 	mov	r3, dpl
      008AD3 7A 00            [12] 1937 	mov	r2,#0x00
      008AD5 EB               [12] 1938 	mov	a,r3
      008AD6 42 05            [12] 1939 	orl	ar5,a
      008AD8 EA               [12] 1940 	mov	a,r2
      008AD9 42 04            [12] 1941 	orl	ar4,a
                                   1942 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008ADB BD 00 05         [24] 1943 	cjne	r5,#0x00,00212$
      008ADE BC 7C 02         [24] 1944 	cjne	r4,#0x7c,00212$
      008AE1 80 06            [24] 1945 	sjmp	00213$
      008AE3                       1946 00212$:
      008AE3 D0 01            [24] 1947 	pop	ar1
      008AE5 D0 00            [24] 1948 	pop	ar0
      008AE7 80 0D            [24] 1949 	sjmp	00113$
      008AE9                       1950 00213$:
      008AE9 D0 01            [24] 1951 	pop	ar1
      008AEB D0 00            [24] 1952 	pop	ar0
                                   1953 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008AED 1E               [12] 1954 	dec	r6
      008AEE BE FF 01         [24] 1955 	cjne	r6,#0xff,00214$
      008AF1 1F               [12] 1956 	dec	r7
      008AF2                       1957 00214$:
      008AF2 EE               [12] 1958 	mov	a,r6
      008AF3 12 8F 7E         [24] 1959 	lcall	_ak820_outline_0136
      008AF6                       1960 00113$:
                                   1961 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008AF6 E5 31            [12] 1962 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008AF8 14               [12] 1963 	dec	a
      008AF9 90 0B 1E         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      008AFC F0               [24] 1965 	movx	@dptr,a
      008AFD                       1966 00115$:
                                   1967 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008AFD 90 0B 1D         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_424
      008B00 E0               [24] 1969 	movx	a,@dptr
      008B01 90 0B 1F         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008B04 F0               [24] 1971 	movx	@dptr,a
      008B05                       1972 00122$:
      008B05 90 0B 1F         [24] 1973 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008B08 E0               [24] 1974 	movx	a,@dptr
      008B09 FF               [12] 1975 	mov	r7,a
      008B0A 90 0B 1E         [24] 1976 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_424
      008B0D E0               [24] 1977 	movx	a,@dptr
      008B0E FE               [12] 1978 	mov	r6,a
      008B0F C3               [12] 1979 	clr	c
      008B10 EF               [12] 1980 	mov	a,r7
      008B11 9E               [12] 1981 	subb	a,r6
      008B12 50 48            [24] 1982 	jnc	00120$
                                   1983 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008B14 EF               [12] 1984 	mov	a,r7
      008B15 28               [12] 1985 	add	a, r0
      008B16 FD               [12] 1986 	mov	r5,a
      008B17 E4               [12] 1987 	clr	a
      008B18 39               [12] 1988 	addc	a, r1
      008B19 FE               [12] 1989 	mov	r6,a
      008B1A 12 49 0D         [24] 1990 	lcall	_ak820_outline_0085
      008B1D 7B 00            [12] 1991 	mov	r3,#0x00
      008B1F 8C 2E            [24] 1992 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008B21 8B 2D            [24] 1993 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008B23 8F 02            [24] 1994 	mov	ar2,r7
      008B25 7F 00            [12] 1995 	mov	r7,#0x00
      008B27 74 01            [12] 1996 	mov	a,#0x01
      008B29 2A               [12] 1997 	add	a, r2
      008B2A FB               [12] 1998 	mov	r3,a
      008B2B E4               [12] 1999 	clr	a
      008B2C 3F               [12] 2000 	addc	a, r7
      008B2D FC               [12] 2001 	mov	r4,a
      008B2E EB               [12] 2002 	mov	a,r3
      008B2F 28               [12] 2003 	add	a, r0
      008B30 F5 82            [12] 2004 	mov	dpl,a
      008B32 EC               [12] 2005 	mov	a,r4
      008B33 39               [12] 2006 	addc	a, r1
      008B34 F5 83            [12] 2007 	mov	dph,a
      008B36 E0               [24] 2008 	movx	a,@dptr
      008B37 FC               [12] 2009 	mov	r4,a
      008B38 7B 00            [12] 2010 	mov	r3,#0x00
      008B3A E5 2E            [12] 2011 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B3C 42 03            [12] 2012 	orl	ar3,a
                                   2013 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008B3E BC 00 12         [24] 2014 	cjne	r4,#0x00,00123$
      008B41 BB 7C 0F         [24] 2015 	cjne	r3,#0x7c,00123$
                                   2016 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008B44 12 39 17         [24] 2017 	lcall	_ak820_outline_0141
      008B47 74 FF            [12] 2018 	mov	a,#0xff
      008B49 F0               [24] 2019 	movx	@dptr,a
                                   2020 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008B4A 0A               [12] 2021 	inc	r2
      008B4B BA 00 01         [24] 2022 	cjne	r2,#0x00,00218$
      008B4E 0F               [12] 2023 	inc	r7
      008B4F                       2024 00218$:
      008B4F EA               [12] 2025 	mov	a,r2
      008B50 12 8F 7E         [24] 2026 	lcall	_ak820_outline_0136
      008B53                       2027 00123$:
                                   2028 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008B53 90 0B 1F         [24] 2029 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_431
      008B56 E0               [24] 2030 	movx	a,@dptr
      008B57 24 02            [12] 2031 	add	a,#0x02
      008B59 F0               [24] 2032 	movx	@dptr,a
      008B5A 80 A9            [24] 2033 	sjmp	00122$
      008B5C                       2034 00120$:
                                   2035 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008B5C 90 0B 1B         [24] 2036 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_417
      008B5F 12 38 C3         [24] 2037 	lcall	_ak820_outline_0060
      008B62 74 40            [12] 2038 	mov	a,#0x40
      008B64 12 43 DA         [24] 2039 	lcall	_ak820_outline_0144
      008B67 90 05 87         [24] 2040 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008B6A 12 48 F9         [24] 2041 	lcall	_ak820_outline_0068
      008B6D E4               [12] 2042 	clr	a
      008B6E A3               [24] 2043 	inc	dptr
      008B6F F0               [24] 2044 	movx	@dptr,a
      008B70 90 05 8A         [24] 2045 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B73 E5 2F            [12] 2046 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008B75 F0               [24] 2047 	movx	@dptr,a
      008B76 E5 30            [12] 2048 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008B78 A3               [24] 2049 	inc	dptr
      008B79 F0               [24] 2050 	movx	@dptr,a
      008B7A 12 39 2E         [24] 2051 	lcall	_ak820_outline_0155
                                   2052 ;	quantum/dynamic_keymap.c:521: }
      008B7D 02 41 A8         [24] 2053 	ljmp	_ak820_eeprom_write_block_xdata
                                   2054 ;------------------------------------------------------------
                                   2055 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2056 ;------------------------------------------------------------
                                   2057 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2058 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2059 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_435'
                                   2060 ;------------------------------------------------------------
                                   2061 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2062 ;	-----------------------------------------
                                   2063 ;	 function keycode_at_keymap_location
                                   2064 ;	-----------------------------------------
      008B80                       2065 _keycode_at_keymap_location:
      008B80 E5 82            [12] 2066 	mov	a,dpl
      008B82 90 0B 22         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_435
      008B85 F0               [24] 2068 	movx	@dptr,a
                                   2069 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008B86 E0               [24] 2070 	movx	a,@dptr
      008B87 FF               [12] 2071 	mov	r7,a
      008B88 BF 06 00         [24] 2072 	cjne	r7,#0x06,00128$
      008B8B                       2073 00128$:
      008B8B 50 23            [24] 2074 	jnc	00102$
      008B8D 90 0B 20         [24] 2075 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008B90 E0               [24] 2076 	movx	a,@dptr
      008B91 FE               [12] 2077 	mov	r6,a
      008B92 BE 10 00         [24] 2078 	cjne	r6,#0x10,00130$
      008B95                       2079 00130$:
      008B95 50 19            [24] 2080 	jnc	00102$
      008B97 90 0B 21         [24] 2081 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008B9A E0               [24] 2082 	movx	a,@dptr
      008B9B FD               [12] 2083 	mov	r5,a
      008B9C BD 08 00         [24] 2084 	cjne	r5,#0x08,00132$
      008B9F                       2085 00132$:
      008B9F 50 0F            [24] 2086 	jnc	00102$
                                   2087 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008BA1 90 0A D4         [24] 2088 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008BA4 EE               [12] 2089 	mov	a,r6
      008BA5 F0               [24] 2090 	movx	@dptr,a
      008BA6 90 0A D5         [24] 2091 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008BA9 ED               [12] 2092 	mov	a,r5
      008BAA F0               [24] 2093 	movx	@dptr,a
      008BAB 8F 82            [24] 2094 	mov	dpl, r7
      008BAD 02 85 1B         [24] 2095 	ljmp	_dynamic_keymap_get_keycode
      008BB0                       2096 00102$:
                                   2097 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008BB0 90 00 00         [24] 2098 	mov	dptr,#0x0000
                                   2099 ;	quantum/dynamic_keymap.c:528: }
      008BB3 22               [24] 2100 	ret
                                   2101 ;------------------------------------------------------------
                                   2102 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2103 ;------------------------------------------------------------
                                   2104 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2105 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2106 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_439'
                                   2107 ;------------------------------------------------------------
                                   2108 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2109 ;	-----------------------------------------
                                   2110 ;	 function keycode_at_encodermap_location
                                   2111 ;	-----------------------------------------
      008BB4                       2112 _keycode_at_encodermap_location:
      008BB4 E5 82            [12] 2113 	mov	a,dpl
      008BB6 90 0B 25         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_439
      008BB9 F0               [24] 2115 	movx	@dptr,a
                                   2116 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008BBA E0               [24] 2117 	movx	a,@dptr
      008BBB FF               [12] 2118 	mov	r7,a
      008BBC BF 06 00         [24] 2119 	cjne	r7,#0x06,00120$
      008BBF                       2120 00120$:
      008BBF 50 1E            [24] 2121 	jnc	00102$
      008BC1 90 0B 23         [24] 2122 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008BC4 E0               [24] 2123 	movx	a,@dptr
      008BC5 FE               [12] 2124 	mov	r6,a
      008BC6 BE 01 00         [24] 2125 	cjne	r6,#0x01,00122$
      008BC9                       2126 00122$:
      008BC9 50 14            [24] 2127 	jnc	00102$
                                   2128 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008BCB 90 0B 24         [24] 2129 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008BCE E0               [24] 2130 	movx	a,@dptr
      008BCF FE               [12] 2131 	mov	r6,a
      008BD0 90 0A DE         [24] 2132 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008BD3 E4               [12] 2133 	clr	a
      008BD4 F0               [24] 2134 	movx	@dptr,a
      008BD5 90 0A DF         [24] 2135 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008BD8 EE               [12] 2136 	mov	a,r6
      008BD9 F0               [24] 2137 	movx	@dptr,a
      008BDA 8F 82            [24] 2138 	mov	dpl, r7
      008BDC 02 85 DA         [24] 2139 	ljmp	_dynamic_keymap_get_encoder
      008BDF                       2140 00102$:
                                   2141 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008BDF 90 00 00         [24] 2142 	mov	dptr,#0x0000
                                   2143 ;	quantum/dynamic_keymap.c:536: }
      008BE2 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_count
                                   2151 ;	-----------------------------------------
      008BE3                       2152 _dynamic_keymap_macro_get_count:
                                   2153 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008BE3 75 82 10         [24] 2154 	mov	dpl, #0x10
                                   2155 ;	quantum/dynamic_keymap.c:541: }
      008BE6 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2159 ;------------------------------------------------------------
                                   2160 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2161 ;	-----------------------------------------
                                   2162 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2163 ;	-----------------------------------------
      008BE7                       2164 _dynamic_keymap_macro_get_buffer_size:
                                   2165 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008BE7 90 20 00         [24] 2166 	mov	dptr,#0x2000
                                   2167 ;	quantum/dynamic_keymap.c:545: }
      008BEA 22               [24] 2168 	ret
                                   2169 ;------------------------------------------------------------
                                   2170 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2171 ;------------------------------------------------------------
                                   2172 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2173 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2174 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2175 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_447'
                                   2176 ;------------------------------------------------------------
                                   2177 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2178 ;	-----------------------------------------
                                   2179 ;	 function dynamic_keymap_macro_get_buffer
                                   2180 ;	-----------------------------------------
      008BEB                       2181 _dynamic_keymap_macro_get_buffer:
      008BEB 12 39 03         [24] 2182 	lcall	_ak820_outline_0122
      008BEE 90 0B 2B         [24] 2183 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_447
      008BF1 12 38 FE         [24] 2184 	lcall	_ak820_outline_0121
                                   2185 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008BF4 12 2B 2B         [24] 2186 	lcall	_ak820_macro_length
      008BF7 12 43 D5         [24] 2187 	lcall	_ak820_outline_0131
      008BFA 90 0B 2B         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_447
      008BFD 12 38 DA         [24] 2189 	lcall	_ak820_outline_0076
      008C00 90 0B 26         [24] 2190 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008C03 E0               [24] 2191 	movx	a,@dptr
      008C04 F5 32            [12] 2192 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008C06 A3               [24] 2193 	inc	dptr
      008C07 E0               [24] 2194 	movx	a,@dptr
      008C08 F5 33            [12] 2195 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008C0A 90 0B 28         [24] 2196 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008C0D 12 38 F8         [24] 2197 	lcall	_ak820_outline_0109
      008C10 A3               [24] 2198 	inc	dptr
      008C11 E0               [24] 2199 	movx	a,@dptr
      008C12 FB               [12] 2200 	mov	r3,a
      008C13 90 0B 03         [24] 2201 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C16 12 48 F9         [24] 2202 	lcall	_ak820_outline_0068
      008C19 90 0B 05         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C1C 12 38 E6         [24] 2204 	lcall	_ak820_outline_0087
      008C1F 90 0B 07         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C22 E5 32            [12] 2206 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008C24 F0               [24] 2207 	movx	@dptr,a
      008C25 E5 33            [12] 2208 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008C27 A3               [24] 2209 	inc	dptr
      008C28 F0               [24] 2210 	movx	@dptr,a
      008C29 90 0B 09         [24] 2211 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C2C E8               [12] 2212 	mov	a,r0
      008C2D F0               [24] 2213 	movx	@dptr,a
      008C2E E9               [12] 2214 	mov	a,r1
      008C2F A3               [24] 2215 	inc	dptr
      008C30 12 78 22         [24] 2216 	lcall	_ak820_outline_0194
      008C33 90 08 00         [24] 2217 	mov	dptr,#0x0800
                                   2218 ;	quantum/dynamic_keymap.c:572: }
      008C36 02 88 F9         [24] 2219 	ljmp	_ak820_dynamic_read_buffer
                                   2220 ;------------------------------------------------------------
                                   2221 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2222 ;------------------------------------------------------------
                                   2223 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2224 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2225 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_449'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function dynamic_keymap_macro_set_buffer
                                   2230 ;	-----------------------------------------
      008C39                       2231 _dynamic_keymap_macro_set_buffer:
      008C39 12 39 03         [24] 2232 	lcall	_ak820_outline_0122
      008C3C 90 0B 32         [24] 2233 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_449
      008C3F 12 38 FE         [24] 2234 	lcall	_ak820_outline_0121
                                   2235 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008C42 90 0B 32         [24] 2236 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_449
      008C45 12 38 C3         [24] 2237 	lcall	_ak820_outline_0060
      008C48 90 0B 2D         [24] 2238 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008C4B 12 38 DA         [24] 2239 	lcall	_ak820_outline_0076
      008C4E 90 0B 2F         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008C51 12 4F 9A         [24] 2241 	lcall	_ak820_outline_0098
      008C54 90 05 0D         [24] 2242 	mov	dptr,#_ak820_macro_write_PARM_2
      008C57 12 38 E6         [24] 2243 	lcall	_ak820_outline_0087
      008C5A 90 05 0F         [24] 2244 	mov	dptr,#_ak820_macro_write_PARM_3
      008C5D E9               [12] 2245 	mov	a,r1
      008C5E 12 4F AC         [24] 2246 	lcall	_ak820_outline_0119
      008C61 12 43 AB         [24] 2247 	lcall	_ak820_outline_0088
                                   2248 ;	quantum/dynamic_keymap.c:577: }
      008C64 02 2B 45         [24] 2249 	ljmp	_ak820_macro_write
                                   2250 ;------------------------------------------------------------
                                   2251 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2252 ;------------------------------------------------------------
                                   2253 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2254 ;	-----------------------------------------
                                   2255 ;	 function dynamic_keymap_macro_reset
                                   2256 ;	-----------------------------------------
      008C67                       2257 _dynamic_keymap_macro_reset:
                                   2258 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2259 ;	quantum/dynamic_keymap.c:603: }
      008C67 02 2E 64         [24] 2260 	ljmp	_ak820_macro_reset
                                   2261 ;------------------------------------------------------------
                                   2262 ;Allocation info for local variables in function 'decode_keycode'
                                   2263 ;------------------------------------------------------------
                                   2264 ;kc            Allocated with name '_decode_keycode_kc_10000_453'
                                   2265 ;------------------------------------------------------------
                                   2266 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2267 ;	-----------------------------------------
                                   2268 ;	 function decode_keycode
                                   2269 ;	-----------------------------------------
      008C6A                       2270 _decode_keycode:
      008C6A 12 39 03         [24] 2271 	lcall	_ak820_outline_0122
      008C6D 90 0B 34         [24] 2272 	mov	dptr,#_decode_keycode_kc_10000_453
      008C70 12 38 FE         [24] 2273 	lcall	_ak820_outline_0121
                                   2274 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008C73 90 0B 34         [24] 2275 	mov	dptr,#_decode_keycode_kc_10000_453
      008C76 12 48 9E         [24] 2276 	lcall	_ak820_outline_0013
      008C79 C3               [12] 2277 	clr	c
      008C7A E4               [12] 2278 	clr	a
      008C7B 9C               [12] 2279 	subb	a,r4
      008C7C 74 FF            [12] 2280 	mov	a,#0xff
      008C7E 9D               [12] 2281 	subb	a,r5
      008C7F 50 08            [24] 2282 	jnc	00102$
                                   2283 ;	free result
                                   2284 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008C81 8C 05            [24] 2285 	mov	ar5,r4
      008C83 7C 00            [12] 2286 	mov	r4,#0x00
      008C85 12 34 76         [24] 2287 	lcall	_ak820_outline_0132
      008C88 22               [24] 2288 	ret
      008C89                       2289 00102$:
                                   2290 ;	quantum/dynamic_keymap.c:609: return kc;
      008C89 12 39 08         [24] 2291 	lcall	_ak820_outline_0123
                                   2292 ;	quantum/dynamic_keymap.c:610: }
      008C8C 22               [24] 2293 	ret
                                   2294 ;------------------------------------------------------------
                                   2295 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2296 ;------------------------------------------------------------
                                   2297 ;sloc0         Allocated with name '_dynamic_keymap_macro_send_sloc0_1_0'
                                   2298 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_456'
                                   2299 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_457'
                                   2300 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_462'
                                   2301 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_463'
                                   2302 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_469'
                                   2303 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_487'
                                   2304 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_491'
                                   2305 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_491'
                                   2306 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_493'
                                   2307 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_495'
                                   2308 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_499'
                                   2309 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_501'
                                   2310 ;------------------------------------------------------------
                                   2311 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2312 ;	-----------------------------------------
                                   2313 ;	 function dynamic_keymap_macro_send
                                   2314 ;	-----------------------------------------
      008C8D                       2315 _dynamic_keymap_macro_send:
      008C8D E5 82            [12] 2316 	mov	a,dpl
      008C8F 90 0B 36         [24] 2317 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008C92 F0               [24] 2318 	movx	@dptr,a
                                   2319 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008C93 90 0B 37         [24] 2320 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008C96 E0               [24] 2321 	movx	a,@dptr
      008C97 60 01            [24] 2322 	jz	00102$
      008C99 22               [24] 2323 	ret
      008C9A                       2324 00102$:
                                   2325 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008C9A 90 0B 36         [24] 2326 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008C9D E0               [24] 2327 	movx	a,@dptr
      008C9E FF               [12] 2328 	mov	r7,a
      008C9F BF 10 00         [24] 2329 	cjne	r7,#0x10,00422$
      008CA2                       2330 00422$:
      008CA2 40 01            [24] 2331 	jc	00104$
                                   2332 ;	quantum/dynamic_keymap.c:620: return;
      008CA4 22               [24] 2333 	ret
      008CA5                       2334 00104$:
                                   2335 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008CA5 C0 07            [24] 2336 	push	ar7
      008CA7 12 2A F2         [24] 2337 	lcall	_ak820_macro_ready
      008CAA E5 82            [12] 2338 	mov	a, dpl
      008CAC D0 07            [24] 2339 	pop	ar7
      008CAE 70 01            [24] 2340 	jnz	00106$
      008CB0 22               [24] 2341 	ret
      008CB1                       2342 00106$:
                                   2343 ;	quantum/dynamic_keymap.c:641: p         = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR);
      008CB1 90 0B 38         [24] 2344 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008CB4 E4               [12] 2345 	clr	a
      008CB5 F0               [24] 2346 	movx	@dptr,a
      008CB6 74 08            [12] 2347 	mov	a,#0x08
      008CB8 12 38 E0         [24] 2348 	lcall	_ak820_outline_0081
                                   2349 ;	quantum/dynamic_keymap.c:643: uint8_t *end = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length());
      008CBB C0 07            [24] 2350 	push	ar7
      008CBD 12 2B 2B         [24] 2351 	lcall	_ak820_macro_length
      008CC0 AD 82            [24] 2352 	mov	r5, dpl
      008CC2 AE 83            [24] 2353 	mov	r6, dph
      008CC4 D0 07            [24] 2354 	pop	ar7
      008CC6 74 08            [12] 2355 	mov	a,#0x08
      008CC8 2E               [12] 2356 	add	a, r6
      008CC9 FE               [12] 2357 	mov	r6,a
      008CCA 8D 34            [24] 2358 	mov	_dynamic_keymap_macro_send_sloc0_1_0,r5
      008CCC 8E 35            [24] 2359 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 1),r6
      008CCE 75 36 00         [24] 2360 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 2),#0x00
                                   2361 ;	quantum/dynamic_keymap.c:647: while (id > 0) {
      008CD1 79 00            [12] 2362 	mov	r1,#0x00
      008CD3 7A 08            [12] 2363 	mov	r2,#0x08
      008CD5 7B 00            [12] 2364 	mov	r3,#0x00
      008CD7                       2365 00111$:
      008CD7 EF               [12] 2366 	mov	a,r7
      008CD8 60 34            [24] 2367 	jz	00113$
                                   2368 ;	quantum/dynamic_keymap.c:651: if (p == end) {
      008CDA C0 34            [24] 2369 	push	_dynamic_keymap_macro_send_sloc0_1_0
      008CDC C0 35            [24] 2370 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      008CDE C0 36            [24] 2371 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      008CE0 12 8F 70         [24] 2372 	lcall	_ak820_outline_0114
      008CE3 12 30 77         [24] 2373 	lcall	___gptr_cmp
      008CE6 15 81            [12] 2374 	dec	sp
      008CE8 15 81            [12] 2375 	dec	sp
      008CEA 15 81            [12] 2376 	dec	sp
      008CEC 70 01            [24] 2377 	jnz	00108$
                                   2378 ;	quantum/dynamic_keymap.c:652: return;
      008CEE 22               [24] 2379 	ret
      008CEF                       2380 00108$:
                                   2381 ;	quantum/dynamic_keymap.c:654: if (eeprom_read_byte(p) == 0) {
      008CEF 12 8F 70         [24] 2382 	lcall	_ak820_outline_0114
      008CF2 12 40 E1         [24] 2383 	lcall	_eeprom_read_byte
      008CF5 E5 82            [12] 2384 	mov	a, dpl
      008CF7 70 06            [24] 2385 	jnz	00110$
                                   2386 ;	quantum/dynamic_keymap.c:655: --id;
      008CF9 1F               [12] 2387 	dec	r7
      008CFA 90 0B 36         [24] 2388 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_456
      008CFD EF               [12] 2389 	mov	a,r7
      008CFE F0               [24] 2390 	movx	@dptr,a
      008CFF                       2391 00110$:
                                   2392 ;	quantum/dynamic_keymap.c:657: ++p;
      008CFF 09               [12] 2393 	inc	r1
      008D00 B9 00 01         [24] 2394 	cjne	r1,#0x00,00429$
      008D03 0A               [12] 2395 	inc	r2
      008D04                       2396 00429$:
      008D04 90 0B 38         [24] 2397 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008D07 E9               [12] 2398 	mov	a,r1
      008D08 12 4F AC         [24] 2399 	lcall	_ak820_outline_0119
      008D0B F0               [24] 2400 	movx	@dptr,a
      008D0C 80 C9            [24] 2401 	sjmp	00111$
      008D0E                       2402 00113$:
                                   2403 ;	quantum/dynamic_keymap.c:663: sending = true;
      008D0E 90 0B 37         [24] 2404 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008D11 74 01            [12] 2405 	mov	a,#0x01
      008D13 F0               [24] 2406 	movx	@dptr,a
                                   2407 ;	quantum/dynamic_keymap.c:665: ak820_macro_cancelled = ak820_macro_primitive = false;
      008D14 12 8F 96         [24] 2408 	lcall	_ak820_outline_0169
      008D17 90 09 80         [24] 2409 	mov	dptr,#_ak820_macro_cancelled
      008D1A F0               [24] 2410 	movx	@dptr,a
                                   2411 ;	quantum/dynamic_keymap.c:670: char data[4] = {0, 0, 0, 0};
      008D1B 90 0B 3B         [24] 2412 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008D1E F0               [24] 2413 	movx	@dptr,a
      008D1F 90 0B 3C         [24] 2414 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008D22 F0               [24] 2415 	movx	@dptr,a
      008D23 90 0B 3D         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0002)
      008D26 F0               [24] 2417 	movx	@dptr,a
      008D27 90 0B 3E         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008D2A F0               [24] 2419 	movx	@dptr,a
                                   2420 ;	quantum/dynamic_keymap.c:673: while (p < end
      008D2B                       2421 00167$:
                                   2422 ;	quantum/dynamic_keymap.c:675: && !ak820_macro_cancelled
      008D2B 90 0B 38         [24] 2423 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008D2E 12 43 B7         [24] 2424 	lcall	_ak820_outline_0110
      008D31 A3               [24] 2425 	inc	dptr
      008D32 E0               [24] 2426 	movx	a,@dptr
      008D33 FF               [12] 2427 	mov	r7,a
      008D34 A8 34            [24] 2428 	mov	r0,_dynamic_keymap_macro_send_sloc0_1_0
      008D36 A9 35            [24] 2429 	mov	r1,(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      008D38 AE 36            [24] 2430 	mov	r6,(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      008D3A C0 00            [24] 2431 	push	ar0
      008D3C C0 01            [24] 2432 	push	ar1
      008D3E C0 06            [24] 2433 	push	ar6
      008D40 12 39 12         [24] 2434 	lcall	_ak820_outline_0140
      008D43 8F F0            [24] 2435 	mov	b,r7
      008D45 12 30 77         [24] 2436 	lcall	___gptr_cmp
      008D48 15 81            [12] 2437 	dec	sp
      008D4A 15 81            [12] 2438 	dec	sp
      008D4C 15 81            [12] 2439 	dec	sp
      008D4E 40 03            [24] 2440 	jc	00430$
      008D50 02 8F 20         [24] 2441 	ljmp	00169$
      008D53                       2442 00430$:
      008D53 90 09 80         [24] 2443 	mov	dptr,#_ak820_macro_cancelled
      008D56 E0               [24] 2444 	movx	a,@dptr
      008D57 60 03            [24] 2445 	jz	00431$
      008D59 02 8F 20         [24] 2446 	ljmp	00169$
      008D5C                       2447 00431$:
                                   2448 ;	quantum/dynamic_keymap.c:678: data[0] = eeprom_read_byte(p++);
      008D5C 8A 04            [24] 2449 	mov	ar4,r2
      008D5E 8B 05            [24] 2450 	mov	ar5,r3
      008D60 8F 06            [24] 2451 	mov	ar6,r7
      008D62 90 0B 38         [24] 2452 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008D65 74 01            [12] 2453 	mov	a,#0x01
      008D67 2A               [12] 2454 	add	a, r2
      008D68 F0               [24] 2455 	movx	@dptr,a
      008D69 E4               [12] 2456 	clr	a
      008D6A 3B               [12] 2457 	addc	a, r3
      008D6B A3               [24] 2458 	inc	dptr
      008D6C 12 38 FE         [24] 2459 	lcall	_ak820_outline_0121
      008D6F 12 4F 93         [24] 2460 	lcall	_ak820_outline_0073
      008D72 12 40 E1         [24] 2461 	lcall	_eeprom_read_byte
      008D75 AF 82            [24] 2462 	mov	r7, dpl
      008D77 90 0B 3B         [24] 2463 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008D7A EF               [12] 2464 	mov	a,r7
      008D7B F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	quantum/dynamic_keymap.c:679: data[1] = 0;
      008D7C 90 0B 3C         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008D7F E4               [12] 2468 	clr	a
      008D80 F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:681: if (data[0] == 0) {
      008D81 90 0B 3B         [24] 2471 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008D84 E0               [24] 2472 	movx	a,@dptr
      008D85 70 03            [24] 2473 	jnz	00432$
      008D87 02 8F 20         [24] 2474 	ljmp	00169$
      008D8A                       2475 00432$:
                                   2476 ;	quantum/dynamic_keymap.c:684: if (data[0] == SS_QMK_PREFIX) {
      008D8A 90 0B 3B         [24] 2477 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008D8D E0               [24] 2478 	movx	a,@dptr
      008D8E FF               [12] 2479 	mov	r7,a
      008D8F BF 01 02         [24] 2480 	cjne	r7,#0x01,00433$
      008D92 80 03            [24] 2481 	sjmp	00434$
      008D94                       2482 00433$:
      008D94 02 8F 0A         [24] 2483 	ljmp	00164$
      008D97                       2484 00434$:
                                   2485 ;	quantum/dynamic_keymap.c:687: data[1] = eeprom_read_byte(p++);
      008D97 12 8F 28         [24] 2486 	lcall	_ak820_outline_0000
      008D9A 12 40 E1         [24] 2487 	lcall	_eeprom_read_byte
      008D9D AF 82            [24] 2488 	mov	r7, dpl
      008D9F 90 0B 3C         [24] 2489 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008DA2 EF               [12] 2490 	mov	a,r7
      008DA3 F0               [24] 2491 	movx	@dptr,a
                                   2492 ;	quantum/dynamic_keymap.c:688: if (data[1] == 0)
      008DA4 EF               [12] 2493 	mov	a,r7
      008DA5 70 03            [24] 2494 	jnz	00435$
      008DA7 02 8F 20         [24] 2495 	ljmp	00169$
      008DAA                       2496 00435$:
                                   2497 ;	quantum/dynamic_keymap.c:690: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008DAA 12 8F 56         [24] 2498 	lcall	_ak820_outline_0100
      008DAD BF 01 02         [24] 2499 	cjne	r7,#0x01,00436$
      008DB0 80 12            [24] 2500 	sjmp	00151$
      008DB2                       2501 00436$:
      008DB2 12 8F 56         [24] 2502 	lcall	_ak820_outline_0100
      008DB5 BF 02 02         [24] 2503 	cjne	r7,#0x02,00437$
      008DB8 80 0A            [24] 2504 	sjmp	00151$
      008DBA                       2505 00437$:
      008DBA 12 8F 56         [24] 2506 	lcall	_ak820_outline_0100
      008DBD BF 03 02         [24] 2507 	cjne	r7,#0x03,00438$
      008DC0 80 02            [24] 2508 	sjmp	00439$
      008DC2                       2509 00438$:
      008DC2 80 49            [24] 2510 	sjmp	00152$
      008DC4                       2511 00439$:
      008DC4                       2512 00151$:
                                   2513 ;	quantum/dynamic_keymap.c:692: data[2] = eeprom_read_byte(p++);
      008DC4 12 8F 28         [24] 2514 	lcall	_ak820_outline_0000
      008DC7 12 40 E1         [24] 2515 	lcall	_eeprom_read_byte
      008DCA 12 8F AE         [24] 2516 	lcall	_ak820_outline_0189
                                   2517 ;	quantum/dynamic_keymap.c:696: if (data[2] != 0) {
      008DCD 70 03            [24] 2518 	jnz	00440$
      008DCF 02 8D 2B         [24] 2519 	ljmp	00167$
      008DD2                       2520 00440$:
                                   2521 ;	quantum/dynamic_keymap.c:698: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008DD2 12 8F 56         [24] 2522 	lcall	_ak820_outline_0100
      008DD5 BF 01 03         [24] 2523 	cjne	r7,#0x01,00441$
      008DD8 D3               [12] 2524 	setb	c
      008DD9 80 01            [24] 2525 	sjmp	00442$
      008DDB                       2526 00441$:
      008DDB C3               [12] 2527 	clr	c
      008DDC                       2528 00442$:
      008DDC 92 24            [24] 2529 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      008DDE 90 09 7F         [24] 2530 	mov	dptr,#_ak820_macro_primitive
      008DE1 B3               [12] 2531 	cpl	c
      008DE2 E4               [12] 2532 	clr	a
      008DE3 33               [12] 2533 	rlc	a
      008DE4 F0               [24] 2534 	movx	@dptr,a
                                   2535 ;	quantum/dynamic_keymap.c:700: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008DE5 12 8F 56         [24] 2536 	lcall	_ak820_outline_0100
      008DE8 BF 01 08         [24] 2537 	cjne	r7,#0x01,00122$
      008DEB 12 8F 8F         [24] 2538 	lcall	_ak820_outline_0159
      008DEE 12 76 F4         [24] 2539 	lcall	_tap_code
      008DF1 80 14            [24] 2540 	sjmp	00123$
      008DF3                       2541 00122$:
                                   2542 ;	quantum/dynamic_keymap.c:701: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008DF3 12 8F 56         [24] 2543 	lcall	_ak820_outline_0100
      008DF6 BF 02 08         [24] 2544 	cjne	r7,#0x02,00119$
      008DF9 12 8F 8F         [24] 2545 	lcall	_ak820_outline_0159
      008DFC 12 75 EE         [24] 2546 	lcall	_register_code
      008DFF 80 06            [24] 2547 	sjmp	00123$
      008E01                       2548 00119$:
                                   2549 ;	quantum/dynamic_keymap.c:702: else unregister_code((uint8_t)data[2]);
      008E01 12 8F 8F         [24] 2550 	lcall	_ak820_outline_0159
      008E04 12 76 5B         [24] 2551 	lcall	_unregister_code
      008E07                       2552 00123$:
                                   2553 ;	quantum/dynamic_keymap.c:704: ak820_macro_primitive = false;
      008E07 12 8F 96         [24] 2554 	lcall	_ak820_outline_0169
      008E0A 02 8D 2B         [24] 2555 	ljmp	00167$
      008E0D                       2556 00152$:
                                   2557 ;	quantum/dynamic_keymap.c:712: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008E0D 12 8F 56         [24] 2558 	lcall	_ak820_outline_0100
      008E10 BF 05 02         [24] 2559 	cjne	r7,#0x05,00447$
      008E13 80 13            [24] 2560 	sjmp	00146$
      008E15                       2561 00447$:
      008E15 12 8F 56         [24] 2562 	lcall	_ak820_outline_0100
      008E18 BF 06 02         [24] 2563 	cjne	r7,#0x06,00448$
      008E1B 80 0B            [24] 2564 	sjmp	00146$
      008E1D                       2565 00448$:
      008E1D 12 8F 56         [24] 2566 	lcall	_ak820_outline_0100
      008E20 BF 07 02         [24] 2567 	cjne	r7,#0x07,00449$
      008E23 80 03            [24] 2568 	sjmp	00450$
      008E25                       2569 00449$:
      008E25 02 8E AB         [24] 2570 	ljmp	00147$
      008E28                       2571 00450$:
      008E28                       2572 00146$:
                                   2573 ;	quantum/dynamic_keymap.c:713: data[2] = eeprom_read_byte(p++);
      008E28 12 8F 28         [24] 2574 	lcall	_ak820_outline_0000
      008E2B 12 40 E1         [24] 2575 	lcall	_eeprom_read_byte
      008E2E 12 8F AE         [24] 2576 	lcall	_ak820_outline_0189
                                   2577 ;	quantum/dynamic_keymap.c:714: if (data[2] != 0) {
      008E31 70 03            [24] 2578 	jnz	00451$
      008E33 02 8D 2B         [24] 2579 	ljmp	00167$
      008E36                       2580 00451$:
                                   2581 ;	quantum/dynamic_keymap.c:715: data[3] = eeprom_read_byte(p++);
      008E36 12 8F 28         [24] 2582 	lcall	_ak820_outline_0000
      008E39 12 40 E1         [24] 2583 	lcall	_eeprom_read_byte
      008E3C AF 82            [24] 2584 	mov	r7, dpl
      008E3E 90 0B 3E         [24] 2585 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008E41 EF               [12] 2586 	mov	a,r7
      008E42 F0               [24] 2587 	movx	@dptr,a
                                   2588 ;	quantum/dynamic_keymap.c:716: if (data[3] != 0) {
      008E43 EF               [12] 2589 	mov	a,r7
      008E44 70 03            [24] 2590 	jnz	00452$
      008E46 02 8D 2B         [24] 2591 	ljmp	00167$
      008E49                       2592 00452$:
                                   2593 ;	quantum/dynamic_keymap.c:719: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008E49 90 0B 3D         [24] 2594 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0002)
      008E4C E0               [24] 2595 	movx	a,@dptr
      008E4D FF               [12] 2596 	mov	r7,a
      008E4E 90 0B 3E         [24] 2597 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0003)
      008E51 E0               [24] 2598 	movx	a,@dptr
      008E52 FD               [12] 2599 	mov	r5,a
      008E53 E4               [12] 2600 	clr	a
      008E54 FE               [12] 2601 	mov	r6,a
      008E55 FC               [12] 2602 	mov	r4,a
      008E56 EF               [12] 2603 	mov	a,r7
      008E57 42 06            [12] 2604 	orl	ar6,a
      008E59 EC               [12] 2605 	mov	a,r4
      008E5A 42 05            [12] 2606 	orl	ar5,a
                                   2607 ;	quantum/dynamic_keymap.c:723: kc = decode_keycode(kc);
      008E5C 8E 82            [24] 2608 	mov	dpl, r6
      008E5E 8D 83            [24] 2609 	mov	dph, r5
      008E60 12 8C 6A         [24] 2610 	lcall	_decode_keycode
      008E63 12 43 D5         [24] 2611 	lcall	_ak820_outline_0131
                                   2612 ;	quantum/dynamic_keymap.c:725: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008E66 90 0B 3C         [24] 2613 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008E69 E0               [24] 2614 	movx	a,@dptr
      008E6A FD               [12] 2615 	mov	r5,a
      008E6B BD 05 03         [24] 2616 	cjne	r5,#0x05,00453$
      008E6E D3               [12] 2617 	setb	c
      008E6F 80 01            [24] 2618 	sjmp	00454$
      008E71                       2619 00453$:
      008E71 C3               [12] 2620 	clr	c
      008E72                       2621 00454$:
      008E72 92 24            [24] 2622 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      008E74 90 09 7F         [24] 2623 	mov	dptr,#_ak820_macro_primitive
      008E77 B3               [12] 2624 	cpl	c
      008E78 E4               [12] 2625 	clr	a
      008E79 33               [12] 2626 	rlc	a
      008E7A F0               [24] 2627 	movx	@dptr,a
                                   2628 ;	quantum/dynamic_keymap.c:727: switch (data[1]) {
      008E7B 90 0B 3C         [24] 2629 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469 + 0x0001)
      008E7E E0               [24] 2630 	movx	a,@dptr
      008E7F FD               [12] 2631 	mov	r5,a
      008E80 BD 05 02         [24] 2632 	cjne	r5,#0x05,00455$
      008E83 80 0A            [24] 2633 	sjmp	00126$
      008E85                       2634 00455$:
      008E85 BD 06 02         [24] 2635 	cjne	r5,#0x06,00456$
      008E88 80 0D            [24] 2636 	sjmp	00127$
      008E8A                       2637 00456$:
                                   2638 ;	quantum/dynamic_keymap.c:728: case VIAL_MACRO_EXT_TAP:
      008E8A BD 07 18         [24] 2639 	cjne	r5,#0x07,00129$
      008E8D 80 10            [24] 2640 	sjmp	00128$
      008E8F                       2641 00126$:
                                   2642 ;	quantum/dynamic_keymap.c:729: vial_keycode_tap(kc);
      008E8F 12 39 08         [24] 2643 	lcall	_ak820_outline_0123
      008E92 12 B5 FC         [24] 2644 	lcall	_vial_keycode_tap
                                   2645 ;	quantum/dynamic_keymap.c:730: break;
                                   2646 ;	quantum/dynamic_keymap.c:731: case VIAL_MACRO_EXT_DOWN:
      008E95 80 0E            [24] 2647 	sjmp	00129$
      008E97                       2648 00127$:
                                   2649 ;	quantum/dynamic_keymap.c:732: vial_keycode_down(kc);
      008E97 12 39 08         [24] 2650 	lcall	_ak820_outline_0123
      008E9A 12 B5 1B         [24] 2651 	lcall	_vial_keycode_down
                                   2652 ;	quantum/dynamic_keymap.c:733: break;
                                   2653 ;	quantum/dynamic_keymap.c:734: case VIAL_MACRO_EXT_UP:
      008E9D 80 06            [24] 2654 	sjmp	00129$
      008E9F                       2655 00128$:
                                   2656 ;	quantum/dynamic_keymap.c:735: vial_keycode_up(kc);
      008E9F 12 39 08         [24] 2657 	lcall	_ak820_outline_0123
      008EA2 12 B5 8C         [24] 2658 	lcall	_vial_keycode_up
                                   2659 ;	quantum/dynamic_keymap.c:737: }
      008EA5                       2660 00129$:
                                   2661 ;	quantum/dynamic_keymap.c:739: ak820_macro_primitive = false;
      008EA5 12 8F 96         [24] 2662 	lcall	_ak820_outline_0169
      008EA8 02 8D 2B         [24] 2663 	ljmp	00167$
      008EAB                       2664 00147$:
                                   2665 ;	quantum/dynamic_keymap.c:743: } else if (data[1] == SS_DELAY_CODE) {
      008EAB 12 8F 56         [24] 2666 	lcall	_ak820_outline_0100
      008EAE BF 04 02         [24] 2667 	cjne	r7,#0x04,00458$
      008EB1 80 03            [24] 2668 	sjmp	00459$
      008EB3                       2669 00458$:
      008EB3 02 8D 2B         [24] 2670 	ljmp	00167$
      008EB6                       2671 00459$:
                                   2672 ;	quantum/dynamic_keymap.c:745: uint8_t d0 = eeprom_read_byte(p++);
      008EB6 12 8F 28         [24] 2673 	lcall	_ak820_outline_0000
      008EB9 12 40 E1         [24] 2674 	lcall	_eeprom_read_byte
      008EBC AF 82            [24] 2675 	mov	r7, dpl
                                   2676 ;	quantum/dynamic_keymap.c:746: uint8_t d1 = eeprom_read_byte(p++);
      008EBE 90 0B 38         [24] 2677 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008EC1 12 4F 72         [24] 2678 	lcall	_ak820_outline_0044
      008EC4 90 0B 38         [24] 2679 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008EC7 74 01            [12] 2680 	mov	a,#0x01
      008EC9 2C               [12] 2681 	add	a, r4
      008ECA F0               [24] 2682 	movx	@dptr,a
      008ECB E4               [12] 2683 	clr	a
      008ECC 3D               [12] 2684 	addc	a, r5
      008ECD A3               [24] 2685 	inc	dptr
      008ECE F0               [24] 2686 	movx	@dptr,a
      008ECF EE               [12] 2687 	mov	a,r6
      008ED0 A3               [24] 2688 	inc	dptr
      008ED1 F0               [24] 2689 	movx	@dptr,a
      008ED2 12 4F 93         [24] 2690 	lcall	_ak820_outline_0073
      008ED5 12 40 E1         [24] 2691 	lcall	_eeprom_read_byte
      008ED8 AE 82            [24] 2692 	mov	r6, dpl
                                   2693 ;	quantum/dynamic_keymap.c:747: if (d0 == 0 || d1 == 0)
      008EDA EF               [12] 2694 	mov	a,r7
      008EDB 60 43            [24] 2695 	jz	00169$
      008EDD EE               [12] 2696 	mov	a,r6
      008EDE 60 40            [24] 2697 	jz	00169$
                                   2698 ;	quantum/dynamic_keymap.c:750: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008EE0 1F               [12] 2699 	dec	r7
      008EE1 1E               [12] 2700 	dec	r6
      008EE2 EE               [12] 2701 	mov	a,r6
      008EE3 75 F0 FF         [24] 2702 	mov	b,#0xff
      008EE6 A4               [48] 2703 	mul	ab
      008EE7 FE               [12] 2704 	mov	r6,a
      008EE8 AD F0            [24] 2705 	mov	r5,b
      008EEA 7C 00            [12] 2706 	mov	r4,#0x00
      008EEC EE               [12] 2707 	mov	a,r6
      008EED 2F               [12] 2708 	add	a, r7
      008EEE FE               [12] 2709 	mov	r6,a
      008EEF ED               [12] 2710 	mov	a,r5
      008EF0 3C               [12] 2711 	addc	a, r4
      008EF1 FD               [12] 2712 	mov	r5,a
                                   2713 ;	quantum/dynamic_keymap.c:751: while (ms--) wait_ms(1);
      008EF2                       2714 00141$:
      008EF2 8E 04            [24] 2715 	mov	ar4,r6
      008EF4 8D 07            [24] 2716 	mov	ar7,r5
      008EF6 1E               [12] 2717 	dec	r6
      008EF7 BE FF 01         [24] 2718 	cjne	r6,#0xff,00462$
      008EFA 1D               [12] 2719 	dec	r5
      008EFB                       2720 00462$:
      008EFB EC               [12] 2721 	mov	a,r4
      008EFC 4F               [12] 2722 	orl	a,r7
      008EFD 70 03            [24] 2723 	jnz	00463$
      008EFF 02 8D 2B         [24] 2724 	ljmp	00167$
      008F02                       2725 00463$:
      008F02 90 00 01         [24] 2726 	mov	dptr,#0x0001
      008F05 12 59 96         [24] 2727 	lcall	_mDelaymS
      008F08 80 E8            [24] 2728 	sjmp	00141$
      008F0A                       2729 00164$:
                                   2730 ;	quantum/dynamic_keymap.c:757: if ((uint8_t)data[0] >= 128) break;
      008F0A 90 0B 3B         [24] 2731 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008F0D E0               [24] 2732 	movx	a,@dptr
      008F0E FF               [12] 2733 	mov	r7,a
      008F0F BF 80 00         [24] 2734 	cjne	r7,#0x80,00464$
      008F12                       2735 00464$:
      008F12 50 0C            [24] 2736 	jnc	00169$
                                   2737 ;	quantum/dynamic_keymap.c:761: send_char(data[0]);
      008F14 90 0B 3B         [24] 2738 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_469
      008F17 E0               [24] 2739 	movx	a,@dptr
      008F18 F5 82            [12] 2740 	mov	dpl,a
      008F1A 12 A8 80         [24] 2741 	lcall	_send_char
                                   2742 ;	quantum/dynamic_keymap.c:762: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008F1D 02 8D 2B         [24] 2743 	ljmp	00167$
      008F20                       2744 00169$:
                                   2745 ;	quantum/dynamic_keymap.c:770: ak820_macro_primitive = false;
      008F20 12 8F 96         [24] 2746 	lcall	_ak820_outline_0169
                                   2747 ;	quantum/dynamic_keymap.c:772: sending = false;
      008F23 90 0B 37         [24] 2748 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_457
      008F26 F0               [24] 2749 	movx	@dptr,a
                                   2750 ;	quantum/dynamic_keymap.c:774: }
      008F27 22               [24] 2751 	ret
                                   2752 	.area CSEG    (CODE)
                                   2753 	.area CONST   (CODE)
                                   2754 	.area XINIT   (CODE)
                                   2755 	.area CABS    (ABS,CODE)
                                   2756 
                                   2757 ; Experimental exact instruction outlining.
                                   2758 	.globl _ak820_outline_0000
                                   2759 	.globl _ak820_outline_0010
                                   2760 	.globl _ak820_outline_0013
                                   2761 	.globl _ak820_outline_0015
                                   2762 	.globl _ak820_outline_0023
                                   2763 	.globl _ak820_outline_0033
                                   2764 	.globl _ak820_outline_0044
                                   2765 	.globl _ak820_outline_0045
                                   2766 	.globl _ak820_outline_0052
                                   2767 	.globl _ak820_outline_0055
                                   2768 	.globl _ak820_outline_0060
                                   2769 	.globl _ak820_outline_0065
                                   2770 	.globl _ak820_outline_0068
                                   2771 	.globl _ak820_outline_0073
                                   2772 	.globl _ak820_outline_0076
                                   2773 	.globl _ak820_outline_0081
                                   2774 	.globl _ak820_outline_0085
                                   2775 	.globl _ak820_outline_0087
                                   2776 	.globl _ak820_outline_0088
                                   2777 	.globl _ak820_outline_0091
                                   2778 	.globl _ak820_outline_0098
                                   2779 	.globl _ak820_outline_0100
                                   2780 	.globl _ak820_outline_0101
                                   2781 	.globl _ak820_outline_0103
                                   2782 	.globl _ak820_outline_0107
                                   2783 	.globl _ak820_outline_0109
                                   2784 	.globl _ak820_outline_0110
                                   2785 	.globl _ak820_outline_0114
                                   2786 	.globl _ak820_outline_0118
                                   2787 	.globl _ak820_outline_0119
                                   2788 	.globl _ak820_outline_0121
                                   2789 	.globl _ak820_outline_0122
                                   2790 	.globl _ak820_outline_0123
                                   2791 	.globl _ak820_outline_0127
                                   2792 	.globl _ak820_outline_0130
                                   2793 	.globl _ak820_outline_0131
                                   2794 	.globl _ak820_outline_0132
                                   2795 	.globl _ak820_outline_0136
                                   2796 	.globl _ak820_outline_0140
                                   2797 	.globl _ak820_outline_0141
                                   2798 	.globl _ak820_outline_0142
                                   2799 	.globl _ak820_outline_0143
                                   2800 	.globl _ak820_outline_0144
                                   2801 	.globl _ak820_outline_0155
                                   2802 	.globl _ak820_outline_0159
                                   2803 	.globl _ak820_outline_0169
                                   2804 	.globl _ak820_outline_0174
                                   2805 	.globl _ak820_outline_0184
                                   2806 	.globl _ak820_outline_0186
                                   2807 	.globl _ak820_outline_0189
                                   2808 	.globl _ak820_outline_0193
                                   2809 	.globl _ak820_outline_0194
                                   2810 	.globl _ak820_outline_0197
                                   2811 
                                   2812 	.area CSEG (CODE)
                                   2813 ; function ak820_outline_0000
      008F28                       2814 _ak820_outline_0000:
      008F28 90 0B 38         [24] 2815 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008F2B E0               [24] 2816 	movx	a,@dptr
      008F2C FD               [12] 2817 	mov	r5,a
      008F2D A3               [24] 2818 	inc	dptr
      008F2E E0               [24] 2819 	movx	a,@dptr
      008F2F FE               [12] 2820 	mov	r6,a
      008F30 A3               [24] 2821 	inc	dptr
      008F31 E0               [24] 2822 	movx	a,@dptr
      008F32 FF               [12] 2823 	mov	r7,a
      008F33 90 0B 38         [24] 2824 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_462
      008F36 74 01            [12] 2825 	mov	a,#0x01
      008F38 2D               [12] 2826 	add	a,r5
      008F39 F0               [24] 2827 	movx	@dptr,a
      008F3A E4               [12] 2828 	clr	a
      008F3B 3E               [12] 2829 	addc	a,r6
      008F3C A3               [24] 2830 	inc	dptr
      008F3D F0               [24] 2831 	movx	@dptr,a
      008F3E EF               [12] 2832 	mov	a,r7
      008F3F A3               [24] 2833 	inc	dptr
      008F40 F0               [24] 2834 	movx	@dptr,a
      008F41 8D 82            [24] 2835 	mov	dpl,r5
      008F43 8E 83            [24] 2836 	mov	dph,r6
      008F45 8F F0            [24] 2837 	mov	b,r7
      008F47 22               [24] 2838 	ret
                                   2839 
                                   2840 	.area CSEG (CODE)
                                   2841 ; function ak820_outline_0091
      008F48                       2842 _ak820_outline_0091:
      008F48 ED               [12] 2843 	mov	a,r5
      008F49 75 F0 0A         [24] 2844 	mov	b,#0x0a
      008F4C A4               [48] 2845 	mul	ab
      008F4D 24 58            [12] 2846 	add	a,#0x58
      008F4F FC               [12] 2847 	mov	r4,a
      008F50 74 06            [12] 2848 	mov	a,#0x06
      008F52 35 F0            [12] 2849 	addc	a,b
      008F54 FD               [12] 2850 	mov	r5,a
      008F55 22               [24] 2851 	ret
                                   2852 
                                   2853 	.area CSEG (CODE)
                                   2854 ; function ak820_outline_0100
      008F56                       2855 _ak820_outline_0100:
      008F56 90 0B 3C         [24] 2856 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0001)
      008F59 E0               [24] 2857 	movx	a,@dptr
      008F5A FF               [12] 2858 	mov	r7,a
      008F5B 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0101
      008F5C                       2863 _ak820_outline_0101:
      008F5C 74 0A            [12] 2864 	mov	a,#0x0a
      008F5E F0               [24] 2865 	movx	@dptr,a
      008F5F E4               [12] 2866 	clr	a
      008F60 A3               [24] 2867 	inc	dptr
      008F61 F0               [24] 2868 	movx	@dptr,a
      008F62 22               [24] 2869 	ret
                                   2870 
                                   2871 	.area CSEG (CODE)
                                   2872 ; function ak820_outline_0107
      008F63                       2873 _ak820_outline_0107:
      008F63 90 0A D1         [24] 2874 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008F66 EE               [12] 2875 	mov	a,r6
      008F67 F0               [24] 2876 	movx	@dptr,a
      008F68 90 0A D2         [24] 2877 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008F6B ED               [12] 2878 	mov	a,r5
      008F6C F0               [24] 2879 	movx	@dptr,a
      008F6D 8F 82            [24] 2880 	mov	dpl,r7
      008F6F 22               [24] 2881 	ret
                                   2882 
                                   2883 	.area CSEG (CODE)
                                   2884 ; function ak820_outline_0114
      008F70                       2885 _ak820_outline_0114:
      008F70 89 82            [24] 2886 	mov	dpl,r1
      008F72 8A 83            [24] 2887 	mov	dph,r2
      008F74 8B F0            [24] 2888 	mov	b,r3
      008F76 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0118
      008F77                       2893 _ak820_outline_0118:
      008F77 AD 82            [24] 2894 	mov	r5,dpl
      008F79 AE 83            [24] 2895 	mov	r6,dph
      008F7B AF F0            [24] 2896 	mov	r7,b
      008F7D 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0136
      008F7E                       2901 _ak820_outline_0136:
      008F7E 28               [12] 2902 	add	a,r0
      008F7F F5 82            [12] 2903 	mov	dpl,a
      008F81 EF               [12] 2904 	mov	a,r7
      008F82 39               [12] 2905 	addc	a,r1
      008F83 F5 83            [12] 2906 	mov	dph,a
      008F85 74 FF            [12] 2907 	mov	a,#0xff
      008F87 F0               [24] 2908 	movx	@dptr,a
      008F88 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0142
      008F89                       2913 _ak820_outline_0142:
      008F89 2D               [12] 2914 	add	a,r5
      008F8A F9               [12] 2915 	mov	r1,a
      008F8B E4               [12] 2916 	clr	a
      008F8C 3E               [12] 2917 	addc	a,r6
      008F8D FA               [12] 2918 	mov	r2,a
      008F8E 22               [24] 2919 	ret
                                   2920 
                                   2921 	.area CSEG (CODE)
                                   2922 ; function ak820_outline_0159
      008F8F                       2923 _ak820_outline_0159:
      008F8F 90 0B 3D         [24] 2924 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0002)
      008F92 E0               [24] 2925 	movx	a,@dptr
      008F93 F5 82            [12] 2926 	mov	dpl,a
      008F95 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0169
      008F96                       2931 _ak820_outline_0169:
      008F96 90 09 7F         [24] 2932 	mov	dptr,#_ak820_macro_primitive
      008F99 E4               [12] 2933 	clr	a
      008F9A F0               [24] 2934 	movx	@dptr,a
      008F9B 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0184
      008F9C                       2939 _ak820_outline_0184:
      008F9C 90 0A E1         [24] 2940 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008F9F E4               [12] 2941 	clr	a
      008FA0 F0               [24] 2942 	movx	@dptr,a
      008FA1 90 0A E2         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008FA4 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0186
      008FA5                       2948 _ak820_outline_0186:
      008FA5 90 0B AD         [24] 2949 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008FA8 E4               [12] 2950 	clr	a
      008FA9 F0               [24] 2951 	movx	@dptr,a
      008FAA 90 0B AE         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008FAD 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0189
      008FAE                       2957 _ak820_outline_0189:
      008FAE AF 82            [24] 2958 	mov	r7,dpl
      008FB0 90 0B 3D         [24] 2959 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_469+0x0002)
      008FB3 EF               [12] 2960 	mov	a,r7
      008FB4 F0               [24] 2961 	movx	@dptr,a
      008FB5 EF               [12] 2962 	mov	a,r7
      008FB6 22               [24] 2963 	ret
