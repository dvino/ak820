                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000045                        541 _vial_handle_cmd_sloc0_1_0:
      000045                        542 	.ds 2
      000047                        543 _vial_handle_cmd_sloc1_1_0:
      000047                        544 	.ds 2
      000049                        545 _vial_handle_cmd_sloc2_1_0:
      000049                        546 	.ds 2
      00004B                        547 _vial_handle_cmd_sloc3_1_0:
      00004B                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C78                        573 _vial_unlock_timer:
      000C78                        574 	.ds 4
      000C7C                        575 _vial_unlock_holding:
      000C7C                        576 	.ds 1
      000C7D                        577 _vial_keycode_firewall_in_10000_602:
      000C7D                        578 	.ds 2
      000C7F                        579 _vial_fill_packet_PARM_2:
      000C7F                        580 	.ds 1
      000C80                        581 _vial_fill_packet_msg_10000_605:
      000C80                        582 	.ds 2
      000C82                        583 _vial_handle_cmd_PARM_2:
      000C82                        584 	.ds 1
      000C83                        585 _vial_handle_cmd_data_10000_610:
      000C83                        586 	.ds 3
      000C86                        587 _vial_handle_cmd_entry_70000_638:
      000C86                        588 	.ds 10
      000C90                        589 _vial_handle_cmd_entry_70000_639:
      000C90                        590 	.ds 10
      000C9A                        591 _g_vial_magic_keycode_override::
      000C9A                        592 	.ds 2
      000C9C                        593 _vial_keycode_down_keycode_10000_641:
      000C9C                        594 	.ds 2
      000C9E                        595 _vial_keycode_down_dummy_event_30000_648:
      000C9E                        596 	.ds 6
      000CA4                        597 _vial_keycode_up_keycode_10000_649:
      000CA4                        598 	.ds 2
      000CA6                        599 _vial_keycode_up_dummy_event_30000_656:
      000CA6                        600 	.ds 6
      000CAC                        601 _vial_keycode_tap_keycode_10000_657:
      000CAC                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E42                        611 _vial_unlocked::
      000E42                        612 	.ds 1
      000E43                        613 _vial_unlock_in_progress::
      000E43                        614 	.ds 1
      000E44                        615 _vial_unlock_counter:
      000E44                        616 	.ds 1
      000E45                        617 _vial_unlock_combo_rows:
      000E45                        618 	.ds 2
      000E47                        619 _vial_unlock_combo_cols:
      000E47                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_175'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00B066                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B066 90 0E 43         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00B069 E0               [24]  667 	movx	a,@dptr
      00B06A 70 01            [24]  668 	jnz	00131$
      00B06C 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B06D                        671 00131$:
      00B06D 7F 00            [12]  672 	mov	r7,#0x00
      00B06F                        673 00115$:
      00B06F BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00B072                        675 00184$:
      00B072 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B074 EF               [12]  678 	mov	a,r7
      00B075 12 B6 54         [24]  679 	lcall	_ak820_outline_0135
      00B078 FE               [12]  680 	mov	r6,a
      00B079 EF               [12]  681 	mov	a,r7
      00B07A 12 B6 49         [24]  682 	lcall	_ak820_outline_0134
      00B07D 90 07 58         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00B080 F0               [24]  684 	movx	@dptr,a
      00B081 8E 82            [24]  685 	mov	dpl, r6
      00B083 C0 07            [24]  686 	push	ar7
      00B085 12 5A 28         [24]  687 	lcall	_matrix_is_on
      00B088 E5 82            [12]  688 	mov	a, dpl
      00B08A D0 07            [24]  689 	pop	ar7
      00B08C 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B08E 90 0C 7C         [24]  692 	mov	dptr,#_vial_unlock_holding
      00B091 E4               [12]  693 	clr	a
      00B092 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B093 90 0E 44         [24]  696 	mov	dptr,#_vial_unlock_counter
      00B096 74 1E            [12]  697 	mov	a,#0x1e
      00B098 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00B099 22               [24]  700 	ret
      00B09A                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B09A 0F               [12]  703 	inc	r7
      00B09B 80 D2            [24]  704 	sjmp	00115$
      00B09D                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B09D 90 0C 7C         [24]  707 	mov	dptr,#_vial_unlock_holding
      00B0A0 E0               [24]  708 	movx	a,@dptr
      00B0A1 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B0A3 90 0C 7C         [24]  711 	mov	dptr,#_vial_unlock_holding
      00B0A6 74 01            [12]  712 	mov	a,#0x01
      00B0A8 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B0A9 12 49 77         [24]  715 	lcall	_timer_read32
      00B0AC 12 4F 84         [24]  716 	lcall	_ak820_outline_0064
      00B0AF 90 0C 78         [24]  717 	mov	dptr,#_vial_unlock_timer
      00B0B2 12 91 31         [24]  718 	lcall	_ak820_outline_0011
      00B0B5                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B0B5 90 0C 78         [24]  721 	mov	dptr,#_vial_unlock_timer
      00B0B8 12 4F 72         [24]  722 	lcall	_ak820_outline_0044
      00B0BB A3               [24]  723 	inc	dptr
      00B0BC E0               [24]  724 	movx	a,@dptr
      00B0BD 12 4F 93         [24]  725 	lcall	_ak820_outline_0073
      00B0C0 12 49 D0         [24]  726 	lcall	_timer_elapsed32
      00B0C3 12 4F 84         [24]  727 	lcall	_ak820_outline_0064
                                    728 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B0C6 7B 1E            [12]  729 	mov	r3,#0x1e
      00B0C8                        730 00109$:
      00B0C8 EB               [12]  731 	mov	a,r3
      00B0C9 60 22            [24]  732 	jz	00111$
      00B0CB C3               [12]  733 	clr	c
      00B0CC EC               [12]  734 	mov	a,r4
      00B0CD 94 64            [12]  735 	subb	a,#0x64
      00B0CF ED               [12]  736 	mov	a,r5
      00B0D0 94 00            [12]  737 	subb	a,#0x00
      00B0D2 EE               [12]  738 	mov	a,r6
      00B0D3 94 00            [12]  739 	subb	a,#0x00
      00B0D5 EF               [12]  740 	mov	a,r7
      00B0D6 94 00            [12]  741 	subb	a,#0x00
      00B0D8 40 13            [24]  742 	jc	00111$
                                    743 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B0DA EC               [12]  744 	mov	a,r4
      00B0DB 24 9C            [12]  745 	add	a,#0x9c
      00B0DD FC               [12]  746 	mov	r4,a
      00B0DE ED               [12]  747 	mov	a,r5
      00B0DF 34 FF            [12]  748 	addc	a,#0xff
      00B0E1 FD               [12]  749 	mov	r5,a
      00B0E2 EE               [12]  750 	mov	a,r6
      00B0E3 34 FF            [12]  751 	addc	a,#0xff
      00B0E5 FE               [12]  752 	mov	r6,a
      00B0E6 EF               [12]  753 	mov	a,r7
      00B0E7 34 FF            [12]  754 	addc	a,#0xff
      00B0E9 FF               [12]  755 	mov	r7,a
                                    756 ;	quantum/vial.c:82: --counter;
      00B0EA 1B               [12]  757 	dec	r3
      00B0EB 80 DB            [24]  758 	sjmp	00109$
      00B0ED                        759 00111$:
                                    760 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B0ED 90 0E 44         [24]  761 	mov	dptr,#_vial_unlock_counter
      00B0F0 EB               [12]  762 	mov	a,r3
      00B0F1 F0               [24]  763 	movx	@dptr,a
                                    764 ;	quantum/vial.c:85: if (!counter) {
      00B0F2 EB               [12]  765 	mov	a,r3
      00B0F3 70 0A            [24]  766 	jnz	00117$
                                    767 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B0F5 90 0E 43         [24]  768 	mov	dptr,#_vial_unlock_in_progress
      00B0F8 E4               [12]  769 	clr	a
      00B0F9 F0               [24]  770 	movx	@dptr,a
                                    771 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B0FA 90 0E 42         [24]  772 	mov	dptr,#_vial_unlocked
      00B0FD 04               [12]  773 	inc	a
      00B0FE F0               [24]  774 	movx	@dptr,a
      00B0FF                        775 00117$:
                                    776 ;	quantum/vial.c:90: }
      00B0FF 22               [24]  777 	ret
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'vial_init'
                                    780 ;------------------------------------------------------------
                                    781 ;	quantum/vial.c:108: void vial_init(void) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function vial_init
                                    784 ;	-----------------------------------------
      00B100                        785 _vial_init:
                                    786 ;	quantum/vial.c:113: reload_combo();
                                    787 ;	quantum/vial.c:118: }
      00B100 02 36 02         [24]  788 	ljmp	_ak820_combo_reload
                                    789 ;------------------------------------------------------------
                                    790 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    791 ;------------------------------------------------------------
                                    792 ;in            Allocated with name '_vial_keycode_firewall_in_10000_602'
                                    793 ;------------------------------------------------------------
                                    794 ;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    795 ;	-----------------------------------------
                                    796 ;	 function vial_keycode_firewall
                                    797 ;	-----------------------------------------
      00B103                        798 _vial_keycode_firewall:
      00B103 12 39 03         [24]  799 	lcall	_ak820_outline_0122
      00B106 90 0C 7D         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_602
      00B109 12 38 FE         [24]  801 	lcall	_ak820_outline_0121
                                    802 ;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
      00B10C 90 0C 7D         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_602
      00B10F 12 48 9E         [24]  804 	lcall	_ak820_outline_0013
      00B112 BC 00 0D         [24]  805 	cjne	r4,#0x00,00102$
      00B115 BD 7C 0A         [24]  806 	cjne	r5,#0x7c,00102$
      00B118 90 0E 42         [24]  807 	mov	dptr,#_vial_unlocked
      00B11B E0               [24]  808 	movx	a,@dptr
      00B11C 70 04            [24]  809 	jnz	00102$
                                    810 ;	quantum/vial.c:122: return 0;
      00B11E 90 00 00         [24]  811 	mov	dptr,#0x0000
      00B121 22               [24]  812 	ret
      00B122                        813 00102$:
                                    814 ;	quantum/vial.c:123: return in;
      00B122 12 39 08         [24]  815 	lcall	_ak820_outline_0123
                                    816 ;	quantum/vial.c:124: }
      00B125 22               [24]  817 	ret
                                    818 ;------------------------------------------------------------
                                    819 ;Allocation info for local variables in function 'vial_fill_packet'
                                    820 ;------------------------------------------------------------
                                    821 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    822 ;msg           Allocated with name '_vial_fill_packet_msg_10000_605'
                                    823 ;i             Allocated with name '_vial_fill_packet_i_20000_607'
                                    824 ;------------------------------------------------------------
                                    825 ;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    826 ;	-----------------------------------------
                                    827 ;	 function vial_fill_packet
                                    828 ;	-----------------------------------------
      00B126                        829 _vial_fill_packet:
      00B126 12 39 03         [24]  830 	lcall	_ak820_outline_0122
      00B129 90 0C 80         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_605
      00B12C 12 38 FE         [24]  832 	lcall	_ak820_outline_0121
                                    833 ;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B12F 90 0C 80         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_605
      00B132 12 38 C3         [24]  835 	lcall	_ak820_outline_0060
      00B135 90 0C 7F         [24]  836 	mov	dptr,#_vial_fill_packet_PARM_2
      00B138 E0               [24]  837 	movx	a,@dptr
      00B139 FD               [12]  838 	mov	r5,a
      00B13A 7C 00            [12]  839 	mov	r4,#0x00
      00B13C                        840 00103$:
      00B13C BC 20 00         [24]  841 	cjne	r4,#0x20,00122$
      00B13F                        842 00122$:
      00B13F 50 09            [24]  843 	jnc	00105$
      00B141 EC               [12]  844 	mov	a,r4
      00B142 12 38 BB         [24]  845 	lcall	_ak820_outline_0045
      00B145 ED               [12]  846 	mov	a,r5
      00B146 F0               [24]  847 	movx	@dptr,a
      00B147 0C               [12]  848 	inc	r4
      00B148 80 F2            [24]  849 	sjmp	00103$
      00B14A                        850 00105$:
                                    851 ;	quantum/vial.c:129: }
      00B14A 22               [24]  852 	ret
                                    853 ;------------------------------------------------------------
                                    854 ;Allocation info for local variables in function 'vial_release_held_state'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/vial.c:140: static void vial_release_held_state(void) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function vial_release_held_state
                                    859 ;	-----------------------------------------
      00B14B                        860 _vial_release_held_state:
                                    861 ;	quantum/vial.c:162: repeat_key_cancel();
      00B14B 12 A5 35         [24]  862 	lcall	_repeat_key_cancel
                                    863 ;	quantum/vial.c:164: clear_keyboard();
                                    864 ;	quantum/vial.c:165: }
      00B14E 02 77 61         [24]  865 	ljmp	_clear_keyboard
                                    866 ;------------------------------------------------------------
                                    867 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    868 ;------------------------------------------------------------
                                    869 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    870 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    871 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    872 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    873 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    874 ;data          Allocated with name '_vial_handle_cmd_data_10000_610'
                                    875 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_611'
                                    876 ;i             Allocated with name '_vial_handle_cmd_i_50000_616'
                                    877 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_617'
                                    878 ;page          Allocated with name '_vial_handle_cmd_page_40001_620'
                                    879 ;start         Allocated with name '_vial_handle_cmd_start_40002_622'
                                    880 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_622'
                                    881 ;count         Allocated with name '_vial_handle_cmd_count_40002_622'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50002_623'
                                    883 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_624'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_624'
                                    885 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_624'
                                    886 ;i             Allocated with name '_vial_handle_cmd_i_50000_627'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_638'
                                    888 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_638'
                                    889 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_639'
                                    890 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_639'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function vial_handle_cmd
                                    895 ;	-----------------------------------------
      00B151                        896 _vial_handle_cmd:
      00B151 12 43 80         [24]  897 	lcall	_ak820_outline_0036
      00B154 90 0C 83         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_610
      00B157 12 38 8B         [24]  899 	lcall	_ak820_outline_0017
                                    900 ;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B15A 90 0C 83         [24]  901 	mov	dptr,#_vial_handle_cmd_data_10000_610
      00B15D 12 38 C3         [24]  902 	lcall	_ak820_outline_0060
                                    903 ;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
      00B160 90 0C 82         [24]  904 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B163 E0               [24]  905 	movx	a,@dptr
      00B164 FD               [12]  906 	mov	r5,a
      00B165 BD 20 02         [24]  907 	cjne	r5,#0x20,00258$
      00B168 80 01            [24]  908 	sjmp	00102$
      00B16A                        909 00258$:
                                    910 ;	quantum/vial.c:178: return;
      00B16A 22               [24]  911 	ret
      00B16B                        912 00102$:
                                    913 ;	quantum/vial.c:181: switch (msg[1]) {
      00B16B 74 01            [12]  914 	mov	a,#0x01
      00B16D 12 48 E6         [24]  915 	lcall	_ak820_outline_0055
      00B170 FB               [12]  916 	mov  r3,a
      00B171 24 F2            [12]  917 	add	a,#0xff - 0x0d
      00B173 50 01            [24]  918 	jnc	00259$
      00B175 22               [24]  919 	ret
      00B176                        920 00259$:
                                    921 ;	free result
      00B176 EB               [12]  922 	mov	a,r3
      00B177 24 0A            [12]  923 	add	a,#(00260$-3-.)
      00B179 83               [24]  924 	movc	a,@a+pc
      00B17A F5 82            [12]  925 	mov	dpl,a
      00B17C EB               [12]  926 	mov	a,r3
      00B17D 24 12            [12]  927 	add	a,#(00261$-3-.)
      00B17F 83               [24]  928 	movc	a,@a+pc
      00B180 F5 83            [12]  929 	mov	dph,a
      00B182 E4               [12]  930 	clr	a
      00B183 73               [24]  931 	jmp	@a+dptr
      00B184                        932 00260$:
      00B184 A0                     933 	.db	00103$
      00B185 E7                     934 	.db	00105$
      00B186 FC                     935 	.db	00106$
      00B187 88                     936 	.db	00112$
      00B188 0E                     937 	.db	00113$
      00B189 58                     938 	.db	00114$
      00B18A C6                     939 	.db	00116$
      00B18B E1                     940 	.db	00119$
      00B18C 00                     941 	.db	00120$
      00B18D 0E                     942 	.db	00121$
      00B18E 1A                     943 	.db	00139$
      00B18F 1A                     944 	.db	00139$
      00B190 1A                     945 	.db	00139$
      00B191 19                     946 	.db	00122$
      00B192                        947 00261$:
      00B192 B1                     948 	.db	00103$>>8
      00B193 B1                     949 	.db	00105$>>8
      00B194 B1                     950 	.db	00106$>>8
      00B195 B2                     951 	.db	00112$>>8
      00B196 B3                     952 	.db	00113$>>8
      00B197 B3                     953 	.db	00114$>>8
      00B198 B3                     954 	.db	00116$>>8
      00B199 B3                     955 	.db	00119$>>8
      00B19A B4                     956 	.db	00120$>>8
      00B19B B4                     957 	.db	00121$>>8
      00B19C B5                     958 	.db	00139$>>8
      00B19D B5                     959 	.db	00139$>>8
      00B19E B5                     960 	.db	00139$>>8
      00B19F B4                     961 	.db	00122$>>8
                                    962 ;	quantum/vial.c:183: case vial_get_keyboard_id: {
      00B1A0                        963 00103$:
                                    964 ;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
      00B1A0 90 0C 7F         [24]  965 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1A3 E4               [12]  966 	clr	a
      00B1A4 12 43 AB         [24]  967 	lcall	_ak820_outline_0088
      00B1A7 C0 07            [24]  968 	push	ar7
      00B1A9 C0 06            [24]  969 	push	ar6
      00B1AB 12 B1 26         [24]  970 	lcall	_vial_fill_packet
      00B1AE D0 06            [24]  971 	pop	ar6
      00B1B0 D0 07            [24]  972 	pop	ar7
                                    973 ;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B1B2 12 39 08         [24]  974 	lcall	_ak820_outline_0123
      00B1B5 74 06            [12]  975 	mov	a,#0x06
      00B1B7 12 43 AB         [24]  976 	lcall	_ak820_outline_0088
                                    977 ;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B1BA A3               [24]  978 	inc	dptr
      00B1BB E4               [12]  979 	clr	a
      00B1BC 12 43 78         [24]  980 	lcall	_ak820_outline_0034
                                    981 ;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B1BF 12 43 78         [24]  982 	lcall	_ak820_outline_0034
                                    983 ;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B1C2 A3               [24]  984 	inc	dptr
      00B1C3 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B1C4 FB               [12]  987 	mov	r3,a
      00B1C5                        988 00131$:
      00B1C5 BB 08 00         [24]  989 	cjne	r3,#0x08,00262$
      00B1C8                        990 00262$:
      00B1C8 50 14            [24]  991 	jnc	00104$
      00B1CA 8B 02            [24]  992 	mov	ar2,r3
      00B1CC 74 04            [12]  993 	mov	a,#0x04
      00B1CE 2A               [12]  994 	add	a, r2
      00B1CF 2E               [12]  995 	add	a, r6
      00B1D0 F9               [12]  996 	mov	r1,a
      00B1D1 E4               [12]  997 	clr	a
      00B1D2 3F               [12]  998 	addc	a,r7
      00B1D3 FA               [12]  999 	mov	r2,a
      00B1D4 EB               [12] 1000 	mov	a,r3
      00B1D5 90 C3 06         [24] 1001 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_615
      00B1D8 93               [24] 1002 	movc	a,@a+dptr
      00B1D9 12 6D 24         [24] 1003 	lcall	_ak820_outline_0158
      00B1DC 80 E7            [24] 1004 	sjmp	00131$
      00B1DE                       1005 00104$:
                                   1006 ;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B1DE 74 0C            [12] 1007 	mov	a,#0x0c
      00B1E0 12 38 BB         [24] 1008 	lcall	_ak820_outline_0045
      00B1E3 74 01            [12] 1009 	mov	a,#0x01
      00B1E5 F0               [24] 1010 	movx	@dptr,a
                                   1011 ;	quantum/vial.c:195: break;
      00B1E6 22               [24] 1012 	ret
                                   1013 ;	quantum/vial.c:198: case vial_get_size: {
      00B1E7                       1014 00105$:
                                   1015 ;	quantum/vial.c:200: msg[0] = sz & 0xFF;
      00B1E7 12 39 08         [24] 1016 	lcall	_ak820_outline_0123
      00B1EA 74 7C            [12] 1017 	mov	a,#0x7c
      00B1EC F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
      00B1ED 12 34 76         [24] 1020 	lcall	_ak820_outline_0132
      00B1F0 74 01            [12] 1021 	mov	a,#0x01
      00B1F2 12 43 78         [24] 1022 	lcall	_ak820_outline_0034
                                   1023 ;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
      00B1F5 E4               [12] 1024 	clr	a
      00B1F6 12 43 78         [24] 1025 	lcall	_ak820_outline_0034
                                   1026 ;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
      00B1F9 A3               [24] 1027 	inc	dptr
      00B1FA F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	quantum/vial.c:204: break;
      00B1FB 22               [24] 1030 	ret
                                   1031 ;	quantum/vial.c:207: case vial_get_def: {
      00B1FC                       1032 00106$:
                                   1033 ;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
      00B1FC 12 B0 31         [24] 1034 	lcall	_ak820_outline_0024
      00B1FF E0               [24] 1035 	movx	a,@dptr
      00B200 FB               [12] 1036 	mov	r3,a
      00B201 12 43 6E         [24] 1037 	lcall	_ak820_outline_0016
      00B204 E0               [24] 1038 	movx	a,@dptr
      00B205 4B               [12] 1039 	orl	a,r3
      00B206 60 01            [24] 1040 	jz	00108$
      00B208 22               [24] 1041 	ret
      00B209                       1042 00108$:
                                   1043 ;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B209 12 38 B3         [24] 1044 	lcall	_ak820_outline_0038
      00B20C FB               [12] 1045 	mov	r3,a
      00B20D 7A 00            [12] 1046 	mov	r2,#0x00
      00B20F 12 B0 28         [24] 1047 	lcall	_ak820_outline_0019
      00B212 F9               [12] 1048 	mov	r1,a
      00B213 E4               [12] 1049 	clr	a
      00B214 42 03            [12] 1050 	orl	ar3,a
      00B216 E9               [12] 1051 	mov	a,r1
      00B217 42 02            [12] 1052 	orl	ar2,a
                                   1053 ;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B219 C3               [12] 1054 	clr	c
      00B21A EB               [12] 1055 	mov	a,r3
      00B21B 94 0C            [12] 1056 	subb	a,#0x0c
      00B21D EA               [12] 1057 	mov	a,r2
      00B21E 94 00            [12] 1058 	subb	a,#0x00
      00B220 40 01            [24] 1059 	jc	00110$
      00B222 22               [24] 1060 	ret
      00B223                       1061 00110$:
                                   1062 ;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B223 EA               [12] 1063 	mov	a,r2
      00B224 C4               [12] 1064 	swap	a
      00B225 23               [12] 1065 	rl	a
      00B226 54 E0            [12] 1066 	anl	a,#0xe0
      00B228 CB               [12] 1067 	xch	a,r3
      00B229 C4               [12] 1068 	swap	a
      00B22A 23               [12] 1069 	rl	a
      00B22B CB               [12] 1070 	xch	a,r3
      00B22C 6B               [12] 1071 	xrl	a,r3
      00B22D CB               [12] 1072 	xch	a,r3
      00B22E 54 E0            [12] 1073 	anl	a,#0xe0
      00B230 CB               [12] 1074 	xch	a,r3
      00B231 6B               [12] 1075 	xrl	a,r3
      00B232 FA               [12] 1076 	mov	r2,a
      00B233 8B 45            [24] 1077 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B235 8A 46            [24] 1078 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1079 ;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B237 74 7C            [12] 1080 	mov	a,#0x7c
      00B239 C3               [12] 1081 	clr	c
      00B23A 95 45            [12] 1082 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B23C F8               [12] 1083 	mov	r0,a
      00B23D 74 01            [12] 1084 	mov	a,#0x01
      00B23F 95 46            [12] 1085 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B241 F9               [12] 1086 	mov	r1,a
                                   1087 ;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B242 C3               [12] 1088 	clr	c
      00B243 E8               [12] 1089 	mov	a,r0
      00B244 94 20            [12] 1090 	subb	a,#0x20
      00B246 E9               [12] 1091 	mov	a,r1
      00B247 94 00            [12] 1092 	subb	a,#0x00
      00B249 40 02            [24] 1093 	jc	00142$
      00B24B 78 20            [12] 1094 	mov	r0,#0x20
      00B24D                       1095 00142$:
                                   1096 ;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B24D 79 00            [12] 1097 	mov	r1,#0x00
      00B24F                       1098 00134$:
      00B24F C3               [12] 1099 	clr	c
      00B250 E9               [12] 1100 	mov	a,r1
      00B251 98               [12] 1101 	subb	a,r0
      00B252 40 01            [24] 1102 	jc	00267$
      00B254 22               [24] 1103 	ret
      00B255                       1104 00267$:
      00B255 C0 00            [24] 1105 	push	ar0
      00B257 E9               [12] 1106 	mov	a,r1
      00B258 2E               [12] 1107 	add	a, r6
      00B259 F5 47            [12] 1108 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B25B E4               [12] 1109 	clr	a
      00B25C 3F               [12] 1110 	addc	a, r7
      00B25D F5 48            [12] 1111 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B25F 89 49            [24] 1112 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B261 75 4A 00         [24] 1113 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B264 A8 45            [24] 1114 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B266 AB 46            [24] 1115 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B268 E5 49            [12] 1116 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B26A 28               [12] 1117 	add	a, r0
      00B26B F8               [12] 1118 	mov	r0,a
      00B26C E5 4A            [12] 1119 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B26E 3B               [12] 1120 	addc	a, r3
      00B26F FB               [12] 1121 	mov	r3,a
      00B270 E8               [12] 1122 	mov	a,r0
      00B271 24 8A            [12] 1123 	add	a, #_keyboard_definition
      00B273 F5 82            [12] 1124 	mov	dpl,a
      00B275 EB               [12] 1125 	mov	a,r3
      00B276 34 C1            [12] 1126 	addc	a, #(_keyboard_definition >> 8)
      00B278 F5 83            [12] 1127 	mov	dph,a
      00B27A E4               [12] 1128 	clr	a
      00B27B 93               [24] 1129 	movc	a,@a+dptr
      00B27C 85 47 82         [24] 1130 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B27F 85 48 83         [24] 1131 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B282 F0               [24] 1132 	movx	@dptr,a
      00B283 09               [12] 1133 	inc	r1
      00B284 D0 00            [24] 1134 	pop	ar0
                                   1135 ;	quantum/vial.c:234: case vial_get_encoder: {
      00B286 80 C7            [24] 1136 	sjmp	00134$
      00B288                       1137 00112$:
                                   1138 ;	quantum/vial.c:235: uint8_t layer = msg[2];
      00B288 74 02            [12] 1139 	mov	a,#0x02
      00B28A 12 48 DB         [24] 1140 	lcall	_ak820_outline_0054
      00B28D F5 49            [12] 1141 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1142 ;	quantum/vial.c:236: uint8_t idx = msg[3];
      00B28F 74 03            [12] 1143 	mov	a,#0x03
      00B291 2E               [12] 1144 	add	a, r6
      00B292 F5 47            [12] 1145 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B294 E4               [12] 1146 	clr	a
      00B295 3F               [12] 1147 	addc	a, r7
      00B296 F5 48            [12] 1148 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B298 85 47 82         [24] 1149 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B29B 85 48 83         [24] 1150 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B29E E0               [24] 1151 	movx	a,@dptr
                                   1152 ;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B29F F5 45            [12] 1153 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B2A1 90 0A DE         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2A4 F0               [24] 1155 	movx	@dptr,a
      00B2A5 90 0A DF         [24] 1156 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2A8 E4               [12] 1157 	clr	a
      00B2A9 F0               [24] 1158 	movx	@dptr,a
      00B2AA 85 49 82         [24] 1159 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B2AD C0 07            [24] 1160 	push	ar7
      00B2AF C0 06            [24] 1161 	push	ar6
      00B2B1 C0 05            [24] 1162 	push	ar5
      00B2B3 C0 04            [24] 1163 	push	ar4
      00B2B5 C0 03            [24] 1164 	push	ar3
      00B2B7 C0 02            [24] 1165 	push	ar2
      00B2B9 12 85 DA         [24] 1166 	lcall	_dynamic_keymap_get_encoder
      00B2BC 85 82 4B         [24] 1167 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B2BF 85 83 4C         [24] 1168 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B2C2 D0 02            [24] 1169 	pop	ar2
      00B2C4 D0 03            [24] 1170 	pop	ar3
      00B2C6 D0 04            [24] 1171 	pop	ar4
      00B2C8 D0 05            [24] 1172 	pop	ar5
      00B2CA D0 06            [24] 1173 	pop	ar6
      00B2CC D0 07            [24] 1174 	pop	ar7
                                   1175 ;	quantum/vial.c:238: msg[0]  = keycode >> 8;
      00B2CE A9 4C            [24] 1176 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2D0 12 39 08         [24] 1177 	lcall	_ak820_outline_0123
      00B2D3 E9               [12] 1178 	mov	a,r1
      00B2D4 F0               [24] 1179 	movx	@dptr,a
                                   1180 ;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
      00B2D5 A8 4B            [24] 1181 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B2D7 12 34 76         [24] 1182 	lcall	_ak820_outline_0132
      00B2DA E8               [12] 1183 	mov	a,r0
      00B2DB F0               [24] 1184 	movx	@dptr,a
                                   1185 ;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B2DC 90 0A DE         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2DF E5 45            [12] 1187 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B2E1 F0               [24] 1188 	movx	@dptr,a
      00B2E2 90 0A DF         [24] 1189 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2E5 74 01            [12] 1190 	mov	a,#0x01
      00B2E7 F0               [24] 1191 	movx	@dptr,a
      00B2E8 85 49 82         [24] 1192 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B2EB C0 03            [24] 1193 	push	ar3
      00B2ED C0 02            [24] 1194 	push	ar2
      00B2EF 12 85 DA         [24] 1195 	lcall	_dynamic_keymap_get_encoder
      00B2F2 85 82 4B         [24] 1196 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B2F5 85 83 4C         [24] 1197 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B2F8 D0 02            [24] 1198 	pop	ar2
      00B2FA D0 03            [24] 1199 	pop	ar3
                                   1200 ;	quantum/vial.c:241: msg[2] = keycode >> 8;
      00B2FC A9 4C            [24] 1201 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2FE 12 39 12         [24] 1202 	lcall	_ak820_outline_0140
      00B301 E9               [12] 1203 	mov	a,r1
      00B302 F0               [24] 1204 	movx	@dptr,a
                                   1205 ;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
      00B303 A8 4B            [24] 1206 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B305 85 47 82         [24] 1207 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B308 85 48 83         [24] 1208 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B30B E8               [12] 1209 	mov	a,r0
      00B30C F0               [24] 1210 	movx	@dptr,a
                                   1211 ;	quantum/vial.c:243: break;
      00B30D 22               [24] 1212 	ret
                                   1213 ;	quantum/vial.c:245: case vial_set_encoder: {
      00B30E                       1214 00113$:
                                   1215 ;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B30E 12 38 B3         [24] 1216 	lcall	_ak820_outline_0038
      00B311 F5 47            [12] 1217 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B313 12 B0 28         [24] 1218 	lcall	_ak820_outline_0019
      00B316 F5 49            [12] 1219 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B318 12 B0 31         [24] 1220 	lcall	_ak820_outline_0024
      00B31B E0               [24] 1221 	movx	a,@dptr
                                   1222 ;	assignBit
      00B31C 24 FF            [12] 1223 	add	a,#0xff
      00B31E E4               [12] 1224 	clr	a
      00B31F 33               [12] 1225 	rlc	a
      00B320 F5 4B            [12] 1226 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B322 12 43 6E         [24] 1227 	lcall	_ak820_outline_0016
      00B325 E0               [24] 1228 	movx	a,@dptr
      00B326 F9               [12] 1229 	mov	r1,a
      00B327 78 00            [12] 1230 	mov	r0,#0x00
      00B329 74 06            [12] 1231 	mov	a,#0x06
      00B32B 12 38 9D         [24] 1232 	lcall	_ak820_outline_0023
      00B32E 7B 00            [12] 1233 	mov	r3,#0x00
      00B330 42 00            [12] 1234 	orl	ar0,a
      00B332 EB               [12] 1235 	mov	a,r3
      00B333 42 01            [12] 1236 	orl	ar1,a
      00B335 12 39 2E         [24] 1237 	lcall	_ak820_outline_0155
      00B338 12 B1 03         [24] 1238 	lcall	_vial_keycode_firewall
      00B33B AA 82            [24] 1239 	mov	r2, dpl
      00B33D AB 83            [24] 1240 	mov	r3, dph
      00B33F 90 0A E1         [24] 1241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B342 E5 49            [12] 1242 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B344 F0               [24] 1243 	movx	@dptr,a
      00B345 90 0A E2         [24] 1244 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B348 E5 4B            [12] 1245 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B34A F0               [24] 1246 	movx	@dptr,a
      00B34B 90 0A E3         [24] 1247 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B34E EA               [12] 1248 	mov	a,r2
      00B34F 12 78 22         [24] 1249 	lcall	_ak820_outline_0194
      00B352 85 47 82         [24] 1250 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1251 ;	quantum/vial.c:247: break;
      00B355 02 86 42         [24] 1252 	ljmp	_dynamic_keymap_set_encoder
                                   1253 ;	quantum/vial.c:250: case vial_get_unlock_status: {
      00B358                       1254 00114$:
                                   1255 ;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B358 90 0C 7F         [24] 1256 	mov	dptr,#_vial_fill_packet_PARM_2
      00B35B 74 FF            [12] 1257 	mov	a,#0xff
      00B35D 12 43 AB         [24] 1258 	lcall	_ak820_outline_0088
      00B360 C0 07            [24] 1259 	push	ar7
      00B362 C0 06            [24] 1260 	push	ar6
      00B364 12 B1 26         [24] 1261 	lcall	_vial_fill_packet
      00B367 D0 06            [24] 1262 	pop	ar6
      00B369 D0 07            [24] 1263 	pop	ar7
                                   1264 ;	quantum/vial.c:254: msg[0] = vial_unlocked;
      00B36B 90 0E 42         [24] 1265 	mov	dptr,#_vial_unlocked
      00B36E E0               [24] 1266 	movx	a,@dptr
      00B36F 12 39 08         [24] 1267 	lcall	_ak820_outline_0123
      00B372 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
      00B373 74 01            [12] 1270 	mov	a,#0x01
      00B375 2E               [12] 1271 	add	a, r6
      00B376 FA               [12] 1272 	mov	r2,a
      00B377 E4               [12] 1273 	clr	a
      00B378 3F               [12] 1274 	addc	a, r7
      00B379 FB               [12] 1275 	mov	r3,a
      00B37A 90 0E 43         [24] 1276 	mov	dptr,#_vial_unlock_in_progress
      00B37D E0               [24] 1277 	movx	a,@dptr
      00B37E 12 39 12         [24] 1278 	lcall	_ak820_outline_0140
      00B381 F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B382 7B 00            [12] 1281 	mov	r3,#0x00
      00B384                       1282 00137$:
      00B384 BB 02 00         [24] 1283 	cjne	r3,#0x02,00268$
      00B387                       1284 00268$:
      00B387 40 01            [24] 1285 	jc	00269$
      00B389 22               [24] 1286 	ret
      00B38A                       1287 00269$:
                                   1288 ;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B38A 8B 01            [24] 1289 	mov	ar1,r3
      00B38C 7A 00            [12] 1290 	mov	r2,#0x00
      00B38E E9               [12] 1291 	mov	a,r1
      00B38F 29               [12] 1292 	add	a,r1
      00B390 F5 4B            [12] 1293 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B392 EA               [12] 1294 	mov	a,r2
      00B393 33               [12] 1295 	rlc	a
      00B394 F5 4C            [12] 1296 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B396 74 02            [12] 1297 	mov	a,#0x02
      00B398 25 4B            [12] 1298 	add	a, _vial_handle_cmd_sloc3_1_0
      00B39A F8               [12] 1299 	mov	r0,a
      00B39B E4               [12] 1300 	clr	a
      00B39C 35 4C            [12] 1301 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B39E FA               [12] 1302 	mov	r2,a
      00B39F E8               [12] 1303 	mov	a,r0
      00B3A0 2E               [12] 1304 	add	a, r6
      00B3A1 F8               [12] 1305 	mov	r0,a
      00B3A2 EA               [12] 1306 	mov	a,r2
      00B3A3 3F               [12] 1307 	addc	a, r7
      00B3A4 FA               [12] 1308 	mov	r2,a
      00B3A5 EB               [12] 1309 	mov	a,r3
      00B3A6 12 B6 54         [24] 1310 	lcall	_ak820_outline_0135
      00B3A9 88 82            [24] 1311 	mov	dpl,r0
      00B3AB 8A 83            [24] 1312 	mov	dph,r2
      00B3AD F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B3AE 74 03            [12] 1315 	mov	a,#0x03
      00B3B0 25 4B            [12] 1316 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3B2 F9               [12] 1317 	mov	r1,a
      00B3B3 E4               [12] 1318 	clr	a
      00B3B4 35 4C            [12] 1319 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3B6 FA               [12] 1320 	mov	r2,a
      00B3B7 E9               [12] 1321 	mov	a,r1
      00B3B8 2E               [12] 1322 	add	a, r6
      00B3B9 F9               [12] 1323 	mov	r1,a
      00B3BA EA               [12] 1324 	mov	a,r2
      00B3BB 3F               [12] 1325 	addc	a, r7
      00B3BC FA               [12] 1326 	mov	r2,a
      00B3BD EB               [12] 1327 	mov	a,r3
      00B3BE 12 B6 49         [24] 1328 	lcall	_ak820_outline_0134
      00B3C1 12 6D 24         [24] 1329 	lcall	_ak820_outline_0158
                                   1330 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
                                   1331 ;	quantum/vial.c:266: case vial_unlock_start: {
      00B3C4 80 BE            [24] 1332 	sjmp	00137$
      00B3C6                       1333 00116$:
                                   1334 ;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
      00B3C6 90 0E 43         [24] 1335 	mov	dptr,#_vial_unlock_in_progress
      00B3C9 E0               [24] 1336 	movx	a,@dptr
      00B3CA 70 03            [24] 1337 	jnz	00118$
      00B3CC 12 B1 4B         [24] 1338 	lcall	_vial_release_held_state
      00B3CF                       1339 00118$:
                                   1340 ;	quantum/vial.c:270: vial_unlock_in_progress = 1;
      00B3CF 90 0E 43         [24] 1341 	mov	dptr,#_vial_unlock_in_progress
      00B3D2 74 01            [12] 1342 	mov	a,#0x01
      00B3D4 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B3D5 90 0E 44         [24] 1345 	mov	dptr,#_vial_unlock_counter
      00B3D8 74 1E            [12] 1346 	mov	a,#0x1e
      00B3DA F0               [24] 1347 	movx	@dptr,a
                                   1348 ;	quantum/vial.c:273: vial_unlock_holding = false;
      00B3DB 90 0C 7C         [24] 1349 	mov	dptr,#_vial_unlock_holding
      00B3DE E4               [12] 1350 	clr	a
      00B3DF F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/vial.c:275: break;
      00B3E0 22               [24] 1353 	ret
                                   1354 ;	quantum/vial.c:277: case vial_unlock_poll: {
      00B3E1                       1355 00119$:
                                   1356 ;	quantum/vial.c:278: msg[0] = vial_unlocked;
      00B3E1 90 0E 42         [24] 1357 	mov	dptr,#_vial_unlocked
      00B3E4 E0               [24] 1358 	movx	a,@dptr
      00B3E5 12 39 08         [24] 1359 	lcall	_ak820_outline_0123
      00B3E8 F0               [24] 1360 	movx	@dptr,a
                                   1361 ;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
      00B3E9 90 0E 43         [24] 1362 	mov	dptr,#_vial_unlock_in_progress
      00B3EC E0               [24] 1363 	movx	a,@dptr
      00B3ED 12 43 CF         [24] 1364 	lcall	_ak820_outline_0127
                                   1365 ;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
      00B3F0 74 02            [12] 1366 	mov	a,#0x02
      00B3F2 2E               [12] 1367 	add	a, r6
      00B3F3 FA               [12] 1368 	mov	r2,a
      00B3F4 E4               [12] 1369 	clr	a
      00B3F5 3F               [12] 1370 	addc	a, r7
      00B3F6 FB               [12] 1371 	mov	r3,a
      00B3F7 90 0E 44         [24] 1372 	mov	dptr,#_vial_unlock_counter
      00B3FA E0               [24] 1373 	movx	a,@dptr
      00B3FB 12 39 12         [24] 1374 	lcall	_ak820_outline_0140
      00B3FE F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/vial.c:281: break;
      00B3FF 22               [24] 1377 	ret
                                   1378 ;	quantum/vial.c:283: case vial_lock: {
      00B400                       1379 00120$:
                                   1380 ;	quantum/vial.c:285: vial_unlocked = 0;
      00B400 90 0E 42         [24] 1381 	mov	dptr,#_vial_unlocked
      00B403 E4               [12] 1382 	clr	a
      00B404 F0               [24] 1383 	movx	@dptr,a
                                   1384 ;	quantum/vial.c:286: vial_unlock_in_progress = 0;
      00B405 90 0E 43         [24] 1385 	mov	dptr,#_vial_unlock_in_progress
      00B408 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:287: vial_unlock_holding = false;
      00B409 90 0C 7C         [24] 1388 	mov	dptr,#_vial_unlock_holding
      00B40C F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:289: break;
      00B40D 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:291: case vial_qmk_settings_query: {
      00B40E                       1393 00121$:
                                   1394 ;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B40E 90 0C 7F         [24] 1395 	mov	dptr,#_vial_fill_packet_PARM_2
      00B411 74 FF            [12] 1396 	mov	a,#0xff
      00B413 12 43 AB         [24] 1397 	lcall	_ak820_outline_0088
                                   1398 ;	quantum/vial.c:298: break;
      00B416 02 B1 26         [24] 1399 	ljmp	_vial_fill_packet
                                   1400 ;	quantum/vial.c:318: case vial_dynamic_entry_op: {
      00B419                       1401 00122$:
                                   1402 ;	quantum/vial.c:319: switch (msg[2]) {
      00B419 12 38 B3         [24] 1403 	lcall	_ak820_outline_0038
      00B41C FB               [12] 1404 	mov	r3,a
      00B41D 60 0C            [24] 1405 	jz	00123$
      00B41F BB 03 02         [24] 1406 	cjne	r3,#0x03,00272$
      00B422 80 31            [24] 1407 	sjmp	00124$
      00B424                       1408 00272$:
      00B424 BB 04 03         [24] 1409 	cjne	r3,#0x04,00273$
      00B427 02 B4 B9         [24] 1410 	ljmp	00125$
      00B42A                       1411 00273$:
      00B42A 22               [24] 1412 	ret
                                   1413 ;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
      00B42B                       1414 00123$:
                                   1415 ;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
      00B42B 90 0C 7F         [24] 1416 	mov	dptr,#_vial_fill_packet_PARM_2
      00B42E E4               [12] 1417 	clr	a
      00B42F 12 43 AB         [24] 1418 	lcall	_ak820_outline_0088
      00B432 C0 07            [24] 1419 	push	ar7
      00B434 C0 06            [24] 1420 	push	ar6
      00B436 12 B1 26         [24] 1421 	lcall	_vial_fill_packet
      00B439 D0 06            [24] 1422 	pop	ar6
      00B43B D0 07            [24] 1423 	pop	ar7
                                   1424 ;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B43D 12 39 08         [24] 1425 	lcall	_ak820_outline_0123
      00B440 E4               [12] 1426 	clr	a
      00B441 12 43 AB         [24] 1427 	lcall	_ak820_outline_0088
                                   1428 ;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
      00B444 A3               [24] 1429 	inc	dptr
      00B445 74 08            [12] 1430 	mov	a,#0x08
      00B447 12 43 78         [24] 1431 	lcall	_ak820_outline_0034
                                   1432 ;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B44A E4               [12] 1433 	clr	a
      00B44B F0               [24] 1434 	movx	@dptr,a
                                   1435 ;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B44C 74 1F            [12] 1436 	mov	a,#0x1f
      00B44E 12 38 BB         [24] 1437 	lcall	_ak820_outline_0045
      00B451 74 01            [12] 1438 	mov	a,#0x01
      00B453 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/vial.c:328: break;
      00B454 22               [24] 1441 	ret
                                   1442 ;	quantum/vial.c:352: case dynamic_vial_combo_get: {
      00B455                       1443 00124$:
                                   1444 ;	quantum/vial.c:353: uint8_t idx = msg[3];
      00B455 12 B0 28         [24] 1445 	lcall	_ak820_outline_0019
      00B458 FB               [12] 1446 	mov	r3,a
                                   1447 ;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
      00B459 90 0C 86         [24] 1448 	mov	dptr,#_vial_handle_cmd_entry_70000_638
      00B45C 12 4F B3         [24] 1449 	lcall	_ak820_outline_0174
      00B45F 90 0C 88         [24] 1450 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0002)
      00B462 F0               [24] 1451 	movx	@dptr,a
      00B463 A3               [24] 1452 	inc	dptr
      00B464 F0               [24] 1453 	movx	@dptr,a
      00B465 90 0C 8A         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0004)
      00B468 F0               [24] 1455 	movx	@dptr,a
      00B469 A3               [24] 1456 	inc	dptr
      00B46A F0               [24] 1457 	movx	@dptr,a
      00B46B 90 0C 8C         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0006)
      00B46E F0               [24] 1459 	movx	@dptr,a
      00B46F A3               [24] 1460 	inc	dptr
      00B470 F0               [24] 1461 	movx	@dptr,a
      00B471 90 0C 8E         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_638 + 0x0008)
      00B474 F0               [24] 1463 	movx	@dptr,a
      00B475 A3               [24] 1464 	inc	dptr
      00B476 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B477 90 0A E6         [24] 1467 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B47A 74 86            [12] 1468 	mov	a,#_vial_handle_cmd_entry_70000_638
      00B47C F0               [24] 1469 	movx	@dptr,a
      00B47D 74 0C            [12] 1470 	mov	a,#(_vial_handle_cmd_entry_70000_638 >> 8)
      00B47F 12 38 E0         [24] 1471 	lcall	_ak820_outline_0081
      00B482 8B 82            [24] 1472 	mov	dpl, r3
      00B484 C0 07            [24] 1473 	push	ar7
      00B486 C0 06            [24] 1474 	push	ar6
      00B488 C0 05            [24] 1475 	push	ar5
      00B48A C0 04            [24] 1476 	push	ar4
      00B48C 12 86 AC         [24] 1477 	lcall	_dynamic_keymap_get_combo
      00B48F AA 82            [24] 1478 	mov	r2, dpl
      00B491 D0 04            [24] 1479 	pop	ar4
      00B493 D0 05            [24] 1480 	pop	ar5
      00B495 D0 06            [24] 1481 	pop	ar6
      00B497 D0 07            [24] 1482 	pop	ar7
      00B499 12 39 08         [24] 1483 	lcall	_ak820_outline_0123
      00B49C EA               [12] 1484 	mov	a,r2
      00B49D F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
      00B49E 7B 00            [12] 1487 	mov	r3,#0x00
      00B4A0 90 0D C2         [24] 1488 	mov	dptr,#___memcpy_PARM_2
      00B4A3 74 86            [12] 1489 	mov	a,#_vial_handle_cmd_entry_70000_638
      00B4A5 F0               [24] 1490 	movx	@dptr,a
      00B4A6 74 0C            [12] 1491 	mov	a,#(_vial_handle_cmd_entry_70000_638 >> 8)
      00B4A8 12 38 E0         [24] 1492 	lcall	_ak820_outline_0081
      00B4AB 90 0D C5         [24] 1493 	mov	dptr,#___memcpy_PARM_3
      00B4AE 12 8F 5C         [24] 1494 	lcall	_ak820_outline_0101
      00B4B1 12 34 76         [24] 1495 	lcall	_ak820_outline_0132
      00B4B4 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:357: break;
      00B4B6 02 BC 07         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:359: case dynamic_vial_combo_set: {
      00B4B9                       1500 00125$:
                                   1501 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B4B9 12 B0 28         [24] 1502 	lcall	_ak820_outline_0019
      00B4BC FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
      00B4BD 74 04            [12] 1505 	mov	a,#0x04
      00B4BF 2E               [12] 1506 	add	a, r6
      00B4C0 FB               [12] 1507 	mov	r3,a
      00B4C1 E4               [12] 1508 	clr	a
      00B4C2 3F               [12] 1509 	addc	a, r7
      00B4C3 FC               [12] 1510 	mov	r4,a
      00B4C4 90 0D C2         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00B4C7 EB               [12] 1512 	mov	a,r3
      00B4C8 F0               [24] 1513 	movx	@dptr,a
      00B4C9 EC               [12] 1514 	mov	a,r4
      00B4CA 12 38 E0         [24] 1515 	lcall	_ak820_outline_0081
      00B4CD 90 0D C5         [24] 1516 	mov	dptr,#___memcpy_PARM_3
      00B4D0 12 8F 5C         [24] 1517 	lcall	_ak820_outline_0101
      00B4D3 90 0C 90         [24] 1518 	mov	dptr,#_vial_handle_cmd_entry_70000_639
      00B4D6 F5 F0            [12] 1519 	mov	b,a
      00B4D8 C0 07            [24] 1520 	push	ar7
      00B4DA C0 06            [24] 1521 	push	ar6
      00B4DC C0 05            [24] 1522 	push	ar5
      00B4DE 12 BC 07         [24] 1523 	lcall	___memcpy
                                   1524 ;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
      00B4E1 90 0C 98         [24] 1525 	mov	dptr,#(_vial_handle_cmd_entry_70000_639 + 0x0008)
      00B4E4 12 39 28         [24] 1526 	lcall	_ak820_outline_0147
      00B4E7 12 34 71         [24] 1527 	lcall	_ak820_outline_0129
      00B4EA 12 B1 03         [24] 1528 	lcall	_vial_keycode_firewall
      00B4ED AB 82            [24] 1529 	mov	r3, dpl
      00B4EF AC 83            [24] 1530 	mov	r4, dph
      00B4F1 D0 05            [24] 1531 	pop	ar5
      00B4F3 90 0C 98         [24] 1532 	mov	dptr,#(_vial_handle_cmd_entry_70000_639 + 0x0008)
      00B4F6 12 38 F2         [24] 1533 	lcall	_ak820_outline_0103
                                   1534 ;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B4F9 90 0A EA         [24] 1535 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B4FC 74 90            [12] 1536 	mov	a,#_vial_handle_cmd_entry_70000_639
      00B4FE F0               [24] 1537 	movx	@dptr,a
      00B4FF 74 0C            [12] 1538 	mov	a,#(_vial_handle_cmd_entry_70000_639 >> 8)
      00B501 12 38 E0         [24] 1539 	lcall	_ak820_outline_0081
      00B504 8D 82            [24] 1540 	mov	dpl, r5
      00B506 12 87 4E         [24] 1541 	lcall	_dynamic_keymap_set_combo
      00B509 AC 82            [24] 1542 	mov	r4, dpl
      00B50B D0 06            [24] 1543 	pop	ar6
      00B50D D0 07            [24] 1544 	pop	ar7
      00B50F 12 39 08         [24] 1545 	lcall	_ak820_outline_0123
      00B512 EC               [12] 1546 	mov	a,r4
      00B513 F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/vial.c:365: if (!msg[0]) reload_combo();
      00B514 EC               [12] 1549 	mov	a,r4
      00B515 70 03            [24] 1550 	jnz	00139$
                                   1551 ;	quantum/vial.c:391: }
                                   1552 ;	quantum/vial.c:392: }
      00B517 02 36 02         [24] 1553 	ljmp	_ak820_combo_reload
      00B51A                       1554 00139$:
      00B51A 22               [24] 1555 	ret
                                   1556 ;------------------------------------------------------------
                                   1557 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1558 ;------------------------------------------------------------
                                   1559 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_641'
                                   1560 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_648'
                                   1561 ;------------------------------------------------------------
                                   1562 ;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
                                   1563 ;	-----------------------------------------
                                   1564 ;	 function vial_keycode_down
                                   1565 ;	-----------------------------------------
      00B51B                       1566 _vial_keycode_down:
      00B51B 12 39 03         [24] 1567 	lcall	_ak820_outline_0122
      00B51E 90 0C 9C         [24] 1568 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B521 12 38 FE         [24] 1569 	lcall	_ak820_outline_0121
                                   1570 ;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B524 90 0C 9C         [24] 1571 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B527 12 48 9E         [24] 1572 	lcall	_ak820_outline_0013
      00B52A 74 E0            [12] 1573 	mov	a,#0x100 - 0x20
      00B52C 2D               [12] 1574 	add	a,r5
      00B52D 50 19            [24] 1575 	jnc	00104$
      00B52F C3               [12] 1576 	clr	c
      00B530 74 FF            [12] 1577 	mov	a,#0xff
      00B532 9C               [12] 1578 	subb	a,r4
      00B533 74 4F            [12] 1579 	mov	a,#0x4f
      00B535 9D               [12] 1580 	subb	a,r5
      00B536 40 10            [24] 1581 	jc	00104$
                                   1582 ;	free result
                                   1583 ;	quantum/vial.c:401: keycode = (uint8_t)keycode;
      00B538 90 0C 9C         [24] 1584 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B53B EE               [12] 1585 	mov	a,r6
      00B53C 12 39 0D         [24] 1586 	lcall	_ak820_outline_0130
                                   1587 ;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
      00B53F 90 0C 9C         [24] 1588 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B542 E0               [24] 1589 	movx	a,@dptr
      00B543 24 FE            [12] 1590 	add	a,#0xff - 0x01
      00B545 40 01            [24] 1591 	jc	00104$
                                   1592 ;	free result
      00B547 22               [24] 1593 	ret
      00B548                       1594 00104$:
                                   1595 ;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
      00B548 90 0C 9C         [24] 1596 	mov	dptr,#_vial_keycode_down_keycode_10000_641
      00B54B 12 B6 1C         [24] 1597 	lcall	_ak820_outline_0026
                                   1598 ;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
      00B54E 40 06            [24] 1599 	jc	00107$
                                   1600 ;	free result
                                   1601 ;	quantum/vial.c:408: register_code16(keycode);
      00B550 12 39 08         [24] 1602 	lcall	_ak820_outline_0123
      00B553 02 A0 CC         [24] 1603 	ljmp	_register_code16
      00B556                       1604 00107$:
                                   1605 ;	quantum/vial.c:410: keyevent_t dummy_event = {
      00B556 90 0C A2         [24] 1606 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0004)
      00B559 74 01            [12] 1607 	mov	a,#0x01
      00B55B F0               [24] 1608 	movx	@dptr,a
      00B55C 90 0C 9F         [24] 1609 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0001)
      00B55F 74 F0            [12] 1610 	mov	a,#0xf0
      00B561 F0               [24] 1611 	movx	@dptr,a
      00B562 90 0C 9E         [24] 1612 	mov	dptr,#_vial_keycode_down_dummy_event_30000_648
      00B565 F0               [24] 1613 	movx	@dptr,a
      00B566 90 0C A3         [24] 1614 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0005)
      00B569 74 01            [12] 1615 	mov	a,#0x01
      00B56B F0               [24] 1616 	movx	@dptr,a
      00B56C 12 49 A8         [24] 1617 	lcall	_timer_read
      00B56F 12 43 D5         [24] 1618 	lcall	_ak820_outline_0131
      00B572 43 06 01         [24] 1619 	orl	ar6,#0x01
      00B575 90 0C A0         [24] 1620 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_648 + 0x0002)
      00B578 12 48 F9         [24] 1621 	lcall	_ak820_outline_0068
                                   1622 ;	quantum/vial.c:414: action_exec(dummy_event);
      00B57B 90 0D C2         [24] 1623 	mov	dptr,#___memcpy_PARM_2
      00B57E 74 9E            [12] 1624 	mov	a,#_vial_keycode_down_dummy_event_30000_648
      00B580 F0               [24] 1625 	movx	@dptr,a
      00B581 74 0C            [12] 1626 	mov	a,#(_vial_keycode_down_dummy_event_30000_648 >> 8)
      00B583 12 B6 35         [24] 1627 	lcall	_ak820_outline_0049
      00B586 12 BC 07         [24] 1628 	lcall	___memcpy
                                   1629 ;	quantum/vial.c:416: }
      00B589 02 71 15         [24] 1630 	ljmp	_action_exec
                                   1631 ;------------------------------------------------------------
                                   1632 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1633 ;------------------------------------------------------------
                                   1634 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_649'
                                   1635 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_656'
                                   1636 ;------------------------------------------------------------
                                   1637 ;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
                                   1638 ;	-----------------------------------------
                                   1639 ;	 function vial_keycode_up
                                   1640 ;	-----------------------------------------
      00B58C                       1641 _vial_keycode_up:
      00B58C 12 39 03         [24] 1642 	lcall	_ak820_outline_0122
      00B58F 90 0C A4         [24] 1643 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B592 12 38 FE         [24] 1644 	lcall	_ak820_outline_0121
                                   1645 ;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B595 90 0C A4         [24] 1646 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B598 12 48 9E         [24] 1647 	lcall	_ak820_outline_0013
      00B59B 74 E0            [12] 1648 	mov	a,#0x100 - 0x20
      00B59D 2D               [12] 1649 	add	a,r5
      00B59E 50 19            [24] 1650 	jnc	00104$
      00B5A0 C3               [12] 1651 	clr	c
      00B5A1 74 FF            [12] 1652 	mov	a,#0xff
      00B5A3 9C               [12] 1653 	subb	a,r4
      00B5A4 74 4F            [12] 1654 	mov	a,#0x4f
      00B5A6 9D               [12] 1655 	subb	a,r5
      00B5A7 40 10            [24] 1656 	jc	00104$
                                   1657 ;	free result
                                   1658 ;	quantum/vial.c:423: keycode = (uint8_t)keycode;
      00B5A9 90 0C A4         [24] 1659 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B5AC EE               [12] 1660 	mov	a,r6
      00B5AD 12 39 0D         [24] 1661 	lcall	_ak820_outline_0130
                                   1662 ;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
      00B5B0 90 0C A4         [24] 1663 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B5B3 E0               [24] 1664 	movx	a,@dptr
      00B5B4 24 FE            [12] 1665 	add	a,#0xff - 0x01
      00B5B6 40 01            [24] 1666 	jc	00104$
                                   1667 ;	free result
      00B5B8 22               [24] 1668 	ret
      00B5B9                       1669 00104$:
                                   1670 ;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
      00B5B9 90 0C A4         [24] 1671 	mov	dptr,#_vial_keycode_up_keycode_10000_649
      00B5BC 12 B6 1C         [24] 1672 	lcall	_ak820_outline_0026
                                   1673 ;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
      00B5BF 40 06            [24] 1674 	jc	00107$
                                   1675 ;	free result
                                   1676 ;	quantum/vial.c:430: unregister_code16(keycode);
      00B5C1 12 39 08         [24] 1677 	lcall	_ak820_outline_0123
      00B5C4 02 A1 11         [24] 1678 	ljmp	_unregister_code16
      00B5C7                       1679 00107$:
                                   1680 ;	quantum/vial.c:432: keyevent_t dummy_event = {
      00B5C7 90 0C AA         [24] 1681 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0004)
      00B5CA 74 01            [12] 1682 	mov	a,#0x01
      00B5CC F0               [24] 1683 	movx	@dptr,a
      00B5CD 90 0C A7         [24] 1684 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0001)
      00B5D0 74 F0            [12] 1685 	mov	a,#0xf0
      00B5D2 F0               [24] 1686 	movx	@dptr,a
      00B5D3 90 0C A6         [24] 1687 	mov	dptr,#_vial_keycode_up_dummy_event_30000_656
      00B5D6 F0               [24] 1688 	movx	@dptr,a
      00B5D7 90 0C AB         [24] 1689 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0005)
      00B5DA E4               [12] 1690 	clr	a
      00B5DB F0               [24] 1691 	movx	@dptr,a
      00B5DC 12 49 A8         [24] 1692 	lcall	_timer_read
      00B5DF 12 43 D5         [24] 1693 	lcall	_ak820_outline_0131
      00B5E2 43 06 01         [24] 1694 	orl	ar6,#0x01
      00B5E5 90 0C A8         [24] 1695 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_656 + 0x0002)
      00B5E8 12 48 F9         [24] 1696 	lcall	_ak820_outline_0068
                                   1697 ;	quantum/vial.c:436: action_exec(dummy_event);
      00B5EB 90 0D C2         [24] 1698 	mov	dptr,#___memcpy_PARM_2
      00B5EE 74 A6            [12] 1699 	mov	a,#_vial_keycode_up_dummy_event_30000_656
      00B5F0 F0               [24] 1700 	movx	@dptr,a
      00B5F1 74 0C            [12] 1701 	mov	a,#(_vial_keycode_up_dummy_event_30000_656 >> 8)
      00B5F3 12 B6 35         [24] 1702 	lcall	_ak820_outline_0049
      00B5F6 12 BC 07         [24] 1703 	lcall	___memcpy
                                   1704 ;	quantum/vial.c:438: }
      00B5F9 02 71 15         [24] 1705 	ljmp	_action_exec
                                   1706 ;------------------------------------------------------------
                                   1707 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1708 ;------------------------------------------------------------
                                   1709 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_657'
                                   1710 ;i             Allocated with name '_vial_keycode_tap_i_30000_660'
                                   1711 ;------------------------------------------------------------
                                   1712 ;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
                                   1713 ;	-----------------------------------------
                                   1714 ;	 function vial_keycode_tap
                                   1715 ;	-----------------------------------------
      00B5FC                       1716 _vial_keycode_tap:
      00B5FC 12 39 03         [24] 1717 	lcall	_ak820_outline_0122
      00B5FF 90 0C AC         [24] 1718 	mov	dptr,#_vial_keycode_tap_keycode_10000_657
      00B602 12 38 FE         [24] 1719 	lcall	_ak820_outline_0121
                                   1720 ;	quantum/vial.c:441: vial_keycode_down(keycode);
      00B605 90 0C AC         [24] 1721 	mov	dptr,#_vial_keycode_tap_keycode_10000_657
      00B608 12 38 81         [24] 1722 	lcall	_ak820_outline_0010
      00B60B C0 07            [24] 1723 	push	ar7
      00B60D C0 06            [24] 1724 	push	ar6
      00B60F 12 B5 1B         [24] 1725 	lcall	_vial_keycode_down
      00B612 D0 06            [24] 1726 	pop	ar6
      00B614 D0 07            [24] 1727 	pop	ar7
                                   1728 ;	quantum/vial.c:443: vial_keycode_up(keycode);
      00B616 12 39 08         [24] 1729 	lcall	_ak820_outline_0123
                                   1730 ;	quantum/vial.c:444: }
      00B619 02 B5 8C         [24] 1731 	ljmp	_vial_keycode_up
                                   1732 ;------------------------------------------------------------
                                   1733 ;Allocation info for local variables in function 'process_record_vial'
                                   1734 ;------------------------------------------------------------
                                   1735 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1736 ;keycode       Allocated with name '_process_record_vial_keycode_10000_662'
                                   1737 ;------------------------------------------------------------
                                   1738 ;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1739 ;	-----------------------------------------
                                   1740 	.area CSEG    (CODE)
                                   1741 	.area CONST   (CODE)
                                   1742 	.area CONST   (CODE)
      00C18A                       1743 _keyboard_definition:
      00C18A FD                    1744 	.db #0xfd	; 253
      00C18B 37                    1745 	.db #0x37	; 55	'7'
      00C18C 7A                    1746 	.db #0x7a	; 122	'z'
      00C18D 58                    1747 	.db #0x58	; 88	'X'
      00C18E 5A                    1748 	.db #0x5a	; 90	'Z'
      00C18F 00                    1749 	.db #0x00	; 0
      00C190 00                    1750 	.db #0x00	; 0
      00C191 04                    1751 	.db #0x04	; 4
      00C192 E6                    1752 	.db #0xe6	; 230
      00C193 D6                    1753 	.db #0xd6	; 214
      00C194 B4                    1754 	.db #0xb4	; 180
      00C195 46                    1755 	.db #0x46	; 70	'F'
      00C196 02                    1756 	.db #0x02	; 2
      00C197 00                    1757 	.db #0x00	; 0
      00C198 21                    1758 	.db #0x21	; 33
      00C199 01                    1759 	.db #0x01	; 1
      00C19A 00                    1760 	.db #0x00	; 0
      00C19B 00                    1761 	.db #0x00	; 0
      00C19C 00                    1762 	.db #0x00	; 0
      00C19D 00                    1763 	.db #0x00	; 0
      00C19E 37                    1764 	.db #0x37	; 55	'7'
      00C19F 27                    1765 	.db #0x27	; 39
      00C1A0 97                    1766 	.db #0x97	; 151
      00C1A1 D6                    1767 	.db #0xd6	; 214
      00C1A2 E0                    1768 	.db #0xe0	; 224
      00C1A3 03                    1769 	.db #0x03	; 3
      00C1A4 CB                    1770 	.db #0xcb	; 203
      00C1A5 01                    1771 	.db #0x01	; 1
      00C1A6 3C                    1772 	.db #0x3c	; 60
      00C1A7 00                    1773 	.db #0x00	; 0
      00C1A8 00                    1774 	.db #0x00	; 0
      00C1A9 3D                    1775 	.db #0x3d	; 61
      00C1AA 88                    1776 	.db #0x88	; 136
      00C1AB CD                    1777 	.db #0xcd	; 205
      00C1AC A5                    1778 	.db #0xa5	; 165
      00C1AD AA                    1779 	.db #0xaa	; 170
      00C1AE E5                    1780 	.db #0xe5	; 229
      00C1AF A8                    1781 	.db #0xa8	; 168
      00C1B0 76                    1782 	.db #0x76	; 118	'v'
      00C1B1 F6                    1783 	.db #0xf6	; 246
      00C1B2 43                    1784 	.db #0x43	; 67	'C'
      00C1B3 0E                    1785 	.db #0x0e	; 14
      00C1B4 D2                    1786 	.db #0xd2	; 210
      00C1B5 90                    1787 	.db #0x90	; 144
      00C1B6 7D                    1788 	.db #0x7d	; 125
      00C1B7 94                    1789 	.db #0x94	; 148
      00C1B8 79                    1790 	.db #0x79	; 121	'y'
      00C1B9 78                    1791 	.db #0x78	; 120	'x'
      00C1BA EF                    1792 	.db #0xef	; 239
      00C1BB 49                    1793 	.db #0x49	; 73	'I'
      00C1BC 3E                    1794 	.db #0x3e	; 62
      00C1BD EF                    1795 	.db #0xef	; 239
      00C1BE FD                    1796 	.db #0xfd	; 253
      00C1BF 8F                    1797 	.db #0x8f	; 143
      00C1C0 EF                    1798 	.db #0xef	; 239
      00C1C1 00                    1799 	.db #0x00	; 0
      00C1C2 C6                    1800 	.db #0xc6	; 198
      00C1C3 D1                    1801 	.db #0xd1	; 209
      00C1C4 DB                    1802 	.db #0xdb	; 219
      00C1C5 FB                    1803 	.db #0xfb	; 251
      00C1C6 EB                    1804 	.db #0xeb	; 235
      00C1C7 DE                    1805 	.db #0xde	; 222
      00C1C8 66                    1806 	.db #0x66	; 102	'f'
      00C1C9 63                    1807 	.db #0x63	; 99	'c'
      00C1CA 0C                    1808 	.db #0x0c	; 12
      00C1CB 92                    1809 	.db #0x92	; 146
      00C1CC 7B                    1810 	.db #0x7b	; 123
      00C1CD F9                    1811 	.db #0xf9	; 249
      00C1CE D4                    1812 	.db #0xd4	; 212
      00C1CF 7A                    1813 	.db #0x7a	; 122	'z'
      00C1D0 4F                    1814 	.db #0x4f	; 79	'O'
      00C1D1 83                    1815 	.db #0x83	; 131
      00C1D2 4B                    1816 	.db #0x4b	; 75	'K'
      00C1D3 86                    1817 	.db #0x86	; 134
      00C1D4 0E                    1818 	.db #0x0e	; 14
      00C1D5 6A                    1819 	.db #0x6a	; 106	'j'
      00C1D6 F2                    1820 	.db #0xf2	; 242
      00C1D7 22                    1821 	.db #0x22	; 34
      00C1D8 22                    1822 	.db #0x22	; 34
      00C1D9 0B                    1823 	.db #0x0b	; 11
      00C1DA 03                    1824 	.db #0x03	; 3
      00C1DB BA                    1825 	.db #0xba	; 186
      00C1DC 67                    1826 	.db #0x67	; 103	'g'
      00C1DD 9B                    1827 	.db #0x9b	; 155
      00C1DE 7A                    1828 	.db #0x7a	; 122	'z'
      00C1DF E1                    1829 	.db #0xe1	; 225
      00C1E0 BC                    1830 	.db #0xbc	; 188
      00C1E1 37                    1831 	.db #0x37	; 55	'7'
      00C1E2 26                    1832 	.db #0x26	; 38
      00C1E3 46                    1833 	.db #0x46	; 70	'F'
      00C1E4 78                    1834 	.db #0x78	; 120	'x'
      00C1E5 05                    1835 	.db #0x05	; 5
      00C1E6 0D                    1836 	.db #0x0d	; 13
      00C1E7 95                    1837 	.db #0x95	; 149
      00C1E8 02                    1838 	.db #0x02	; 2
      00C1E9 E4                    1839 	.db #0xe4	; 228
      00C1EA 18                    1840 	.db #0x18	; 24
      00C1EB CA                    1841 	.db #0xca	; 202
      00C1EC 33                    1842 	.db #0x33	; 51	'3'
      00C1ED EA                    1843 	.db #0xea	; 234
      00C1EE 24                    1844 	.db #0x24	; 36
      00C1EF C8                    1845 	.db #0xc8	; 200
      00C1F0 81                    1846 	.db #0x81	; 129
      00C1F1 4E                    1847 	.db #0x4e	; 78	'N'
      00C1F2 47                    1848 	.db #0x47	; 71	'G'
      00C1F3 A8                    1849 	.db #0xa8	; 168
      00C1F4 44                    1850 	.db #0x44	; 68	'D'
      00C1F5 DD                    1851 	.db #0xdd	; 221
      00C1F6 91                    1852 	.db #0x91	; 145
      00C1F7 6D                    1853 	.db #0x6d	; 109	'm'
      00C1F8 69                    1854 	.db #0x69	; 105	'i'
      00C1F9 DB                    1855 	.db #0xdb	; 219
      00C1FA 4F                    1856 	.db #0x4f	; 79	'O'
      00C1FB 3A                    1857 	.db #0x3a	; 58
      00C1FC 43                    1858 	.db #0x43	; 67	'C'
      00C1FD 9D                    1859 	.db #0x9d	; 157
      00C1FE 26                    1860 	.db #0x26	; 38
      00C1FF 49                    1861 	.db #0x49	; 73	'I'
      00C200 4C                    1862 	.db #0x4c	; 76	'L'
      00C201 EF                    1863 	.db #0xef	; 239
      00C202 2B                    1864 	.db #0x2b	; 43
      00C203 D8                    1865 	.db #0xd8	; 216
      00C204 55                    1866 	.db #0x55	; 85	'U'
      00C205 95                    1867 	.db #0x95	; 149
      00C206 70                    1868 	.db #0x70	; 112	'p'
      00C207 B1                    1869 	.db #0xb1	; 177
      00C208 CC                    1870 	.db #0xcc	; 204
      00C209 CF                    1871 	.db #0xcf	; 207
      00C20A 13                    1872 	.db #0x13	; 19
      00C20B 32                    1873 	.db #0x32	; 50	'2'
      00C20C 6A                    1874 	.db #0x6a	; 106	'j'
      00C20D A1                    1875 	.db #0xa1	; 161
      00C20E FF                    1876 	.db #0xff	; 255
      00C20F 99                    1877 	.db #0x99	; 153
      00C210 61                    1878 	.db #0x61	; 97	'a'
      00C211 95                    1879 	.db #0x95	; 149
      00C212 B1                    1880 	.db #0xb1	; 177
      00C213 89                    1881 	.db #0x89	; 137
      00C214 9B                    1882 	.db #0x9b	; 155
      00C215 11                    1883 	.db #0x11	; 17
      00C216 D9                    1884 	.db #0xd9	; 217
      00C217 35                    1885 	.db #0x35	; 53	'5'
      00C218 78                    1886 	.db #0x78	; 120	'x'
      00C219 ED                    1887 	.db #0xed	; 237
      00C21A CD                    1888 	.db #0xcd	; 205
      00C21B 94                    1889 	.db #0x94	; 148
      00C21C 6E                    1890 	.db #0x6e	; 110	'n'
      00C21D 60                    1891 	.db #0x60	; 96
      00C21E 8E                    1892 	.db #0x8e	; 142
      00C21F 63                    1893 	.db #0x63	; 99	'c'
      00C220 8B                    1894 	.db #0x8b	; 139
      00C221 FF                    1895 	.db #0xff	; 255
      00C222 4E                    1896 	.db #0x4e	; 78	'N'
      00C223 20                    1897 	.db #0x20	; 32
      00C224 7A                    1898 	.db #0x7a	; 122	'z'
      00C225 B5                    1899 	.db #0xb5	; 181
      00C226 87                    1900 	.db #0x87	; 135
      00C227 C2                    1901 	.db #0xc2	; 194
      00C228 35                    1902 	.db #0x35	; 53	'5'
      00C229 A4                    1903 	.db #0xa4	; 164
      00C22A 6D                    1904 	.db #0x6d	; 109	'm'
      00C22B 18                    1905 	.db #0x18	; 24
      00C22C C1                    1906 	.db #0xc1	; 193
      00C22D A3                    1907 	.db #0xa3	; 163
      00C22E DB                    1908 	.db #0xdb	; 219
      00C22F 53                    1909 	.db #0x53	; 83	'S'
      00C230 1D                    1910 	.db #0x1d	; 29
      00C231 EC                    1911 	.db #0xec	; 236
      00C232 F0                    1912 	.db #0xf0	; 240
      00C233 BF                    1913 	.db #0xbf	; 191
      00C234 4A                    1914 	.db #0x4a	; 74	'J'
      00C235 4C                    1915 	.db #0x4c	; 76	'L'
      00C236 4A                    1916 	.db #0x4a	; 74	'J'
      00C237 C4                    1917 	.db #0xc4	; 196
      00C238 AA                    1918 	.db #0xaa	; 170
      00C239 37                    1919 	.db #0x37	; 55	'7'
      00C23A 19                    1920 	.db #0x19	; 25
      00C23B 34                    1921 	.db #0x34	; 52	'4'
      00C23C 3F                    1922 	.db #0x3f	; 63
      00C23D A1                    1923 	.db #0xa1	; 161
      00C23E D3                    1924 	.db #0xd3	; 211
      00C23F 1A                    1925 	.db #0x1a	; 26
      00C240 5C                    1926 	.db #0x5c	; 92
      00C241 03                    1927 	.db #0x03	; 3
      00C242 4D                    1928 	.db #0x4d	; 77	'M'
      00C243 BC                    1929 	.db #0xbc	; 188
      00C244 10                    1930 	.db #0x10	; 16
      00C245 2E                    1931 	.db #0x2e	; 46
      00C246 80                    1932 	.db #0x80	; 128
      00C247 F7                    1933 	.db #0xf7	; 247
      00C248 D6                    1934 	.db #0xd6	; 214
      00C249 82                    1935 	.db #0x82	; 130
      00C24A 24                    1936 	.db #0x24	; 36
      00C24B 4C                    1937 	.db #0x4c	; 76	'L'
      00C24C 87                    1938 	.db #0x87	; 135
      00C24D B9                    1939 	.db #0xb9	; 185
      00C24E F8                    1940 	.db #0xf8	; 248
      00C24F BE                    1941 	.db #0xbe	; 190
      00C250 67                    1942 	.db #0x67	; 103	'g'
      00C251 96                    1943 	.db #0x96	; 150
      00C252 89                    1944 	.db #0x89	; 137
      00C253 30                    1945 	.db #0x30	; 48	'0'
      00C254 C8                    1946 	.db #0xc8	; 200
      00C255 8D                    1947 	.db #0x8d	; 141
      00C256 2C                    1948 	.db #0x2c	; 44
      00C257 F5                    1949 	.db #0xf5	; 245
      00C258 06                    1950 	.db #0x06	; 6
      00C259 05                    1951 	.db #0x05	; 5
      00C25A 7C                    1952 	.db #0x7c	; 124
      00C25B 48                    1953 	.db #0x48	; 72	'H'
      00C25C 1B                    1954 	.db #0x1b	; 27
      00C25D 76                    1955 	.db #0x76	; 118	'v'
      00C25E AA                    1956 	.db #0xaa	; 170
      00C25F 3D                    1957 	.db #0x3d	; 61
      00C260 28                    1958 	.db #0x28	; 40
      00C261 FC                    1959 	.db #0xfc	; 252
      00C262 80                    1960 	.db #0x80	; 128
      00C263 75                    1961 	.db #0x75	; 117	'u'
      00C264 EB                    1962 	.db #0xeb	; 235
      00C265 78                    1963 	.db #0x78	; 120	'x'
      00C266 D0                    1964 	.db #0xd0	; 208
      00C267 8A                    1965 	.db #0x8a	; 138
      00C268 8F                    1966 	.db #0x8f	; 143
      00C269 27                    1967 	.db #0x27	; 39
      00C26A F7                    1968 	.db #0xf7	; 247
      00C26B F2                    1969 	.db #0xf2	; 242
      00C26C EB                    1970 	.db #0xeb	; 235
      00C26D 58                    1971 	.db #0x58	; 88	'X'
      00C26E 37                    1972 	.db #0x37	; 55	'7'
      00C26F 3C                    1973 	.db #0x3c	; 60
      00C270 2B                    1974 	.db #0x2b	; 43
      00C271 6F                    1975 	.db #0x6f	; 111	'o'
      00C272 0E                    1976 	.db #0x0e	; 14
      00C273 C7                    1977 	.db #0xc7	; 199
      00C274 E2                    1978 	.db #0xe2	; 226
      00C275 A0                    1979 	.db #0xa0	; 160
      00C276 97                    1980 	.db #0x97	; 151
      00C277 EE                    1981 	.db #0xee	; 238
      00C278 FD                    1982 	.db #0xfd	; 253
      00C279 9F                    1983 	.db #0x9f	; 159
      00C27A 45                    1984 	.db #0x45	; 69	'E'
      00C27B 17                    1985 	.db #0x17	; 23
      00C27C 94                    1986 	.db #0x94	; 148
      00C27D E6                    1987 	.db #0xe6	; 230
      00C27E E7                    1988 	.db #0xe7	; 231
      00C27F FA                    1989 	.db #0xfa	; 250
      00C280 4C                    1990 	.db #0x4c	; 76	'L'
      00C281 7A                    1991 	.db #0x7a	; 122	'z'
      00C282 D6                    1992 	.db #0xd6	; 214
      00C283 7A                    1993 	.db #0x7a	; 122	'z'
      00C284 7B                    1994 	.db #0x7b	; 123
      00C285 ED                    1995 	.db #0xed	; 237
      00C286 10                    1996 	.db #0x10	; 16
      00C287 C5                    1997 	.db #0xc5	; 197
      00C288 BC                    1998 	.db #0xbc	; 188
      00C289 E3                    1999 	.db #0xe3	; 227
      00C28A A9                    2000 	.db #0xa9	; 169
      00C28B 1F                    2001 	.db #0x1f	; 31
      00C28C CF                    2002 	.db #0xcf	; 207
      00C28D C4                    2003 	.db #0xc4	; 196
      00C28E 9D                    2004 	.db #0x9d	; 157
      00C28F DC                    2005 	.db #0xdc	; 220
      00C290 45                    2006 	.db #0x45	; 69	'E'
      00C291 2A                    2007 	.db #0x2a	; 42
      00C292 69                    2008 	.db #0x69	; 105	'i'
      00C293 57                    2009 	.db #0x57	; 87	'W'
      00C294 8F                    2010 	.db #0x8f	; 143
      00C295 EC                    2011 	.db #0xec	; 236
      00C296 85                    2012 	.db #0x85	; 133
      00C297 6C                    2013 	.db #0x6c	; 108	'l'
      00C298 43                    2014 	.db #0x43	; 67	'C'
      00C299 1C                    2015 	.db #0x1c	; 28
      00C29A BA                    2016 	.db #0xba	; 186
      00C29B 89                    2017 	.db #0x89	; 137
      00C29C 68                    2018 	.db #0x68	; 104	'h'
      00C29D 4A                    2019 	.db #0x4a	; 74	'J'
      00C29E 1C                    2020 	.db #0x1c	; 28
      00C29F 91                    2021 	.db #0x91	; 145
      00C2A0 3F                    2022 	.db #0x3f	; 63
      00C2A1 D1                    2023 	.db #0xd1	; 209
      00C2A2 B3                    2024 	.db #0xb3	; 179
      00C2A3 96                    2025 	.db #0x96	; 150
      00C2A4 1D                    2026 	.db #0x1d	; 29
      00C2A5 7C                    2027 	.db #0x7c	; 124
      00C2A6 14                    2028 	.db #0x14	; 20
      00C2A7 77                    2029 	.db #0x77	; 119	'w'
      00C2A8 9C                    2030 	.db #0x9c	; 156
      00C2A9 74                    2031 	.db #0x74	; 116	't'
      00C2AA 36                    2032 	.db #0x36	; 54	'6'
      00C2AB FF                    2033 	.db #0xff	; 255
      00C2AC 2C                    2034 	.db #0x2c	; 44
      00C2AD 66                    2035 	.db #0x66	; 102	'f'
      00C2AE AF                    2036 	.db #0xaf	; 175
      00C2AF 0F                    2037 	.db #0x0f	; 15
      00C2B0 3C                    2038 	.db #0x3c	; 60
      00C2B1 A2                    2039 	.db #0xa2	; 162
      00C2B2 23                    2040 	.db #0x23	; 35
      00C2B3 85                    2041 	.db #0x85	; 133
      00C2B4 05                    2042 	.db #0x05	; 5
      00C2B5 87                    2043 	.db #0x87	; 135
      00C2B6 DA                    2044 	.db #0xda	; 218
      00C2B7 61                    2045 	.db #0x61	; 97	'a'
      00C2B8 5E                    2046 	.db #0x5e	; 94
      00C2B9 42                    2047 	.db #0x42	; 66	'B'
      00C2BA 54                    2048 	.db #0x54	; 84	'T'
      00C2BB 60                    2049 	.db #0x60	; 96
      00C2BC 23                    2050 	.db #0x23	; 35
      00C2BD CA                    2051 	.db #0xca	; 202
      00C2BE BC                    2052 	.db #0xbc	; 188
      00C2BF B3                    2053 	.db #0xb3	; 179
      00C2C0 18                    2054 	.db #0x18	; 24
      00C2C1 1D                    2055 	.db #0x1d	; 29
      00C2C2 F8                    2056 	.db #0xf8	; 248
      00C2C3 0A                    2057 	.db #0x0a	; 10
      00C2C4 55                    2058 	.db #0x55	; 85	'U'
      00C2C5 CD                    2059 	.db #0xcd	; 205
      00C2C6 A3                    2060 	.db #0xa3	; 163
      00C2C7 DE                    2061 	.db #0xde	; 222
      00C2C8 FF                    2062 	.db #0xff	; 255
      00C2C9 B2                    2063 	.db #0xb2	; 178
      00C2CA 2A                    2064 	.db #0x2a	; 42
      00C2CB 35                    2065 	.db #0x35	; 53	'5'
      00C2CC 00                    2066 	.db #0x00	; 0
      00C2CD D6                    2067 	.db #0xd6	; 214
      00C2CE 7B                    2068 	.db #0x7b	; 123
      00C2CF E8                    2069 	.db #0xe8	; 232
      00C2D0 F2                    2070 	.db #0xf2	; 242
      00C2D1 1A                    2071 	.db #0x1a	; 26
      00C2D2 BC                    2072 	.db #0xbc	; 188
      00C2D3 F5                    2073 	.db #0xf5	; 245
      00C2D4 7E                    2074 	.db #0x7e	; 126
      00C2D5 48                    2075 	.db #0x48	; 72	'H'
      00C2D6 72                    2076 	.db #0x72	; 114	'r'
      00C2D7 E0                    2077 	.db #0xe0	; 224
      00C2D8 E4                    2078 	.db #0xe4	; 228
      00C2D9 E0                    2079 	.db #0xe0	; 224
      00C2DA 27                    2080 	.db #0x27	; 39
      00C2DB 87                    2081 	.db #0x87	; 135
      00C2DC 9A                    2082 	.db #0x9a	; 154
      00C2DD 51                    2083 	.db #0x51	; 81	'Q'
      00C2DE D4                    2084 	.db #0xd4	; 212
      00C2DF DD                    2085 	.db #0xdd	; 221
      00C2E0 C3                    2086 	.db #0xc3	; 195
      00C2E1 AA                    2087 	.db #0xaa	; 170
      00C2E2 49                    2088 	.db #0x49	; 73	'I'
      00C2E3 5A                    2089 	.db #0x5a	; 90	'Z'
      00C2E4 2A                    2090 	.db #0x2a	; 42
      00C2E5 00                    2091 	.db #0x00	; 0
      00C2E6 A0                    2092 	.db #0xa0	; 160
      00C2E7 8C                    2093 	.db #0x8c	; 140
      00C2E8 FF                    2094 	.db #0xff	; 255
      00C2E9 74                    2095 	.db #0x74	; 116	't'
      00C2EA BF                    2096 	.db #0xbf	; 191
      00C2EB EC                    2097 	.db #0xec	; 236
      00C2EC 1D                    2098 	.db #0x1d	; 29
      00C2ED F1                    2099 	.db #0xf1	; 241
      00C2EE 00                    2100 	.db #0x00	; 0
      00C2EF 01                    2101 	.db #0x01	; 1
      00C2F0 D8                    2102 	.db #0xd8	; 216
      00C2F1 02                    2103 	.db #0x02	; 2
      00C2F2 CC                    2104 	.db #0xcc	; 204
      00C2F3 07                    2105 	.db #0x07	; 7
      00C2F4 00                    2106 	.db #0x00	; 0
      00C2F5 00                    2107 	.db #0x00	; 0
      00C2F6 C4                    2108 	.db #0xc4	; 196
      00C2F7 5E                    2109 	.db #0x5e	; 94
      00C2F8 2C                    2110 	.db #0x2c	; 44
      00C2F9 7E                    2111 	.db #0x7e	; 126
      00C2FA B1                    2112 	.db #0xb1	; 177
      00C2FB C4                    2113 	.db #0xc4	; 196
      00C2FC 67                    2114 	.db #0x67	; 103	'g'
      00C2FD FB                    2115 	.db #0xfb	; 251
      00C2FE 02                    2116 	.db #0x02	; 2
      00C2FF 00                    2117 	.db #0x00	; 0
      00C300 00                    2118 	.db #0x00	; 0
      00C301 00                    2119 	.db #0x00	; 0
      00C302 00                    2120 	.db #0x00	; 0
      00C303 04                    2121 	.db #0x04	; 4
      00C304 59                    2122 	.db #0x59	; 89	'Y'
      00C305 5A                    2123 	.db #0x5a	; 90	'Z'
                                   2124 	.area CSEG    (CODE)
                                   2125 	.area CONST   (CODE)
      00C306                       2126 _vial_handle_cmd_keyboard_uid_40000_615:
      00C306 04                    2127 	.db #0x04	; 4
      00C307 70                    2128 	.db #0x70	; 112	'p'
      00C308 FF                    2129 	.db #0xff	; 255
      00C309 90                    2130 	.db #0x90	; 144
      00C30A 01                    2131 	.db #0x01	; 1
      00C30B B9                    2132 	.db #0xb9	; 185
      00C30C 15                    2133 	.db #0x15	; 21
      00C30D D3                    2134 	.db #0xd3	; 211
                                   2135 	.area CSEG    (CODE)
                                   2136 	.area XINIT   (CODE)
      00C53C                       2137 __xinit__vial_unlocked:
      00C53C 00                    2138 	.db #0x00	;  0
      00C53D                       2139 __xinit__vial_unlock_in_progress:
      00C53D 00                    2140 	.db #0x00	;  0
      00C53E                       2141 __xinit__vial_unlock_counter:
      00C53E 00                    2142 	.db #0x00	; 0
      00C53F                       2143 __xinit__vial_unlock_combo_rows:
      00C53F 00                    2144 	.db #0x00	; 0
      00C540 00                    2145 	.db #0x00	; 0
      00C541                       2146 __xinit__vial_unlock_combo_cols:
      00C541 00                    2147 	.db #0x00	; 0
      00C542 05                    2148 	.db #0x05	; 5
                                   2149 	.area CABS    (ABS,CODE)
                                   2150 
                                   2151 ; Experimental exact instruction outlining.
                                   2152 	.globl _ak820_outline_0010
                                   2153 	.globl _ak820_outline_0011
                                   2154 	.globl _ak820_outline_0013
                                   2155 	.globl _ak820_outline_0016
                                   2156 	.globl _ak820_outline_0017
                                   2157 	.globl _ak820_outline_0019
                                   2158 	.globl _ak820_outline_0023
                                   2159 	.globl _ak820_outline_0024
                                   2160 	.globl _ak820_outline_0026
                                   2161 	.globl _ak820_outline_0034
                                   2162 	.globl _ak820_outline_0036
                                   2163 	.globl _ak820_outline_0038
                                   2164 	.globl _ak820_outline_0044
                                   2165 	.globl _ak820_outline_0045
                                   2166 	.globl _ak820_outline_0049
                                   2167 	.globl _ak820_outline_0054
                                   2168 	.globl _ak820_outline_0055
                                   2169 	.globl _ak820_outline_0060
                                   2170 	.globl _ak820_outline_0064
                                   2171 	.globl _ak820_outline_0068
                                   2172 	.globl _ak820_outline_0073
                                   2173 	.globl _ak820_outline_0081
                                   2174 	.globl _ak820_outline_0088
                                   2175 	.globl _ak820_outline_0101
                                   2176 	.globl _ak820_outline_0103
                                   2177 	.globl _ak820_outline_0121
                                   2178 	.globl _ak820_outline_0122
                                   2179 	.globl _ak820_outline_0123
                                   2180 	.globl _ak820_outline_0127
                                   2181 	.globl _ak820_outline_0129
                                   2182 	.globl _ak820_outline_0130
                                   2183 	.globl _ak820_outline_0131
                                   2184 	.globl _ak820_outline_0132
                                   2185 	.globl _ak820_outline_0134
                                   2186 	.globl _ak820_outline_0135
                                   2187 	.globl _ak820_outline_0140
                                   2188 	.globl _ak820_outline_0147
                                   2189 	.globl _ak820_outline_0155
                                   2190 	.globl _ak820_outline_0158
                                   2191 	.globl _ak820_outline_0174
                                   2192 	.globl _ak820_outline_0194
                                   2193 
                                   2194 	.area CSEG (CODE)
                                   2195 ; function ak820_outline_0026
      00B61C                       2196 _ak820_outline_0026:
      00B61C E0               [24] 2197 	movx	a,@dptr
      00B61D FE               [12] 2198 	mov	r6,a
      00B61E A3               [24] 2199 	inc	dptr
      00B61F E0               [24] 2200 	movx	a,@dptr
      00B620 FF               [12] 2201 	mov	r7,a
      00B621 90 0C 9A         [24] 2202 	mov	dptr,#_g_vial_magic_keycode_override
      00B624 EE               [12] 2203 	mov	a,r6
      00B625 F0               [24] 2204 	movx	@dptr,a
      00B626 EF               [12] 2205 	mov	a,r7
      00B627 A3               [24] 2206 	inc	dptr
      00B628 F0               [24] 2207 	movx	@dptr,a
      00B629 8E 04            [24] 2208 	mov	ar4,r6
      00B62B 8F 05            [24] 2209 	mov	ar5,r7
      00B62D C3               [12] 2210 	clr	c
      00B62E 74 FF            [12] 2211 	mov	a,#0xff
      00B630 9C               [12] 2212 	subb	a,r4
      00B631 74 1F            [12] 2213 	mov	a,#0x1f
      00B633 9D               [12] 2214 	subb	a,r5
      00B634 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0049
      00B635                       2219 _ak820_outline_0049:
      00B635 A3               [24] 2220 	inc	dptr
      00B636 F0               [24] 2221 	movx	@dptr,a
      00B637 E4               [12] 2222 	clr	a
      00B638 A3               [24] 2223 	inc	dptr
      00B639 F0               [24] 2224 	movx	@dptr,a
      00B63A 90 0D C5         [24] 2225 	mov	dptr,#___memcpy_PARM_3
      00B63D 74 06            [12] 2226 	mov	a,#0x06
      00B63F F0               [24] 2227 	movx	@dptr,a
      00B640 E4               [12] 2228 	clr	a
      00B641 A3               [24] 2229 	inc	dptr
      00B642 F0               [24] 2230 	movx	@dptr,a
      00B643 90 08 10         [24] 2231 	mov	dptr,#_action_exec_PARM_1
      00B646 F5 F0            [12] 2232 	mov	b,a
      00B648 22               [24] 2233 	ret
                                   2234 
                                   2235 	.area CSEG (CODE)
                                   2236 ; function ak820_outline_0134
      00B649                       2237 _ak820_outline_0134:
      00B649 24 47            [12] 2238 	add	a,#_vial_unlock_combo_cols
      00B64B F5 82            [12] 2239 	mov	dpl,a
      00B64D E4               [12] 2240 	clr	a
      00B64E 34 0E            [12] 2241 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B650 F5 83            [12] 2242 	mov	dph,a
      00B652 E0               [24] 2243 	movx	a,@dptr
      00B653 22               [24] 2244 	ret
                                   2245 
                                   2246 	.area CSEG (CODE)
                                   2247 ; function ak820_outline_0135
      00B654                       2248 _ak820_outline_0135:
      00B654 24 45            [12] 2249 	add	a,#_vial_unlock_combo_rows
      00B656 F5 82            [12] 2250 	mov	dpl,a
      00B658 E4               [12] 2251 	clr	a
      00B659 34 0E            [12] 2252 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B65B F5 83            [12] 2253 	mov	dph,a
      00B65D E0               [24] 2254 	movx	a,@dptr
      00B65E 22               [24] 2255 	ret
