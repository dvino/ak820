                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000597                        562 _source_state:
      000597                        563 	.ds 130
      000619                        564 _pending_time:
      000619                        565 	.ds 2
      00061B                        566 _pending_code:
      00061B                        567 	.ds 2
      00061D                        568 _ak820_tapping_source_PARM_1:
      00061D                        569 	.ds 2
      00061F                        570 _hold_PARM_2:
      00061F                        571 	.ds 1
      000620                        572 _hold_code_10000_594:
      000620                        573 	.ds 2
      000622                        574 _hold_mods_30000_597:
      000622                        575 	.ds 1
      000623                        576 _commit_pending_id_10000_603:
      000623                        577 	.ds 1
      000624                        578 _ak820_tapping_before_event_10000_604:
      000624                        579 	.ds 2
      000626                        580 _ak820_tapping_process_record_10000_615:
      000626                        581 	.ds 2
      000628                        582 _ak820_tapping_process_code_10000_616:
      000628                        583 	.ds 2
      00062A                        584 _ak820_tapping_process_sc_mods_10000_616:
      00062A                        585 	.ds 1
      00062B                        586 _ak820_oneshot_mods::
      00062B                        587 	.ds 1
      00062C                        588 _ak820_oneshot_consumed::
      00062C                        589 	.ds 1
      00062D                        590 _ak820_oneshot_process_PARM_2:
      00062D                        591 	.ds 1
      00062E                        592 _ak820_oneshot_process_PARM_3:
      00062E                        593 	.ds 1
      00062F                        594 _ak820_oneshot_process_code_10000_641:
      00062F                        595 	.ds 2
      000631                        596 _ak820_oneshot_process_mods_10000_642:
      000631                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DD2                        606 _pending:
      000DD2                        607 	.ds 1
      000DD3                        608 _ak820_oneshot_target::
      000DD3                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0043FE                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0043FE 90 06 1E         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004401 E0               [24]  656 	movx	a,@dptr
      004402 FF               [12]  657 	mov	r7,a
      004403 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004406                        659 00147$:
      004406 50 10            [24]  660 	jnc	00102$
      004408 90 06 1D         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      00440B E0               [24]  662 	movx	a,@dptr
      00440C FE               [12]  663 	mov	r6,a
      00440D BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004410                        665 00149$:
      004410 50 06            [24]  666 	jnc	00102$
      004412 12 49 29         [24]  667 	lcall	_ak820_outline_0177
      004415 F5 82            [12]  668 	mov	dpl,a
      004417 22               [24]  669 	ret
      004418                        670 00102$:
                                    671 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      004418 90 06 1D         [24]  672 	mov	dptr,#_ak820_tapping_source_PARM_1
      00441B E0               [24]  673 	movx	a,@dptr
      00441C FE               [12]  674 	mov	r6,a
      00441D BE 01 00         [24]  675 	cjne	r6,#0x01,00151$
      004420                        676 00151$:
      004420 50 0E            [24]  677 	jnc	00109$
                                    678 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004422 BF FD 04         [24]  679 	cjne	r7,#0xfd,00105$
      004425 75 82 80         [24]  680 	mov	dpl, #0x80
      004428 22               [24]  681 	ret
      004429                        682 00105$:
                                    683 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004429 BF FC 04         [24]  684 	cjne	r7,#0xfc,00109$
      00442C 75 82 81         [24]  685 	mov	dpl, #0x81
      00442F 22               [24]  686 	ret
      004430                        687 00109$:
                                    688 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      004430 75 82 FF         [24]  689 	mov	dpl, #0xff
                                    690 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004433 22               [24]  691 	ret
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'hold'
                                    694 ;------------------------------------------------------------
                                    695 ;pressed       Allocated with name '_hold_PARM_2'
                                    696 ;code          Allocated with name '_hold_code_10000_594'
                                    697 ;mods          Allocated with name '_hold_mods_30000_597'
                                    698 ;layer         Allocated with name '_hold_layer_30000_600'
                                    699 ;------------------------------------------------------------
                                    700 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    701 ;	-----------------------------------------
                                    702 ;	 function hold
                                    703 ;	-----------------------------------------
      004434                        704 _hold:
      004434 12 39 03         [24]  705 	lcall	_ak820_outline_0122
      004437 90 06 20         [24]  706 	mov	dptr,#_hold_code_10000_594
      00443A 12 38 FE         [24]  707 	lcall	_ak820_outline_0121
                                    708 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00443D 90 06 20         [24]  709 	mov	dptr,#_hold_code_10000_594
      004440 12 48 9E         [24]  710 	lcall	_ak820_outline_0013
      004443 74 C0            [12]  711 	mov	a,#0x100 - 0x40
      004445 2D               [12]  712 	add	a,r5
      004446 40 2E            [24]  713 	jc	00110$
                                    714 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004448 8F 05            [24]  715 	mov	ar5,r7
      00444A 53 05 1F         [24]  716 	anl	ar5,#0x1f
      00444D 90 06 22         [24]  717 	mov	dptr,#_hold_mods_30000_597
      004450 ED               [12]  718 	mov	a,r5
      004451 F0               [24]  719 	movx	@dptr,a
                                    720 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004452 ED               [12]  721 	mov	a,r5
      004453 30 E4 08         [24]  722 	jnb	acc.4,00102$
      004456 ED               [12]  723 	mov	a,r5
      004457 C4               [12]  724 	swap	a
      004458 54 F0            [12]  725 	anl	a,#0xf0
      00445A 90 06 22         [24]  726 	mov	dptr,#_hold_mods_30000_597
      00445D F0               [24]  727 	movx	@dptr,a
      00445E                        728 00102$:
                                    729 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      00445E 90 06 1F         [24]  730 	mov	dptr,#_hold_PARM_2
      004461 E0               [24]  731 	movx	a,@dptr
      004462 60 09            [24]  732 	jz	00104$
      004464 90 06 22         [24]  733 	mov	dptr,#_hold_mods_30000_597
      004467 E0               [24]  734 	movx	a,@dptr
      004468 F5 82            [12]  735 	mov	dpl,a
      00446A 02 77 11         [24]  736 	ljmp	_register_mods
      00446D                        737 00104$:
                                    738 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00446D 90 06 22         [24]  739 	mov	dptr,#_hold_mods_30000_597
      004470 E0               [24]  740 	movx	a,@dptr
      004471 F5 82            [12]  741 	mov	dpl,a
      004473 02 77 25         [24]  742 	ljmp	_unregister_mods
      004476                        743 00110$:
                                    744 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004476 8F 06            [24]  745 	mov	ar6,r7
      004478 74 0F            [12]  746 	mov	a,#0x0f
      00447A 5E               [12]  747 	anl	a,r6
      00447B FF               [12]  748 	mov	r7,a
                                    749 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00447C 90 06 1F         [24]  750 	mov	dptr,#_hold_PARM_2
      00447F E0               [24]  751 	movx	a,@dptr
      004480 60 05            [24]  752 	jz	00107$
      004482 8F 82            [24]  753 	mov	dpl, r7
      004484 02 78 F7         [24]  754 	ljmp	_layer_hold_on
      004487                        755 00107$:
                                    756 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004487 8F 82            [24]  757 	mov	dpl, r7
                                    758 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004489 02 79 2F         [24]  759 	ljmp	_layer_hold_off
                                    760 ;------------------------------------------------------------
                                    761 ;Allocation info for local variables in function 'commit_pending'
                                    762 ;------------------------------------------------------------
                                    763 ;id            Allocated with name '_commit_pending_id_10000_603'
                                    764 ;------------------------------------------------------------
                                    765 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    766 ;	-----------------------------------------
                                    767 ;	 function commit_pending
                                    768 ;	-----------------------------------------
      00448C                        769 _commit_pending:
                                    770 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00448C 90 0D D2         [24]  771 	mov	dptr,#_pending
      00448F E0               [24]  772 	movx	a,@dptr
      004490 90 06 23         [24]  773 	mov	dptr,#_commit_pending_id_10000_603
      004493 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004494 12 49 22         [24]  776 	lcall	_ak820_outline_0162
                                    777 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004497 90 06 23         [24]  778 	mov	dptr,#_commit_pending_id_10000_603
      00449A E0               [24]  779 	movx	a,@dptr
      00449B 24 97            [12]  780 	add	a,#_source_state
      00449D FF               [12]  781 	mov	r7,a
      00449E E4               [12]  782 	clr	a
      00449F 34 05            [12]  783 	addc	a, #(_source_state >> 8)
      0044A1 FE               [12]  784 	mov	r6,a
      0044A2 12 43 E0         [24]  785 	lcall	_ak820_outline_0164
      0044A5 E0               [24]  786 	movx	a,@dptr
      0044A6 FD               [12]  787 	mov	r5,a
      0044A7 43 05 04         [24]  788 	orl	ar5,#0x04
      0044AA 12 43 E0         [24]  789 	lcall	_ak820_outline_0164
      0044AD ED               [12]  790 	mov	a,r5
      0044AE F0               [24]  791 	movx	@dptr,a
                                    792 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      0044AF 90 06 1B         [24]  793 	mov	dptr,#_pending_code
      0044B2 12 38 C3         [24]  794 	lcall	_ak820_outline_0060
      0044B5 90 06 1F         [24]  795 	mov	dptr,#_hold_PARM_2
      0044B8 74 01            [12]  796 	mov	a,#0x01
      0044BA 12 43 AB         [24]  797 	lcall	_ak820_outline_0088
                                    798 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0044BD 02 44 34         [24]  799 	ljmp	_hold
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    802 ;------------------------------------------------------------
                                    803 ;event         Allocated with name '_ak820_tapping_before_event_10000_604'
                                    804 ;id            Allocated with name '_ak820_tapping_before_id_10000_605'
                                    805 ;------------------------------------------------------------
                                    806 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function ak820_tapping_before
                                    809 ;	-----------------------------------------
      0044C0                        810 _ak820_tapping_before:
      0044C0 12 39 03         [24]  811 	lcall	_ak820_outline_0122
      0044C3 90 06 24         [24]  812 	mov	dptr,#_ak820_tapping_before_event_10000_604
      0044C6 12 38 FE         [24]  813 	lcall	_ak820_outline_0121
                                    814 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0044C9 90 06 24         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_604
      0044CC 12 48 9E         [24]  816 	lcall	_ak820_outline_0013
      0044CF 12 48 B7         [24]  817 	lcall	_ak820_outline_0025
      0044D2 C0 07            [24]  818 	push	ar7
      0044D4 C0 06            [24]  819 	push	ar6
      0044D6 12 BC 07         [24]  820 	lcall	___memcpy
      0044D9 12 43 FE         [24]  821 	lcall	_ak820_tapping_source
      0044DC AD 82            [24]  822 	mov	r5, dpl
      0044DE D0 06            [24]  823 	pop	ar6
      0044E0 D0 07            [24]  824 	pop	ar7
                                    825 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0044E2 90 0E 43         [24]  826 	mov	dptr,#_vial_unlock_in_progress
      0044E5 E0               [24]  827 	movx	a,@dptr
      0044E6 60 2B            [24]  828 	jz	00106$
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044E8 74 04            [12]  830 	mov	a,#0x04
      0044EA 12 48 D1         [24]  831 	lcall	_ak820_outline_0032
      0044ED E0               [24]  832 	movx	a,@dptr
      0044EE 60 1F            [24]  833 	jz	00102$
      0044F0 BD FF 02         [24]  834 	cjne	r5,#0xff,00218$
      0044F3 80 1A            [24]  835 	sjmp	00102$
      0044F5                        836 00218$:
      0044F5 74 05            [12]  837 	mov	a,#0x05
      0044F7 12 48 D1         [24]  838 	lcall	_ak820_outline_0032
      0044FA E0               [24]  839 	movx	a,@dptr
      0044FB 70 12            [24]  840 	jnz	00102$
      0044FD ED               [12]  841 	mov	a,r5
      0044FE 24 97            [12]  842 	add	a, #_source_state
      004500 FB               [12]  843 	mov	r3,a
      004501 E4               [12]  844 	clr	a
      004502 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      004504 12 48 F1         [24]  846 	lcall	_ak820_outline_0063
      004507 53 02 FD         [24]  847 	anl	ar2,#0xfd
      00450A 12 34 71         [24]  848 	lcall	_ak820_outline_0129
      00450D EA               [12]  849 	mov	a,r2
      00450E F0               [24]  850 	movx	@dptr,a
      00450F                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      00450F 75 82 00         [24]  853 	mov	dpl, #0x00
      004512 22               [24]  854 	ret
      004513                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      004513 90 0D D2         [24]  857 	mov	dptr,#_pending
      004516 E0               [24]  858 	movx	a,@dptr
      004517 FC               [12]  859 	mov	r4,a
      004518 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      00451B 80 3B            [24]  861 	sjmp	00108$
      00451D                        862 00220$:
      00451D 12 38 B3         [24]  863 	lcall	_ak820_outline_0038
      004520 FA               [12]  864 	mov	r2,a
      004521 A3               [24]  865 	inc	dptr
      004522 E0               [24]  866 	movx	a,@dptr
      004523 FB               [12]  867 	mov	r3,a
      004524 90 06 19         [24]  868 	mov	dptr,#_pending_time
      004527 12 38 F8         [24]  869 	lcall	_ak820_outline_0109
      00452A EA               [12]  870 	mov	a,r2
      00452B C3               [12]  871 	clr	c
      00452C 98               [12]  872 	subb	a,r0
      00452D FA               [12]  873 	mov	r2,a
      00452E EB               [12]  874 	mov	a,r3
      00452F 99               [12]  875 	subb	a,r1
      004530 FB               [12]  876 	mov	r3,a
      004531 C3               [12]  877 	clr	c
      004532 EA               [12]  878 	mov	a,r2
      004533 94 C8            [12]  879 	subb	a,#0xc8
      004535 EB               [12]  880 	mov	a,r3
      004536 94 00            [12]  881 	subb	a,#0x00
      004538 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      00453A 74 04            [12]  884 	mov	a,#0x04
      00453C 12 48 DB         [24]  885 	lcall	_ak820_outline_0054
      00453F 60 17            [24]  886 	jz	00108$
      004541 12 38 A6         [24]  887 	lcall	_ak820_outline_0037
      004544 60 12            [24]  888 	jz	00108$
      004546 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004549 80 06            [24]  890 	sjmp	00107$
      00454B                        891 00224$:
      00454B ED               [12]  892 	mov	a,r5
      00454C B5 04 02         [24]  893 	cjne	a,ar4,00225$
      00454F 80 07            [24]  894 	sjmp	00108$
      004551                        895 00225$:
      004551                        896 00107$:
      004551 C0 05            [24]  897 	push	ar5
      004553 12 44 8C         [24]  898 	lcall	_commit_pending
      004556 D0 05            [24]  899 	pop	ar5
      004558                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004558 90 06 24         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_604
      00455B 12 38 C3         [24]  903 	lcall	_ak820_outline_0060
      00455E 74 04            [12]  904 	mov	a,#0x04
      004560 12 48 D1         [24]  905 	lcall	_ak820_outline_0032
      004563 E0               [24]  906 	movx	a,@dptr
      004564 60 03            [24]  907 	jz	00114$
      004566 BD FF 04         [24]  908 	cjne	r5,#0xff,00115$
      004569                        909 00114$:
      004569 75 82 01         [24]  910 	mov	dpl, #0x01
      00456C 22               [24]  911 	ret
      00456D                        912 00115$:
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      00456D ED               [12]  914 	mov	a,r5
      00456E 12 49 14         [24]  915 	lcall	_ak820_outline_0090
      004571 30 E1 12         [24]  916 	jnb	acc.1,00120$
                                    917 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004574 74 05            [12]  918 	mov	a,#0x05
      004576 2E               [12]  919 	add	a, r6
      004577 12 38 93         [24]  920 	lcall	_ak820_outline_0018
      00457A 70 06            [24]  921 	jnz	00118$
      00457C 74 FD            [12]  922 	mov	a,#0xfd
      00457E 5B               [12]  923 	anl	a,r3
      00457F 12 43 CF         [24]  924 	lcall	_ak820_outline_0127
      004582                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      004582 75 82 00         [24]  927 	mov	dpl, #0x00
      004585 22               [24]  928 	ret
      004586                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004586 12 43 6E         [24]  931 	lcall	_ak820_outline_0016
      004589 E0               [24]  932 	movx	a,@dptr
      00458A FF               [12]  933 	mov	r7,a
      00458B 8B 06            [24]  934 	mov	ar6,r3
      00458D 53 06 01         [24]  935 	anl	ar6,#0x01
      004590 EE               [12]  936 	mov	a,r6
      004591 B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      004594                        938 00231$:
      004594 B3               [12]  939 	cpl	c
      004595 92 0E            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004597 8F F0            [24]  941 	mov	b,r7
      004599 E4               [12]  942 	clr	a
      00459A 33               [12]  943 	rlc	a
      00459B B5 F0 04         [24]  944 	cjne	a,b,00122$
      00459E 75 82 00         [24]  945 	mov	dpl, #0x00
      0045A1 22               [24]  946 	ret
      0045A2                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      0045A2 63 03 01         [24]  949 	xrl	ar3,#0x01
      0045A5 12 34 76         [24]  950 	lcall	_ak820_outline_0132
      0045A8 EB               [12]  951 	mov	a,r3
      0045A9 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      0045AA 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      0045AD 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_615'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_616'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_616'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_616'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_616'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      0045AE                        970 _ak820_tapping_process:
      0045AE 12 39 03         [24]  971 	lcall	_ak820_outline_0122
      0045B1 90 06 26         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_615
      0045B4 12 38 FE         [24]  973 	lcall	_ak820_outline_0121
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      0045B7 90 06 2A         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_616
      0045BA E4               [12]  976 	clr	a
      0045BB F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      0045BC 90 06 26         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_615
      0045BF 12 38 C3         [24]  980 	lcall	_ak820_outline_0060
      0045C2 74 04            [12]  981 	mov	a,#0x04
      0045C4 12 48 E6         [24]  982 	lcall	_ak820_outline_0055
      0045C7 70 04            [24]  983 	jnz	00102$
      0045C9 75 82 01         [24]  984 	mov	dpl, #0x01
      0045CC 22               [24]  985 	ret
      0045CD                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      0045CD 8E 04            [24]  988 	mov	ar4,r6
      0045CF 8F 05            [24]  989 	mov	ar5,r7
      0045D1 12 48 B7         [24]  990 	lcall	_ak820_outline_0025
      0045D4 C0 07            [24]  991 	push	ar7
      0045D6 C0 06            [24]  992 	push	ar6
      0045D8 12 BC 07         [24]  993 	lcall	___memcpy
      0045DB 12 43 FE         [24]  994 	lcall	_ak820_tapping_source
      0045DE AD 82            [24]  995 	mov	r5, dpl
      0045E0 D0 06            [24]  996 	pop	ar6
      0045E2 D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0045E4 BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      0045E7 75 82 01         [24] 1000 	mov	dpl, #0x01
      0045EA 22               [24] 1001 	ret
      0045EB                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0045EB 74 07            [12] 1004 	mov	a,#0x07
      0045ED 12 38 9D         [24] 1005 	lcall	_ak820_outline_0023
      0045F0 FE               [12] 1006 	mov	r6,a
      0045F1 A3               [24] 1007 	inc	dptr
      0045F2 E0               [24] 1008 	movx	a,@dptr
      0045F3 FF               [12] 1009 	mov	r7,a
      0045F4 90 06 28         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_616
      0045F7 12 48 F9         [24] 1011 	lcall	_ak820_outline_0068
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0045FA BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      0045FD BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      004600 90 06 28         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_616
      004603 74 26            [12] 1016 	mov	a,#0x26
      004605 F0               [24] 1017 	movx	@dptr,a
      004606 74 22            [12] 1018 	mov	a,#0x22
      004608 A3               [24] 1019 	inc	dptr
      004609 F0               [24] 1020 	movx	@dptr,a
      00460A 90 06 2A         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_616
      00460D 74 02            [12] 1022 	mov	a,#0x02
      00460F F0               [24] 1023 	movx	@dptr,a
      004610 80 28            [24] 1024 	sjmp	00112$
      004612                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004612 BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      004615 BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      004618 90 06 28         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_616
      00461B 74 27            [12] 1030 	mov	a,#0x27
      00461D F0               [24] 1031 	movx	@dptr,a
      00461E 74 32            [12] 1032 	mov	a,#0x32
      004620 A3               [24] 1033 	inc	dptr
      004621 F0               [24] 1034 	movx	@dptr,a
      004622 90 06 2A         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_616
      004625 74 20            [12] 1036 	mov	a,#0x20
      004627 F0               [24] 1037 	movx	@dptr,a
      004628 80 10            [24] 1038 	sjmp	00112$
      00462A                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      00462A BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      00462D BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      004630 90 06 28         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_616
      004633 74 28            [12] 1044 	mov	a,#0x28
      004635 F0               [24] 1045 	movx	@dptr,a
      004636 74 32            [12] 1046 	mov	a,#0x32
      004638 A3               [24] 1047 	inc	dptr
      004639 F0               [24] 1048 	movx	@dptr,a
      00463A                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      00463A 90 06 28         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_616
      00463D E0               [24] 1052 	movx	a,@dptr
      00463E A3               [24] 1053 	inc	dptr
      00463F E0               [24] 1054 	movx	a,@dptr
      004640 FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004641 BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      004644                       1058 00242$:
      004644 40 05            [24] 1059 	jc	00113$
      004646 BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      004649                       1061 00244$:
      004649 40 04            [24] 1062 	jc	00114$
      00464B                       1063 00113$:
      00464B 75 82 01         [24] 1064 	mov	dpl, #0x01
      00464E 22               [24] 1065 	ret
      00464F                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      00464F BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      004652                       1069 00246$:
      004652 40 0C            [24] 1070 	jc	00117$
      004654 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      004657 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      00465A                       1073 00248$:
      00465A 40 04            [24] 1074 	jc	00117$
      00465C 75 82 00         [24] 1075 	mov	dpl, #0x00
      00465F 22               [24] 1076 	ret
      004660                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      004660 90 06 26         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_615
      004663 12 38 C3         [24] 1080 	lcall	_ak820_outline_0060
      004666 74 05            [12] 1081 	mov	a,#0x05
      004668 12 48 D1         [24] 1082 	lcall	_ak820_outline_0032
      00466B E0               [24] 1083 	movx	a,@dptr
      00466C 60 1F            [24] 1084 	jz	00131$
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      00466E 90 0D D2         [24] 1086 	mov	dptr,#_pending
      004671 ED               [12] 1087 	mov	a,r5
      004672 12 43 78         [24] 1088 	lcall	_ak820_outline_0034
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      004675 12 38 C3         [24] 1090 	lcall	_ak820_outline_0060
      004678 90 06 19         [24] 1091 	mov	dptr,#_pending_time
      00467B 12 48 F9         [24] 1092 	lcall	_ak820_outline_0068
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      00467E 90 06 28         [24] 1094 	mov	dptr,#_ak820_tapping_process_code_10000_616
      004681 12 38 C3         [24] 1095 	lcall	_ak820_outline_0060
      004684 90 06 1B         [24] 1096 	mov	dptr,#_pending_code
      004687 12 48 F9         [24] 1097 	lcall	_ak820_outline_0068
      00468A 02 47 3F         [24] 1098 	ljmp	00132$
      00468D                       1099 00131$:
                                   1100 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      00468D 90 0D D2         [24] 1101 	mov	dptr,#_pending
      004690 E0               [24] 1102 	movx	a,@dptr
      004691 FF               [12] 1103 	mov	r7,a
      004692 ED               [12] 1104 	mov	a,r5
      004693 B5 07 02         [24] 1105 	cjne	a,ar7,00251$
      004696 80 03            [24] 1106 	sjmp	00252$
      004698                       1107 00251$:
      004698 02 47 17         [24] 1108 	ljmp	00128$
      00469B                       1109 00252$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      00469B 12 49 22         [24] 1111 	lcall	_ak820_outline_0162
                                   1112 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      00469E 90 06 2A         [24] 1113 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_616
      0046A1 E0               [24] 1114 	movx	a,@dptr
      0046A2 FF               [12] 1115 	mov	r7,a
      0046A3 E0               [24] 1116 	movx	a,@dptr
      0046A4 60 05            [24] 1117 	jz	00120$
      0046A6 8F 82            [24] 1118 	mov	dpl, r7
      0046A8 12 7D F7         [24] 1119 	lcall	_add_owned_mods
      0046AB                       1120 00120$:
                                   1121 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      0046AB 90 06 26         [24] 1122 	mov	dptr,#_ak820_tapping_process_record_10000_615
      0046AE 12 38 C3         [24] 1123 	lcall	_ak820_outline_0060
      0046B1 74 07            [12] 1124 	mov	a,#0x07
      0046B3 2E               [12] 1125 	add	a, r6
      0046B4 FB               [12] 1126 	mov	r3,a
      0046B5 E4               [12] 1127 	clr	a
      0046B6 3F               [12] 1128 	addc	a, r7
      0046B7 FC               [12] 1129 	mov	r4,a
      0046B8 90 06 28         [24] 1130 	mov	dptr,#_ak820_tapping_process_code_10000_616
      0046BB E0               [24] 1131 	movx	a,@dptr
      0046BC F9               [12] 1132 	mov	r1,a
      0046BD 7A 00            [12] 1133 	mov	r2,#0x00
      0046BF 12 34 71         [24] 1134 	lcall	_ak820_outline_0129
      0046C2 E9               [12] 1135 	mov	a,r1
      0046C3 F0               [24] 1136 	movx	@dptr,a
      0046C4 EA               [12] 1137 	mov	a,r2
      0046C5 A3               [24] 1138 	inc	dptr
      0046C6 F0               [24] 1139 	movx	@dptr,a
                                   1140 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0046C7 C3               [12] 1141 	clr	c
      0046C8 04               [12] 1142 	inc	a
      0046C9 99               [12] 1143 	subb	a,r1
      0046CA 50 39            [24] 1144 	jnc	00122$
                                   1145 ;	free result
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0046CC 74 06            [12] 1147 	mov	a,#0x06
      0046CE 12 38 9D         [24] 1148 	lcall	_ak820_outline_0023
      0046D1 54 0F            [12] 1149 	anl	a,#0x0f
      0046D3 44 10            [12] 1150 	orl	a,#0x10
      0046D5 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0046D6 74 05            [12] 1153 	mov	a,#0x05
      0046D8 12 48 D1         [24] 1154 	lcall	_ak820_outline_0032
      0046DB 74 01            [12] 1155 	mov	a,#0x01
      0046DD F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0046DE 12 48 FF         [24] 1158 	lcall	_ak820_outline_0083
      0046E1 12 49 06         [24] 1159 	lcall	_ak820_outline_0084
      0046E4 C0 07            [24] 1160 	push	ar7
      0046E6 C0 06            [24] 1161 	push	ar6
      0046E8 C0 04            [24] 1162 	push	ar4
      0046EA C0 03            [24] 1163 	push	ar3
      0046EC 12 71 82         [24] 1164 	lcall	_process_record
      0046EF D0 03            [24] 1165 	pop	ar3
      0046F1 D0 04            [24] 1166 	pop	ar4
      0046F3 D0 06            [24] 1167 	pop	ar6
      0046F5 D0 07            [24] 1168 	pop	ar7
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0046F7 12 34 71         [24] 1170 	lcall	_ak820_outline_0129
      0046FA E4               [12] 1171 	clr	a
      0046FB F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0046FC FC               [12] 1174 	mov	r4,a
      0046FD 12 39 08         [24] 1175 	lcall	_ak820_outline_0123
      004700 8C F0            [24] 1176 	mov	b, r4
      004702 12 71 82         [24] 1177 	lcall	_process_record
      004705                       1178 00122$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      004705 90 06 2A         [24] 1180 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_616
      004708 E0               [24] 1181 	movx	a,@dptr
      004709 FF               [12] 1182 	mov	r7,a
      00470A E0               [24] 1183 	movx	a,@dptr
      00470B 60 32            [24] 1184 	jz	00132$
                                   1185 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      00470D 8F 82            [24] 1186 	mov	dpl, r7
      00470F 12 7E 07         [24] 1187 	lcall	_del_owned_mods
                                   1188 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      004712 12 81 3B         [24] 1189 	lcall	_send_keyboard_report
      004715 80 28            [24] 1190 	sjmp	00132$
      004717                       1191 00128$:
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      004717 ED               [12] 1193 	mov	a,r5
      004718 24 97            [12] 1194 	add	a, #_source_state
      00471A FE               [12] 1195 	mov	r6,a
      00471B E4               [12] 1196 	clr	a
      00471C 34 05            [12] 1197 	addc	a, #(_source_state >> 8)
      00471E FF               [12] 1198 	mov	r7,a
      00471F 12 39 08         [24] 1199 	lcall	_ak820_outline_0123
      004722 E0               [24] 1200 	movx	a,@dptr
      004723 FD               [12] 1201 	mov	r5,a
      004724 30 E2 18         [24] 1202 	jnb	acc.2,00132$
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      004727 53 05 FB         [24] 1204 	anl	ar5,#0xfb
      00472A 12 39 08         [24] 1205 	lcall	_ak820_outline_0123
      00472D ED               [12] 1206 	mov	a,r5
      00472E F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      00472F 90 06 28         [24] 1209 	mov	dptr,#_ak820_tapping_process_code_10000_616
      004732 12 38 C3         [24] 1210 	lcall	_ak820_outline_0060
      004735 90 06 1F         [24] 1211 	mov	dptr,#_hold_PARM_2
      004738 E4               [12] 1212 	clr	a
      004739 12 43 AB         [24] 1213 	lcall	_ak820_outline_0088
      00473C 12 44 34         [24] 1214 	lcall	_hold
      00473F                       1215 00132$:
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      00473F 75 82 00         [24] 1217 	mov	dpl, #0x00
                                   1218 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004742 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1222 ;------------------------------------------------------------
                                   1223 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_639'
                                   1224 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_640'
                                   1225 ;------------------------------------------------------------
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1227 ;	-----------------------------------------
                                   1228 ;	 function ak820_tapping_cancel
                                   1229 ;	-----------------------------------------
      004743                       1230 _ak820_tapping_cancel:
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004743 12 49 22         [24] 1232 	lcall	_ak820_outline_0162
                                   1233 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004746 7F 00            [12] 1234 	mov	r7,#0x00
      004748                       1235 00103$:
      004748 BF 82 00         [24] 1236 	cjne	r7,#0x82,00122$
      00474B                       1237 00122$:
      00474B 50 16            [24] 1238 	jnc	00105$
                                   1239 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      00474D 12 48 A8         [24] 1240 	lcall	_ak820_outline_0022
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004750 74 02            [12] 1242 	mov	a,#0x02
      004752 5C               [12] 1243 	anl	a,r4
      004753 FB               [12] 1244 	mov	r3,a
      004754 53 04 01         [24] 1245 	anl	ar4,#0x01
      004757 EC               [12] 1246 	mov	a,r4
      004758 2C               [12] 1247 	add	a,r4
      004759 42 03            [12] 1248 	orl	ar3,a
      00475B 12 39 17         [24] 1249 	lcall	_ak820_outline_0141
      00475E EB               [12] 1250 	mov	a,r3
      00475F F0               [24] 1251 	movx	@dptr,a
                                   1252 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004760 0F               [12] 1253 	inc	r7
      004761 80 E5            [24] 1254 	sjmp	00103$
      004763                       1255 00105$:
                                   1256 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004763 22               [24] 1257 	ret
                                   1258 ;------------------------------------------------------------
                                   1259 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1260 ;------------------------------------------------------------
                                   1261 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1262 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1263 ;code          Allocated with name '_ak820_oneshot_process_code_10000_641'
                                   1264 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_642'
                                   1265 ;i             Allocated with name '_ak820_oneshot_process_i_40000_656'
                                   1266 ;------------------------------------------------------------
                                   1267 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1268 ;	-----------------------------------------
                                   1269 ;	 function ak820_oneshot_process
                                   1270 ;	-----------------------------------------
      004764                       1271 _ak820_oneshot_process:
      004764 12 39 03         [24] 1272 	lcall	_ak820_outline_0122
      004767 90 06 2F         [24] 1273 	mov	dptr,#_ak820_oneshot_process_code_10000_641
      00476A 12 38 FE         [24] 1274 	lcall	_ak820_outline_0121
                                   1275 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      00476D 90 06 2D         [24] 1276 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004770 E0               [24] 1277 	movx	a,@dptr
      004771 FF               [12] 1278 	mov	r7,a
      004772 BF FF 02         [24] 1279 	cjne	r7,#0xff,00248$
      004775 80 0B            [24] 1280 	sjmp	00101$
      004777                       1281 00248$:
      004777 C0 07            [24] 1282 	push	ar7
      004779 12 A5 C9         [24] 1283 	lcall	_get_repeat_key_count
      00477C E5 82            [12] 1284 	mov	a, dpl
      00477E D0 07            [24] 1285 	pop	ar7
      004780 60 04            [24] 1286 	jz	00102$
      004782                       1287 00101$:
      004782 75 82 01         [24] 1288 	mov	dpl, #0x01
      004785 22               [24] 1289 	ret
      004786                       1290 00102$:
                                   1291 ;	keyboards/ajazz/ak820/ak820_tapping.c:146: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004786 90 06 2F         [24] 1292 	mov	dptr,#_ak820_oneshot_process_code_10000_641
      004789 E0               [24] 1293 	movx	a,@dptr
      00478A FD               [12] 1294 	mov	r5,a
      00478B A3               [24] 1295 	inc	dptr
      00478C E0               [24] 1296 	movx	a,@dptr
      00478D FB               [12] 1297 	mov	r3,a
      00478E BB 52 02         [24] 1298 	cjne	r3,#0x52,00250$
      004791 80 03            [24] 1299 	sjmp	00251$
      004793                       1300 00250$:
      004793 02 48 38         [24] 1301 	ljmp	00116$
      004796                       1302 00251$:
      004796 8D 04            [24] 1303 	mov	ar4,r5
      004798 53 04 E0         [24] 1304 	anl	ar4,#0xe0
      00479B BC A0 02         [24] 1305 	cjne	r4,#0xa0,00252$
      00479E 80 03            [24] 1306 	sjmp	00253$
      0047A0                       1307 00252$:
      0047A0 02 48 38         [24] 1308 	ljmp	00116$
      0047A3                       1309 00253$:
                                   1310 ;	keyboards/ajazz/ak820/ak820_tapping.c:147: mods = code & 15;
      0047A3 8D 04            [24] 1311 	mov	ar4,r5
      0047A5 53 04 0F         [24] 1312 	anl	ar4,#0x0f
      0047A8 90 06 31         [24] 1313 	mov	dptr,#_ak820_oneshot_process_mods_10000_642
      0047AB EC               [12] 1314 	mov	a,r4
      0047AC F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:148: if (code & 16) mods <<= 4;
      0047AD ED               [12] 1317 	mov	a,r5
      0047AE 30 E4 08         [24] 1318 	jnb	acc.4,00105$
      0047B1 EC               [12] 1319 	mov	a,r4
      0047B2 C4               [12] 1320 	swap	a
      0047B3 54 F0            [12] 1321 	anl	a,#0xf0
      0047B5 90 06 31         [24] 1322 	mov	dptr,#_ak820_oneshot_process_mods_10000_642
      0047B8 F0               [24] 1323 	movx	@dptr,a
      0047B9                       1324 00105$:
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: if (pressed) {
      0047B9 90 06 2E         [24] 1326 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0047BC E0               [24] 1327 	movx	a,@dptr
      0047BD 60 2D            [24] 1328 	jz	00113$
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:150: source_state[id] |= SOURCE_ONESHOT;
      0047BF 12 48 A8         [24] 1330 	lcall	_ak820_outline_0022
      0047C2 43 04 08         [24] 1331 	orl	ar4,#0x08
      0047C5 12 43 A4         [24] 1332 	lcall	_ak820_outline_0074
                                   1333 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0047C8 53 04 EF         [24] 1334 	anl	ar4,#0xef
      0047CB 12 43 A4         [24] 1335 	lcall	_ak820_outline_0074
                                   1336 ;	keyboards/ajazz/ak820/ak820_tapping.c:152: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0047CE 90 0D D3         [24] 1337 	mov	dptr,#_ak820_oneshot_target
      0047D1 E0               [24] 1338 	movx	a,@dptr
      0047D2 FC               [12] 1339 	mov	r4,a
      0047D3 BC FF 02         [24] 1340 	cjne	r4,#0xff,00256$
      0047D6 80 09            [24] 1341 	sjmp	00107$
      0047D8                       1342 00256$:
      0047D8 12 49 0D         [24] 1343 	lcall	_ak820_outline_0085
      0047DB 43 04 10         [24] 1344 	orl	ar4,#0x10
      0047DE 12 43 A4         [24] 1345 	lcall	_ak820_outline_0074
      0047E1                       1346 00107$:
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:153: register_mods(mods);
      0047E1 90 06 31         [24] 1348 	mov	dptr,#_ak820_oneshot_process_mods_10000_642
      0047E4 E0               [24] 1349 	movx	a,@dptr
      0047E5 F5 82            [12] 1350 	mov	dpl,a
      0047E7 12 77 11         [24] 1351 	lcall	_register_mods
      0047EA 80 48            [24] 1352 	sjmp	00114$
      0047EC                       1353 00113$:
                                   1354 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: } else if (source_state[id] & SOURCE_ONESHOT) {
      0047EC 12 48 A8         [24] 1355 	lcall	_ak820_outline_0022
      0047EF 30 E3 42         [24] 1356 	jnb	acc.3,00114$
                                   1357 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0047F2 EC               [12] 1358 	mov	a,r4
      0047F3 20 E4 24         [24] 1359 	jb	acc.4,00109$
                                   1360 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: add_owned_mods(mods & ~ak820_oneshot_mods);
      0047F6 90 06 2B         [24] 1361 	mov	dptr,#_ak820_oneshot_mods
      0047F9 E0               [24] 1362 	movx	a,@dptr
      0047FA F4               [12] 1363 	cpl	a
      0047FB FC               [12] 1364 	mov	r4,a
      0047FC 90 06 31         [24] 1365 	mov	dptr,#_ak820_oneshot_process_mods_10000_642
      0047FF E0               [24] 1366 	movx	a,@dptr
      004800 FB               [12] 1367 	mov	r3,a
      004801 52 04            [12] 1368 	anl	ar4,a
      004803 8C 82            [24] 1369 	mov	dpl, r4
      004805 C0 06            [24] 1370 	push	ar6
      004807 C0 05            [24] 1371 	push	ar5
      004809 C0 03            [24] 1372 	push	ar3
      00480B 12 7D F7         [24] 1373 	lcall	_add_owned_mods
      00480E D0 03            [24] 1374 	pop	ar3
      004810 D0 05            [24] 1375 	pop	ar5
      004812 D0 06            [24] 1376 	pop	ar6
                                   1377 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: ak820_oneshot_mods |= mods;
      004814 90 06 2B         [24] 1378 	mov	dptr,#_ak820_oneshot_mods
      004817 E0               [24] 1379 	movx	a,@dptr
      004818 4B               [12] 1380 	orl	a,r3
      004819 F0               [24] 1381 	movx	@dptr,a
      00481A                       1382 00109$:
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: unregister_mods(mods);
      00481A 90 06 31         [24] 1384 	mov	dptr,#_ak820_oneshot_process_mods_10000_642
      00481D E0               [24] 1385 	movx	a,@dptr
      00481E F5 82            [12] 1386 	mov	dpl,a
      004820 C0 06            [24] 1387 	push	ar6
      004822 C0 05            [24] 1388 	push	ar5
      004824 12 77 25         [24] 1389 	lcall	_unregister_mods
      004827 D0 05            [24] 1390 	pop	ar5
      004829 D0 06            [24] 1391 	pop	ar6
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      00482B 12 49 0D         [24] 1393 	lcall	_ak820_outline_0085
      00482E 53 04 E7         [24] 1394 	anl	ar4,#0xe7
      004831 12 43 A4         [24] 1395 	lcall	_ak820_outline_0074
      004834                       1396 00114$:
                                   1397 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: return false;
      004834 75 82 00         [24] 1398 	mov	dpl, #0x00
      004837 22               [24] 1399 	ret
      004838                       1400 00116$:
                                   1401 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (pressed && code > KC_TRANSPARENT &&
      004838 90 06 2E         [24] 1402 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00483B E0               [24] 1403 	movx	a,@dptr
      00483C 60 5C            [24] 1404 	jz	00124$
      00483E 90 06 2F         [24] 1405 	mov	dptr,#_ak820_oneshot_process_code_10000_641
      004841 12 38 EC         [24] 1406 	lcall	_ak820_outline_0089
      004844 C3               [12] 1407 	clr	c
      004845 74 01            [12] 1408 	mov	a,#0x01
      004847 9D               [12] 1409 	subb	a,r5
      004848 E4               [12] 1410 	clr	a
      004849 9E               [12] 1411 	subb	a,r6
      00484A 50 4E            [24] 1412 	jnc	00124$
                                   1413 ;	free result
                                   1414 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: !(code >= KC_LCTL && code <= KC_RGUI) &&
      00484C C3               [12] 1415 	clr	c
      00484D ED               [12] 1416 	mov	a,r5
      00484E 94 E0            [12] 1417 	subb	a,#0xe0
      004850 EE               [12] 1418 	mov	a,r6
      004851 94 00            [12] 1419 	subb	a,#0x00
      004853 40 07            [24] 1420 	jc	00129$
      004855 74 E7            [12] 1421 	mov	a,#0xe7
      004857 9D               [12] 1422 	subb	a,r5
      004858 E4               [12] 1423 	clr	a
      004859 9E               [12] 1424 	subb	a,r6
      00485A 50 3E            [24] 1425 	jnc	00124$
                                   1426 ;	free result
      00485C                       1427 00129$:
                                   1428 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      00485C 74 AE            [12] 1429 	mov	a,#0x100 - 0x52
      00485E 2E               [12] 1430 	add	a,r6
      00485F 50 09            [24] 1431 	jnc	00165$
      004861 C3               [12] 1432 	clr	c
      004862 74 DF            [12] 1433 	mov	a,#0xdf
      004864 9D               [12] 1434 	subb	a,r5
      004865 74 52            [12] 1435 	mov	a,#0x52
      004867 9E               [12] 1436 	subb	a,r6
      004868 50 30            [24] 1437 	jnc	00124$
                                   1438 ;	free result
                                   1439 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: for (uint8_t i = 0; i < SOURCES; ++i)
      00486A                       1440 00165$:
      00486A 7E 00            [12] 1441 	mov	r6,#0x00
      00486C                       1442 00131$:
      00486C BE 82 00         [24] 1443 	cjne	r6,#0x82,00265$
      00486F                       1444 00265$:
      00486F 50 12            [24] 1445 	jnc	00120$
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004871 EE               [12] 1447 	mov	a,r6
      004872 12 49 14         [24] 1448 	lcall	_ak820_outline_0090
      004875 30 E3 08         [24] 1449 	jnb	acc.3,00132$
      004878 43 03 10         [24] 1450 	orl	ar3,#0x10
      00487B 12 34 76         [24] 1451 	lcall	_ak820_outline_0132
      00487E EB               [12] 1452 	mov	a,r3
      00487F F0               [24] 1453 	movx	@dptr,a
      004880                       1454 00132$:
                                   1455 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: for (uint8_t i = 0; i < SOURCES; ++i)
      004880 0E               [12] 1456 	inc	r6
      004881 80 E9            [24] 1457 	sjmp	00131$
      004883                       1458 00120$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: if (ak820_oneshot_mods) {
      004883 90 06 2B         [24] 1460 	mov	dptr,#_ak820_oneshot_mods
      004886 E0               [24] 1461 	movx	a,@dptr
      004887 FE               [12] 1462 	mov	r6,a
      004888 E0               [24] 1463 	movx	a,@dptr
      004889 60 0F            [24] 1464 	jz	00124$
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: ak820_oneshot_consumed = ak820_oneshot_mods;
      00488B 90 06 2C         [24] 1466 	mov	dptr,#_ak820_oneshot_consumed
      00488E EE               [12] 1467 	mov	a,r6
      00488F F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: ak820_oneshot_target = id;
      004890 90 0D D3         [24] 1470 	mov	dptr,#_ak820_oneshot_target
      004893 EF               [12] 1471 	mov	a,r7
      004894 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: ak820_oneshot_mods = 0;
      004895 90 06 2B         [24] 1474 	mov	dptr,#_ak820_oneshot_mods
      004898 E4               [12] 1475 	clr	a
      004899 F0               [24] 1476 	movx	@dptr,a
      00489A                       1477 00124$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: return true;
      00489A 75 82 01         [24] 1479 	mov	dpl, #0x01
                                   1480 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: }
      00489D 22               [24] 1481 	ret
                                   1482 	.area CSEG    (CODE)
                                   1483 	.area CONST   (CODE)
                                   1484 	.area XINIT   (CODE)
      00C4CC                       1485 __xinit__pending:
      00C4CC FF                    1486 	.db #0xff	; 255
      00C4CD                       1487 __xinit__ak820_oneshot_target:
      00C4CD FF                    1488 	.db #0xff	; 255
                                   1489 	.area CABS    (ABS,CODE)
                                   1490 
                                   1491 ; Experimental exact instruction outlining.
                                   1492 	.globl _ak820_outline_0013
                                   1493 	.globl _ak820_outline_0016
                                   1494 	.globl _ak820_outline_0018
                                   1495 	.globl _ak820_outline_0022
                                   1496 	.globl _ak820_outline_0023
                                   1497 	.globl _ak820_outline_0025
                                   1498 	.globl _ak820_outline_0032
                                   1499 	.globl _ak820_outline_0034
                                   1500 	.globl _ak820_outline_0037
                                   1501 	.globl _ak820_outline_0038
                                   1502 	.globl _ak820_outline_0054
                                   1503 	.globl _ak820_outline_0055
                                   1504 	.globl _ak820_outline_0060
                                   1505 	.globl _ak820_outline_0063
                                   1506 	.globl _ak820_outline_0068
                                   1507 	.globl _ak820_outline_0074
                                   1508 	.globl _ak820_outline_0083
                                   1509 	.globl _ak820_outline_0084
                                   1510 	.globl _ak820_outline_0085
                                   1511 	.globl _ak820_outline_0088
                                   1512 	.globl _ak820_outline_0089
                                   1513 	.globl _ak820_outline_0090
                                   1514 	.globl _ak820_outline_0109
                                   1515 	.globl _ak820_outline_0121
                                   1516 	.globl _ak820_outline_0122
                                   1517 	.globl _ak820_outline_0123
                                   1518 	.globl _ak820_outline_0127
                                   1519 	.globl _ak820_outline_0129
                                   1520 	.globl _ak820_outline_0132
                                   1521 	.globl _ak820_outline_0141
                                   1522 	.globl _ak820_outline_0162
                                   1523 	.globl _ak820_outline_0164
                                   1524 	.globl _ak820_outline_0177
                                   1525 
                                   1526 	.area CSEG (CODE)
                                   1527 ; function ak820_outline_0013
      00489E                       1528 _ak820_outline_0013:
      00489E E0               [24] 1529 	movx	a,@dptr
      00489F FE               [12] 1530 	mov	r6,a
      0048A0 A3               [24] 1531 	inc	dptr
      0048A1 E0               [24] 1532 	movx	a,@dptr
      0048A2 FF               [12] 1533 	mov	r7,a
      0048A3 8E 04            [24] 1534 	mov	ar4,r6
      0048A5 8F 05            [24] 1535 	mov	ar5,r7
      0048A7 22               [24] 1536 	ret
                                   1537 
                                   1538 	.area CSEG (CODE)
                                   1539 ; function ak820_outline_0022
      0048A8                       1540 _ak820_outline_0022:
      0048A8 EF               [12] 1541 	mov	a,r7
      0048A9 24 97            [12] 1542 	add	a,#_source_state
      0048AB FD               [12] 1543 	mov	r5,a
      0048AC E4               [12] 1544 	clr	a
      0048AD 34 05            [12] 1545 	addc	a,#(_source_state>>8)
      0048AF FE               [12] 1546 	mov	r6,a
      0048B0 8D 82            [24] 1547 	mov	dpl,r5
      0048B2 8E 83            [24] 1548 	mov	dph,r6
      0048B4 E0               [24] 1549 	movx	a,@dptr
      0048B5 FC               [12] 1550 	mov	r4,a
      0048B6 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0025
      0048B7                       1555 _ak820_outline_0025:
      0048B7 90 0D C2         [24] 1556 	mov	dptr,#___memcpy_PARM_2
      0048BA EC               [12] 1557 	mov	a,r4
      0048BB F0               [24] 1558 	movx	@dptr,a
      0048BC ED               [12] 1559 	mov	a,r5
      0048BD A3               [24] 1560 	inc	dptr
      0048BE F0               [24] 1561 	movx	@dptr,a
      0048BF E4               [12] 1562 	clr	a
      0048C0 A3               [24] 1563 	inc	dptr
      0048C1 F0               [24] 1564 	movx	@dptr,a
      0048C2 90 0D C5         [24] 1565 	mov	dptr,#___memcpy_PARM_3
      0048C5 74 02            [12] 1566 	mov	a,#0x02
      0048C7 F0               [24] 1567 	movx	@dptr,a
      0048C8 E4               [12] 1568 	clr	a
      0048C9 A3               [24] 1569 	inc	dptr
      0048CA F0               [24] 1570 	movx	@dptr,a
      0048CB 90 06 1D         [24] 1571 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048CE F5 F0            [12] 1572 	mov	b,a
      0048D0 22               [24] 1573 	ret
                                   1574 
                                   1575 	.area CSEG (CODE)
                                   1576 ; function ak820_outline_0032
      0048D1                       1577 _ak820_outline_0032:
      0048D1 2E               [12] 1578 	add	a,r6
      0048D2 FB               [12] 1579 	mov	r3,a
      0048D3 E4               [12] 1580 	clr	a
      0048D4 3F               [12] 1581 	addc	a,r7
      0048D5 FC               [12] 1582 	mov	r4,a
      0048D6 8B 82            [24] 1583 	mov	dpl,r3
      0048D8 8C 83            [24] 1584 	mov	dph,r4
      0048DA 22               [24] 1585 	ret
                                   1586 
                                   1587 	.area CSEG (CODE)
                                   1588 ; function ak820_outline_0054
      0048DB                       1589 _ak820_outline_0054:
      0048DB 2E               [12] 1590 	add	a,r6
      0048DC FA               [12] 1591 	mov	r2,a
      0048DD E4               [12] 1592 	clr	a
      0048DE 3F               [12] 1593 	addc	a,r7
      0048DF FB               [12] 1594 	mov	r3,a
      0048E0 8A 82            [24] 1595 	mov	dpl,r2
      0048E2 8B 83            [24] 1596 	mov	dph,r3
      0048E4 E0               [24] 1597 	movx	a,@dptr
      0048E5 22               [24] 1598 	ret
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0055
      0048E6                       1602 _ak820_outline_0055:
      0048E6 2E               [12] 1603 	add	a,r6
      0048E7 FC               [12] 1604 	mov	r4,a
      0048E8 E4               [12] 1605 	clr	a
      0048E9 3F               [12] 1606 	addc	a,r7
      0048EA FD               [12] 1607 	mov	r5,a
      0048EB 8C 82            [24] 1608 	mov	dpl,r4
      0048ED 8D 83            [24] 1609 	mov	dph,r5
      0048EF E0               [24] 1610 	movx	a,@dptr
      0048F0 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0063
      0048F1                       1615 _ak820_outline_0063:
      0048F1 FC               [12] 1616 	mov	r4,a
      0048F2 8B 82            [24] 1617 	mov	dpl,r3
      0048F4 8C 83            [24] 1618 	mov	dph,r4
      0048F6 E0               [24] 1619 	movx	a,@dptr
      0048F7 FA               [12] 1620 	mov	r2,a
      0048F8 22               [24] 1621 	ret
                                   1622 
                                   1623 	.area CSEG (CODE)
                                   1624 ; function ak820_outline_0068
      0048F9                       1625 _ak820_outline_0068:
      0048F9 EE               [12] 1626 	mov	a,r6
      0048FA F0               [24] 1627 	movx	@dptr,a
      0048FB EF               [12] 1628 	mov	a,r7
      0048FC A3               [24] 1629 	inc	dptr
      0048FD F0               [24] 1630 	movx	@dptr,a
      0048FE 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0083
      0048FF                       1635 _ak820_outline_0083:
      0048FF 8E 00            [24] 1636 	mov	ar0,r6
      004901 8F 01            [24] 1637 	mov	ar1,r7
      004903 7A 00            [12] 1638 	mov	r2,#0x00
      004905 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0084
      004906                       1643 _ak820_outline_0084:
      004906 88 82            [24] 1644 	mov	dpl,r0
      004908 89 83            [24] 1645 	mov	dph,r1
      00490A 8A F0            [24] 1646 	mov	b,r2
      00490C 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0085
      00490D                       1651 _ak820_outline_0085:
      00490D 8D 82            [24] 1652 	mov	dpl,r5
      00490F 8E 83            [24] 1653 	mov	dph,r6
      004911 E0               [24] 1654 	movx	a,@dptr
      004912 FC               [12] 1655 	mov	r4,a
      004913 22               [24] 1656 	ret
                                   1657 
                                   1658 	.area CSEG (CODE)
                                   1659 ; function ak820_outline_0090
      004914                       1660 _ak820_outline_0090:
      004914 24 97            [12] 1661 	add	a,#_source_state
      004916 FC               [12] 1662 	mov	r4,a
      004917 E4               [12] 1663 	clr	a
      004918 34 05            [12] 1664 	addc	a,#(_source_state>>8)
      00491A FD               [12] 1665 	mov	r5,a
      00491B 8C 82            [24] 1666 	mov	dpl,r4
      00491D 8D 83            [24] 1667 	mov	dph,r5
      00491F E0               [24] 1668 	movx	a,@dptr
      004920 FB               [12] 1669 	mov	r3,a
      004921 22               [24] 1670 	ret
                                   1671 
                                   1672 	.area CSEG (CODE)
                                   1673 ; function ak820_outline_0162
      004922                       1674 _ak820_outline_0162:
      004922 90 0D D2         [24] 1675 	mov	dptr,#_pending
      004925 74 FF            [12] 1676 	mov	a,#0xff
      004927 F0               [24] 1677 	movx	@dptr,a
      004928 22               [24] 1678 	ret
                                   1679 
                                   1680 	.area CSEG (CODE)
                                   1681 ; function ak820_outline_0177
      004929                       1682 _ak820_outline_0177:
      004929 8F 05            [24] 1683 	mov	ar5,r7
      00492B ED               [12] 1684 	mov	a,r5
      00492C C4               [12] 1685 	swap	a
      00492D 03               [12] 1686 	rr	a
      00492E 54 F8            [12] 1687 	anl	a,#0xf8
      004930 2E               [12] 1688 	add	a,r6
      004931 22               [24] 1689 	ret
