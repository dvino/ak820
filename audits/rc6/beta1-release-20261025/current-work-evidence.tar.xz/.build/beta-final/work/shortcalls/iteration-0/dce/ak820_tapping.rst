                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000C                        552 _ak820_tapping_before_sloc0_1_0:
      00000C                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000611                        562 _source_state:
      000611                        563 	.ds 130
      000693                        564 _pending_time:
      000693                        565 	.ds 2
      000695                        566 _pending_code:
      000695                        567 	.ds 2
      000697                        568 _ak820_tapping_source_PARM_1:
      000697                        569 	.ds 2
      000699                        570 _hold_PARM_2:
      000699                        571 	.ds 1
      00069A                        572 _hold_code_10000_601:
      00069A                        573 	.ds 2
      00069C                        574 _hold_mods_30000_604:
      00069C                        575 	.ds 1
      00069D                        576 _commit_pending_id_10000_610:
      00069D                        577 	.ds 1
      00069E                        578 _ak820_tapping_before_event_10000_611:
      00069E                        579 	.ds 2
      0006A0                        580 _ak820_tapping_process_record_10000_622:
      0006A0                        581 	.ds 2
      0006A2                        582 _ak820_tapping_process_code_10000_623:
      0006A2                        583 	.ds 2
      0006A4                        584 _ak820_tapping_process_sc_mods_10000_623:
      0006A4                        585 	.ds 1
      0006A5                        586 _ak820_oneshot_mods::
      0006A5                        587 	.ds 1
      0006A6                        588 _ak820_oneshot_consumed::
      0006A6                        589 	.ds 1
      0006A7                        590 _ak820_oneshot_process_PARM_2:
      0006A7                        591 	.ds 1
      0006A8                        592 _ak820_oneshot_process_PARM_3:
      0006A8                        593 	.ds 1
      0006A9                        594 _ak820_oneshot_process_code_10000_648:
      0006A9                        595 	.ds 2
      0006AB                        596 _ak820_oneshot_process_mods_10000_649:
      0006AB                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DF9                        606 _pending:
      000DF9                        607 	.ds 1
      000DFA                        608 _ak820_oneshot_target::
      000DFA                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0049EB                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0049EB 90 06 98         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0049EE E0               [24]  656 	movx	a,@dptr
      0049EF FF               [12]  657 	mov	r7,a
      0049F0 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0049F3                        659 00147$:
      0049F3 50 14            [24]  660 	jnc	00102$
      0049F5 90 06 97         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0049F8 E0               [24]  662 	movx	a,@dptr
      0049F9 FE               [12]  663 	mov	r6,a
      0049FA BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0049FD                        665 00149$:
      0049FD 50 0A            [24]  666 	jnc	00102$
      0049FF 8F 05            [24]  667 	mov	ar5,r7
      004A01 ED               [12]  668 	mov	a,r5
      004A02 12 38 87         [24]  669 	lcall	_ak820_outline_0188
      004A05 2E               [12]  670 	add	a,r6
      004A06 F5 82            [12]  671 	mov	dpl,a
      004A08 22               [24]  672 	ret
      004A09                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004A09 90 06 97         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004A0C E0               [24]  676 	movx	a,@dptr
      004A0D FE               [12]  677 	mov	r6,a
      004A0E BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004A11                        679 00151$:
      004A11 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004A13 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004A16 75 82 80         [24]  683 	mov	dpl, #0x80
      004A19 22               [24]  684 	ret
      004A1A                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004A1A BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004A1D 75 82 81         [24]  688 	mov	dpl, #0x81
      004A20 22               [24]  689 	ret
      004A21                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004A21 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004A24 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004A25                        707 _hold:
      004A25 12 38 41         [24]  708 	lcall	_ak820_outline_0104
      004A28 90 06 9A         [24]  709 	mov	dptr,#_hold_code_10000_601
      004A2B 12 38 46         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004A2E 90 06 9A         [24]  712 	mov	dptr,#_hold_code_10000_601
      004A31 12 37 C2         [24]  713 	lcall	_ak820_outline_0011
      004A34 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004A36 2D               [12]  715 	add	a,r5
      004A37 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004A39 8F 05            [24]  718 	mov	ar5,r7
      004A3B 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004A3E 90 06 9C         [24]  720 	mov	dptr,#_hold_mods_30000_604
      004A41 ED               [12]  721 	mov	a,r5
      004A42 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004A43 ED               [12]  724 	mov	a,r5
      004A44 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004A47 ED               [12]  726 	mov	a,r5
      004A48 C4               [12]  727 	swap	a
      004A49 54 F0            [12]  728 	anl	a,#0xf0
      004A4B 90 06 9C         [24]  729 	mov	dptr,#_hold_mods_30000_604
      004A4E F0               [24]  730 	movx	@dptr,a
      004A4F                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004A4F 90 06 99         [24]  733 	mov	dptr,#_hold_PARM_2
      004A52 E0               [24]  734 	movx	a,@dptr
      004A53 60 09            [24]  735 	jz	00104$
      004A55 90 06 9C         [24]  736 	mov	dptr,#_hold_mods_30000_604
      004A58 E0               [24]  737 	movx	a,@dptr
      004A59 F5 82            [12]  738 	mov	dpl,a
      004A5B 02 7D 8F         [24]  739 	ljmp	_register_mods
      004A5E                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004A5E 90 06 9C         [24]  742 	mov	dptr,#_hold_mods_30000_604
      004A61 E0               [24]  743 	movx	a,@dptr
      004A62 F5 82            [12]  744 	mov	dpl,a
      004A64 02 7D A3         [24]  745 	ljmp	_unregister_mods
      004A67                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004A67 8F 06            [24]  748 	mov	ar6,r7
      004A69 74 0F            [12]  749 	mov	a,#0x0f
      004A6B 5E               [12]  750 	anl	a,r6
      004A6C FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004A6D 90 06 99         [24]  753 	mov	dptr,#_hold_PARM_2
      004A70 E0               [24]  754 	movx	a,@dptr
      004A71 60 05            [24]  755 	jz	00107$
      004A73 8F 82            [24]  756 	mov	dpl, r7
      004A75 02 7F 55         [24]  757 	ljmp	_layer_hold_on
      004A78                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      004A78 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004A7A 02 7F 8C         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004A7D                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004A7D 90 0D F9         [24]  774 	mov	dptr,#_pending
      004A80 E0               [24]  775 	movx	a,@dptr
      004A81 90 06 9D         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004A84 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004A85 12 4E DF         [24]  779 	lcall	_ak820_outline_0151
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      004A88 90 06 9D         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      004A8B E0               [24]  782 	movx	a,@dptr
      004A8C 24 11            [12]  783 	add	a,#_source_state
      004A8E FF               [12]  784 	mov	r7,a
      004A8F E4               [12]  785 	clr	a
      004A90 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004A92 FE               [12]  787 	mov	r6,a
      004A93 12 49 0B         [24]  788 	lcall	_ak820_outline_0154
      004A96 E0               [24]  789 	movx	a,@dptr
      004A97 FD               [12]  790 	mov	r5,a
      004A98 43 05 04         [24]  791 	orl	ar5,#0x04
      004A9B 12 49 0B         [24]  792 	lcall	_ak820_outline_0154
      004A9E ED               [12]  793 	mov	a,r5
      004A9F F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004AA0 90 06 95         [24]  796 	mov	dptr,#_pending_code
      004AA3 12 37 F7         [24]  797 	lcall	_ak820_outline_0052
      004AA6 90 06 99         [24]  798 	mov	dptr,#_hold_PARM_2
      004AA9 12 4E A9         [24]  799 	lcall	_ak820_outline_0044
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004AAC 41 25            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004AAE                        812 _ak820_tapping_before:
      004AAE 12 38 41         [24]  813 	lcall	_ak820_outline_0104
      004AB1 90 06 9E         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004AB4 12 38 46         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      004AB7 90 06 9E         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004ABA 12 37 C2         [24]  818 	lcall	_ak820_outline_0011
      004ABD 12 4E 8F         [24]  819 	lcall	_ak820_outline_0023
      004AC0 C0 07            [24]  820 	push	ar7
      004AC2 C0 06            [24]  821 	push	ar6
      004AC4 12 BD 95         [24]  822 	lcall	___memcpy
      004AC7 31 EB            [12]  823 	acall	_ak820_tapping_source
      004AC9 AD 82            [24]  824 	mov	r5, dpl
      004ACB D0 06            [24]  825 	pop	ar6
      004ACD D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004ACF 90 0E 6A         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      004AD2 E0               [24]  829 	movx	a,@dptr
      004AD3 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004AD5 74 04            [12]  832 	mov	a,#0x04
      004AD7 12 4E 75         [24]  833 	lcall	_ak820_outline_0013
      004ADA 60 1E            [24]  834 	jz	00102$
      004ADC BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      004ADF 80 19            [24]  836 	sjmp	00102$
      004AE1                        837 00218$:
      004AE1 74 05            [12]  838 	mov	a,#0x05
      004AE3 12 4E 75         [24]  839 	lcall	_ak820_outline_0013
      004AE6 70 12            [24]  840 	jnz	00102$
      004AE8 ED               [12]  841 	mov	a,r5
      004AE9 24 11            [12]  842 	add	a, #_source_state
      004AEB FB               [12]  843 	mov	r3,a
      004AEC E4               [12]  844 	clr	a
      004AED 34 06            [12]  845 	addc	a, #(_source_state >> 8)
      004AEF 12 4E BC         [24]  846 	lcall	_ak820_outline_0056
      004AF2 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004AF5 12 33 FC         [24]  848 	lcall	_ak820_outline_0123
      004AF8 EA               [12]  849 	mov	a,r2
      004AF9 F0               [24]  850 	movx	@dptr,a
      004AFA                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004AFA 75 82 00         [24]  853 	mov	dpl, #0x00
      004AFD 22               [24]  854 	ret
      004AFE                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004AFE 90 0D F9         [24]  857 	mov	dptr,#_pending
      004B01 E0               [24]  858 	movx	a,@dptr
      004B02 FC               [12]  859 	mov	r4,a
      004B03 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004B06 80 3A            [24]  861 	sjmp	00108$
      004B08                        862 00220$:
      004B08 12 37 E7         [24]  863 	lcall	_ak820_outline_0030
      004B0B FA               [12]  864 	mov	r2,a
      004B0C A3               [24]  865 	inc	dptr
      004B0D E0               [24]  866 	movx	a,@dptr
      004B0E FB               [12]  867 	mov	r3,a
      004B0F 90 06 93         [24]  868 	mov	dptr,#_pending_time
      004B12 12 38 3B         [24]  869 	lcall	_ak820_outline_0101
      004B15 EA               [12]  870 	mov	a,r2
      004B16 C3               [12]  871 	clr	c
      004B17 98               [12]  872 	subb	a,r0
      004B18 FA               [12]  873 	mov	r2,a
      004B19 EB               [12]  874 	mov	a,r3
      004B1A 99               [12]  875 	subb	a,r1
      004B1B FB               [12]  876 	mov	r3,a
      004B1C C3               [12]  877 	clr	c
      004B1D EA               [12]  878 	mov	a,r2
      004B1E 94 C8            [12]  879 	subb	a,#0xc8
      004B20 EB               [12]  880 	mov	a,r3
      004B21 94 00            [12]  881 	subb	a,#0x00
      004B23 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004B25 74 04            [12]  884 	mov	a,#0x04
      004B27 12 4E B1         [24]  885 	lcall	_ak820_outline_0047
      004B2A 60 16            [24]  886 	jz	00108$
      004B2C 12 37 A1         [24]  887 	lcall	_ak820_outline_0005
      004B2F 60 11            [24]  888 	jz	00108$
      004B31 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004B34 80 06            [24]  890 	sjmp	00107$
      004B36                        891 00224$:
      004B36 ED               [12]  892 	mov	a,r5
      004B37 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004B3A 80 06            [24]  894 	sjmp	00108$
      004B3C                        895 00225$:
      004B3C                        896 00107$:
      004B3C C0 05            [24]  897 	push	ar5
      004B3E 51 7D            [12]  898 	acall	_commit_pending
      004B40 D0 05            [24]  899 	pop	ar5
      004B42                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004B42 90 06 9E         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004B45 12 37 F7         [24]  903 	lcall	_ak820_outline_0052
      004B48 74 04            [12]  904 	mov	a,#0x04
      004B4A 12 4E 75         [24]  905 	lcall	_ak820_outline_0013
      004B4D 60 03            [24]  906 	jz	00114$
      004B4F BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      004B52                        908 00114$:
      004B52 75 82 01         [24]  909 	mov	dpl, #0x01
      004B55 22               [24]  910 	ret
      004B56                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004B56 ED               [12]  913 	mov	a,r5
      004B57 12 4E D1         [24]  914 	lcall	_ak820_outline_0079
      004B5A 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004B5D 74 05            [12]  917 	mov	a,#0x05
      004B5F 2E               [12]  918 	add	a, r6
      004B60 12 37 CC         [24]  919 	lcall	_ak820_outline_0014
      004B63 70 07            [24]  920 	jnz	00118$
      004B65 74 FD            [12]  921 	mov	a,#0xfd
      004B67 5B               [12]  922 	anl	a,r3
      004B68 12 38 57         [24]  923 	lcall	_ak820_outline_0122
      004B6B F0               [24]  924 	movx	@dptr,a
      004B6C                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004B6C 75 82 00         [24]  927 	mov	dpl, #0x00
      004B6F 22               [24]  928 	ret
      004B70                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004B70 12 48 8A         [24]  931 	lcall	_ak820_outline_0010
      004B73 E0               [24]  932 	movx	a,@dptr
      004B74 FF               [12]  933 	mov	r7,a
      004B75 8B 06            [24]  934 	mov	ar6,r3
      004B77 53 06 01         [24]  935 	anl	ar6,#0x01
      004B7A EE               [12]  936 	mov	a,r6
      004B7B B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      004B7E                        938 00231$:
      004B7E B3               [12]  939 	cpl	c
      004B7F 92 0C            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004B81 8F F0            [24]  941 	mov	b,r7
      004B83 E4               [12]  942 	clr	a
      004B84 33               [12]  943 	rlc	a
      004B85 B5 F0 04         [24]  944 	cjne	a,b,00122$
      004B88 75 82 00         [24]  945 	mov	dpl, #0x00
      004B8B 22               [24]  946 	ret
      004B8C                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004B8C 63 03 01         [24]  949 	xrl	ar3,#0x01
      004B8F 12 38 57         [24]  950 	lcall	_ak820_outline_0122
      004B92 EB               [12]  951 	mov	a,r3
      004B93 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004B94 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004B97 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      004B98                        970 _ak820_tapping_process:
      004B98 12 38 41         [24]  971 	lcall	_ak820_outline_0104
      004B9B 90 06 A0         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004B9E 12 38 46         [24]  973 	lcall	_ak820_outline_0105
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004BA1 90 06 A4         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004BA4 E4               [12]  976 	clr	a
      004BA5 F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004BA6 90 06 A0         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004BA9 12 37 F7         [24]  980 	lcall	_ak820_outline_0052
      004BAC 74 04            [12]  981 	mov	a,#0x04
      004BAE 12 4E 6A         [24]  982 	lcall	_ak820_outline_0012
      004BB1 70 04            [24]  983 	jnz	00102$
      004BB3 75 82 01         [24]  984 	mov	dpl, #0x01
      004BB6 22               [24]  985 	ret
      004BB7                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004BB7 8E 04            [24]  988 	mov	ar4,r6
      004BB9 8F 05            [24]  989 	mov	ar5,r7
      004BBB 12 4E 8F         [24]  990 	lcall	_ak820_outline_0023
      004BBE C0 07            [24]  991 	push	ar7
      004BC0 C0 06            [24]  992 	push	ar6
      004BC2 12 BD 95         [24]  993 	lcall	___memcpy
      004BC5 31 EB            [12]  994 	acall	_ak820_tapping_source
      004BC7 AD 82            [24]  995 	mov	r5, dpl
      004BC9 D0 06            [24]  996 	pop	ar6
      004BCB D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004BCD BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      004BD0 75 82 01         [24] 1000 	mov	dpl, #0x01
      004BD3 22               [24] 1001 	ret
      004BD4                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004BD4 74 07            [12] 1004 	mov	a,#0x07
      004BD6 12 37 DE         [24] 1005 	lcall	_ak820_outline_0017
      004BD9 FE               [12] 1006 	mov	r6,a
      004BDA A3               [24] 1007 	inc	dptr
      004BDB E0               [24] 1008 	movx	a,@dptr
      004BDC FF               [12] 1009 	mov	r7,a
      004BDD 90 06 A2         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004BE0 12 4E C4         [24] 1011 	lcall	_ak820_outline_0059
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004BE3 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      004BE6 BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      004BE9 90 06 A2         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004BEC 74 26            [12] 1016 	mov	a,#0x26
      004BEE F0               [24] 1017 	movx	@dptr,a
      004BEF 74 22            [12] 1018 	mov	a,#0x22
      004BF1 A3               [24] 1019 	inc	dptr
      004BF2 F0               [24] 1020 	movx	@dptr,a
      004BF3 90 06 A4         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004BF6 74 02            [12] 1022 	mov	a,#0x02
      004BF8 F0               [24] 1023 	movx	@dptr,a
      004BF9 80 28            [24] 1024 	sjmp	00112$
      004BFB                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004BFB BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      004BFE BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      004C01 90 06 A2         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004C04 74 27            [12] 1030 	mov	a,#0x27
      004C06 F0               [24] 1031 	movx	@dptr,a
      004C07 74 32            [12] 1032 	mov	a,#0x32
      004C09 A3               [24] 1033 	inc	dptr
      004C0A F0               [24] 1034 	movx	@dptr,a
      004C0B 90 06 A4         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004C0E 74 20            [12] 1036 	mov	a,#0x20
      004C10 F0               [24] 1037 	movx	@dptr,a
      004C11 80 10            [24] 1038 	sjmp	00112$
      004C13                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004C13 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      004C16 BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      004C19 90 06 A2         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004C1C 74 28            [12] 1044 	mov	a,#0x28
      004C1E F0               [24] 1045 	movx	@dptr,a
      004C1F 74 32            [12] 1046 	mov	a,#0x32
      004C21 A3               [24] 1047 	inc	dptr
      004C22 F0               [24] 1048 	movx	@dptr,a
      004C23                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004C23 90 06 A2         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004C26 E0               [24] 1052 	movx	a,@dptr
      004C27 A3               [24] 1053 	inc	dptr
      004C28 E0               [24] 1054 	movx	a,@dptr
      004C29 FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004C2A BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      004C2D                       1058 00242$:
      004C2D 40 05            [24] 1059 	jc	00113$
      004C2F BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      004C32                       1061 00244$:
      004C32 40 04            [24] 1062 	jc	00114$
      004C34                       1063 00113$:
      004C34 75 82 01         [24] 1064 	mov	dpl, #0x01
      004C37 22               [24] 1065 	ret
      004C38                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004C38 BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      004C3B                       1069 00246$:
      004C3B 40 0C            [24] 1070 	jc	00117$
      004C3D 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      004C40 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      004C43                       1073 00248$:
      004C43 40 04            [24] 1074 	jc	00117$
      004C45 75 82 00         [24] 1075 	mov	dpl, #0x00
      004C48 22               [24] 1076 	ret
      004C49                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004C49 90 06 A0         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004C4C 12 37 F7         [24] 1080 	lcall	_ak820_outline_0052
      004C4F 74 05            [12] 1081 	mov	a,#0x05
      004C51 12 4E 75         [24] 1082 	lcall	_ak820_outline_0013
      004C54 60 20            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004C56 90 0D F9         [24] 1085 	mov	dptr,#_pending
      004C59 ED               [12] 1086 	mov	a,r5
      004C5A F0               [24] 1087 	movx	@dptr,a
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004C5B 12 37 E7         [24] 1089 	lcall	_ak820_outline_0030
      004C5E FE               [12] 1090 	mov	r6,a
      004C5F A3               [24] 1091 	inc	dptr
      004C60 E0               [24] 1092 	movx	a,@dptr
      004C61 FF               [12] 1093 	mov	r7,a
      004C62 90 06 93         [24] 1094 	mov	dptr,#_pending_time
      004C65 12 4E C4         [24] 1095 	lcall	_ak820_outline_0059
                                   1096 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004C68 90 06 A2         [24] 1097 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004C6B 12 37 F7         [24] 1098 	lcall	_ak820_outline_0052
      004C6E 90 06 95         [24] 1099 	mov	dptr,#_pending_code
      004C71 12 4E C4         [24] 1100 	lcall	_ak820_outline_0059
      004C74 A1 11            [12] 1101 	ajmp	00132$
      004C76                       1102 00131$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004C76 90 0D F9         [24] 1104 	mov	dptr,#_pending
      004C79 E0               [24] 1105 	movx	a,@dptr
      004C7A FF               [12] 1106 	mov	r7,a
      004C7B ED               [12] 1107 	mov	a,r5
      004C7C B5 07 02         [24] 1108 	cjne	a,ar7,00251$
      004C7F 80 02            [24] 1109 	sjmp	00252$
      004C81                       1110 00251$:
      004C81 81 EB            [12] 1111 	ajmp	00128$
      004C83                       1112 00252$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004C83 12 4E DF         [24] 1114 	lcall	_ak820_outline_0151
                                   1115 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004C86 90 06 A4         [24] 1116 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004C89 E0               [24] 1117 	movx	a,@dptr
      004C8A FF               [12] 1118 	mov	r7,a
      004C8B E0               [24] 1119 	movx	a,@dptr
      004C8C 60 05            [24] 1120 	jz	00120$
      004C8E 8F 82            [24] 1121 	mov	dpl, r7
      004C90 12 83 CA         [24] 1122 	lcall	_add_owned_mods
      004C93                       1123 00120$:
                                   1124 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004C93 90 06 A0         [24] 1125 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004C96 12 37 F7         [24] 1126 	lcall	_ak820_outline_0052
      004C99 74 07            [12] 1127 	mov	a,#0x07
      004C9B 2E               [12] 1128 	add	a, r6
      004C9C FB               [12] 1129 	mov	r3,a
      004C9D E4               [12] 1130 	clr	a
      004C9E 3F               [12] 1131 	addc	a, r7
      004C9F FC               [12] 1132 	mov	r4,a
      004CA0 90 06 A2         [24] 1133 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004CA3 E0               [24] 1134 	movx	a,@dptr
      004CA4 F9               [12] 1135 	mov	r1,a
      004CA5 7A 00            [12] 1136 	mov	r2,#0x00
      004CA7 12 33 FC         [24] 1137 	lcall	_ak820_outline_0123
      004CAA E9               [12] 1138 	mov	a,r1
      004CAB F0               [24] 1139 	movx	@dptr,a
      004CAC EA               [12] 1140 	mov	a,r2
      004CAD A3               [24] 1141 	inc	dptr
      004CAE F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004CAF C3               [12] 1144 	clr	c
      004CB0 04               [12] 1145 	inc	a
      004CB1 99               [12] 1146 	subb	a,r1
      004CB2 50 25            [24] 1147 	jnc	00122$
                                   1148 ;	free result
                                   1149 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004CB4 74 06            [12] 1150 	mov	a,#0x06
      004CB6 12 37 DE         [24] 1151 	lcall	_ak820_outline_0017
      004CB9 54 0F            [12] 1152 	anl	a,#0x0f
      004CBB 44 10            [12] 1153 	orl	a,#0x10
      004CBD F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004CBE 12 48 8A         [24] 1156 	lcall	_ak820_outline_0010
      004CC1 12 4E A9         [24] 1157 	lcall	_ak820_outline_0044
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004CC4 12 77 D1         [24] 1159 	lcall	_process_record
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004CC7 90 06 A0         [24] 1161 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004CCA 12 37 97         [24] 1162 	lcall	_ak820_outline_0004
      004CCD A3               [24] 1163 	inc	dptr
      004CCE A3               [24] 1164 	inc	dptr
      004CCF A3               [24] 1165 	inc	dptr
      004CD0 A3               [24] 1166 	inc	dptr
      004CD1 A3               [24] 1167 	inc	dptr
      004CD2 E4               [12] 1168 	clr	a
      004CD3 12 48 C0         [24] 1169 	lcall	_ak820_outline_0061
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004CD6 12 77 D1         [24] 1171 	lcall	_process_record
      004CD9                       1172 00122$:
                                   1173 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004CD9 90 06 A4         [24] 1174 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004CDC E0               [24] 1175 	movx	a,@dptr
      004CDD FF               [12] 1176 	mov	r7,a
      004CDE E0               [24] 1177 	movx	a,@dptr
      004CDF 60 30            [24] 1178 	jz	00132$
                                   1179 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004CE1 8F 82            [24] 1180 	mov	dpl, r7
      004CE3 12 83 D9         [24] 1181 	lcall	_del_owned_mods
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004CE6 12 86 FB         [24] 1183 	lcall	_send_keyboard_report
      004CE9 80 26            [24] 1184 	sjmp	00132$
      004CEB                       1185 00128$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004CEB ED               [12] 1187 	mov	a,r5
      004CEC 24 11            [12] 1188 	add	a, #_source_state
      004CEE FE               [12] 1189 	mov	r6,a
      004CEF E4               [12] 1190 	clr	a
      004CF0 34 06            [12] 1191 	addc	a, #(_source_state >> 8)
      004CF2 FF               [12] 1192 	mov	r7,a
      004CF3 12 38 2F         [24] 1193 	lcall	_ak820_outline_0091
      004CF6 FD               [12] 1194 	mov	r5,a
      004CF7 30 E2 17         [24] 1195 	jnb	acc.2,00132$
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004CFA 53 05 FB         [24] 1197 	anl	ar5,#0xfb
      004CFD 12 48 E5         [24] 1198 	lcall	_ak820_outline_0114
      004D00 ED               [12] 1199 	mov	a,r5
      004D01 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004D02 90 06 A2         [24] 1202 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004D05 12 37 F7         [24] 1203 	lcall	_ak820_outline_0052
      004D08 90 06 99         [24] 1204 	mov	dptr,#_hold_PARM_2
      004D0B E4               [12] 1205 	clr	a
      004D0C 12 48 C0         [24] 1206 	lcall	_ak820_outline_0061
      004D0F 51 25            [12] 1207 	acall	_hold
      004D11                       1208 00132$:
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004D11 75 82 00         [24] 1210 	mov	dpl, #0x00
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004D14 22               [24] 1212 	ret
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1215 ;------------------------------------------------------------
                                   1216 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1217 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1218 ;------------------------------------------------------------
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1220 ;	-----------------------------------------
                                   1221 ;	 function ak820_tapping_cancel
                                   1222 ;	-----------------------------------------
      004D15                       1223 _ak820_tapping_cancel:
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004D15 12 4E DF         [24] 1225 	lcall	_ak820_outline_0151
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004D18 7F 00            [12] 1227 	mov	r7,#0x00
      004D1A                       1228 00103$:
      004D1A BF 82 00         [24] 1229 	cjne	r7,#0x82,00122$
      004D1D                       1230 00122$:
      004D1D 50 16            [24] 1231 	jnc	00105$
                                   1232 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004D1F 12 4E 80         [24] 1233 	lcall	_ak820_outline_0019
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004D22 74 02            [12] 1235 	mov	a,#0x02
      004D24 5C               [12] 1236 	anl	a,r4
      004D25 FB               [12] 1237 	mov	r3,a
      004D26 53 04 01         [24] 1238 	anl	ar4,#0x01
      004D29 EC               [12] 1239 	mov	a,r4
      004D2A 2C               [12] 1240 	add	a,r4
      004D2B 42 03            [12] 1241 	orl	ar3,a
      004D2D 12 38 61         [24] 1242 	lcall	_ak820_outline_0133
      004D30 EB               [12] 1243 	mov	a,r3
      004D31 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004D32 0F               [12] 1246 	inc	r7
      004D33 80 E5            [24] 1247 	sjmp	00103$
      004D35                       1248 00105$:
                                   1249 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004D35 22               [24] 1250 	ret
                                   1251 ;------------------------------------------------------------
                                   1252 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1253 ;------------------------------------------------------------
                                   1254 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1255 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1256 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1257 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1258 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1259 ;------------------------------------------------------------
                                   1260 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1261 ;	-----------------------------------------
                                   1262 ;	 function ak820_oneshot_process
                                   1263 ;	-----------------------------------------
      004D36                       1264 _ak820_oneshot_process:
      004D36 12 38 41         [24] 1265 	lcall	_ak820_outline_0104
      004D39 90 06 A9         [24] 1266 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004D3C 12 38 46         [24] 1267 	lcall	_ak820_outline_0105
                                   1268 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004D3F 90 06 A7         [24] 1269 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004D42 E0               [24] 1270 	movx	a,@dptr
      004D43 FF               [12] 1271 	mov	r7,a
      004D44 BF FF 02         [24] 1272 	cjne	r7,#0xff,00248$
      004D47 80 07            [24] 1273 	sjmp	00101$
      004D49                       1274 00248$:
      004D49 12 A7 C4         [24] 1275 	lcall	_get_repeat_key_count
      004D4C E5 82            [12] 1276 	mov	a, dpl
      004D4E 60 04            [24] 1277 	jz	00102$
      004D50                       1278 00101$:
      004D50 75 82 01         [24] 1279 	mov	dpl, #0x01
      004D53 22               [24] 1280 	ret
      004D54                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004D54 90 06 A9         [24] 1283 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004D57 E0               [24] 1284 	movx	a,@dptr
      004D58 FD               [12] 1285 	mov	r5,a
      004D59 A3               [24] 1286 	inc	dptr
      004D5A E0               [24] 1287 	movx	a,@dptr
      004D5B FB               [12] 1288 	mov	r3,a
      004D5C BB 52 02         [24] 1289 	cjne	r3,#0x52,00250$
      004D5F 80 02            [24] 1290 	sjmp	00251$
      004D61                       1291 00250$:
      004D61 C1 04            [12] 1292 	ajmp	00116$
      004D63                       1293 00251$:
      004D63 8D 04            [24] 1294 	mov	ar4,r5
      004D65 53 04 E0         [24] 1295 	anl	ar4,#0xe0
      004D68 BC A0 02         [24] 1296 	cjne	r4,#0xa0,00252$
      004D6B 80 02            [24] 1297 	sjmp	00253$
      004D6D                       1298 00252$:
      004D6D C1 04            [12] 1299 	ajmp	00116$
      004D6F                       1300 00253$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004D6F 8D 04            [24] 1302 	mov	ar4,r5
      004D71 53 04 0F         [24] 1303 	anl	ar4,#0x0f
      004D74 90 06 AB         [24] 1304 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004D77 EC               [12] 1305 	mov	a,r4
      004D78 F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004D79 ED               [12] 1308 	mov	a,r5
      004D7A 30 E4 08         [24] 1309 	jnb	acc.4,00105$
      004D7D EC               [12] 1310 	mov	a,r4
      004D7E C4               [12] 1311 	swap	a
      004D7F 54 F0            [12] 1312 	anl	a,#0xf0
      004D81 90 06 AB         [24] 1313 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004D84 F0               [24] 1314 	movx	@dptr,a
      004D85                       1315 00105$:
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004D85 90 06 A8         [24] 1317 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D88 E0               [24] 1318 	movx	a,@dptr
      004D89 60 2D            [24] 1319 	jz	00113$
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004D8B 12 4E 80         [24] 1321 	lcall	_ak820_outline_0019
      004D8E 43 04 08         [24] 1322 	orl	ar4,#0x08
      004D91 12 48 C6         [24] 1323 	lcall	_ak820_outline_0065
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004D94 53 04 EF         [24] 1325 	anl	ar4,#0xef
      004D97 12 48 C6         [24] 1326 	lcall	_ak820_outline_0065
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004D9A 90 0D FA         [24] 1328 	mov	dptr,#_ak820_oneshot_target
      004D9D E0               [24] 1329 	movx	a,@dptr
      004D9E FC               [12] 1330 	mov	r4,a
      004D9F BC FF 02         [24] 1331 	cjne	r4,#0xff,00256$
      004DA2 80 09            [24] 1332 	sjmp	00107$
      004DA4                       1333 00256$:
      004DA4 12 4E CA         [24] 1334 	lcall	_ak820_outline_0076
      004DA7 43 04 10         [24] 1335 	orl	ar4,#0x10
      004DAA 12 48 C6         [24] 1336 	lcall	_ak820_outline_0065
      004DAD                       1337 00107$:
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004DAD 90 06 AB         [24] 1339 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004DB0 E0               [24] 1340 	movx	a,@dptr
      004DB1 F5 82            [12] 1341 	mov	dpl,a
      004DB3 12 7D 8F         [24] 1342 	lcall	_register_mods
      004DB6 80 48            [24] 1343 	sjmp	00114$
      004DB8                       1344 00113$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004DB8 12 4E 80         [24] 1346 	lcall	_ak820_outline_0019
      004DBB 30 E3 42         [24] 1347 	jnb	acc.3,00114$
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004DBE EC               [12] 1349 	mov	a,r4
      004DBF 20 E4 24         [24] 1350 	jb	acc.4,00109$
                                   1351 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004DC2 90 06 A5         [24] 1352 	mov	dptr,#_ak820_oneshot_mods
      004DC5 E0               [24] 1353 	movx	a,@dptr
      004DC6 F4               [12] 1354 	cpl	a
      004DC7 FC               [12] 1355 	mov	r4,a
      004DC8 90 06 AB         [24] 1356 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004DCB E0               [24] 1357 	movx	a,@dptr
      004DCC FB               [12] 1358 	mov	r3,a
      004DCD 52 04            [12] 1359 	anl	ar4,a
      004DCF 8C 82            [24] 1360 	mov	dpl, r4
      004DD1 C0 06            [24] 1361 	push	ar6
      004DD3 C0 05            [24] 1362 	push	ar5
      004DD5 C0 03            [24] 1363 	push	ar3
      004DD7 12 83 CA         [24] 1364 	lcall	_add_owned_mods
      004DDA D0 03            [24] 1365 	pop	ar3
      004DDC D0 05            [24] 1366 	pop	ar5
      004DDE D0 06            [24] 1367 	pop	ar6
                                   1368 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004DE0 90 06 A5         [24] 1369 	mov	dptr,#_ak820_oneshot_mods
      004DE3 E0               [24] 1370 	movx	a,@dptr
      004DE4 4B               [12] 1371 	orl	a,r3
      004DE5 F0               [24] 1372 	movx	@dptr,a
      004DE6                       1373 00109$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004DE6 90 06 AB         [24] 1375 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004DE9 E0               [24] 1376 	movx	a,@dptr
      004DEA F5 82            [12] 1377 	mov	dpl,a
      004DEC C0 06            [24] 1378 	push	ar6
      004DEE C0 05            [24] 1379 	push	ar5
      004DF0 12 7D A3         [24] 1380 	lcall	_unregister_mods
      004DF3 D0 05            [24] 1381 	pop	ar5
      004DF5 D0 06            [24] 1382 	pop	ar6
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004DF7 12 4E CA         [24] 1384 	lcall	_ak820_outline_0076
      004DFA 53 04 E7         [24] 1385 	anl	ar4,#0xe7
      004DFD 12 48 C6         [24] 1386 	lcall	_ak820_outline_0065
      004E00                       1387 00114$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004E00 75 82 00         [24] 1389 	mov	dpl, #0x00
      004E03 22               [24] 1390 	ret
      004E04                       1391 00116$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004E04 90 06 A8         [24] 1393 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004E07 E0               [24] 1394 	movx	a,@dptr
      004E08 60 5C            [24] 1395 	jz	00124$
      004E0A 90 06 A9         [24] 1396 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004E0D 12 48 D3         [24] 1397 	lcall	_ak820_outline_0095
      004E10 C3               [12] 1398 	clr	c
      004E11 74 01            [12] 1399 	mov	a,#0x01
      004E13 9D               [12] 1400 	subb	a,r5
      004E14 E4               [12] 1401 	clr	a
      004E15 9E               [12] 1402 	subb	a,r6
      004E16 50 4E            [24] 1403 	jnc	00124$
                                   1404 ;	free result
                                   1405 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004E18 C3               [12] 1406 	clr	c
      004E19 ED               [12] 1407 	mov	a,r5
      004E1A 94 E0            [12] 1408 	subb	a,#0xe0
      004E1C EE               [12] 1409 	mov	a,r6
      004E1D 94 00            [12] 1410 	subb	a,#0x00
      004E1F 40 07            [24] 1411 	jc	00129$
      004E21 74 E7            [12] 1412 	mov	a,#0xe7
      004E23 9D               [12] 1413 	subb	a,r5
      004E24 E4               [12] 1414 	clr	a
      004E25 9E               [12] 1415 	subb	a,r6
      004E26 50 3E            [24] 1416 	jnc	00124$
                                   1417 ;	free result
      004E28                       1418 00129$:
                                   1419 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004E28 74 AE            [12] 1420 	mov	a,#0x100 - 0x52
      004E2A 2E               [12] 1421 	add	a,r6
      004E2B 50 09            [24] 1422 	jnc	00165$
      004E2D C3               [12] 1423 	clr	c
      004E2E 74 DF            [12] 1424 	mov	a,#0xdf
      004E30 9D               [12] 1425 	subb	a,r5
      004E31 74 52            [12] 1426 	mov	a,#0x52
      004E33 9E               [12] 1427 	subb	a,r6
      004E34 50 30            [24] 1428 	jnc	00124$
                                   1429 ;	free result
                                   1430 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004E36                       1431 00165$:
      004E36 7E 00            [12] 1432 	mov	r6,#0x00
      004E38                       1433 00131$:
      004E38 BE 82 00         [24] 1434 	cjne	r6,#0x82,00265$
      004E3B                       1435 00265$:
      004E3B 50 12            [24] 1436 	jnc	00120$
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004E3D EE               [12] 1438 	mov	a,r6
      004E3E 12 4E D1         [24] 1439 	lcall	_ak820_outline_0079
      004E41 30 E3 08         [24] 1440 	jnb	acc.3,00132$
      004E44 43 03 10         [24] 1441 	orl	ar3,#0x10
      004E47 12 38 57         [24] 1442 	lcall	_ak820_outline_0122
      004E4A EB               [12] 1443 	mov	a,r3
      004E4B F0               [24] 1444 	movx	@dptr,a
      004E4C                       1445 00132$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004E4C 0E               [12] 1447 	inc	r6
      004E4D 80 E9            [24] 1448 	sjmp	00131$
      004E4F                       1449 00120$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004E4F 90 06 A5         [24] 1451 	mov	dptr,#_ak820_oneshot_mods
      004E52 E0               [24] 1452 	movx	a,@dptr
      004E53 FE               [12] 1453 	mov	r6,a
      004E54 E0               [24] 1454 	movx	a,@dptr
      004E55 60 0F            [24] 1455 	jz	00124$
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004E57 90 06 A6         [24] 1457 	mov	dptr,#_ak820_oneshot_consumed
      004E5A EE               [12] 1458 	mov	a,r6
      004E5B F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004E5C 90 0D FA         [24] 1461 	mov	dptr,#_ak820_oneshot_target
      004E5F EF               [12] 1462 	mov	a,r7
      004E60 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004E61 90 06 A5         [24] 1465 	mov	dptr,#_ak820_oneshot_mods
      004E64 E4               [12] 1466 	clr	a
      004E65 F0               [24] 1467 	movx	@dptr,a
      004E66                       1468 00124$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004E66 75 82 01         [24] 1470 	mov	dpl, #0x01
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004E69 22               [24] 1472 	ret
                                   1473 	.area CSEG    (CODE)
                                   1474 	.area CONST   (CODE)
                                   1475 	.area XINIT   (CODE)
      00C656                       1476 __xinit__pending:
      00C656 FF                    1477 	.db #0xff	; 255
      00C657                       1478 __xinit__ak820_oneshot_target:
      00C657 FF                    1479 	.db #0xff	; 255
                                   1480 	.area CABS    (ABS,CODE)
                                   1481 
                                   1482 ; Experimental exact instruction outlining.
                                   1483 	.globl _ak820_outline_0004
                                   1484 	.globl _ak820_outline_0005
                                   1485 	.globl _ak820_outline_0010
                                   1486 	.globl _ak820_outline_0011
                                   1487 	.globl _ak820_outline_0012
                                   1488 	.globl _ak820_outline_0013
                                   1489 	.globl _ak820_outline_0014
                                   1490 	.globl _ak820_outline_0017
                                   1491 	.globl _ak820_outline_0019
                                   1492 	.globl _ak820_outline_0023
                                   1493 	.globl _ak820_outline_0030
                                   1494 	.globl _ak820_outline_0044
                                   1495 	.globl _ak820_outline_0047
                                   1496 	.globl _ak820_outline_0052
                                   1497 	.globl _ak820_outline_0056
                                   1498 	.globl _ak820_outline_0059
                                   1499 	.globl _ak820_outline_0061
                                   1500 	.globl _ak820_outline_0065
                                   1501 	.globl _ak820_outline_0076
                                   1502 	.globl _ak820_outline_0079
                                   1503 	.globl _ak820_outline_0091
                                   1504 	.globl _ak820_outline_0095
                                   1505 	.globl _ak820_outline_0101
                                   1506 	.globl _ak820_outline_0104
                                   1507 	.globl _ak820_outline_0105
                                   1508 	.globl _ak820_outline_0114
                                   1509 	.globl _ak820_outline_0122
                                   1510 	.globl _ak820_outline_0123
                                   1511 	.globl _ak820_outline_0133
                                   1512 	.globl _ak820_outline_0151
                                   1513 	.globl _ak820_outline_0154
                                   1514 	.globl _ak820_outline_0188
                                   1515 
                                   1516 	.area CSEG (CODE)
                                   1517 ; function ak820_outline_0012
      004E6A                       1518 _ak820_outline_0012:
      004E6A 2E               [12] 1519 	add	a,r6
      004E6B FC               [12] 1520 	mov	r4,a
      004E6C E4               [12] 1521 	clr	a
      004E6D 3F               [12] 1522 	addc	a,r7
      004E6E FD               [12] 1523 	mov	r5,a
      004E6F 8C 82            [24] 1524 	mov	dpl,r4
      004E71 8D 83            [24] 1525 	mov	dph,r5
      004E73 E0               [24] 1526 	movx	a,@dptr
      004E74 22               [24] 1527 	ret
                                   1528 
                                   1529 	.area CSEG (CODE)
                                   1530 ; function ak820_outline_0013
      004E75                       1531 _ak820_outline_0013:
      004E75 2E               [12] 1532 	add	a,r6
      004E76 FB               [12] 1533 	mov	r3,a
      004E77 E4               [12] 1534 	clr	a
      004E78 3F               [12] 1535 	addc	a,r7
      004E79 FC               [12] 1536 	mov	r4,a
      004E7A 8B 82            [24] 1537 	mov	dpl,r3
      004E7C 8C 83            [24] 1538 	mov	dph,r4
      004E7E E0               [24] 1539 	movx	a,@dptr
      004E7F 22               [24] 1540 	ret
                                   1541 
                                   1542 	.area CSEG (CODE)
                                   1543 ; function ak820_outline_0019
      004E80                       1544 _ak820_outline_0019:
      004E80 EF               [12] 1545 	mov	a,r7
      004E81 24 11            [12] 1546 	add	a,#_source_state
      004E83 FD               [12] 1547 	mov	r5,a
      004E84 E4               [12] 1548 	clr	a
      004E85 34 06            [12] 1549 	addc	a,#(_source_state>>8)
      004E87 FE               [12] 1550 	mov	r6,a
      004E88 8D 82            [24] 1551 	mov	dpl,r5
      004E8A 8E 83            [24] 1552 	mov	dph,r6
      004E8C E0               [24] 1553 	movx	a,@dptr
      004E8D FC               [12] 1554 	mov	r4,a
      004E8E 22               [24] 1555 	ret
                                   1556 
                                   1557 	.area CSEG (CODE)
                                   1558 ; function ak820_outline_0023
      004E8F                       1559 _ak820_outline_0023:
      004E8F 90 0D E8         [24] 1560 	mov	dptr,#___memcpy_PARM_2
      004E92 EC               [12] 1561 	mov	a,r4
      004E93 F0               [24] 1562 	movx	@dptr,a
      004E94 ED               [12] 1563 	mov	a,r5
      004E95 A3               [24] 1564 	inc	dptr
      004E96 F0               [24] 1565 	movx	@dptr,a
      004E97 E4               [12] 1566 	clr	a
      004E98 A3               [24] 1567 	inc	dptr
      004E99 F0               [24] 1568 	movx	@dptr,a
      004E9A 90 0D EB         [24] 1569 	mov	dptr,#___memcpy_PARM_3
      004E9D 74 02            [12] 1570 	mov	a,#0x02
      004E9F F0               [24] 1571 	movx	@dptr,a
      004EA0 E4               [12] 1572 	clr	a
      004EA1 A3               [24] 1573 	inc	dptr
      004EA2 F0               [24] 1574 	movx	@dptr,a
      004EA3 90 06 97         [24] 1575 	mov	dptr,#_ak820_tapping_source_PARM_1
      004EA6 F5 F0            [12] 1576 	mov	b,a
      004EA8 22               [24] 1577 	ret
                                   1578 
                                   1579 	.area CSEG (CODE)
                                   1580 ; function ak820_outline_0044
      004EA9                       1581 _ak820_outline_0044:
      004EA9 74 01            [12] 1582 	mov	a,#0x01
      004EAB F0               [24] 1583 	movx	@dptr,a
      004EAC 8E 82            [24] 1584 	mov	dpl,r6
      004EAE 8F 83            [24] 1585 	mov	dph,r7
      004EB0 22               [24] 1586 	ret
                                   1587 
                                   1588 	.area CSEG (CODE)
                                   1589 ; function ak820_outline_0047
      004EB1                       1590 _ak820_outline_0047:
      004EB1 2E               [12] 1591 	add	a,r6
      004EB2 FA               [12] 1592 	mov	r2,a
      004EB3 E4               [12] 1593 	clr	a
      004EB4 3F               [12] 1594 	addc	a,r7
      004EB5 FB               [12] 1595 	mov	r3,a
      004EB6 8A 82            [24] 1596 	mov	dpl,r2
      004EB8 8B 83            [24] 1597 	mov	dph,r3
      004EBA E0               [24] 1598 	movx	a,@dptr
      004EBB 22               [24] 1599 	ret
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0056
      004EBC                       1603 _ak820_outline_0056:
      004EBC FC               [12] 1604 	mov	r4,a
      004EBD 8B 82            [24] 1605 	mov	dpl,r3
      004EBF 8C 83            [24] 1606 	mov	dph,r4
      004EC1 E0               [24] 1607 	movx	a,@dptr
      004EC2 FA               [12] 1608 	mov	r2,a
      004EC3 22               [24] 1609 	ret
                                   1610 
                                   1611 	.area CSEG (CODE)
                                   1612 ; function ak820_outline_0059
      004EC4                       1613 _ak820_outline_0059:
      004EC4 EE               [12] 1614 	mov	a,r6
      004EC5 F0               [24] 1615 	movx	@dptr,a
      004EC6 EF               [12] 1616 	mov	a,r7
      004EC7 A3               [24] 1617 	inc	dptr
      004EC8 F0               [24] 1618 	movx	@dptr,a
      004EC9 22               [24] 1619 	ret
                                   1620 
                                   1621 	.area CSEG (CODE)
                                   1622 ; function ak820_outline_0076
      004ECA                       1623 _ak820_outline_0076:
      004ECA 8D 82            [24] 1624 	mov	dpl,r5
      004ECC 8E 83            [24] 1625 	mov	dph,r6
      004ECE E0               [24] 1626 	movx	a,@dptr
      004ECF FC               [12] 1627 	mov	r4,a
      004ED0 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0079
      004ED1                       1632 _ak820_outline_0079:
      004ED1 24 11            [12] 1633 	add	a,#_source_state
      004ED3 FC               [12] 1634 	mov	r4,a
      004ED4 E4               [12] 1635 	clr	a
      004ED5 34 06            [12] 1636 	addc	a,#(_source_state>>8)
      004ED7 FD               [12] 1637 	mov	r5,a
      004ED8 8C 82            [24] 1638 	mov	dpl,r4
      004EDA 8D 83            [24] 1639 	mov	dph,r5
      004EDC E0               [24] 1640 	movx	a,@dptr
      004EDD FB               [12] 1641 	mov	r3,a
      004EDE 22               [24] 1642 	ret
                                   1643 
                                   1644 	.area CSEG (CODE)
                                   1645 ; function ak820_outline_0151
      004EDF                       1646 _ak820_outline_0151:
      004EDF 90 0D F9         [24] 1647 	mov	dptr,#_pending
      004EE2 74 FF            [12] 1648 	mov	a,#0xff
      004EE4 F0               [24] 1649 	movx	@dptr,a
      004EE5 22               [24] 1650 	ret
