                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_dynamic_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_keyboard_report_pending
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_key
                                     14 	.globl _add_owned_key
                                     15 	.globl _del_owned_mods
                                     16 	.globl _add_owned_mods
                                     17 	.globl _get_weak_mods
                                     18 	.globl _get_mods
                                     19 	.globl _send_keyboard_report
                                     20 	.globl _timer_read
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_dynamic_macro_observe_PARM_2
                                    265 	.globl _ak820_dynamic_macro_process_PARM_2
                                    266 	.globl _ak820_dynamic_macro_source
                                    267 	.globl _ak820_dynamic_macro_cancel
                                    268 	.globl _ak820_dynamic_macro_process
                                    269 	.globl _ak820_dynamic_macro_observe
                                    270 	.globl _ak820_dynamic_macro_task
                                    271 ;--------------------------------------------------------
                                    272 ; special function registers
                                    273 ;--------------------------------------------------------
                                    274 	.area RSEG    (ABS,DATA)
      000000                        275 	.org 0x0000
                           0000D0   276 _PSW	=	0x00d0
                           0000E0   277 _ACC	=	0x00e0
                           0000F0   278 _B	=	0x00f0
                           0000FD   279 _A_INV	=	0x00fd
                           000081   280 _SP	=	0x0081
                           000082   281 _DPL	=	0x0082
                           000083   282 _DPH	=	0x0083
                           0000A1   283 _SAFE_MOD	=	0x00a1
                           0000B1   284 _GLOBAL_CFG	=	0x00b1
                           000087   285 _PCON	=	0x0087
                           0000BA   286 _POWER_CFG	=	0x00ba
                           0000B9   287 _CLOCK_CFG	=	0x00b9
                           0000A9   288 _WAKE_CTRL	=	0x00a9
                           0000FE   289 _RESET_KEEP	=	0x00fe
                           0000FF   290 _WDOG_COUNT	=	0x00ff
                           0000A8   291 _IE	=	0x00a8
                           0000B8   292 _IP	=	0x00b8
                           0000E8   293 _IE_EX	=	0x00e8
                           0000E9   294 _IP_EX	=	0x00e9
                           0000B2   295 _GPIO_IE	=	0x00b2
                           008584   296 _ROM_ADDR	=	0x8584
                           000084   297 _ROM_ADDR_L	=	0x0084
                           000085   298 _ROM_ADDR_H	=	0x0085
                           008F8E   299 _ROM_DATA_HI	=	0x8f8e
                           00008E   300 _ROM_DATA_HL	=	0x008e
                           00008F   301 _ROM_DATA_HH	=	0x008f
                           000086   302 _ROM_CTRL	=	0x0086
                           000080   303 _P0	=	0x0080
                           0000C4   304 _P0_MOD_OC	=	0x00c4
                           0000C5   305 _P0_DIR_PU	=	0x00c5
                           000090   306 _P1	=	0x0090
                           000092   307 _P1_MOD_OC	=	0x0092
                           000093   308 _P1_DIR_PU	=	0x0093
                           0000A0   309 _P2	=	0x00a0
                           000094   310 _P2_MOD_OC	=	0x0094
                           000095   311 _P2_DIR_PU	=	0x0095
                           0000B0   312 _P3	=	0x00b0
                           000096   313 _P3_MOD_OC	=	0x0096
                           000097   314 _P3_DIR_PU	=	0x0097
                           0000C0   315 _P4	=	0x00c0
                           0000C2   316 _P4_MOD_OC	=	0x00c2
                           0000C3   317 _P4_DIR_PU	=	0x00c3
                           0000C1   318 _P4_LED_KEY	=	0x00c1
                           0000AA   319 _P5_IN	=	0x00aa
                           0000AB   320 _P5_OUT_PU	=	0x00ab
                           0000AC   321 _P5_DIR	=	0x00ac
                           0000AD   322 _P6_IN	=	0x00ad
                           0000AE   323 _P6_OUT_PU	=	0x00ae
                           0000AF   324 _P6_DIR	=	0x00af
                           0000F1   325 _P7	=	0x00f1
                           0000A2   326 _XBUS_AUX	=	0x00a2
                           000088   327 _TCON	=	0x0088
                           000089   328 _TMOD	=	0x0089
                           00008A   329 _TL0	=	0x008a
                           00008B   330 _TL1	=	0x008b
                           00008C   331 _TH0	=	0x008c
                           00008D   332 _TH1	=	0x008d
                           000098   333 _SCON	=	0x0098
                           000099   334 _SBUF	=	0x0099
                           0000C8   335 _T2CON	=	0x00c8
                           0000C9   336 _T2MOD	=	0x00c9
                           00CBCA   337 _RCAP2	=	0xcbca
                           0000CA   338 _RCAP2L	=	0x00ca
                           0000CB   339 _RCAP2H	=	0x00cb
                           00CDCC   340 _T2COUNT	=	0xcdcc
                           0000CC   341 _TL2	=	0x00cc
                           0000CD   342 _TH2	=	0x00cd
                           00CFCE   343 _T2CAP1	=	0xcfce
                           0000CE   344 _T2CAP1L	=	0x00ce
                           0000CF   345 _T2CAP1H	=	0x00cf
                           0000F8   346 _SPI0_STAT	=	0x00f8
                           0000F9   347 _SPI0_DATA	=	0x00f9
                           0000FA   348 _SPI0_CTRL	=	0x00fa
                           0000FB   349 _SPI0_CK_SE	=	0x00fb
                           0000FC   350 _SPI0_SETUP	=	0x00fc
                           0000BC   351 _SCON1	=	0x00bc
                           0000BD   352 _SBUF1	=	0x00bd
                           0000BE   353 _SBAUD1	=	0x00be
                           0000BF   354 _SIF1	=	0x00bf
                           0000B4   355 _SPI1_STAT	=	0x00b4
                           0000B5   356 _SPI1_DATA	=	0x00b5
                           0000B6   357 _SPI1_CTRL	=	0x00b6
                           0000B7   358 _SPI1_CK_SE	=	0x00b7
                           0000F3   359 _ADC_CTRL	=	0x00f3
                           00F5F4   360 _ADC_DAT	=	0xf5f4
                           0000F4   361 _ADC_DAT_L	=	0x00f4
                           0000F5   362 _ADC_DAT_H	=	0x00f5
                           0000F6   363 _ADC_CHAN	=	0x00f6
                           0000A6   364 _LED_COMMON	=	0x00a6
                           0000A7   365 _LED_PWM_OE	=	0x00a7
                           00C7C6   366 _LED_DMA	=	0xc7c6
                           0000C6   367 _LED_DMA_L	=	0x00c6
                           0000C7   368 _LED_DMA_H	=	0x00c7
                           0000F7   369 _LED_STATUS	=	0x00f7
                           0000B3   370 _I2CX_INT	=	0x00b3
                           0000BB   371 _I2CS_INT_ST	=	0x00bb
                                    372 ;--------------------------------------------------------
                                    373 ; special function bits
                                    374 ;--------------------------------------------------------
                                    375 	.area RSEG    (ABS,DATA)
      000000                        376 	.org 0x0000
                           0000D7   377 _CY	=	0x00d7
                           0000D6   378 _AC	=	0x00d6
                           0000D5   379 _F0	=	0x00d5
                           0000D4   380 _RS1	=	0x00d4
                           0000D3   381 _RS0	=	0x00d3
                           0000D2   382 _OV	=	0x00d2
                           0000D1   383 _F1	=	0x00d1
                           0000D0   384 _P	=	0x00d0
                           0000AF   385 _EA	=	0x00af
                           0000AE   386 _E_DIS	=	0x00ae
                           0000AD   387 _ET2	=	0x00ad
                           0000AC   388 _ES	=	0x00ac
                           0000AB   389 _ET1	=	0x00ab
                           0000AA   390 _EX1	=	0x00aa
                           0000A9   391 _ET0	=	0x00a9
                           0000A8   392 _EX0	=	0x00a8
                           0000BF   393 _PH_FLAG	=	0x00bf
                           0000BE   394 _PL_FLAG	=	0x00be
                           0000BD   395 _PT2	=	0x00bd
                           0000BC   396 _PS	=	0x00bc
                           0000BB   397 _PT1	=	0x00bb
                           0000BA   398 _PX1	=	0x00ba
                           0000B9   399 _PT0	=	0x00b9
                           0000B8   400 _PX0	=	0x00b8
                           0000EF   401 _IE_WDOG	=	0x00ef
                           0000EE   402 _IE_GPIO	=	0x00ee
                           0000ED   403 _IE_PWM_I2C	=	0x00ed
                           0000EC   404 _IE_UART1	=	0x00ec
                           0000EB   405 _IE_ADC	=	0x00eb
                           0000E9   406 _IE_USB	=	0x00e9
                           0000E8   407 _IE_SPI0	=	0x00e8
                           000087   408 _P0_7	=	0x0087
                           000086   409 _P0_6	=	0x0086
                           000085   410 _P0_5	=	0x0085
                           000084   411 _P0_4	=	0x0084
                           000083   412 _P0_3	=	0x0083
                           000082   413 _P0_2	=	0x0082
                           000081   414 _P0_1	=	0x0081
                           000080   415 _P0_0	=	0x0080
                           000081   416 _SDA0	=	0x0081
                           000080   417 _SCL0	=	0x0080
                           000083   418 _TXD_	=	0x0083
                           000082   419 _RXD_	=	0x0082
                           000085   420 _AIN13	=	0x0085
                           000084   421 _AIN12	=	0x0084
                           000083   422 _AIN11	=	0x0083
                           000082   423 _AIN10	=	0x0082
                           000081   424 _AIN9	=	0x0081
                           000080   425 _AIN8	=	0x0080
                           000097   426 _P1_7	=	0x0097
                           000096   427 _P1_6	=	0x0096
                           000095   428 _P1_5	=	0x0095
                           000094   429 _P1_4	=	0x0094
                           000093   430 _P1_3	=	0x0093
                           000092   431 _P1_2	=	0x0092
                           000091   432 _P1_1	=	0x0091
                           000090   433 _P1_0	=	0x0090
                           000097   434 _TXD1_	=	0x0097
                           000096   435 _RXD1_	=	0x0096
                           000097   436 _SCK	=	0x0097
                           000096   437 _MISO	=	0x0096
                           000095   438 _MOSI	=	0x0095
                           000094   439 _SCS	=	0x0094
                           000092   440 _INT0_	=	0x0092
                           000091   441 _T2EX	=	0x0091
                           000091   442 _CAP2	=	0x0091
                           000090   443 _T2	=	0x0090
                           000090   444 _CAP1	=	0x0090
                           000097   445 _AIN7	=	0x0097
                           000096   446 _AIN6	=	0x0096
                           000095   447 _AIN5	=	0x0095
                           000094   448 _AIN4	=	0x0094
                           000093   449 _AIN3	=	0x0093
                           000092   450 _AIN2	=	0x0092
                           000091   451 _AIN1	=	0x0091
                           000090   452 _AIN0	=	0x0090
                           0000A7   453 _P2_7	=	0x00a7
                           0000A6   454 _P2_6	=	0x00a6
                           0000A5   455 _P2_5	=	0x00a5
                           0000A4   456 _P2_4	=	0x00a4
                           0000A3   457 _P2_3	=	0x00a3
                           0000A2   458 _P2_2	=	0x00a2
                           0000A1   459 _P2_1	=	0x00a1
                           0000A0   460 _P2_0	=	0x00a0
                           0000A7   461 _TXD1	=	0x00a7
                           0000A6   462 _RXD1	=	0x00a6
                           0000A5   463 _T2EX_	=	0x00a5
                           0000A5   464 _CAP2_	=	0x00a5
                           0000A4   465 _T2_	=	0x00a4
                           0000A4   466 _CAP1_	=	0x00a4
                           0000B7   467 _P3_7	=	0x00b7
                           0000B6   468 _P3_6	=	0x00b6
                           0000B5   469 _P3_5	=	0x00b5
                           0000B4   470 _P3_4	=	0x00b4
                           0000B3   471 _P3_3	=	0x00b3
                           0000B2   472 _P3_2	=	0x00b2
                           0000B1   473 _P3_1	=	0x00b1
                           0000B0   474 _P3_0	=	0x00b0
                           0000B7   475 _SCK1	=	0x00b7
                           0000B6   476 _MISO1	=	0x00b6
                           0000B5   477 _MOSI1	=	0x00b5
                           0000B5   478 _T1	=	0x00b5
                           0000B4   479 _T0	=	0x00b4
                           0000B3   480 _INT1	=	0x00b3
                           0000B2   481 _INT0	=	0x00b2
                           0000B1   482 _TXD	=	0x00b1
                           0000B0   483 _RXD	=	0x00b0
                           0000C6   484 _P4_6	=	0x00c6
                           0000C5   485 _P4_5	=	0x00c5
                           0000C4   486 _P4_4	=	0x00c4
                           0000C3   487 _P4_3	=	0x00c3
                           0000C2   488 _P4_2	=	0x00c2
                           0000C1   489 _P4_1	=	0x00c1
                           0000C0   490 _P4_0	=	0x00c0
                           00008F   491 _TF1	=	0x008f
                           00008E   492 _TR1	=	0x008e
                           00008D   493 _TF0	=	0x008d
                           00008C   494 _TR0	=	0x008c
                           00008B   495 _IE1	=	0x008b
                           00008A   496 _IT1	=	0x008a
                           000089   497 _IE0	=	0x0089
                           000088   498 _IT0	=	0x0088
                           00009F   499 _SM0	=	0x009f
                           00009E   500 _SM1	=	0x009e
                           00009D   501 _SM2	=	0x009d
                           00009C   502 _REN	=	0x009c
                           00009B   503 _TB8	=	0x009b
                           00009A   504 _RB8	=	0x009a
                           000099   505 _TI	=	0x0099
                           000098   506 _RI	=	0x0098
                           0000CF   507 _TF2	=	0x00cf
                           0000CF   508 _CAP1F	=	0x00cf
                           0000CE   509 _EXF2	=	0x00ce
                           0000CD   510 _RCLK	=	0x00cd
                           0000CC   511 _TCLK	=	0x00cc
                           0000CB   512 _EXEN2	=	0x00cb
                           0000CA   513 _TR2	=	0x00ca
                           0000C9   514 _C_T2	=	0x00c9
                           0000C8   515 _CP_RL2	=	0x00c8
                           0000FF   516 _S0_FST_ACT	=	0x00ff
                           0000FE   517 _S0_IF_OV	=	0x00fe
                           0000FD   518 _S0_IF_FIRST	=	0x00fd
                           0000FC   519 _S0_IF_BYTE	=	0x00fc
                           0000FB   520 _S0_FREE	=	0x00fb
                           0000FA   521 _S0_T_FIFO	=	0x00fa
                           0000F8   522 _S0_R_FIFO	=	0x00f8
                           0000F7   523 _ADC_START	=	0x00f7
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable register banks
                                    526 ;--------------------------------------------------------
                                    527 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        528 	.ds 8
                                    529 ;--------------------------------------------------------
                                    530 ; internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area DSEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; overlayable items in internal ram
                                    535 ;--------------------------------------------------------
                                    536 	.area	OSEG    (OVR,DATA)
      000055                        537 _dm_finish_sloc0_1_0:
      000055                        538 	.ds 2
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
                                    552 ;--------------------------------------------------------
                                    553 ; paged external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area PSEG    (PAG,XDATA)
                                    556 ;--------------------------------------------------------
                                    557 ; uninitialized external ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area XSEG    (XDATA)
      000460                        560 _dm_taps:
      000460                        561 	.ds 64
      0004A0                        562 _dm_lengths:
      0004A0                        563 	.ds 2
      0004A2                        564 _dm_record:
      0004A2                        565 	.ds 1
      0004A3                        566 _dm_play:
      0004A3                        567 	.ds 1
      0004A4                        568 _dm_index:
      0004A4                        569 	.ds 1
      0004A5                        570 _dm_down:
      0004A5                        571 	.ds 1
      0004A6                        572 _dm_mods:
      0004A6                        573 	.ds 1
      0004A7                        574 _dm_time:
      0004A7                        575 	.ds 2
      0004A9                        576 _ak820_dynamic_macro_source::
      0004A9                        577 	.ds 1
      0004AA                        578 _ak820_dynamic_macro_process_PARM_2:
      0004AA                        579 	.ds 1
      0004AB                        580 _ak820_dynamic_macro_process_code_10000_602:
      0004AB                        581 	.ds 2
      0004AD                        582 _ak820_dynamic_macro_observe_PARM_2:
      0004AD                        583 	.ds 1
      0004AE                        584 _ak820_dynamic_macro_observe_code_10000_611:
      0004AE                        585 	.ds 1
      0004AF                        586 _ak820_dynamic_macro_observe_slot_10001_614:
      0004AF                        587 	.ds 1
      0004B0                        588 _ak820_dynamic_macro_observe_base_10001_614:
      0004B0                        589 	.ds 1
      0004B1                        590 _ak820_dynamic_macro_observe_i_30001_616:
      0004B1                        591 	.ds 1
      0004B2                        592 _ak820_dynamic_macro_task_now_10000_623:
      0004B2                        593 	.ds 2
      0004B4                        594 _ak820_dynamic_macro_task_i_40000_630:
      0004B4                        595 	.ds 1
      0004B5                        596 _ak820_dynamic_macro_task_code_40000_630:
      0004B5                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT0 (CODE)
                                    608 	.area GSINIT1 (CODE)
                                    609 	.area GSINIT2 (CODE)
                                    610 	.area GSINIT3 (CODE)
                                    611 	.area GSINIT4 (CODE)
                                    612 	.area GSINIT5 (CODE)
                                    613 	.area GSINIT  (CODE)
                                    614 	.area GSFINAL (CODE)
                                    615 	.area CSEG    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; global & static initialisations
                                    618 ;--------------------------------------------------------
                                    619 	.area HOME    (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; Home
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area HOME    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; code
                                    630 ;--------------------------------------------------------
                                    631 	.area CSEG    (CODE)
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    634 ;------------------------------------------------------------
                                    635 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    638 ;	-----------------------------------------
                           000007   639 	ar7 = 0x07
                           000006   640 	ar6 = 0x06
                           000005   641 	ar5 = 0x05
                           000004   642 	ar4 = 0x04
                           000003   643 	ar3 = 0x03
                           000002   644 	ar2 = 0x02
                           000001   645 	ar1 = 0x01
                           000000   646 	ar0 = 0x00
                                    647 ;	 function dm_finish
                                    648 ;	-----------------------------------------
      00388C                        649 _dm_finish:
                                    650 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:17: if (dm_record) {
      00388C 90 04 A2         [24]  651 	mov	dptr,#_dm_record
      00388F E0               [24]  652 	movx	a,@dptr
      003890 FF               [12]  653 	mov	r7,a
      003891 E0               [24]  654 	movx	a,@dptr
      003892 70 01            [24]  655 	jnz	00140$
      003894 22               [24]  656 	ret
      003895                        657 00140$:
                                    658 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:18: uint8_t slot = dm_record - 1, base = slot * 16, out = 0;
      003895 1F               [12]  659 	dec	r7
      003896 EF               [12]  660 	mov	a,r7
      003897 C4               [12]  661 	swap	a
      003898 54 F0            [12]  662 	anl	a,#0xf0
      00389A FE               [12]  663 	mov	r6,a
                                    664 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      00389B EF               [12]  665 	mov	a,r7
      00389C 24 A0            [12]  666 	add	a, #_dm_lengths
      00389E FD               [12]  667 	mov	r5,a
      00389F E4               [12]  668 	clr	a
      0038A0 34 04            [12]  669 	addc	a, #(_dm_lengths >> 8)
      0038A2 FF               [12]  670 	mov	r7,a
      0038A3 7C 00            [12]  671 	mov	r4,#0x00
      0038A5 7B 00            [12]  672 	mov	r3,#0x00
      0038A7                        673 00107$:
      0038A7 8D 82            [24]  674 	mov	dpl,r5
      0038A9 8F 83            [24]  675 	mov	dph,r7
      0038AB E0               [24]  676 	movx	a,@dptr
      0038AC FA               [12]  677 	mov	r2,a
      0038AD C3               [12]  678 	clr	c
      0038AE EB               [12]  679 	mov	a,r3
      0038AF 9A               [12]  680 	subb	a,r2
      0038B0 50 5C            [24]  681 	jnc	00103$
                                    682 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:20: if (!(dm_taps[base + i].code & 0x80)) {
      0038B2 EB               [12]  683 	mov	a,r3
      0038B3 2E               [12]  684 	add	a, r6
      0038B4 75 F0 02         [24]  685 	mov	b,#0x02
      0038B7 A4               [48]  686 	mul	ab
      0038B8 24 60            [12]  687 	add	a, #_dm_taps
      0038BA F5 82            [12]  688 	mov	dpl,a
      0038BC 74 04            [12]  689 	mov	a,#(_dm_taps >> 8)
      0038BE 35 F0            [12]  690 	addc	a, b
      0038C0 F5 83            [12]  691 	mov	dph,a
      0038C2 E0               [24]  692 	movx	a,@dptr
      0038C3 20 E7 45         [24]  693 	jb	acc.7,00108$
                                    694 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:24: dm_taps[base + out].code = dm_taps[base + i].code;
      0038C6 C0 05            [24]  695 	push	ar5
      0038C8 C0 07            [24]  696 	push	ar7
      0038CA EC               [12]  697 	mov	a,r4
      0038CB 2E               [12]  698 	add	a, r6
      0038CC 75 F0 02         [24]  699 	mov	b,#0x02
      0038CF A4               [48]  700 	mul	ab
      0038D0 24 60            [12]  701 	add	a, #_dm_taps
      0038D2 F9               [12]  702 	mov	r1,a
      0038D3 74 04            [12]  703 	mov	a,#(_dm_taps >> 8)
      0038D5 35 F0            [12]  704 	addc	a, b
      0038D7 FA               [12]  705 	mov	r2,a
      0038D8 89 55            [24]  706 	mov	_dm_finish_sloc0_1_0,r1
      0038DA 8A 56            [24]  707 	mov	(_dm_finish_sloc0_1_0 + 1),r2
      0038DC EB               [12]  708 	mov	a,r3
      0038DD 2E               [12]  709 	add	a, r6
      0038DE 75 F0 02         [24]  710 	mov	b,#0x02
      0038E1 A4               [48]  711 	mul	ab
      0038E2 24 60            [12]  712 	add	a, #_dm_taps
      0038E4 FD               [12]  713 	mov	r5,a
      0038E5 74 04            [12]  714 	mov	a,#(_dm_taps >> 8)
      0038E7 35 F0            [12]  715 	addc	a, b
      0038E9 FF               [12]  716 	mov	r7,a
      0038EA 8D 82            [24]  717 	mov	dpl,r5
      0038EC 8F 83            [24]  718 	mov	dph,r7
      0038EE E0               [24]  719 	movx	a,@dptr
      0038EF 85 55 82         [24]  720 	mov	dpl,_dm_finish_sloc0_1_0
      0038F2 85 56 83         [24]  721 	mov	dph,(_dm_finish_sloc0_1_0 + 1)
      0038F5 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:25: dm_taps[base + out].mods = dm_taps[base + i].mods;
      0038F6 09               [12]  724 	inc	r1
      0038F7 B9 00 01         [24]  725 	cjne	r1,#0x00,00143$
      0038FA 0A               [12]  726 	inc	r2
      0038FB                        727 00143$:
      0038FB 8D 82            [24]  728 	mov	dpl,r5
      0038FD 8F 83            [24]  729 	mov	dph,r7
      0038FF A3               [24]  730 	inc	dptr
      003900 E0               [24]  731 	movx	a,@dptr
      003901 89 82            [24]  732 	mov	dpl,r1
      003903 8A 83            [24]  733 	mov	dph,r2
      003905 F0               [24]  734 	movx	@dptr,a
                                    735 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: ++out;
      003906 0C               [12]  736 	inc	r4
                                    737 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_record = 0;
      003907 D0 07            [24]  738 	pop	ar7
      003909 D0 05            [24]  739 	pop	ar5
                                    740 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: ++out;
      00390B                        741 00108$:
                                    742 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      00390B 0B               [12]  743 	inc	r3
      00390C 80 99            [24]  744 	sjmp	00107$
      00390E                        745 00103$:
                                    746 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:29: dm_lengths[slot] = out;
      00390E 8D 82            [24]  747 	mov	dpl,r5
      003910 8F 83            [24]  748 	mov	dph,r7
      003912 EC               [12]  749 	mov	a,r4
      003913 F0               [24]  750 	movx	@dptr,a
                                    751 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_record = 0;
      003914 90 04 A2         [24]  752 	mov	dptr,#_dm_record
      003917 E4               [12]  753 	clr	a
      003918 F0               [24]  754 	movx	@dptr,a
                                    755 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:32: }
      003919 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'ak820_dynamic_macro_cancel'
                                    759 ;------------------------------------------------------------
                                    760 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:33: void ak820_dynamic_macro_cancel(void) {
                                    761 ;	-----------------------------------------
                                    762 ;	 function ak820_dynamic_macro_cancel
                                    763 ;	-----------------------------------------
      00391A                        764 _ak820_dynamic_macro_cancel:
                                    765 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:34: dm_finish();
      00391A 12 38 8C         [24]  766 	lcall	_dm_finish
                                    767 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:37: dm_play = dm_down = 0;
      00391D 90 04 A5         [24]  768 	mov	dptr,#_dm_down
      003920 E4               [12]  769 	clr	a
      003921 F0               [24]  770 	movx	@dptr,a
      003922 90 04 A3         [24]  771 	mov	dptr,#_dm_play
      003925 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:38: ak820_dynamic_macro_source = false;
      003926 90 04 A9         [24]  774 	mov	dptr,#_ak820_dynamic_macro_source
      003929 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:39: }
      00392A 22               [24]  777 	ret
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'ak820_dynamic_macro_process'
                                    780 ;------------------------------------------------------------
                                    781 ;pressed       Allocated with name '_ak820_dynamic_macro_process_PARM_2'
                                    782 ;code          Allocated with name '_ak820_dynamic_macro_process_code_10000_602'
                                    783 ;------------------------------------------------------------
                                    784 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:40: bool ak820_dynamic_macro_process(uint16_t code, bool pressed) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function ak820_dynamic_macro_process
                                    787 ;	-----------------------------------------
      00392B                        788 _ak820_dynamic_macro_process:
      00392B AF 83            [24]  789 	mov	r7,dph
      00392D E5 82            [12]  790 	mov	a,dpl
      00392F 90 04 AB         [24]  791 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003932 F0               [24]  792 	movx	@dptr,a
      003933 EF               [12]  793 	mov	a,r7
      003934 A3               [24]  794 	inc	dptr
      003935 F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:41: if (code < QK_DYNAMIC_MACRO_RECORD_START_1 || code > QK_DYNAMIC_MACRO_PLAY_2) return true;
      003936 90 04 AB         [24]  797 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003939 E0               [24]  798 	movx	a,@dptr
      00393A FE               [12]  799 	mov	r6,a
      00393B A3               [24]  800 	inc	dptr
      00393C E0               [24]  801 	movx	a,@dptr
      00393D FF               [12]  802 	mov	r7,a
      00393E 8E 04            [24]  803 	mov	ar4,r6
      003940 8F 05            [24]  804 	mov	ar5,r7
      003942 C3               [12]  805 	clr	c
      003943 EC               [12]  806 	mov	a,r4
      003944 94 53            [12]  807 	subb	a,#0x53
      003946 ED               [12]  808 	mov	a,r5
      003947 94 7C            [12]  809 	subb	a,#0x7c
      003949 40 08            [24]  810 	jc	00101$
      00394B 74 57            [12]  811 	mov	a,#0x57
      00394D 9C               [12]  812 	subb	a,r4
      00394E 74 7C            [12]  813 	mov	a,#0x7c
      003950 9D               [12]  814 	subb	a,r5
      003951 50 04            [24]  815 	jnc	00102$
                                    816 ;	free result
      003953                        817 00101$:
      003953 75 82 01         [24]  818 	mov	dpl, #0x01
      003956 22               [24]  819 	ret
      003957                        820 00102$:
                                    821 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:42: if (!pressed || get_repeat_key_count()) return false;
      003957 90 04 AA         [24]  822 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      00395A E0               [24]  823 	movx	a,@dptr
      00395B 60 07            [24]  824 	jz	00104$
      00395D 12 A7 C4         [24]  825 	lcall	_get_repeat_key_count
      003960 E5 82            [12]  826 	mov	a, dpl
      003962 60 04            [24]  827 	jz	00105$
      003964                        828 00104$:
      003964 75 82 00         [24]  829 	mov	dpl, #0x00
      003967 22               [24]  830 	ret
      003968                        831 00105$:
                                    832 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:45: if (dm_play) return false;
      003968 90 04 A3         [24]  833 	mov	dptr,#_dm_play
      00396B E0               [24]  834 	movx	a,@dptr
      00396C 60 04            [24]  835 	jz	00108$
      00396E 75 82 00         [24]  836 	mov	dpl, #0x00
      003971 22               [24]  837 	ret
      003972                        838 00108$:
                                    839 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:46: dm_finish();
      003972 C0 07            [24]  840 	push	ar7
      003974 C0 06            [24]  841 	push	ar6
      003976 C0 05            [24]  842 	push	ar5
      003978 C0 04            [24]  843 	push	ar4
      00397A 12 38 8C         [24]  844 	lcall	_dm_finish
      00397D D0 04            [24]  845 	pop	ar4
      00397F D0 05            [24]  846 	pop	ar5
      003981 D0 06            [24]  847 	pop	ar6
      003983 D0 07            [24]  848 	pop	ar7
                                    849 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:47: if (code <= QK_DYNAMIC_MACRO_RECORD_START_2) {
      003985 C3               [12]  850 	clr	c
      003986 74 54            [12]  851 	mov	a,#0x54
      003988 9C               [12]  852 	subb	a,r4
      003989 74 7C            [12]  853 	mov	a,#0x7c
      00398B 9D               [12]  854 	subb	a,r5
      00398C 40 1E            [24]  855 	jc	00112$
                                    856 ;	free result
                                    857 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:48: dm_record = code - QK_DYNAMIC_MACRO_RECORD_START_1 + 1;
      00398E 8E 03            [24]  858 	mov	ar3,r6
      003990 74 AE            [12]  859 	mov	a,#0xae
      003992 2B               [12]  860 	add	a, r3
      003993 FB               [12]  861 	mov	r3,a
      003994 90 04 A2         [24]  862 	mov	dptr,#_dm_record
      003997 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:49: dm_lengths[dm_record - 1] = 0;
      003998 1B               [12]  865 	dec	r3
      003999 EB               [12]  866 	mov	a,r3
      00399A 33               [12]  867 	rlc	a
      00399B 95 E0            [12]  868 	subb	a,acc
      00399D FA               [12]  869 	mov	r2,a
      00399E EB               [12]  870 	mov	a,r3
      00399F 24 A0            [12]  871 	add	a, #_dm_lengths
      0039A1 F5 82            [12]  872 	mov	dpl,a
      0039A3 EA               [12]  873 	mov	a,r2
      0039A4 34 04            [12]  874 	addc	a, #(_dm_lengths >> 8)
      0039A6 F5 83            [12]  875 	mov	dph,a
      0039A8 E4               [12]  876 	clr	a
      0039A9 F0               [24]  877 	movx	@dptr,a
      0039AA 80 29            [24]  878 	sjmp	00113$
      0039AC                        879 00112$:
                                    880 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:50: } else if (code >= QK_DYNAMIC_MACRO_PLAY_1) {
      0039AC C3               [12]  881 	clr	c
      0039AD EC               [12]  882 	mov	a,r4
      0039AE 94 56            [12]  883 	subb	a,#0x56
      0039B0 ED               [12]  884 	mov	a,r5
      0039B1 94 7C            [12]  885 	subb	a,#0x7c
      0039B3 40 20            [24]  886 	jc	00113$
                                    887 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:51: dm_play = code - QK_DYNAMIC_MACRO_PLAY_1 + 1;
      0039B5 90 04 A3         [24]  888 	mov	dptr,#_dm_play
      0039B8 74 AB            [12]  889 	mov	a,#0xab
      0039BA 2E               [12]  890 	add	a, r6
      0039BB F0               [24]  891 	movx	@dptr,a
                                    892 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:52: dm_index = dm_down = 0;
      0039BC 90 04 A5         [24]  893 	mov	dptr,#_dm_down
      0039BF E4               [12]  894 	clr	a
      0039C0 F0               [24]  895 	movx	@dptr,a
      0039C1 90 04 A4         [24]  896 	mov	dptr,#_dm_index
      0039C4 F0               [24]  897 	movx	@dptr,a
                                    898 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:53: dm_time = timer_read();
      0039C5 12 4F 5C         [24]  899 	lcall	_timer_read
      0039C8 E5 82            [12]  900 	mov	a, dpl
      0039CA 85 83 F0         [24]  901 	mov	b, dph
      0039CD 90 04 A7         [24]  902 	mov	dptr,#_dm_time
      0039D0 F0               [24]  903 	movx	@dptr,a
      0039D1 E5 F0            [12]  904 	mov	a,b
      0039D3 A3               [24]  905 	inc	dptr
      0039D4 F0               [24]  906 	movx	@dptr,a
      0039D5                        907 00113$:
                                    908 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:55: return false;
      0039D5 75 82 00         [24]  909 	mov	dpl, #0x00
                                    910 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:56: }
      0039D8 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'ak820_dynamic_macro_observe'
                                    914 ;------------------------------------------------------------
                                    915 ;pressed       Allocated with name '_ak820_dynamic_macro_observe_PARM_2'
                                    916 ;code          Allocated with name '_ak820_dynamic_macro_observe_code_10000_611'
                                    917 ;slot          Allocated with name '_ak820_dynamic_macro_observe_slot_10001_614'
                                    918 ;base          Allocated with name '_ak820_dynamic_macro_observe_base_10001_614'
                                    919 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_30001_616'
                                    920 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_40001_619'
                                    921 ;------------------------------------------------------------
                                    922 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:57: void ak820_dynamic_macro_observe(uint8_t code, bool pressed) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function ak820_dynamic_macro_observe
                                    925 ;	-----------------------------------------
      0039D9                        926 _ak820_dynamic_macro_observe:
      0039D9 E5 82            [12]  927 	mov	a,dpl
      0039DB 90 04 AE         [24]  928 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      0039DE F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:58: if (!dm_record || !ak820_dynamic_macro_source || code < KC_A || code >= 0x80) return;
      0039DF 90 04 A2         [24]  931 	mov	dptr,#_dm_record
      0039E2 E0               [24]  932 	movx	a,@dptr
      0039E3 FF               [12]  933 	mov	r7,a
      0039E4 E0               [24]  934 	movx	a,@dptr
      0039E5 60 15            [24]  935 	jz	00101$
      0039E7 90 04 A9         [24]  936 	mov	dptr,#_ak820_dynamic_macro_source
      0039EA E0               [24]  937 	movx	a,@dptr
      0039EB 60 0F            [24]  938 	jz	00101$
      0039ED 90 04 AE         [24]  939 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      0039F0 E0               [24]  940 	movx	a,@dptr
      0039F1 FE               [12]  941 	mov	r6,a
      0039F2 BE 04 00         [24]  942 	cjne	r6,#0x04,00177$
      0039F5                        943 00177$:
      0039F5 40 05            [24]  944 	jc	00101$
      0039F7 BE 80 00         [24]  945 	cjne	r6,#0x80,00179$
      0039FA                        946 00179$:
      0039FA 40 01            [24]  947 	jc	00102$
      0039FC                        948 00101$:
      0039FC 22               [24]  949 	ret
      0039FD                        950 00102$:
                                    951 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:59: uint8_t slot = dm_record - 1, base = slot * 16;
      0039FD 1F               [12]  952 	dec	r7
      0039FE 90 04 AF         [24]  953 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003A01 EF               [12]  954 	mov	a,r7
      003A02 F0               [24]  955 	movx	@dptr,a
      003A03 EF               [12]  956 	mov	a,r7
      003A04 C4               [12]  957 	swap	a
      003A05 54 F0            [12]  958 	anl	a,#0xf0
      003A07 FD               [12]  959 	mov	r5,a
      003A08 90 04 B0         [24]  960 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003A0B F0               [24]  961 	movx	@dptr,a
                                    962 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:60: if (pressed) {
      003A0C 90 04 AD         [24]  963 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      003A0F E0               [24]  964 	movx	a,@dptr
      003A10 60 67            [24]  965 	jz	00134$
                                    966 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:61: uint8_t i = dm_lengths[slot];
      003A12 EF               [12]  967 	mov	a,r7
      003A13 24 A0            [12]  968 	add	a, #_dm_lengths
      003A15 F5 82            [12]  969 	mov	dpl,a
      003A17 E4               [12]  970 	clr	a
      003A18 34 04            [12]  971 	addc	a, #(_dm_lengths >> 8)
      003A1A F5 83            [12]  972 	mov	dph,a
      003A1C E0               [24]  973 	movx	a,@dptr
      003A1D FC               [12]  974 	mov	r4,a
      003A1E 90 04 B1         [24]  975 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003A21 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:62: if (i == 16) return; /* Full: retain first 16; still accept releases. */
      003A22 BC 10 01         [24]  978 	cjne	r4,#0x10,00107$
      003A25 22               [24]  979 	ret
      003A26                        980 00107$:
                                    981 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: dm_taps[base + i].code = code | 0x80;
      003A26 EC               [12]  982 	mov	a,r4
      003A27 2D               [12]  983 	add	a, r5
      003A28 75 F0 02         [24]  984 	mov	b,#0x02
      003A2B A4               [48]  985 	mul	ab
      003A2C 24 60            [12]  986 	add	a, #_dm_taps
      003A2E F5 82            [12]  987 	mov	dpl,a
      003A30 74 04            [12]  988 	mov	a,#(_dm_taps >> 8)
      003A32 35 F0            [12]  989 	addc	a, b
      003A34 F5 83            [12]  990 	mov	dph,a
      003A36 43 06 80         [24]  991 	orl	ar6,#0x80
      003A39 EE               [12]  992 	mov	a,r6
      003A3A F0               [24]  993 	movx	@dptr,a
                                    994 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:64: dm_taps[base + i].mods = get_mods() | get_weak_mods();
      003A3B 90 04 B1         [24]  995 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003A3E E0               [24]  996 	movx	a,@dptr
      003A3F FE               [12]  997 	mov	r6,a
      003A40 90 04 B0         [24]  998 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003A43 E0               [24]  999 	movx	a,@dptr
      003A44 2E               [12] 1000 	add	a, r6
      003A45 75 F0 02         [24] 1001 	mov	b,#0x02
      003A48 A4               [48] 1002 	mul	ab
      003A49 24 60            [12] 1003 	add	a, #_dm_taps
      003A4B FB               [12] 1004 	mov	r3,a
      003A4C 74 04            [12] 1005 	mov	a,#(_dm_taps >> 8)
      003A4E 35 F0            [12] 1006 	addc	a, b
      003A50 FC               [12] 1007 	mov	r4,a
      003A51 0B               [12] 1008 	inc	r3
      003A52 BB 00 01         [24] 1009 	cjne	r3,#0x00,00184$
      003A55 0C               [12] 1010 	inc	r4
      003A56                       1011 00184$:
      003A56 12 87 66         [24] 1012 	lcall	_get_mods
      003A59 AA 82            [24] 1013 	mov	r2, dpl
      003A5B 12 87 7C         [24] 1014 	lcall	_get_weak_mods
      003A5E E5 82            [12] 1015 	mov	a,dpl
      003A60 42 02            [12] 1016 	orl	ar2,a
      003A62 8B 82            [24] 1017 	mov	dpl,r3
      003A64 8C 83            [24] 1018 	mov	dph,r4
      003A66 EA               [12] 1019 	mov	a,r2
      003A67 F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:65: dm_lengths[slot] = i + 1;
      003A68 90 04 AF         [24] 1022 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003A6B E0               [24] 1023 	movx	a,@dptr
      003A6C 24 A0            [12] 1024 	add	a, #_dm_lengths
      003A6E F5 82            [12] 1025 	mov	dpl,a
      003A70 E4               [12] 1026 	clr	a
      003A71 34 04            [12] 1027 	addc	a, #(_dm_lengths >> 8)
      003A73 F5 83            [12] 1028 	mov	dph,a
      003A75 0E               [12] 1029 	inc	r6
      003A76 EE               [12] 1030 	mov	a,r6
      003A77 F0               [24] 1031 	movx	@dptr,a
                                   1032 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:67: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003A78 22               [24] 1033 	ret
      003A79                       1034 00134$:
      003A79 EF               [12] 1035 	mov	a,r7
      003A7A 24 A0            [12] 1036 	add	a, #_dm_lengths
      003A7C FE               [12] 1037 	mov	r6,a
      003A7D E4               [12] 1038 	clr	a
      003A7E 34 04            [12] 1039 	addc	a, #(_dm_lengths >> 8)
      003A80 FF               [12] 1040 	mov	r7,a
      003A81 7C 00            [12] 1041 	mov	r4,#0x00
      003A83                       1042 00115$:
      003A83 8E 82            [24] 1043 	mov	dpl,r6
      003A85 8F 83            [24] 1044 	mov	dph,r7
      003A87 E0               [24] 1045 	movx	a,@dptr
      003A88 FB               [12] 1046 	mov	r3,a
      003A89 C3               [12] 1047 	clr	c
      003A8A EC               [12] 1048 	mov	a,r4
      003A8B 9B               [12] 1049 	subb	a,r3
      003A8C 50 35            [24] 1050 	jnc	00117$
                                   1051 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:68: if (dm_taps[base + i].code == (uint8_t)(code | 0x80)) {
      003A8E EC               [12] 1052 	mov	a,r4
      003A8F 2D               [12] 1053 	add	a, r5
      003A90 75 F0 02         [24] 1054 	mov	b,#0x02
      003A93 A4               [48] 1055 	mul	ab
      003A94 24 60            [12] 1056 	add	a, #_dm_taps
      003A96 F5 82            [12] 1057 	mov	dpl,a
      003A98 74 04            [12] 1058 	mov	a,#(_dm_taps >> 8)
      003A9A 35 F0            [12] 1059 	addc	a, b
      003A9C F5 83            [12] 1060 	mov	dph,a
      003A9E E0               [24] 1061 	movx	a,@dptr
      003A9F FB               [12] 1062 	mov	r3,a
      003AA0 90 04 AE         [24] 1063 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003AA3 E0               [24] 1064 	movx	a,@dptr
      003AA4 FA               [12] 1065 	mov	r2,a
      003AA5 74 80            [12] 1066 	mov	a,#0x80
      003AA7 4A               [12] 1067 	orl	a,r2
      003AA8 F9               [12] 1068 	mov	r1,a
      003AA9 EB               [12] 1069 	mov	a,r3
      003AAA B5 01 13         [24] 1070 	cjne	a,ar1,00116$
                                   1071 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:69: dm_taps[base + i].code = code;
      003AAD EC               [12] 1072 	mov	a,r4
      003AAE 2D               [12] 1073 	add	a, r5
      003AAF 75 F0 02         [24] 1074 	mov	b,#0x02
      003AB2 A4               [48] 1075 	mul	ab
      003AB3 24 60            [12] 1076 	add	a, #_dm_taps
      003AB5 F5 82            [12] 1077 	mov	dpl,a
      003AB7 74 04            [12] 1078 	mov	a,#(_dm_taps >> 8)
      003AB9 35 F0            [12] 1079 	addc	a, b
      003ABB F5 83            [12] 1080 	mov	dph,a
      003ABD EA               [12] 1081 	mov	a,r2
      003ABE F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:70: break;
      003ABF 22               [24] 1084 	ret
      003AC0                       1085 00116$:
                                   1086 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:67: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003AC0 0C               [12] 1087 	inc	r4
      003AC1 80 C0            [24] 1088 	sjmp	00115$
      003AC3                       1089 00117$:
                                   1090 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:74: }
      003AC3 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'ak820_dynamic_macro_task'
                                   1094 ;------------------------------------------------------------
                                   1095 ;now           Allocated with name '_ak820_dynamic_macro_task_now_10000_623'
                                   1096 ;i             Allocated with name '_ak820_dynamic_macro_task_i_40000_630'
                                   1097 ;code          Allocated with name '_ak820_dynamic_macro_task_code_40000_630'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:75: void ak820_dynamic_macro_task(uint16_t now) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function ak820_dynamic_macro_task
                                   1102 ;	-----------------------------------------
      003AC4                       1103 _ak820_dynamic_macro_task:
      003AC4 AF 83            [24] 1104 	mov	r7,dph
      003AC6 E5 82            [12] 1105 	mov	a,dpl
      003AC8 90 04 B2         [24] 1106 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003ACB F0               [24] 1107 	movx	@dptr,a
      003ACC EF               [12] 1108 	mov	a,r7
      003ACD A3               [24] 1109 	inc	dptr
      003ACE F0               [24] 1110 	movx	@dptr,a
                                   1111 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:76: if (!dm_play || ak820_macro_primitive || ak820_keyboard_report_pending() || (uint16_t)(now - dm_time) < 10) return;
      003ACF 90 04 A3         [24] 1112 	mov	dptr,#_dm_play
      003AD2 E0               [24] 1113 	movx	a,@dptr
      003AD3 60 2D            [24] 1114 	jz	00101$
      003AD5 90 09 F4         [24] 1115 	mov	dptr,#_ak820_macro_primitive
      003AD8 E0               [24] 1116 	movx	a,@dptr
      003AD9 70 27            [24] 1117 	jnz	00101$
      003ADB 12 4F C4         [24] 1118 	lcall	_ak820_keyboard_report_pending
      003ADE E5 82            [12] 1119 	mov	a, dpl
      003AE0 70 20            [24] 1120 	jnz	00101$
      003AE2 90 04 A7         [24] 1121 	mov	dptr,#_dm_time
      003AE5 E0               [24] 1122 	movx	a,@dptr
      003AE6 FE               [12] 1123 	mov	r6,a
      003AE7 A3               [24] 1124 	inc	dptr
      003AE8 E0               [24] 1125 	movx	a,@dptr
      003AE9 FF               [12] 1126 	mov	r7,a
      003AEA 90 04 B2         [24] 1127 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003AED E0               [24] 1128 	movx	a,@dptr
      003AEE FC               [12] 1129 	mov	r4,a
      003AEF A3               [24] 1130 	inc	dptr
      003AF0 E0               [24] 1131 	movx	a,@dptr
      003AF1 FD               [12] 1132 	mov	r5,a
      003AF2 EC               [12] 1133 	mov	a,r4
      003AF3 C3               [12] 1134 	clr	c
      003AF4 9E               [12] 1135 	subb	a,r6
      003AF5 FE               [12] 1136 	mov	r6,a
      003AF6 ED               [12] 1137 	mov	a,r5
      003AF7 9F               [12] 1138 	subb	a,r7
      003AF8 FF               [12] 1139 	mov	r7,a
      003AF9 C3               [12] 1140 	clr	c
      003AFA EE               [12] 1141 	mov	a,r6
      003AFB 94 0A            [12] 1142 	subb	a,#0x0a
      003AFD EF               [12] 1143 	mov	a,r7
      003AFE 94 00            [12] 1144 	subb	a,#0x00
      003B00 50 01            [24] 1145 	jnc	00102$
      003B02                       1146 00101$:
      003B02 22               [24] 1147 	ret
      003B03                       1148 00102$:
                                   1149 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:77: dm_time = now;
      003B03 90 04 A7         [24] 1150 	mov	dptr,#_dm_time
      003B06 EC               [12] 1151 	mov	a,r4
      003B07 F0               [24] 1152 	movx	@dptr,a
      003B08 ED               [12] 1153 	mov	a,r5
      003B09 A3               [24] 1154 	inc	dptr
      003B0A F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:78: if (dm_down) {
      003B0B 90 04 A5         [24] 1157 	mov	dptr,#_dm_down
      003B0E E0               [24] 1158 	movx	a,@dptr
      003B0F FF               [12] 1159 	mov	r7,a
      003B10 E0               [24] 1160 	movx	a,@dptr
      003B11 60 16            [24] 1161 	jz	00112$
                                   1162 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:79: del_owned_key(dm_down);
      003B13 8F 82            [24] 1163 	mov	dpl, r7
      003B15 12 84 E2         [24] 1164 	lcall	_del_owned_key
                                   1165 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:80: del_owned_mods(dm_mods);
      003B18 90 04 A6         [24] 1166 	mov	dptr,#_dm_mods
      003B1B E0               [24] 1167 	movx	a,@dptr
      003B1C F5 82            [12] 1168 	mov	dpl,a
      003B1E 12 83 D9         [24] 1169 	lcall	_del_owned_mods
                                   1170 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:81: dm_down = 0;
      003B21 90 04 A5         [24] 1171 	mov	dptr,#_dm_down
      003B24 E4               [12] 1172 	clr	a
      003B25 F0               [24] 1173 	movx	@dptr,a
                                   1174 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:82: send_keyboard_report();
      003B26 02 86 FB         [24] 1175 	ljmp	_send_keyboard_report
      003B29                       1176 00112$:
                                   1177 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:83: } else if (dm_index == dm_lengths[dm_play - 1]) {
      003B29 90 04 A3         [24] 1178 	mov	dptr,#_dm_play
      003B2C E0               [24] 1179 	movx	a,@dptr
      003B2D FF               [12] 1180 	mov	r7,a
      003B2E 14               [12] 1181 	dec	a
      003B2F FE               [12] 1182 	mov	r6,a
      003B30 33               [12] 1183 	rlc	a
      003B31 95 E0            [12] 1184 	subb	a,acc
      003B33 FD               [12] 1185 	mov	r5,a
      003B34 EE               [12] 1186 	mov	a,r6
      003B35 24 A0            [12] 1187 	add	a, #_dm_lengths
      003B37 F5 82            [12] 1188 	mov	dpl,a
      003B39 ED               [12] 1189 	mov	a,r5
      003B3A 34 04            [12] 1190 	addc	a, #(_dm_lengths >> 8)
      003B3C F5 83            [12] 1191 	mov	dph,a
      003B3E E0               [24] 1192 	movx	a,@dptr
      003B3F FE               [12] 1193 	mov	r6,a
      003B40 90 04 A4         [24] 1194 	mov	dptr,#_dm_index
      003B43 E0               [24] 1195 	movx	a,@dptr
      003B44 FD               [12] 1196 	mov	r5,a
      003B45 B5 06 06         [24] 1197 	cjne	a,ar6,00109$
                                   1198 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:84: dm_play = 0;
      003B48 90 04 A3         [24] 1199 	mov	dptr,#_dm_play
      003B4B E4               [12] 1200 	clr	a
      003B4C F0               [24] 1201 	movx	@dptr,a
      003B4D 22               [24] 1202 	ret
      003B4E                       1203 00109$:
                                   1204 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:86: uint8_t i = (dm_play - 1) * 16 + dm_index++;
      003B4E 1F               [12] 1205 	dec	r7
      003B4F EF               [12] 1206 	mov	a,r7
      003B50 C4               [12] 1207 	swap	a
      003B51 54 F0            [12] 1208 	anl	a,#0xf0
      003B53 FF               [12] 1209 	mov	r7,a
      003B54 8D 06            [24] 1210 	mov	ar6,r5
      003B56 90 04 A4         [24] 1211 	mov	dptr,#_dm_index
      003B59 ED               [12] 1212 	mov	a,r5
      003B5A 04               [12] 1213 	inc	a
      003B5B F0               [24] 1214 	movx	@dptr,a
      003B5C EE               [12] 1215 	mov	a,r6
      003B5D 2F               [12] 1216 	add	a, r7
      003B5E FF               [12] 1217 	mov	r7,a
      003B5F 90 04 B4         [24] 1218 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003B62 F0               [24] 1219 	movx	@dptr,a
                                   1220 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:87: uint8_t code = dm_taps[i].code;
      003B63 8F E0            [24] 1221 	mov	acc,r7
      003B65 75 F0 02         [24] 1222 	mov	b,#0x02
      003B68 A4               [48] 1223 	mul	ab
      003B69 24 60            [12] 1224 	add	a, #_dm_taps
      003B6B F5 82            [12] 1225 	mov	dpl,a
      003B6D 74 04            [12] 1226 	mov	a,#(_dm_taps >> 8)
      003B6F 35 F0            [12] 1227 	addc	a, b
      003B71 F5 83            [12] 1228 	mov	dph,a
      003B73 E0               [24] 1229 	movx	a,@dptr
      003B74 FF               [12] 1230 	mov	r7,a
      003B75 90 04 B5         [24] 1231 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003B78 F0               [24] 1232 	movx	@dptr,a
                                   1233 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:90: if (!add_owned_key(code)) {
      003B79 8F 82            [24] 1234 	mov	dpl, r7
      003B7B 12 84 69         [24] 1235 	lcall	_add_owned_key
      003B7E E5 82            [12] 1236 	mov	a, dpl
      003B80 70 09            [24] 1237 	jnz	00107$
                                   1238 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:91: del_owned_key(code);
      003B82 90 04 B5         [24] 1239 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003B85 E0               [24] 1240 	movx	a,@dptr
      003B86 F5 82            [12] 1241 	mov	dpl,a
                                   1242 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:92: return;
      003B88 02 84 E2         [24] 1243 	ljmp	_del_owned_key
      003B8B                       1244 00107$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:94: dm_down = code;
      003B8B 90 04 B5         [24] 1246 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003B8E E0               [24] 1247 	movx	a,@dptr
      003B8F 90 04 A5         [24] 1248 	mov	dptr,#_dm_down
      003B92 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:95: dm_mods = dm_taps[i].mods;
      003B93 90 04 B4         [24] 1251 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003B96 E0               [24] 1252 	movx	a,@dptr
      003B97 75 F0 02         [24] 1253 	mov	b,#0x02
      003B9A A4               [48] 1254 	mul	ab
      003B9B 24 60            [12] 1255 	add	a, #_dm_taps
      003B9D FE               [12] 1256 	mov	r6,a
      003B9E 74 04            [12] 1257 	mov	a,#(_dm_taps >> 8)
      003BA0 35 F0            [12] 1258 	addc	a, b
      003BA2 FF               [12] 1259 	mov	r7,a
      003BA3 8E 82            [24] 1260 	mov	dpl,r6
      003BA5 8F 83            [24] 1261 	mov	dph,r7
      003BA7 A3               [24] 1262 	inc	dptr
      003BA8 E0               [24] 1263 	movx	a,@dptr
      003BA9 FF               [12] 1264 	mov	r7,a
      003BAA 90 04 A6         [24] 1265 	mov	dptr,#_dm_mods
      003BAD F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:96: add_owned_mods(dm_mods);
      003BAE 8F 82            [24] 1268 	mov	dpl, r7
      003BB0 12 83 CA         [24] 1269 	lcall	_add_owned_mods
                                   1270 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:97: send_keyboard_report();
                                   1271 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:99: }
      003BB3 02 86 FB         [24] 1272 	ljmp	_send_keyboard_report
                                   1273 	.area CSEG    (CODE)
                                   1274 	.area CONST   (CODE)
                                   1275 	.area XINIT   (CODE)
                                   1276 	.area CABS    (ABS,CODE)
