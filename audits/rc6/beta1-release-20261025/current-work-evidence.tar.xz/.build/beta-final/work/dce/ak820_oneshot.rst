                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_oneshot
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _unregister_mods
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_oneshot_post_PARM_2
                                    257 	.globl _ak820_oneshot_post
                                    258 	.globl _ak820_oneshot_cancel
                                    259 ;--------------------------------------------------------
                                    260 ; special function registers
                                    261 ;--------------------------------------------------------
                                    262 	.area RSEG    (ABS,DATA)
      000000                        263 	.org 0x0000
                           0000D0   264 _PSW	=	0x00d0
                           0000E0   265 _ACC	=	0x00e0
                           0000F0   266 _B	=	0x00f0
                           0000FD   267 _A_INV	=	0x00fd
                           000081   268 _SP	=	0x0081
                           000082   269 _DPL	=	0x0082
                           000083   270 _DPH	=	0x0083
                           0000A1   271 _SAFE_MOD	=	0x00a1
                           0000B1   272 _GLOBAL_CFG	=	0x00b1
                           000087   273 _PCON	=	0x0087
                           0000BA   274 _POWER_CFG	=	0x00ba
                           0000B9   275 _CLOCK_CFG	=	0x00b9
                           0000A9   276 _WAKE_CTRL	=	0x00a9
                           0000FE   277 _RESET_KEEP	=	0x00fe
                           0000FF   278 _WDOG_COUNT	=	0x00ff
                           0000A8   279 _IE	=	0x00a8
                           0000B8   280 _IP	=	0x00b8
                           0000E8   281 _IE_EX	=	0x00e8
                           0000E9   282 _IP_EX	=	0x00e9
                           0000B2   283 _GPIO_IE	=	0x00b2
                           008584   284 _ROM_ADDR	=	0x8584
                           000084   285 _ROM_ADDR_L	=	0x0084
                           000085   286 _ROM_ADDR_H	=	0x0085
                           008F8E   287 _ROM_DATA_HI	=	0x8f8e
                           00008E   288 _ROM_DATA_HL	=	0x008e
                           00008F   289 _ROM_DATA_HH	=	0x008f
                           000086   290 _ROM_CTRL	=	0x0086
                           000080   291 _P0	=	0x0080
                           0000C4   292 _P0_MOD_OC	=	0x00c4
                           0000C5   293 _P0_DIR_PU	=	0x00c5
                           000090   294 _P1	=	0x0090
                           000092   295 _P1_MOD_OC	=	0x0092
                           000093   296 _P1_DIR_PU	=	0x0093
                           0000A0   297 _P2	=	0x00a0
                           000094   298 _P2_MOD_OC	=	0x0094
                           000095   299 _P2_DIR_PU	=	0x0095
                           0000B0   300 _P3	=	0x00b0
                           000096   301 _P3_MOD_OC	=	0x0096
                           000097   302 _P3_DIR_PU	=	0x0097
                           0000C0   303 _P4	=	0x00c0
                           0000C2   304 _P4_MOD_OC	=	0x00c2
                           0000C3   305 _P4_DIR_PU	=	0x00c3
                           0000C1   306 _P4_LED_KEY	=	0x00c1
                           0000AA   307 _P5_IN	=	0x00aa
                           0000AB   308 _P5_OUT_PU	=	0x00ab
                           0000AC   309 _P5_DIR	=	0x00ac
                           0000AD   310 _P6_IN	=	0x00ad
                           0000AE   311 _P6_OUT_PU	=	0x00ae
                           0000AF   312 _P6_DIR	=	0x00af
                           0000F1   313 _P7	=	0x00f1
                           0000A2   314 _XBUS_AUX	=	0x00a2
                           000088   315 _TCON	=	0x0088
                           000089   316 _TMOD	=	0x0089
                           00008A   317 _TL0	=	0x008a
                           00008B   318 _TL1	=	0x008b
                           00008C   319 _TH0	=	0x008c
                           00008D   320 _TH1	=	0x008d
                           000098   321 _SCON	=	0x0098
                           000099   322 _SBUF	=	0x0099
                           0000C8   323 _T2CON	=	0x00c8
                           0000C9   324 _T2MOD	=	0x00c9
                           00CBCA   325 _RCAP2	=	0xcbca
                           0000CA   326 _RCAP2L	=	0x00ca
                           0000CB   327 _RCAP2H	=	0x00cb
                           00CDCC   328 _T2COUNT	=	0xcdcc
                           0000CC   329 _TL2	=	0x00cc
                           0000CD   330 _TH2	=	0x00cd
                           00CFCE   331 _T2CAP1	=	0xcfce
                           0000CE   332 _T2CAP1L	=	0x00ce
                           0000CF   333 _T2CAP1H	=	0x00cf
                           0000F8   334 _SPI0_STAT	=	0x00f8
                           0000F9   335 _SPI0_DATA	=	0x00f9
                           0000FA   336 _SPI0_CTRL	=	0x00fa
                           0000FB   337 _SPI0_CK_SE	=	0x00fb
                           0000FC   338 _SPI0_SETUP	=	0x00fc
                           0000BC   339 _SCON1	=	0x00bc
                           0000BD   340 _SBUF1	=	0x00bd
                           0000BE   341 _SBAUD1	=	0x00be
                           0000BF   342 _SIF1	=	0x00bf
                           0000B4   343 _SPI1_STAT	=	0x00b4
                           0000B5   344 _SPI1_DATA	=	0x00b5
                           0000B6   345 _SPI1_CTRL	=	0x00b6
                           0000B7   346 _SPI1_CK_SE	=	0x00b7
                           0000F3   347 _ADC_CTRL	=	0x00f3
                           00F5F4   348 _ADC_DAT	=	0xf5f4
                           0000F4   349 _ADC_DAT_L	=	0x00f4
                           0000F5   350 _ADC_DAT_H	=	0x00f5
                           0000F6   351 _ADC_CHAN	=	0x00f6
                           0000A6   352 _LED_COMMON	=	0x00a6
                           0000A7   353 _LED_PWM_OE	=	0x00a7
                           00C7C6   354 _LED_DMA	=	0xc7c6
                           0000C6   355 _LED_DMA_L	=	0x00c6
                           0000C7   356 _LED_DMA_H	=	0x00c7
                           0000F7   357 _LED_STATUS	=	0x00f7
                           0000B3   358 _I2CX_INT	=	0x00b3
                           0000BB   359 _I2CS_INT_ST	=	0x00bb
                                    360 ;--------------------------------------------------------
                                    361 ; special function bits
                                    362 ;--------------------------------------------------------
                                    363 	.area RSEG    (ABS,DATA)
      000000                        364 	.org 0x0000
                           0000D7   365 _CY	=	0x00d7
                           0000D6   366 _AC	=	0x00d6
                           0000D5   367 _F0	=	0x00d5
                           0000D4   368 _RS1	=	0x00d4
                           0000D3   369 _RS0	=	0x00d3
                           0000D2   370 _OV	=	0x00d2
                           0000D1   371 _F1	=	0x00d1
                           0000D0   372 _P	=	0x00d0
                           0000AF   373 _EA	=	0x00af
                           0000AE   374 _E_DIS	=	0x00ae
                           0000AD   375 _ET2	=	0x00ad
                           0000AC   376 _ES	=	0x00ac
                           0000AB   377 _ET1	=	0x00ab
                           0000AA   378 _EX1	=	0x00aa
                           0000A9   379 _ET0	=	0x00a9
                           0000A8   380 _EX0	=	0x00a8
                           0000BF   381 _PH_FLAG	=	0x00bf
                           0000BE   382 _PL_FLAG	=	0x00be
                           0000BD   383 _PT2	=	0x00bd
                           0000BC   384 _PS	=	0x00bc
                           0000BB   385 _PT1	=	0x00bb
                           0000BA   386 _PX1	=	0x00ba
                           0000B9   387 _PT0	=	0x00b9
                           0000B8   388 _PX0	=	0x00b8
                           0000EF   389 _IE_WDOG	=	0x00ef
                           0000EE   390 _IE_GPIO	=	0x00ee
                           0000ED   391 _IE_PWM_I2C	=	0x00ed
                           0000EC   392 _IE_UART1	=	0x00ec
                           0000EB   393 _IE_ADC	=	0x00eb
                           0000E9   394 _IE_USB	=	0x00e9
                           0000E8   395 _IE_SPI0	=	0x00e8
                           000087   396 _P0_7	=	0x0087
                           000086   397 _P0_6	=	0x0086
                           000085   398 _P0_5	=	0x0085
                           000084   399 _P0_4	=	0x0084
                           000083   400 _P0_3	=	0x0083
                           000082   401 _P0_2	=	0x0082
                           000081   402 _P0_1	=	0x0081
                           000080   403 _P0_0	=	0x0080
                           000081   404 _SDA0	=	0x0081
                           000080   405 _SCL0	=	0x0080
                           000083   406 _TXD_	=	0x0083
                           000082   407 _RXD_	=	0x0082
                           000085   408 _AIN13	=	0x0085
                           000084   409 _AIN12	=	0x0084
                           000083   410 _AIN11	=	0x0083
                           000082   411 _AIN10	=	0x0082
                           000081   412 _AIN9	=	0x0081
                           000080   413 _AIN8	=	0x0080
                           000097   414 _P1_7	=	0x0097
                           000096   415 _P1_6	=	0x0096
                           000095   416 _P1_5	=	0x0095
                           000094   417 _P1_4	=	0x0094
                           000093   418 _P1_3	=	0x0093
                           000092   419 _P1_2	=	0x0092
                           000091   420 _P1_1	=	0x0091
                           000090   421 _P1_0	=	0x0090
                           000097   422 _TXD1_	=	0x0097
                           000096   423 _RXD1_	=	0x0096
                           000097   424 _SCK	=	0x0097
                           000096   425 _MISO	=	0x0096
                           000095   426 _MOSI	=	0x0095
                           000094   427 _SCS	=	0x0094
                           000092   428 _INT0_	=	0x0092
                           000091   429 _T2EX	=	0x0091
                           000091   430 _CAP2	=	0x0091
                           000090   431 _T2	=	0x0090
                           000090   432 _CAP1	=	0x0090
                           000097   433 _AIN7	=	0x0097
                           000096   434 _AIN6	=	0x0096
                           000095   435 _AIN5	=	0x0095
                           000094   436 _AIN4	=	0x0094
                           000093   437 _AIN3	=	0x0093
                           000092   438 _AIN2	=	0x0092
                           000091   439 _AIN1	=	0x0091
                           000090   440 _AIN0	=	0x0090
                           0000A7   441 _P2_7	=	0x00a7
                           0000A6   442 _P2_6	=	0x00a6
                           0000A5   443 _P2_5	=	0x00a5
                           0000A4   444 _P2_4	=	0x00a4
                           0000A3   445 _P2_3	=	0x00a3
                           0000A2   446 _P2_2	=	0x00a2
                           0000A1   447 _P2_1	=	0x00a1
                           0000A0   448 _P2_0	=	0x00a0
                           0000A7   449 _TXD1	=	0x00a7
                           0000A6   450 _RXD1	=	0x00a6
                           0000A5   451 _T2EX_	=	0x00a5
                           0000A5   452 _CAP2_	=	0x00a5
                           0000A4   453 _T2_	=	0x00a4
                           0000A4   454 _CAP1_	=	0x00a4
                           0000B7   455 _P3_7	=	0x00b7
                           0000B6   456 _P3_6	=	0x00b6
                           0000B5   457 _P3_5	=	0x00b5
                           0000B4   458 _P3_4	=	0x00b4
                           0000B3   459 _P3_3	=	0x00b3
                           0000B2   460 _P3_2	=	0x00b2
                           0000B1   461 _P3_1	=	0x00b1
                           0000B0   462 _P3_0	=	0x00b0
                           0000B7   463 _SCK1	=	0x00b7
                           0000B6   464 _MISO1	=	0x00b6
                           0000B5   465 _MOSI1	=	0x00b5
                           0000B5   466 _T1	=	0x00b5
                           0000B4   467 _T0	=	0x00b4
                           0000B3   468 _INT1	=	0x00b3
                           0000B2   469 _INT0	=	0x00b2
                           0000B1   470 _TXD	=	0x00b1
                           0000B0   471 _RXD	=	0x00b0
                           0000C6   472 _P4_6	=	0x00c6
                           0000C5   473 _P4_5	=	0x00c5
                           0000C4   474 _P4_4	=	0x00c4
                           0000C3   475 _P4_3	=	0x00c3
                           0000C2   476 _P4_2	=	0x00c2
                           0000C1   477 _P4_1	=	0x00c1
                           0000C0   478 _P4_0	=	0x00c0
                           00008F   479 _TF1	=	0x008f
                           00008E   480 _TR1	=	0x008e
                           00008D   481 _TF0	=	0x008d
                           00008C   482 _TR0	=	0x008c
                           00008B   483 _IE1	=	0x008b
                           00008A   484 _IT1	=	0x008a
                           000089   485 _IE0	=	0x0089
                           000088   486 _IT0	=	0x0088
                           00009F   487 _SM0	=	0x009f
                           00009E   488 _SM1	=	0x009e
                           00009D   489 _SM2	=	0x009d
                           00009C   490 _REN	=	0x009c
                           00009B   491 _TB8	=	0x009b
                           00009A   492 _RB8	=	0x009a
                           000099   493 _TI	=	0x0099
                           000098   494 _RI	=	0x0098
                           0000CF   495 _TF2	=	0x00cf
                           0000CF   496 _CAP1F	=	0x00cf
                           0000CE   497 _EXF2	=	0x00ce
                           0000CD   498 _RCLK	=	0x00cd
                           0000CC   499 _TCLK	=	0x00cc
                           0000CB   500 _EXEN2	=	0x00cb
                           0000CA   501 _TR2	=	0x00ca
                           0000C9   502 _C_T2	=	0x00c9
                           0000C8   503 _CP_RL2	=	0x00c8
                           0000FF   504 _S0_FST_ACT	=	0x00ff
                           0000FE   505 _S0_IF_OV	=	0x00fe
                           0000FD   506 _S0_IF_FIRST	=	0x00fd
                           0000FC   507 _S0_IF_BYTE	=	0x00fc
                           0000FB   508 _S0_FREE	=	0x00fb
                           0000FA   509 _S0_T_FIFO	=	0x00fa
                           0000F8   510 _S0_R_FIFO	=	0x00f8
                           0000F7   511 _ADC_START	=	0x00f7
                                    512 ;--------------------------------------------------------
                                    513 ; overlayable register banks
                                    514 ;--------------------------------------------------------
                                    515 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        516 	.ds 8
                                    517 ;--------------------------------------------------------
                                    518 ; internal ram data
                                    519 ;--------------------------------------------------------
                                    520 	.area DSEG    (DATA)
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable items in internal ram
                                    523 ;--------------------------------------------------------
                                    524 ;--------------------------------------------------------
                                    525 ; indirectly addressable internal ram data
                                    526 ;--------------------------------------------------------
                                    527 	.area ISEG    (DATA)
                                    528 ;--------------------------------------------------------
                                    529 ; absolute internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area IABS    (ABS,DATA)
                                    532 	.area IABS    (ABS,DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; bit data
                                    535 ;--------------------------------------------------------
                                    536 	.area BSEG    (BIT)
                                    537 ;--------------------------------------------------------
                                    538 ; paged external ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area PSEG    (PAG,XDATA)
                                    541 ;--------------------------------------------------------
                                    542 ; uninitialized external ram data
                                    543 ;--------------------------------------------------------
                                    544 	.area XSEG    (XDATA)
      000607                        545 _ak820_oneshot_post_PARM_2:
      000607                        546 	.ds 1
      000608                        547 _ak820_oneshot_post_id_10000_594:
      000608                        548 	.ds 1
                                    549 ;--------------------------------------------------------
                                    550 ; absolute external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area XABS    (ABS,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; initialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XISEG   (XDATA)
                                    557 	.area HOME    (CODE)
                                    558 	.area GSINIT0 (CODE)
                                    559 	.area GSINIT1 (CODE)
                                    560 	.area GSINIT2 (CODE)
                                    561 	.area GSINIT3 (CODE)
                                    562 	.area GSINIT4 (CODE)
                                    563 	.area GSINIT5 (CODE)
                                    564 	.area GSINIT  (CODE)
                                    565 	.area GSFINAL (CODE)
                                    566 	.area CSEG    (CODE)
                                    567 ;--------------------------------------------------------
                                    568 ; global & static initialisations
                                    569 ;--------------------------------------------------------
                                    570 	.area HOME    (CODE)
                                    571 	.area GSINIT  (CODE)
                                    572 	.area GSFINAL (CODE)
                                    573 	.area GSINIT  (CODE)
                                    574 ;--------------------------------------------------------
                                    575 ; Home
                                    576 ;--------------------------------------------------------
                                    577 	.area HOME    (CODE)
                                    578 	.area HOME    (CODE)
                                    579 ;--------------------------------------------------------
                                    580 ; code
                                    581 ;--------------------------------------------------------
                                    582 	.area AK820LOW(CODE)
                                    583 ;------------------------------------------------------------
                                    584 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    585 ;------------------------------------------------------------
                                    586 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    587 ;------------------------------------------------------------
                                    588 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    589 ;	-----------------------------------------
                           000007   590 	ar7 = 0x07
                           000006   591 	ar6 = 0x06
                           000005   592 	ar5 = 0x05
                           000004   593 	ar4 = 0x04
                           000003   594 	ar3 = 0x03
                           000002   595 	ar2 = 0x02
                           000001   596 	ar1 = 0x01
                           000000   597 	ar0 = 0x00
                                    598 ;	 function ak820_oneshot_post
                                    599 ;	-----------------------------------------
      002E6F                        600 _ak820_oneshot_post:
      002E6F E5 82            [12]  601 	mov	a,dpl
      002E71 90 06 08         [24]  602 	mov	dptr,#_ak820_oneshot_post_id_10000_594
      002E74 F0               [24]  603 	movx	@dptr,a
                                    604 ;	keyboards/ajazz/ak820/ak820_oneshot.c:11: if (!pressed && id == ak820_oneshot_target && !get_repeat_key_count()) {
      002E75 90 06 07         [24]  605 	mov	dptr,#_ak820_oneshot_post_PARM_2
      002E78 E0               [24]  606 	movx	a,@dptr
      002E79 70 28            [24]  607 	jnz	00105$
      002E7B 90 06 08         [24]  608 	mov	dptr,#_ak820_oneshot_post_id_10000_594
      002E7E E0               [24]  609 	movx	a,@dptr
      002E7F FF               [12]  610 	mov	r7,a
      002E80 90 0D FA         [24]  611 	mov	dptr,#_ak820_oneshot_target
      002E83 E0               [24]  612 	movx	a,@dptr
      002E84 FE               [12]  613 	mov	r6,a
      002E85 EF               [12]  614 	mov	a,r7
      002E86 B5 06 1A         [24]  615 	cjne	a,ar6,00105$
      002E89 12 A7 D1         [24]  616 	lcall	_get_repeat_key_count
      002E8C E5 82            [12]  617 	mov	a, dpl
      002E8E 70 13            [24]  618 	jnz	00105$
                                    619 ;	keyboards/ajazz/ak820/ak820_oneshot.c:12: unregister_mods(ak820_oneshot_consumed);
      002E90 90 06 A6         [24]  620 	mov	dptr,#_ak820_oneshot_consumed
      002E93 E0               [24]  621 	movx	a,@dptr
      002E94 F5 82            [12]  622 	mov	dpl,a
      002E96 12 7D A4         [24]  623 	lcall	_unregister_mods
                                    624 ;	keyboards/ajazz/ak820/ak820_oneshot.c:13: ak820_oneshot_consumed = 0;
      002E99 90 06 A6         [24]  625 	mov	dptr,#_ak820_oneshot_consumed
      002E9C E4               [12]  626 	clr	a
      002E9D F0               [24]  627 	movx	@dptr,a
                                    628 ;	keyboards/ajazz/ak820/ak820_oneshot.c:14: ak820_oneshot_target = 255;
      002E9E 90 0D FA         [24]  629 	mov	dptr,#_ak820_oneshot_target
      002EA1 14               [12]  630 	dec	a
      002EA2 F0               [24]  631 	movx	@dptr,a
      002EA3                        632 00105$:
                                    633 ;	keyboards/ajazz/ak820/ak820_oneshot.c:16: }
      002EA3 22               [24]  634 	ret
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'ak820_oneshot_cancel'
                                    637 ;------------------------------------------------------------
                                    638 ;	keyboards/ajazz/ak820/ak820_oneshot.c:17: void ak820_oneshot_cancel(void) {
                                    639 ;	-----------------------------------------
                                    640 ;	 function ak820_oneshot_cancel
                                    641 ;	-----------------------------------------
      002EA4                        642 _ak820_oneshot_cancel:
                                    643 ;	keyboards/ajazz/ak820/ak820_oneshot.c:18: ak820_oneshot_mods = ak820_oneshot_consumed = 0;
      002EA4 90 06 A6         [24]  644 	mov	dptr,#_ak820_oneshot_consumed
      002EA7 E4               [12]  645 	clr	a
      002EA8 F0               [24]  646 	movx	@dptr,a
      002EA9 90 06 A5         [24]  647 	mov	dptr,#_ak820_oneshot_mods
      002EAC F0               [24]  648 	movx	@dptr,a
                                    649 ;	keyboards/ajazz/ak820/ak820_oneshot.c:19: ak820_oneshot_target = 255;
      002EAD 90 0D FA         [24]  650 	mov	dptr,#_ak820_oneshot_target
      002EB0 14               [12]  651 	dec	a
      002EB1 F0               [24]  652 	movx	@dptr,a
                                    653 ;	keyboards/ajazz/ak820/ak820_oneshot.c:20: }
      002EB2 22               [24]  654 	ret
                                    655 	.area AK820LOW(CODE)
                                    656 	.area CONST   (CODE)
                                    657 	.area XINIT   (CODE)
                                    658 	.area CABS    (ABS,CODE)
