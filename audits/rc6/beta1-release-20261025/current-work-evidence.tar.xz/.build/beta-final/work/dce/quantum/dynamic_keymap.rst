                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      00002A                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      00002A                        588 	.ds 2
      00002C                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002C                        590 	.ds 1
      00002D                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002D                        592 	.ds 1
      00002E                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002E                        594 	.ds 2
      000030                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000030                        596 	.ds 2
      000032                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000032                        598 	.ds 1
      000033                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000033                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B46                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B46                        628 	.ds 1
      000B47                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B47                        630 	.ds 1
      000B48                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000B48                        632 	.ds 1
      000B49                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B49                        634 	.ds 1
      000B4A                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B4A                        636 	.ds 1
      000B4B                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000B4B                        638 	.ds 1
      000B4C                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B4C                        640 	.ds 1
      000B4D                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B4D                        642 	.ds 1
      000B4E                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B4E                        644 	.ds 2
      000B50                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000B50                        646 	.ds 1
      000B51                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B51                        648 	.ds 1
      000B52                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000B52                        650 	.ds 1
      000B53                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B53                        652 	.ds 1
      000B54                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B54                        654 	.ds 1
      000B55                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000B55                        656 	.ds 1
      000B56                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B56                        658 	.ds 1
      000B57                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B57                        660 	.ds 1
      000B58                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B58                        662 	.ds 2
      000B5A                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000B5A                        664 	.ds 1
      000B5B                        665 _dynamic_keymap_get_combo_PARM_2:
      000B5B                        666 	.ds 3
      000B5E                        667 _dynamic_keymap_get_combo_index_10000_384:
      000B5E                        668 	.ds 1
      000B5F                        669 _dynamic_keymap_set_combo_PARM_2:
      000B5F                        670 	.ds 3
      000B62                        671 _dynamic_keymap_set_combo_index_10000_390:
      000B62                        672 	.ds 1
      000B63                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000B63                        674 	.ds 10
      000B6D                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000B6D                        676 	.ds 1
      000B6E                        677 _dynamic_keymap_reset_combo_10001_407:
      000B6E                        678 	.ds 10
      000B78                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B78                        680 	.ds 2
      000B7A                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B7A                        682 	.ds 2
      000B7C                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B7C                        684 	.ds 2
      000B7E                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B7E                        686 	.ds 3
      000B81                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B81                        688 	.ds 2
      000B83                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B83                        690 	.ds 1
      000B84                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B84                        692 	.ds 2
      000B86                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B86                        694 	.ds 3
      000B89                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B89                        696 	.ds 2
      000B8B                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B8B                        698 	.ds 2
      000B8D                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B8D                        700 	.ds 3
      000B90                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B90                        702 	.ds 2
      000B92                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B92                        704 	.ds 1
      000B93                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B93                        706 	.ds 1
      000B94                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B94                        708 	.ds 1
      000B95                        709 _keycode_at_keymap_location_PARM_2:
      000B95                        710 	.ds 1
      000B96                        711 _keycode_at_keymap_location_PARM_3:
      000B96                        712 	.ds 1
      000B97                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B97                        714 	.ds 1
      000B98                        715 _keycode_at_encodermap_location_PARM_2:
      000B98                        716 	.ds 1
      000B99                        717 _keycode_at_encodermap_location_PARM_3:
      000B99                        718 	.ds 1
      000B9A                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B9A                        720 	.ds 1
      000B9B                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B9B                        722 	.ds 2
      000B9D                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B9D                        724 	.ds 3
      000BA0                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000BA0                        726 	.ds 2
      000BA2                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BA2                        728 	.ds 2
      000BA4                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BA4                        730 	.ds 3
      000BA7                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000BA7                        732 	.ds 2
      000BA9                        733 _decode_keycode_kc_10000_454:
      000BA9                        734 	.ds 2
      000BAB                        735 _dynamic_keymap_macro_send_id_10000_457:
      000BAB                        736 	.ds 1
      000BAC                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000BAC                        738 	.ds 1
      000BAD                        739 _dynamic_keymap_macro_send_p_10001_463:
      000BAD                        740 	.ds 2
      000BAF                        741 _dynamic_keymap_macro_send_data_10003_470:
      000BAF                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008AA5                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008AA5 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008AA8 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008AA9                        810 _dynamic_keymap_key_to_eeprom_address:
      008AA9 E5 82            [12]  811 	mov	a,dpl
      008AAB 90 0B 48         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      008AAE F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008AAF E0               [24]  815 	movx	a,@dptr
      008AB0 FF               [12]  816 	mov	r7,a
      008AB1 7E 00            [12]  817 	mov	r6,#0x00
      008AB3 74 40            [12]  818 	mov	a,#0x40
      008AB5 12 48 F5         [24]  819 	lcall	_ak820_outline_0135
      008AB8 7D 00            [12]  820 	mov	r5,#0x00
      008ABA 90 0B 46         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008ABD E0               [24]  822 	movx	a,@dptr
      008ABE 75 F0 10         [24]  823 	mov	b,#0x10
      008AC1 A4               [48]  824 	mul	ab
      008AC2 2E               [12]  825 	add	a, r6
      008AC3 FE               [12]  826 	mov	r6,a
      008AC4 EF               [12]  827 	mov	a,r7
      008AC5 35 F0            [12]  828 	addc	a, b
      008AC7 FF               [12]  829 	mov	r7,a
      008AC8 90 0B 47         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008ACB E0               [24]  831 	movx	a,@dptr
      008ACC 7C 00            [12]  832 	mov	r4,#0x00
      008ACE 25 E0            [12]  833 	add	a,acc
      008AD0 FB               [12]  834 	mov	r3,a
      008AD1 EC               [12]  835 	mov	a,r4
      008AD2 33               [12]  836 	rlc	a
      008AD3 FC               [12]  837 	mov	r4,a
      008AD4 EB               [12]  838 	mov	a,r3
      008AD5 2E               [12]  839 	add	a, r6
      008AD6 FE               [12]  840 	mov	r6,a
      008AD7 EC               [12]  841 	mov	a,r4
      008AD8 3F               [12]  842 	addc	a, r7
      008AD9 FF               [12]  843 	mov	r7,a
      008ADA 12 48 E5         [24]  844 	lcall	_ak820_outline_0114
      008ADD 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008ADF 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      008AE0                        861 _dynamic_keymap_get_keycode:
      008AE0 E5 82            [12]  862 	mov	a,dpl
      008AE2 90 0B 4B         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      008AE5 F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008AE6 E0               [24]  866 	movx	a,@dptr
      008AE7 FF               [12]  867 	mov	r7,a
      008AE8 BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008AEB                        869 00121$:
      008AEB 50 14            [24]  870 	jnc	00101$
      008AED 90 0B 49         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008AF0 E0               [24]  872 	movx	a,@dptr
      008AF1 FE               [12]  873 	mov	r6,a
      008AF2 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008AF5                        875 00123$:
      008AF5 50 0A            [24]  876 	jnc	00101$
      008AF7 90 0B 4A         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008AFA E0               [24]  878 	movx	a,@dptr
      008AFB FD               [12]  879 	mov	r5,a
      008AFC BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008AFF                        881 00125$:
      008AFF 40 04            [24]  882 	jc	00102$
      008B01                        883 00101$:
      008B01 90 00 00         [24]  884 	mov	dptr,#0x0000
      008B04 22               [24]  885 	ret
      008B05                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008B05 12 95 3B         [24]  888 	lcall	_ak820_outline_0098
      008B08 51 A9            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008B0A 12 95 48         [24]  891 	lcall	_ak820_outline_0112
      008B0D 12 45 FD         [24]  892 	lcall	_eeprom_read_byte
      008B10 AB 82            [24]  893 	mov	r3,dpl
      008B12 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008B14 0D               [12]  896 	inc	r5
      008B15 BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008B18 0E               [12]  898 	inc	r6
      008B19                        899 00127$:
      008B19 12 55 35         [24]  900 	lcall	_ak820_outline_0045
      008B1C 12 45 FD         [24]  901 	lcall	_eeprom_read_byte
      008B1F AF 82            [24]  902 	mov	r7, dpl
      008B21 7E 00            [12]  903 	mov	r6,#0x00
      008B23 EF               [12]  904 	mov	a,r7
      008B24 42 04            [12]  905 	orl	ar4,a
      008B26 EE               [12]  906 	mov	a,r6
      008B27 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008B29 12 49 21         [24]  909 	lcall	_ak820_outline_0181
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008B2C 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008B2D                        925 _dynamic_keymap_set_keycode:
      008B2D E5 82            [12]  926 	mov	a,dpl
      008B2F 90 0B 50         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      008B32 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008B33 E0               [24]  930 	movx	a,@dptr
      008B34 FF               [12]  931 	mov	r7,a
      008B35 BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008B38                        933 00121$:
      008B38 50 14            [24]  934 	jnc	00101$
      008B3A 90 0B 4C         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008B3D E0               [24]  936 	movx	a,@dptr
      008B3E FE               [12]  937 	mov	r6,a
      008B3F BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      008B42                        939 00123$:
      008B42 50 0A            [24]  940 	jnc	00101$
      008B44 90 0B 4D         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008B47 E0               [24]  942 	movx	a,@dptr
      008B48 FD               [12]  943 	mov	r5,a
      008B49 BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008B4C                        945 00125$:
      008B4C 40 01            [24]  946 	jc	00102$
      008B4E                        947 00101$:
      008B4E 22               [24]  948 	ret
      008B4F                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008B4F 12 95 3B         [24]  951 	lcall	_ak820_outline_0098
      008B52 51 A9            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      008B54 12 95 48         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008B57 90 0B 4E         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008B5A E0               [24]  956 	movx	a,@dptr
      008B5B FB               [12]  957 	mov	r3,a
      008B5C A3               [24]  958 	inc	dptr
      008B5D E0               [24]  959 	movx	a,@dptr
      008B5E 90 07 0E         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      008B61 F0               [24]  961 	movx	@dptr,a
      008B62 12 55 35         [24]  962 	lcall	_ak820_outline_0045
      008B65 12 54 1F         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008B68 0D               [12]  965 	inc	r5
      008B69 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008B6C 0E               [12]  967 	inc	r6
      008B6D                        968 00127$:
      008B6D 90 07 0E         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008B70 EB               [12]  970 	mov	a,r3
      008B71 F0               [24]  971 	movx	@dptr,a
      008B72 12 55 35         [24]  972 	lcall	_ak820_outline_0045
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008B75 02 54 1F         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008B78                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008B78 E5 82            [12]  986 	mov	a,dpl
      008B7A 90 0B 52         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      008B7D F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008B7E E0               [24]  990 	movx	a,@dptr
      008B7F 75 F0 04         [24]  991 	mov	b,#0x04
      008B82 A4               [48]  992 	mul	ab
      008B83 24 40            [12]  993 	add	a, #0x40
      008B85 FD               [12]  994 	mov	r5,a
      008B86 74 06            [12]  995 	mov	a,#0x06
      008B88 35 F0            [12]  996 	addc	a, b
      008B8A FE               [12]  997 	mov	r6,a
      008B8B 7F 00            [12]  998 	mov	r7,#0x00
      008B8D 90 0B 51         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008B90 E0               [24] 1000 	movx	a,@dptr
      008B91 75 F0 04         [24] 1001 	mov	b,#0x04
      008B94 A4               [48] 1002 	mul	ab
      008B95 2D               [12] 1003 	add	a, r5
      008B96 FD               [12] 1004 	mov	r5,a
      008B97 EE               [12] 1005 	mov	a,r6
      008B98 35 F0            [12] 1006 	addc	a, b
      008B9A FE               [12] 1007 	mov	r6,a
      008B9B 12 55 35         [24] 1008 	lcall	_ak820_outline_0045
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008B9E 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008B9F                       1024 _dynamic_keymap_get_encoder:
      008B9F E5 82            [12] 1025 	mov	a,dpl
      008BA1 90 0B 55         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      008BA4 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008BA5 E0               [24] 1029 	movx	a,@dptr
      008BA6 FF               [12] 1030 	mov	r7,a
      008BA7 BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008BAA                       1032 00131$:
      008BAA 50 0A            [24] 1033 	jnc	00101$
      008BAC 90 0B 53         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008BAF E0               [24] 1035 	movx	a,@dptr
      008BB0 FE               [12] 1036 	mov	r6,a
      008BB1 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008BB4                       1038 00133$:
      008BB4 40 04            [24] 1039 	jc	00102$
      008BB6                       1040 00101$:
      008BB6 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008BB9 22               [24] 1042 	ret
      008BBA                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008BBA 90 0B 51         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008BBD 12 7E 88         [24] 1046 	lcall	_ak820_outline_0185
      008BC0 71 78            [12] 1047 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008BC2 12 95 48         [24] 1048 	lcall	_ak820_outline_0112
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008BC5 90 0B 54         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008BC8 E0               [24] 1051 	movx	a,@dptr
      008BC9 FC               [12] 1052 	mov	r4,a
      008BCA E0               [24] 1053 	movx	a,@dptr
      008BCB 60 04            [24] 1054 	jz	00106$
      008BCD 7B 00            [12] 1055 	mov	r3,#0x00
      008BCF 80 02            [24] 1056 	sjmp	00107$
      008BD1                       1057 00106$:
      008BD1 7B 02            [12] 1058 	mov	r3,#0x02
      008BD3                       1059 00107$:
      008BD3 EB               [12] 1060 	mov	a,r3
      008BD4 12 95 19         [24] 1061 	lcall	_ak820_outline_0025
      008BD7 12 45 FD         [24] 1062 	lcall	_eeprom_read_byte
      008BDA AA 82            [24] 1063 	mov	r2,dpl
      008BDC 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008BDE EC               [12] 1066 	mov	a,r4
      008BDF 60 04            [24] 1067 	jz	00108$
      008BE1 7C 00            [12] 1068 	mov	r4,#0x00
      008BE3 80 02            [24] 1069 	sjmp	00109$
      008BE5                       1070 00108$:
      008BE5 7C 02            [12] 1071 	mov	r4,#0x02
      008BE7                       1072 00109$:
      008BE7 EC               [12] 1073 	mov	a,r4
      008BE8 12 38 71         [24] 1074 	lcall	_ak820_outline_0156
      008BEB 0D               [12] 1075 	inc	r5
      008BEC BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      008BEF 0E               [12] 1077 	inc	r6
      008BF0                       1078 00137$:
      008BF0 12 55 35         [24] 1079 	lcall	_ak820_outline_0045
      008BF3 12 45 FD         [24] 1080 	lcall	_eeprom_read_byte
      008BF6 AF 82            [24] 1081 	mov	r7, dpl
      008BF8 7E 00            [12] 1082 	mov	r6,#0x00
      008BFA EF               [12] 1083 	mov	a,r7
      008BFB 42 03            [12] 1084 	orl	ar3,a
      008BFD EE               [12] 1085 	mov	a,r6
      008BFE 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      008C00 8B 82            [24] 1088 	mov	dpl, r3
      008C02 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      008C04 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      008C05                       1106 _dynamic_keymap_set_encoder:
      008C05 E5 82            [12] 1107 	mov	a,dpl
      008C07 90 0B 5A         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008C0A F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008C0B E0               [24] 1111 	movx	a,@dptr
      008C0C FF               [12] 1112 	mov	r7,a
      008C0D BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      008C10                       1114 00131$:
      008C10 50 0A            [24] 1115 	jnc	00101$
      008C12 90 0B 56         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008C15 E0               [24] 1117 	movx	a,@dptr
      008C16 FE               [12] 1118 	mov	r6,a
      008C17 BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      008C1A                       1120 00133$:
      008C1A 40 01            [24] 1121 	jc	00102$
      008C1C                       1122 00101$:
      008C1C 22               [24] 1123 	ret
      008C1D                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008C1D 90 0B 51         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008C20 12 7E 88         [24] 1127 	lcall	_ak820_outline_0185
      008C23 71 78            [12] 1128 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008C25 12 95 48         [24] 1129 	lcall	_ak820_outline_0112
                                   1130 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008C28 90 0B 57         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008C2B E0               [24] 1132 	movx	a,@dptr
      008C2C FC               [12] 1133 	mov	r4,a
      008C2D E0               [24] 1134 	movx	a,@dptr
      008C2E 60 04            [24] 1135 	jz	00106$
      008C30 7B 00            [12] 1136 	mov	r3,#0x00
      008C32 80 02            [24] 1137 	sjmp	00107$
      008C34                       1138 00106$:
      008C34 7B 02            [12] 1139 	mov	r3,#0x02
      008C36                       1140 00107$:
      008C36 EB               [12] 1141 	mov	a,r3
      008C37 12 95 5A         [24] 1142 	lcall	_ak820_outline_0134
      008C3A 8F 03            [24] 1143 	mov	ar3,r7
      008C3C 90 0B 58         [24] 1144 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C3F E0               [24] 1145 	movx	a,@dptr
      008C40 F5 2A            [12] 1146 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008C42 A3               [24] 1147 	inc	dptr
      008C43 E0               [24] 1148 	movx	a,@dptr
      008C44 F5 2B            [12] 1149 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008C46 90 07 0E         [24] 1150 	mov	dptr,#_eeprom_update_byte_PARM_2
      008C49 F0               [24] 1151 	movx	@dptr,a
      008C4A 12 49 1C         [24] 1152 	lcall	_ak820_outline_0180
      008C4D 8B F0            [24] 1153 	mov	b, r3
      008C4F 12 54 1F         [24] 1154 	lcall	_eeprom_update_byte
                                   1155 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008C52 EC               [12] 1156 	mov	a,r4
      008C53 60 04            [24] 1157 	jz	00108$
      008C55 7C 00            [12] 1158 	mov	r4,#0x00
      008C57 80 02            [24] 1159 	sjmp	00109$
      008C59                       1160 00108$:
      008C59 7C 02            [12] 1161 	mov	r4,#0x02
      008C5B                       1162 00109$:
      008C5B EC               [12] 1163 	mov	a,r4
      008C5C 12 38 71         [24] 1164 	lcall	_ak820_outline_0156
      008C5F 0D               [12] 1165 	inc	r5
      008C60 BD 00 01         [24] 1166 	cjne	r5,#0x00,00137$
      008C63 0E               [12] 1167 	inc	r6
      008C64                       1168 00137$:
      008C64 90 07 0E         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      008C67 E5 2A            [12] 1170 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008C69 F0               [24] 1171 	movx	@dptr,a
      008C6A 12 55 35         [24] 1172 	lcall	_ak820_outline_0045
                                   1173 ;	quantum/dynamic_keymap.c:245: }
      008C6D 02 54 1F         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008C70                       1189 _dynamic_keymap_get_combo:
      008C70 E5 82            [12] 1190 	mov	a,dpl
      008C72 90 0B 5E         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008C75 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008C76 90 0B 5B         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008C79 12 37 F7         [24] 1195 	lcall	_ak820_outline_0052
                                   1196 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008C7C 90 0B 5E         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008C7F E0               [24] 1198 	movx	a,@dptr
      008C80 FD               [12] 1199 	mov	r5,a
      008C81 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      008C84                       1201 00132$:
      008C84 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:315: return -1;
      008C86 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008C89 22               [24] 1205 	ret
      008C8A                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008C8A 12 95 27         [24] 1208 	lcall	_ak820_outline_0080
                                   1209 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008C8D 8E 02            [24] 1210 	mov	ar2,r6
      008C8F 8F 03            [24] 1211 	mov	ar3,r7
      008C91 90 05 F0         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008C94 12 38 23         [24] 1213 	lcall	_ak820_outline_0072
      008C97 E4               [12] 1214 	clr	a
      008C98 A3               [24] 1215 	inc	dptr
      008C99 F0               [24] 1216 	movx	@dptr,a
      008C9A 90 05 F3         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008C9D 74 0A            [12] 1218 	mov	a,#0x0a
      008C9F 12 38 5C         [24] 1219 	lcall	_ak820_outline_0124
      008CA2 12 49 01         [24] 1220 	lcall	_ak820_outline_0141
      008CA5 C0 07            [24] 1221 	push	ar7
      008CA7 C0 06            [24] 1222 	push	ar6
      008CA9 12 46 38         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      008CAC D0 06            [24] 1224 	pop	ar6
      008CAE D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008CB0 74 04            [12] 1227 	mov	a,#0x04
      008CB2 12 4E 6A         [24] 1228 	lcall	_ak820_outline_0012
      008CB5 FA               [12] 1229 	mov	r2,a
      008CB6 A3               [24] 1230 	inc	dptr
      008CB7 E0               [24] 1231 	movx	a,@dptr
      008CB8 FB               [12] 1232 	mov	r3,a
      008CB9 BA 20 14         [24] 1233 	cjne	r2,#0x20,00108$
      008CBC BB 08 11         [24] 1234 	cjne	r3,#0x08,00108$
      008CBF 74 06            [12] 1235 	mov	a,#0x06
      008CC1 12 37 DE         [24] 1236 	lcall	_ak820_outline_0017
      008CC4 FA               [12] 1237 	mov	r2,a
      008CC5 A3               [24] 1238 	inc	dptr
      008CC6 E0               [24] 1239 	movx	a,@dptr
      008CC7 FB               [12] 1240 	mov	r3,a
      008CC8 BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      008CCB BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      008CCE 80 05            [24] 1243 	sjmp	00109$
      008CD0                       1244 00136$:
      008CD0                       1245 00108$:
      008CD0 75 2C 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008CD3 80 03            [24] 1247 	sjmp	00110$
      008CD5                       1248 00109$:
      008CD5 75 2C 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008CD8                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008CD8 74 06            [12] 1252 	mov	a,#0x06
      008CDA 12 37 EF         [24] 1253 	lcall	_ak820_outline_0031
      008CDD E4               [12] 1254 	clr	a
      008CDE F0               [24] 1255 	movx	@dptr,a
      008CDF A3               [24] 1256 	inc	dptr
      008CE0 12 38 35         [24] 1257 	lcall	_ak820_outline_0099
      008CE3 F0               [24] 1258 	movx	@dptr,a
      008CE4 A3               [24] 1259 	inc	dptr
      008CE5 F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008CE6 E5 2C            [12] 1262 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008CE8 60 12            [24] 1263 	jz	00103$
      008CEA 12 48 E5         [24] 1264 	lcall	_ak820_outline_0114
      008CED C0 07            [24] 1265 	push	ar7
      008CEF C0 06            [24] 1266 	push	ar6
      008CF1 12 34 68         [24] 1267 	lcall	_ak820_combo_valid
      008CF4 E5 82            [12] 1268 	mov	a, dpl
      008CF6 D0 06            [24] 1269 	pop	ar6
      008CF8 D0 07            [24] 1270 	pop	ar7
      008CFA 70 17            [24] 1271 	jnz	00104$
      008CFC                       1272 00103$:
      008CFC 7D 00            [12] 1273 	mov	r5,#0x00
      008CFE 90 0D F0         [24] 1274 	mov	dptr,#_memset_PARM_2
      008D01 E4               [12] 1275 	clr	a
      008D02 F0               [24] 1276 	movx	@dptr,a
      008D03 90 0D F1         [24] 1277 	mov	dptr,#_memset_PARM_3
      008D06 74 0A            [12] 1278 	mov	a,#0x0a
      008D08 F0               [24] 1279 	movx	@dptr,a
      008D09 E4               [12] 1280 	clr	a
      008D0A A3               [24] 1281 	inc	dptr
      008D0B 12 48 C0         [24] 1282 	lcall	_ak820_outline_0061
      008D0E 8D F0            [24] 1283 	mov	b, r5
      008D10 12 BE 24         [24] 1284 	lcall	_memset
      008D13                       1285 00104$:
                                   1286 ;	quantum/dynamic_keymap.c:329: return 0;
      008D13 90 00 00         [24] 1287 	mov	dptr,#0x0000
                                   1288 ;	quantum/dynamic_keymap.c:330: }
      008D16 22               [24] 1289 	ret
                                   1290 ;------------------------------------------------------------
                                   1291 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1292 ;------------------------------------------------------------
                                   1293 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1294 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1295 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1296 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1297 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1298 ;------------------------------------------------------------
                                   1299 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1300 ;	-----------------------------------------
                                   1301 ;	 function dynamic_keymap_set_combo
                                   1302 ;	-----------------------------------------
      008D17                       1303 _dynamic_keymap_set_combo:
      008D17 E5 82            [12] 1304 	mov	a,dpl
      008D19 90 0B 62         [24] 1305 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008D1C F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008D1D 90 0B 5F         [24] 1308 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008D20 12 37 97         [24] 1309 	lcall	_ak820_outline_0004
                                   1310 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008D23 C0 07            [24] 1311 	push	ar7
      008D25 C0 06            [24] 1312 	push	ar6
      008D27 12 34 68         [24] 1313 	lcall	_ak820_combo_valid
      008D2A E5 82            [12] 1314 	mov	a, dpl
      008D2C D0 06            [24] 1315 	pop	ar6
      008D2E D0 07            [24] 1316 	pop	ar7
      008D30 60 07            [24] 1317 	jz	00101$
      008D32 12 43 A4         [24] 1318 	lcall	_ak820_nvm_ok
      008D35 E5 82            [12] 1319 	mov	a, dpl
      008D37 70 04            [24] 1320 	jnz	00102$
      008D39                       1321 00101$:
      008D39 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      008D3C 22               [24] 1323 	ret
      008D3D                       1324 00102$:
                                   1325 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008D3D 90 0B 62         [24] 1326 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008D40 E0               [24] 1327 	movx	a,@dptr
      008D41 FD               [12] 1328 	mov	r5,a
      008D42 BD 08 00         [24] 1329 	cjne	r5,#0x08,00133$
      008D45                       1330 00133$:
      008D45 40 04            [24] 1331 	jc	00105$
                                   1332 ;	quantum/dynamic_keymap.c:342: return -1;
      008D47 90 FF FF         [24] 1333 	mov	dptr,#0xffff
      008D4A 22               [24] 1334 	ret
      008D4B                       1335 00105$:
                                   1336 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008D4B 12 95 27         [24] 1337 	lcall	_ak820_outline_0080
                                   1338 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008D4E C0 07            [24] 1339 	push	ar7
      008D50 C0 06            [24] 1340 	push	ar6
      008D52 C0 05            [24] 1341 	push	ar5
      008D54 C0 04            [24] 1342 	push	ar4
      008D56 12 7D E0         [24] 1343 	lcall	_clear_keyboard
      008D59 D0 04            [24] 1344 	pop	ar4
      008D5B D0 05            [24] 1345 	pop	ar5
      008D5D D0 06            [24] 1346 	pop	ar6
      008D5F D0 07            [24] 1347 	pop	ar7
                                   1348 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008D61 90 0D E8         [24] 1349 	mov	dptr,#___memcpy_PARM_2
      008D64 12 4E C4         [24] 1350 	lcall	_ak820_outline_0059
      008D67 E4               [12] 1351 	clr	a
      008D68 A3               [24] 1352 	inc	dptr
      008D69 F0               [24] 1353 	movx	@dptr,a
      008D6A 90 0D EB         [24] 1354 	mov	dptr,#___memcpy_PARM_3
      008D6D 74 0A            [12] 1355 	mov	a,#0x0a
      008D6F 12 38 5C         [24] 1356 	lcall	_ak820_outline_0124
      008D72 90 0B 63         [24] 1357 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008D75 F5 F0            [12] 1358 	mov	b,a
      008D77 C0 05            [24] 1359 	push	ar5
      008D79 C0 04            [24] 1360 	push	ar4
      008D7B 12 BD AE         [24] 1361 	lcall	___memcpy
      008D7E D0 04            [24] 1362 	pop	ar4
      008D80 D0 05            [24] 1363 	pop	ar5
                                   1364 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008D82 90 0B 67         [24] 1365 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008D85 74 20            [12] 1366 	mov	a,#0x20
      008D87 F0               [24] 1367 	movx	@dptr,a
      008D88 74 08            [12] 1368 	mov	a,#0x08
      008D8A A3               [24] 1369 	inc	dptr
      008D8B F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008D8C 90 0B 69         [24] 1372 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      008D8F 74 01            [12] 1373 	mov	a,#0x01
      008D91 12 38 5C         [24] 1374 	lcall	_ak820_outline_0124
                                   1375 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008D94 90 05 F9         [24] 1376 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008D97 12 38 23         [24] 1377 	lcall	_ak820_outline_0072
      008D9A E4               [12] 1378 	clr	a
      008D9B A3               [24] 1379 	inc	dptr
      008D9C F0               [24] 1380 	movx	@dptr,a
      008D9D 90 05 FC         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008DA0 74 0A            [12] 1382 	mov	a,#0x0a
      008DA2 12 38 5C         [24] 1383 	lcall	_ak820_outline_0124
      008DA5 90 0B 63         [24] 1384 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008DA8 12 46 C4         [24] 1385 	lcall	_ak820_eeprom_write_block_xdata
                                   1386 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008DAB 12 43 B3         [24] 1387 	lcall	_ak820_nvm_flush
                                   1388 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008DAE 12 43 A4         [24] 1389 	lcall	_ak820_nvm_ok
      008DB1 E5 82            [12] 1390 	mov	a, dpl
      008DB3 70 04            [24] 1391 	jnz	00107$
      008DB5 90 FF FF         [24] 1392 	mov	dptr,#0xffff
      008DB8 22               [24] 1393 	ret
      008DB9                       1394 00107$:
                                   1395 ;	quantum/dynamic_keymap.c:360: return 0;
      008DB9 90 00 00         [24] 1396 	mov	dptr,#0x0000
                                   1397 ;	quantum/dynamic_keymap.c:361: }
      008DBC 22               [24] 1398 	ret
                                   1399 ;------------------------------------------------------------
                                   1400 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1401 ;------------------------------------------------------------
                                   1402 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1403 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1404 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1405 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1406 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1407 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1408 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1409 ;------------------------------------------------------------
                                   1410 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1411 ;	-----------------------------------------
                                   1412 ;	 function dynamic_keymap_reset
                                   1413 ;	-----------------------------------------
      008DBD                       1414 _dynamic_keymap_reset:
                                   1415 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008DBD 90 0E 69         [24] 1416 	mov	dptr,#_vial_unlocked
      008DC0 E0               [24] 1417 	movx	a,@dptr
      008DC1 90 0B 6D         [24] 1418 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008DC4 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008DC5 90 0E 69         [24] 1421 	mov	dptr,#_vial_unlocked
      008DC8 74 01            [12] 1422 	mov	a,#0x01
      008DCA F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008DCB 7F 00            [12] 1425 	mov	r7,#0x00
      008DCD                       1426 00116$:
      008DCD BF 06 00         [24] 1427 	cjne	r7,#0x06,00198$
      008DD0                       1428 00198$:
      008DD0 40 02            [24] 1429 	jc	00199$
      008DD2 C1 7B            [12] 1430 	ajmp	00104$
      008DD4                       1431 00199$:
                                   1432 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008DD4 7E 00            [12] 1433 	mov	r6,#0x00
      008DD6                       1434 00110$:
      008DD6 BE 10 00         [24] 1435 	cjne	r6,#0x10,00200$
      008DD9                       1436 00200$:
      008DD9 50 4C            [24] 1437 	jnc	00102$
                                   1438 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008DDB 7D 00            [12] 1439 	mov	r5,#0x00
      008DDD                       1440 00107$:
      008DDD BD 08 00         [24] 1441 	cjne	r5,#0x08,00202$
      008DE0                       1442 00202$:
      008DE0 50 42            [24] 1443 	jnc	00111$
                                   1444 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008DE2 90 0C 09         [24] 1445 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008DE5 EE               [12] 1446 	mov	a,r6
      008DE6 F0               [24] 1447 	movx	@dptr,a
      008DE7 90 0C 0A         [24] 1448 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008DEA ED               [12] 1449 	mov	a,r5
      008DEB F0               [24] 1450 	movx	@dptr,a
      008DEC 8F 82            [24] 1451 	mov	dpl, r7
      008DEE C0 07            [24] 1452 	push	ar7
      008DF0 C0 06            [24] 1453 	push	ar6
      008DF2 C0 05            [24] 1454 	push	ar5
      008DF4 12 9D 52         [24] 1455 	lcall	_keycode_at_keymap_location_raw
      008DF7 AB 82            [24] 1456 	mov	r3, dpl
      008DF9 AC 83            [24] 1457 	mov	r4, dph
      008DFB D0 05            [24] 1458 	pop	ar5
      008DFD D0 06            [24] 1459 	pop	ar6
      008DFF D0 07            [24] 1460 	pop	ar7
      008E01 90 0B 4C         [24] 1461 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008E04 EE               [12] 1462 	mov	a,r6
      008E05 F0               [24] 1463 	movx	@dptr,a
      008E06 90 0B 4D         [24] 1464 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008E09 ED               [12] 1465 	mov	a,r5
      008E0A F0               [24] 1466 	movx	@dptr,a
      008E0B 90 0B 4E         [24] 1467 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008E0E 12 38 29         [24] 1468 	lcall	_ak820_outline_0078
      008E11 8F 82            [24] 1469 	mov	dpl, r7
      008E13 C0 07            [24] 1470 	push	ar7
      008E15 C0 06            [24] 1471 	push	ar6
      008E17 C0 05            [24] 1472 	push	ar5
      008E19 71 2D            [12] 1473 	acall	_dynamic_keymap_set_keycode
      008E1B D0 05            [24] 1474 	pop	ar5
      008E1D D0 06            [24] 1475 	pop	ar6
      008E1F D0 07            [24] 1476 	pop	ar7
                                   1477 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008E21 0D               [12] 1478 	inc	r5
      008E22 80 B9            [24] 1479 	sjmp	00107$
      008E24                       1480 00111$:
                                   1481 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008E24 0E               [12] 1482 	inc	r6
      008E25 80 AF            [24] 1483 	sjmp	00110$
      008E27                       1484 00102$:
                                   1485 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008E27 7E 00            [12] 1486 	mov	r6,#0x00
      008E29                       1487 00113$:
      008E29 BE 01 00         [24] 1488 	cjne	r6,#0x01,00204$
      008E2C                       1489 00204$:
      008E2C 50 4A            [24] 1490 	jnc	00117$
                                   1491 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008E2E 12 95 76         [24] 1492 	lcall	_ak820_outline_0175
      008E31 04               [12] 1493 	inc	a
      008E32 F0               [24] 1494 	movx	@dptr,a
      008E33 8F 82            [24] 1495 	mov	dpl, r7
      008E35 C0 07            [24] 1496 	push	ar7
      008E37 12 9D 97         [24] 1497 	lcall	_keycode_at_encodermap_location_raw
      008E3A 12 49 06         [24] 1498 	lcall	_ak820_outline_0142
      008E3D D0 07            [24] 1499 	pop	ar7
      008E3F 12 95 6D         [24] 1500 	lcall	_ak820_outline_0174
      008E42 04               [12] 1501 	inc	a
      008E43 F0               [24] 1502 	movx	@dptr,a
      008E44 90 0B 58         [24] 1503 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E47 12 38 23         [24] 1504 	lcall	_ak820_outline_0072
      008E4A 8F 82            [24] 1505 	mov	dpl, r7
      008E4C C0 07            [24] 1506 	push	ar7
      008E4E 91 05            [24] 1507 	acall	_dynamic_keymap_set_encoder
      008E50 D0 07            [24] 1508 	pop	ar7
                                   1509 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008E52 12 95 76         [24] 1510 	lcall	_ak820_outline_0175
      008E55 F0               [24] 1511 	movx	@dptr,a
      008E56 8F 82            [24] 1512 	mov	dpl, r7
      008E58 C0 07            [24] 1513 	push	ar7
      008E5A 12 9D 97         [24] 1514 	lcall	_keycode_at_encodermap_location_raw
      008E5D 12 49 06         [24] 1515 	lcall	_ak820_outline_0142
      008E60 D0 07            [24] 1516 	pop	ar7
      008E62 12 95 6D         [24] 1517 	lcall	_ak820_outline_0174
      008E65 F0               [24] 1518 	movx	@dptr,a
      008E66 90 0B 58         [24] 1519 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E69 12 38 23         [24] 1520 	lcall	_ak820_outline_0072
      008E6C 8F 82            [24] 1521 	mov	dpl, r7
      008E6E C0 07            [24] 1522 	push	ar7
      008E70 91 05            [24] 1523 	acall	_dynamic_keymap_set_encoder
      008E72 D0 07            [24] 1524 	pop	ar7
                                   1525 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008E74 7E 01            [12] 1526 	mov	r6,#0x01
      008E76 80 B1            [24] 1527 	sjmp	00113$
      008E78                       1528 00117$:
                                   1529 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008E78 0F               [12] 1530 	inc	r7
      008E79 A1 CD            [12] 1531 	ajmp	00116$
      008E7B                       1532 00104$:
                                   1533 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008E7B 90 0B 6E         [24] 1534 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008E7E 12 55 7E         [24] 1535 	lcall	_ak820_outline_0179
      008E81 90 0B 70         [24] 1536 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008E84 F0               [24] 1537 	movx	@dptr,a
      008E85 A3               [24] 1538 	inc	dptr
      008E86 F0               [24] 1539 	movx	@dptr,a
      008E87 90 0B 72         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      008E8A F0               [24] 1541 	movx	@dptr,a
      008E8B A3               [24] 1542 	inc	dptr
      008E8C F0               [24] 1543 	movx	@dptr,a
      008E8D 90 0B 74         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008E90 F0               [24] 1545 	movx	@dptr,a
      008E91 A3               [24] 1546 	inc	dptr
      008E92 F0               [24] 1547 	movx	@dptr,a
      008E93 90 0B 76         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008E96 F0               [24] 1549 	movx	@dptr,a
      008E97 A3               [24] 1550 	inc	dptr
      008E98 F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008E99 FF               [12] 1553 	mov	r7,a
      008E9A                       1554 00119$:
      008E9A BF 08 00         [24] 1555 	cjne	r7,#0x08,00206$
      008E9D                       1556 00206$:
      008E9D 50 16            [24] 1557 	jnc	00105$
                                   1558 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008E9F 90 0B 5F         [24] 1559 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008EA2 74 6E            [12] 1560 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      008EA4 F0               [24] 1561 	movx	@dptr,a
      008EA5 74 0B            [12] 1562 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      008EA7 12 38 4B         [24] 1563 	lcall	_ak820_outline_0117
      008EAA 8F 82            [24] 1564 	mov	dpl, r7
      008EAC C0 07            [24] 1565 	push	ar7
      008EAE B1 17            [24] 1566 	acall	_dynamic_keymap_set_combo
      008EB0 D0 07            [24] 1567 	pop	ar7
                                   1568 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008EB2 0F               [12] 1569 	inc	r7
      008EB3 80 E5            [24] 1570 	sjmp	00119$
      008EB5                       1571 00105$:
                                   1572 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008EB5 90 0B 6D         [24] 1573 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008EB8 E0               [24] 1574 	movx	a,@dptr
      008EB9 90 0E 69         [24] 1575 	mov	dptr,#_vial_unlocked
      008EBC F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/dynamic_keymap.c:468: }
      008EBD 22               [24] 1578 	ret
                                   1579 ;------------------------------------------------------------
                                   1580 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1581 ;------------------------------------------------------------
                                   1582 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1583 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1584 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1585 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1586 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1587 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1588 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1589 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1590 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1591 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1592 ;------------------------------------------------------------
                                   1593 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1594 ;	-----------------------------------------
                                   1595 ;	 function ak820_dynamic_read_buffer
                                   1596 ;	-----------------------------------------
      008EBE                       1597 _ak820_dynamic_read_buffer:
      008EBE 12 38 41         [24] 1598 	lcall	_ak820_outline_0104
      008EC1 90 0B 81         [24] 1599 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008EC4 12 38 46         [24] 1600 	lcall	_ak820_outline_0105
                                   1601 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008EC7 90 0B 7E         [24] 1602 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008ECA 12 37 F7         [24] 1603 	lcall	_ak820_outline_0052
                                   1604 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008ECD 90 0B 83         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008ED0 E4               [12] 1606 	clr	a
      008ED1 F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008ED2 90 0B 7C         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008ED5 12 38 16         [24] 1610 	lcall	_ak820_outline_0060
      008ED8 8C 02            [24] 1611 	mov	ar2,r4
      008EDA 8D 03            [24] 1612 	mov	ar3,r5
      008EDC C3               [12] 1613 	clr	c
      008EDD 74 1C            [12] 1614 	mov	a,#0x1c
      008EDF 9A               [12] 1615 	subb	a,r2
      008EE0 E4               [12] 1616 	clr	a
      008EE1 9B               [12] 1617 	subb	a,r3
      008EE2 50 01            [24] 1618 	jnc	00102$
                                   1619 ;	free result
      008EE4 22               [24] 1620 	ret
      008EE5                       1621 00102$:
                                   1622 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008EE5 90 0B 7A         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008EE8 12 48 EA         [24] 1624 	lcall	_ak820_outline_0120
      008EEB 90 0B 78         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008EEE 12 38 3B         [24] 1626 	lcall	_ak820_outline_0101
      008EF1 C3               [12] 1627 	clr	c
      008EF2 EA               [12] 1628 	mov	a,r2
      008EF3 98               [12] 1629 	subb	a,r0
      008EF4 EB               [12] 1630 	mov	a,r3
      008EF5 99               [12] 1631 	subb	a,r1
      008EF6 50 17            [24] 1632 	jnc	00104$
                                   1633 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008EF8 E8               [12] 1634 	mov	a,r0
      008EF9 C3               [12] 1635 	clr	c
      008EFA 9A               [12] 1636 	subb	a,r2
      008EFB F8               [12] 1637 	mov	r0,a
      008EFC E9               [12] 1638 	mov	a,r1
      008EFD 9B               [12] 1639 	subb	a,r3
      008EFE F9               [12] 1640 	mov	r1,a
                                   1641 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008EFF C3               [12] 1642 	clr	c
      008F00 E8               [12] 1643 	mov	a,r0
      008F01 9C               [12] 1644 	subb	a,r4
      008F02 E9               [12] 1645 	mov	a,r1
      008F03 9D               [12] 1646 	subb	a,r5
      008F04 40 04            [24] 1647 	jc	00114$
      008F06 8C 00            [24] 1648 	mov	ar0,r4
      008F08 8D 01            [24] 1649 	mov	ar1,r5
      008F0A                       1650 00114$:
      008F0A 90 0B 83         [24] 1651 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008F0D E8               [12] 1652 	mov	a,r0
      008F0E F0               [24] 1653 	movx	@dptr,a
      008F0F                       1654 00104$:
                                   1655 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008F0F 90 0B 83         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008F12 E0               [24] 1657 	movx	a,@dptr
      008F13 F5 2D            [12] 1658 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008F15 E0               [24] 1659 	movx	a,@dptr
      008F16 60 42            [24] 1660 	jz	00106$
      008F18 C0 04            [24] 1661 	push	ar4
      008F1A C0 05            [24] 1662 	push	ar5
      008F1C 8E 00            [24] 1663 	mov	ar0,r6
      008F1E 8F 05            [24] 1664 	mov	ar5,r7
      008F20 90 0B 81         [24] 1665 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008F23 E0               [24] 1666 	movx	a,@dptr
      008F24 F9               [12] 1667 	mov	r1,a
      008F25 A3               [24] 1668 	inc	dptr
      008F26 E0               [24] 1669 	movx	a,@dptr
      008F27 FC               [12] 1670 	mov	r4,a
      008F28 EA               [12] 1671 	mov	a,r2
      008F29 29               [12] 1672 	add	a, r1
      008F2A FA               [12] 1673 	mov	r2,a
      008F2B EB               [12] 1674 	mov	a,r3
      008F2C 3C               [12] 1675 	addc	a, r4
      008F2D FB               [12] 1676 	mov	r3,a
      008F2E 90 05 F0         [24] 1677 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008F31 EA               [12] 1678 	mov	a,r2
      008F32 F0               [24] 1679 	movx	@dptr,a
      008F33 EB               [12] 1680 	mov	a,r3
      008F34 12 38 4B         [24] 1681 	lcall	_ak820_outline_0117
      008F37 90 05 F3         [24] 1682 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008F3A E5 2D            [12] 1683 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008F3C 12 38 5C         [24] 1684 	lcall	_ak820_outline_0124
      008F3F 88 82            [24] 1685 	mov	dpl, r0
      008F41 8D 83            [24] 1686 	mov	dph, r5
      008F43 C0 07            [24] 1687 	push	ar7
      008F45 C0 06            [24] 1688 	push	ar6
      008F47 C0 05            [24] 1689 	push	ar5
      008F49 C0 04            [24] 1690 	push	ar4
      008F4B 12 46 38         [24] 1691 	lcall	_ak820_eeprom_read_block_xdata
      008F4E D0 04            [24] 1692 	pop	ar4
      008F50 D0 05            [24] 1693 	pop	ar5
      008F52 D0 06            [24] 1694 	pop	ar6
      008F54 D0 07            [24] 1695 	pop	ar7
                                   1696 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008F56 D0 05            [24] 1697 	pop	ar5
      008F58 D0 04            [24] 1698 	pop	ar4
                                   1699 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008F5A                       1700 00106$:
                                   1701 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008F5A 90 0B 83         [24] 1702 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008F5D E0               [24] 1703 	movx	a,@dptr
      008F5E FB               [12] 1704 	mov	r3,a
      008F5F                       1705 00109$:
      008F5F 8B 01            [24] 1706 	mov	ar1,r3
      008F61 7A 00            [12] 1707 	mov	r2,#0x00
      008F63 C3               [12] 1708 	clr	c
      008F64 E9               [12] 1709 	mov	a,r1
      008F65 9C               [12] 1710 	subb	a,r4
      008F66 EA               [12] 1711 	mov	a,r2
      008F67 9D               [12] 1712 	subb	a,r5
      008F68 50 09            [24] 1713 	jnc	00111$
      008F6A EB               [12] 1714 	mov	a,r3
      008F6B 12 37 EF         [24] 1715 	lcall	_ak820_outline_0031
      008F6E E4               [12] 1716 	clr	a
      008F6F F0               [24] 1717 	movx	@dptr,a
      008F70 0B               [12] 1718 	inc	r3
      008F71 80 EC            [24] 1719 	sjmp	00109$
      008F73                       1720 00111$:
                                   1721 ;	quantum/dynamic_keymap.c:483: }
      008F73 22               [24] 1722 	ret
                                   1723 ;------------------------------------------------------------
                                   1724 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1725 ;------------------------------------------------------------
                                   1726 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1727 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1728 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1729 ;------------------------------------------------------------
                                   1730 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1731 ;	-----------------------------------------
                                   1732 ;	 function dynamic_keymap_get_buffer
                                   1733 ;	-----------------------------------------
      008F74                       1734 _dynamic_keymap_get_buffer:
      008F74 12 38 41         [24] 1735 	lcall	_ak820_outline_0104
      008F77 90 0B 89         [24] 1736 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008F7A 12 38 46         [24] 1737 	lcall	_ak820_outline_0105
                                   1738 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008F7D 90 0B 89         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008F80 12 37 F7         [24] 1740 	lcall	_ak820_outline_0052
      008F83 90 0B 84         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008F86 12 38 16         [24] 1742 	lcall	_ak820_outline_0060
      008F89 90 0B 86         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008F8C 12 55 5E         [24] 1744 	lcall	_ak820_outline_0089
      008F8F 90 0B 78         [24] 1745 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F92 E4               [12] 1746 	clr	a
      008F93 F0               [24] 1747 	movx	@dptr,a
      008F94 74 06            [12] 1748 	mov	a,#0x06
      008F96 A3               [24] 1749 	inc	dptr
      008F97 F0               [24] 1750 	movx	@dptr,a
      008F98 90 0B 7A         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F9B 12 4E C4         [24] 1752 	lcall	_ak820_outline_0059
      008F9E 90 0B 7C         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008FA1 12 38 23         [24] 1754 	lcall	_ak820_outline_0072
      008FA4 90 0B 7E         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008FA7 E9               [12] 1756 	mov	a,r1
      008FA8 12 55 77         [24] 1757 	lcall	_ak820_outline_0152
      008FAB F0               [24] 1758 	movx	@dptr,a
      008FAC 90 00 40         [24] 1759 	mov	dptr,#0x0040
                                   1760 ;	quantum/dynamic_keymap.c:511: }
      008FAF 02 8E BE         [24] 1761 	ljmp	_ak820_dynamic_read_buffer
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1764 ;------------------------------------------------------------
                                   1765 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1766 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1767 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1768 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1769 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1770 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1771 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1772 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1773 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1774 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1775 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1776 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1777 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1778 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1779 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function dynamic_keymap_set_buffer
                                   1785 ;	-----------------------------------------
      008FB2                       1786 _dynamic_keymap_set_buffer:
      008FB2 12 38 41         [24] 1787 	lcall	_ak820_outline_0104
      008FB5 90 0B 90         [24] 1788 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008FB8 12 38 46         [24] 1789 	lcall	_ak820_outline_0105
                                   1790 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008FBB 90 0B 90         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008FBE 12 37 C2         [24] 1792 	lcall	_ak820_outline_0011
      008FC1 74 40            [12] 1793 	mov	a,#0x40
      008FC3 2C               [12] 1794 	add	a, r4
      008FC4 FA               [12] 1795 	mov	r2,a
      008FC5 E4               [12] 1796 	clr	a
      008FC6 3D               [12] 1797 	addc	a, r5
      008FC7 FB               [12] 1798 	mov	r3,a
                                   1799 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008FC8 90 0B 8D         [24] 1800 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008FCB 12 38 3B         [24] 1801 	lcall	_ak820_outline_0101
                                   1802 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008FCE 90 0B 8B         [24] 1803 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008FD1 E0               [24] 1804 	movx	a,@dptr
      008FD2 F5 2E            [12] 1805 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008FD4 A3               [24] 1806 	inc	dptr
      008FD5 E0               [24] 1807 	movx	a,@dptr
      008FD6 F5 2F            [12] 1808 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008FD8 E5 2E            [12] 1809 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008FDA 45 2F            [12] 1810 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008FDC 70 01            [24] 1811 	jnz	00102$
      008FDE 22               [24] 1812 	ret
      008FDF                       1813 00102$:
                                   1814 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008FDF 85 2E 30         [24] 1815 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008FE2 85 2F 31         [24] 1816 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008FE5 C3               [12] 1817 	clr	c
      008FE6 74 1C            [12] 1818 	mov	a,#0x1c
      008FE8 95 30            [12] 1819 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008FEA E4               [12] 1820 	clr	a
      008FEB 95 31            [12] 1821 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008FED 50 01            [24] 1822 	jnc	00104$
                                   1823 ;	free result
      008FEF 22               [24] 1824 	ret
      008FF0                       1825 00104$:
                                   1826 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008FF0 85 2E 32         [24] 1827 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1828 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008FF3 74 FA            [12] 1829 	mov	a,#0x100 - 0x06
      008FF5 2F               [12] 1830 	add	a,r7
      008FF6 40 11            [24] 1831 	jc	00105$
      008FF8 E4               [12] 1832 	clr	a
      008FF9 C3               [12] 1833 	clr	c
      008FFA 9E               [12] 1834 	subb	a,r6
      008FFB FE               [12] 1835 	mov	r6,a
      008FFC 74 06            [12] 1836 	mov	a,#0x06
      008FFE 9F               [12] 1837 	subb	a,r7
      008FFF FF               [12] 1838 	mov	r7,a
      009000 C3               [12] 1839 	clr	c
      009001 EE               [12] 1840 	mov	a,r6
      009002 95 2E            [12] 1841 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      009004 EF               [12] 1842 	mov	a,r7
      009005 95 2F            [12] 1843 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009007 50 01            [24] 1844 	jnc	00106$
      009009                       1845 00105$:
                                   1846 ;	quantum/dynamic_keymap.c:529: return;
      009009 22               [24] 1847 	ret
      00900A                       1848 00106$:
                                   1849 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      00900A 90 0E 69         [24] 1850 	mov	dptr,#_vial_unlocked
      00900D E0               [24] 1851 	movx	a,@dptr
      00900E 60 02            [24] 1852 	jz	00207$
      009010 21 1E            [12] 1853 	ajmp	00120$
      009012                       1854 00207$:
                                   1855 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      009012 90 0B 92         [24] 1856 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      009015 E4               [12] 1857 	clr	a
      009016 F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      009017 90 0B 93         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      00901A E5 32            [12] 1861 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00901C F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      00901D EC               [12] 1864 	mov	a,r4
      00901E 30 E0 33         [24] 1865 	jnb	acc.0,00111$
                                   1866 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      009021 EA               [12] 1867 	mov	a,r2
      009022 24 FF            [12] 1868 	add	a,#0xff
      009024 FE               [12] 1869 	mov	r6,a
      009025 EB               [12] 1870 	mov	a,r3
      009026 34 FF            [12] 1871 	addc	a,#0xff
      009028 FF               [12] 1872 	mov	r7,a
      009029 7D 00            [12] 1873 	mov	r5,#0x00
      00902B 12 48 E5         [24] 1874 	lcall	_ak820_outline_0114
      00902E 8D F0            [24] 1875 	mov	b, r5
      009030 12 45 FD         [24] 1876 	lcall	_eeprom_read_byte
      009033 AE 82            [24] 1877 	mov	r6,dpl
      009035 7F 00            [12] 1878 	mov	r7,#0x00
      009037 12 38 6C         [24] 1879 	lcall	_ak820_outline_0153
      00903A E0               [24] 1880 	movx	a,@dptr
      00903B 7C 00            [12] 1881 	mov	r4,#0x00
      00903D 42 07            [12] 1882 	orl	ar7,a
      00903F EC               [12] 1883 	mov	a,r4
      009040 42 06            [12] 1884 	orl	ar6,a
                                   1885 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      009042 BF 00 09         [24] 1886 	cjne	r7,#0x00,00109$
      009045 BE 7C 06         [24] 1887 	cjne	r6,#0x7c,00109$
                                   1888 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      009048 12 38 6C         [24] 1889 	lcall	_ak820_outline_0153
      00904B 74 FF            [12] 1890 	mov	a,#0xff
      00904D F0               [24] 1891 	movx	@dptr,a
      00904E                       1892 00109$:
                                   1893 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      00904E 90 0B 92         [24] 1894 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      009051 74 01            [12] 1895 	mov	a,#0x01
      009053 F0               [24] 1896 	movx	@dptr,a
      009054                       1897 00111$:
                                   1898 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      009054 90 0B 90         [24] 1899 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      009057 12 37 F7         [24] 1900 	lcall	_ak820_outline_0052
      00905A E5 2E            [12] 1901 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00905C 2E               [12] 1902 	add	a, r6
      00905D FE               [12] 1903 	mov	r6,a
      00905E E5 2F            [12] 1904 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009060 3F               [12] 1905 	addc	a, r7
      009061 EE               [12] 1906 	mov	a,r6
      009062 30 E0 5A         [24] 1907 	jnb	acc.0,00115$
                                   1908 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      009065 AE 32            [24] 1909 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      009067 7F 00            [12] 1910 	mov	r7,#0x00
      009069 EE               [12] 1911 	mov	a,r6
      00906A 24 FF            [12] 1912 	add	a,#0xff
      00906C FC               [12] 1913 	mov	r4,a
      00906D EF               [12] 1914 	mov	a,r7
      00906E 34 FF            [12] 1915 	addc	a,#0xff
      009070 FD               [12] 1916 	mov	r5,a
      009071 EC               [12] 1917 	mov	a,r4
      009072 28               [12] 1918 	add	a, r0
      009073 F5 82            [12] 1919 	mov	dpl,a
      009075 ED               [12] 1920 	mov	a,r5
      009076 39               [12] 1921 	addc	a, r1
      009077 F5 83            [12] 1922 	mov	dph,a
      009079 E0               [24] 1923 	movx	a,@dptr
      00907A FC               [12] 1924 	mov	r4,a
      00907B 7D 00            [12] 1925 	mov	r5,#0x00
      00907D E5 32            [12] 1926 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00907F 2A               [12] 1927 	add	a, r2
      009080 FA               [12] 1928 	mov	r2,a
      009081 E4               [12] 1929 	clr	a
      009082 3B               [12] 1930 	addc	a, r3
      009083 FB               [12] 1931 	mov	r3,a
      009084 C0 00            [24] 1932 	push	ar0
      009086 C0 01            [24] 1933 	push	ar1
      009088 8B 01            [24] 1934 	mov	ar1,r3
      00908A 7B 00            [12] 1935 	mov	r3,#0x00
      00908C 8A 82            [24] 1936 	mov	dpl, r2
      00908E 89 83            [24] 1937 	mov	dph, r1
      009090 8B F0            [24] 1938 	mov	b, r3
      009092 12 45 FD         [24] 1939 	lcall	_eeprom_read_byte
      009095 AB 82            [24] 1940 	mov	r3, dpl
      009097 7A 00            [12] 1941 	mov	r2,#0x00
      009099 EB               [12] 1942 	mov	a,r3
      00909A 12 48 FB         [24] 1943 	lcall	_ak820_outline_0140
                                   1944 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      00909D BD 00 05         [24] 1945 	cjne	r5,#0x00,00212$
      0090A0 BC 7C 02         [24] 1946 	cjne	r4,#0x7c,00212$
      0090A3 80 06            [24] 1947 	sjmp	00213$
      0090A5                       1948 00212$:
      0090A5 D0 01            [24] 1949 	pop	ar1
      0090A7 D0 00            [24] 1950 	pop	ar0
      0090A9 80 0D            [24] 1951 	sjmp	00113$
      0090AB                       1952 00213$:
      0090AB D0 01            [24] 1953 	pop	ar1
      0090AD D0 00            [24] 1954 	pop	ar0
                                   1955 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      0090AF 1E               [12] 1956 	dec	r6
      0090B0 BE FF 01         [24] 1957 	cjne	r6,#0xff,00214$
      0090B3 1F               [12] 1958 	dec	r7
      0090B4                       1959 00214$:
      0090B4 EE               [12] 1960 	mov	a,r6
      0090B5 12 95 4F         [24] 1961 	lcall	_ak820_outline_0128
      0090B8                       1962 00113$:
                                   1963 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      0090B8 E5 32            [12] 1964 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0090BA 14               [12] 1965 	dec	a
      0090BB 90 0B 93         [24] 1966 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0090BE F0               [24] 1967 	movx	@dptr,a
      0090BF                       1968 00115$:
                                   1969 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0090BF 90 0B 92         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0090C2 E0               [24] 1971 	movx	a,@dptr
      0090C3 90 0B 94         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0090C6 F0               [24] 1973 	movx	@dptr,a
      0090C7                       1974 00122$:
      0090C7 90 0B 94         [24] 1975 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0090CA E0               [24] 1976 	movx	a,@dptr
      0090CB FF               [12] 1977 	mov	r7,a
      0090CC 90 0B 93         [24] 1978 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0090CF E0               [24] 1979 	movx	a,@dptr
      0090D0 FE               [12] 1980 	mov	r6,a
      0090D1 C3               [12] 1981 	clr	c
      0090D2 EF               [12] 1982 	mov	a,r7
      0090D3 9E               [12] 1983 	subb	a,r6
      0090D4 50 48            [24] 1984 	jnc	00120$
                                   1985 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      0090D6 EF               [12] 1986 	mov	a,r7
      0090D7 28               [12] 1987 	add	a, r0
      0090D8 FD               [12] 1988 	mov	r5,a
      0090D9 E4               [12] 1989 	clr	a
      0090DA 39               [12] 1990 	addc	a, r1
      0090DB FE               [12] 1991 	mov	r6,a
      0090DC 12 4E CA         [24] 1992 	lcall	_ak820_outline_0076
      0090DF 7B 00            [12] 1993 	mov	r3,#0x00
      0090E1 8C 2F            [24] 1994 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      0090E3 8B 2E            [24] 1995 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      0090E5 8F 02            [24] 1996 	mov	ar2,r7
      0090E7 7F 00            [12] 1997 	mov	r7,#0x00
      0090E9 74 01            [12] 1998 	mov	a,#0x01
      0090EB 2A               [12] 1999 	add	a, r2
      0090EC FB               [12] 2000 	mov	r3,a
      0090ED E4               [12] 2001 	clr	a
      0090EE 3F               [12] 2002 	addc	a, r7
      0090EF FC               [12] 2003 	mov	r4,a
      0090F0 EB               [12] 2004 	mov	a,r3
      0090F1 28               [12] 2005 	add	a, r0
      0090F2 F5 82            [12] 2006 	mov	dpl,a
      0090F4 EC               [12] 2007 	mov	a,r4
      0090F5 39               [12] 2008 	addc	a, r1
      0090F6 F5 83            [12] 2009 	mov	dph,a
      0090F8 E0               [24] 2010 	movx	a,@dptr
      0090F9 FC               [12] 2011 	mov	r4,a
      0090FA 7B 00            [12] 2012 	mov	r3,#0x00
      0090FC E5 2F            [12] 2013 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0090FE 42 03            [12] 2014 	orl	ar3,a
                                   2015 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      009100 BC 00 12         [24] 2016 	cjne	r4,#0x00,00123$
      009103 BB 7C 0F         [24] 2017 	cjne	r3,#0x7c,00123$
                                   2018 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      009106 12 38 61         [24] 2019 	lcall	_ak820_outline_0133
      009109 74 FF            [12] 2020 	mov	a,#0xff
      00910B F0               [24] 2021 	movx	@dptr,a
                                   2022 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      00910C 0A               [12] 2023 	inc	r2
      00910D BA 00 01         [24] 2024 	cjne	r2,#0x00,00218$
      009110 0F               [12] 2025 	inc	r7
      009111                       2026 00218$:
      009111 EA               [12] 2027 	mov	a,r2
      009112 12 95 4F         [24] 2028 	lcall	_ak820_outline_0128
      009115                       2029 00123$:
                                   2030 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009115 90 0B 94         [24] 2031 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      009118 E0               [24] 2032 	movx	a,@dptr
      009119 24 02            [12] 2033 	add	a,#0x02
      00911B F0               [24] 2034 	movx	@dptr,a
      00911C 80 A9            [24] 2035 	sjmp	00122$
      00911E                       2036 00120$:
                                   2037 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      00911E 90 0B 90         [24] 2038 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      009121 12 37 F7         [24] 2039 	lcall	_ak820_outline_0052
      009124 74 40            [12] 2040 	mov	a,#0x40
      009126 12 48 F5         [24] 2041 	lcall	_ak820_outline_0135
      009129 90 05 F9         [24] 2042 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00912C 12 4E C4         [24] 2043 	lcall	_ak820_outline_0059
      00912F E4               [12] 2044 	clr	a
      009130 A3               [24] 2045 	inc	dptr
      009131 F0               [24] 2046 	movx	@dptr,a
      009132 90 05 FC         [24] 2047 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009135 E5 30            [12] 2048 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009137 F0               [24] 2049 	movx	@dptr,a
      009138 E5 31            [12] 2050 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00913A A3               [24] 2051 	inc	dptr
      00913B F0               [24] 2052 	movx	@dptr,a
      00913C 12 38 6C         [24] 2053 	lcall	_ak820_outline_0153
                                   2054 ;	quantum/dynamic_keymap.c:584: }
      00913F 02 46 C4         [24] 2055 	ljmp	_ak820_eeprom_write_block_xdata
                                   2056 ;------------------------------------------------------------
                                   2057 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2058 ;------------------------------------------------------------
                                   2059 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2060 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2061 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2062 ;------------------------------------------------------------
                                   2063 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2064 ;	-----------------------------------------
                                   2065 ;	 function keycode_at_keymap_location
                                   2066 ;	-----------------------------------------
      009142                       2067 _keycode_at_keymap_location:
      009142 E5 82            [12] 2068 	mov	a,dpl
      009144 90 0B 97         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      009147 F0               [24] 2070 	movx	@dptr,a
                                   2071 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      009148 E0               [24] 2072 	movx	a,@dptr
      009149 FF               [12] 2073 	mov	r7,a
      00914A BF 06 00         [24] 2074 	cjne	r7,#0x06,00128$
      00914D                       2075 00128$:
      00914D 50 23            [24] 2076 	jnc	00102$
      00914F 90 0B 95         [24] 2077 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009152 E0               [24] 2078 	movx	a,@dptr
      009153 FE               [12] 2079 	mov	r6,a
      009154 BE 10 00         [24] 2080 	cjne	r6,#0x10,00130$
      009157                       2081 00130$:
      009157 50 19            [24] 2082 	jnc	00102$
      009159 90 0B 96         [24] 2083 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00915C E0               [24] 2084 	movx	a,@dptr
      00915D FD               [12] 2085 	mov	r5,a
      00915E BD 08 00         [24] 2086 	cjne	r5,#0x08,00132$
      009161                       2087 00132$:
      009161 50 0F            [24] 2088 	jnc	00102$
                                   2089 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      009163 90 0B 49         [24] 2090 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009166 EE               [12] 2091 	mov	a,r6
      009167 F0               [24] 2092 	movx	@dptr,a
      009168 90 0B 4A         [24] 2093 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00916B ED               [12] 2094 	mov	a,r5
      00916C F0               [24] 2095 	movx	@dptr,a
      00916D 8F 82            [24] 2096 	mov	dpl, r7
      00916F 02 8A E0         [24] 2097 	ljmp	_dynamic_keymap_get_keycode
      009172                       2098 00102$:
                                   2099 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      009172 90 00 00         [24] 2100 	mov	dptr,#0x0000
                                   2101 ;	quantum/dynamic_keymap.c:591: }
      009175 22               [24] 2102 	ret
                                   2103 ;------------------------------------------------------------
                                   2104 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2105 ;------------------------------------------------------------
                                   2106 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2107 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2108 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2109 ;------------------------------------------------------------
                                   2110 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2111 ;	-----------------------------------------
                                   2112 ;	 function keycode_at_encodermap_location
                                   2113 ;	-----------------------------------------
      009176                       2114 _keycode_at_encodermap_location:
      009176 E5 82            [12] 2115 	mov	a,dpl
      009178 90 0B 9A         [24] 2116 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      00917B F0               [24] 2117 	movx	@dptr,a
                                   2118 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      00917C E0               [24] 2119 	movx	a,@dptr
      00917D FF               [12] 2120 	mov	r7,a
      00917E BF 06 00         [24] 2121 	cjne	r7,#0x06,00120$
      009181                       2122 00120$:
      009181 50 1E            [24] 2123 	jnc	00102$
      009183 90 0B 98         [24] 2124 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      009186 E0               [24] 2125 	movx	a,@dptr
      009187 FE               [12] 2126 	mov	r6,a
      009188 BE 01 00         [24] 2127 	cjne	r6,#0x01,00122$
      00918B                       2128 00122$:
      00918B 50 14            [24] 2129 	jnc	00102$
                                   2130 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      00918D 90 0B 99         [24] 2131 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      009190 E0               [24] 2132 	movx	a,@dptr
      009191 FE               [12] 2133 	mov	r6,a
      009192 90 0B 53         [24] 2134 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      009195 E4               [12] 2135 	clr	a
      009196 F0               [24] 2136 	movx	@dptr,a
      009197 90 0B 54         [24] 2137 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00919A EE               [12] 2138 	mov	a,r6
      00919B F0               [24] 2139 	movx	@dptr,a
      00919C 8F 82            [24] 2140 	mov	dpl, r7
      00919E 02 8B 9F         [24] 2141 	ljmp	_dynamic_keymap_get_encoder
      0091A1                       2142 00102$:
                                   2143 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      0091A1 90 00 00         [24] 2144 	mov	dptr,#0x0000
                                   2145 ;	quantum/dynamic_keymap.c:599: }
      0091A4 22               [24] 2146 	ret
                                   2147 ;------------------------------------------------------------
                                   2148 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2149 ;------------------------------------------------------------
                                   2150 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2151 ;	-----------------------------------------
                                   2152 ;	 function dynamic_keymap_macro_get_count
                                   2153 ;	-----------------------------------------
      0091A5                       2154 _dynamic_keymap_macro_get_count:
                                   2155 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0091A5 75 82 10         [24] 2156 	mov	dpl, #0x10
                                   2157 ;	quantum/dynamic_keymap.c:604: }
      0091A8 22               [24] 2158 	ret
                                   2159 ;------------------------------------------------------------
                                   2160 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2161 ;------------------------------------------------------------
                                   2162 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2163 ;	-----------------------------------------
                                   2164 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2165 ;	-----------------------------------------
      0091A9                       2166 _dynamic_keymap_macro_get_buffer_size:
                                   2167 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0091A9 90 20 00         [24] 2168 	mov	dptr,#0x2000
                                   2169 ;	quantum/dynamic_keymap.c:608: }
      0091AC 22               [24] 2170 	ret
                                   2171 ;------------------------------------------------------------
                                   2172 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2173 ;------------------------------------------------------------
                                   2174 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2175 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2176 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2177 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2178 ;------------------------------------------------------------
                                   2179 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2180 ;	-----------------------------------------
                                   2181 ;	 function dynamic_keymap_macro_get_buffer
                                   2182 ;	-----------------------------------------
      0091AD                       2183 _dynamic_keymap_macro_get_buffer:
      0091AD 12 38 41         [24] 2184 	lcall	_ak820_outline_0104
      0091B0 90 0B A0         [24] 2185 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      0091B3 12 38 46         [24] 2186 	lcall	_ak820_outline_0105
                                   2187 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      0091B6 12 2A DF         [24] 2188 	lcall	_ak820_macro_length
      0091B9 12 48 F0         [24] 2189 	lcall	_ak820_outline_0132
      0091BC 90 0B A0         [24] 2190 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      0091BF 12 38 16         [24] 2191 	lcall	_ak820_outline_0060
      0091C2 90 0B 9B         [24] 2192 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0091C5 E0               [24] 2193 	movx	a,@dptr
      0091C6 F5 33            [12] 2194 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0091C8 A3               [24] 2195 	inc	dptr
      0091C9 E0               [24] 2196 	movx	a,@dptr
      0091CA F5 34            [12] 2197 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0091CC 90 0B 9D         [24] 2198 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      0091CF 12 38 3B         [24] 2199 	lcall	_ak820_outline_0101
      0091D2 A3               [24] 2200 	inc	dptr
      0091D3 E0               [24] 2201 	movx	a,@dptr
      0091D4 FB               [12] 2202 	mov	r3,a
      0091D5 90 0B 78         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0091D8 12 4E C4         [24] 2204 	lcall	_ak820_outline_0059
      0091DB 90 0B 7A         [24] 2205 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0091DE 12 38 23         [24] 2206 	lcall	_ak820_outline_0072
      0091E1 90 0B 7C         [24] 2207 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0091E4 E5 33            [12] 2208 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      0091E6 F0               [24] 2209 	movx	@dptr,a
      0091E7 E5 34            [12] 2210 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      0091E9 A3               [24] 2211 	inc	dptr
      0091EA F0               [24] 2212 	movx	@dptr,a
      0091EB 90 0B 7E         [24] 2213 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0091EE E8               [12] 2214 	mov	a,r0
      0091EF F0               [24] 2215 	movx	@dptr,a
      0091F0 E9               [12] 2216 	mov	a,r1
      0091F1 A3               [24] 2217 	inc	dptr
      0091F2 F0               [24] 2218 	movx	@dptr,a
      0091F3 EB               [12] 2219 	mov	a,r3
      0091F4 A3               [24] 2220 	inc	dptr
      0091F5 F0               [24] 2221 	movx	@dptr,a
      0091F6 90 08 00         [24] 2222 	mov	dptr,#0x0800
                                   2223 ;	quantum/dynamic_keymap.c:635: }
      0091F9 02 8E BE         [24] 2224 	ljmp	_ak820_dynamic_read_buffer
                                   2225 ;------------------------------------------------------------
                                   2226 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2227 ;------------------------------------------------------------
                                   2228 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2229 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2230 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2231 ;------------------------------------------------------------
                                   2232 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2233 ;	-----------------------------------------
                                   2234 ;	 function dynamic_keymap_macro_set_buffer
                                   2235 ;	-----------------------------------------
      0091FC                       2236 _dynamic_keymap_macro_set_buffer:
      0091FC 12 38 41         [24] 2237 	lcall	_ak820_outline_0104
      0091FF 90 0B A7         [24] 2238 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      009202 12 38 46         [24] 2239 	lcall	_ak820_outline_0105
                                   2240 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009205 90 0B A7         [24] 2241 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      009208 12 37 F7         [24] 2242 	lcall	_ak820_outline_0052
      00920B 90 0B A2         [24] 2243 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00920E 12 38 16         [24] 2244 	lcall	_ak820_outline_0060
      009211 90 0B A4         [24] 2245 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009214 12 55 5E         [24] 2246 	lcall	_ak820_outline_0089
      009217 90 05 7F         [24] 2247 	mov	dptr,#_ak820_macro_write_PARM_2
      00921A 12 38 23         [24] 2248 	lcall	_ak820_outline_0072
      00921D 90 05 81         [24] 2249 	mov	dptr,#_ak820_macro_write_PARM_3
      009220 E9               [12] 2250 	mov	a,r1
      009221 12 55 77         [24] 2251 	lcall	_ak820_outline_0152
      009224 12 48 C0         [24] 2252 	lcall	_ak820_outline_0061
                                   2253 ;	quantum/dynamic_keymap.c:640: }
      009227 02 2A F9         [24] 2254 	ljmp	_ak820_macro_write
                                   2255 ;------------------------------------------------------------
                                   2256 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2257 ;------------------------------------------------------------
                                   2258 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2259 ;	-----------------------------------------
                                   2260 ;	 function dynamic_keymap_macro_reset
                                   2261 ;	-----------------------------------------
      00922A                       2262 _dynamic_keymap_macro_reset:
                                   2263 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2264 ;	quantum/dynamic_keymap.c:666: }
      00922A 02 2E 18         [24] 2265 	ljmp	_ak820_macro_reset
                                   2266 ;------------------------------------------------------------
                                   2267 ;Allocation info for local variables in function 'decode_keycode'
                                   2268 ;------------------------------------------------------------
                                   2269 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2270 ;------------------------------------------------------------
                                   2271 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2272 ;	-----------------------------------------
                                   2273 ;	 function decode_keycode
                                   2274 ;	-----------------------------------------
      00922D                       2275 _decode_keycode:
      00922D 12 38 41         [24] 2276 	lcall	_ak820_outline_0104
      009230 90 0B A9         [24] 2277 	mov	dptr,#_decode_keycode_kc_10000_454
      009233 12 38 46         [24] 2278 	lcall	_ak820_outline_0105
                                   2279 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009236 90 0B A9         [24] 2280 	mov	dptr,#_decode_keycode_kc_10000_454
      009239 12 37 C2         [24] 2281 	lcall	_ak820_outline_0011
      00923C C3               [12] 2282 	clr	c
      00923D E4               [12] 2283 	clr	a
      00923E 9C               [12] 2284 	subb	a,r4
      00923F 74 FF            [12] 2285 	mov	a,#0xff
      009241 9D               [12] 2286 	subb	a,r5
      009242 50 08            [24] 2287 	jnc	00102$
                                   2288 ;	free result
                                   2289 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009244 8C 05            [24] 2290 	mov	ar5,r4
      009246 7C 00            [12] 2291 	mov	r4,#0x00
      009248 12 38 57         [24] 2292 	lcall	_ak820_outline_0122
      00924B 22               [24] 2293 	ret
      00924C                       2294 00102$:
                                   2295 ;	quantum/dynamic_keymap.c:672: return kc;
      00924C 12 48 E5         [24] 2296 	lcall	_ak820_outline_0114
                                   2297 ;	quantum/dynamic_keymap.c:673: }
      00924F 22               [24] 2298 	ret
                                   2299 ;------------------------------------------------------------
                                   2300 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2301 ;------------------------------------------------------------
                                   2302 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2303 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2304 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2305 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2306 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2307 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2308 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2309 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2310 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2311 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2312 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2313 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2314 ;------------------------------------------------------------
                                   2315 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2316 ;	-----------------------------------------
                                   2317 ;	 function dynamic_keymap_macro_send
                                   2318 ;	-----------------------------------------
      009250                       2319 _dynamic_keymap_macro_send:
      009250 E5 82            [12] 2320 	mov	a,dpl
      009252 90 0B AB         [24] 2321 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      009255 F0               [24] 2322 	movx	@dptr,a
                                   2323 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      009256 90 0B AC         [24] 2324 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      009259 E0               [24] 2325 	movx	a,@dptr
      00925A 60 01            [24] 2326 	jz	00102$
      00925C 22               [24] 2327 	ret
      00925D                       2328 00102$:
                                   2329 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00925D 90 0B AB         [24] 2330 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      009260 E0               [24] 2331 	movx	a,@dptr
      009261 FF               [12] 2332 	mov	r7,a
      009262 BF 10 00         [24] 2333 	cjne	r7,#0x10,00422$
      009265                       2334 00422$:
      009265 40 01            [24] 2335 	jc	00104$
                                   2336 ;	quantum/dynamic_keymap.c:683: return;
      009267 22               [24] 2337 	ret
      009268                       2338 00104$:
                                   2339 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      009268 C0 07            [24] 2340 	push	ar7
      00926A 12 2A A6         [24] 2341 	lcall	_ak820_macro_ready
      00926D E5 82            [12] 2342 	mov	a, dpl
      00926F D0 07            [24] 2343 	pop	ar7
      009271 70 01            [24] 2344 	jnz	00106$
      009273 22               [24] 2345 	ret
      009274                       2346 00106$:
                                   2347 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      009274 90 0B AD         [24] 2348 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009277 E4               [12] 2349 	clr	a
      009278 F0               [24] 2350 	movx	@dptr,a
      009279 74 08            [12] 2351 	mov	a,#0x08
      00927B A3               [24] 2352 	inc	dptr
      00927C F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      00927D C0 07            [24] 2355 	push	ar7
      00927F 12 2A DF         [24] 2356 	lcall	_ak820_macro_length
      009282 AD 82            [24] 2357 	mov	r5, dpl
      009284 AE 83            [24] 2358 	mov	r6, dph
      009286 D0 07            [24] 2359 	pop	ar7
      009288 74 08            [12] 2360 	mov	a,#0x08
      00928A 2E               [12] 2361 	add	a, r6
      00928B FE               [12] 2362 	mov	r6,a
                                   2363 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      00928C 7B 00            [12] 2364 	mov	r3,#0x00
      00928E 7C 08            [12] 2365 	mov	r4,#0x08
      009290                       2366 00111$:
      009290 EF               [12] 2367 	mov	a,r7
      009291 60 31            [24] 2368 	jz	00113$
                                   2369 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      009293 EB               [12] 2370 	mov	a,r3
      009294 B5 05 05         [24] 2371 	cjne	a,ar5,00108$
      009297 EC               [12] 2372 	mov	a,r4
      009298 B5 06 01         [24] 2373 	cjne	a,ar6,00108$
                                   2374 ;	quantum/dynamic_keymap.c:717: return;
      00929B 22               [24] 2375 	ret
      00929C                       2376 00108$:
                                   2377 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      00929C 8B 01            [24] 2378 	mov	ar1,r3
      00929E 8C 02            [24] 2379 	mov	ar2,r4
      0092A0 8A 00            [24] 2380 	mov	ar0,r2
      0092A2 7A 00            [12] 2381 	mov	r2,#0x00
      0092A4 89 82            [24] 2382 	mov	dpl, r1
      0092A6 88 83            [24] 2383 	mov	dph, r0
      0092A8 8A F0            [24] 2384 	mov	b, r2
      0092AA 12 45 FD         [24] 2385 	lcall	_eeprom_read_byte
      0092AD E5 82            [12] 2386 	mov	a, dpl
      0092AF 70 06            [24] 2387 	jnz	00110$
                                   2388 ;	quantum/dynamic_keymap.c:720: --id;
      0092B1 1F               [12] 2389 	dec	r7
      0092B2 90 0B AB         [24] 2390 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0092B5 EF               [12] 2391 	mov	a,r7
      0092B6 F0               [24] 2392 	movx	@dptr,a
      0092B7                       2393 00110$:
                                   2394 ;	quantum/dynamic_keymap.c:722: ++p;
      0092B7 0B               [12] 2395 	inc	r3
      0092B8 BB 00 01         [24] 2396 	cjne	r3,#0x00,00429$
      0092BB 0C               [12] 2397 	inc	r4
      0092BC                       2398 00429$:
      0092BC 90 0B AD         [24] 2399 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0092BF 12 38 29         [24] 2400 	lcall	_ak820_outline_0078
      0092C2 80 CC            [24] 2401 	sjmp	00111$
      0092C4                       2402 00113$:
                                   2403 ;	quantum/dynamic_keymap.c:728: sending = true;
      0092C4 90 0B AC         [24] 2404 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0092C7 74 01            [12] 2405 	mov	a,#0x01
      0092C9 F0               [24] 2406 	movx	@dptr,a
                                   2407 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      0092CA 12 95 67         [24] 2408 	lcall	_ak820_outline_0161
      0092CD 90 09 F5         [24] 2409 	mov	dptr,#_ak820_macro_cancelled
      0092D0 F0               [24] 2410 	movx	@dptr,a
                                   2411 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      0092D1 90 0B AF         [24] 2412 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0092D4 F0               [24] 2413 	movx	@dptr,a
      0092D5 90 0B B0         [24] 2414 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0092D8 F0               [24] 2415 	movx	@dptr,a
      0092D9 90 0B B1         [24] 2416 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      0092DC F0               [24] 2417 	movx	@dptr,a
      0092DD 90 0B B2         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0092E0 F0               [24] 2419 	movx	@dptr,a
                                   2420 ;	quantum/dynamic_keymap.c:738: while (p < end
      0092E1                       2421 00167$:
                                   2422 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      0092E1 90 0B AD         [24] 2423 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0092E4 E0               [24] 2424 	movx	a,@dptr
      0092E5 FC               [12] 2425 	mov	r4,a
      0092E6 A3               [24] 2426 	inc	dptr
      0092E7 E0               [24] 2427 	movx	a,@dptr
      0092E8 FF               [12] 2428 	mov	r7,a
      0092E9 C3               [12] 2429 	clr	c
      0092EA EC               [12] 2430 	mov	a,r4
      0092EB 9D               [12] 2431 	subb	a,r5
      0092EC EF               [12] 2432 	mov	a,r7
      0092ED 9E               [12] 2433 	subb	a,r6
      0092EE 40 02            [24] 2434 	jc	00430$
      0092F0 81 F5            [12] 2435 	ajmp	00169$
      0092F2                       2436 00430$:
      0092F2 90 09 F5         [24] 2437 	mov	dptr,#_ak820_macro_cancelled
      0092F5 E0               [24] 2438 	movx	a,@dptr
      0092F6 60 02            [24] 2439 	jz	00431$
      0092F8 81 F5            [12] 2440 	ajmp	00169$
      0092FA                       2441 00431$:
                                   2442 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092FA 8C 02            [24] 2443 	mov	ar2,r4
      0092FC 8F 03            [24] 2444 	mov	ar3,r7
      0092FE 90 0B AD         [24] 2445 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009301 74 01            [12] 2446 	mov	a,#0x01
      009303 2C               [12] 2447 	add	a, r4
      009304 F0               [24] 2448 	movx	@dptr,a
      009305 E4               [12] 2449 	clr	a
      009306 3F               [12] 2450 	addc	a, r7
      009307 A3               [24] 2451 	inc	dptr
      009308 F0               [24] 2452 	movx	@dptr,a
      009309 7F 00            [12] 2453 	mov	r7,#0x00
      00930B 12 49 01         [24] 2454 	lcall	_ak820_outline_0141
      00930E 8F F0            [24] 2455 	mov	b, r7
      009310 12 45 FD         [24] 2456 	lcall	_eeprom_read_byte
      009313 AF 82            [24] 2457 	mov	r7, dpl
      009315 90 0B AF         [24] 2458 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009318 EF               [12] 2459 	mov	a,r7
      009319 F0               [24] 2460 	movx	@dptr,a
                                   2461 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00931A 90 0B B0         [24] 2462 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00931D E4               [12] 2463 	clr	a
      00931E F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      00931F 90 0B AF         [24] 2466 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009322 E0               [24] 2467 	movx	a,@dptr
      009323 70 02            [24] 2468 	jnz	00432$
      009325 81 F5            [12] 2469 	ajmp	00169$
      009327                       2470 00432$:
                                   2471 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009327 90 0B AF         [24] 2472 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00932A E0               [24] 2473 	movx	a,@dptr
      00932B FF               [12] 2474 	mov	r7,a
      00932C BF 01 02         [24] 2475 	cjne	r7,#0x01,00433$
      00932F 80 02            [24] 2476 	sjmp	00434$
      009331                       2477 00433$:
      009331 81 D8            [12] 2478 	ajmp	00164$
      009333                       2479 00434$:
                                   2480 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009333 12 94 FD         [24] 2481 	lcall	_ak820_outline_0000
      009336 12 45 FD         [24] 2482 	lcall	_eeprom_read_byte
      009339 AF 82            [24] 2483 	mov	r7, dpl
      00933B 90 0B B0         [24] 2484 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00933E EF               [12] 2485 	mov	a,r7
      00933F F0               [24] 2486 	movx	@dptr,a
                                   2487 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      009340 EF               [12] 2488 	mov	a,r7
      009341 70 02            [24] 2489 	jnz	00435$
      009343 81 F5            [12] 2490 	ajmp	00169$
      009345                       2491 00435$:
                                   2492 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009345 12 95 35         [24] 2493 	lcall	_ak820_outline_0092
      009348 BF 01 02         [24] 2494 	cjne	r7,#0x01,00436$
      00934B 80 12            [24] 2495 	sjmp	00151$
      00934D                       2496 00436$:
      00934D 12 95 35         [24] 2497 	lcall	_ak820_outline_0092
      009350 BF 02 02         [24] 2498 	cjne	r7,#0x02,00437$
      009353 80 0A            [24] 2499 	sjmp	00151$
      009355                       2500 00437$:
      009355 12 95 35         [24] 2501 	lcall	_ak820_outline_0092
      009358 BF 03 02         [24] 2502 	cjne	r7,#0x03,00438$
      00935B 80 02            [24] 2503 	sjmp	00439$
      00935D                       2504 00438$:
      00935D 61 BE            [12] 2505 	ajmp	00152$
      00935F                       2506 00439$:
      00935F                       2507 00151$:
                                   2508 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00935F 12 94 FD         [24] 2509 	lcall	_ak820_outline_0000
      009362 12 45 FD         [24] 2510 	lcall	_eeprom_read_byte
      009365 12 95 7F         [24] 2511 	lcall	_ak820_outline_0178
                                   2512 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      009368 70 02            [24] 2513 	jnz	00440$
      00936A 41 E1            [12] 2514 	ajmp	00167$
      00936C                       2515 00440$:
                                   2516 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      00936C 12 95 35         [24] 2517 	lcall	_ak820_outline_0092
      00936F BF 01 03         [24] 2518 	cjne	r7,#0x01,00441$
      009372 D3               [12] 2519 	setb	c
      009373 80 01            [24] 2520 	sjmp	00442$
      009375                       2521 00441$:
      009375 C3               [12] 2522 	clr	c
      009376                       2523 00442$:
      009376 92 24            [24] 2524 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009378 90 09 F4         [24] 2525 	mov	dptr,#_ak820_macro_primitive
      00937B B3               [12] 2526 	cpl	c
      00937C E4               [12] 2527 	clr	a
      00937D 33               [12] 2528 	rlc	a
      00937E F0               [24] 2529 	movx	@dptr,a
                                   2530 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      00937F 12 95 35         [24] 2531 	lcall	_ak820_outline_0092
      009382 BF 01 10         [24] 2532 	cjne	r7,#0x01,00122$
      009385 12 95 60         [24] 2533 	lcall	_ak820_outline_0148
      009388 C0 06            [24] 2534 	push	ar6
      00938A C0 05            [24] 2535 	push	ar5
      00938C 12 7D 74         [24] 2536 	lcall	_tap_code
      00938F D0 05            [24] 2537 	pop	ar5
      009391 D0 06            [24] 2538 	pop	ar6
      009393 80 24            [24] 2539 	sjmp	00123$
      009395                       2540 00122$:
                                   2541 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009395 12 95 35         [24] 2542 	lcall	_ak820_outline_0092
      009398 BF 02 10         [24] 2543 	cjne	r7,#0x02,00119$
      00939B 12 95 60         [24] 2544 	lcall	_ak820_outline_0148
      00939E C0 06            [24] 2545 	push	ar6
      0093A0 C0 05            [24] 2546 	push	ar5
      0093A2 12 7C 55         [24] 2547 	lcall	_register_code
      0093A5 D0 05            [24] 2548 	pop	ar5
      0093A7 D0 06            [24] 2549 	pop	ar6
      0093A9 80 0E            [24] 2550 	sjmp	00123$
      0093AB                       2551 00119$:
                                   2552 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0093AB 12 95 60         [24] 2553 	lcall	_ak820_outline_0148
      0093AE C0 06            [24] 2554 	push	ar6
      0093B0 C0 05            [24] 2555 	push	ar5
      0093B2 12 7C D1         [24] 2556 	lcall	_unregister_code
      0093B5 D0 05            [24] 2557 	pop	ar5
      0093B7 D0 06            [24] 2558 	pop	ar6
      0093B9                       2559 00123$:
                                   2560 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      0093B9 12 95 67         [24] 2561 	lcall	_ak820_outline_0161
      0093BC 41 E1            [12] 2562 	ajmp	00167$
      0093BE                       2563 00152$:
                                   2564 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0093BE 12 95 35         [24] 2565 	lcall	_ak820_outline_0092
      0093C1 BF 05 02         [24] 2566 	cjne	r7,#0x05,00447$
      0093C4 80 12            [24] 2567 	sjmp	00146$
      0093C6                       2568 00447$:
      0093C6 12 95 35         [24] 2569 	lcall	_ak820_outline_0092
      0093C9 BF 06 02         [24] 2570 	cjne	r7,#0x06,00448$
      0093CC 80 0A            [24] 2571 	sjmp	00146$
      0093CE                       2572 00448$:
      0093CE 12 95 35         [24] 2573 	lcall	_ak820_outline_0092
      0093D1 BF 07 02         [24] 2574 	cjne	r7,#0x07,00449$
      0093D4 80 02            [24] 2575 	sjmp	00450$
      0093D6                       2576 00449$:
      0093D6 81 7A            [12] 2577 	ajmp	00147$
      0093D8                       2578 00450$:
      0093D8                       2579 00146$:
                                   2580 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093D8 12 94 FD         [24] 2581 	lcall	_ak820_outline_0000
      0093DB 12 45 FD         [24] 2582 	lcall	_eeprom_read_byte
      0093DE 12 95 7F         [24] 2583 	lcall	_ak820_outline_0178
                                   2584 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      0093E1 70 02            [24] 2585 	jnz	00451$
      0093E3 41 E1            [12] 2586 	ajmp	00167$
      0093E5                       2587 00451$:
                                   2588 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093E5 12 94 FD         [24] 2589 	lcall	_ak820_outline_0000
      0093E8 12 45 FD         [24] 2590 	lcall	_eeprom_read_byte
      0093EB AF 82            [24] 2591 	mov	r7, dpl
      0093ED 90 0B B2         [24] 2592 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0093F0 EF               [12] 2593 	mov	a,r7
      0093F1 F0               [24] 2594 	movx	@dptr,a
                                   2595 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      0093F2 EF               [12] 2596 	mov	a,r7
      0093F3 70 02            [24] 2597 	jnz	00452$
      0093F5 41 E1            [12] 2598 	ajmp	00167$
      0093F7                       2599 00452$:
                                   2600 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      0093F7 90 0B B1         [24] 2601 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      0093FA E0               [24] 2602 	movx	a,@dptr
      0093FB FF               [12] 2603 	mov	r7,a
      0093FC 90 0B B2         [24] 2604 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      0093FF E0               [24] 2605 	movx	a,@dptr
      009400 FB               [12] 2606 	mov	r3,a
      009401 E4               [12] 2607 	clr	a
      009402 FC               [12] 2608 	mov	r4,a
      009403 FA               [12] 2609 	mov	r2,a
      009404 EF               [12] 2610 	mov	a,r7
      009405 42 04            [12] 2611 	orl	ar4,a
      009407 EA               [12] 2612 	mov	a,r2
      009408 42 03            [12] 2613 	orl	ar3,a
                                   2614 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00940A 12 49 21         [24] 2615 	lcall	_ak820_outline_0181
      00940D C0 06            [24] 2616 	push	ar6
      00940F C0 05            [24] 2617 	push	ar5
      009411 51 2D            [12] 2618 	acall	_decode_keycode
      009413 AC 82            [24] 2619 	mov	r4, dpl
      009415 AF 83            [24] 2620 	mov	r7, dph
      009417 D0 05            [24] 2621 	pop	ar5
      009419 D0 06            [24] 2622 	pop	ar6
                                   2623 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00941B 90 0B B0         [24] 2624 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00941E E0               [24] 2625 	movx	a,@dptr
      00941F FB               [12] 2626 	mov	r3,a
      009420 BB 05 03         [24] 2627 	cjne	r3,#0x05,00453$
      009423 D3               [12] 2628 	setb	c
      009424 80 01            [24] 2629 	sjmp	00454$
      009426                       2630 00453$:
      009426 C3               [12] 2631 	clr	c
      009427                       2632 00454$:
      009427 92 24            [24] 2633 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009429 90 09 F4         [24] 2634 	mov	dptr,#_ak820_macro_primitive
      00942C B3               [12] 2635 	cpl	c
      00942D E4               [12] 2636 	clr	a
      00942E 33               [12] 2637 	rlc	a
      00942F F0               [24] 2638 	movx	@dptr,a
                                   2639 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009430 90 0B B0         [24] 2640 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      009433 E0               [24] 2641 	movx	a,@dptr
      009434 FB               [12] 2642 	mov	r3,a
      009435 BB 05 02         [24] 2643 	cjne	r3,#0x05,00455$
      009438 80 0A            [24] 2644 	sjmp	00126$
      00943A                       2645 00455$:
      00943A BB 06 02         [24] 2646 	cjne	r3,#0x06,00456$
      00943D 80 16            [24] 2647 	sjmp	00127$
      00943F                       2648 00456$:
                                   2649 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      00943F BB 07 33         [24] 2650 	cjne	r3,#0x07,00129$
      009442 80 22            [24] 2651 	sjmp	00128$
      009444                       2652 00126$:
                                   2653 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009444 8C 82            [24] 2654 	mov	dpl, r4
      009446 8F 83            [24] 2655 	mov	dph, r7
      009448 C0 06            [24] 2656 	push	ar6
      00944A C0 05            [24] 2657 	push	ar5
      00944C 12 B7 B7         [24] 2658 	lcall	_vial_keycode_tap
      00944F D0 05            [24] 2659 	pop	ar5
      009451 D0 06            [24] 2660 	pop	ar6
                                   2661 ;	quantum/dynamic_keymap.c:795: break;
                                   2662 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      009453 80 20            [24] 2663 	sjmp	00129$
      009455                       2664 00127$:
                                   2665 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      009455 8C 82            [24] 2666 	mov	dpl, r4
      009457 8F 83            [24] 2667 	mov	dph, r7
      009459 C0 06            [24] 2668 	push	ar6
      00945B C0 05            [24] 2669 	push	ar5
      00945D 12 B6 EC         [24] 2670 	lcall	_vial_keycode_down
      009460 D0 05            [24] 2671 	pop	ar5
      009462 D0 06            [24] 2672 	pop	ar6
                                   2673 ;	quantum/dynamic_keymap.c:798: break;
                                   2674 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      009464 80 0F            [24] 2675 	sjmp	00129$
      009466                       2676 00128$:
                                   2677 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      009466 8C 82            [24] 2678 	mov	dpl, r4
      009468 8F 83            [24] 2679 	mov	dph, r7
      00946A C0 06            [24] 2680 	push	ar6
      00946C C0 05            [24] 2681 	push	ar5
      00946E 12 B7 52         [24] 2682 	lcall	_vial_keycode_up
      009471 D0 05            [24] 2683 	pop	ar5
      009473 D0 06            [24] 2684 	pop	ar6
                                   2685 ;	quantum/dynamic_keymap.c:802: }
      009475                       2686 00129$:
                                   2687 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      009475 12 95 67         [24] 2688 	lcall	_ak820_outline_0161
      009478 41 E1            [12] 2689 	ajmp	00167$
      00947A                       2690 00147$:
                                   2691 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      00947A 12 95 35         [24] 2692 	lcall	_ak820_outline_0092
      00947D BF 04 02         [24] 2693 	cjne	r7,#0x04,00458$
      009480 80 02            [24] 2694 	sjmp	00459$
      009482                       2695 00458$:
      009482 41 E1            [12] 2696 	ajmp	00167$
      009484                       2697 00459$:
                                   2698 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009484 12 94 FD         [24] 2699 	lcall	_ak820_outline_0000
      009487 12 45 FD         [24] 2700 	lcall	_eeprom_read_byte
      00948A AF 82            [24] 2701 	mov	r7, dpl
                                   2702 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00948C 90 0B AD         [24] 2703 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00948F 12 38 51         [24] 2704 	lcall	_ak820_outline_0121
      009492 90 0B AD         [24] 2705 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009495 74 01            [12] 2706 	mov	a,#0x01
      009497 2B               [12] 2707 	add	a, r3
      009498 F0               [24] 2708 	movx	@dptr,a
      009499 E4               [12] 2709 	clr	a
      00949A 3C               [12] 2710 	addc	a, r4
      00949B A3               [24] 2711 	inc	dptr
      00949C F0               [24] 2712 	movx	@dptr,a
      00949D 7A 00            [12] 2713 	mov	r2,#0x00
      00949F 12 33 FC         [24] 2714 	lcall	_ak820_outline_0123
      0094A2 8A F0            [24] 2715 	mov	b, r2
      0094A4 12 45 FD         [24] 2716 	lcall	_eeprom_read_byte
      0094A7 AC 82            [24] 2717 	mov	r4, dpl
                                   2718 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0094A9 EF               [12] 2719 	mov	a,r7
      0094AA 60 49            [24] 2720 	jz	00169$
      0094AC EC               [12] 2721 	mov	a,r4
      0094AD 60 46            [24] 2722 	jz	00169$
                                   2723 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0094AF 1F               [12] 2724 	dec	r7
      0094B0 1C               [12] 2725 	dec	r4
      0094B1 EC               [12] 2726 	mov	a,r4
      0094B2 75 F0 FF         [24] 2727 	mov	b,#0xff
      0094B5 A4               [48] 2728 	mul	ab
      0094B6 FC               [12] 2729 	mov	r4,a
      0094B7 AB F0            [24] 2730 	mov	r3,b
      0094B9 7A 00            [12] 2731 	mov	r2,#0x00
      0094BB EC               [12] 2732 	mov	a,r4
      0094BC 2F               [12] 2733 	add	a, r7
      0094BD FC               [12] 2734 	mov	r4,a
      0094BE EB               [12] 2735 	mov	a,r3
      0094BF 3A               [12] 2736 	addc	a, r2
      0094C0 FB               [12] 2737 	mov	r3,a
                                   2738 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      0094C1                       2739 00141$:
      0094C1 8C 02            [24] 2740 	mov	ar2,r4
      0094C3 8B 07            [24] 2741 	mov	ar7,r3
      0094C5 1C               [12] 2742 	dec	r4
      0094C6 BC FF 01         [24] 2743 	cjne	r4,#0xff,00462$
      0094C9 1B               [12] 2744 	dec	r3
      0094CA                       2745 00462$:
      0094CA EA               [12] 2746 	mov	a,r2
      0094CB 4F               [12] 2747 	orl	a,r7
      0094CC 70 02            [24] 2748 	jnz	00463$
      0094CE 41 E1            [12] 2749 	ajmp	00167$
      0094D0                       2750 00463$:
      0094D0 90 00 01         [24] 2751 	mov	dptr,#0x0001
      0094D3 12 5E E8         [24] 2752 	lcall	_mDelaymS
      0094D6 80 E9            [24] 2753 	sjmp	00141$
      0094D8                       2754 00164$:
                                   2755 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      0094D8 90 0B AF         [24] 2756 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0094DB E0               [24] 2757 	movx	a,@dptr
      0094DC FF               [12] 2758 	mov	r7,a
      0094DD BF 80 00         [24] 2759 	cjne	r7,#0x80,00464$
      0094E0                       2760 00464$:
      0094E0 50 13            [24] 2761 	jnc	00169$
                                   2762 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      0094E2 90 0B AF         [24] 2763 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0094E5 E0               [24] 2764 	movx	a,@dptr
      0094E6 F5 82            [12] 2765 	mov	dpl,a
      0094E8 C0 06            [24] 2766 	push	ar6
      0094EA C0 05            [24] 2767 	push	ar5
      0094EC 12 AA 6F         [24] 2768 	lcall	_send_char
      0094EF D0 05            [24] 2769 	pop	ar5
      0094F1 D0 06            [24] 2770 	pop	ar6
                                   2771 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      0094F3 41 E1            [12] 2772 	ajmp	00167$
      0094F5                       2773 00169$:
                                   2774 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      0094F5 12 95 67         [24] 2775 	lcall	_ak820_outline_0161
                                   2776 ;	quantum/dynamic_keymap.c:837: sending = false;
      0094F8 90 0B AC         [24] 2777 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0094FB F0               [24] 2778 	movx	@dptr,a
                                   2779 ;	quantum/dynamic_keymap.c:839: }
      0094FC 22               [24] 2780 	ret
                                   2781 	.area CSEG    (CODE)
                                   2782 	.area CONST   (CODE)
                                   2783 	.area XINIT   (CODE)
                                   2784 	.area CABS    (ABS,CODE)
                                   2785 
                                   2786 ; Experimental exact instruction outlining.
                                   2787 	.globl _ak820_outline_0000
                                   2788 	.globl _ak820_outline_0004
                                   2789 	.globl _ak820_outline_0011
                                   2790 	.globl _ak820_outline_0012
                                   2791 	.globl _ak820_outline_0017
                                   2792 	.globl _ak820_outline_0025
                                   2793 	.globl _ak820_outline_0031
                                   2794 	.globl _ak820_outline_0045
                                   2795 	.globl _ak820_outline_0052
                                   2796 	.globl _ak820_outline_0059
                                   2797 	.globl _ak820_outline_0060
                                   2798 	.globl _ak820_outline_0061
                                   2799 	.globl _ak820_outline_0072
                                   2800 	.globl _ak820_outline_0076
                                   2801 	.globl _ak820_outline_0078
                                   2802 	.globl _ak820_outline_0080
                                   2803 	.globl _ak820_outline_0089
                                   2804 	.globl _ak820_outline_0092
                                   2805 	.globl _ak820_outline_0098
                                   2806 	.globl _ak820_outline_0099
                                   2807 	.globl _ak820_outline_0101
                                   2808 	.globl _ak820_outline_0104
                                   2809 	.globl _ak820_outline_0105
                                   2810 	.globl _ak820_outline_0112
                                   2811 	.globl _ak820_outline_0114
                                   2812 	.globl _ak820_outline_0117
                                   2813 	.globl _ak820_outline_0120
                                   2814 	.globl _ak820_outline_0121
                                   2815 	.globl _ak820_outline_0122
                                   2816 	.globl _ak820_outline_0123
                                   2817 	.globl _ak820_outline_0124
                                   2818 	.globl _ak820_outline_0128
                                   2819 	.globl _ak820_outline_0132
                                   2820 	.globl _ak820_outline_0133
                                   2821 	.globl _ak820_outline_0134
                                   2822 	.globl _ak820_outline_0135
                                   2823 	.globl _ak820_outline_0140
                                   2824 	.globl _ak820_outline_0141
                                   2825 	.globl _ak820_outline_0142
                                   2826 	.globl _ak820_outline_0148
                                   2827 	.globl _ak820_outline_0152
                                   2828 	.globl _ak820_outline_0153
                                   2829 	.globl _ak820_outline_0156
                                   2830 	.globl _ak820_outline_0161
                                   2831 	.globl _ak820_outline_0174
                                   2832 	.globl _ak820_outline_0175
                                   2833 	.globl _ak820_outline_0178
                                   2834 	.globl _ak820_outline_0179
                                   2835 	.globl _ak820_outline_0180
                                   2836 	.globl _ak820_outline_0181
                                   2837 	.globl _ak820_outline_0185
                                   2838 
                                   2839 	.area CSEG (CODE)
                                   2840 ; function ak820_outline_0000
      0094FD                       2841 _ak820_outline_0000:
      0094FD 90 0B AD         [24] 2842 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009500 E0               [24] 2843 	movx	a,@dptr
      009501 FC               [12] 2844 	mov	r4,a
      009502 A3               [24] 2845 	inc	dptr
      009503 E0               [24] 2846 	movx	a,@dptr
      009504 FF               [12] 2847 	mov	r7,a
      009505 90 0B AD         [24] 2848 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009508 74 01            [12] 2849 	mov	a,#0x01
      00950A 2C               [12] 2850 	add	a,r4
      00950B F0               [24] 2851 	movx	@dptr,a
      00950C E4               [12] 2852 	clr	a
      00950D 3F               [12] 2853 	addc	a,r7
      00950E A3               [24] 2854 	inc	dptr
      00950F F0               [24] 2855 	movx	@dptr,a
      009510 7B 00            [12] 2856 	mov	r3,#0x00
      009512 8C 82            [24] 2857 	mov	dpl,r4
      009514 8F 83            [24] 2858 	mov	dph,r7
      009516 8B F0            [24] 2859 	mov	b,r3
      009518 22               [24] 2860 	ret
                                   2861 
                                   2862 	.area CSEG (CODE)
                                   2863 ; function ak820_outline_0025
      009519                       2864 _ak820_outline_0025:
      009519 2D               [12] 2865 	add	a,r5
      00951A F9               [12] 2866 	mov	r1,a
      00951B E4               [12] 2867 	clr	a
      00951C 3E               [12] 2868 	addc	a,r6
      00951D FA               [12] 2869 	mov	r2,a
      00951E 8F 03            [24] 2870 	mov	ar3,r7
      009520 89 82            [24] 2871 	mov	dpl,r1
      009522 8A 83            [24] 2872 	mov	dph,r2
      009524 8B F0            [24] 2873 	mov	b,r3
      009526 22               [24] 2874 	ret
                                   2875 
                                   2876 	.area CSEG (CODE)
                                   2877 ; function ak820_outline_0080
      009527                       2878 _ak820_outline_0080:
      009527 ED               [12] 2879 	mov	a,r5
      009528 75 F0 0A         [24] 2880 	mov	b,#0x0a
      00952B A4               [48] 2881 	mul	ab
      00952C 24 58            [12] 2882 	add	a,#0x58
      00952E FC               [12] 2883 	mov	r4,a
      00952F 74 06            [12] 2884 	mov	a,#0x06
      009531 35 F0            [12] 2885 	addc	a,b
      009533 FD               [12] 2886 	mov	r5,a
      009534 22               [24] 2887 	ret
                                   2888 
                                   2889 	.area CSEG (CODE)
                                   2890 ; function ak820_outline_0092
      009535                       2891 _ak820_outline_0092:
      009535 90 0B B0         [24] 2892 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      009538 E0               [24] 2893 	movx	a,@dptr
      009539 FF               [12] 2894 	mov	r7,a
      00953A 22               [24] 2895 	ret
                                   2896 
                                   2897 	.area CSEG (CODE)
                                   2898 ; function ak820_outline_0098
      00953B                       2899 _ak820_outline_0098:
      00953B 90 0B 46         [24] 2900 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00953E EE               [12] 2901 	mov	a,r6
      00953F F0               [24] 2902 	movx	@dptr,a
      009540 90 0B 47         [24] 2903 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009543 ED               [12] 2904 	mov	a,r5
      009544 F0               [24] 2905 	movx	@dptr,a
      009545 8F 82            [24] 2906 	mov	dpl,r7
      009547 22               [24] 2907 	ret
                                   2908 
                                   2909 	.area CSEG (CODE)
                                   2910 ; function ak820_outline_0112
      009548                       2911 _ak820_outline_0112:
      009548 AD 82            [24] 2912 	mov	r5,dpl
      00954A AE 83            [24] 2913 	mov	r6,dph
      00954C AF F0            [24] 2914 	mov	r7,b
      00954E 22               [24] 2915 	ret
                                   2916 
                                   2917 	.area CSEG (CODE)
                                   2918 ; function ak820_outline_0128
      00954F                       2919 _ak820_outline_0128:
      00954F 28               [12] 2920 	add	a,r0
      009550 F5 82            [12] 2921 	mov	dpl,a
      009552 EF               [12] 2922 	mov	a,r7
      009553 39               [12] 2923 	addc	a,r1
      009554 F5 83            [12] 2924 	mov	dph,a
      009556 74 FF            [12] 2925 	mov	a,#0xff
      009558 F0               [24] 2926 	movx	@dptr,a
      009559 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0134
      00955A                       2931 _ak820_outline_0134:
      00955A 2D               [12] 2932 	add	a,r5
      00955B F9               [12] 2933 	mov	r1,a
      00955C E4               [12] 2934 	clr	a
      00955D 3E               [12] 2935 	addc	a,r6
      00955E FA               [12] 2936 	mov	r2,a
      00955F 22               [24] 2937 	ret
                                   2938 
                                   2939 	.area CSEG (CODE)
                                   2940 ; function ak820_outline_0148
      009560                       2941 _ak820_outline_0148:
      009560 90 0B B1         [24] 2942 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      009563 E0               [24] 2943 	movx	a,@dptr
      009564 F5 82            [12] 2944 	mov	dpl,a
      009566 22               [24] 2945 	ret
                                   2946 
                                   2947 	.area CSEG (CODE)
                                   2948 ; function ak820_outline_0161
      009567                       2949 _ak820_outline_0161:
      009567 90 09 F4         [24] 2950 	mov	dptr,#_ak820_macro_primitive
      00956A E4               [12] 2951 	clr	a
      00956B F0               [24] 2952 	movx	@dptr,a
      00956C 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0174
      00956D                       2957 _ak820_outline_0174:
      00956D 90 0B 56         [24] 2958 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009570 E4               [12] 2959 	clr	a
      009571 F0               [24] 2960 	movx	@dptr,a
      009572 90 0B 57         [24] 2961 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009575 22               [24] 2962 	ret
                                   2963 
                                   2964 	.area CSEG (CODE)
                                   2965 ; function ak820_outline_0175
      009576                       2966 _ak820_outline_0175:
      009576 90 0C 0C         [24] 2967 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009579 E4               [12] 2968 	clr	a
      00957A F0               [24] 2969 	movx	@dptr,a
      00957B 90 0C 0D         [24] 2970 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      00957E 22               [24] 2971 	ret
                                   2972 
                                   2973 	.area CSEG (CODE)
                                   2974 ; function ak820_outline_0178
      00957F                       2975 _ak820_outline_0178:
      00957F AF 82            [24] 2976 	mov	r7,dpl
      009581 90 0B B1         [24] 2977 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      009584 EF               [12] 2978 	mov	a,r7
      009585 F0               [24] 2979 	movx	@dptr,a
      009586 EF               [12] 2980 	mov	a,r7
      009587 22               [24] 2981 	ret
