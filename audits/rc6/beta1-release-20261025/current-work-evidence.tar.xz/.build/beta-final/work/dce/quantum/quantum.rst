                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_combo_tick
                                     18 	.globl _ak820_leader_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _register_code16
                                    284 	.globl _unregister_code16
                                    285 	.globl _reset_keyboard
                                    286 	.globl _soft_reset_keyboard
                                    287 	.globl _get_record_keycode
                                    288 	.globl _pre_process_record_quantum
                                    289 	.globl _process_record_quantum
                                    290 	.globl _process_record_quantum_helper
                                    291 	.globl _shutdown_user
                                    292 ;--------------------------------------------------------
                                    293 ; special function registers
                                    294 ;--------------------------------------------------------
                                    295 	.area RSEG    (ABS,DATA)
      000000                        296 	.org 0x0000
                           0000D0   297 _PSW	=	0x00d0
                           0000E0   298 _ACC	=	0x00e0
                           0000F0   299 _B	=	0x00f0
                           0000FD   300 _A_INV	=	0x00fd
                           000081   301 _SP	=	0x0081
                           000082   302 _DPL	=	0x0082
                           000083   303 _DPH	=	0x0083
                           0000A1   304 _SAFE_MOD	=	0x00a1
                           0000B1   305 _GLOBAL_CFG	=	0x00b1
                           000087   306 _PCON	=	0x0087
                           0000BA   307 _POWER_CFG	=	0x00ba
                           0000B9   308 _CLOCK_CFG	=	0x00b9
                           0000A9   309 _WAKE_CTRL	=	0x00a9
                           0000FE   310 _RESET_KEEP	=	0x00fe
                           0000FF   311 _WDOG_COUNT	=	0x00ff
                           0000A8   312 _IE	=	0x00a8
                           0000B8   313 _IP	=	0x00b8
                           0000E8   314 _IE_EX	=	0x00e8
                           0000E9   315 _IP_EX	=	0x00e9
                           0000B2   316 _GPIO_IE	=	0x00b2
                           008584   317 _ROM_ADDR	=	0x8584
                           000084   318 _ROM_ADDR_L	=	0x0084
                           000085   319 _ROM_ADDR_H	=	0x0085
                           008F8E   320 _ROM_DATA_HI	=	0x8f8e
                           00008E   321 _ROM_DATA_HL	=	0x008e
                           00008F   322 _ROM_DATA_HH	=	0x008f
                           000086   323 _ROM_CTRL	=	0x0086
                           000080   324 _P0	=	0x0080
                           0000C4   325 _P0_MOD_OC	=	0x00c4
                           0000C5   326 _P0_DIR_PU	=	0x00c5
                           000090   327 _P1	=	0x0090
                           000092   328 _P1_MOD_OC	=	0x0092
                           000093   329 _P1_DIR_PU	=	0x0093
                           0000A0   330 _P2	=	0x00a0
                           000094   331 _P2_MOD_OC	=	0x0094
                           000095   332 _P2_DIR_PU	=	0x0095
                           0000B0   333 _P3	=	0x00b0
                           000096   334 _P3_MOD_OC	=	0x0096
                           000097   335 _P3_DIR_PU	=	0x0097
                           0000C0   336 _P4	=	0x00c0
                           0000C2   337 _P4_MOD_OC	=	0x00c2
                           0000C3   338 _P4_DIR_PU	=	0x00c3
                           0000C1   339 _P4_LED_KEY	=	0x00c1
                           0000AA   340 _P5_IN	=	0x00aa
                           0000AB   341 _P5_OUT_PU	=	0x00ab
                           0000AC   342 _P5_DIR	=	0x00ac
                           0000AD   343 _P6_IN	=	0x00ad
                           0000AE   344 _P6_OUT_PU	=	0x00ae
                           0000AF   345 _P6_DIR	=	0x00af
                           0000F1   346 _P7	=	0x00f1
                           0000A2   347 _XBUS_AUX	=	0x00a2
                           000088   348 _TCON	=	0x0088
                           000089   349 _TMOD	=	0x0089
                           00008A   350 _TL0	=	0x008a
                           00008B   351 _TL1	=	0x008b
                           00008C   352 _TH0	=	0x008c
                           00008D   353 _TH1	=	0x008d
                           000098   354 _SCON	=	0x0098
                           000099   355 _SBUF	=	0x0099
                           0000C8   356 _T2CON	=	0x00c8
                           0000C9   357 _T2MOD	=	0x00c9
                           00CBCA   358 _RCAP2	=	0xcbca
                           0000CA   359 _RCAP2L	=	0x00ca
                           0000CB   360 _RCAP2H	=	0x00cb
                           00CDCC   361 _T2COUNT	=	0xcdcc
                           0000CC   362 _TL2	=	0x00cc
                           0000CD   363 _TH2	=	0x00cd
                           00CFCE   364 _T2CAP1	=	0xcfce
                           0000CE   365 _T2CAP1L	=	0x00ce
                           0000CF   366 _T2CAP1H	=	0x00cf
                           0000F8   367 _SPI0_STAT	=	0x00f8
                           0000F9   368 _SPI0_DATA	=	0x00f9
                           0000FA   369 _SPI0_CTRL	=	0x00fa
                           0000FB   370 _SPI0_CK_SE	=	0x00fb
                           0000FC   371 _SPI0_SETUP	=	0x00fc
                           0000BC   372 _SCON1	=	0x00bc
                           0000BD   373 _SBUF1	=	0x00bd
                           0000BE   374 _SBAUD1	=	0x00be
                           0000BF   375 _SIF1	=	0x00bf
                           0000B4   376 _SPI1_STAT	=	0x00b4
                           0000B5   377 _SPI1_DATA	=	0x00b5
                           0000B6   378 _SPI1_CTRL	=	0x00b6
                           0000B7   379 _SPI1_CK_SE	=	0x00b7
                           0000F3   380 _ADC_CTRL	=	0x00f3
                           00F5F4   381 _ADC_DAT	=	0xf5f4
                           0000F4   382 _ADC_DAT_L	=	0x00f4
                           0000F5   383 _ADC_DAT_H	=	0x00f5
                           0000F6   384 _ADC_CHAN	=	0x00f6
                           0000A6   385 _LED_COMMON	=	0x00a6
                           0000A7   386 _LED_PWM_OE	=	0x00a7
                           00C7C6   387 _LED_DMA	=	0xc7c6
                           0000C6   388 _LED_DMA_L	=	0x00c6
                           0000C7   389 _LED_DMA_H	=	0x00c7
                           0000F7   390 _LED_STATUS	=	0x00f7
                           0000B3   391 _I2CX_INT	=	0x00b3
                           0000BB   392 _I2CS_INT_ST	=	0x00bb
                                    393 ;--------------------------------------------------------
                                    394 ; special function bits
                                    395 ;--------------------------------------------------------
                                    396 	.area RSEG    (ABS,DATA)
      000000                        397 	.org 0x0000
                           0000D7   398 _CY	=	0x00d7
                           0000D6   399 _AC	=	0x00d6
                           0000D5   400 _F0	=	0x00d5
                           0000D4   401 _RS1	=	0x00d4
                           0000D3   402 _RS0	=	0x00d3
                           0000D2   403 _OV	=	0x00d2
                           0000D1   404 _F1	=	0x00d1
                           0000D0   405 _P	=	0x00d0
                           0000AF   406 _EA	=	0x00af
                           0000AE   407 _E_DIS	=	0x00ae
                           0000AD   408 _ET2	=	0x00ad
                           0000AC   409 _ES	=	0x00ac
                           0000AB   410 _ET1	=	0x00ab
                           0000AA   411 _EX1	=	0x00aa
                           0000A9   412 _ET0	=	0x00a9
                           0000A8   413 _EX0	=	0x00a8
                           0000BF   414 _PH_FLAG	=	0x00bf
                           0000BE   415 _PL_FLAG	=	0x00be
                           0000BD   416 _PT2	=	0x00bd
                           0000BC   417 _PS	=	0x00bc
                           0000BB   418 _PT1	=	0x00bb
                           0000BA   419 _PX1	=	0x00ba
                           0000B9   420 _PT0	=	0x00b9
                           0000B8   421 _PX0	=	0x00b8
                           0000EF   422 _IE_WDOG	=	0x00ef
                           0000EE   423 _IE_GPIO	=	0x00ee
                           0000ED   424 _IE_PWM_I2C	=	0x00ed
                           0000EC   425 _IE_UART1	=	0x00ec
                           0000EB   426 _IE_ADC	=	0x00eb
                           0000E9   427 _IE_USB	=	0x00e9
                           0000E8   428 _IE_SPI0	=	0x00e8
                           000087   429 _P0_7	=	0x0087
                           000086   430 _P0_6	=	0x0086
                           000085   431 _P0_5	=	0x0085
                           000084   432 _P0_4	=	0x0084
                           000083   433 _P0_3	=	0x0083
                           000082   434 _P0_2	=	0x0082
                           000081   435 _P0_1	=	0x0081
                           000080   436 _P0_0	=	0x0080
                           000081   437 _SDA0	=	0x0081
                           000080   438 _SCL0	=	0x0080
                           000083   439 _TXD_	=	0x0083
                           000082   440 _RXD_	=	0x0082
                           000085   441 _AIN13	=	0x0085
                           000084   442 _AIN12	=	0x0084
                           000083   443 _AIN11	=	0x0083
                           000082   444 _AIN10	=	0x0082
                           000081   445 _AIN9	=	0x0081
                           000080   446 _AIN8	=	0x0080
                           000097   447 _P1_7	=	0x0097
                           000096   448 _P1_6	=	0x0096
                           000095   449 _P1_5	=	0x0095
                           000094   450 _P1_4	=	0x0094
                           000093   451 _P1_3	=	0x0093
                           000092   452 _P1_2	=	0x0092
                           000091   453 _P1_1	=	0x0091
                           000090   454 _P1_0	=	0x0090
                           000097   455 _TXD1_	=	0x0097
                           000096   456 _RXD1_	=	0x0096
                           000097   457 _SCK	=	0x0097
                           000096   458 _MISO	=	0x0096
                           000095   459 _MOSI	=	0x0095
                           000094   460 _SCS	=	0x0094
                           000092   461 _INT0_	=	0x0092
                           000091   462 _T2EX	=	0x0091
                           000091   463 _CAP2	=	0x0091
                           000090   464 _T2	=	0x0090
                           000090   465 _CAP1	=	0x0090
                           000097   466 _AIN7	=	0x0097
                           000096   467 _AIN6	=	0x0096
                           000095   468 _AIN5	=	0x0095
                           000094   469 _AIN4	=	0x0094
                           000093   470 _AIN3	=	0x0093
                           000092   471 _AIN2	=	0x0092
                           000091   472 _AIN1	=	0x0091
                           000090   473 _AIN0	=	0x0090
                           0000A7   474 _P2_7	=	0x00a7
                           0000A6   475 _P2_6	=	0x00a6
                           0000A5   476 _P2_5	=	0x00a5
                           0000A4   477 _P2_4	=	0x00a4
                           0000A3   478 _P2_3	=	0x00a3
                           0000A2   479 _P2_2	=	0x00a2
                           0000A1   480 _P2_1	=	0x00a1
                           0000A0   481 _P2_0	=	0x00a0
                           0000A7   482 _TXD1	=	0x00a7
                           0000A6   483 _RXD1	=	0x00a6
                           0000A5   484 _T2EX_	=	0x00a5
                           0000A5   485 _CAP2_	=	0x00a5
                           0000A4   486 _T2_	=	0x00a4
                           0000A4   487 _CAP1_	=	0x00a4
                           0000B7   488 _P3_7	=	0x00b7
                           0000B6   489 _P3_6	=	0x00b6
                           0000B5   490 _P3_5	=	0x00b5
                           0000B4   491 _P3_4	=	0x00b4
                           0000B3   492 _P3_3	=	0x00b3
                           0000B2   493 _P3_2	=	0x00b2
                           0000B1   494 _P3_1	=	0x00b1
                           0000B0   495 _P3_0	=	0x00b0
                           0000B7   496 _SCK1	=	0x00b7
                           0000B6   497 _MISO1	=	0x00b6
                           0000B5   498 _MOSI1	=	0x00b5
                           0000B5   499 _T1	=	0x00b5
                           0000B4   500 _T0	=	0x00b4
                           0000B3   501 _INT1	=	0x00b3
                           0000B2   502 _INT0	=	0x00b2
                           0000B1   503 _TXD	=	0x00b1
                           0000B0   504 _RXD	=	0x00b0
                           0000C6   505 _P4_6	=	0x00c6
                           0000C5   506 _P4_5	=	0x00c5
                           0000C4   507 _P4_4	=	0x00c4
                           0000C3   508 _P4_3	=	0x00c3
                           0000C2   509 _P4_2	=	0x00c2
                           0000C1   510 _P4_1	=	0x00c1
                           0000C0   511 _P4_0	=	0x00c0
                           00008F   512 _TF1	=	0x008f
                           00008E   513 _TR1	=	0x008e
                           00008D   514 _TF0	=	0x008d
                           00008C   515 _TR0	=	0x008c
                           00008B   516 _IE1	=	0x008b
                           00008A   517 _IT1	=	0x008a
                           000089   518 _IE0	=	0x0089
                           000088   519 _IT0	=	0x0088
                           00009F   520 _SM0	=	0x009f
                           00009E   521 _SM1	=	0x009e
                           00009D   522 _SM2	=	0x009d
                           00009C   523 _REN	=	0x009c
                           00009B   524 _TB8	=	0x009b
                           00009A   525 _RB8	=	0x009a
                           000099   526 _TI	=	0x0099
                           000098   527 _RI	=	0x0098
                           0000CF   528 _TF2	=	0x00cf
                           0000CF   529 _CAP1F	=	0x00cf
                           0000CE   530 _EXF2	=	0x00ce
                           0000CD   531 _RCLK	=	0x00cd
                           0000CC   532 _TCLK	=	0x00cc
                           0000CB   533 _EXEN2	=	0x00cb
                           0000CA   534 _TR2	=	0x00ca
                           0000C9   535 _C_T2	=	0x00c9
                           0000C8   536 _CP_RL2	=	0x00c8
                           0000FF   537 _S0_FST_ACT	=	0x00ff
                           0000FE   538 _S0_IF_OV	=	0x00fe
                           0000FD   539 _S0_IF_FIRST	=	0x00fd
                           0000FC   540 _S0_IF_BYTE	=	0x00fc
                           0000FB   541 _S0_FREE	=	0x00fb
                           0000FA   542 _S0_T_FIFO	=	0x00fa
                           0000F8   543 _S0_R_FIFO	=	0x00f8
                           0000F7   544 _ADC_START	=	0x00f7
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable register banks
                                    547 ;--------------------------------------------------------
                                    548 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        549 	.ds 8
                                    550 ;--------------------------------------------------------
                                    551 ; internal ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area DSEG    (DATA)
                                    554 ;--------------------------------------------------------
                                    555 ; overlayable items in internal ram
                                    556 ;--------------------------------------------------------
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000025                        570 _get_record_keycode_sloc0_1_0:
      000025                        571 	.ds 1
      000026                        572 _pre_process_record_quantum_sloc0_1_0:
      000026                        573 	.ds 1
      000027                        574 _process_ak820_nkro_sloc0_1_0:
      000027                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      000C44                        584 _extract_mod_bits_code_10000_602:
      000C44                        585 	.ds 2
      000C46                        586 _register_code16_code_10000_608:
      000C46                        587 	.ds 2
      000C48                        588 _unregister_code16_code_10000_613:
      000C48                        589 	.ds 2
      000C4A                        590 _get_record_keycode_PARM_2:
      000C4A                        591 	.ds 1
      000C4B                        592 _get_record_keycode_record_argument_10000_651:
      000C4B                        593 	.ds 2
      000C4D                        594 _pre_process_record_quantum_record_argument_10000_657:
      000C4D                        595 	.ds 2
      000C4F                        596 _process_record_quantum_record_10000_663:
      000C4F                        597 	.ds 2
      000C51                        598 _process_ak820_nkro_PARM_2:
      000C51                        599 	.ds 3
      000C54                        600 _process_ak820_nkro_keycode_10000_665:
      000C54                        601 	.ds 2
      000C56                        602 _process_record_quantum_helper_PARM_2:
      000C56                        603 	.ds 2
      000C58                        604 _process_record_quantum_helper_keycode_10000_670:
      000C58                        605 	.ds 2
      000C5A                        606 _get_u8_str_last_num_10000_696:
      000C5A                        607 	.ds 1
      000C5B                        608 _get_u16_str_last_num_10000_700:
      000C5B                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
                                    618 	.area HOME    (CODE)
                                    619 	.area GSINIT0 (CODE)
                                    620 	.area GSINIT1 (CODE)
                                    621 	.area GSINIT2 (CODE)
                                    622 	.area GSINIT3 (CODE)
                                    623 	.area GSINIT4 (CODE)
                                    624 	.area GSINIT5 (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area CSEG    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; global & static initialisations
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 	.area GSFINAL (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'get_u8_str'
                                    637 ;------------------------------------------------------------
                                    638 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    639 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_695'
                                    640 ;buf           Allocated with name '_get_u8_str_buf_10000_696'
                                    641 ;last_num      Allocated with name '_get_u8_str_last_num_10000_696'
                                    642 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_696'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C 5A         [24]  645 	mov	dptr,#_get_u8_str_last_num_10000_696
      0030F6 74 FF            [12]  646 	mov	a,#0xff
      0030F8 F0               [24]  647 	movx	@dptr,a
                                    648 ;------------------------------------------------------------
                                    649 ;Allocation info for local variables in function 'get_u16_str'
                                    650 ;------------------------------------------------------------
                                    651 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    652 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_699'
                                    653 ;buf           Allocated with name '_get_u16_str_buf_10000_700'
                                    654 ;last_num      Allocated with name '_get_u16_str_last_num_10000_700'
                                    655 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_700'
                                    656 ;------------------------------------------------------------
                                    657 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C 5B         [24]  658 	mov	dptr,#_get_u16_str_last_num_10000_700
      0030FC 74 FF            [12]  659 	mov	a,#0xff
      0030FE F0               [24]  660 	movx	@dptr,a
      0030FF E4               [12]  661 	clr	a
      003100 A3               [24]  662 	inc	dptr
      003101 F0               [24]  663 	movx	@dptr,a
                                    664 ;--------------------------------------------------------
                                    665 ; Home
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area HOME    (CODE)
                                    669 ;--------------------------------------------------------
                                    670 ; code
                                    671 ;--------------------------------------------------------
                                    672 	.area CSEG    (CODE)
                                    673 ;------------------------------------------------------------
                                    674 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    675 ;------------------------------------------------------------
                                    676 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    679 ;	-----------------------------------------
                           000007   680 	ar7 = 0x07
                           000006   681 	ar6 = 0x06
                           000005   682 	ar5 = 0x05
                           000004   683 	ar4 = 0x04
                           000003   684 	ar3 = 0x03
                           000002   685 	ar2 = 0x02
                           000001   686 	ar1 = 0x01
                           000000   687 	ar0 = 0x00
                                    688 ;	 function extract_mod_bits
                                    689 ;	-----------------------------------------
      00A3B5                        690 _extract_mod_bits:
      00A3B5 12 38 41         [24]  691 	lcall	_ak820_outline_0104
      00A3B8 90 0C 44         [24]  692 	mov	dptr,#_extract_mod_bits_code_10000_602
      00A3BB 12 38 46         [24]  693 	lcall	_ak820_outline_0105
                                    694 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A3BE 90 0C 44         [24]  695 	mov	dptr,#_extract_mod_bits_code_10000_602
      00A3C1 E0               [24]  696 	movx	a,@dptr
      00A3C2 A3               [24]  697 	inc	dptr
      00A3C3 E0               [24]  698 	movx	a,@dptr
                                    699 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A3C4 FF               [12]  700 	mov	r7,a
      00A3C5 60 05            [24]  701 	jz	00101$
      00A3C7 EF               [12]  702 	mov	a,r7
      00A3C8 24 E0            [12]  703 	add	a,#0xff - 0x1f
      00A3CA 50 04            [24]  704 	jnc	00102$
                                    705 ;	free result
      00A3CC                        706 00101$:
      00A3CC 75 82 00         [24]  707 	mov	dpl, #0x00
      00A3CF 22               [24]  708 	ret
      00A3D0                        709 00102$:
                                    710 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A3D0 EF               [12]  711 	mov	a,r7
      00A3D1 30 E4 07         [24]  712 	jnb	acc.4,00106$
      00A3D4 EF               [12]  713 	mov	a,r7
      00A3D5 C4               [12]  714 	swap	a
      00A3D6 54 F0            [12]  715 	anl	a,#0xf0
      00A3D8 FE               [12]  716 	mov	r6,a
      00A3D9 80 02            [24]  717 	sjmp	00107$
      00A3DB                        718 00106$:
      00A3DB 8F 06            [24]  719 	mov	ar6,r7
      00A3DD                        720 00107$:
      00A3DD 8E 82            [24]  721 	mov	dpl, r6
                                    722 ;	quantum/quantum.c:143: }
      00A3DF 22               [24]  723 	ret
                                    724 ;------------------------------------------------------------
                                    725 ;Allocation info for local variables in function 'do_code16'
                                    726 ;------------------------------------------------------------
                                    727 ;f             Allocated with name '_do_code16_PARM_2'
                                    728 ;code          Allocated with name '_do_code16_code_10000_605'
                                    729 ;------------------------------------------------------------
                                    730 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    731 ;	-----------------------------------------
                                    732 ;	 function register_code16
                                    733 ;	-----------------------------------------
      00A3E0                        734 _register_code16:
      00A3E0 12 38 41         [24]  735 	lcall	_ak820_outline_0104
      00A3E3 90 0C 46         [24]  736 	mov	dptr,#_register_code16_code_10000_608
      00A3E6 12 38 46         [24]  737 	lcall	_ak820_outline_0105
                                    738 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A3E9 90 0C 46         [24]  739 	mov	dptr,#_register_code16_code_10000_608
      00A3EC 12 37 97         [24]  740 	lcall	_ak820_outline_0004
      00A3EF C0 07            [24]  741 	push	ar7
      00A3F1 C0 06            [24]  742 	push	ar6
      00A3F3 71 B5            [12]  743 	acall	_extract_mod_bits
      00A3F5 AD 82            [24]  744 	mov	r5, dpl
      00A3F7 D0 06            [24]  745 	pop	ar6
      00A3F9 D0 07            [24]  746 	pop	ar7
                                    747 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A3FB 12 A1 F7         [24]  748 	lcall	_ak820_outline_0115
      00A3FE 40 07            [24]  749 	jc	00105$
      00A400 74 E7            [12]  750 	mov	a,#0xe7
      00A402 9E               [12]  751 	subb	a,r6
      00A403 E4               [12]  752 	clr	a
      00A404 9F               [12]  753 	subb	a,r7
      00A405 50 08            [24]  754 	jnc	00101$
                                    755 ;	free result
      00A407                        756 00105$:
      00A407 90 0C 46         [24]  757 	mov	dptr,#_register_code16_code_10000_608
      00A40A 12 74 87         [24]  758 	lcall	_ak820_outline_0036
      00A40D 70 07            [24]  759 	jnz	00102$
      00A40F                        760 00101$:
                                    761 ;	quantum/quantum.c:153: register_mods(mods);
      00A40F 8D 82            [24]  762 	mov	dpl, r5
      00A411 12 7D 90         [24]  763 	lcall	_register_mods
      00A414 80 05            [24]  764 	sjmp	00103$
      00A416                        765 00102$:
                                    766 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A416 8D 82            [24]  767 	mov	dpl, r5
      00A418 12 7D B8         [24]  768 	lcall	_register_weak_mods
      00A41B                        769 00103$:
                                    770 ;	quantum/quantum.c:157: register_code(code);
      00A41B 90 0C 46         [24]  771 	mov	dptr,#_register_code16_code_10000_608
      00A41E E0               [24]  772 	movx	a,@dptr
      00A41F F5 82            [12]  773 	mov	dpl,a
                                    774 ;	quantum/quantum.c:167: }
      00A421 02 7C 55         [24]  775 	ljmp	_register_code
                                    776 ;------------------------------------------------------------
                                    777 ;Allocation info for local variables in function 'unregister_code16'
                                    778 ;------------------------------------------------------------
                                    779 ;code          Allocated with name '_unregister_code16_code_10000_613'
                                    780 ;mods          Allocated with name '_unregister_code16_mods_10000_614'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function unregister_code16
                                    785 ;	-----------------------------------------
      00A424                        786 _unregister_code16:
      00A424 12 38 41         [24]  787 	lcall	_ak820_outline_0104
      00A427 90 0C 48         [24]  788 	mov	dptr,#_unregister_code16_code_10000_613
      00A42A 12 38 46         [24]  789 	lcall	_ak820_outline_0105
                                    790 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A42D 90 0C 48         [24]  791 	mov	dptr,#_unregister_code16_code_10000_613
      00A430 12 37 97         [24]  792 	lcall	_ak820_outline_0004
      00A433 C0 07            [24]  793 	push	ar7
      00A435 C0 06            [24]  794 	push	ar6
      00A437 71 B5            [12]  795 	acall	_extract_mod_bits
      00A439 AD 82            [24]  796 	mov	r5, dpl
      00A43B D0 06            [24]  797 	pop	ar6
                                    798 ;	quantum/quantum.c:172: unregister_code(code);
      00A43D 8E 04            [24]  799 	mov	ar4,r6
      00A43F 8C 82            [24]  800 	mov	dpl, r4
      00A441 C0 06            [24]  801 	push	ar6
      00A443 C0 05            [24]  802 	push	ar5
      00A445 12 7C D1         [24]  803 	lcall	_unregister_code
      00A448 D0 05            [24]  804 	pop	ar5
      00A44A D0 06            [24]  805 	pop	ar6
      00A44C D0 07            [24]  806 	pop	ar7
                                    807 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A44E 12 A1 F7         [24]  808 	lcall	_ak820_outline_0115
      00A451 40 07            [24]  809 	jc	00105$
      00A453 74 E7            [12]  810 	mov	a,#0xe7
      00A455 9E               [12]  811 	subb	a,r6
      00A456 E4               [12]  812 	clr	a
      00A457 9F               [12]  813 	subb	a,r7
      00A458 50 08            [24]  814 	jnc	00101$
                                    815 ;	free result
      00A45A                        816 00105$:
      00A45A 90 0C 48         [24]  817 	mov	dptr,#_unregister_code16_code_10000_613
      00A45D 12 74 87         [24]  818 	lcall	_ak820_outline_0036
      00A460 70 05            [24]  819 	jnz	00102$
      00A462                        820 00101$:
                                    821 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A462 8D 82            [24]  822 	mov	dpl, r5
      00A464 02 7D A4         [24]  823 	ljmp	_unregister_mods
      00A467                        824 00102$:
                                    825 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A467 8D 82            [24]  826 	mov	dpl, r5
                                    827 ;	quantum/quantum.c:187: }
      00A469 02 7D CC         [24]  828 	ljmp	_unregister_weak_mods
                                    829 ;------------------------------------------------------------
                                    830 ;Allocation info for local variables in function 'tap_code16_delay'
                                    831 ;------------------------------------------------------------
                                    832 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    833 ;code          Allocated with name '_tap_code16_delay_code_10000_618'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_20000_620'
                                    835 ;i             Allocated with name '_tap_code16_delay_i_50000_623'
                                    836 ;------------------------------------------------------------
                                    837 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    838 ;	-----------------------------------------
                                    839 ;	 function shutdown_quantum
                                    840 ;	-----------------------------------------
      00A46C                        841 _shutdown_quantum:
                                    842 ;	quantum/quantum.c:237: clear_keyboard();
      00A46C 12 7D E0         [24]  843 	lcall	_clear_keyboard
                                    844 ;	quantum/quantum.c:252: shutdown_user();
      00A46F F1 2F            [12]  845 	acall	_shutdown_user
                                    846 ;	quantum/quantum.c:253: wait_ms(250);
      00A471 7F FA            [12]  847 	mov	r7,#0xfa
      00A473                        848 00106$:
      00A473 EF               [12]  849 	mov	a,r7
      00A474 60 09            [24]  850 	jz	00108$
      00A476 90 00 01         [24]  851 	mov	dptr,#0x0001
      00A479 12 5E E8         [24]  852 	lcall	_mDelaymS
      00A47C 1F               [12]  853 	dec	r7
      00A47D 80 F4            [24]  854 	sjmp	00106$
      00A47F                        855 00108$:
                                    856 ;	quantum/quantum.c:258: }
      00A47F 22               [24]  857 	ret
                                    858 ;------------------------------------------------------------
                                    859 ;Allocation info for local variables in function 'reset_keyboard'
                                    860 ;------------------------------------------------------------
                                    861 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    862 ;	-----------------------------------------
                                    863 ;	 function reset_keyboard
                                    864 ;	-----------------------------------------
      00A480                        865 _reset_keyboard:
                                    866 ;	quantum/quantum.c:261: shutdown_quantum();
      00A480 91 6C            [12]  867 	acall	_shutdown_quantum
                                    868 ;	quantum/quantum.c:262: bootloader_jump();
                                    869 ;	quantum/quantum.c:263: }
      00A482 02 34 0E         [24]  870 	ljmp	_bootloader_jump
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function soft_reset_keyboard
                                    877 ;	-----------------------------------------
      00A485                        878 _soft_reset_keyboard:
                                    879 ;	quantum/quantum.c:266: shutdown_quantum();
      00A485 91 6C            [12]  880 	acall	_shutdown_quantum
                                    881 ;	quantum/quantum.c:267: mcu_reset();
                                    882 ;	quantum/quantum.c:268: }
      00A487 02 34 01         [24]  883 	ljmp	_mcu_reset
                                    884 ;------------------------------------------------------------
                                    885 ;Allocation info for local variables in function 'get_record_keycode'
                                    886 ;------------------------------------------------------------
                                    887 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    888 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_651'
                                    889 ;record        Allocated with name '_get_record_keycode_record_10000_652'
                                    890 ;------------------------------------------------------------
                                    891 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    892 ;	-----------------------------------------
                                    893 ;	 function get_record_keycode
                                    894 ;	-----------------------------------------
      00A48A                        895 _get_record_keycode:
      00A48A 12 38 41         [24]  896 	lcall	_ak820_outline_0104
      00A48D 90 0C 4B         [24]  897 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      00A490 12 38 46         [24]  898 	lcall	_ak820_outline_0105
                                    899 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A493 90 0C 4B         [24]  900 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      00A496 12 37 AE         [24]  901 	lcall	_ak820_outline_0009
                                    902 ;	quantum/quantum.c:278: if (record->keycode) {
      00A499 4C               [12]  903 	orl	a,r4
      00A49A 60 04            [24]  904 	jz	00102$
                                    905 ;	quantum/quantum.c:279: return record->keycode;
      00A49C 12 38 57         [24]  906 	lcall	_ak820_outline_0122
      00A49F 22               [24]  907 	ret
      00A4A0                        908 00102$:
                                    909 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A4A0 12 7E 26         [24]  910 	lcall	_ak820_outline_0020
      00A4A3 7A 00            [12]  911 	mov	r2,#0x00
      00A4A5 12 48 FB         [24]  912 	lcall	_ak820_outline_0140
      00A4A8 12 37 A1         [24]  913 	lcall	_ak820_outline_0005
      00A4AB 60 06            [24]  914 	jz	00105$
      00A4AD 90 0C 4A         [24]  915 	mov	dptr,#_get_record_keycode_PARM_2
      00A4B0 E0               [24]  916 	movx	a,@dptr
      00A4B1 70 04            [24]  917 	jnz	00106$
      00A4B3                        918 00105$:
                                    919 ;	assignBit
      00A4B3 C2 25            [12]  920 	clr	_get_record_keycode_sloc0_1_0
      00A4B5 80 02            [24]  921 	sjmp	00107$
      00A4B7                        922 00106$:
                                    923 ;	assignBit
      00A4B7 D2 25            [12]  924 	setb	_get_record_keycode_sloc0_1_0
      00A4B9                        925 00107$:
      00A4B9 90 09 DA         [24]  926 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A4BC A2 25            [12]  927 	mov	c,_get_record_keycode_sloc0_1_0
      00A4BE E4               [12]  928 	clr	a
      00A4BF 33               [12]  929 	rlc	a
      00A4C0 F0               [24]  930 	movx	@dptr,a
      00A4C1 12 49 26         [24]  931 	lcall	_ak820_outline_0186
                                    932 ;	quantum/quantum.c:287: }
      00A4C4 02 81 BC         [24]  933 	ljmp	_ak820_resolve_key
                                    934 ;------------------------------------------------------------
                                    935 ;Allocation info for local variables in function 'get_event_keycode'
                                    936 ;------------------------------------------------------------
                                    937 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    938 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_655'
                                    939 ;------------------------------------------------------------
                                    940 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    941 ;	-----------------------------------------
                                    942 ;	 function pre_process_record_quantum
                                    943 ;	-----------------------------------------
      00A4C7                        944 _pre_process_record_quantum:
      00A4C7 12 38 41         [24]  945 	lcall	_ak820_outline_0104
      00A4CA 90 0C 4D         [24]  946 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      00A4CD 12 38 46         [24]  947 	lcall	_ak820_outline_0105
                                    948 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A4D0 90 0C 4D         [24]  949 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      00A4D3 12 37 F7         [24]  950 	lcall	_ak820_outline_0052
                                    951 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A4D6 90 0C 4A         [24]  952 	mov	dptr,#_get_record_keycode_PARM_2
      00A4D9 12 4E A9         [24]  953 	lcall	_ak820_outline_0044
      00A4DC C0 07            [24]  954 	push	ar7
      00A4DE C0 06            [24]  955 	push	ar6
      00A4E0 91 8A            [12]  956 	acall	_get_record_keycode
      00A4E2 12 49 06         [24]  957 	lcall	_ak820_outline_0142
      00A4E5 D0 06            [24]  958 	pop	ar6
      00A4E7 D0 07            [24]  959 	pop	ar7
                                    960 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A4E9 74 07            [12]  961 	mov	a,#0x07
      00A4EB 12 37 EF         [24]  962 	lcall	_ak820_outline_0031
      00A4EE 12 38 23         [24]  963 	lcall	_ak820_outline_0072
                                    964 ;	quantum/quantum.c:339: if (keycode == QK_LEAD && record->event.pressed && record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS)
      00A4F1 BC 58 38         [24]  965 	cjne	r4,#0x58,00102$
      00A4F4 BD 7C 35         [24]  966 	cjne	r5,#0x7c,00102$
      00A4F7 74 05            [12]  967 	mov	a,#0x05
      00A4F9 12 4E 6A         [24]  968 	lcall	_ak820_outline_0012
      00A4FC 60 2E            [24]  969 	jz	00102$
      00A4FE 12 38 1C         [24]  970 	lcall	_ak820_outline_0066
      00A501 FD               [12]  971 	mov	r5,a
      00A502 BD 10 00         [24]  972 	cjne	r5,#0x10,00158$
      00A505                        973 00158$:
      00A505 50 25            [24]  974 	jnc	00102$
      00A507 12 38 2F         [24]  975 	lcall	_ak820_outline_0091
      00A50A FD               [12]  976 	mov	r5,a
      00A50B BD 08 00         [24]  977 	cjne	r5,#0x08,00160$
      00A50E                        978 00160$:
      00A50E 50 1C            [24]  979 	jnc	00102$
                                    980 ;	quantum/quantum.c:340: ak820_combo_tick(record->event.time +
      00A510 12 37 E7         [24]  981 	lcall	_ak820_outline_0030
      00A513 FC               [12]  982 	mov	r4,a
      00A514 A3               [24]  983 	inc	dptr
      00A515 E0               [24]  984 	movx	a,@dptr
      00A516 FD               [12]  985 	mov	r5,a
      00A517 74 28            [12]  986 	mov	a,#0x28
      00A519 2C               [12]  987 	add	a, r4
      00A51A FC               [12]  988 	mov	r4,a
      00A51B E4               [12]  989 	clr	a
      00A51C 3D               [12]  990 	addc	a, r5
      00A51D FD               [12]  991 	mov	r5,a
      00A51E 12 38 57         [24]  992 	lcall	_ak820_outline_0122
      00A521 C0 07            [24]  993 	push	ar7
      00A523 C0 06            [24]  994 	push	ar6
      00A525 12 35 B7         [24]  995 	lcall	_ak820_combo_tick
      00A528 D0 06            [24]  996 	pop	ar6
      00A52A D0 07            [24]  997 	pop	ar7
      00A52C                        998 00102$:
                                    999 ;	quantum/quantum.c:348: if (!ak820_leader_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A52C 12 48 E5         [24] 1000 	lcall	_ak820_outline_0114
      00A52F C0 07            [24] 1001 	push	ar7
      00A531 C0 06            [24] 1002 	push	ar6
      00A533 12 3F 68         [24] 1003 	lcall	_ak820_leader_process
      00A536 E5 82            [12] 1004 	mov	a, dpl
      00A538 D0 06            [24] 1005 	pop	ar6
      00A53A D0 07            [24] 1006 	pop	ar7
      00A53C 70 03            [24] 1007 	jnz	00107$
      00A53E F5 82            [12] 1008 	mov	dpl,a
      00A540 22               [24] 1009 	ret
      00A541                       1010 00107$:
                                   1011 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A541 12 48 E5         [24] 1012 	lcall	_ak820_outline_0114
      00A544 12 35 ED         [24] 1013 	lcall	_ak820_combo_process
      00A547 E5 82            [12] 1014 	mov	a, dpl
      00A549 70 04            [24] 1015 	jnz	00111$
                                   1016 ;	quantum/quantum.c:366: true;
                                   1017 ;	assignBit
      00A54B C2 26            [12] 1018 	clr	_pre_process_record_quantum_sloc0_1_0
      00A54D 80 02            [24] 1019 	sjmp	00112$
      00A54F                       1020 00111$:
                                   1021 ;	assignBit
      00A54F D2 26            [12] 1022 	setb	_pre_process_record_quantum_sloc0_1_0
      00A551                       1023 00112$:
      00A551 A2 26            [12] 1024 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A553 12 38 7D         [24] 1025 	lcall	_ak820_outline_0167
                                   1026 ;	quantum/quantum.c:367: }
      00A556 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1030 ;------------------------------------------------------------
                                   1031 ;record        Allocated with name '_post_process_record_quantum_record_10000_661'
                                   1032 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_662'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function process_record_quantum
                                   1037 ;	-----------------------------------------
      00A557                       1038 _process_record_quantum:
      00A557 12 38 41         [24] 1039 	lcall	_ak820_outline_0104
      00A55A 90 0C 4F         [24] 1040 	mov	dptr,#_process_record_quantum_record_10000_663
      00A55D 12 38 46         [24] 1041 	lcall	_ak820_outline_0105
                                   1042 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A560 90 0C 4F         [24] 1043 	mov	dptr,#_process_record_quantum_record_10000_663
      00A563 12 37 F7         [24] 1044 	lcall	_ak820_outline_0052
      00A566 90 0C 4A         [24] 1045 	mov	dptr,#_get_record_keycode_PARM_2
      00A569 E4               [12] 1046 	clr	a
      00A56A 12 48 C0         [24] 1047 	lcall	_ak820_outline_0061
      00A56D 91 8A            [12] 1048 	acall	_get_record_keycode
      00A56F 12 48 F0         [24] 1049 	lcall	_ak820_outline_0132
                                   1050 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A572 90 0C 4F         [24] 1051 	mov	dptr,#_process_record_quantum_record_10000_663
      00A575 12 38 16         [24] 1052 	lcall	_ak820_outline_0060
      00A578 90 0C 56         [24] 1053 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A57B EC               [12] 1054 	mov	a,r4
      00A57C F0               [24] 1055 	movx	@dptr,a
      00A57D ED               [12] 1056 	mov	a,r5
      00A57E A3               [24] 1057 	inc	dptr
      00A57F 12 48 C0         [24] 1058 	lcall	_ak820_outline_0061
                                   1059 ;	quantum/quantum.c:382: }
      00A582 A1 EF            [24] 1060 	ajmp	_process_record_quantum_helper
                                   1061 ;------------------------------------------------------------
                                   1062 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1063 ;------------------------------------------------------------
                                   1064 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1065 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_665'
                                   1066 ;record        Allocated with name '_process_ak820_nkro_record_10000_666'
                                   1067 ;------------------------------------------------------------
                                   1068 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1069 ;	-----------------------------------------
                                   1070 ;	 function process_ak820_nkro
                                   1071 ;	-----------------------------------------
      00A584                       1072 _process_ak820_nkro:
      00A584 12 38 41         [24] 1073 	lcall	_ak820_outline_0104
      00A587 90 0C 54         [24] 1074 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A58A 12 38 46         [24] 1075 	lcall	_ak820_outline_0105
                                   1076 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A58D 90 0C 51         [24] 1077 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A590 12 37 F7         [24] 1078 	lcall	_ak820_outline_0052
                                   1079 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A593 90 0C 54         [24] 1080 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A596 12 38 16         [24] 1081 	lcall	_ak820_outline_0060
      00A599 C3               [12] 1082 	clr	c
      00A59A EC               [12] 1083 	mov	a,r4
      00A59B 94 11            [12] 1084 	subb	a,#0x11
      00A59D ED               [12] 1085 	mov	a,r5
      00A59E 94 70            [12] 1086 	subb	a,#0x70
      00A5A0 40 08            [24] 1087 	jc	00101$
      00A5A2 74 13            [12] 1088 	mov	a,#0x13
      00A5A4 9C               [12] 1089 	subb	a,r4
      00A5A5 74 70            [12] 1090 	mov	a,#0x70
      00A5A7 9D               [12] 1091 	subb	a,r5
      00A5A8 50 04            [24] 1092 	jnc	00102$
                                   1093 ;	free result
      00A5AA                       1094 00101$:
      00A5AA 75 82 01         [24] 1095 	mov	dpl, #0x01
      00A5AD 22               [24] 1096 	ret
      00A5AE                       1097 00102$:
                                   1098 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A5AE 12 37 A1         [24] 1099 	lcall	_ak820_outline_0005
      00A5B1 60 38            [24] 1100 	jz	00105$
                                   1101 ;	quantum/quantum.c:407: clear_keyboard();
      00A5B3 C0 05            [24] 1102 	push	ar5
      00A5B5 C0 04            [24] 1103 	push	ar4
      00A5B7 12 7D E0         [24] 1104 	lcall	_clear_keyboard
      00A5BA D0 04            [24] 1105 	pop	ar4
      00A5BC D0 05            [24] 1106 	pop	ar5
                                   1107 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A5BE BC 13 14         [24] 1108 	cjne	r4,#0x13,00108$
      00A5C1 BD 70 11         [24] 1109 	cjne	r5,#0x70,00108$
      00A5C4 90 0B 2C         [24] 1110 	mov	dptr,#_keymap_config
      00A5C7 E0               [24] 1111 	movx	a,@dptr
      00A5C8 23               [12] 1112 	rl	a
      00A5C9 54 01            [12] 1113 	anl	a,#0x01
      00A5CB B4 01 00         [24] 1114 	cjne	a,#0x01,00136$
      00A5CE                       1115 00136$:
      00A5CE 92 27            [24] 1116 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A5D0 E4               [12] 1117 	clr	a
      00A5D1 33               [12] 1118 	rlc	a
      00A5D2 FF               [12] 1119 	mov	r7,a
      00A5D3 80 09            [24] 1120 	sjmp	00109$
      00A5D5                       1121 00108$:
      00A5D5 E4               [12] 1122 	clr	a
      00A5D6 BC 11 04         [24] 1123 	cjne	r4,#0x11,00137$
      00A5D9 BD 70 01         [24] 1124 	cjne	r5,#0x70,00137$
      00A5DC 04               [12] 1125 	inc	a
      00A5DD                       1126 00137$:
      00A5DD FF               [12] 1127 	mov	r7,a
      00A5DE                       1128 00109$:
                                   1129 ;	assignBit
      00A5DE EF               [12] 1130 	mov	a,r7
      00A5DF 24 FF            [12] 1131 	add	a,#0xff
      00A5E1 E4               [12] 1132 	clr	a
      00A5E2 33               [12] 1133 	rlc	a
      00A5E3 90 0B 2C         [24] 1134 	mov	dptr,#_keymap_config
      00A5E6 13               [12] 1135 	rrc	a
      00A5E7 E0               [24] 1136 	movx	a,@dptr
      00A5E8 92 E7            [24] 1137 	mov	acc.7,c
      00A5EA F0               [24] 1138 	movx	@dptr,a
      00A5EB                       1139 00105$:
                                   1140 ;	quantum/quantum.c:410: return false;
      00A5EB 75 82 00         [24] 1141 	mov	dpl, #0x00
                                   1142 ;	quantum/quantum.c:411: }
      00A5EE 22               [24] 1143 	ret
                                   1144 ;------------------------------------------------------------
                                   1145 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1146 ;------------------------------------------------------------
                                   1147 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1148 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_670'
                                   1149 ;record        Allocated with name '_process_record_quantum_helper_record_10000_671'
                                   1150 ;------------------------------------------------------------
                                   1151 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1152 ;	-----------------------------------------
                                   1153 ;	 function process_record_quantum_helper
                                   1154 ;	-----------------------------------------
      00A5EF                       1155 _process_record_quantum_helper:
      00A5EF 12 38 41         [24] 1156 	lcall	_ak820_outline_0104
      00A5F2 90 0C 58         [24] 1157 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A5F5 12 38 46         [24] 1158 	lcall	_ak820_outline_0105
                                   1159 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A5F8 90 0C 56         [24] 1160 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A5FB 12 37 F7         [24] 1161 	lcall	_ak820_outline_0052
                                   1162 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A5FE 90 0C 58         [24] 1163 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A601 12 38 16         [24] 1164 	lcall	_ak820_outline_0060
      00A604 90 0C 51         [24] 1165 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A607 12 A7 30         [24] 1166 	lcall	_ak820_outline_0006
      00A60A C0 07            [24] 1167 	push	ar7
      00A60C C0 06            [24] 1168 	push	ar6
      00A60E C0 05            [24] 1169 	push	ar5
      00A610 C0 04            [24] 1170 	push	ar4
      00A612 B1 84            [24] 1171 	acall	_process_ak820_nkro
      00A614 E5 82            [12] 1172 	mov	a, dpl
      00A616 D0 04            [24] 1173 	pop	ar4
      00A618 D0 05            [24] 1174 	pop	ar5
      00A61A D0 06            [24] 1175 	pop	ar6
      00A61C D0 07            [24] 1176 	pop	ar7
      00A61E 70 02            [24] 1177 	jnz	00196$
      00A620 C1 F5            [12] 1178 	ajmp	00101$
      00A622                       1179 00196$:
                                   1180 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A622 90 0C 2F         [24] 1181 	mov	dptr,#_process_last_key_PARM_2
      00A625 12 4E C4         [24] 1182 	lcall	_ak820_outline_0059
      00A628 12 38 57         [24] 1183 	lcall	_ak820_outline_0122
      00A62B C0 07            [24] 1184 	push	ar7
      00A62D C0 06            [24] 1185 	push	ar6
      00A62F C0 05            [24] 1186 	push	ar5
      00A631 C0 04            [24] 1187 	push	ar4
      00A633 31 39            [12] 1188 	acall	_process_last_key
      00A635 E5 82            [12] 1189 	mov	a, dpl
      00A637 D0 04            [24] 1190 	pop	ar4
      00A639 D0 05            [24] 1191 	pop	ar5
      00A63B D0 06            [24] 1192 	pop	ar6
      00A63D D0 07            [24] 1193 	pop	ar7
      00A63F 70 02            [24] 1194 	jnz	00197$
      00A641 C1 F5            [12] 1195 	ajmp	00101$
      00A643                       1196 00197$:
      00A643 90 0C 34         [24] 1197 	mov	dptr,#_process_repeat_key_PARM_2
      00A646 12 4E C4         [24] 1198 	lcall	_ak820_outline_0059
      00A649 12 38 57         [24] 1199 	lcall	_ak820_outline_0122
      00A64C C0 07            [24] 1200 	push	ar7
      00A64E C0 06            [24] 1201 	push	ar6
      00A650 C0 05            [24] 1202 	push	ar5
      00A652 C0 04            [24] 1203 	push	ar4
      00A654 31 B0            [12] 1204 	acall	_process_repeat_key
      00A656 E5 82            [12] 1205 	mov	a, dpl
      00A658 D0 04            [24] 1206 	pop	ar4
      00A65A D0 05            [24] 1207 	pop	ar5
      00A65C D0 06            [24] 1208 	pop	ar6
      00A65E D0 07            [24] 1209 	pop	ar7
      00A660 70 02            [24] 1210 	jnz	00198$
      00A662 C1 F5            [12] 1211 	ajmp	00101$
      00A664                       1212 00198$:
                                   1213 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A664 90 0C 91         [24] 1214 	mov	dptr,#_process_record_via_PARM_2
      00A667 12 A7 30         [24] 1215 	lcall	_ak820_outline_0006
      00A66A C0 07            [24] 1216 	push	ar7
      00A66C C0 06            [24] 1217 	push	ar6
      00A66E C0 05            [24] 1218 	push	ar5
      00A670 C0 04            [24] 1219 	push	ar4
      00A672 12 AC 11         [24] 1220 	lcall	_process_record_via
      00A675 E5 82            [12] 1221 	mov	a, dpl
      00A677 D0 04            [24] 1222 	pop	ar4
      00A679 D0 05            [24] 1223 	pop	ar5
      00A67B D0 06            [24] 1224 	pop	ar6
      00A67D D0 07            [24] 1225 	pop	ar7
      00A67F 70 02            [24] 1226 	jnz	00199$
      00A681 C1 F5            [12] 1227 	ajmp	00101$
      00A683                       1228 00199$:
                                   1229 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A683 90 0C 18         [24] 1230 	mov	dptr,#_process_caps_word_PARM_2
      00A686 12 A7 30         [24] 1231 	lcall	_ak820_outline_0006
      00A689 C0 07            [24] 1232 	push	ar7
      00A68B C0 06            [24] 1233 	push	ar6
      00A68D C0 05            [24] 1234 	push	ar5
      00A68F C0 04            [24] 1235 	push	ar4
      00A691 12 9E D9         [24] 1236 	lcall	_process_caps_word
      00A694 E5 82            [12] 1237 	mov	a, dpl
      00A696 D0 04            [24] 1238 	pop	ar4
      00A698 D0 05            [24] 1239 	pop	ar5
      00A69A D0 06            [24] 1240 	pop	ar6
      00A69C D0 07            [24] 1241 	pop	ar7
      00A69E 60 55            [24] 1242 	jz	00101$
                                   1243 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A6A0 90 0C 1D         [24] 1244 	mov	dptr,#_process_grave_esc_PARM_2
      00A6A3 12 A7 30         [24] 1245 	lcall	_ak820_outline_0006
      00A6A6 C0 07            [24] 1246 	push	ar7
      00A6A8 C0 06            [24] 1247 	push	ar6
      00A6AA C0 05            [24] 1248 	push	ar5
      00A6AC C0 04            [24] 1249 	push	ar4
      00A6AE 12 9F EC         [24] 1250 	lcall	_process_grave_esc
      00A6B1 E5 82            [12] 1251 	mov	a, dpl
      00A6B3 D0 04            [24] 1252 	pop	ar4
      00A6B5 D0 05            [24] 1253 	pop	ar5
      00A6B7 D0 06            [24] 1254 	pop	ar6
      00A6B9 D0 07            [24] 1255 	pop	ar7
      00A6BB 60 38            [24] 1256 	jz	00101$
                                   1257 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A6BD 90 0C 38         [24] 1258 	mov	dptr,#_process_rgb_PARM_2
      00A6C0 12 A7 30         [24] 1259 	lcall	_ak820_outline_0006
      00A6C3 C0 07            [24] 1260 	push	ar7
      00A6C5 C0 06            [24] 1261 	push	ar6
      00A6C7 C0 05            [24] 1262 	push	ar5
      00A6C9 C0 04            [24] 1263 	push	ar4
      00A6CB 31 FF            [12] 1264 	acall	_process_rgb
      00A6CD E5 82            [12] 1265 	mov	a, dpl
      00A6CF D0 04            [24] 1266 	pop	ar4
      00A6D1 D0 05            [24] 1267 	pop	ar5
      00A6D3 D0 06            [24] 1268 	pop	ar6
      00A6D5 D0 07            [24] 1269 	pop	ar7
      00A6D7 60 1C            [24] 1270 	jz	00101$
                                   1271 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A6D9 90 0C 3E         [24] 1272 	mov	dptr,#_process_tri_layer_PARM_2
      00A6DC 12 A7 30         [24] 1273 	lcall	_ak820_outline_0006
      00A6DF C0 07            [24] 1274 	push	ar7
      00A6E1 C0 06            [24] 1275 	push	ar6
      00A6E3 C0 05            [24] 1276 	push	ar5
      00A6E5 C0 04            [24] 1277 	push	ar4
      00A6E7 51 B0            [12] 1278 	acall	_process_tri_layer
      00A6E9 E5 82            [12] 1279 	mov	a, dpl
      00A6EB D0 04            [24] 1280 	pop	ar4
      00A6ED D0 05            [24] 1281 	pop	ar5
      00A6EF D0 06            [24] 1282 	pop	ar6
      00A6F1 D0 07            [24] 1283 	pop	ar7
      00A6F3 70 04            [24] 1284 	jnz	00102$
                                   1285 ;	quantum/quantum.c:561: true)) {
      00A6F5                       1286 00101$:
                                   1287 ;	quantum/quantum.c:562: return false;
      00A6F5 75 82 00         [24] 1288 	mov	dpl, #0x00
      00A6F8 22               [24] 1289 	ret
      00A6F9                       1290 00102$:
                                   1291 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A6F9 12 37 A1         [24] 1292 	lcall	_ak820_outline_0005
      00A6FC 60 2D            [24] 1293 	jz	00116$
                                   1294 ;	quantum/quantum.c:566: switch (keycode) {
      00A6FE BC 00 05         [24] 1295 	cjne	r4,#0x00,00205$
      00A701 BD 7C 02         [24] 1296 	cjne	r5,#0x7c,00205$
      00A704 80 10            [24] 1297 	sjmp	00111$
      00A706                       1298 00205$:
      00A706 BC 01 05         [24] 1299 	cjne	r4,#0x01,00206$
      00A709 BD 7C 02         [24] 1300 	cjne	r5,#0x7c,00206$
      00A70C 80 0E            [24] 1301 	sjmp	00112$
      00A70E                       1302 00206$:
                                   1303 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A70E BC 03 1A         [24] 1304 	cjne	r4,#0x03,00116$
      00A711 BD 7C 17         [24] 1305 	cjne	r5,#0x7c,00116$
      00A714 80 0C            [24] 1306 	sjmp	00113$
      00A716                       1307 00111$:
                                   1308 ;	quantum/quantum.c:569: reset_keyboard();
      00A716 91 80            [12] 1309 	acall	_reset_keyboard
                                   1310 ;	quantum/quantum.c:570: return false;
      00A718 75 82 00         [24] 1311 	mov	dpl, #0x00
                                   1312 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A71B 22               [24] 1313 	ret
      00A71C                       1314 00112$:
                                   1315 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A71C 91 85            [12] 1316 	acall	_soft_reset_keyboard
                                   1317 ;	quantum/quantum.c:573: return false;
      00A71E 75 82 00         [24] 1318 	mov	dpl, #0x00
                                   1319 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A721 22               [24] 1320 	ret
      00A722                       1321 00113$:
                                   1322 ;	quantum/quantum.c:592: eeconfig_disable();
      00A722 12 96 64         [24] 1323 	lcall	_eeconfig_disable
                                   1324 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A725 91 85            [12] 1325 	acall	_soft_reset_keyboard
                                   1326 ;	quantum/quantum.c:595: return false;
      00A727 75 82 00         [24] 1327 	mov	dpl, #0x00
                                   1328 ;	quantum/quantum.c:650: }
      00A72A 22               [24] 1329 	ret
      00A72B                       1330 00116$:
                                   1331 ;	quantum/quantum.c:654: return true;
      00A72B 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/quantum.c:658: }
      00A72E 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1337 ;------------------------------------------------------------
                                   1338 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_678'
                                   1339 ;------------------------------------------------------------
                                   1340 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1341 ;	-----------------------------------------
                                   1342 ;	 function shutdown_user
                                   1343 ;	-----------------------------------------
      00A72F                       1344 _shutdown_user:
      00A72F 22               [24] 1345 	ret
                                   1346 ;------------------------------------------------------------
                                   1347 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1348 ;------------------------------------------------------------
                                   1349 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1350 ;	-----------------------------------------
                                   1351 	.area CSEG    (CODE)
                                   1352 	.area CONST   (CODE)
                                   1353 	.area XINIT   (CODE)
                                   1354 	.area CABS    (ABS,CODE)
                                   1355 
                                   1356 ; Experimental exact instruction outlining.
                                   1357 	.globl _ak820_outline_0004
                                   1358 	.globl _ak820_outline_0005
                                   1359 	.globl _ak820_outline_0006
                                   1360 	.globl _ak820_outline_0009
                                   1361 	.globl _ak820_outline_0012
                                   1362 	.globl _ak820_outline_0020
                                   1363 	.globl _ak820_outline_0030
                                   1364 	.globl _ak820_outline_0031
                                   1365 	.globl _ak820_outline_0036
                                   1366 	.globl _ak820_outline_0044
                                   1367 	.globl _ak820_outline_0052
                                   1368 	.globl _ak820_outline_0059
                                   1369 	.globl _ak820_outline_0060
                                   1370 	.globl _ak820_outline_0061
                                   1371 	.globl _ak820_outline_0066
                                   1372 	.globl _ak820_outline_0072
                                   1373 	.globl _ak820_outline_0091
                                   1374 	.globl _ak820_outline_0104
                                   1375 	.globl _ak820_outline_0105
                                   1376 	.globl _ak820_outline_0114
                                   1377 	.globl _ak820_outline_0115
                                   1378 	.globl _ak820_outline_0122
                                   1379 	.globl _ak820_outline_0132
                                   1380 	.globl _ak820_outline_0140
                                   1381 	.globl _ak820_outline_0142
                                   1382 	.globl _ak820_outline_0167
                                   1383 	.globl _ak820_outline_0186
                                   1384 
                                   1385 	.area CSEG (CODE)
                                   1386 ; function ak820_outline_0006
      00A730                       1387 _ak820_outline_0006:
      00A730 EE               [12] 1388 	mov	a,r6
      00A731 F0               [24] 1389 	movx	@dptr,a
      00A732 EF               [12] 1390 	mov	a,r7
      00A733 A3               [24] 1391 	inc	dptr
      00A734 F0               [24] 1392 	movx	@dptr,a
      00A735 E4               [12] 1393 	clr	a
      00A736 A3               [24] 1394 	inc	dptr
      00A737 F0               [24] 1395 	movx	@dptr,a
      00A738 8C 82            [24] 1396 	mov	dpl,r4
      00A73A 8D 83            [24] 1397 	mov	dph,r5
      00A73C 22               [24] 1398 	ret
