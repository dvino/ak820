                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _ak820_leader_cancel
                                     25 	.globl _ak820_leader_task
                                     26 	.globl _pre_process_record_quantum
                                     27 	.globl _get_record_keycode
                                     28 	.globl _get_repeat_key_count
                                     29 	.globl _repeat_key_cancel
                                     30 	.globl _clear_owned_usages
                                     31 	.globl _owned_usage_key
                                     32 	.globl _clear_owned_keys
                                     33 	.globl _del_owned_key
                                     34 	.globl _add_owned_key
                                     35 	.globl _clear_owned_mods
                                     36 	.globl _del_owned_weak_mods
                                     37 	.globl _add_owned_weak_mods
                                     38 	.globl _del_owned_mods
                                     39 	.globl _add_owned_mods
                                     40 	.globl _clear_weak_mods
                                     41 	.globl _clear_mods
                                     42 	.globl _send_keyboard_report
                                     43 	.globl _layer_hold_clear
                                     44 	.globl _layer_hold_off
                                     45 	.globl _layer_hold_on
                                     46 	.globl _ak820_resolve_key
                                     47 	.globl _layer_xor
                                     48 	.globl _layer_and
                                     49 	.globl _layer_or
                                     50 	.globl _layer_off
                                     51 	.globl _layer_on
                                     52 	.globl _layer_move
                                     53 	.globl _layer_clear
                                     54 	.globl _layer_state_set
                                     55 	.globl _default_layer_xor
                                     56 	.globl _default_layer_and
                                     57 	.globl _default_layer_or
                                     58 	.globl _default_layer_set
                                     59 	.globl _process_record_quantum
                                     60 	.globl _action_for_keycode
                                     61 	.globl _mDelaymS
                                     62 	.globl _host_consumer_send
                                     63 	.globl _host_system_send
                                     64 	.globl _host_keyboard_leds
                                     65 	.globl _led_set
                                     66 	.globl _clear_keys_from_report
                                     67 	.globl ___memcpy
                                     68 	.globl _ADC_START
                                     69 	.globl _S0_R_FIFO
                                     70 	.globl _S0_T_FIFO
                                     71 	.globl _S0_FREE
                                     72 	.globl _S0_IF_BYTE
                                     73 	.globl _S0_IF_FIRST
                                     74 	.globl _S0_IF_OV
                                     75 	.globl _S0_FST_ACT
                                     76 	.globl _CP_RL2
                                     77 	.globl _C_T2
                                     78 	.globl _TR2
                                     79 	.globl _EXEN2
                                     80 	.globl _TCLK
                                     81 	.globl _RCLK
                                     82 	.globl _EXF2
                                     83 	.globl _CAP1F
                                     84 	.globl _TF2
                                     85 	.globl _RI
                                     86 	.globl _TI
                                     87 	.globl _RB8
                                     88 	.globl _TB8
                                     89 	.globl _REN
                                     90 	.globl _SM2
                                     91 	.globl _SM1
                                     92 	.globl _SM0
                                     93 	.globl _IT0
                                     94 	.globl _IE0
                                     95 	.globl _IT1
                                     96 	.globl _IE1
                                     97 	.globl _TR0
                                     98 	.globl _TF0
                                     99 	.globl _TR1
                                    100 	.globl _TF1
                                    101 	.globl _P4_0
                                    102 	.globl _P4_1
                                    103 	.globl _P4_2
                                    104 	.globl _P4_3
                                    105 	.globl _P4_4
                                    106 	.globl _P4_5
                                    107 	.globl _P4_6
                                    108 	.globl _RXD
                                    109 	.globl _TXD
                                    110 	.globl _INT0
                                    111 	.globl _INT1
                                    112 	.globl _T0
                                    113 	.globl _T1
                                    114 	.globl _MOSI1
                                    115 	.globl _MISO1
                                    116 	.globl _SCK1
                                    117 	.globl _P3_0
                                    118 	.globl _P3_1
                                    119 	.globl _P3_2
                                    120 	.globl _P3_3
                                    121 	.globl _P3_4
                                    122 	.globl _P3_5
                                    123 	.globl _P3_6
                                    124 	.globl _P3_7
                                    125 	.globl _CAP1_
                                    126 	.globl _T2_
                                    127 	.globl _CAP2_
                                    128 	.globl _T2EX_
                                    129 	.globl _RXD1
                                    130 	.globl _TXD1
                                    131 	.globl _P2_0
                                    132 	.globl _P2_1
                                    133 	.globl _P2_2
                                    134 	.globl _P2_3
                                    135 	.globl _P2_4
                                    136 	.globl _P2_5
                                    137 	.globl _P2_6
                                    138 	.globl _P2_7
                                    139 	.globl _AIN0
                                    140 	.globl _AIN1
                                    141 	.globl _AIN2
                                    142 	.globl _AIN3
                                    143 	.globl _AIN4
                                    144 	.globl _AIN5
                                    145 	.globl _AIN6
                                    146 	.globl _AIN7
                                    147 	.globl _CAP1
                                    148 	.globl _T2
                                    149 	.globl _CAP2
                                    150 	.globl _T2EX
                                    151 	.globl _INT0_
                                    152 	.globl _SCS
                                    153 	.globl _MOSI
                                    154 	.globl _MISO
                                    155 	.globl _SCK
                                    156 	.globl _RXD1_
                                    157 	.globl _TXD1_
                                    158 	.globl _P1_0
                                    159 	.globl _P1_1
                                    160 	.globl _P1_2
                                    161 	.globl _P1_3
                                    162 	.globl _P1_4
                                    163 	.globl _P1_5
                                    164 	.globl _P1_6
                                    165 	.globl _P1_7
                                    166 	.globl _AIN8
                                    167 	.globl _AIN9
                                    168 	.globl _AIN10
                                    169 	.globl _AIN11
                                    170 	.globl _AIN12
                                    171 	.globl _AIN13
                                    172 	.globl _RXD_
                                    173 	.globl _TXD_
                                    174 	.globl _SCL0
                                    175 	.globl _SDA0
                                    176 	.globl _P0_0
                                    177 	.globl _P0_1
                                    178 	.globl _P0_2
                                    179 	.globl _P0_3
                                    180 	.globl _P0_4
                                    181 	.globl _P0_5
                                    182 	.globl _P0_6
                                    183 	.globl _P0_7
                                    184 	.globl _IE_SPI0
                                    185 	.globl _IE_USB
                                    186 	.globl _IE_ADC
                                    187 	.globl _IE_UART1
                                    188 	.globl _IE_PWM_I2C
                                    189 	.globl _IE_GPIO
                                    190 	.globl _IE_WDOG
                                    191 	.globl _PX0
                                    192 	.globl _PT0
                                    193 	.globl _PX1
                                    194 	.globl _PT1
                                    195 	.globl _PS
                                    196 	.globl _PT2
                                    197 	.globl _PL_FLAG
                                    198 	.globl _PH_FLAG
                                    199 	.globl _EX0
                                    200 	.globl _ET0
                                    201 	.globl _EX1
                                    202 	.globl _ET1
                                    203 	.globl _ES
                                    204 	.globl _ET2
                                    205 	.globl _E_DIS
                                    206 	.globl _EA
                                    207 	.globl _P
                                    208 	.globl _F1
                                    209 	.globl _OV
                                    210 	.globl _RS0
                                    211 	.globl _RS1
                                    212 	.globl _F0
                                    213 	.globl _AC
                                    214 	.globl _CY
                                    215 	.globl _I2CS_INT_ST
                                    216 	.globl _I2CX_INT
                                    217 	.globl _LED_STATUS
                                    218 	.globl _LED_DMA_H
                                    219 	.globl _LED_DMA_L
                                    220 	.globl _LED_DMA
                                    221 	.globl _LED_PWM_OE
                                    222 	.globl _LED_COMMON
                                    223 	.globl _ADC_CHAN
                                    224 	.globl _ADC_DAT_H
                                    225 	.globl _ADC_DAT_L
                                    226 	.globl _ADC_DAT
                                    227 	.globl _ADC_CTRL
                                    228 	.globl _SPI1_CK_SE
                                    229 	.globl _SPI1_CTRL
                                    230 	.globl _SPI1_DATA
                                    231 	.globl _SPI1_STAT
                                    232 	.globl _SIF1
                                    233 	.globl _SBAUD1
                                    234 	.globl _SBUF1
                                    235 	.globl _SCON1
                                    236 	.globl _SPI0_SETUP
                                    237 	.globl _SPI0_CK_SE
                                    238 	.globl _SPI0_CTRL
                                    239 	.globl _SPI0_DATA
                                    240 	.globl _SPI0_STAT
                                    241 	.globl _T2CAP1H
                                    242 	.globl _T2CAP1L
                                    243 	.globl _T2CAP1
                                    244 	.globl _TH2
                                    245 	.globl _TL2
                                    246 	.globl _T2COUNT
                                    247 	.globl _RCAP2H
                                    248 	.globl _RCAP2L
                                    249 	.globl _RCAP2
                                    250 	.globl _T2MOD
                                    251 	.globl _T2CON
                                    252 	.globl _SBUF
                                    253 	.globl _SCON
                                    254 	.globl _TH1
                                    255 	.globl _TH0
                                    256 	.globl _TL1
                                    257 	.globl _TL0
                                    258 	.globl _TMOD
                                    259 	.globl _TCON
                                    260 	.globl _XBUS_AUX
                                    261 	.globl _P7
                                    262 	.globl _P6_DIR
                                    263 	.globl _P6_OUT_PU
                                    264 	.globl _P6_IN
                                    265 	.globl _P5_DIR
                                    266 	.globl _P5_OUT_PU
                                    267 	.globl _P5_IN
                                    268 	.globl _P4_LED_KEY
                                    269 	.globl _P4_DIR_PU
                                    270 	.globl _P4_MOD_OC
                                    271 	.globl _P4
                                    272 	.globl _P3_DIR_PU
                                    273 	.globl _P3_MOD_OC
                                    274 	.globl _P3
                                    275 	.globl _P2_DIR_PU
                                    276 	.globl _P2_MOD_OC
                                    277 	.globl _P2
                                    278 	.globl _P1_DIR_PU
                                    279 	.globl _P1_MOD_OC
                                    280 	.globl _P1
                                    281 	.globl _P0_DIR_PU
                                    282 	.globl _P0_MOD_OC
                                    283 	.globl _P0
                                    284 	.globl _ROM_CTRL
                                    285 	.globl _ROM_DATA_HH
                                    286 	.globl _ROM_DATA_HL
                                    287 	.globl _ROM_DATA_HI
                                    288 	.globl _ROM_ADDR_H
                                    289 	.globl _ROM_ADDR_L
                                    290 	.globl _ROM_ADDR
                                    291 	.globl _GPIO_IE
                                    292 	.globl _IP_EX
                                    293 	.globl _IE_EX
                                    294 	.globl _IP
                                    295 	.globl _IE
                                    296 	.globl _WDOG_COUNT
                                    297 	.globl _RESET_KEEP
                                    298 	.globl _WAKE_CTRL
                                    299 	.globl _CLOCK_CFG
                                    300 	.globl _POWER_CFG
                                    301 	.globl _PCON
                                    302 	.globl _GLOBAL_CFG
                                    303 	.globl _SAFE_MOD
                                    304 	.globl _DPH
                                    305 	.globl _DPL
                                    306 	.globl _SP
                                    307 	.globl _A_INV
                                    308 	.globl _B
                                    309 	.globl _ACC
                                    310 	.globl _PSW
                                    311 	.globl _disable_action_cache
                                    312 	.globl _tap_code_delay_PARM_2
                                    313 	.globl _process_action_PARM_2
                                    314 	.globl _action_exec_PARM_1
                                    315 	.globl _tp_buttons
                                    316 	.globl _action_exec
                                    317 	.globl _ak820_action_exec
                                    318 	.globl _process_record
                                    319 	.globl _process_record_handler
                                    320 	.globl _process_action
                                    321 	.globl _register_code
                                    322 	.globl _unregister_code
                                    323 	.globl _tap_code_delay
                                    324 	.globl _tap_code
                                    325 	.globl _register_mods
                                    326 	.globl _unregister_mods
                                    327 	.globl _register_weak_mods
                                    328 	.globl _unregister_weak_mods
                                    329 	.globl _clear_keyboard
                                    330 	.globl _clear_keyboard_but_mods
                                    331 	.globl _clear_keyboard_but_mods_and_keys
                                    332 ;--------------------------------------------------------
                                    333 ; special function registers
                                    334 ;--------------------------------------------------------
                                    335 	.area RSEG    (ABS,DATA)
      000000                        336 	.org 0x0000
                           0000D0   337 _PSW	=	0x00d0
                           0000E0   338 _ACC	=	0x00e0
                           0000F0   339 _B	=	0x00f0
                           0000FD   340 _A_INV	=	0x00fd
                           000081   341 _SP	=	0x0081
                           000082   342 _DPL	=	0x0082
                           000083   343 _DPH	=	0x0083
                           0000A1   344 _SAFE_MOD	=	0x00a1
                           0000B1   345 _GLOBAL_CFG	=	0x00b1
                           000087   346 _PCON	=	0x0087
                           0000BA   347 _POWER_CFG	=	0x00ba
                           0000B9   348 _CLOCK_CFG	=	0x00b9
                           0000A9   349 _WAKE_CTRL	=	0x00a9
                           0000FE   350 _RESET_KEEP	=	0x00fe
                           0000FF   351 _WDOG_COUNT	=	0x00ff
                           0000A8   352 _IE	=	0x00a8
                           0000B8   353 _IP	=	0x00b8
                           0000E8   354 _IE_EX	=	0x00e8
                           0000E9   355 _IP_EX	=	0x00e9
                           0000B2   356 _GPIO_IE	=	0x00b2
                           008584   357 _ROM_ADDR	=	0x8584
                           000084   358 _ROM_ADDR_L	=	0x0084
                           000085   359 _ROM_ADDR_H	=	0x0085
                           008F8E   360 _ROM_DATA_HI	=	0x8f8e
                           00008E   361 _ROM_DATA_HL	=	0x008e
                           00008F   362 _ROM_DATA_HH	=	0x008f
                           000086   363 _ROM_CTRL	=	0x0086
                           000080   364 _P0	=	0x0080
                           0000C4   365 _P0_MOD_OC	=	0x00c4
                           0000C5   366 _P0_DIR_PU	=	0x00c5
                           000090   367 _P1	=	0x0090
                           000092   368 _P1_MOD_OC	=	0x0092
                           000093   369 _P1_DIR_PU	=	0x0093
                           0000A0   370 _P2	=	0x00a0
                           000094   371 _P2_MOD_OC	=	0x0094
                           000095   372 _P2_DIR_PU	=	0x0095
                           0000B0   373 _P3	=	0x00b0
                           000096   374 _P3_MOD_OC	=	0x0096
                           000097   375 _P3_DIR_PU	=	0x0097
                           0000C0   376 _P4	=	0x00c0
                           0000C2   377 _P4_MOD_OC	=	0x00c2
                           0000C3   378 _P4_DIR_PU	=	0x00c3
                           0000C1   379 _P4_LED_KEY	=	0x00c1
                           0000AA   380 _P5_IN	=	0x00aa
                           0000AB   381 _P5_OUT_PU	=	0x00ab
                           0000AC   382 _P5_DIR	=	0x00ac
                           0000AD   383 _P6_IN	=	0x00ad
                           0000AE   384 _P6_OUT_PU	=	0x00ae
                           0000AF   385 _P6_DIR	=	0x00af
                           0000F1   386 _P7	=	0x00f1
                           0000A2   387 _XBUS_AUX	=	0x00a2
                           000088   388 _TCON	=	0x0088
                           000089   389 _TMOD	=	0x0089
                           00008A   390 _TL0	=	0x008a
                           00008B   391 _TL1	=	0x008b
                           00008C   392 _TH0	=	0x008c
                           00008D   393 _TH1	=	0x008d
                           000098   394 _SCON	=	0x0098
                           000099   395 _SBUF	=	0x0099
                           0000C8   396 _T2CON	=	0x00c8
                           0000C9   397 _T2MOD	=	0x00c9
                           00CBCA   398 _RCAP2	=	0xcbca
                           0000CA   399 _RCAP2L	=	0x00ca
                           0000CB   400 _RCAP2H	=	0x00cb
                           00CDCC   401 _T2COUNT	=	0xcdcc
                           0000CC   402 _TL2	=	0x00cc
                           0000CD   403 _TH2	=	0x00cd
                           00CFCE   404 _T2CAP1	=	0xcfce
                           0000CE   405 _T2CAP1L	=	0x00ce
                           0000CF   406 _T2CAP1H	=	0x00cf
                           0000F8   407 _SPI0_STAT	=	0x00f8
                           0000F9   408 _SPI0_DATA	=	0x00f9
                           0000FA   409 _SPI0_CTRL	=	0x00fa
                           0000FB   410 _SPI0_CK_SE	=	0x00fb
                           0000FC   411 _SPI0_SETUP	=	0x00fc
                           0000BC   412 _SCON1	=	0x00bc
                           0000BD   413 _SBUF1	=	0x00bd
                           0000BE   414 _SBAUD1	=	0x00be
                           0000BF   415 _SIF1	=	0x00bf
                           0000B4   416 _SPI1_STAT	=	0x00b4
                           0000B5   417 _SPI1_DATA	=	0x00b5
                           0000B6   418 _SPI1_CTRL	=	0x00b6
                           0000B7   419 _SPI1_CK_SE	=	0x00b7
                           0000F3   420 _ADC_CTRL	=	0x00f3
                           00F5F4   421 _ADC_DAT	=	0xf5f4
                           0000F4   422 _ADC_DAT_L	=	0x00f4
                           0000F5   423 _ADC_DAT_H	=	0x00f5
                           0000F6   424 _ADC_CHAN	=	0x00f6
                           0000A6   425 _LED_COMMON	=	0x00a6
                           0000A7   426 _LED_PWM_OE	=	0x00a7
                           00C7C6   427 _LED_DMA	=	0xc7c6
                           0000C6   428 _LED_DMA_L	=	0x00c6
                           0000C7   429 _LED_DMA_H	=	0x00c7
                           0000F7   430 _LED_STATUS	=	0x00f7
                           0000B3   431 _I2CX_INT	=	0x00b3
                           0000BB   432 _I2CS_INT_ST	=	0x00bb
                                    433 ;--------------------------------------------------------
                                    434 ; special function bits
                                    435 ;--------------------------------------------------------
                                    436 	.area RSEG    (ABS,DATA)
      000000                        437 	.org 0x0000
                           0000D7   438 _CY	=	0x00d7
                           0000D6   439 _AC	=	0x00d6
                           0000D5   440 _F0	=	0x00d5
                           0000D4   441 _RS1	=	0x00d4
                           0000D3   442 _RS0	=	0x00d3
                           0000D2   443 _OV	=	0x00d2
                           0000D1   444 _F1	=	0x00d1
                           0000D0   445 _P	=	0x00d0
                           0000AF   446 _EA	=	0x00af
                           0000AE   447 _E_DIS	=	0x00ae
                           0000AD   448 _ET2	=	0x00ad
                           0000AC   449 _ES	=	0x00ac
                           0000AB   450 _ET1	=	0x00ab
                           0000AA   451 _EX1	=	0x00aa
                           0000A9   452 _ET0	=	0x00a9
                           0000A8   453 _EX0	=	0x00a8
                           0000BF   454 _PH_FLAG	=	0x00bf
                           0000BE   455 _PL_FLAG	=	0x00be
                           0000BD   456 _PT2	=	0x00bd
                           0000BC   457 _PS	=	0x00bc
                           0000BB   458 _PT1	=	0x00bb
                           0000BA   459 _PX1	=	0x00ba
                           0000B9   460 _PT0	=	0x00b9
                           0000B8   461 _PX0	=	0x00b8
                           0000EF   462 _IE_WDOG	=	0x00ef
                           0000EE   463 _IE_GPIO	=	0x00ee
                           0000ED   464 _IE_PWM_I2C	=	0x00ed
                           0000EC   465 _IE_UART1	=	0x00ec
                           0000EB   466 _IE_ADC	=	0x00eb
                           0000E9   467 _IE_USB	=	0x00e9
                           0000E8   468 _IE_SPI0	=	0x00e8
                           000087   469 _P0_7	=	0x0087
                           000086   470 _P0_6	=	0x0086
                           000085   471 _P0_5	=	0x0085
                           000084   472 _P0_4	=	0x0084
                           000083   473 _P0_3	=	0x0083
                           000082   474 _P0_2	=	0x0082
                           000081   475 _P0_1	=	0x0081
                           000080   476 _P0_0	=	0x0080
                           000081   477 _SDA0	=	0x0081
                           000080   478 _SCL0	=	0x0080
                           000083   479 _TXD_	=	0x0083
                           000082   480 _RXD_	=	0x0082
                           000085   481 _AIN13	=	0x0085
                           000084   482 _AIN12	=	0x0084
                           000083   483 _AIN11	=	0x0083
                           000082   484 _AIN10	=	0x0082
                           000081   485 _AIN9	=	0x0081
                           000080   486 _AIN8	=	0x0080
                           000097   487 _P1_7	=	0x0097
                           000096   488 _P1_6	=	0x0096
                           000095   489 _P1_5	=	0x0095
                           000094   490 _P1_4	=	0x0094
                           000093   491 _P1_3	=	0x0093
                           000092   492 _P1_2	=	0x0092
                           000091   493 _P1_1	=	0x0091
                           000090   494 _P1_0	=	0x0090
                           000097   495 _TXD1_	=	0x0097
                           000096   496 _RXD1_	=	0x0096
                           000097   497 _SCK	=	0x0097
                           000096   498 _MISO	=	0x0096
                           000095   499 _MOSI	=	0x0095
                           000094   500 _SCS	=	0x0094
                           000092   501 _INT0_	=	0x0092
                           000091   502 _T2EX	=	0x0091
                           000091   503 _CAP2	=	0x0091
                           000090   504 _T2	=	0x0090
                           000090   505 _CAP1	=	0x0090
                           000097   506 _AIN7	=	0x0097
                           000096   507 _AIN6	=	0x0096
                           000095   508 _AIN5	=	0x0095
                           000094   509 _AIN4	=	0x0094
                           000093   510 _AIN3	=	0x0093
                           000092   511 _AIN2	=	0x0092
                           000091   512 _AIN1	=	0x0091
                           000090   513 _AIN0	=	0x0090
                           0000A7   514 _P2_7	=	0x00a7
                           0000A6   515 _P2_6	=	0x00a6
                           0000A5   516 _P2_5	=	0x00a5
                           0000A4   517 _P2_4	=	0x00a4
                           0000A3   518 _P2_3	=	0x00a3
                           0000A2   519 _P2_2	=	0x00a2
                           0000A1   520 _P2_1	=	0x00a1
                           0000A0   521 _P2_0	=	0x00a0
                           0000A7   522 _TXD1	=	0x00a7
                           0000A6   523 _RXD1	=	0x00a6
                           0000A5   524 _T2EX_	=	0x00a5
                           0000A5   525 _CAP2_	=	0x00a5
                           0000A4   526 _T2_	=	0x00a4
                           0000A4   527 _CAP1_	=	0x00a4
                           0000B7   528 _P3_7	=	0x00b7
                           0000B6   529 _P3_6	=	0x00b6
                           0000B5   530 _P3_5	=	0x00b5
                           0000B4   531 _P3_4	=	0x00b4
                           0000B3   532 _P3_3	=	0x00b3
                           0000B2   533 _P3_2	=	0x00b2
                           0000B1   534 _P3_1	=	0x00b1
                           0000B0   535 _P3_0	=	0x00b0
                           0000B7   536 _SCK1	=	0x00b7
                           0000B6   537 _MISO1	=	0x00b6
                           0000B5   538 _MOSI1	=	0x00b5
                           0000B5   539 _T1	=	0x00b5
                           0000B4   540 _T0	=	0x00b4
                           0000B3   541 _INT1	=	0x00b3
                           0000B2   542 _INT0	=	0x00b2
                           0000B1   543 _TXD	=	0x00b1
                           0000B0   544 _RXD	=	0x00b0
                           0000C6   545 _P4_6	=	0x00c6
                           0000C5   546 _P4_5	=	0x00c5
                           0000C4   547 _P4_4	=	0x00c4
                           0000C3   548 _P4_3	=	0x00c3
                           0000C2   549 _P4_2	=	0x00c2
                           0000C1   550 _P4_1	=	0x00c1
                           0000C0   551 _P4_0	=	0x00c0
                           00008F   552 _TF1	=	0x008f
                           00008E   553 _TR1	=	0x008e
                           00008D   554 _TF0	=	0x008d
                           00008C   555 _TR0	=	0x008c
                           00008B   556 _IE1	=	0x008b
                           00008A   557 _IT1	=	0x008a
                           000089   558 _IE0	=	0x0089
                           000088   559 _IT0	=	0x0088
                           00009F   560 _SM0	=	0x009f
                           00009E   561 _SM1	=	0x009e
                           00009D   562 _SM2	=	0x009d
                           00009C   563 _REN	=	0x009c
                           00009B   564 _TB8	=	0x009b
                           00009A   565 _RB8	=	0x009a
                           000099   566 _TI	=	0x0099
                           000098   567 _RI	=	0x0098
                           0000CF   568 _TF2	=	0x00cf
                           0000CF   569 _CAP1F	=	0x00cf
                           0000CE   570 _EXF2	=	0x00ce
                           0000CD   571 _RCLK	=	0x00cd
                           0000CC   572 _TCLK	=	0x00cc
                           0000CB   573 _EXEN2	=	0x00cb
                           0000CA   574 _TR2	=	0x00ca
                           0000C9   575 _C_T2	=	0x00c9
                           0000C8   576 _CP_RL2	=	0x00c8
                           0000FF   577 _S0_FST_ACT	=	0x00ff
                           0000FE   578 _S0_IF_OV	=	0x00fe
                           0000FD   579 _S0_IF_FIRST	=	0x00fd
                           0000FC   580 _S0_IF_BYTE	=	0x00fc
                           0000FB   581 _S0_FREE	=	0x00fb
                           0000FA   582 _S0_T_FIFO	=	0x00fa
                           0000F8   583 _S0_R_FIFO	=	0x00f8
                           0000F7   584 _ADC_START	=	0x00f7
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable register banks
                                    587 ;--------------------------------------------------------
                                    588 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        589 	.ds 8
                                    590 ;--------------------------------------------------------
                                    591 ; internal ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area DSEG    (DATA)
      000027                        594 _process_record_sloc0_1_0:
      000027                        595 	.ds 1
      000028                        596 _process_action_sloc0_1_0:
      000028                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; overlayable items in internal ram
                                    600 ;--------------------------------------------------------
                                    601 ;--------------------------------------------------------
                                    602 ; indirectly addressable internal ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area ISEG    (DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; absolute internal ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area IABS    (ABS,DATA)
                                    609 	.area IABS    (ABS,DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; bit data
                                    612 ;--------------------------------------------------------
                                    613 	.area BSEG    (BIT)
      00001F                        614 _process_action_sloc1_1_0:
      00001F                        615 	.ds 1
                                    616 ;--------------------------------------------------------
                                    617 ; paged external ram data
                                    618 ;--------------------------------------------------------
                                    619 	.area PSEG    (PAG,XDATA)
                                    620 ;--------------------------------------------------------
                                    621 ; uninitialized external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area XSEG    (XDATA)
      000882                        624 _tp_buttons::
      000882                        625 	.ds 2
      000884                        626 _action_exec_PARM_1:
      000884                        627 	.ds 6
      00088A                        628 _action_exec_record_10001_632:
      00088A                        629 	.ds 9
      000893                        630 _ak820_action_exec_event_10000_637:
      000893                        631 	.ds 2
      000895                        632 _ak820_action_exec_snapshot_10000_638:
      000895                        633 	.ds 6
      00089B                        634 _process_record_record_argument_10000_641:
      00089B                        635 	.ds 2
      00089D                        636 _process_record_handler_record_argument_10000_650:
      00089D                        637 	.ds 2
      00089F                        638 _process_record_handler_action_10000_651:
      00089F                        639 	.ds 2
      0008A1                        640 _process_action_PARM_2:
      0008A1                        641 	.ds 2
      0008A3                        642 _process_action_record_argument_10000_662:
      0008A3                        643 	.ds 2
      0008A5                        644 _process_action_on_40000_685:
      0008A5                        645 	.ds 1
      0008A6                        646 _register_code_code_10000_719:
      0008A6                        647 	.ds 1
      0008A7                        648 _unregister_code_code_10000_733:
      0008A7                        649 	.ds 1
      0008A8                        650 _tap_code_delay_PARM_2:
      0008A8                        651 	.ds 2
      0008AA                        652 _tap_code_delay_code_10000_746:
      0008AA                        653 	.ds 1
      0008AB                        654 _tap_code_code_10000_753:
      0008AB                        655 	.ds 1
      0008AC                        656 _register_mods_mods_10000_755:
      0008AC                        657 	.ds 1
      0008AD                        658 _unregister_mods_mods_10000_759:
      0008AD                        659 	.ds 1
      0008AE                        660 _register_weak_mods_mods_10000_763:
      0008AE                        661 	.ds 1
      0008AF                        662 _unregister_weak_mods_mods_10000_767:
      0008AF                        663 	.ds 1
                                    664 ;--------------------------------------------------------
                                    665 ; absolute external ram data
                                    666 ;--------------------------------------------------------
                                    667 	.area XABS    (ABS,XDATA)
                                    668 ;--------------------------------------------------------
                                    669 ; initialized external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XISEG   (XDATA)
      000E09                        672 _disable_action_cache::
      000E09                        673 	.ds 1
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT0 (CODE)
                                    676 	.area GSINIT1 (CODE)
                                    677 	.area GSINIT2 (CODE)
                                    678 	.area GSINIT3 (CODE)
                                    679 	.area GSINIT4 (CODE)
                                    680 	.area GSINIT5 (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 	.area GSFINAL (CODE)
                                    683 	.area CSEG    (CODE)
                                    684 ;--------------------------------------------------------
                                    685 ; global & static initialisations
                                    686 ;--------------------------------------------------------
                                    687 	.area HOME    (CODE)
                                    688 	.area GSINIT  (CODE)
                                    689 	.area GSFINAL (CODE)
                                    690 	.area GSINIT  (CODE)
                                    691 ;--------------------------------------------------------
                                    692 ; Home
                                    693 ;--------------------------------------------------------
                                    694 	.area HOME    (CODE)
                                    695 	.area HOME    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; code
                                    698 ;--------------------------------------------------------
                                    699 	.area CSEG    (CODE)
                                    700 ;------------------------------------------------------------
                                    701 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    702 ;------------------------------------------------------------
                                    703 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    704 ;------------------------------------------------------------
                                    705 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    706 ;	-----------------------------------------
                           000007   707 	ar7 = 0x07
                           000006   708 	ar6 = 0x06
                           000005   709 	ar5 = 0x05
                           000004   710 	ar4 = 0x04
                           000003   711 	ar3 = 0x03
                           000002   712 	ar2 = 0x02
                           000001   713 	ar1 = 0x01
                           000000   714 	ar0 = 0x00
                                    715 ;	 function action_exec
                                    716 ;	-----------------------------------------
      00771B                        717 _action_exec:
                                    718 ;	quantum/action.c:98: ak820_dynamic_macro_task(event.time);
      00771B 90 08 86         [24]  719 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00771E 12 37 97         [24]  720 	lcall	_ak820_outline_0004
      007721 12 3A C4         [24]  721 	lcall	_ak820_dynamic_macro_task
                                    722 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007724 90 08 86         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007727 12 37 97         [24]  724 	lcall	_ak820_outline_0004
      00772A 12 35 B7         [24]  725 	lcall	_ak820_combo_tick
                                    726 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      00772D 90 08 84         [24]  727 	mov	dptr,#_action_exec_PARM_1
      007730 12 4A AE         [24]  728 	lcall	_ak820_tapping_before
      007733 E5 82            [12]  729 	mov	a, dpl
      007735 70 01            [24]  730 	jnz	00102$
      007737 22               [24]  731 	ret
      007738                        732 00102$:
                                    733 ;	quantum/action.c:126: if (event.pressed) {
      007738 90 08 89         [24]  734 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00773B E0               [24]  735 	movx	a,@dptr
      00773C 60 03            [24]  736 	jz	00104$
                                    737 ;	quantum/action.c:128: clear_weak_mods();
      00773E 12 87 B3         [24]  738 	lcall	_clear_weak_mods
      007741                        739 00104$:
                                    740 ;	quantum/action.c:140: record.event = event;
      007741 90 0D E8         [24]  741 	mov	dptr,#___memcpy_PARM_2
      007744 74 84            [12]  742 	mov	a,#_action_exec_PARM_1
      007746 F0               [24]  743 	movx	@dptr,a
      007747 74 08            [12]  744 	mov	a,#(_action_exec_PARM_1 >> 8)
      007749 12 7E 3E         [24]  745 	lcall	_ak820_outline_0051
      00774C 12 7E 5E         [24]  746 	lcall	_ak820_outline_0108
      00774F 90 08 8A         [24]  747 	mov	dptr,#_action_exec_record_10001_632
      007752 F5 F0            [12]  748 	mov	b,a
      007754 12 BD AE         [24]  749 	lcall	___memcpy
                                    750 ;	quantum/action.c:142: record.tap.count = 0;
      007757 90 08 90         [24]  751 	mov	dptr,#(_action_exec_record_10001_632 + 0x0006)
      00775A E0               [24]  752 	movx	a,@dptr
      00775B 54 0F            [12]  753 	anl	a,#0x0f
      00775D F0               [24]  754 	movx	@dptr,a
                                    755 ;	quantum/action.c:147: record.keycode = 0;
      00775E 90 08 91         [24]  756 	mov	dptr,#(_action_exec_record_10001_632 + 0x0007)
      007761 12 55 7E         [24]  757 	lcall	_ak820_outline_0179
                                    758 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007764 90 08 8E         [24]  759 	mov	dptr,#(_action_exec_record_10001_632 + 0x0004)
      007767 E0               [24]  760 	movx	a,@dptr
      007768 60 0A            [24]  761 	jz	00107$
      00776A 90 08 8A         [24]  762 	mov	dptr,#_action_exec_record_10001_632
      00776D 12 A4 C7         [24]  763 	lcall	_pre_process_record_quantum
      007770 E5 82            [12]  764 	mov	a, dpl
      007772 60 11            [24]  765 	jz	00108$
      007774                        766 00107$:
                                    767 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007774 90 08 8A         [24]  768 	mov	dptr,#_action_exec_record_10001_632
      007777 12 4B 98         [24]  769 	lcall	_ak820_tapping_process
      00777A E5 82            [12]  770 	mov	a, dpl
      00777C 70 01            [24]  771 	jnz	00106$
      00777E 22               [24]  772 	ret
      00777F                        773 00106$:
                                    774 ;	quantum/action.c:185: process_record(&record);
      00777F 90 08 8A         [24]  775 	mov	dptr,#_action_exec_record_10001_632
      007782 12 77 D2         [24]  776 	lcall	_process_record
      007785                        777 00108$:
                                    778 ;	quantum/action.c:198: if (IS_NOEVENT(event)) ak820_leader_task(event.time);
      007785 90 08 88         [24]  779 	mov	dptr,#(_action_exec_PARM_1 + 0x0004)
      007788 E0               [24]  780 	movx	a,@dptr
      007789 70 09            [24]  781 	jnz	00112$
      00778B 90 08 86         [24]  782 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00778E 12 37 97         [24]  783 	lcall	_ak820_outline_0004
                                    784 ;	quantum/action.c:200: }
      007791 02 3E F9         [24]  785 	ljmp	_ak820_leader_task
      007794                        786 00112$:
      007794 22               [24]  787 	ret
                                    788 ;------------------------------------------------------------
                                    789 ;Allocation info for local variables in function 'ak820_action_exec'
                                    790 ;------------------------------------------------------------
                                    791 ;event         Allocated with name '_ak820_action_exec_event_10000_637'
                                    792 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_638'
                                    793 ;------------------------------------------------------------
                                    794 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    795 ;	-----------------------------------------
                                    796 ;	 function ak820_action_exec
                                    797 ;	-----------------------------------------
      007795                        798 _ak820_action_exec:
      007795 12 38 41         [24]  799 	lcall	_ak820_outline_0104
      007798 90 08 93         [24]  800 	mov	dptr,#_ak820_action_exec_event_10000_637
      00779B 12 38 46         [24]  801 	lcall	_ak820_outline_0105
                                    802 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      00779E 90 08 93         [24]  803 	mov	dptr,#_ak820_action_exec_event_10000_637
      0077A1 12 38 0E         [24]  804 	lcall	_ak820_outline_0058
      0077A4 90 0D E8         [24]  805 	mov	dptr,#___memcpy_PARM_2
      0077A7 ED               [12]  806 	mov	a,r5
      0077A8 12 37 D6         [24]  807 	lcall	_ak820_outline_0016
      0077AB 90 0D EB         [24]  808 	mov	dptr,#___memcpy_PARM_3
      0077AE 12 7E 5E         [24]  809 	lcall	_ak820_outline_0108
      0077B1 90 08 95         [24]  810 	mov	dptr,#_ak820_action_exec_snapshot_10000_638
      0077B4 F5 F0            [12]  811 	mov	b,a
      0077B6 12 BD AE         [24]  812 	lcall	___memcpy
                                    813 ;	quantum/action.c:207: action_exec(snapshot);
      0077B9 90 0D E8         [24]  814 	mov	dptr,#___memcpy_PARM_2
      0077BC 74 95            [12]  815 	mov	a,#_ak820_action_exec_snapshot_10000_638
      0077BE F0               [24]  816 	movx	@dptr,a
      0077BF 74 08            [12]  817 	mov	a,#(_ak820_action_exec_snapshot_10000_638 >> 8)
      0077C1 12 7E 3E         [24]  818 	lcall	_ak820_outline_0051
      0077C4 12 7E 5E         [24]  819 	lcall	_ak820_outline_0108
      0077C7 90 08 84         [24]  820 	mov	dptr,#_action_exec_PARM_1
      0077CA F5 F0            [12]  821 	mov	b,a
      0077CC 12 BD AE         [24]  822 	lcall	___memcpy
                                    823 ;	quantum/action.c:208: }
      0077CF 02 77 1B         [24]  824 	ljmp	_action_exec
                                    825 ;------------------------------------------------------------
                                    826 ;Allocation info for local variables in function 'process_record_nocache'
                                    827 ;------------------------------------------------------------
                                    828 ;record        Allocated with name '_process_record_nocache_record_10000_639'
                                    829 ;------------------------------------------------------------
                                    830 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    831 ;	-----------------------------------------
                                    832 ;	 function process_record
                                    833 ;	-----------------------------------------
      0077D2                        834 _process_record:
      0077D2 12 38 41         [24]  835 	lcall	_ak820_outline_0104
      0077D5 90 08 9B         [24]  836 	mov	dptr,#_process_record_record_argument_10000_641
      0077D8 12 38 46         [24]  837 	lcall	_ak820_outline_0105
                                    838 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0077DB 90 08 9B         [24]  839 	mov	dptr,#_process_record_record_argument_10000_641
      0077DE 12 37 F7         [24]  840 	lcall	_ak820_outline_0052
                                    841 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0077E1 74 04            [12]  842 	mov	a,#0x04
      0077E3 12 4E 6A         [24]  843 	lcall	_ak820_outline_0012
      0077E6 70 01            [24]  844 	jnz	00102$
                                    845 ;	quantum/action.c:354: return;
      0077E8 22               [24]  846 	ret
      0077E9                        847 00102$:
                                    848 ;	quantum/action.c:358: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      0077E9 12 38 1C         [24]  849 	lcall	_ak820_outline_0066
      0077EC FD               [12]  850 	mov	r5,a
      0077ED BD 10 00         [24]  851 	cjne	r5,#0x10,00192$
      0077F0                        852 00192$:
      0077F0 50 3D            [24]  853 	jnc	00104$
      0077F2 12 38 2F         [24]  854 	lcall	_ak820_outline_0091
      0077F5 FD               [12]  855 	mov	r5,a
      0077F6 BD 08 00         [24]  856 	cjne	r5,#0x08,00194$
      0077F9                        857 00194$:
      0077F9 50 34            [24]  858 	jnc	00104$
      0077FB 90 09 F4         [24]  859 	mov	dptr,#_ak820_macro_primitive
      0077FE E0               [24]  860 	movx	a,@dptr
      0077FF 70 2E            [24]  861 	jnz	00104$
                                    862 ;	quantum/action.c:359: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007801 90 0C 4A         [24]  863 	mov	dptr,#_get_record_keycode_PARM_2
      007804 12 4E A9         [24]  864 	lcall	_ak820_outline_0044
      007807 C0 07            [24]  865 	push	ar7
      007809 C0 06            [24]  866 	push	ar6
      00780B 12 A4 8A         [24]  867 	lcall	_get_record_keycode
      00780E 12 49 06         [24]  868 	lcall	_ak820_outline_0142
      007811 D0 06            [24]  869 	pop	ar6
      007813 D0 07            [24]  870 	pop	ar7
      007815 12 48 8A         [24]  871 	lcall	_ak820_outline_0010
      007818 E0               [24]  872 	movx	a,@dptr
      007819 90 04 AA         [24]  873 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      00781C 12 38 35         [24]  874 	lcall	_ak820_outline_0099
      00781F C0 07            [24]  875 	push	ar7
      007821 C0 06            [24]  876 	push	ar6
      007823 12 39 2B         [24]  877 	lcall	_ak820_dynamic_macro_process
      007826 E5 82            [12]  878 	mov	a, dpl
      007828 D0 06            [24]  879 	pop	ar6
      00782A D0 07            [24]  880 	pop	ar7
      00782C 70 01            [24]  881 	jnz	00104$
      00782E 22               [24]  882 	ret
      00782F                        883 00104$:
                                    884 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00782F 8E 04            [24]  885 	mov	ar4,r6
      007831 8F 05            [24]  886 	mov	ar5,r7
      007833 90 0D E8         [24]  887 	mov	dptr,#___memcpy_PARM_2
      007836 EC               [12]  888 	mov	a,r4
      007837 F0               [24]  889 	movx	@dptr,a
      007838 ED               [12]  890 	mov	a,r5
      007839 12 7E 3E         [24]  891 	lcall	_ak820_outline_0051
      00783C 12 55 70         [24]  892 	lcall	_ak820_outline_0107
      00783F 90 06 97         [24]  893 	mov	dptr,#_ak820_tapping_source_PARM_1
      007842 F5 F0            [12]  894 	mov	b,a
      007844 C0 07            [24]  895 	push	ar7
      007846 C0 06            [24]  896 	push	ar6
      007848 12 BD AE         [24]  897 	lcall	___memcpy
      00784B 12 49 EB         [24]  898 	lcall	_ak820_tapping_source
      00784E AD 82            [24]  899 	mov	r5, dpl
      007850 D0 06            [24]  900 	pop	ar6
      007852 D0 07            [24]  901 	pop	ar7
                                    902 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007854 12 48 8A         [24]  903 	lcall	_ak820_outline_0010
      007857 E0               [24]  904 	movx	a,@dptr
      007858 FC               [12]  905 	mov	r4,a
                                    906 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      007859 74 07            [12]  907 	mov	a,#0x07
      00785B 2E               [12]  908 	add	a, r6
      00785C FA               [12]  909 	mov	r2,a
      00785D E4               [12]  910 	clr	a
      00785E 3F               [12]  911 	addc	a, r7
      00785F FB               [12]  912 	mov	r3,a
      007860 90 0C 4A         [24]  913 	mov	dptr,#_get_record_keycode_PARM_2
      007863 12 4E A9         [24]  914 	lcall	_ak820_outline_0044
      007866 C0 07            [24]  915 	push	ar7
      007868 C0 06            [24]  916 	push	ar6
      00786A C0 05            [24]  917 	push	ar5
      00786C C0 04            [24]  918 	push	ar4
      00786E C0 03            [24]  919 	push	ar3
      007870 C0 02            [24]  920 	push	ar2
      007872 12 A4 8A         [24]  921 	lcall	_get_record_keycode
      007875 A8 82            [24]  922 	mov	r0, dpl
      007877 A9 83            [24]  923 	mov	r1, dph
      007879 D0 02            [24]  924 	pop	ar2
      00787B D0 03            [24]  925 	pop	ar3
      00787D D0 04            [24]  926 	pop	ar4
      00787F D0 05            [24]  927 	pop	ar5
      007881 D0 06            [24]  928 	pop	ar6
      007883 D0 07            [24]  929 	pop	ar7
      007885 12 49 01         [24]  930 	lcall	_ak820_outline_0141
      007888 E8               [12]  931 	mov	a,r0
      007889 F0               [24]  932 	movx	@dptr,a
      00788A E9               [12]  933 	mov	a,r1
      00788B A3               [24]  934 	inc	dptr
      00788C F0               [24]  935 	movx	@dptr,a
                                    936 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00788D 74 07            [12]  937 	mov	a,#0x07
      00788F 12 37 DE         [24]  938 	lcall	_ak820_outline_0017
      007892 FA               [12]  939 	mov	r2,a
      007893 A3               [24]  940 	inc	dptr
      007894 E0               [24]  941 	movx	a,@dptr
      007895 FB               [12]  942 	mov	r3,a
      007896 90 06 A7         [24]  943 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007899 ED               [12]  944 	mov	a,r5
      00789A F0               [24]  945 	movx	@dptr,a
      00789B 90 06 A8         [24]  946 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00789E EC               [12]  947 	mov	a,r4
      00789F F0               [24]  948 	movx	@dptr,a
      0078A0 12 49 01         [24]  949 	lcall	_ak820_outline_0141
      0078A3 C0 07            [24]  950 	push	ar7
      0078A5 C0 06            [24]  951 	push	ar6
      0078A7 C0 05            [24]  952 	push	ar5
      0078A9 C0 04            [24]  953 	push	ar4
      0078AB 12 4D 36         [24]  954 	lcall	_ak820_oneshot_process
      0078AE E5 82            [12]  955 	mov	a, dpl
      0078B0 D0 04            [24]  956 	pop	ar4
      0078B2 D0 05            [24]  957 	pop	ar5
      0078B4 D0 06            [24]  958 	pop	ar6
      0078B6 D0 07            [24]  959 	pop	ar7
      0078B8 70 01            [24]  960 	jnz	00109$
      0078BA 22               [24]  961 	ret
      0078BB                        962 00109$:
                                    963 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0078BB 12 48 E5         [24]  964 	lcall	_ak820_outline_0114
      0078BE C0 07            [24]  965 	push	ar7
      0078C0 C0 06            [24]  966 	push	ar6
      0078C2 C0 05            [24]  967 	push	ar5
      0078C4 C0 04            [24]  968 	push	ar4
      0078C6 12 A5 57         [24]  969 	lcall	_process_record_quantum
      0078C9 E5 82            [12]  970 	mov	a, dpl
      0078CB D0 04            [24]  971 	pop	ar4
      0078CD D0 05            [24]  972 	pop	ar5
      0078CF D0 06            [24]  973 	pop	ar6
      0078D1 D0 07            [24]  974 	pop	ar7
      0078D3 70 0A            [24]  975 	jnz	00111$
                                    976 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0078D5 90 06 07         [24]  977 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0078D8 EC               [12]  978 	mov	a,r4
      0078D9 F0               [24]  979 	movx	@dptr,a
      0078DA 8D 82            [24]  980 	mov	dpl, r5
                                    981 ;	quantum/action.c:376: return;
      0078DC 02 2E 6F         [24]  982 	ljmp	_ak820_oneshot_post
      0078DF                        983 00111$:
                                    984 ;	quantum/action.c:380: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      0078DF 12 38 1C         [24]  985 	lcall	_ak820_outline_0066
      0078E2 FB               [12]  986 	mov	r3,a
      0078E3 BB 10 00         [24]  987 	cjne	r3,#0x10,00200$
      0078E6                        988 00200$:
      0078E6 50 16            [24]  989 	jnc	00114$
      0078E8 12 38 2F         [24]  990 	lcall	_ak820_outline_0091
      0078EB FB               [12]  991 	mov	r3,a
      0078EC BB 08 00         [24]  992 	cjne	r3,#0x08,00202$
      0078EF                        993 00202$:
      0078EF 50 0D            [24]  994 	jnc	00114$
      0078F1 12 A7 D1         [24]  995 	lcall	_get_repeat_key_count
      0078F4 E5 82            [12]  996 	mov	a, dpl
      0078F6 70 06            [24]  997 	jnz	00114$
      0078F8 90 09 F4         [24]  998 	mov	dptr,#_ak820_macro_primitive
      0078FB E0               [24]  999 	movx	a,@dptr
      0078FC 60 05            [24] 1000 	jz	00115$
      0078FE                       1001 00114$:
      0078FE 75 27 00         [24] 1002 	mov	_process_record_sloc0_1_0,#0x00
      007901 80 03            [24] 1003 	sjmp	00116$
      007903                       1004 00115$:
      007903 75 27 01         [24] 1005 	mov	_process_record_sloc0_1_0,#0x01
      007906                       1006 00116$:
      007906 90 04 A9         [24] 1007 	mov	dptr,#_ak820_dynamic_macro_source
      007909 E5 27            [12] 1008 	mov	a,_process_record_sloc0_1_0
      00790B 12 48 C0         [24] 1009 	lcall	_ak820_outline_0061
                                   1010 ;	quantum/action.c:382: process_record_handler(record);
      00790E C0 05            [24] 1011 	push	ar5
      007910 C0 04            [24] 1012 	push	ar4
      007912 31 27            [24] 1013 	acall	_process_record_handler
      007914 D0 04            [24] 1014 	pop	ar4
      007916 D0 05            [24] 1015 	pop	ar5
                                   1016 ;	quantum/action.c:384: ak820_dynamic_macro_source = false;
      007918 90 04 A9         [24] 1017 	mov	dptr,#_ak820_dynamic_macro_source
      00791B E4               [12] 1018 	clr	a
      00791C F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00791D 90 06 07         [24] 1021 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007920 EC               [12] 1022 	mov	a,r4
      007921 F0               [24] 1023 	movx	@dptr,a
      007922 8D 82            [24] 1024 	mov	dpl, r5
                                   1025 ;	quantum/action.c:392: }
      007924 02 2E 6F         [24] 1026 	ljmp	_ak820_oneshot_post
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'process_record_handler'
                                   1029 ;------------------------------------------------------------
                                   1030 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_650'
                                   1031 ;record        Allocated with name '_process_record_handler_record_10000_651'
                                   1032 ;action        Allocated with name '_process_record_handler_action_10000_651'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function process_record_handler
                                   1037 ;	-----------------------------------------
      007927                       1038 _process_record_handler:
      007927 12 38 41         [24] 1039 	lcall	_ak820_outline_0104
      00792A 90 08 9D         [24] 1040 	mov	dptr,#_process_record_handler_record_argument_10000_650
      00792D 12 38 46         [24] 1041 	lcall	_ak820_outline_0105
                                   1042 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007930 90 08 9D         [24] 1043 	mov	dptr,#_process_record_handler_record_argument_10000_650
      007933 12 37 AE         [24] 1044 	lcall	_ak820_outline_0009
                                   1045 ;	quantum/action.c:405: if (record->keycode) {
      007936 4C               [12] 1046 	orl	a,r4
      007937 60 19            [24] 1047 	jz	00102$
                                   1048 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007939 12 38 57         [24] 1049 	lcall	_ak820_outline_0122
      00793C C0 07            [24] 1050 	push	ar7
      00793E C0 06            [24] 1051 	push	ar6
      007940 12 9B 6F         [24] 1052 	lcall	_action_for_keycode
      007943 12 49 06         [24] 1053 	lcall	_ak820_outline_0142
      007946 D0 06            [24] 1054 	pop	ar6
      007948 D0 07            [24] 1055 	pop	ar7
      00794A 90 08 9F         [24] 1056 	mov	dptr,#_process_record_handler_action_10000_651
      00794D 12 38 23         [24] 1057 	lcall	_ak820_outline_0072
      007950 80 2A            [24] 1058 	sjmp	00104$
      007952                       1059 00102$:
                                   1060 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007952 12 7E 26         [24] 1061 	lcall	_ak820_outline_0020
      007955 7A 00            [12] 1062 	mov	r2,#0x00
      007957 12 48 FB         [24] 1063 	lcall	_ak820_outline_0140
      00795A 12 48 8A         [24] 1064 	lcall	_ak820_outline_0010
      00795D E0               [24] 1065 	movx	a,@dptr
      00795E 90 09 DA         [24] 1066 	mov	dptr,#_ak820_resolve_key_PARM_2
      007961 F0               [24] 1067 	movx	@dptr,a
      007962 12 49 26         [24] 1068 	lcall	_ak820_outline_0186
      007965 C0 07            [24] 1069 	push	ar7
      007967 C0 06            [24] 1070 	push	ar6
      007969 12 81 BC         [24] 1071 	lcall	_ak820_resolve_key
      00796C 12 9B 6F         [24] 1072 	lcall	_action_for_keycode
      00796F 12 49 06         [24] 1073 	lcall	_ak820_outline_0142
      007972 D0 06            [24] 1074 	pop	ar6
      007974 D0 07            [24] 1075 	pop	ar7
      007976 90 08 9F         [24] 1076 	mov	dptr,#_process_record_handler_action_10000_651
      007979 12 38 23         [24] 1077 	lcall	_ak820_outline_0072
                                   1078 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00797C                       1079 00104$:
                                   1080 ;	quantum/action.c:429: process_action(record, action);
      00797C 90 0D E8         [24] 1081 	mov	dptr,#___memcpy_PARM_2
      00797F 74 9F            [12] 1082 	mov	a,#_process_record_handler_action_10000_651
      007981 F0               [24] 1083 	movx	@dptr,a
      007982 74 08            [12] 1084 	mov	a,#(_process_record_handler_action_10000_651 >> 8)
      007984 12 7E 3E         [24] 1085 	lcall	_ak820_outline_0051
      007987 12 55 70         [24] 1086 	lcall	_ak820_outline_0107
      00798A 90 08 A1         [24] 1087 	mov	dptr,#_process_action_PARM_2
      00798D F5 F0            [12] 1088 	mov	b,a
      00798F C0 07            [24] 1089 	push	ar7
      007991 C0 06            [24] 1090 	push	ar6
      007993 12 BD AE         [24] 1091 	lcall	___memcpy
      007996 D0 06            [24] 1092 	pop	ar6
      007998 D0 07            [24] 1093 	pop	ar7
      00799A 12 48 E5         [24] 1094 	lcall	_ak820_outline_0114
                                   1095 ;	quantum/action.c:430: }
      00799D 21 9F            [24] 1096 	ajmp	_process_action
                                   1097 ;------------------------------------------------------------
                                   1098 ;Allocation info for local variables in function 'register_mouse'
                                   1099 ;------------------------------------------------------------
                                   1100 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1101 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_659'
                                   1102 ;------------------------------------------------------------
                                   1103 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1104 ;	-----------------------------------------
                                   1105 ;	 function process_action
                                   1106 ;	-----------------------------------------
      00799F                       1107 _process_action:
      00799F 12 38 41         [24] 1108 	lcall	_ak820_outline_0104
      0079A2 90 08 A3         [24] 1109 	mov	dptr,#_process_action_record_argument_10000_662
      0079A5 12 38 46         [24] 1110 	lcall	_ak820_outline_0105
                                   1111 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0079A8 90 08 A3         [24] 1112 	mov	dptr,#_process_action_record_argument_10000_662
      0079AB 12 37 97         [24] 1113 	lcall	_ak820_outline_0004
                                   1114 ;	quantum/action.c:501: pressed = record->event.pressed;
      0079AE A3               [24] 1115 	inc	dptr
      0079AF A3               [24] 1116 	inc	dptr
      0079B0 A3               [24] 1117 	inc	dptr
      0079B1 A3               [24] 1118 	inc	dptr
      0079B2 A3               [24] 1119 	inc	dptr
      0079B3 E0               [24] 1120 	movx	a,@dptr
      0079B4 F5 28            [12] 1121 	mov	_process_action_sloc0_1_0,a
                                   1122 ;	quantum/action.c:525: switch (action.kind.id) {
      0079B6 90 08 A2         [24] 1123 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079B9 E0               [24] 1124 	movx	a,@dptr
      0079BA C4               [12] 1125 	swap	a
      0079BB 54 0F            [12] 1126 	anl	a,#0x0f
      0079BD FD               [12] 1127 	mov  r5,a
      0079BE 24 F4            [12] 1128 	add	a,#0xff - 0x0b
      0079C0 50 03            [24] 1129 	jnc	00434$
      0079C2 02 7C 3E         [24] 1130 	ljmp	00181$
      0079C5                       1131 00434$:
                                   1132 ;	free result
      0079C5 ED               [12] 1133 	mov	a,r5
      0079C6 24 0A            [12] 1134 	add	a,#(00435$-3-.)
      0079C8 83               [24] 1135 	movc	a,@a+pc
      0079C9 F5 82            [12] 1136 	mov	dpl,a
      0079CB ED               [12] 1137 	mov	a,r5
      0079CC 24 10            [12] 1138 	add	a,#(00436$-3-.)
      0079CE 83               [24] 1139 	movc	a,@a+pc
      0079CF F5 83            [12] 1140 	mov	dph,a
      0079D1 E4               [12] 1141 	clr	a
      0079D2 73               [24] 1142 	jmp	@a+dptr
      0079D3                       1143 00435$:
      0079D3 EB                    1144 	.db	00102$
      0079D4 EB                    1145 	.db	00102$
      0079D5 3E                    1146 	.db	00181$
      0079D6 3E                    1147 	.db	00181$
      0079D7 73                    1148 	.db	00123$
      0079D8 3E                    1149 	.db	00181$
      0079D9 3E                    1150 	.db	00181$
      0079DA 3E                    1151 	.db	00181$
      0079DB D3                    1152 	.db	00131$
      0079DC A5                    1153 	.db	00147$
      0079DD CB                    1154 	.db	00152$
      0079DE CB                    1155 	.db	00152$
      0079DF                       1156 00436$:
      0079DF 79                    1157 	.db	00102$>>8
      0079E0 79                    1158 	.db	00102$>>8
      0079E1 7C                    1159 	.db	00181$>>8
      0079E2 7C                    1160 	.db	00181$>>8
      0079E3 7A                    1161 	.db	00123$>>8
      0079E4 7C                    1162 	.db	00181$>>8
      0079E5 7C                    1163 	.db	00181$>>8
      0079E6 7C                    1164 	.db	00181$>>8
      0079E7 7A                    1165 	.db	00131$>>8
      0079E8 7B                    1166 	.db	00147$>>8
      0079E9 7B                    1167 	.db	00152$>>8
      0079EA 7B                    1168 	.db	00152$>>8
                                   1169 ;	quantum/action.c:528: case ACT_RMODS: {
      0079EB                       1170 00102$:
                                   1171 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0079EB 90 08 A2         [24] 1172 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079EE E0               [24] 1173 	movx	a,@dptr
      0079EF 54 F0            [12] 1174 	anl	a,#0xf0
      0079F1 70 06            [24] 1175 	jnz	00194$
      0079F3 12 7E 65         [24] 1176 	lcall	_ak820_outline_0109
      0079F6 FD               [12] 1177 	mov	r5,a
      0079F7 80 07            [24] 1178 	sjmp	00195$
      0079F9                       1179 00194$:
      0079F9 12 7E 65         [24] 1180 	lcall	_ak820_outline_0109
      0079FC C4               [12] 1181 	swap	a
      0079FD 54 F0            [12] 1182 	anl	a,#0xf0
      0079FF FD               [12] 1183 	mov	r5,a
      007A00                       1184 00195$:
                                   1185 ;	quantum/action.c:531: if (pressed) {
      007A00 E5 28            [12] 1186 	mov	a,_process_action_sloc0_1_0
      007A02 60 34            [24] 1187 	jz	00119$
                                   1188 ;	quantum/action.c:532: if (mods) {
      007A04 ED               [12] 1189 	mov	a,r5
      007A05 60 28            [24] 1190 	jz	00110$
                                   1191 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007A07 12 7E 77         [24] 1192 	lcall	_ak820_outline_0155
      007A0A FC               [12] 1193 	mov	r4,a
      007A0B BC E0 00         [24] 1194 	cjne	r4,#0xe0,00440$
      007A0E                       1195 00440$:
      007A0E 40 07            [24] 1196 	jc	00108$
      007A10 12 7E 77         [24] 1197 	lcall	_ak820_outline_0155
      007A13 24 18            [12] 1198 	add	a,#0xff - 0xe7
      007A15 50 09            [24] 1199 	jnc	00104$
                                   1200 ;	free result
      007A17                       1201 00108$:
      007A17 7B A1            [12] 1202 	mov	r3,#_process_action_PARM_2
      007A19 7C 08            [12] 1203 	mov	r4,#(_process_action_PARM_2 >> 8)
      007A1B 12 73 52         [24] 1204 	lcall	_ak820_outline_0118
      007A1E 70 07            [24] 1205 	jnz	00105$
      007A20                       1206 00104$:
                                   1207 ;	quantum/action.c:537: add_owned_mods(mods);
      007A20 8D 82            [24] 1208 	mov	dpl, r5
      007A22 12 83 D2         [24] 1209 	lcall	_add_owned_mods
      007A25 80 05            [24] 1210 	sjmp	00106$
      007A27                       1211 00105$:
                                   1212 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007A27 8D 82            [24] 1213 	mov	dpl, r5
      007A29 12 83 EE         [24] 1214 	lcall	_add_owned_weak_mods
      007A2C                       1215 00106$:
                                   1216 ;	quantum/action.c:541: send_keyboard_report();
      007A2C 12 87 03         [24] 1217 	lcall	_send_keyboard_report
      007A2F                       1218 00110$:
                                   1219 ;	quantum/action.c:543: register_code(action.key.code);
      007A2F 12 7E 4E         [24] 1220 	lcall	_ak820_outline_0077
      007A32 12 7C 55         [24] 1221 	lcall	_register_code
      007A35 02 7C 3E         [24] 1222 	ljmp	00181$
      007A38                       1223 00119$:
                                   1224 ;	quantum/action.c:545: unregister_code(action.key.code);
      007A38 12 7E 4E         [24] 1225 	lcall	_ak820_outline_0077
      007A3B C0 05            [24] 1226 	push	ar5
      007A3D 12 7C D1         [24] 1227 	lcall	_unregister_code
      007A40 D0 05            [24] 1228 	pop	ar5
                                   1229 ;	quantum/action.c:546: if (mods) {
      007A42 ED               [12] 1230 	mov	a,r5
      007A43 70 03            [24] 1231 	jnz	00444$
      007A45 02 7C 3E         [24] 1232 	ljmp	00181$
      007A48                       1233 00444$:
                                   1234 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007A48 12 7E 77         [24] 1235 	lcall	_ak820_outline_0155
      007A4B FC               [12] 1236 	mov	r4,a
      007A4C BC E0 00         [24] 1237 	cjne	r4,#0xe0,00445$
      007A4F                       1238 00445$:
      007A4F 40 07            [24] 1239 	jc	00115$
      007A51 12 7E 77         [24] 1240 	lcall	_ak820_outline_0155
      007A54 24 18            [12] 1241 	add	a,#0xff - 0xe7
      007A56 50 09            [24] 1242 	jnc	00111$
                                   1243 ;	free result
      007A58                       1244 00115$:
      007A58 7B A1            [12] 1245 	mov	r3,#_process_action_PARM_2
      007A5A 7C 08            [12] 1246 	mov	r4,#(_process_action_PARM_2 >> 8)
      007A5C 12 73 52         [24] 1247 	lcall	_ak820_outline_0118
      007A5F 70 07            [24] 1248 	jnz	00112$
      007A61                       1249 00111$:
                                   1250 ;	quantum/action.c:548: del_owned_mods(mods);
      007A61 8D 82            [24] 1251 	mov	dpl, r5
      007A63 12 83 E1         [24] 1252 	lcall	_del_owned_mods
      007A66 80 05            [24] 1253 	sjmp	00113$
      007A68                       1254 00112$:
                                   1255 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007A68 8D 82            [24] 1256 	mov	dpl, r5
      007A6A 12 83 FD         [24] 1257 	lcall	_del_owned_weak_mods
      007A6D                       1258 00113$:
                                   1259 ;	quantum/action.c:552: send_keyboard_report();
      007A6D 12 87 03         [24] 1260 	lcall	_send_keyboard_report
                                   1261 ;	quantum/action.c:555: } break;
      007A70 02 7C 3E         [24] 1262 	ljmp	00181$
                                   1263 ;	quantum/action.c:632: case ACT_USAGE:
      007A73                       1264 00123$:
                                   1265 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007A73 74 07            [12] 1266 	mov	a,#0x07
      007A75 12 37 EF         [24] 1267 	lcall	_ak820_outline_0031
      007A78 12 37 C2         [24] 1268 	lcall	_ak820_outline_0011
      007A7B C3               [12] 1269 	clr	c
      007A7C EC               [12] 1270 	mov	a,r4
      007A7D 94 A5            [12] 1271 	subb	a,#0xa5
      007A7F ED               [12] 1272 	mov	a,r5
      007A80 94 00            [12] 1273 	subb	a,#0x00
      007A82 40 15            [24] 1274 	jc	00125$
      007A84 74 C2            [12] 1275 	mov	a,#0xc2
      007A86 9C               [12] 1276 	subb	a,r4
      007A87 E4               [12] 1277 	clr	a
      007A88 9D               [12] 1278 	subb	a,r5
      007A89 40 0E            [24] 1279 	jc	00125$
                                   1280 ;	free result
                                   1281 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      007A8B 90 0B 01         [24] 1282 	mov	dptr,#_owned_usage_key_PARM_2
      007A8E E5 28            [12] 1283 	mov	a,_process_action_sloc0_1_0
      007A90 F0               [24] 1284 	movx	@dptr,a
      007A91 8E 82            [24] 1285 	mov	dpl, r6
      007A93 12 85 B0         [24] 1286 	lcall	_owned_usage_key
                                   1287 ;	quantum/action.c:640: break;
      007A96 02 7C 3E         [24] 1288 	ljmp	00181$
      007A99                       1289 00125$:
                                   1290 ;	quantum/action.c:643: switch (action.usage.page) {
      007A99 12 7E 55         [24] 1291 	lcall	_ak820_outline_0087
      007A9C FF               [12] 1292 	mov	r7,a
      007A9D 60 08            [24] 1293 	jz	00127$
      007A9F BF 01 02         [24] 1294 	cjne	r7,#0x01,00452$
      007AA2 80 19            [24] 1295 	sjmp	00128$
      007AA4                       1296 00452$:
      007AA4 02 7C 3E         [24] 1297 	ljmp	00181$
                                   1298 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007AA7                       1299 00127$:
                                   1300 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007AA7 E5 28            [12] 1301 	mov	a,_process_action_sloc0_1_0
      007AA9 60 05            [24] 1302 	jz	00196$
      007AAB 12 7E 6C         [24] 1303 	lcall	_ak820_outline_0130
      007AAE 80 04            [24] 1304 	sjmp	00197$
      007AB0                       1305 00196$:
      007AB0 7E 00            [12] 1306 	mov	r6,#0x00
      007AB2 7F 00            [12] 1307 	mov	r7,#0x00
      007AB4                       1308 00197$:
      007AB4 12 48 E5         [24] 1309 	lcall	_ak820_outline_0114
      007AB7 12 74 1B         [24] 1310 	lcall	_host_system_send
                                   1311 ;	quantum/action.c:646: break;
      007ABA 02 7C 3E         [24] 1312 	ljmp	00181$
                                   1313 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007ABD                       1314 00128$:
                                   1315 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007ABD E5 28            [12] 1316 	mov	a,_process_action_sloc0_1_0
      007ABF 60 05            [24] 1317 	jz	00198$
      007AC1 12 7E 6C         [24] 1318 	lcall	_ak820_outline_0130
      007AC4 80 04            [24] 1319 	sjmp	00199$
      007AC6                       1320 00198$:
      007AC6 7E 00            [12] 1321 	mov	r6,#0x00
      007AC8 7F 00            [12] 1322 	mov	r7,#0x00
      007ACA                       1323 00199$:
      007ACA 12 48 E5         [24] 1324 	lcall	_ak820_outline_0114
      007ACD 12 74 4A         [24] 1325 	lcall	_host_consumer_send
                                   1326 ;	quantum/action.c:651: break;
      007AD0 02 7C 3E         [24] 1327 	ljmp	00181$
                                   1328 ;	quantum/action.c:658: case ACT_LAYER: {
      007AD3                       1329 00131$:
                                   1330 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007AD3 90 08 A2         [24] 1331 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007AD6 E0               [24] 1332 	movx	a,@dptr
      007AD7 54 03            [12] 1333 	anl	a,#0x03
      007AD9 90 08 A5         [24] 1334 	mov	dptr,#_process_action_on_40000_685
      007ADC F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007ADD E0               [24] 1337 	movx	a,@dptr
      007ADE FF               [12] 1338 	mov	r7,a
      007ADF 60 11            [24] 1339 	jz	00200$
      007AE1 E5 28            [12] 1340 	mov	a,_process_action_sloc0_1_0
      007AE3 60 07            [24] 1341 	jz	00202$
      007AE5 8F 06            [24] 1342 	mov	ar6,r7
      007AE7 53 06 01         [24] 1343 	anl	ar6,#0x01
      007AEA 80 10            [24] 1344 	sjmp	00201$
      007AEC                       1345 00202$:
      007AEC 74 02            [12] 1346 	mov	a,#0x02
      007AEE 5F               [12] 1347 	anl	a,r7
      007AEF FE               [12] 1348 	mov	r6,a
      007AF0 80 0A            [24] 1349 	sjmp	00201$
      007AF2                       1350 00200$:
      007AF2 E5 28            [12] 1351 	mov	a,_process_action_sloc0_1_0
      007AF4 B4 01 00         [24] 1352 	cjne	a,#0x01,00457$
      007AF7                       1353 00457$:
      007AF7 92 1F            [24] 1354 	mov  _process_action_sloc1_1_0,c
      007AF9 E4               [12] 1355 	clr	a
      007AFA 33               [12] 1356 	rlc	a
      007AFB FE               [12] 1357 	mov	r6,a
      007AFC                       1358 00201$:
      007AFC EE               [12] 1359 	mov	a,r6
      007AFD 70 03            [24] 1360 	jnz	00458$
      007AFF 02 7C 3E         [24] 1361 	ljmp	00181$
      007B02                       1362 00458$:
                                   1363 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007B02 12 7E 77         [24] 1364 	lcall	_ak820_outline_0155
      007B05 C4               [12] 1365 	swap	a
      007B06 03               [12] 1366 	rr	a
      007B07 54 07            [12] 1367 	anl	a,#0x07
      007B09 25 E0            [12] 1368 	add	a,acc
      007B0B 25 E0            [12] 1369 	add	a,acc
      007B0D FF               [12] 1370 	mov	r7,a
                                   1371 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007B0E 12 7E 77         [24] 1372 	lcall	_ak820_outline_0155
      007B11 54 0F            [12] 1373 	anl	a,#0x0f
      007B13 FE               [12] 1374 	mov	r6,a
      007B14 8F F0            [24] 1375 	mov	b,r7
      007B16 05 F0            [12] 1376 	inc	b
      007B18 EE               [12] 1377 	mov	a,r6
      007B19 80 02            [24] 1378 	sjmp	00460$
      007B1B                       1379 00459$:
      007B1B 25 E0            [12] 1380 	add	a,acc
      007B1D                       1381 00460$:
      007B1D D5 F0 FB         [24] 1382 	djnz	b,00459$
      007B20 FE               [12] 1383 	mov	r6,a
                                   1384 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007B21 12 7E 77         [24] 1385 	lcall	_ak820_outline_0155
      007B24 30 E4 11         [24] 1386 	jnb	acc.4,00204$
      007B27 8F F0            [24] 1387 	mov	b,r7
      007B29 05 F0            [12] 1388 	inc	b
      007B2B 74 0F            [12] 1389 	mov	a,#0x0f
      007B2D 80 02            [24] 1390 	sjmp	00463$
      007B2F                       1391 00462$:
      007B2F 25 E0            [12] 1392 	add	a,acc
      007B31                       1393 00463$:
      007B31 D5 F0 FB         [24] 1394 	djnz	b,00462$
      007B34 F4               [12] 1395 	cpl	a
      007B35 FF               [12] 1396 	mov	r7,a
      007B36 80 02            [24] 1397 	sjmp	00205$
      007B38                       1398 00204$:
      007B38 7F 00            [12] 1399 	mov	r7,#0x00
      007B3A                       1400 00205$:
                                   1401 ;	quantum/action.c:666: bits |= mask;
      007B3A EE               [12] 1402 	mov	a,r6
      007B3B 42 07            [12] 1403 	orl	ar7,a
                                   1404 ;	quantum/action.c:667: if (!on) {
      007B3D 90 08 A5         [24] 1405 	mov	dptr,#_process_action_on_40000_685
      007B40 E0               [24] 1406 	movx	a,@dptr
      007B41 70 31            [24] 1407 	jnz	00143$
                                   1408 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007B43 12 7E 55         [24] 1409 	lcall	_ak820_outline_0087
      007B46 FE               [12] 1410 	mov	r6,a
      007B47 2E               [12] 1411 	add	a,r6
                                   1412 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007B48 90 7B 4C         [24] 1413 	mov	dptr,#00465$
      007B4B 73               [24] 1414 	jmp	@a+dptr
      007B4C                       1415 00465$:
      007B4C 80 06            [24] 1416 	sjmp	00132$
      007B4E 80 0C            [24] 1417 	sjmp	00133$
      007B50 80 12            [24] 1418 	sjmp	00134$
      007B52 80 18            [24] 1419 	sjmp	00135$
      007B54                       1420 00132$:
      007B54 8F 82            [24] 1421 	mov	dpl, r7
      007B56 12 7E D2         [24] 1422 	lcall	_default_layer_and
      007B59 02 7C 3E         [24] 1423 	ljmp	00181$
                                   1424 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007B5C                       1425 00133$:
      007B5C 8F 82            [24] 1426 	mov	dpl, r7
      007B5E 12 7E C2         [24] 1427 	lcall	_default_layer_or
      007B61 02 7C 3E         [24] 1428 	ljmp	00181$
                                   1429 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007B64                       1430 00134$:
      007B64 8F 82            [24] 1431 	mov	dpl, r7
      007B66 12 7E E7         [24] 1432 	lcall	_default_layer_xor
      007B69 02 7C 3E         [24] 1433 	ljmp	00181$
                                   1434 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007B6C                       1435 00135$:
      007B6C 8F 82            [24] 1436 	mov	dpl, r7
      007B6E 12 7E B8         [24] 1437 	lcall	_default_layer_set
                                   1438 ;	quantum/action.c:673: }
      007B71 02 7C 3E         [24] 1439 	ljmp	00181$
      007B74                       1440 00143$:
                                   1441 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007B74 12 7E 55         [24] 1442 	lcall	_ak820_outline_0087
      007B77 FE               [12] 1443 	mov	r6,a
      007B78 2E               [12] 1444 	add	a,r6
                                   1445 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007B79 90 7B 7D         [24] 1446 	mov	dptr,#00466$
      007B7C 73               [24] 1447 	jmp	@a+dptr
      007B7D                       1448 00466$:
      007B7D 80 06            [24] 1449 	sjmp	00137$
      007B7F 80 0C            [24] 1450 	sjmp	00138$
      007B81 80 12            [24] 1451 	sjmp	00139$
      007B83 80 18            [24] 1452 	sjmp	00140$
      007B85                       1453 00137$:
      007B85 8F 82            [24] 1454 	mov	dpl, r7
      007B87 12 80 67         [24] 1455 	lcall	_layer_and
      007B8A 02 7C 3E         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007B8D                       1458 00138$:
      007B8D 8F 82            [24] 1459 	mov	dpl, r7
      007B8F 12 80 56         [24] 1460 	lcall	_layer_or
      007B92 02 7C 3E         [24] 1461 	ljmp	00181$
                                   1462 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007B95                       1463 00139$:
      007B95 8F 82            [24] 1464 	mov	dpl, r7
      007B97 12 80 7D         [24] 1465 	lcall	_layer_xor
      007B9A 02 7C 3E         [24] 1466 	ljmp	00181$
                                   1467 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007B9D                       1468 00140$:
      007B9D 8F 82            [24] 1469 	mov	dpl, r7
      007B9F 12 7F F3         [24] 1470 	lcall	_layer_state_set
                                   1471 ;	quantum/action.c:683: break;
      007BA2 02 7C 3E         [24] 1472 	ljmp	00181$
                                   1473 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007BA5                       1474 00147$:
                                   1475 ;	quantum/action.c:686: if (pressed) {
      007BA5 E5 28            [12] 1476 	mov	a,_process_action_sloc0_1_0
      007BA7 60 11            [24] 1477 	jz	00149$
                                   1478 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007BA9 12 7E 65         [24] 1479 	lcall	_ak820_outline_0109
      007BAC F5 82            [12] 1480 	mov	dpl,a
      007BAE 12 7F 56         [24] 1481 	lcall	_layer_hold_on
                                   1482 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007BB1 12 7E 4E         [24] 1483 	lcall	_ak820_outline_0077
      007BB4 12 7D 90         [24] 1484 	lcall	_register_mods
      007BB7 02 7C 3E         [24] 1485 	ljmp	00181$
      007BBA                       1486 00149$:
                                   1487 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007BBA 12 7E 4E         [24] 1488 	lcall	_ak820_outline_0077
      007BBD 12 7D A4         [24] 1489 	lcall	_unregister_mods
                                   1490 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007BC0 12 7E 65         [24] 1491 	lcall	_ak820_outline_0109
      007BC3 F5 82            [12] 1492 	mov	dpl,a
      007BC5 12 7F 8D         [24] 1493 	lcall	_layer_hold_off
                                   1494 ;	quantum/action.c:693: break;
      007BC8 02 7C 3E         [24] 1495 	ljmp	00181$
                                   1496 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007BCB                       1497 00152$:
                                   1498 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007BCB 12 7E 77         [24] 1499 	lcall	_ak820_outline_0155
      007BCE FF               [12] 1500 	mov	r7,a
      007BCF BF F1 02         [24] 1501 	cjne	r7,#0xf1,00468$
      007BD2 80 0A            [24] 1502 	sjmp	00154$
      007BD4                       1503 00468$:
      007BD4 BF F2 02         [24] 1504 	cjne	r7,#0xf2,00469$
      007BD7 80 19            [24] 1505 	sjmp	00155$
      007BD9                       1506 00469$:
                                   1507 ;	quantum/action.c:712: momentary_layer_action:
      007BD9 BF F3 3B         [24] 1508 	cjne	r7,#0xf3,00160$
      007BDC 80 28            [24] 1509 	sjmp	00156$
      007BDE                       1510 00154$:
                                   1511 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007BDE E5 28            [12] 1512 	mov	a,_process_action_sloc0_1_0
      007BE0 60 08            [24] 1513 	jz	00206$
      007BE2 12 7E 35         [24] 1514 	lcall	_ak820_outline_0039
      007BE5 12 7F 56         [24] 1515 	lcall	_layer_hold_on
      007BE8 80 54            [24] 1516 	sjmp	00181$
      007BEA                       1517 00206$:
      007BEA 12 7E 35         [24] 1518 	lcall	_ak820_outline_0039
      007BED 12 7F 8D         [24] 1519 	lcall	_layer_hold_off
                                   1520 ;	quantum/action.c:714: break;
                                   1521 ;	quantum/action.c:715: case OP_OFF_ON:
      007BF0 80 4C            [24] 1522 	sjmp	00181$
      007BF2                       1523 00155$:
                                   1524 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007BF2 E5 28            [12] 1525 	mov	a,_process_action_sloc0_1_0
      007BF4 60 08            [24] 1526 	jz	00208$
      007BF6 12 7E 35         [24] 1527 	lcall	_ak820_outline_0039
      007BF9 12 80 38         [24] 1528 	lcall	_layer_off
      007BFC 80 40            [24] 1529 	sjmp	00181$
      007BFE                       1530 00208$:
      007BFE 12 7E 35         [24] 1531 	lcall	_ak820_outline_0039
      007C01 12 80 1D         [24] 1532 	lcall	_layer_on
                                   1533 ;	quantum/action.c:717: break;
                                   1534 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007C04 80 38            [24] 1535 	sjmp	00181$
      007C06                       1536 00156$:
                                   1537 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007C06 E5 28            [12] 1538 	mov	a,_process_action_sloc0_1_0
      007C08 60 08            [24] 1539 	jz	00210$
      007C0A 12 7E 35         [24] 1540 	lcall	_ak820_outline_0039
      007C0D 12 80 07         [24] 1541 	lcall	_layer_move
      007C10 80 2C            [24] 1542 	sjmp	00181$
      007C12                       1543 00210$:
      007C12 12 80 01         [24] 1544 	lcall	_layer_clear
                                   1545 ;	quantum/action.c:720: break;
                                   1546 ;	quantum/action.c:766: default:
      007C15 80 27            [24] 1547 	sjmp	00181$
      007C17                       1548 00160$:
                                   1549 ;	quantum/action.c:773: if (pressed) {
      007C17 E5 28            [12] 1550 	mov	a,_process_action_sloc0_1_0
      007C19 60 08            [24] 1551 	jz	00163$
                                   1552 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007C1B 12 7E 4E         [24] 1553 	lcall	_ak820_outline_0077
      007C1E 12 7C 55         [24] 1554 	lcall	_register_code
                                   1555 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007C21 80 1B            [24] 1556 	sjmp	00181$
      007C23                       1557 00163$:
                                   1558 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007C23 12 7E 77         [24] 1559 	lcall	_ak820_outline_0155
      007C26 FF               [12] 1560 	mov	r7,a
      007C27 BF 39 0E         [24] 1561 	cjne	r7,#0x39,00175$
                                   1562 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007C2A 7F 50            [12] 1563 	mov	r7,#0x50
      007C2C                       1564 00187$:
      007C2C EF               [12] 1565 	mov	a,r7
      007C2D 60 09            [24] 1566 	jz	00175$
      007C2F 90 00 01         [24] 1567 	mov	dptr,#0x0001
      007C32 12 5E E8         [24] 1568 	lcall	_mDelaymS
      007C35 1F               [12] 1569 	dec	r7
                                   1570 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007C36 80 F4            [24] 1571 	sjmp	00187$
      007C38                       1572 00175$:
                                   1573 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007C38 12 7E 4E         [24] 1574 	lcall	_ak820_outline_0077
      007C3B 12 7C D1         [24] 1575 	lcall	_unregister_code
                                   1576 ;	quantum/action.c:866: }
      007C3E                       1577 00181$:
                                   1578 ;	quantum/action.c:887: switch (action.kind.id) {
      007C3E 90 08 A2         [24] 1579 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007C41 E0               [24] 1580 	movx	a,@dptr
      007C42 C4               [12] 1581 	swap	a
      007C43 54 0F            [12] 1582 	anl	a,#0x0f
      007C45 FF               [12] 1583 	mov	r7,a
      007C46 BF 08 02         [24] 1584 	cjne	r7,#0x08,00478$
      007C49 80 03            [24] 1585 	sjmp	00183$
      007C4B                       1586 00478$:
      007C4B BF 09 06         [24] 1587 	cjne	r7,#0x09,00192$
                                   1588 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007C4E                       1589 00183$:
                                   1590 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007C4E 12 73 80         [24] 1591 	lcall	_host_keyboard_leds
                                   1592 ;	quantum/action.c:898: }
                                   1593 ;	quantum/action.c:951: }
      007C51 02 9E 22         [24] 1594 	ljmp	_led_set
      007C54                       1595 00192$:
      007C54 22               [24] 1596 	ret
                                   1597 ;------------------------------------------------------------
                                   1598 ;Allocation info for local variables in function 'register_code'
                                   1599 ;------------------------------------------------------------
                                   1600 ;code          Allocated with name '_register_code_code_10000_719'
                                   1601 ;------------------------------------------------------------
                                   1602 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1603 ;	-----------------------------------------
                                   1604 ;	 function register_code
                                   1605 ;	-----------------------------------------
      007C55                       1606 _register_code:
      007C55 E5 82            [12] 1607 	mov	a,dpl
      007C57 90 08 A6         [24] 1608 	mov	dptr,#_register_code_code_10000_719
      007C5A F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/action.c:958: if (code == KC_NO) {
      007C5B E0               [24] 1611 	movx	a,@dptr
      007C5C FF               [12] 1612 	mov	r7,a
      007C5D 70 01            [24] 1613 	jnz	00123$
                                   1614 ;	quantum/action.c:959: return;
      007C5F 22               [24] 1615 	ret
      007C60                       1616 00123$:
                                   1617 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007C60 BF 04 00         [24] 1618 	cjne	r7,#0x04,00186$
      007C63                       1619 00186$:
      007C63 40 21            [24] 1620 	jc	00119$
      007C65 EF               [12] 1621 	mov	a,r7
      007C66 24 5B            [12] 1622 	add	a,#0xff - 0xa4
      007C68 40 1C            [24] 1623 	jc	00119$
                                   1624 ;	free result
                                   1625 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007C6A 8F 82            [24] 1626 	mov	dpl, r7
      007C6C C0 07            [24] 1627 	push	ar7
      007C6E 12 84 71         [24] 1628 	lcall	_add_owned_key
      007C71 E5 82            [12] 1629 	mov	a, dpl
      007C73 D0 07            [24] 1630 	pop	ar7
      007C75 70 01            [24] 1631 	jnz	00104$
      007C77 22               [24] 1632 	ret
      007C78                       1633 00104$:
                                   1634 ;	quantum/action.c:1001: ak820_dynamic_macro_observe(code, true);
      007C78 90 04 AD         [24] 1635 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007C7B 74 01            [12] 1636 	mov	a,#0x01
      007C7D F0               [24] 1637 	movx	@dptr,a
      007C7E 8F 82            [24] 1638 	mov	dpl, r7
      007C80 12 39 D9         [24] 1639 	lcall	_ak820_dynamic_macro_observe
                                   1640 ;	quantum/action.c:1013: send_keyboard_report();
      007C83 02 87 03         [24] 1641 	ljmp	_send_keyboard_report
      007C86                       1642 00119$:
                                   1643 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007C86 12 7E 7C         [24] 1644 	lcall	_ak820_outline_0163
      007C89 BF E0 00         [24] 1645 	cjne	r7,#0xe0,00190$
      007C8C                       1646 00190$:
      007C8C 40 1A            [24] 1647 	jc	00115$
      007C8E EF               [12] 1648 	mov	a,r7
      007C8F 24 18            [12] 1649 	add	a,#0xff - 0xe7
      007C91 40 15            [24] 1650 	jc	00115$
                                   1651 ;	free result
                                   1652 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007C93 74 07            [12] 1653 	mov	a,#0x07
      007C95 5F               [12] 1654 	anl	a,r7
      007C96 12 7E 47         [24] 1655 	lcall	_ak820_outline_0063
      007C99 80 02            [24] 1656 	sjmp	00194$
      007C9B                       1657 00193$:
      007C9B 25 E0            [12] 1658 	add	a,acc
      007C9D                       1659 00194$:
      007C9D D5 F0 FB         [24] 1660 	djnz	b,00193$
      007CA0 F5 82            [12] 1661 	mov	dpl,a
      007CA2 12 83 D2         [24] 1662 	lcall	_add_owned_mods
                                   1663 ;	quantum/action.c:1016: send_keyboard_report();
      007CA5 02 87 03         [24] 1664 	ljmp	_send_keyboard_report
      007CA8                       1665 00115$:
                                   1666 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007CA8 12 7E 7C         [24] 1667 	lcall	_ak820_outline_0163
      007CAB BF A5 00         [24] 1668 	cjne	r7,#0xa5,00195$
      007CAE                       1669 00195$:
      007CAE 40 05            [24] 1670 	jc	00113$
      007CB0 EF               [12] 1671 	mov	a,r7
      007CB1 24 58            [12] 1672 	add	a,#0xff - 0xa7
      007CB3 50 0D            [24] 1673 	jnc	00108$
                                   1674 ;	free result
      007CB5                       1675 00113$:
      007CB5 12 7E 7C         [24] 1676 	lcall	_ak820_outline_0163
      007CB8 BF A8 00         [24] 1677 	cjne	r7,#0xa8,00198$
      007CBB                       1678 00198$:
      007CBB 40 13            [24] 1679 	jc	00125$
      007CBD EF               [12] 1680 	mov	a,r7
      007CBE 24 3D            [12] 1681 	add	a,#0xff - 0xc2
      007CC0 40 0E            [24] 1682 	jc	00125$
                                   1683 ;	free result
      007CC2                       1684 00108$:
                                   1685 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007CC2 12 7E 7C         [24] 1686 	lcall	_ak820_outline_0163
      007CC5 90 0B 01         [24] 1687 	mov	dptr,#_owned_usage_key_PARM_2
      007CC8 74 01            [12] 1688 	mov	a,#0x01
      007CCA F0               [24] 1689 	movx	@dptr,a
      007CCB 8F 82            [24] 1690 	mov	dpl, r7
                                   1691 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1692 ;	quantum/action.c:1031: }
      007CCD 02 85 B0         [24] 1693 	ljmp	_owned_usage_key
      007CD0                       1694 00125$:
      007CD0 22               [24] 1695 	ret
                                   1696 ;------------------------------------------------------------
                                   1697 ;Allocation info for local variables in function 'unregister_code'
                                   1698 ;------------------------------------------------------------
                                   1699 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function unregister_code
                                   1704 ;	-----------------------------------------
      007CD1                       1705 _unregister_code:
      007CD1 E5 82            [12] 1706 	mov	a,dpl
      007CD3 90 08 A7         [24] 1707 	mov	dptr,#_unregister_code_code_10000_733
      007CD6 F0               [24] 1708 	movx	@dptr,a
                                   1709 ;	quantum/action.c:1038: if (code == KC_NO) {
      007CD7 E0               [24] 1710 	movx	a,@dptr
      007CD8 FF               [12] 1711 	mov	r7,a
      007CD9 70 01            [24] 1712 	jnz	00121$
                                   1713 ;	quantum/action.c:1039: return;
      007CDB 22               [24] 1714 	ret
      007CDC                       1715 00121$:
                                   1716 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007CDC BF 04 00         [24] 1717 	cjne	r7,#0x04,00184$
      007CDF                       1718 00184$:
      007CDF 40 1F            [24] 1719 	jc	00117$
      007CE1 EF               [12] 1720 	mov	a,r7
      007CE2 24 5B            [12] 1721 	add	a,#0xff - 0xa4
      007CE4 40 1A            [24] 1722 	jc	00117$
                                   1723 ;	free result
                                   1724 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007CE6 8F 82            [24] 1725 	mov	dpl, r7
      007CE8 C0 07            [24] 1726 	push	ar7
      007CEA 12 84 EA         [24] 1727 	lcall	_del_owned_key
      007CED E5 82            [12] 1728 	mov	a, dpl
      007CEF D0 07            [24] 1729 	pop	ar7
      007CF1 70 01            [24] 1730 	jnz	00102$
      007CF3 22               [24] 1731 	ret
      007CF4                       1732 00102$:
                                   1733 ;	quantum/action.c:1075: ak820_dynamic_macro_observe(code, false);
      007CF4 90 04 AD         [24] 1734 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007CF7 12 7E 88         [24] 1735 	lcall	_ak820_outline_0185
      007CFA 12 39 D9         [24] 1736 	lcall	_ak820_dynamic_macro_observe
                                   1737 ;	quantum/action.c:1080: send_keyboard_report();
      007CFD 02 87 03         [24] 1738 	ljmp	_send_keyboard_report
      007D00                       1739 00117$:
                                   1740 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007D00 12 7E 82         [24] 1741 	lcall	_ak820_outline_0164
      007D03 BF E0 00         [24] 1742 	cjne	r7,#0xe0,00188$
      007D06                       1743 00188$:
      007D06 40 1A            [24] 1744 	jc	00113$
      007D08 EF               [12] 1745 	mov	a,r7
      007D09 24 18            [12] 1746 	add	a,#0xff - 0xe7
      007D0B 40 15            [24] 1747 	jc	00113$
                                   1748 ;	free result
                                   1749 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007D0D 74 07            [12] 1750 	mov	a,#0x07
      007D0F 5F               [12] 1751 	anl	a,r7
      007D10 12 7E 47         [24] 1752 	lcall	_ak820_outline_0063
      007D13 80 02            [24] 1753 	sjmp	00192$
      007D15                       1754 00191$:
      007D15 25 E0            [12] 1755 	add	a,acc
      007D17                       1756 00192$:
      007D17 D5 F0 FB         [24] 1757 	djnz	b,00191$
      007D1A F5 82            [12] 1758 	mov	dpl,a
      007D1C 12 83 E1         [24] 1759 	lcall	_del_owned_mods
                                   1760 ;	quantum/action.c:1083: send_keyboard_report();
      007D1F 02 87 03         [24] 1761 	ljmp	_send_keyboard_report
      007D22                       1762 00113$:
                                   1763 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007D22 12 7E 82         [24] 1764 	lcall	_ak820_outline_0164
      007D25 BF A5 00         [24] 1765 	cjne	r7,#0xa5,00193$
      007D28                       1766 00193$:
      007D28 40 05            [24] 1767 	jc	00111$
      007D2A EF               [12] 1768 	mov	a,r7
      007D2B 24 58            [12] 1769 	add	a,#0xff - 0xa7
      007D2D 50 0D            [24] 1770 	jnc	00106$
                                   1771 ;	free result
      007D2F                       1772 00111$:
      007D2F 12 7E 82         [24] 1773 	lcall	_ak820_outline_0164
      007D32 BF A8 00         [24] 1774 	cjne	r7,#0xa8,00196$
      007D35                       1775 00196$:
      007D35 40 11            [24] 1776 	jc	00123$
      007D37 EF               [12] 1777 	mov	a,r7
      007D38 24 3D            [12] 1778 	add	a,#0xff - 0xc2
      007D3A 40 0C            [24] 1779 	jc	00123$
                                   1780 ;	free result
      007D3C                       1781 00106$:
                                   1782 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007D3C 12 7E 82         [24] 1783 	lcall	_ak820_outline_0164
      007D3F 90 0B 01         [24] 1784 	mov	dptr,#_owned_usage_key_PARM_2
      007D42 12 7E 88         [24] 1785 	lcall	_ak820_outline_0185
                                   1786 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1787 ;	quantum/action.c:1098: }
      007D45 02 85 B0         [24] 1788 	ljmp	_owned_usage_key
      007D48                       1789 00123$:
      007D48 22               [24] 1790 	ret
                                   1791 ;------------------------------------------------------------
                                   1792 ;Allocation info for local variables in function 'tap_code_delay'
                                   1793 ;------------------------------------------------------------
                                   1794 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1795 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1796 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1797 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function tap_code_delay
                                   1802 ;	-----------------------------------------
      007D49                       1803 _tap_code_delay:
      007D49 E5 82            [12] 1804 	mov	a,dpl
      007D4B 90 08 AA         [24] 1805 	mov	dptr,#_tap_code_delay_code_10000_746
      007D4E F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action.c:1106: register_code(code);
      007D4F E0               [24] 1808 	movx	a,@dptr
      007D50 FF               [12] 1809 	mov	r7,a
      007D51 F5 82            [12] 1810 	mov	dpl,a
      007D53 C0 07            [24] 1811 	push	ar7
      007D55 91 55            [12] 1812 	acall	_register_code
      007D57 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007D59 90 08 A8         [24] 1815 	mov	dptr,#_tap_code_delay_PARM_2
      007D5C 12 48 D3         [24] 1816 	lcall	_ak820_outline_0095
      007D5F                       1817 00110$:
      007D5F ED               [12] 1818 	mov	a,r5
      007D60 4E               [12] 1819 	orl	a,r6
      007D61 60 0D            [24] 1820 	jz	00105$
                                   1821 ;	quantum/action.c:1108: wait_ms(1);
      007D63 90 00 01         [24] 1822 	mov	dptr,#0x0001
      007D66 12 5E E8         [24] 1823 	lcall	_mDelaymS
                                   1824 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007D69 1D               [12] 1825 	dec	r5
      007D6A BD FF 01         [24] 1826 	cjne	r5,#0xff,00141$
      007D6D 1E               [12] 1827 	dec	r6
      007D6E                       1828 00141$:
      007D6E 80 EF            [24] 1829 	sjmp	00110$
      007D70                       1830 00105$:
                                   1831 ;	quantum/action.c:1110: unregister_code(code);
      007D70 8F 82            [24] 1832 	mov	dpl, r7
                                   1833 ;	quantum/action.c:1111: }
      007D72 81 D1            [12] 1834 	ajmp	_unregister_code
                                   1835 ;------------------------------------------------------------
                                   1836 ;Allocation info for local variables in function 'tap_code'
                                   1837 ;------------------------------------------------------------
                                   1838 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1839 ;------------------------------------------------------------
                                   1840 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1841 ;	-----------------------------------------
                                   1842 ;	 function tap_code
                                   1843 ;	-----------------------------------------
      007D74                       1844 _tap_code:
      007D74 E5 82            [12] 1845 	mov	a,dpl
      007D76 90 08 AB         [24] 1846 	mov	dptr,#_tap_code_code_10000_753
      007D79 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007D7A E0               [24] 1849 	movx	a,@dptr
      007D7B FF               [12] 1850 	mov	r7,a
      007D7C BF 39 04         [24] 1851 	cjne	r7,#0x39,00103$
      007D7F 7E 50            [12] 1852 	mov	r6,#0x50
      007D81 80 02            [24] 1853 	sjmp	00104$
      007D83                       1854 00103$:
      007D83 7E 00            [12] 1855 	mov	r6,#0x00
      007D85                       1856 00104$:
      007D85 90 08 A8         [24] 1857 	mov	dptr,#_tap_code_delay_PARM_2
      007D88 EE               [12] 1858 	mov	a,r6
      007D89 12 38 5C         [24] 1859 	lcall	_ak820_outline_0124
      007D8C 8F 82            [24] 1860 	mov	dpl, r7
                                   1861 ;	quantum/action.c:1119: }
      007D8E A1 49            [12] 1862 	ajmp	_tap_code_delay
                                   1863 ;------------------------------------------------------------
                                   1864 ;Allocation info for local variables in function 'register_mods'
                                   1865 ;------------------------------------------------------------
                                   1866 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1867 ;------------------------------------------------------------
                                   1868 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1869 ;	-----------------------------------------
                                   1870 ;	 function register_mods
                                   1871 ;	-----------------------------------------
      007D90                       1872 _register_mods:
      007D90 E5 82            [12] 1873 	mov	a,dpl
      007D92 90 08 AC         [24] 1874 	mov	dptr,#_register_mods_mods_10000_755
      007D95 F0               [24] 1875 	movx	@dptr,a
                                   1876 ;	quantum/action.c:1126: if (mods) {
      007D96 E0               [24] 1877 	movx	a,@dptr
      007D97 FF               [12] 1878 	mov	r7,a
      007D98 E0               [24] 1879 	movx	a,@dptr
      007D99 60 08            [24] 1880 	jz	00103$
                                   1881 ;	quantum/action.c:1127: add_owned_mods(mods);
      007D9B 8F 82            [24] 1882 	mov	dpl, r7
      007D9D 12 83 D2         [24] 1883 	lcall	_add_owned_mods
                                   1884 ;	quantum/action.c:1128: send_keyboard_report();
                                   1885 ;	quantum/action.c:1130: }
      007DA0 02 87 03         [24] 1886 	ljmp	_send_keyboard_report
      007DA3                       1887 00103$:
      007DA3 22               [24] 1888 	ret
                                   1889 ;------------------------------------------------------------
                                   1890 ;Allocation info for local variables in function 'unregister_mods'
                                   1891 ;------------------------------------------------------------
                                   1892 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1893 ;------------------------------------------------------------
                                   1894 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1895 ;	-----------------------------------------
                                   1896 ;	 function unregister_mods
                                   1897 ;	-----------------------------------------
      007DA4                       1898 _unregister_mods:
      007DA4 E5 82            [12] 1899 	mov	a,dpl
      007DA6 90 08 AD         [24] 1900 	mov	dptr,#_unregister_mods_mods_10000_759
      007DA9 F0               [24] 1901 	movx	@dptr,a
                                   1902 ;	quantum/action.c:1137: if (mods) {
      007DAA E0               [24] 1903 	movx	a,@dptr
      007DAB FF               [12] 1904 	mov	r7,a
      007DAC E0               [24] 1905 	movx	a,@dptr
      007DAD 60 08            [24] 1906 	jz	00103$
                                   1907 ;	quantum/action.c:1138: del_owned_mods(mods);
      007DAF 8F 82            [24] 1908 	mov	dpl, r7
      007DB1 12 83 E1         [24] 1909 	lcall	_del_owned_mods
                                   1910 ;	quantum/action.c:1139: send_keyboard_report();
                                   1911 ;	quantum/action.c:1141: }
      007DB4 02 87 03         [24] 1912 	ljmp	_send_keyboard_report
      007DB7                       1913 00103$:
      007DB7 22               [24] 1914 	ret
                                   1915 ;------------------------------------------------------------
                                   1916 ;Allocation info for local variables in function 'register_weak_mods'
                                   1917 ;------------------------------------------------------------
                                   1918 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1919 ;------------------------------------------------------------
                                   1920 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1921 ;	-----------------------------------------
                                   1922 ;	 function register_weak_mods
                                   1923 ;	-----------------------------------------
      007DB8                       1924 _register_weak_mods:
      007DB8 E5 82            [12] 1925 	mov	a,dpl
      007DBA 90 08 AE         [24] 1926 	mov	dptr,#_register_weak_mods_mods_10000_763
      007DBD F0               [24] 1927 	movx	@dptr,a
                                   1928 ;	quantum/action.c:1148: if (mods) {
      007DBE E0               [24] 1929 	movx	a,@dptr
      007DBF FF               [12] 1930 	mov	r7,a
      007DC0 E0               [24] 1931 	movx	a,@dptr
      007DC1 60 08            [24] 1932 	jz	00103$
                                   1933 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007DC3 8F 82            [24] 1934 	mov	dpl, r7
      007DC5 12 83 EE         [24] 1935 	lcall	_add_owned_weak_mods
                                   1936 ;	quantum/action.c:1150: send_keyboard_report();
                                   1937 ;	quantum/action.c:1152: }
      007DC8 02 87 03         [24] 1938 	ljmp	_send_keyboard_report
      007DCB                       1939 00103$:
      007DCB 22               [24] 1940 	ret
                                   1941 ;------------------------------------------------------------
                                   1942 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1943 ;------------------------------------------------------------
                                   1944 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function unregister_weak_mods
                                   1949 ;	-----------------------------------------
      007DCC                       1950 _unregister_weak_mods:
      007DCC E5 82            [12] 1951 	mov	a,dpl
      007DCE 90 08 AF         [24] 1952 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007DD1 F0               [24] 1953 	movx	@dptr,a
                                   1954 ;	quantum/action.c:1159: if (mods) {
      007DD2 E0               [24] 1955 	movx	a,@dptr
      007DD3 FF               [12] 1956 	mov	r7,a
      007DD4 E0               [24] 1957 	movx	a,@dptr
      007DD5 60 08            [24] 1958 	jz	00103$
                                   1959 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007DD7 8F 82            [24] 1960 	mov	dpl, r7
      007DD9 12 83 FD         [24] 1961 	lcall	_del_owned_weak_mods
                                   1962 ;	quantum/action.c:1161: send_keyboard_report();
                                   1963 ;	quantum/action.c:1163: }
      007DDC 02 87 03         [24] 1964 	ljmp	_send_keyboard_report
      007DDF                       1965 00103$:
      007DDF 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'clear_keyboard'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function clear_keyboard
                                   1973 ;	-----------------------------------------
      007DE0                       1974 _clear_keyboard:
                                   1975 ;	quantum/action.c:1170: clear_mods();
      007DE0 12 87 7E         [24] 1976 	lcall	_clear_mods
                                   1977 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1978 ;	quantum/action.c:1172: }
      007DE3 A1 E5            [12] 1979 	ajmp	_clear_keyboard_but_mods
                                   1980 ;------------------------------------------------------------
                                   1981 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1982 ;------------------------------------------------------------
                                   1983 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1984 ;	-----------------------------------------
                                   1985 ;	 function clear_keyboard_but_mods
                                   1986 ;	-----------------------------------------
      007DE5                       1987 _clear_keyboard_but_mods:
                                   1988 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007DE5 90 0E 0E         [24] 1989 	mov	dptr,#_actual_keyboard_report
      007DE8 12 76 39         [24] 1990 	lcall	_clear_keys_from_report
                                   1991 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1992 ;	quantum/action.c:1181: }
      007DEB A1 ED            [12] 1993 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function clear_keyboard_but_mods_and_keys
                                   2000 ;	-----------------------------------------
      007DED                       2001 _clear_keyboard_but_mods_and_keys:
                                   2002 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007DED 12 4D 15         [24] 2003 	lcall	_ak820_tapping_cancel
                                   2004 ;	quantum/action.c:1197: ak820_leader_cancel();
      007DF0 12 3E D8         [24] 2005 	lcall	_ak820_leader_cancel
                                   2006 ;	quantum/action.c:1200: ak820_dynamic_macro_cancel();
      007DF3 12 39 1A         [24] 2007 	lcall	_ak820_dynamic_macro_cancel
                                   2008 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007DF6 12 2E A4         [24] 2009 	lcall	_ak820_oneshot_cancel
                                   2010 ;	quantum/action.c:1209: ak820_combo_cancel();
      007DF9 12 35 27         [24] 2011 	lcall	_ak820_combo_cancel
                                   2012 ;	quantum/action.c:1212: repeat_key_cancel();
      007DFC 12 A7 3D         [24] 2013 	lcall	_repeat_key_cancel
                                   2014 ;	quantum/action.c:1214: clear_owned_mods();
      007DFF 12 84 0C         [24] 2015 	lcall	_clear_owned_mods
                                   2016 ;	quantum/action.c:1215: clear_owned_keys();
      007E02 12 84 44         [24] 2017 	lcall	_clear_owned_keys
                                   2018 ;	quantum/action.c:1216: clear_owned_usages();
      007E05 12 85 78         [24] 2019 	lcall	_clear_owned_usages
                                   2020 ;	quantum/action.c:1217: layer_hold_clear();
      007E08 12 7F C5         [24] 2021 	lcall	_layer_hold_clear
                                   2022 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007E0B 12 A2 A5         [24] 2023 	lcall	_clear_macro_tri_layer
                                   2024 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007E0E 90 0E 0E         [24] 2025 	mov	dptr,#_actual_keyboard_report
      007E11 12 76 39         [24] 2026 	lcall	_clear_keys_from_report
                                   2027 ;	quantum/action.c:1224: host_system_send(0);
      007E14 90 00 00         [24] 2028 	mov	dptr,#0x0000
      007E17 12 74 1B         [24] 2029 	lcall	_host_system_send
                                   2030 ;	quantum/action.c:1225: host_consumer_send(0);
      007E1A 90 00 00         [24] 2031 	mov	dptr,#0x0000
      007E1D 12 74 4A         [24] 2032 	lcall	_host_consumer_send
                                   2033 ;	quantum/action.c:1227: clear_weak_mods();
      007E20 12 87 B3         [24] 2034 	lcall	_clear_weak_mods
                                   2035 ;	quantum/action.c:1228: send_keyboard_report();
                                   2036 ;	quantum/action.c:1236: }
      007E23 02 87 03         [24] 2037 	ljmp	_send_keyboard_report
                                   2038 ;------------------------------------------------------------
                                   2039 ;Allocation info for local variables in function 'is_tap_record'
                                   2040 ;------------------------------------------------------------
                                   2041 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   2042 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   2043 ;------------------------------------------------------------
                                   2044 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2045 ;	-----------------------------------------
                                   2046 	.area CSEG    (CODE)
                                   2047 	.area CONST   (CODE)
                                   2048 	.area XINIT   (CODE)
      00C67F                       2049 __xinit__disable_action_cache:
      00C67F 00                    2050 	.db #0x00	;  0
                                   2051 	.area CABS    (ABS,CODE)
                                   2052 
                                   2053 ; Experimental exact instruction outlining.
                                   2054 	.globl _ak820_outline_0004
                                   2055 	.globl _ak820_outline_0009
                                   2056 	.globl _ak820_outline_0010
                                   2057 	.globl _ak820_outline_0011
                                   2058 	.globl _ak820_outline_0012
                                   2059 	.globl _ak820_outline_0016
                                   2060 	.globl _ak820_outline_0017
                                   2061 	.globl _ak820_outline_0020
                                   2062 	.globl _ak820_outline_0031
                                   2063 	.globl _ak820_outline_0039
                                   2064 	.globl _ak820_outline_0044
                                   2065 	.globl _ak820_outline_0051
                                   2066 	.globl _ak820_outline_0052
                                   2067 	.globl _ak820_outline_0058
                                   2068 	.globl _ak820_outline_0061
                                   2069 	.globl _ak820_outline_0063
                                   2070 	.globl _ak820_outline_0066
                                   2071 	.globl _ak820_outline_0072
                                   2072 	.globl _ak820_outline_0077
                                   2073 	.globl _ak820_outline_0087
                                   2074 	.globl _ak820_outline_0091
                                   2075 	.globl _ak820_outline_0095
                                   2076 	.globl _ak820_outline_0099
                                   2077 	.globl _ak820_outline_0104
                                   2078 	.globl _ak820_outline_0105
                                   2079 	.globl _ak820_outline_0107
                                   2080 	.globl _ak820_outline_0108
                                   2081 	.globl _ak820_outline_0109
                                   2082 	.globl _ak820_outline_0114
                                   2083 	.globl _ak820_outline_0118
                                   2084 	.globl _ak820_outline_0122
                                   2085 	.globl _ak820_outline_0124
                                   2086 	.globl _ak820_outline_0130
                                   2087 	.globl _ak820_outline_0140
                                   2088 	.globl _ak820_outline_0141
                                   2089 	.globl _ak820_outline_0142
                                   2090 	.globl _ak820_outline_0155
                                   2091 	.globl _ak820_outline_0163
                                   2092 	.globl _ak820_outline_0164
                                   2093 	.globl _ak820_outline_0179
                                   2094 	.globl _ak820_outline_0185
                                   2095 	.globl _ak820_outline_0186
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0020
      007E26                       2099 _ak820_outline_0020:
      007E26 8E 82            [24] 2100 	mov	dpl,r6
      007E28 8F 83            [24] 2101 	mov	dph,r7
      007E2A A3               [24] 2102 	inc	dptr
      007E2B E0               [24] 2103 	movx	a,@dptr
      007E2C FC               [12] 2104 	mov	r4,a
      007E2D 7D 00            [12] 2105 	mov	r5,#0x00
      007E2F 8E 82            [24] 2106 	mov	dpl,r6
      007E31 8F 83            [24] 2107 	mov	dph,r7
      007E33 E0               [24] 2108 	movx	a,@dptr
      007E34 22               [24] 2109 	ret
                                   2110 
                                   2111 	.area CSEG (CODE)
                                   2112 ; function ak820_outline_0039
      007E35                       2113 _ak820_outline_0039:
      007E35 90 08 A2         [24] 2114 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007E38 E0               [24] 2115 	movx	a,@dptr
      007E39 54 1F            [12] 2116 	anl	a,#0x1f
      007E3B F5 82            [12] 2117 	mov	dpl,a
      007E3D 22               [24] 2118 	ret
                                   2119 
                                   2120 	.area CSEG (CODE)
                                   2121 ; function ak820_outline_0051
      007E3E                       2122 _ak820_outline_0051:
      007E3E A3               [24] 2123 	inc	dptr
      007E3F F0               [24] 2124 	movx	@dptr,a
      007E40 E4               [12] 2125 	clr	a
      007E41 A3               [24] 2126 	inc	dptr
      007E42 F0               [24] 2127 	movx	@dptr,a
      007E43 90 0D EB         [24] 2128 	mov	dptr,#___memcpy_PARM_3
      007E46 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0063
      007E47                       2133 _ak820_outline_0063:
      007E47 F5 F0            [12] 2134 	mov	b,a
      007E49 05 F0            [12] 2135 	inc	b
      007E4B 74 01            [12] 2136 	mov	a,#0x01
      007E4D 22               [24] 2137 	ret
                                   2138 
                                   2139 	.area CSEG (CODE)
                                   2140 ; function ak820_outline_0077
      007E4E                       2141 _ak820_outline_0077:
      007E4E 90 08 A1         [24] 2142 	mov	dptr,#_process_action_PARM_2
      007E51 E0               [24] 2143 	movx	a,@dptr
      007E52 F5 82            [12] 2144 	mov	dpl,a
      007E54 22               [24] 2145 	ret
                                   2146 
                                   2147 	.area CSEG (CODE)
                                   2148 ; function ak820_outline_0087
      007E55                       2149 _ak820_outline_0087:
      007E55 90 08 A2         [24] 2150 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007E58 E0               [24] 2151 	movx	a,@dptr
      007E59 03               [12] 2152 	rr	a
      007E5A 03               [12] 2153 	rr	a
      007E5B 54 03            [12] 2154 	anl	a,#0x03
      007E5D 22               [24] 2155 	ret
                                   2156 
                                   2157 	.area CSEG (CODE)
                                   2158 ; function ak820_outline_0108
      007E5E                       2159 _ak820_outline_0108:
      007E5E 74 06            [12] 2160 	mov	a,#0x06
      007E60 F0               [24] 2161 	movx	@dptr,a
      007E61 E4               [12] 2162 	clr	a
      007E62 A3               [24] 2163 	inc	dptr
      007E63 F0               [24] 2164 	movx	@dptr,a
      007E64 22               [24] 2165 	ret
                                   2166 
                                   2167 	.area CSEG (CODE)
                                   2168 ; function ak820_outline_0109
      007E65                       2169 _ak820_outline_0109:
      007E65 90 08 A2         [24] 2170 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007E68 E0               [24] 2171 	movx	a,@dptr
      007E69 54 0F            [12] 2172 	anl	a,#0x0f
      007E6B 22               [24] 2173 	ret
                                   2174 
                                   2175 	.area CSEG (CODE)
                                   2176 ; function ak820_outline_0130
      007E6C                       2177 _ak820_outline_0130:
      007E6C 90 08 A1         [24] 2178 	mov	dptr,#_process_action_PARM_2
      007E6F E0               [24] 2179 	movx	a,@dptr
      007E70 FE               [12] 2180 	mov	r6,a
      007E71 A3               [24] 2181 	inc	dptr
      007E72 E0               [24] 2182 	movx	a,@dptr
      007E73 54 03            [12] 2183 	anl	a,#0x03
      007E75 FF               [12] 2184 	mov	r7,a
      007E76 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0155
      007E77                       2189 _ak820_outline_0155:
      007E77 90 08 A1         [24] 2190 	mov	dptr,#_process_action_PARM_2
      007E7A E0               [24] 2191 	movx	a,@dptr
      007E7B 22               [24] 2192 	ret
                                   2193 
                                   2194 	.area CSEG (CODE)
                                   2195 ; function ak820_outline_0163
      007E7C                       2196 _ak820_outline_0163:
      007E7C 90 08 A6         [24] 2197 	mov	dptr,#_register_code_code_10000_719
      007E7F E0               [24] 2198 	movx	a,@dptr
      007E80 FF               [12] 2199 	mov	r7,a
      007E81 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0164
      007E82                       2204 _ak820_outline_0164:
      007E82 90 08 A7         [24] 2205 	mov	dptr,#_unregister_code_code_10000_733
      007E85 E0               [24] 2206 	movx	a,@dptr
      007E86 FF               [12] 2207 	mov	r7,a
      007E87 22               [24] 2208 	ret
                                   2209 
                                   2210 	.area CSEG (CODE)
                                   2211 ; function ak820_outline_0185
      007E88                       2212 _ak820_outline_0185:
      007E88 E4               [12] 2213 	clr	a
      007E89 F0               [24] 2214 	movx	@dptr,a
      007E8A 8F 82            [24] 2215 	mov	dpl,r7
      007E8C 22               [24] 2216 	ret
