                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006F2                         85 _eeprom_read_word_addr_10000_91:
      0006F2                         86 	.ds 3
      0006F5                         87 _eeprom_read_word_ret_10000_92:
      0006F5                         88 	.ds 2
      0006F7                         89 _eeprom_read_dword_addr_10000_93:
      0006F7                         90 	.ds 3
      0006FA                         91 _eeprom_read_dword_ret_10000_94:
      0006FA                         92 	.ds 4
      0006FE                         93 _eeprom_write_byte_PARM_2:
      0006FE                         94 	.ds 1
      0006FF                         95 _eeprom_write_byte_addr_10000_95:
      0006FF                         96 	.ds 3
      000702                         97 _eeprom_write_word_PARM_2:
      000702                         98 	.ds 2
      000704                         99 _eeprom_write_word_addr_10000_97:
      000704                        100 	.ds 3
      000707                        101 _eeprom_write_dword_PARM_2:
      000707                        102 	.ds 4
      00070B                        103 _eeprom_write_dword_addr_10000_99:
      00070B                        104 	.ds 3
      00070E                        105 _eeprom_update_byte_PARM_2:
      00070E                        106 	.ds 1
      00070F                        107 _eeprom_update_byte_addr_10000_107:
      00070F                        108 	.ds 3
      000712                        109 _eeprom_update_word_PARM_2:
      000712                        110 	.ds 2
      000714                        111 _eeprom_update_word_addr_10000_111:
      000714                        112 	.ds 3
      000717                        113 _eeprom_update_dword_PARM_2:
      000717                        114 	.ds 4
      00071B                        115 _eeprom_update_dword_addr_10000_115:
      00071B                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      005373                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      005373 12 48 9C         [24]  170 	lcall	_ak820_outline_0037
      005376 90 06 F2         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005379 12 37 D6         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      00537C 90 06 F5         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00537F 12 55 7E         [24]  175 	lcall	_ak820_outline_0179
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      005382 90 06 F2         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005385 12 55 2C         [24]  178 	lcall	_ak820_outline_0022
      005388 90 05 F0         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00538B ED               [12]  180 	mov	a,r5
      00538C 12 37 D6         [24]  181 	lcall	_ak820_outline_0016
      00538F 90 05 F3         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005392 12 55 70         [24]  183 	lcall	_ak820_outline_0107
      005395 90 06 F5         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005398 12 46 38         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      00539B 90 06 F5         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00539E 12 55 67         [24]  188 	lcall	_ak820_outline_0090
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0053A1 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0053A2                        201 _eeprom_read_dword:
      0053A2 12 48 9C         [24]  202 	lcall	_ak820_outline_0037
      0053A5 90 06 F7         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0053A8 12 37 D6         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0053AB 90 06 FA         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053AE 12 55 3C         [24]  207 	lcall	_ak820_outline_0050
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0053B1 90 06 F7         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0053B4 12 55 2C         [24]  210 	lcall	_ak820_outline_0022
      0053B7 90 05 F0         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0053BA ED               [12]  212 	mov	a,r5
      0053BB 12 37 D6         [24]  213 	lcall	_ak820_outline_0016
      0053BE 90 05 F3         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0053C1 74 04            [12]  215 	mov	a,#0x04
      0053C3 12 38 5C         [24]  216 	lcall	_ak820_outline_0124
      0053C6 90 06 FA         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053C9 12 46 38         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0053CC 90 06 FA         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0053CF 12 55 45         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0053D2 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0053D3                        234 _eeprom_write_byte:
      0053D3 12 48 9C         [24]  235 	lcall	_ak820_outline_0037
      0053D6 90 06 FF         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0053D9 12 37 D6         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0053DC 90 06 FF         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0053DF 12 55 06         [24]  240 	lcall	_ak820_outline_0002
      0053E2 74 01            [12]  241 	mov	a,#0x01
      0053E4 12 38 5C         [24]  242 	lcall	_ak820_outline_0124
      0053E7 90 06 FE         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0053EA 02 46 C4         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0053ED                        256 _eeprom_write_word:
      0053ED 12 48 9C         [24]  257 	lcall	_ak820_outline_0037
      0053F0 90 07 04         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0053F3 12 37 D6         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      0053F6 90 07 04         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0053F9 12 55 06         [24]  262 	lcall	_ak820_outline_0002
      0053FC 12 55 70         [24]  263 	lcall	_ak820_outline_0107
      0053FF 90 07 02         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005402 02 46 C4         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005405                        277 _eeprom_write_dword:
      005405 12 48 9C         [24]  278 	lcall	_ak820_outline_0037
      005408 90 07 0B         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00540B 12 37 D6         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      00540E 90 07 0B         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005411 12 55 06         [24]  283 	lcall	_ak820_outline_0002
      005414 74 04            [12]  284 	mov	a,#0x04
      005416 12 38 5C         [24]  285 	lcall	_ak820_outline_0124
      005419 90 07 07         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      00541C 02 46 C4         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00541F                        307 _eeprom_update_byte:
      00541F C0 07            [24]  308 	push	ar7
      005421 C0 06            [24]  309 	push	ar6
      005423 C0 05            [24]  310 	push	ar5
      005425 C0 04            [24]  311 	push	ar4
      005427 12 48 9C         [24]  312 	lcall	_ak820_outline_0037
      00542A 90 07 0F         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00542D 12 37 D6         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005430 90 07 0F         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005433 12 55 1D         [24]  317 	lcall	_ak820_outline_0003
      005436 12 45 FD         [24]  318 	lcall	_eeprom_read_byte
      005439 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      00543B 90 07 0E         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      00543E E0               [24]  322 	movx	a,@dptr
      00543F FE               [12]  323 	mov	r6,a
      005440 EF               [12]  324 	mov	a,r7
      005441 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005444 80 35            [24]  326 	sjmp	00103$
      005446                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005446 90 07 0F         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005449 12 38 16         [24]  330 	lcall	_ak820_outline_0060
      00544C A3               [24]  331 	inc	dptr
      00544D E0               [24]  332 	movx	a,@dptr
      00544E FF               [12]  333 	mov	r7,a
      00544F 90 06 FE         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005452 EE               [12]  335 	mov	a,r6
      005453 12 38 35         [24]  336 	lcall	_ak820_outline_0099
      005456 8F F0            [24]  337 	mov	b, r7
      005458 C0 07            [24]  338 	push	ar7
      00545A C0 06            [24]  339 	push	ar6
      00545C C0 05            [24]  340 	push	ar5
      00545E C0 04            [24]  341 	push	ar4
      005460 C0 03            [24]  342 	push	ar3
      005462 C0 02            [24]  343 	push	ar2
      005464 C0 01            [24]  344 	push	ar1
      005466 C0 00            [24]  345 	push	ar0
      005468 12 53 D3         [24]  346 	lcall	_eeprom_write_byte
      00546B D0 00            [24]  347 	pop	ar0
      00546D D0 01            [24]  348 	pop	ar1
      00546F D0 02            [24]  349 	pop	ar2
      005471 D0 03            [24]  350 	pop	ar3
      005473 D0 04            [24]  351 	pop	ar4
      005475 D0 05            [24]  352 	pop	ar5
      005477 D0 06            [24]  353 	pop	ar6
      005479 D0 07            [24]  354 	pop	ar7
      00547B                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      00547B D0 04            [24]  357 	pop	ar4
      00547D D0 05            [24]  358 	pop	ar5
      00547F D0 06            [24]  359 	pop	ar6
      005481 D0 07            [24]  360 	pop	ar7
      005483 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      005484                        373 _eeprom_update_word:
      005484 12 48 9C         [24]  374 	lcall	_ak820_outline_0037
      005487 90 07 14         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00548A 12 37 D6         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      00548D 90 07 14         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005490 12 55 1D         [24]  379 	lcall	_ak820_outline_0003
      005493 12 53 73         [24]  380 	lcall	_eeprom_read_word
      005496 12 48 F0         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005499 90 07 12         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      00549C 12 38 16         [24]  384 	lcall	_ak820_outline_0060
      00549F EE               [12]  385 	mov	a,r6
      0054A0 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0054A3 EF               [12]  387 	mov	a,r7
      0054A4 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0054A7 22               [24]  389 	ret
      0054A8                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0054A8 90 07 14         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0054AB E0               [24]  393 	movx	a,@dptr
      0054AC FB               [12]  394 	mov	r3,a
      0054AD A3               [24]  395 	inc	dptr
      0054AE 12 37 F7         [24]  396 	lcall	_ak820_outline_0052
      0054B1 90 07 02         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0054B4 12 38 23         [24]  398 	lcall	_ak820_outline_0072
      0054B7 8B 82            [24]  399 	mov	dpl, r3
      0054B9 8E 83            [24]  400 	mov	dph, r6
      0054BB 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0054BD 02 53 ED         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0054C0                        415 _eeprom_update_dword:
      0054C0 12 48 9C         [24]  416 	lcall	_ak820_outline_0037
      0054C3 90 07 1B         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054C6 12 37 D6         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0054C9 90 07 1B         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054CC 12 55 1D         [24]  421 	lcall	_ak820_outline_0003
      0054CF 12 53 A2         [24]  422 	lcall	_eeprom_read_dword
      0054D2 12 55 56         [24]  423 	lcall	_ak820_outline_0057
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0054D5 90 07 17         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0054D8 E0               [24]  426 	movx	a,@dptr
      0054D9 F8               [12]  427 	mov	r0,a
      0054DA A3               [24]  428 	inc	dptr
      0054DB 12 55 5E         [24]  429 	lcall	_ak820_outline_0089
      0054DE EC               [12]  430 	mov	a,r4
      0054DF B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0054E2 ED               [12]  432 	mov	a,r5
      0054E3 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0054E6 EE               [12]  434 	mov	a,r6
      0054E7 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0054EA EF               [12]  436 	mov	a,r7
      0054EB B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0054EE 22               [24]  438 	ret
      0054EF                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0054EF 90 07 1B         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0054F2 12 55 2C         [24]  442 	lcall	_ak820_outline_0022
      0054F5 90 07 07         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      0054F8 E8               [12]  444 	mov	a,r0
      0054F9 F0               [24]  445 	movx	@dptr,a
      0054FA E9               [12]  446 	mov	a,r1
      0054FB A3               [24]  447 	inc	dptr
      0054FC 12 55 77         [24]  448 	lcall	_ak820_outline_0152
      0054FF F0               [24]  449 	movx	@dptr,a
      005500 12 55 35         [24]  450 	lcall	_ak820_outline_0045
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      005503 02 54 05         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0022
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0045
                                    465 	.globl _ak820_outline_0050
                                    466 	.globl _ak820_outline_0052
                                    467 	.globl _ak820_outline_0055
                                    468 	.globl _ak820_outline_0057
                                    469 	.globl _ak820_outline_0060
                                    470 	.globl _ak820_outline_0072
                                    471 	.globl _ak820_outline_0089
                                    472 	.globl _ak820_outline_0090
                                    473 	.globl _ak820_outline_0099
                                    474 	.globl _ak820_outline_0107
                                    475 	.globl _ak820_outline_0124
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0152
                                    478 	.globl _ak820_outline_0179
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      005506                        482 _ak820_outline_0002:
      005506 E0               [24]  483 	movx	a,@dptr
      005507 FD               [12]  484 	mov	r5,a
      005508 A3               [24]  485 	inc	dptr
      005509 E0               [24]  486 	movx	a,@dptr
      00550A FE               [12]  487 	mov	r6,a
      00550B A3               [24]  488 	inc	dptr
      00550C E0               [24]  489 	movx	a,@dptr
      00550D FF               [12]  490 	mov	r7,a
      00550E 90 05 F9         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005511 ED               [12]  492 	mov	a,r5
      005512 F0               [24]  493 	movx	@dptr,a
      005513 EE               [12]  494 	mov	a,r6
      005514 A3               [24]  495 	inc	dptr
      005515 F0               [24]  496 	movx	@dptr,a
      005516 EF               [12]  497 	mov	a,r7
      005517 A3               [24]  498 	inc	dptr
      005518 F0               [24]  499 	movx	@dptr,a
      005519 90 05 FC         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00551C 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      00551D                        505 _ak820_outline_0003:
      00551D E0               [24]  506 	movx	a,@dptr
      00551E FD               [12]  507 	mov	r5,a
      00551F A3               [24]  508 	inc	dptr
      005520 E0               [24]  509 	movx	a,@dptr
      005521 FE               [12]  510 	mov	r6,a
      005522 A3               [24]  511 	inc	dptr
      005523 E0               [24]  512 	movx	a,@dptr
      005524 FF               [12]  513 	mov	r7,a
      005525 8D 82            [24]  514 	mov	dpl,r5
      005527 8E 83            [24]  515 	mov	dph,r6
      005529 8F F0            [24]  516 	mov	b,r7
      00552B 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0022
      00552C                        521 _ak820_outline_0022:
      00552C E0               [24]  522 	movx	a,@dptr
      00552D FD               [12]  523 	mov	r5,a
      00552E A3               [24]  524 	inc	dptr
      00552F E0               [24]  525 	movx	a,@dptr
      005530 FE               [12]  526 	mov	r6,a
      005531 A3               [24]  527 	inc	dptr
      005532 E0               [24]  528 	movx	a,@dptr
      005533 FF               [12]  529 	mov	r7,a
      005534 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0045
      005535                        534 _ak820_outline_0045:
      005535 8D 82            [24]  535 	mov	dpl,r5
      005537 8E 83            [24]  536 	mov	dph,r6
      005539 8F F0            [24]  537 	mov	b,r7
      00553B 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0050
      00553C                        542 _ak820_outline_0050:
      00553C E4               [12]  543 	clr	a
      00553D F0               [24]  544 	movx	@dptr,a
      00553E A3               [24]  545 	inc	dptr
      00553F F0               [24]  546 	movx	@dptr,a
      005540 A3               [24]  547 	inc	dptr
      005541 F0               [24]  548 	movx	@dptr,a
      005542 A3               [24]  549 	inc	dptr
      005543 F0               [24]  550 	movx	@dptr,a
      005544 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      005545                        555 _ak820_outline_0055:
      005545 E0               [24]  556 	movx	a,@dptr
      005546 FC               [12]  557 	mov	r4,a
      005547 A3               [24]  558 	inc	dptr
      005548 E0               [24]  559 	movx	a,@dptr
      005549 FD               [12]  560 	mov	r5,a
      00554A A3               [24]  561 	inc	dptr
      00554B E0               [24]  562 	movx	a,@dptr
      00554C FE               [12]  563 	mov	r6,a
      00554D A3               [24]  564 	inc	dptr
      00554E E0               [24]  565 	movx	a,@dptr
      00554F 8C 82            [24]  566 	mov	dpl,r4
      005551 8D 83            [24]  567 	mov	dph,r5
      005553 8E F0            [24]  568 	mov	b,r6
      005555 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0057
      005556                        573 _ak820_outline_0057:
      005556 AC 82            [24]  574 	mov	r4,dpl
      005558 AD 83            [24]  575 	mov	r5,dph
      00555A AE F0            [24]  576 	mov	r6,b
      00555C FF               [12]  577 	mov	r7,a
      00555D 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0089
      00555E                        582 _ak820_outline_0089:
      00555E E0               [24]  583 	movx	a,@dptr
      00555F F9               [12]  584 	mov	r1,a
      005560 A3               [24]  585 	inc	dptr
      005561 E0               [24]  586 	movx	a,@dptr
      005562 FA               [12]  587 	mov	r2,a
      005563 A3               [24]  588 	inc	dptr
      005564 E0               [24]  589 	movx	a,@dptr
      005565 FB               [12]  590 	mov	r3,a
      005566 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0090
      005567                        595 _ak820_outline_0090:
      005567 E0               [24]  596 	movx	a,@dptr
      005568 FE               [12]  597 	mov	r6,a
      005569 A3               [24]  598 	inc	dptr
      00556A E0               [24]  599 	movx	a,@dptr
      00556B 8E 82            [24]  600 	mov	dpl,r6
      00556D F5 83            [12]  601 	mov	dph,a
      00556F 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0107
      005570                        606 _ak820_outline_0107:
      005570 74 02            [12]  607 	mov	a,#0x02
      005572 F0               [24]  608 	movx	@dptr,a
      005573 E4               [12]  609 	clr	a
      005574 A3               [24]  610 	inc	dptr
      005575 F0               [24]  611 	movx	@dptr,a
      005576 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0152
      005577                        616 _ak820_outline_0152:
      005577 F0               [24]  617 	movx	@dptr,a
      005578 EA               [12]  618 	mov	a,r2
      005579 A3               [24]  619 	inc	dptr
      00557A F0               [24]  620 	movx	@dptr,a
      00557B EB               [12]  621 	mov	a,r3
      00557C A3               [24]  622 	inc	dptr
      00557D 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0179
      00557E                        627 _ak820_outline_0179:
      00557E E4               [12]  628 	clr	a
      00557F F0               [24]  629 	movx	@dptr,a
      005580 A3               [24]  630 	inc	dptr
      005581 F0               [24]  631 	movx	@dptr,a
      005582 22               [24]  632 	ret
