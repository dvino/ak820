                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000588                        109 _page_data:
      000588                        110 	.ds 64
      0005C8                        111 _cached_page:
      0005C8                        112 	.ds 1
      0005C9                        113 _batch_depth:
      0005C9                        114 	.ds 1
      0005CA                        115 _first_failure_stage:
      0005CA                        116 	.ds 1
      0005CB                        117 _nvm_fail_stage_10000_20:
      0005CB                        118 	.ds 1
      0005CC                        119 _ak820_nvm_diagnostic_out_10000_23:
      0005CC                        120 	.ds 2
      0005CE                        121 _crc_byte_PARM_2:
      0005CE                        122 	.ds 1
      0005CF                        123 _crc_byte_crc_10000_25:
      0005CF                        124 	.ds 2
      0005D1                        125 _page_crc_crc_10000_30:
      0005D1                        126 	.ds 2
      0005D3                        127 _write_page_address_10000_32:
      0005D3                        128 	.ds 2
      0005D5                        129 _journal_header_valid_header_10000_39:
      0005D5                        130 	.ds 2
      0005D7                        131 _recover_journal_header_10000_46:
      0005D7                        132 	.ds 9
      0005E0                        133 _ak820_nvm_flush_header_10000_62:
      0005E0                        134 	.ds 9
      0005E9                        135 _ak820_nvm_flush_stage_10000_62:
      0005E9                        136 	.ds 1
      0005EA                        137 _load_page_page_10000_87:
      0005EA                        138 	.ds 1
      0005EB                        139 _read_offset_offset_10000_93:
      0005EB                        140 	.ds 2
      0005ED                        141 _eeprom_read_byte_addr_10000_97:
      0005ED                        142 	.ds 3
      0005F0                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      0005F0                        144 	.ds 3
      0005F3                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      0005F3                        146 	.ds 2
      0005F5                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      0005F5                        148 	.ds 2
      0005F7                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      0005F7                        150 	.ds 2
      0005F9                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      0005F9                        152 	.ds 3
      0005FC                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005FC                        154 	.ds 2
      0005FE                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005FE                        156 	.ds 2
      000600                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000600                        158 	.ds 3
      000603                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000603                        160 	.ds 2
      000605                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000605                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      00410E                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      00410E E5 82            [12]  215 	mov	a,dpl
      004110 90 05 CB         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      004113 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      004114 20 09 08         [24]  219 	jb	_storage_failed,00102$
      004117 90 05 CB         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      00411A E0               [24]  221 	movx	a,@dptr
      00411B 90 05 CA         [24]  222 	mov	dptr,#_first_failure_stage
      00411E F0               [24]  223 	movx	@dptr,a
      00411F                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      00411F D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      004121 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      004122                        239 _ak820_nvm_diagnostic:
      004122 12 38 41         [24]  240 	lcall	_ak820_outline_0104
      004125 90 05 CC         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      004128 12 38 46         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      00412B 90 05 CC         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      00412E 12 37 F7         [24]  245 	lcall	_ak820_outline_0052
      004131 A2 09            [12]  246 	mov	c,_storage_failed
      004133 E4               [12]  247 	clr	a
      004134 33               [12]  248 	rlc	a
      004135 12 48 E5         [24]  249 	lcall	_ak820_outline_0114
      004138 12 48 C0         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      00413B A3               [24]  252 	inc	dptr
      00413C A2 07            [12]  253 	mov	c,_page_valid
      00413E E4               [12]  254 	clr	a
      00413F 33               [12]  255 	rlc	a
      004140 12 48 94         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      004143 A2 08            [12]  258 	mov	c,_page_dirty
      004145 E4               [12]  259 	clr	a
      004146 33               [12]  260 	rlc	a
      004147 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      004148 74 03            [12]  263 	mov	a,#0x03
      00414A 12 49 10         [24]  264 	lcall	_ak820_outline_0157
      00414D 90 05 C9         [24]  265 	mov	dptr,#_batch_depth
      004150 E0               [24]  266 	movx	a,@dptr
      004151 12 38 57         [24]  267 	lcall	_ak820_outline_0122
      004154 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      004155 74 04            [12]  270 	mov	a,#0x04
      004157 12 49 10         [24]  271 	lcall	_ak820_outline_0157
      00415A 90 05 C8         [24]  272 	mov	dptr,#_cached_page
      00415D E0               [24]  273 	movx	a,@dptr
      00415E 12 38 57         [24]  274 	lcall	_ak820_outline_0122
      004161 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      004162 12 48 8A         [24]  277 	lcall	_ak820_outline_0010
      004165 E4               [12]  278 	clr	a
      004166 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      004167 74 06            [12]  281 	mov	a,#0x06
      004169 12 48 F5         [24]  282 	lcall	_ak820_outline_0135
      00416C 90 05 CA         [24]  283 	mov	dptr,#_first_failure_stage
      00416F E0               [24]  284 	movx	a,@dptr
      004170 12 48 E5         [24]  285 	lcall	_ak820_outline_0114
      004173 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      004174 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      004175                        300 _crc_byte:
      004175 12 38 41         [24]  301 	lcall	_ak820_outline_0104
      004178 90 05 CF         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      00417B 12 38 46         [24]  303 	lcall	_ak820_outline_0105
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      00417E 90 05 CE         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      004181 E0               [24]  306 	movx	a,@dptr
      004182 FF               [12]  307 	mov	r7,a
      004183 7E 00            [12]  308 	mov	r6,#0x00
      004185 90 05 CF         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      004188 E0               [24]  310 	movx	a,@dptr
      004189 6E               [12]  311 	xrl	a,r6
      00418A F0               [24]  312 	movx	@dptr,a
      00418B A3               [24]  313 	inc	dptr
      00418C E0               [24]  314 	movx	a,@dptr
      00418D 6F               [12]  315 	xrl	a,r7
      00418E F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      00418F 7F 00            [12]  318 	mov	r7,#0x00
      004191                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      004191 90 05 CF         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      004194 12 48 D3         [24]  322 	lcall	_ak820_outline_0095
      004197 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      00419A ED               [12]  324 	mov	a,r5
      00419B 2D               [12]  325 	add	a,r5
      00419C FB               [12]  326 	mov	r3,a
      00419D EE               [12]  327 	mov	a,r6
      00419E 33               [12]  328 	rlc	a
      00419F FC               [12]  329 	mov	r4,a
      0041A0 63 03 21         [24]  330 	xrl	ar3,#0x21
      0041A3 63 04 10         [24]  331 	xrl	ar4,#0x10
      0041A6 80 06            [24]  332 	sjmp	00107$
      0041A8                        333 00106$:
      0041A8 ED               [12]  334 	mov	a,r5
      0041A9 2D               [12]  335 	add	a,r5
      0041AA FB               [12]  336 	mov	r3,a
      0041AB EE               [12]  337 	mov	a,r6
      0041AC 33               [12]  338 	rlc	a
      0041AD FC               [12]  339 	mov	r4,a
      0041AE                        340 00107$:
      0041AE 90 05 CF         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      0041B1 12 38 29         [24]  342 	lcall	_ak820_outline_0078
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      0041B4 0F               [12]  344 	inc	r7
      0041B5 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      0041B8 12 33 FC         [24]  347 	lcall	_ak820_outline_0123
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      0041BB 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      0041BC                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      0041BC 90 05 D1         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      0041BF 74 FF            [12]  363 	mov	a,#0xff
      0041C1 F0               [24]  364 	movx	@dptr,a
      0041C2 A3               [24]  365 	inc	dptr
      0041C3 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      0041C4 7F 00            [12]  368 	mov	r7,#0x00
      0041C6                        369 00102$:
      0041C6 90 05 D1         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      0041C9 12 48 D3         [24]  371 	lcall	_ak820_outline_0095
      0041CC 12 48 D9         [24]  372 	lcall	_ak820_outline_0102
      0041CF 90 05 CE         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      0041D2 F0               [24]  374 	movx	@dptr,a
      0041D3 12 38 61         [24]  375 	lcall	_ak820_outline_0133
      0041D6 C0 07            [24]  376 	push	ar7
      0041D8 12 41 75         [24]  377 	lcall	_crc_byte
      0041DB AD 82            [24]  378 	mov	r5, dpl
      0041DD AE 83            [24]  379 	mov	r6, dph
      0041DF D0 07            [24]  380 	pop	ar7
      0041E1 90 05 D1         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      0041E4 12 49 16         [24]  382 	lcall	_ak820_outline_0158
      0041E7 0F               [12]  383 	inc	r7
      0041E8 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      0041EB 12 38 61         [24]  386 	lcall	_ak820_outline_0133
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      0041EE 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      0041EF                        399 _write_page:
      0041EF 12 38 41         [24]  400 	lcall	_ak820_outline_0104
      0041F2 90 05 D3         [24]  401 	mov	dptr,#_write_page_address_10000_32
      0041F5 12 38 46         [24]  402 	lcall	_ak820_outline_0105
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      0041F8 90 05 D3         [24]  404 	mov	dptr,#_write_page_address_10000_32
      0041FB 12 37 97         [24]  405 	lcall	_ak820_outline_0004
      0041FE C0 07            [24]  406 	push	ar7
      004200 C0 06            [24]  407 	push	ar6
      004202 12 3C E7         [24]  408 	lcall	_ak820_flash_erase
      004205 E5 82            [12]  409 	mov	a, dpl
      004207 D0 06            [24]  410 	pop	ar6
      004209 D0 07            [24]  411 	pop	ar7
      00420B 70 03            [24]  412 	jnz	00102$
      00420D F5 82            [12]  413 	mov	dpl,a
      00420F 22               [24]  414 	ret
      004210                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      004210 90 05 4B         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      004213 74 88            [12]  418 	mov	a,#_page_data
      004215 F0               [24]  419 	movx	@dptr,a
      004216 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      004218 A3               [24]  421 	inc	dptr
      004219 12 48 C0         [24]  422 	lcall	_ak820_outline_0061
      00421C 12 3D FB         [24]  423 	lcall	_ak820_flash_program_page
      00421F E5 82            [12]  424 	mov	a, dpl
      004221 70 03            [24]  425 	jnz	00120$
      004223 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004225 22               [24]  428 	ret
      004226                        429 00120$:
      004226 7F 00            [12]  430 	mov	r7,#0x00
      004228                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      004228 8F 05            [24]  433 	mov	ar5,r7
      00422A 7E 00            [12]  434 	mov	r6,#0x00
      00422C 90 05 D3         [24]  435 	mov	dptr,#_write_page_address_10000_32
      00422F 12 38 51         [24]  436 	lcall	_ak820_outline_0121
      004232 ED               [12]  437 	mov	a,r5
      004233 2B               [12]  438 	add	a, r3
      004234 FB               [12]  439 	mov	r3,a
      004235 EE               [12]  440 	mov	a,r6
      004236 3C               [12]  441 	addc	a, r4
      004237 FC               [12]  442 	mov	r4,a
      004238 12 33 FC         [24]  443 	lcall	_ak820_outline_0123
      00423B 12 3B DA         [24]  444 	lcall	_ak820_flash_read
      00423E AE 82            [24]  445 	mov	r6, dpl
      004240 12 48 D9         [24]  446 	lcall	_ak820_outline_0102
      004243 FD               [12]  447 	mov	r5,a
      004244 EE               [12]  448 	mov	a,r6
      004245 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      004248 80 04            [24]  450 	sjmp	00109$
      00424A                        451 00149$:
      00424A 75 82 00         [24]  452 	mov	dpl, #0x00
      00424D 22               [24]  453 	ret
      00424E                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00424E 0F               [12]  456 	inc	r7
      00424F BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      004252 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      004255 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      004256                        472 _journal_header_valid:
      004256 12 38 41         [24]  473 	lcall	_ak820_outline_0104
      004259 90 05 D5         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      00425C 12 38 46         [24]  475 	lcall	_ak820_outline_0105
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      00425F 90 05 D5         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      004262 12 37 97         [24]  478 	lcall	_ak820_outline_0004
      004265 E0               [24]  479 	movx	a,@dptr
      004266 FD               [12]  480 	mov	r5,a
      004267 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      00426A 80 04            [24]  482 	sjmp	00116$
      00426C                        483 00138$:
      00426C 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      00426F 22               [24]  486 	ret
      004270                        487 00116$:
      004270 7D 01            [12]  488 	mov	r5,#0x01
      004272                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      004272 ED               [12]  491 	mov	a,r5
      004273 12 37 DE         [24]  492 	lcall	_ak820_outline_0017
      004276 FC               [12]  493 	mov	r4,a
      004277 8D 02            [24]  494 	mov	ar2,r5
      004279 7B 00            [12]  495 	mov	r3,#0x00
      00427B 74 04            [12]  496 	mov	a,#0x04
      00427D 2A               [12]  497 	add	a, r2
      00427E FA               [12]  498 	mov	r2,a
      00427F E4               [12]  499 	clr	a
      004280 3B               [12]  500 	addc	a, r3
      004281 FB               [12]  501 	mov	r3,a
      004282 EA               [12]  502 	mov	a,r2
      004283 2E               [12]  503 	add	a, r6
      004284 F5 82            [12]  504 	mov	dpl,a
      004286 EB               [12]  505 	mov	a,r3
      004287 3F               [12]  506 	addc	a, r7
      004288 F5 83            [12]  507 	mov	dph,a
      00428A E0               [24]  508 	movx	a,@dptr
      00428B 62 04            [12]  509 	xrl	ar4,a
      00428D BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      004290 80 04            [24]  511 	sjmp	00107$
      004292                        512 00139$:
      004292 75 82 00         [24]  513 	mov	dpl, #0x00
      004295 22               [24]  514 	ret
      004296                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      004296 0D               [12]  517 	inc	r5
      004297 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      00429A 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      00429D 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      00429E                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      00429E 7F 00            [12]  537 	mov	r7,#0x00
      0042A0                        538 00115$:
      0042A0 EF               [12]  539 	mov	a,r7
      0042A1 24 D7            [12]  540 	add	a, #_recover_journal_header_10000_46
      0042A3 FD               [12]  541 	mov	r5,a
      0042A4 E4               [12]  542 	clr	a
      0042A5 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      0042A7 FE               [12]  544 	mov	r6,a
      0042A8 8F 04            [24]  545 	mov	ar4,r7
      0042AA 7B 00            [12]  546 	mov	r3,#0x00
      0042AC 74 40            [12]  547 	mov	a,#0x40
      0042AE 2C               [12]  548 	add	a, r4
      0042AF FC               [12]  549 	mov	r4,a
      0042B0 74 EF            [12]  550 	mov	a,#0xef
      0042B2 3B               [12]  551 	addc	a, r3
      0042B3 FB               [12]  552 	mov	r3,a
      0042B4 12 49 21         [24]  553 	lcall	_ak820_outline_0181
      0042B7 12 3B DA         [24]  554 	lcall	_ak820_flash_read
      0042BA AC 82            [24]  555 	mov	r4, dpl
      0042BC 12 48 C6         [24]  556 	lcall	_ak820_outline_0065
      0042BF 0F               [12]  557 	inc	r7
      0042C0 BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      0042C3 90 05 D7         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      0042C6 12 42 56         [24]  561 	lcall	_journal_header_valid
      0042C9 E5 82            [12]  562 	mov	a, dpl
      0042CB 70 01            [24]  563 	jnz	00103$
      0042CD 22               [24]  564 	ret
      0042CE                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      0042CE 90 05 D8         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      0042D1 E0               [24]  568 	movx	a,@dptr
      0042D2 FF               [12]  569 	mov	r7,a
      0042D3 7E 00            [12]  570 	mov	r6,#0x00
      0042D5 90 05 D9         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      0042D8 E0               [24]  572 	movx	a,@dptr
      0042D9 FC               [12]  573 	mov	r4,a
      0042DA E4               [12]  574 	clr	a
      0042DB 42 07            [12]  575 	orl	ar7,a
      0042DD EC               [12]  576 	mov	a,r4
      0042DE 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      0042E0 90 05 DA         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      0042E3 E0               [24]  580 	movx	a,@dptr
      0042E4 FD               [12]  581 	mov	r5,a
      0042E5 7C 00            [12]  582 	mov	r4,#0x00
      0042E7 90 05 DB         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      0042EA E0               [24]  584 	movx	a,@dptr
      0042EB FA               [12]  585 	mov	r2,a
      0042EC E4               [12]  586 	clr	a
      0042ED 12 48 FB         [24]  587 	lcall	_ak820_outline_0140
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      0042F0 C3               [12]  589 	clr	c
      0042F1 EF               [12]  590 	mov	a,r7
      0042F2 94 A0            [12]  591 	subb	a,#0xa0
      0042F4 EE               [12]  592 	mov	a,r6
      0042F5 94 00            [12]  593 	subb	a,#0x00
      0042F7 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      0042F9 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      0042FC 02 41 0E         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      0042FF                        600 00134$:
      0042FF 7B 00            [12]  601 	mov	r3,#0x00
      004301                        602 00117$:
      004301 C0 05            [24]  603 	push	ar5
      004303 C0 04            [24]  604 	push	ar4
      004305 EB               [12]  605 	mov	a,r3
      004306 24 88            [12]  606 	add	a, #_page_data
      004308 F9               [12]  607 	mov	r1,a
      004309 E4               [12]  608 	clr	a
      00430A 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      00430C FA               [12]  610 	mov	r2,a
      00430D 8B 00            [24]  611 	mov	ar0,r3
      00430F 7D 00            [12]  612 	mov	r5,#0x00
      004311 74 EF            [12]  613 	mov	a,#0xef
      004313 2D               [12]  614 	add	a, r5
      004314 FD               [12]  615 	mov	r5,a
      004315 88 82            [24]  616 	mov	dpl, r0
      004317 8D 83            [24]  617 	mov	dph, r5
      004319 12 3B DA         [24]  618 	lcall	_ak820_flash_read
      00431C AD 82            [24]  619 	mov	r5, dpl
      00431E 12 49 1C         [24]  620 	lcall	_ak820_outline_0180
      004321 ED               [12]  621 	mov	a,r5
      004322 F0               [24]  622 	movx	@dptr,a
      004323 0B               [12]  623 	inc	r3
      004324 BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      004327 80 06            [24]  625 	sjmp	00191$
      004329                        626 00190$:
      004329 D0 04            [24]  627 	pop	ar4
      00432B D0 05            [24]  628 	pop	ar5
      00432D 80 D2            [24]  629 	sjmp	00117$
      00432F                        630 00191$:
      00432F D0 04            [24]  631 	pop	ar4
      004331 D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      004333 C0 07            [24]  634 	push	ar7
      004335 C0 06            [24]  635 	push	ar6
      004337 C0 05            [24]  636 	push	ar5
      004339 C0 04            [24]  637 	push	ar4
      00433B 12 41 BC         [24]  638 	lcall	_page_crc
      00433E AA 82            [24]  639 	mov	r2, dpl
      004340 AB 83            [24]  640 	mov	r3, dph
      004342 D0 04            [24]  641 	pop	ar4
      004344 D0 05            [24]  642 	pop	ar5
      004346 D0 06            [24]  643 	pop	ar6
      004348 D0 07            [24]  644 	pop	ar7
      00434A EA               [12]  645 	mov	a,r2
      00434B B5 05 06         [24]  646 	cjne	a,ar5,00192$
      00434E EB               [12]  647 	mov	a,r3
      00434F B5 04 02         [24]  648 	cjne	a,ar4,00192$
      004352 80 06            [24]  649 	sjmp	00113$
      004354                        650 00192$:
      004354 75 82 02         [24]  651 	mov	dpl, #0x02
      004357 02 41 0E         [24]  652 	ljmp	_nvm_fail
      00435A                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00435A EE               [12]  655 	mov	a,r6
      00435B 54 03            [12]  656 	anl	a,#0x03
      00435D A2 E0            [12]  657 	mov	c,acc.0
      00435F CF               [12]  658 	xch	a,r7
      004360 13               [12]  659 	rrc	a
      004361 CF               [12]  660 	xch	a,r7
      004362 13               [12]  661 	rrc	a
      004363 A2 E0            [12]  662 	mov	c,acc.0
      004365 CF               [12]  663 	xch	a,r7
      004366 13               [12]  664 	rrc	a
      004367 CF               [12]  665 	xch	a,r7
      004368 13               [12]  666 	rrc	a
      004369 CF               [12]  667 	xch	a,r7
      00436A 24 C7            [12]  668 	add	a,#0xc7
      00436C FE               [12]  669 	mov	r6,a
      00436D 12 49 0B         [24]  670 	lcall	_ak820_outline_0154
      004370 12 41 EF         [24]  671 	lcall	_write_page
      004373 E5 82            [12]  672 	mov	a, dpl
      004375 70 06            [24]  673 	jnz	00110$
      004377 75 82 03         [24]  674 	mov	dpl, #0x03
      00437A 02 41 0E         [24]  675 	ljmp	_nvm_fail
      00437D                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      00437D 90 EF 40         [24]  678 	mov	dptr,#0xef40
      004380 12 3C E7         [24]  679 	lcall	_ak820_flash_erase
      004383 E5 82            [12]  680 	mov	a, dpl
      004385 70 06            [24]  681 	jnz	00119$
      004387 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00438A 02 41 0E         [24]  684 	ljmp	_nvm_fail
      00438D                        685 00119$:
      00438D 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      00438E                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      00438E C2 09            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004390 90 05 CA         [24]  699 	mov	dptr,#_first_failure_stage
      004393 E4               [12]  700 	clr	a
      004394 F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      004395 C2 08            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      004397 C2 07            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004399 90 05 C9         [24]  708 	mov	dptr,#_batch_depth
      00439C E4               [12]  709 	clr	a
      00439D F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00439E 12 42 9E         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      0043A1 02 2A 6B         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      0043A4                        723 _ak820_nvm_ok:
      0043A4 A2 09            [12]  724 	mov	c,_storage_failed
      0043A6 B3               [12]  725 	cpl	c
      0043A7 92 0A            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      0043A9 12 38 7D         [24]  727 	lcall	_ak820_outline_0167
      0043AC 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      0043AD                        736 _ak820_nvm_schema_fault:
      0043AD 75 82 10         [24]  737 	mov	dpl, #0x10
      0043B0 02 41 0E         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      0043B3                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      0043B3 30 08 03         [24]  753 	jnb	_page_dirty,00101$
      0043B6 30 09 01         [24]  754 	jnb	_storage_failed,00102$
      0043B9                        755 00101$:
      0043B9 22               [24]  756 	ret
      0043BA                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0043BA 12 41 BC         [24]  759 	lcall	_page_crc
      0043BD 12 48 F0         [24]  760 	lcall	_ak820_outline_0132
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0043C0 90 05 E0         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0043C3 74 A5            [12]  763 	mov	a,#0xa5
      0043C5 F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0043C6 90 05 C8         [24]  766 	mov	dptr,#_cached_page
      0043C9 E0               [24]  767 	movx	a,@dptr
      0043CA 90 05 E1         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0043CD F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0043CE 90 05 E2         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0043D1 E4               [12]  772 	clr	a
      0043D2 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0043D3 8E 05            [24]  775 	mov	ar5,r6
      0043D5 90 05 E3         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0043D8 ED               [12]  777 	mov	a,r5
      0043D9 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0043DA 8F 06            [24]  780 	mov	ar6,r7
      0043DC 90 05 E4         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0043DF EE               [12]  782 	mov	a,r6
      0043E0 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0043E1 7F 01            [12]  785 	mov	r7,#0x01
      0043E3                        786 00128$:
      0043E3 8F 06            [24]  787 	mov	ar6,r7
      0043E5 EE               [12]  788 	mov	a,r6
      0043E6 24 04            [12]  789 	add	a,#0x04
      0043E8 FE               [12]  790 	mov	r6,a
      0043E9 33               [12]  791 	rlc	a
      0043EA 95 E0            [12]  792 	subb	a,acc
      0043EC FD               [12]  793 	mov	r5,a
      0043ED EE               [12]  794 	mov	a,r6
      0043EE 24 E0            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      0043F0 FE               [12]  796 	mov	r6,a
      0043F1 ED               [12]  797 	mov	a,r5
      0043F2 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0043F4 FD               [12]  799 	mov	r5,a
      0043F5 12 48 A3         [24]  800 	lcall	_ak820_outline_0041
      0043F8 FC               [12]  801 	mov	r4,a
      0043F9 63 04 FF         [24]  802 	xrl	ar4,#0xff
      0043FC 8E 82            [24]  803 	mov	dpl,r6
      0043FE 8D 83            [24]  804 	mov	dph,r5
      004400 EC               [12]  805 	mov	a,r4
      004401 F0               [24]  806 	movx	@dptr,a
      004402 0F               [12]  807 	inc	r7
      004403 BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      004406 90 05 E9         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004409 74 05            [12]  811 	mov	a,#0x05
      00440B F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      00440C 90 EF 40         [24]  814 	mov	dptr,#0xef40
      00440F 12 3C E7         [24]  815 	lcall	_ak820_flash_erase
      004412 E5 82            [12]  816 	mov	a, dpl
      004414 70 03            [24]  817 	jnz	00269$
      004416 02 44 FC         [24]  818 	ljmp	00127$
      004419                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004419 90 05 E9         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00441C 74 06            [12]  822 	mov	a,#0x06
      00441E F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00441F 7F 00            [12]  825 	mov	r7,#0x00
      004421                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004421 12 48 AF         [24]  828 	lcall	_ak820_outline_0053
      004424 12 3B DA         [24]  829 	lcall	_ak820_flash_read
      004427 E5 82            [12]  830 	mov	a, dpl
      004429 60 03            [24]  831 	jz	00270$
      00442B 02 44 FC         [24]  832 	ljmp	00127$
      00442E                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00442E 0F               [12]  835 	inc	r7
      00442F BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      004432 90 05 E9         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004435 74 07            [12]  839 	mov	a,#0x07
      004437 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      004438 90 EF 00         [24]  842 	mov	dptr,#0xef00
      00443B 12 41 EF         [24]  843 	lcall	_write_page
      00443E E5 82            [12]  844 	mov	a, dpl
      004440 70 03            [24]  845 	jnz	00273$
      004442 02 44 FC         [24]  846 	ljmp	00127$
      004445                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004445 90 05 E9         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004448 74 08            [12]  850 	mov	a,#0x08
      00444A F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00444B 7F 01            [12]  853 	mov	r7,#0x01
      00444D                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      00444D 12 48 A3         [24]  856 	lcall	_ak820_outline_0041
      004450 FE               [12]  857 	mov	r6,a
      004451 60 22            [24]  858 	jz	00133$
      004453 8F 05            [24]  859 	mov	ar5,r7
      004455 7C 00            [12]  860 	mov	r4,#0x00
      004457 74 40            [12]  861 	mov	a,#0x40
      004459 2D               [12]  862 	add	a, r5
      00445A FD               [12]  863 	mov	r5,a
      00445B 74 EF            [12]  864 	mov	a,#0xef
      00445D 3C               [12]  865 	addc	a, r4
      00445E FC               [12]  866 	mov	r4,a
      00445F 90 05 48         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      004462 EE               [12]  868 	mov	a,r6
      004463 F0               [24]  869 	movx	@dptr,a
      004464 12 49 26         [24]  870 	lcall	_ak820_outline_0186
      004467 C0 07            [24]  871 	push	ar7
      004469 12 3D 47         [24]  872 	lcall	_ak820_flash_program
      00446C E5 82            [12]  873 	mov	a, dpl
      00446E D0 07            [24]  874 	pop	ar7
      004470 70 03            [24]  875 	jnz	00275$
      004472 02 44 FC         [24]  876 	ljmp	00127$
      004475                        877 00275$:
      004475                        878 00133$:
                                    879 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004475 0F               [12]  880 	inc	r7
      004476 BF 09 D4         [24]  881 	cjne	r7,#0x09,00132$
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      004479 90 05 E9         [24]  883 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00447C 74 09            [12]  884 	mov	a,#0x09
      00447E F0               [24]  885 	movx	@dptr,a
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00447F 7F 01            [12]  887 	mov	r7,#0x01
      004481                        888 00134$:
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004481 12 48 AF         [24]  890 	lcall	_ak820_outline_0053
      004484 12 3B DA         [24]  891 	lcall	_ak820_flash_read
      004487 AE 82            [24]  892 	mov	r6, dpl
      004489 12 48 A3         [24]  893 	lcall	_ak820_outline_0041
      00448C FD               [12]  894 	mov	r5,a
      00448D EE               [12]  895 	mov	a,r6
      00448E B5 05 6B         [24]  896 	cjne	a,ar5,00127$
                                    897 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004491 0F               [12]  898 	inc	r7
      004492 BF 09 EC         [24]  899 	cjne	r7,#0x09,00134$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004495 90 05 E9         [24]  901 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004498 74 0A            [12]  902 	mov	a,#0x0a
      00449A F0               [24]  903 	movx	@dptr,a
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00449B 90 05 E0         [24]  905 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      00449E E0               [24]  906 	movx	a,@dptr
      00449F 90 05 48         [24]  907 	mov	dptr,#_ak820_flash_program_PARM_2
      0044A2 F0               [24]  908 	movx	@dptr,a
      0044A3 90 EF 40         [24]  909 	mov	dptr,#0xef40
      0044A6 12 3D 47         [24]  910 	lcall	_ak820_flash_program
      0044A9 E5 82            [12]  911 	mov	a, dpl
      0044AB 60 4F            [24]  912 	jz	00127$
                                    913 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      0044AD 90 05 E9         [24]  914 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044B0 74 0B            [12]  915 	mov	a,#0x0b
      0044B2 F0               [24]  916 	movx	@dptr,a
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      0044B3 90 EF 40         [24]  918 	mov	dptr,#0xef40
      0044B6 12 3B DA         [24]  919 	lcall	_ak820_flash_read
      0044B9 AF 82            [24]  920 	mov	r7, dpl
      0044BB 90 05 E0         [24]  921 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0044BE E0               [24]  922 	movx	a,@dptr
      0044BF FE               [12]  923 	mov	r6,a
      0044C0 EF               [12]  924 	mov	a,r7
      0044C1 B5 06 38         [24]  925 	cjne	a,ar6,00127$
                                    926 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0044C4 90 05 E9         [24]  927 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044C7 74 0C            [12]  928 	mov	a,#0x0c
      0044C9 F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0044CA 90 05 C8         [24]  931 	mov	dptr,#_cached_page
      0044CD E0               [24]  932 	movx	a,@dptr
      0044CE FE               [12]  933 	mov	r6,a
      0044CF E4               [12]  934 	clr	a
      0044D0 C3               [12]  935 	clr	c
      0044D1 CE               [12]  936 	xch	a,r6
      0044D2 13               [12]  937 	rrc	a
      0044D3 CE               [12]  938 	xch	a,r6
      0044D4 13               [12]  939 	rrc	a
      0044D5 A2 E0            [12]  940 	mov	c,acc.0
      0044D7 CE               [12]  941 	xch	a,r6
      0044D8 13               [12]  942 	rrc	a
      0044D9 CE               [12]  943 	xch	a,r6
      0044DA 13               [12]  944 	rrc	a
      0044DB CE               [12]  945 	xch	a,r6
      0044DC 24 C7            [12]  946 	add	a,#0xc7
      0044DE FF               [12]  947 	mov	r7,a
      0044DF 12 48 E5         [24]  948 	lcall	_ak820_outline_0114
      0044E2 12 41 EF         [24]  949 	lcall	_write_page
      0044E5 E5 82            [12]  950 	mov	a, dpl
      0044E7 60 13            [24]  951 	jz	00127$
                                    952 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0044E9 90 05 E9         [24]  953 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044EC 74 0D            [12]  954 	mov	a,#0x0d
      0044EE F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0044EF 90 EF 40         [24]  957 	mov	dptr,#0xef40
      0044F2 12 3C E7         [24]  958 	lcall	_ak820_flash_erase
      0044F5 E5 82            [12]  959 	mov	a, dpl
      0044F7 60 03            [24]  960 	jz	00127$
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    962 ;	assignBit
      0044F9 C2 08            [12]  963 	clr	_page_dirty
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0044FB 22               [24]  966 	ret
      0044FC                        967 00127$:
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0044FC 90 05 E9         [24]  969 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0044FF E0               [24]  970 	movx	a,@dptr
      004500 F5 82            [12]  971 	mov	dpl,a
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      004502 02 41 0E         [24]  973 	ljmp	_nvm_fail
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    976 ;------------------------------------------------------------
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    978 ;	-----------------------------------------
                                    979 ;	 function ak820_nvm_begin
                                    980 ;	-----------------------------------------
      004505                        981 _ak820_nvm_begin:
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      004505 90 05 C9         [24]  983 	mov	dptr,#_batch_depth
      004508 E0               [24]  984 	movx	a,@dptr
      004509 FF               [12]  985 	mov	r7,a
      00450A BF FF 06         [24]  986 	cjne	r7,#0xff,00102$
      00450D 75 82 0F         [24]  987 	mov	dpl, #0x0f
      004510 02 41 0E         [24]  988 	ljmp	_nvm_fail
      004513                        989 00102$:
                                    990 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004513 90 05 C9         [24]  991 	mov	dptr,#_batch_depth
      004516 EF               [12]  992 	mov	a,r7
      004517 04               [12]  993 	inc	a
      004518 F0               [24]  994 	movx	@dptr,a
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004519 22               [24]  996 	ret
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    999 ;------------------------------------------------------------
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function ak820_nvm_end
                                   1003 ;	-----------------------------------------
      00451A                       1004 _ak820_nvm_end:
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00451A 90 05 C9         [24] 1006 	mov	dptr,#_batch_depth
      00451D E0               [24] 1007 	movx	a,@dptr
      00451E FF               [12] 1008 	mov	r7,a
      00451F E0               [24] 1009 	movx	a,@dptr
      004520 60 06            [24] 1010 	jz	00102$
      004522 EF               [12] 1011 	mov	a,r7
      004523 14               [12] 1012 	dec	a
      004524 90 05 C9         [24] 1013 	mov	dptr,#_batch_depth
      004527 F0               [24] 1014 	movx	@dptr,a
      004528                       1015 00102$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004528 90 05 C9         [24] 1017 	mov	dptr,#_batch_depth
      00452B E0               [24] 1018 	movx	a,@dptr
      00452C 70 03            [24] 1019 	jnz	00105$
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      00452E 02 43 B3         [24] 1021 	ljmp	_ak820_nvm_flush
      004531                       1022 00105$:
      004531 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'load_page'
                                   1026 ;------------------------------------------------------------
                                   1027 ;page          Allocated with name '_load_page_page_10000_87'
                                   1028 ;i             Allocated with name '_load_page_i_10000_88'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function load_page
                                   1033 ;	-----------------------------------------
      004532                       1034 _load_page:
      004532 E5 82            [12] 1035 	mov	a,dpl
      004534 90 05 EA         [24] 1036 	mov	dptr,#_load_page_page_10000_87
      004537 F0               [24] 1037 	movx	@dptr,a
                                   1038 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004538 30 07 17         [24] 1039 	jnb	_page_valid,00102$
      00453B 90 05 C8         [24] 1040 	mov	dptr,#_cached_page
      00453E E0               [24] 1041 	movx	a,@dptr
      00453F FF               [12] 1042 	mov	r7,a
      004540 90 05 EA         [24] 1043 	mov	dptr,#_load_page_page_10000_87
      004543 E0               [24] 1044 	movx	a,@dptr
      004544 FE               [12] 1045 	mov	r6,a
      004545 EF               [12] 1046 	mov	a,r7
      004546 B5 06 09         [24] 1047 	cjne	a,ar6,00102$
      004549 A2 09            [12] 1048 	mov	c,_storage_failed
      00454B B3               [12] 1049 	cpl	c
      00454C 92 0B            [24] 1050 	mov  _load_page_sloc0_1_0,c
      00454E 12 38 7D         [24] 1051 	lcall	_ak820_outline_0167
      004551 22               [24] 1052 	ret
      004552                       1053 00102$:
                                   1054 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004552 12 43 B3         [24] 1055 	lcall	_ak820_nvm_flush
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004555 30 09 04         [24] 1057 	jnb	_storage_failed,00119$
      004558 75 82 00         [24] 1058 	mov	dpl, #0x00
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00455B 22               [24] 1060 	ret
      00455C                       1061 00119$:
      00455C 7F 00            [12] 1062 	mov	r7,#0x00
      00455E                       1063 00107$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      00455E EF               [12] 1065 	mov	a,r7
      00455F 24 88            [12] 1066 	add	a, #_page_data
      004561 FD               [12] 1067 	mov	r5,a
      004562 E4               [12] 1068 	clr	a
      004563 34 05            [12] 1069 	addc	a, #(_page_data >> 8)
      004565 FE               [12] 1070 	mov	r6,a
      004566 90 05 EA         [24] 1071 	mov	dptr,#_load_page_page_10000_87
      004569 E0               [24] 1072 	movx	a,@dptr
      00456A FC               [12] 1073 	mov	r4,a
      00456B FA               [12] 1074 	mov	r2,a
      00456C E4               [12] 1075 	clr	a
      00456D C3               [12] 1076 	clr	c
      00456E CA               [12] 1077 	xch	a,r2
      00456F 13               [12] 1078 	rrc	a
      004570 CA               [12] 1079 	xch	a,r2
      004571 13               [12] 1080 	rrc	a
      004572 A2 E0            [12] 1081 	mov	c,acc.0
      004574 CA               [12] 1082 	xch	a,r2
      004575 13               [12] 1083 	rrc	a
      004576 CA               [12] 1084 	xch	a,r2
      004577 13               [12] 1085 	rrc	a
      004578 CA               [12] 1086 	xch	a,r2
      004579 24 C7            [12] 1087 	add	a,#0xc7
      00457B FB               [12] 1088 	mov	r3,a
      00457C 8F 01            [24] 1089 	mov	ar1,r7
      00457E 89 00            [24] 1090 	mov	ar0,r1
      004580 79 00            [12] 1091 	mov	r1,#0x00
      004582 E8               [12] 1092 	mov	a,r0
      004583 2A               [12] 1093 	add	a, r2
      004584 FA               [12] 1094 	mov	r2,a
      004585 E9               [12] 1095 	mov	a,r1
      004586 3B               [12] 1096 	addc	a, r3
      004587 FB               [12] 1097 	mov	r3,a
      004588 12 49 01         [24] 1098 	lcall	_ak820_outline_0141
      00458B 12 3B DA         [24] 1099 	lcall	_ak820_flash_read
      00458E AB 82            [24] 1100 	mov	r3, dpl
      004590 12 38 61         [24] 1101 	lcall	_ak820_outline_0133
      004593 EB               [12] 1102 	mov	a,r3
      004594 F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004595 0F               [12] 1105 	inc	r7
      004596 BF 40 C5         [24] 1106 	cjne	r7,#0x40,00107$
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004599 90 05 C8         [24] 1108 	mov	dptr,#_cached_page
      00459C EC               [12] 1109 	mov	a,r4
      00459D F0               [24] 1110 	movx	@dptr,a
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1112 ;	assignBit
      00459E D2 07            [12] 1113 	setb	_page_valid
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      0045A0 75 82 01         [24] 1115 	mov	dpl, #0x01
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      0045A3 22               [24] 1117 	ret
                                   1118 ;------------------------------------------------------------
                                   1119 ;Allocation info for local variables in function 'read_offset'
                                   1120 ;------------------------------------------------------------
                                   1121 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1122 ;------------------------------------------------------------
                                   1123 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1124 ;	-----------------------------------------
                                   1125 ;	 function read_offset
                                   1126 ;	-----------------------------------------
      0045A4                       1127 _read_offset:
      0045A4 12 38 41         [24] 1128 	lcall	_ak820_outline_0104
      0045A7 90 05 EB         [24] 1129 	mov	dptr,#_read_offset_offset_10000_93
      0045AA 12 38 46         [24] 1130 	lcall	_ak820_outline_0105
                                   1131 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      0045AD 90 05 EB         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      0045B0 12 37 F7         [24] 1133 	lcall	_ak820_outline_0052
      0045B3 C3               [12] 1134 	clr	c
      0045B4 94 28            [12] 1135 	subb	a,#0x28
      0045B6 40 04            [24] 1136 	jc	00102$
      0045B8 75 82 00         [24] 1137 	mov	dpl, #0x00
      0045BB 22               [24] 1138 	ret
      0045BC                       1139 00102$:
                                   1140 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0045BC 30 07 34         [24] 1141 	jnb	_page_valid,00104$
      0045BF 8E 04            [24] 1142 	mov	ar4,r6
      0045C1 EF               [12] 1143 	mov	a,r7
      0045C2 A2 E7            [12] 1144 	mov	c,acc.7
      0045C4 CC               [12] 1145 	xch	a,r4
      0045C5 33               [12] 1146 	rlc	a
      0045C6 CC               [12] 1147 	xch	a,r4
      0045C7 33               [12] 1148 	rlc	a
      0045C8 A2 E7            [12] 1149 	mov	c,acc.7
      0045CA CC               [12] 1150 	xch	a,r4
      0045CB 33               [12] 1151 	rlc	a
      0045CC CC               [12] 1152 	xch	a,r4
      0045CD 33               [12] 1153 	rlc	a
      0045CE CC               [12] 1154 	xch	a,r4
      0045CF 54 03            [12] 1155 	anl	a,#0x03
      0045D1 FD               [12] 1156 	mov	r5,a
      0045D2 90 05 C8         [24] 1157 	mov	dptr,#_cached_page
      0045D5 E0               [24] 1158 	movx	a,@dptr
      0045D6 FA               [12] 1159 	mov	r2,a
      0045D7 7B 00            [12] 1160 	mov	r3,#0x00
      0045D9 EC               [12] 1161 	mov	a,r4
      0045DA B5 02 16         [24] 1162 	cjne	a,ar2,00104$
      0045DD ED               [12] 1163 	mov	a,r5
      0045DE B5 03 12         [24] 1164 	cjne	a,ar3,00104$
                                   1165 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0045E1 74 3F            [12] 1166 	mov	a,#0x3f
      0045E3 5E               [12] 1167 	anl	a,r6
      0045E4 7D 00            [12] 1168 	mov	r5,#0x00
      0045E6 24 88            [12] 1169 	add	a, #_page_data
      0045E8 F5 82            [12] 1170 	mov	dpl,a
      0045EA ED               [12] 1171 	mov	a,r5
      0045EB 34 05            [12] 1172 	addc	a, #(_page_data >> 8)
      0045ED F5 83            [12] 1173 	mov	dph,a
      0045EF E0               [24] 1174 	movx	a,@dptr
      0045F0 F5 82            [12] 1175 	mov	dpl,a
      0045F2 22               [24] 1176 	ret
      0045F3                       1177 00104$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0045F3 74 C7            [12] 1179 	mov	a,#0xc7
      0045F5 2F               [12] 1180 	add	a, r7
      0045F6 FF               [12] 1181 	mov	r7,a
      0045F7 12 48 E5         [24] 1182 	lcall	_ak820_outline_0114
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0045FA 02 3B DA         [24] 1184 	ljmp	_ak820_flash_read
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1187 ;------------------------------------------------------------
                                   1188 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function eeprom_read_byte
                                   1193 ;	-----------------------------------------
      0045FD                       1194 _eeprom_read_byte:
      0045FD C0 07            [24] 1195 	push	ar7
      0045FF C0 06            [24] 1196 	push	ar6
      004601 12 48 9C         [24] 1197 	lcall	_ak820_outline_0037
      004604 90 05 ED         [24] 1198 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004607 12 37 D6         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00460A 90 05 ED         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00460D 12 37 97         [24] 1202 	lcall	_ak820_outline_0004
      004610 C0 06            [24] 1203 	push	ar6
      004612 C0 05            [24] 1204 	push	ar5
      004614 C0 04            [24] 1205 	push	ar4
      004616 C0 03            [24] 1206 	push	ar3
      004618 C0 02            [24] 1207 	push	ar2
      00461A C0 01            [24] 1208 	push	ar1
      00461C C0 00            [24] 1209 	push	ar0
      00461E 12 45 A4         [24] 1210 	lcall	_read_offset
      004621 AF 82            [24] 1211 	mov	r7, dpl
      004623 D0 00            [24] 1212 	pop	ar0
      004625 D0 01            [24] 1213 	pop	ar1
      004627 D0 02            [24] 1214 	pop	ar2
      004629 D0 03            [24] 1215 	pop	ar3
      00462B D0 04            [24] 1216 	pop	ar4
      00462D D0 05            [24] 1217 	pop	ar5
      00462F D0 06            [24] 1218 	pop	ar6
      004631 8F 82            [24] 1219 	mov	dpl, r7
                                   1220 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004633 D0 06            [24] 1221 	pop	ar6
      004635 D0 07            [24] 1222 	pop	ar7
      004637 22               [24] 1223 	ret
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1226 ;------------------------------------------------------------
                                   1227 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1228 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1229 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1230 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1231 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1232 ;------------------------------------------------------------
                                   1233 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1234 ;	-----------------------------------------
                                   1235 ;	 function ak820_eeprom_read_block_xdata
                                   1236 ;	-----------------------------------------
      004638                       1237 _ak820_eeprom_read_block_xdata:
      004638 12 38 41         [24] 1238 	lcall	_ak820_outline_0104
      00463B 90 05 F5         [24] 1239 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00463E 12 38 46         [24] 1240 	lcall	_ak820_outline_0105
                                   1241 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004641 90 05 F0         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004644 12 37 F7         [24] 1243 	lcall	_ak820_outline_0052
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004647 90 05 F5         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00464A 12 38 16         [24] 1246 	lcall	_ak820_outline_0060
      00464D 90 05 F7         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004650 12 38 23         [24] 1248 	lcall	_ak820_outline_0072
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004653 90 05 F3         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004656 12 38 16         [24] 1251 	lcall	_ak820_outline_0060
      004659                       1252 00103$:
      004659 8C 02            [24] 1253 	mov	ar2,r4
      00465B 8D 03            [24] 1254 	mov	ar3,r5
      00465D 1C               [12] 1255 	dec	r4
      00465E BC FF 01         [24] 1256 	cjne	r4,#0xff,00130$
      004661 1D               [12] 1257 	dec	r5
      004662                       1258 00130$:
      004662 EA               [12] 1259 	mov	a,r2
      004663 4B               [12] 1260 	orl	a,r3
      004664 60 5D            [24] 1261 	jz	00106$
                                   1262 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004666 8E 02            [24] 1263 	mov	ar2,r6
      004668 8F 03            [24] 1264 	mov	ar3,r7
      00466A 74 D8            [12] 1265 	mov	a,#0x100 - 0x28
      00466C 2B               [12] 1266 	add	a,r3
      00466D 50 17            [24] 1267 	jnc	00102$
      00466F 90 05 F7         [24] 1268 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004672 12 48 EA         [24] 1269 	lcall	_ak820_outline_0120
      004675 12 49 01         [24] 1270 	lcall	_ak820_outline_0141
      004678 E4               [12] 1271 	clr	a
      004679 F0               [24] 1272 	movx	@dptr,a
      00467A 90 05 F7         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00467D 04               [12] 1274 	inc	a
      00467E 2A               [12] 1275 	add	a, r2
      00467F F0               [24] 1276 	movx	@dptr,a
      004680 E4               [12] 1277 	clr	a
      004681 3B               [12] 1278 	addc	a, r3
      004682 A3               [24] 1279 	inc	dptr
      004683 F0               [24] 1280 	movx	@dptr,a
      004684 80 D3            [24] 1281 	sjmp	00103$
      004686                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004686 90 05 F7         [24] 1284 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004689 12 48 EA         [24] 1285 	lcall	_ak820_outline_0120
      00468C 12 48 E5         [24] 1286 	lcall	_ak820_outline_0114
      00468F C0 07            [24] 1287 	push	ar7
      004691 C0 06            [24] 1288 	push	ar6
      004693 C0 05            [24] 1289 	push	ar5
      004695 C0 04            [24] 1290 	push	ar4
      004697 C0 03            [24] 1291 	push	ar3
      004699 C0 02            [24] 1292 	push	ar2
      00469B 12 45 A4         [24] 1293 	lcall	_read_offset
      00469E A9 82            [24] 1294 	mov	r1, dpl
      0046A0 D0 02            [24] 1295 	pop	ar2
      0046A2 D0 03            [24] 1296 	pop	ar3
      0046A4 D0 04            [24] 1297 	pop	ar4
      0046A6 D0 05            [24] 1298 	pop	ar5
      0046A8 D0 06            [24] 1299 	pop	ar6
      0046AA D0 07            [24] 1300 	pop	ar7
      0046AC 12 49 01         [24] 1301 	lcall	_ak820_outline_0141
      0046AF E9               [12] 1302 	mov	a,r1
      0046B0 F0               [24] 1303 	movx	@dptr,a
      0046B1 90 05 F7         [24] 1304 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0046B4 74 01            [12] 1305 	mov	a,#0x01
      0046B6 2A               [12] 1306 	add	a, r2
      0046B7 F0               [24] 1307 	movx	@dptr,a
      0046B8 E4               [12] 1308 	clr	a
      0046B9 3B               [12] 1309 	addc	a, r3
      0046BA A3               [24] 1310 	inc	dptr
      0046BB F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0046BC 0E               [12] 1313 	inc	r6
      0046BD BE 00 99         [24] 1314 	cjne	r6,#0x00,00103$
      0046C0 0F               [12] 1315 	inc	r7
      0046C1 80 96            [24] 1316 	sjmp	00103$
      0046C3                       1317 00106$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0046C3 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1322 ;------------------------------------------------------------
                                   1323 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1324 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1325 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1326 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1327 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1328 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1329 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1330 ;------------------------------------------------------------
                                   1331 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1332 ;	-----------------------------------------
                                   1333 ;	 function ak820_eeprom_write_block_xdata
                                   1334 ;	-----------------------------------------
      0046C4                       1335 _ak820_eeprom_write_block_xdata:
      0046C4 12 38 41         [24] 1336 	lcall	_ak820_outline_0104
      0046C7 90 05 FE         [24] 1337 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0046CA 12 38 46         [24] 1338 	lcall	_ak820_outline_0105
                                   1339 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0046CD 90 05 F9         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0046D0 12 37 F7         [24] 1341 	lcall	_ak820_outline_0052
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0046D3 90 05 FE         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0046D6 12 38 16         [24] 1344 	lcall	_ak820_outline_0060
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0046D9 8E 02            [24] 1346 	mov	ar2,r6
      0046DB 8F 03            [24] 1347 	mov	ar3,r7
      0046DD C3               [12] 1348 	clr	c
      0046DE E4               [12] 1349 	clr	a
      0046DF 9A               [12] 1350 	subb	a,r2
      0046E0 74 28            [12] 1351 	mov	a,#0x28
      0046E2 9B               [12] 1352 	subb	a,r3
      0046E3 40 15            [24] 1353 	jc	00101$
                                   1354 ;	free result
      0046E5 E4               [12] 1355 	clr	a
      0046E6 C3               [12] 1356 	clr	c
      0046E7 9E               [12] 1357 	subb	a,r6
      0046E8 FA               [12] 1358 	mov	r2,a
      0046E9 74 28            [12] 1359 	mov	a,#0x28
      0046EB 9F               [12] 1360 	subb	a,r7
      0046EC FB               [12] 1361 	mov	r3,a
      0046ED 90 05 FC         [24] 1362 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0046F0 12 38 3B         [24] 1363 	lcall	_ak820_outline_0101
      0046F3 C3               [12] 1364 	clr	c
      0046F4 EA               [12] 1365 	mov	a,r2
      0046F5 98               [12] 1366 	subb	a,r0
      0046F6 EB               [12] 1367 	mov	a,r3
      0046F7 99               [12] 1368 	subb	a,r1
      0046F8 50 06            [24] 1369 	jnc	00125$
                                   1370 ;	free result
      0046FA                       1371 00101$:
                                   1372 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0046FA 75 82 0E         [24] 1373 	mov	dpl, #0x0e
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0046FD 02 41 0E         [24] 1375 	ljmp	_nvm_fail
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004700                       1377 00125$:
      004700 90 05 FC         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004703 12 48 EA         [24] 1379 	lcall	_ak820_outline_0120
      004706                       1380 00108$:
      004706 8A 00            [24] 1381 	mov	ar0,r2
      004708 8B 01            [24] 1382 	mov	ar1,r3
      00470A 1A               [12] 1383 	dec	r2
      00470B BA FF 01         [24] 1384 	cjne	r2,#0xff,00159$
      00470E 1B               [12] 1385 	dec	r3
      00470F                       1386 00159$:
      00470F E8               [12] 1387 	mov	a,r0
      004710 49               [12] 1388 	orl	a,r1
      004711 70 03            [24] 1389 	jnz	00160$
      004713 02 47 9D         [24] 1390 	ljmp	00110$
      004716                       1391 00160$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004716 C0 02            [24] 1393 	push	ar2
      004718 C0 03            [24] 1394 	push	ar3
      00471A 12 48 CD         [24] 1395 	lcall	_ak820_outline_0094
      00471D F9               [12] 1396 	mov	r1,a
      00471E A3               [24] 1397 	inc	dptr
      00471F 12 49 06         [24] 1398 	lcall	_ak820_outline_0142
                                   1399 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004722 8E 0C            [24] 1400 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004724 8F 0D            [24] 1401 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004726 A8 0C            [24] 1402 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004728 E5 0D            [12] 1403 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00472A A2 E7            [12] 1404 	mov	c,acc.7
      00472C C8               [12] 1405 	xch	a,r0
      00472D 33               [12] 1406 	rlc	a
      00472E C8               [12] 1407 	xch	a,r0
      00472F 33               [12] 1408 	rlc	a
      004730 A2 E7            [12] 1409 	mov	c,acc.7
      004732 C8               [12] 1410 	xch	a,r0
      004733 33               [12] 1411 	rlc	a
      004734 C8               [12] 1412 	xch	a,r0
      004735 33               [12] 1413 	rlc	a
      004736 C8               [12] 1414 	xch	a,r0
      004737 54 03            [12] 1415 	anl	a,#0x03
      004739 FB               [12] 1416 	mov	r3,a
      00473A 88 82            [24] 1417 	mov	dpl, r0
      00473C C0 07            [24] 1418 	push	ar7
      00473E C0 06            [24] 1419 	push	ar6
      004740 C0 05            [24] 1420 	push	ar5
      004742 C0 04            [24] 1421 	push	ar4
      004744 C0 03            [24] 1422 	push	ar3
      004746 C0 02            [24] 1423 	push	ar2
      004748 C0 01            [24] 1424 	push	ar1
      00474A 12 45 32         [24] 1425 	lcall	_load_page
      00474D E5 82            [12] 1426 	mov	a, dpl
      00474F D0 01            [24] 1427 	pop	ar1
      004751 D0 02            [24] 1428 	pop	ar2
      004753 D0 03            [24] 1429 	pop	ar3
      004755 D0 04            [24] 1430 	pop	ar4
      004757 D0 05            [24] 1431 	pop	ar5
      004759 D0 06            [24] 1432 	pop	ar6
      00475B D0 07            [24] 1433 	pop	ar7
      00475D D0 03            [24] 1434 	pop	ar3
      00475F D0 02            [24] 1435 	pop	ar2
      004761 70 01            [24] 1436 	jnz	00105$
      004763 22               [24] 1437 	ret
      004764                       1438 00105$:
                                   1439 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004764 C0 06            [24] 1440 	push	ar6
      004766 C0 07            [24] 1441 	push	ar7
      004768 74 3F            [12] 1442 	mov	a,#0x3f
      00476A 55 0C            [12] 1443 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00476C 7F 00            [12] 1444 	mov	r7,#0x00
      00476E 24 88            [12] 1445 	add	a, #_page_data
      004770 F5 0C            [12] 1446 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004772 EF               [12] 1447 	mov	a,r7
      004773 34 05            [12] 1448 	addc	a, #(_page_data >> 8)
      004775 F5 0D            [12] 1449 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004777 85 0C 82         [24] 1450 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00477A 85 0D 83         [24] 1451 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00477D E0               [24] 1452 	movx	a,@dptr
      00477E B5 01 06         [24] 1453 	cjne	a,ar1,00162$
      004781 D0 07            [24] 1454 	pop	ar7
      004783 D0 06            [24] 1455 	pop	ar6
      004785 80 0E            [24] 1456 	sjmp	00107$
      004787                       1457 00162$:
      004787 D0 07            [24] 1458 	pop	ar7
      004789 D0 06            [24] 1459 	pop	ar6
                                   1460 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00478B 85 0C 82         [24] 1461 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00478E 85 0D 83         [24] 1462 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004791 E9               [12] 1463 	mov	a,r1
      004792 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1466 ;	assignBit
      004793 D2 08            [12] 1467 	setb	_page_dirty
      004795                       1468 00107$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004795 0E               [12] 1470 	inc	r6
      004796 BE 00 01         [24] 1471 	cjne	r6,#0x00,00163$
      004799 0F               [12] 1472 	inc	r7
      00479A                       1473 00163$:
      00479A 02 47 06         [24] 1474 	ljmp	00108$
      00479D                       1475 00110$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00479D 90 05 C9         [24] 1477 	mov	dptr,#_batch_depth
      0047A0 E0               [24] 1478 	movx	a,@dptr
      0047A1 70 03            [24] 1479 	jnz	00113$
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0047A3 02 43 B3         [24] 1481 	ljmp	_ak820_nvm_flush
      0047A6                       1482 00113$:
      0047A6 22               [24] 1483 	ret
                                   1484 ;------------------------------------------------------------
                                   1485 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1486 ;------------------------------------------------------------
                                   1487 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1488 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1489 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1490 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1491 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1492 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1493 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1494 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1495 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1496 ;------------------------------------------------------------
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1498 ;	-----------------------------------------
                                   1499 ;	 function ak820_eeprom_update_block_xdata
                                   1500 ;	-----------------------------------------
      0047A7                       1501 _ak820_eeprom_update_block_xdata:
      0047A7 12 38 41         [24] 1502 	lcall	_ak820_outline_0104
      0047AA 90 06 05         [24] 1503 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0047AD 12 38 46         [24] 1504 	lcall	_ak820_outline_0105
                                   1505 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0047B0 90 06 05         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0047B3 12 37 F7         [24] 1507 	lcall	_ak820_outline_0052
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0047B6 90 06 00         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0047B9 E0               [24] 1510 	movx	a,@dptr
      0047BA F5 12            [12] 1511 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0047BC A3               [24] 1512 	inc	dptr
      0047BD E0               [24] 1513 	movx	a,@dptr
      0047BE F5 13            [12] 1514 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0047C0 A3               [24] 1515 	inc	dptr
      0047C1 E0               [24] 1516 	movx	a,@dptr
      0047C2 F5 14            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0047C4 A9 12            [24] 1518 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0047C6 AA 13            [24] 1519 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1520 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0047C8 E4               [12] 1521 	clr	a
      0047C9 F5 0E            [12] 1522 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0047CB F5 0F            [12] 1523 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0047CD                       1524 00105$:
      0047CD 90 06 03         [24] 1525 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0047D0 E0               [24] 1526 	movx	a,@dptr
      0047D1 F5 10            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0047D3 A3               [24] 1528 	inc	dptr
      0047D4 E0               [24] 1529 	movx	a,@dptr
      0047D5 F5 11            [12] 1530 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0047D7 C3               [12] 1531 	clr	c
      0047D8 E5 0E            [12] 1532 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047DA 95 10            [12] 1533 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0047DC E5 0F            [12] 1534 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047DE 95 11            [12] 1535 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0047E0 50 68            [24] 1536 	jnc	00107$
                                   1537 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0047E2 89 00            [24] 1538 	mov	ar0,r1
      0047E4 8A 05            [24] 1539 	mov	ar5,r2
      0047E6 E5 0E            [12] 1540 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0047E8 28               [12] 1541 	add	a, r0
      0047E9 F8               [12] 1542 	mov	r0,a
      0047EA E5 0F            [12] 1543 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0047EC 3D               [12] 1544 	addc	a, r5
      0047ED FD               [12] 1545 	mov	r5,a
      0047EE 88 82            [24] 1546 	mov	dpl, r0
      0047F0 8D 83            [24] 1547 	mov	dph, r5
      0047F2 C0 07            [24] 1548 	push	ar7
      0047F4 C0 06            [24] 1549 	push	ar6
      0047F6 C0 02            [24] 1550 	push	ar2
      0047F8 C0 01            [24] 1551 	push	ar1
      0047FA 12 45 A4         [24] 1552 	lcall	_read_offset
      0047FD AD 82            [24] 1553 	mov	r5, dpl
      0047FF D0 01            [24] 1554 	pop	ar1
      004801 D0 02            [24] 1555 	pop	ar2
      004803 D0 06            [24] 1556 	pop	ar6
      004805 D0 07            [24] 1557 	pop	ar7
      004807 E5 0E            [12] 1558 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004809 2E               [12] 1559 	add	a, r6
      00480A F5 82            [12] 1560 	mov	dpl,a
      00480C E5 0F            [12] 1561 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00480E 3F               [12] 1562 	addc	a, r7
      00480F F5 83            [12] 1563 	mov	dph,a
      004811 E0               [24] 1564 	movx	a,@dptr
      004812 FC               [12] 1565 	mov	r4,a
      004813 ED               [12] 1566 	mov	a,r5
      004814 B5 04 02         [24] 1567 	cjne	a,ar4,00131$
      004817 80 27            [24] 1568 	sjmp	00106$
      004819                       1569 00131$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004819 90 06 05         [24] 1571 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00481C E0               [24] 1572 	movx	a,@dptr
      00481D F8               [12] 1573 	mov	r0,a
      00481E A3               [24] 1574 	inc	dptr
      00481F E0               [24] 1575 	movx	a,@dptr
      004820 FD               [12] 1576 	mov	r5,a
      004821 90 05 F9         [24] 1577 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004824 E5 12            [12] 1578 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004826 F0               [24] 1579 	movx	@dptr,a
      004827 E5 13            [12] 1580 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004829 A3               [24] 1581 	inc	dptr
      00482A F0               [24] 1582 	movx	@dptr,a
      00482B E5 14            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00482D A3               [24] 1584 	inc	dptr
      00482E F0               [24] 1585 	movx	@dptr,a
      00482F 90 05 FC         [24] 1586 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004832 E5 10            [12] 1587 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004834 F0               [24] 1588 	movx	@dptr,a
      004835 E5 11            [12] 1589 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004837 A3               [24] 1590 	inc	dptr
      004838 F0               [24] 1591 	movx	@dptr,a
      004839 88 82            [24] 1592 	mov	dpl, r0
      00483B 8D 83            [24] 1593 	mov	dph, r5
                                   1594 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00483D 02 46 C4         [24] 1595 	ljmp	_ak820_eeprom_write_block_xdata
      004840                       1596 00106$:
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004840 05 0E            [12] 1598 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004842 E4               [12] 1599 	clr	a
      004843 B5 0E 87         [24] 1600 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004846 05 0F            [12] 1601 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004848 80 83            [24] 1602 	sjmp	00105$
      00484A                       1603 00107$:
                                   1604 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00484A 22               [24] 1605 	ret
                                   1606 ;------------------------------------------------------------
                                   1607 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1608 ;------------------------------------------------------------
                                   1609 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1610 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1611 ;------------------------------------------------------------
                                   1612 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1613 ;	-----------------------------------------
                                   1614 ;	 function eeprom_driver_erase
                                   1615 ;	-----------------------------------------
      00484B                       1616 _eeprom_driver_erase:
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00484B 12 43 B3         [24] 1618 	lcall	_ak820_nvm_flush
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00484E 7F 00            [12] 1620 	mov	r7,#0x00
      004850                       1621 00111$:
      004850 BF A0 01         [24] 1622 	cjne	r7,#0xa0,00165$
      004853 22               [24] 1623 	ret
      004854                       1624 00165$:
      004854 20 09 32         [24] 1625 	jb	_storage_failed,00113$
                                   1626 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004857 8F 82            [24] 1627 	mov	dpl, r7
      004859 C0 07            [24] 1628 	push	ar7
      00485B 12 45 32         [24] 1629 	lcall	_load_page
      00485E E5 82            [12] 1630 	mov	a, dpl
      004860 D0 07            [24] 1631 	pop	ar7
      004862 70 01            [24] 1632 	jnz	00126$
                                   1633 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004864 22               [24] 1634 	ret
      004865                       1635 00126$:
      004865 7E 00            [12] 1636 	mov	r6,#0x00
      004867                       1637 00107$:
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004867 EE               [12] 1639 	mov	a,r6
      004868 24 88            [12] 1640 	add	a, #_page_data
      00486A FC               [12] 1641 	mov	r4,a
      00486B E4               [12] 1642 	clr	a
      00486C 34 05            [12] 1643 	addc	a, #(_page_data >> 8)
      00486E FD               [12] 1644 	mov	r5,a
      00486F 12 48 CD         [24] 1645 	lcall	_ak820_outline_0094
      004872 60 07            [24] 1646 	jz	00108$
      004874 12 38 57         [24] 1647 	lcall	_ak820_outline_0122
      004877 E4               [12] 1648 	clr	a
      004878 F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	assignBit
      004879 D2 08            [12] 1651 	setb	_page_dirty
      00487B                       1652 00108$:
                                   1653 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00487B 0E               [12] 1654 	inc	r6
      00487C BE 40 E8         [24] 1655 	cjne	r6,#0x40,00107$
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00487F C0 07            [24] 1657 	push	ar7
      004881 12 43 B3         [24] 1658 	lcall	_ak820_nvm_flush
      004884 D0 07            [24] 1659 	pop	ar7
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004886 0F               [12] 1661 	inc	r7
      004887 80 C7            [24] 1662 	sjmp	00111$
      004889                       1663 00113$:
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004889 22               [24] 1665 	ret
                                   1666 	.area CSEG    (CODE)
                                   1667 	.area CONST   (CODE)
                                   1668 	.area XINIT   (CODE)
                                   1669 	.area CABS    (ABS,CODE)
                                   1670 
                                   1671 ; Experimental exact instruction outlining.
                                   1672 	.globl _ak820_outline_0004
                                   1673 	.globl _ak820_outline_0010
                                   1674 	.globl _ak820_outline_0016
                                   1675 	.globl _ak820_outline_0017
                                   1676 	.globl _ak820_outline_0032
                                   1677 	.globl _ak820_outline_0037
                                   1678 	.globl _ak820_outline_0041
                                   1679 	.globl _ak820_outline_0052
                                   1680 	.globl _ak820_outline_0053
                                   1681 	.globl _ak820_outline_0060
                                   1682 	.globl _ak820_outline_0061
                                   1683 	.globl _ak820_outline_0065
                                   1684 	.globl _ak820_outline_0072
                                   1685 	.globl _ak820_outline_0078
                                   1686 	.globl _ak820_outline_0094
                                   1687 	.globl _ak820_outline_0095
                                   1688 	.globl _ak820_outline_0101
                                   1689 	.globl _ak820_outline_0102
                                   1690 	.globl _ak820_outline_0104
                                   1691 	.globl _ak820_outline_0105
                                   1692 	.globl _ak820_outline_0114
                                   1693 	.globl _ak820_outline_0120
                                   1694 	.globl _ak820_outline_0121
                                   1695 	.globl _ak820_outline_0122
                                   1696 	.globl _ak820_outline_0123
                                   1697 	.globl _ak820_outline_0132
                                   1698 	.globl _ak820_outline_0133
                                   1699 	.globl _ak820_outline_0135
                                   1700 	.globl _ak820_outline_0140
                                   1701 	.globl _ak820_outline_0141
                                   1702 	.globl _ak820_outline_0142
                                   1703 	.globl _ak820_outline_0154
                                   1704 	.globl _ak820_outline_0157
                                   1705 	.globl _ak820_outline_0158
                                   1706 	.globl _ak820_outline_0167
                                   1707 	.globl _ak820_outline_0180
                                   1708 	.globl _ak820_outline_0181
                                   1709 	.globl _ak820_outline_0186
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0010
      00488A                       1713 _ak820_outline_0010:
      00488A 8E 82            [24] 1714 	mov	dpl,r6
      00488C 8F 83            [24] 1715 	mov	dph,r7
      00488E A3               [24] 1716 	inc	dptr
      00488F A3               [24] 1717 	inc	dptr
      004890 A3               [24] 1718 	inc	dptr
      004891 A3               [24] 1719 	inc	dptr
      004892 A3               [24] 1720 	inc	dptr
      004893 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0032
      004894                       1725 _ak820_outline_0032:
      004894 F0               [24] 1726 	movx	@dptr,a
      004895 8E 82            [24] 1727 	mov	dpl,r6
      004897 8F 83            [24] 1728 	mov	dph,r7
      004899 A3               [24] 1729 	inc	dptr
      00489A A3               [24] 1730 	inc	dptr
      00489B 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      00489C                       1735 _ak820_outline_0037:
      00489C AF F0            [24] 1736 	mov	r7,b
      00489E AE 83            [24] 1737 	mov	r6,dph
      0048A0 E5 82            [12] 1738 	mov	a,dpl
      0048A2 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0041
      0048A3                       1743 _ak820_outline_0041:
      0048A3 EF               [12] 1744 	mov	a,r7
      0048A4 24 E0            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      0048A6 F5 82            [12] 1746 	mov	dpl,a
      0048A8 E4               [12] 1747 	clr	a
      0048A9 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0048AB F5 83            [12] 1749 	mov	dph,a
      0048AD E0               [24] 1750 	movx	a,@dptr
      0048AE 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0053
      0048AF                       1755 _ak820_outline_0053:
      0048AF 8F 06            [24] 1756 	mov	ar6,r7
      0048B1 7D 00            [12] 1757 	mov	r5,#0x00
      0048B3 74 40            [12] 1758 	mov	a,#0x40
      0048B5 2E               [12] 1759 	add	a,r6
      0048B6 FE               [12] 1760 	mov	r6,a
      0048B7 74 EF            [12] 1761 	mov	a,#0xef
      0048B9 3D               [12] 1762 	addc	a,r5
      0048BA FD               [12] 1763 	mov	r5,a
      0048BB 8E 82            [24] 1764 	mov	dpl,r6
      0048BD 8D 83            [24] 1765 	mov	dph,r5
      0048BF 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      0048C0                       1770 _ak820_outline_0061:
      0048C0 F0               [24] 1771 	movx	@dptr,a
      0048C1 8E 82            [24] 1772 	mov	dpl,r6
      0048C3 8F 83            [24] 1773 	mov	dph,r7
      0048C5 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0065
      0048C6                       1778 _ak820_outline_0065:
      0048C6 8D 82            [24] 1779 	mov	dpl,r5
      0048C8 8E 83            [24] 1780 	mov	dph,r6
      0048CA EC               [12] 1781 	mov	a,r4
      0048CB F0               [24] 1782 	movx	@dptr,a
      0048CC 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0094
      0048CD                       1787 _ak820_outline_0094:
      0048CD 8C 82            [24] 1788 	mov	dpl,r4
      0048CF 8D 83            [24] 1789 	mov	dph,r5
      0048D1 E0               [24] 1790 	movx	a,@dptr
      0048D2 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0095
      0048D3                       1795 _ak820_outline_0095:
      0048D3 E0               [24] 1796 	movx	a,@dptr
      0048D4 FD               [12] 1797 	mov	r5,a
      0048D5 A3               [24] 1798 	inc	dptr
      0048D6 E0               [24] 1799 	movx	a,@dptr
      0048D7 FE               [12] 1800 	mov	r6,a
      0048D8 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0102
      0048D9                       1805 _ak820_outline_0102:
      0048D9 EF               [12] 1806 	mov	a,r7
      0048DA 24 88            [12] 1807 	add	a,#_page_data
      0048DC F5 82            [12] 1808 	mov	dpl,a
      0048DE E4               [12] 1809 	clr	a
      0048DF 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      0048E1 F5 83            [12] 1811 	mov	dph,a
      0048E3 E0               [24] 1812 	movx	a,@dptr
      0048E4 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0114
      0048E5                       1817 _ak820_outline_0114:
      0048E5 8E 82            [24] 1818 	mov	dpl,r6
      0048E7 8F 83            [24] 1819 	mov	dph,r7
      0048E9 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0120
      0048EA                       1824 _ak820_outline_0120:
      0048EA E0               [24] 1825 	movx	a,@dptr
      0048EB FA               [12] 1826 	mov	r2,a
      0048EC A3               [24] 1827 	inc	dptr
      0048ED E0               [24] 1828 	movx	a,@dptr
      0048EE FB               [12] 1829 	mov	r3,a
      0048EF 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0132
      0048F0                       1834 _ak820_outline_0132:
      0048F0 AE 82            [24] 1835 	mov	r6,dpl
      0048F2 AF 83            [24] 1836 	mov	r7,dph
      0048F4 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0135
      0048F5                       1841 _ak820_outline_0135:
      0048F5 2E               [12] 1842 	add	a,r6
      0048F6 FE               [12] 1843 	mov	r6,a
      0048F7 E4               [12] 1844 	clr	a
      0048F8 3F               [12] 1845 	addc	a,r7
      0048F9 FF               [12] 1846 	mov	r7,a
      0048FA 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0140
      0048FB                       1851 _ak820_outline_0140:
      0048FB 42 05            [12] 1852 	orl	ar5,a
      0048FD EA               [12] 1853 	mov	a,r2
      0048FE 42 04            [12] 1854 	orl	ar4,a
      004900 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0141
      004901                       1859 _ak820_outline_0141:
      004901 8A 82            [24] 1860 	mov	dpl,r2
      004903 8B 83            [24] 1861 	mov	dph,r3
      004905 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0142
      004906                       1866 _ak820_outline_0142:
      004906 AC 82            [24] 1867 	mov	r4,dpl
      004908 AD 83            [24] 1868 	mov	r5,dph
      00490A 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0154
      00490B                       1873 _ak820_outline_0154:
      00490B 8F 82            [24] 1874 	mov	dpl,r7
      00490D 8E 83            [24] 1875 	mov	dph,r6
      00490F 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0157
      004910                       1880 _ak820_outline_0157:
      004910 2E               [12] 1881 	add	a,r6
      004911 FC               [12] 1882 	mov	r4,a
      004912 E4               [12] 1883 	clr	a
      004913 3F               [12] 1884 	addc	a,r7
      004914 FD               [12] 1885 	mov	r5,a
      004915 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0158
      004916                       1890 _ak820_outline_0158:
      004916 ED               [12] 1891 	mov	a,r5
      004917 F0               [24] 1892 	movx	@dptr,a
      004918 EE               [12] 1893 	mov	a,r6
      004919 A3               [24] 1894 	inc	dptr
      00491A F0               [24] 1895 	movx	@dptr,a
      00491B 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0180
      00491C                       1900 _ak820_outline_0180:
      00491C 89 82            [24] 1901 	mov	dpl,r1
      00491E 8A 83            [24] 1902 	mov	dph,r2
      004920 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0181
      004921                       1907 _ak820_outline_0181:
      004921 8C 82            [24] 1908 	mov	dpl,r4
      004923 8B 83            [24] 1909 	mov	dph,r3
      004925 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0186
      004926                       1914 _ak820_outline_0186:
      004926 8D 82            [24] 1915 	mov	dpl,r5
      004928 8C 83            [24] 1916 	mov	dph,r4
      00492A 22               [24] 1917 	ret
