;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_mousekey
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_usb_try_send
	.globl _timer_read
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _mousekey_on
	.globl _mousekey_off
	.globl _mousekey_send
	.globl _mousekey_task
	.globl _mousekey_clear
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_directions:
	.ds 1
_immediate:
	.ds 1
_buttons:
	.ds 1
_accepted_buttons:
	.ds 1
_cursor_time:
	.ds 2
_wheel_time:
	.ds 2
_mouse_report:
	.ds 6
_direction_bit_code_10000_129:
	.ds 1
_mousekey_on_code_10000_133:
	.ds 1
_mousekey_off_code_10000_140:
	.ds 1
_axis_PARM_2:
	.ds 1
_axis_PARM_3:
	.ds 1
_axis_selected_10000_143:
	.ds 1
_mousekey_send_selected_10000_149:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function direction_bit
;	-----------------------------------------
_direction_bit:
	mov	a,dpl
	mov	dptr,#_direction_bit_code_10000_129
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:24: if (code >= KC_MS_UP && code <= KC_MS_RIGHT) return (uint8_t)(1u << (code - KC_MS_UP));
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xcd,00137$
00137$:
	jc	00102$
	mov	a,r7
	add	a,#0xff - 0xd0
	jc	00102$
;	free result
	mov	a,r7
	add	a,#0x33
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00141$
00140$:
	add	a,acc
00141$:
	djnz	b,00140$
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:25: if (code >= KC_MS_WH_UP && code <= KC_MS_WH_RIGHT) return (uint8_t)(0x10u << (code - KC_MS_WH_UP));
	mov	dptr,#_direction_bit_code_10000_129
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xd9,00142$
00142$:
	jc	00105$
	mov	a,r7
	add	a,#0xff - 0xdc
	jc	00105$
;	free result
	mov	a,r7
	add	a,#0x27
	mov	b,a
	inc	b
	mov	a,#0x10
	sjmp	00146$
00145$:
	add	a,acc
00146$:
	djnz	b,00145$
	mov	dpl,a
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:26: return 0;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_mousekey.c:27: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mousekey_on'
;------------------------------------------------------------
;code          Allocated with name '_mousekey_on_code_10000_133'
;bit           Allocated with name '_mousekey_on_bit_10000_134'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:29: void mousekey_on(uint8_t code) {
;	-----------------------------------------
;	 function mousekey_on
;	-----------------------------------------
_mousekey_on:
	mov	a,dpl
	mov	dptr,#_mousekey_on_code_10000_133
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:30: uint8_t bit = direction_bit(code);
	movx	a,@dptr
	mov	dpl,a
	lcall	_direction_bit
;	keyboards/ajazz/ak820/ak820_mousekey.c:31: if (bit && !(directions & bit)) {
	mov	a,dpl
	mov	r7,a
	jz	00108$
	mov	dptr,#_directions
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	anl	a,r6
	jnz	00108$
;	keyboards/ajazz/ak820/ak820_mousekey.c:32: immediate |= bit;
	mov	dptr,#_immediate
	movx	a,@dptr
	orl	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:33: directions |= bit;
	mov	dptr,#_directions
	mov	a,r7
	orl	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:34: if (bit & 0x0f) cursor_time = timer_read();
	mov	a,r7
	anl	a,#0x0f
	jz	00102$
	lcall	_timer_read
	mov	a, dpl
	mov	b, dph
	mov	dptr,#_cursor_time
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:35: else wheel_time = timer_read();
	lcall	_timer_read
	mov	a, dpl
	mov	b, dph
	mov	dptr,#_wheel_time
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
	ret
00108$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:36: } else if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) {
	mov	dptr,#_mousekey_on_code_10000_133
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xd1,00151$
00151$:
	jc	00111$
	mov	a,r7
	add	a,#0xff - 0xd5
	jc	00111$
;	free result
;	keyboards/ajazz/ak820/ak820_mousekey.c:37: buttons |= (uint8_t)(1u << (code - KC_MS_BTN1));
	mov	a,r7
	add	a,#0x2f
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00155$
00154$:
	add	a,acc
00155$:
	djnz	b,00154$
	mov	r7,a
	mov	dptr,#_buttons
	movx	a,@dptr
	orl	a,r7
	movx	@dptr,a
00111$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:39: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mousekey_off'
;------------------------------------------------------------
;code          Allocated with name '_mousekey_off_code_10000_140'
;bit           Allocated with name '_mousekey_off_bit_10000_141'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:41: void mousekey_off(uint8_t code) {
;	-----------------------------------------
;	 function mousekey_off
;	-----------------------------------------
_mousekey_off:
	mov	a,dpl
	mov	dptr,#_mousekey_off_code_10000_140
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:42: uint8_t bit = direction_bit(code);
	movx	a,@dptr
	mov	r7,a
	mov	dpl,a
	push	ar7
	lcall	_direction_bit
	mov	a, dpl
	pop	ar7
;	keyboards/ajazz/ak820/ak820_mousekey.c:43: directions &= (uint8_t)~bit;
	cpl	a
	mov	r6,a
	mov	dptr,#_directions
	movx	a,@dptr
	anl	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:44: immediate &= (uint8_t)~bit;
	mov	dptr,#_immediate
	movx	a,@dptr
	anl	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:45: if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) buttons &= (uint8_t)~(1u << (code - KC_MS_BTN1));
	cjne	r7,#0xd1,00120$
00120$:
	jc	00104$
	mov	a,r7
	add	a,#0xff - 0xd5
	jc	00104$
;	free result
	mov	a,r7
	add	a,#0x2f
	mov	b,a
	inc	b
	mov	a,#0x01
	sjmp	00124$
00123$:
	add	a,acc
00124$:
	djnz	b,00123$
	cpl	a
	mov	r7,a
	mov	dptr,#_buttons
	movx	a,@dptr
	anl	a,r7
	movx	@dptr,a
00104$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:46: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'axis'
;------------------------------------------------------------
;negative      Allocated with name '_axis_PARM_2'
;positive      Allocated with name '_axis_PARM_3'
;selected      Allocated with name '_axis_selected_10000_143'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:49: static int8_t axis(uint8_t selected, uint8_t negative, uint8_t positive) {
;	-----------------------------------------
;	 function axis
;	-----------------------------------------
_axis:
	mov	a,dpl
	mov	dptr,#_axis_selected_10000_143
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:50: if ((directions & (negative | positive)) == (negative | positive)) return 0;
	mov	dptr,#_axis_PARM_3
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_axis_PARM_2
	movx	a,@dptr
	mov	r6,a
	orl	a,r7
	mov	r5,a
	mov	dptr,#_directions
	movx	a,@dptr
	anl	a,r5
	cjne	a,ar5,00102$
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:51: if (selected & negative) return -1;
	mov	dptr,#_axis_selected_10000_143
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	anl	a,r5
	jz	00104$
	mov	dpl, #0xff
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:52: if (selected & positive) return 1;
	mov	a,r7
	anl	a,r5
	jz	00106$
	mov	dpl, #0x01
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:53: return 0;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_mousekey.c:54: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mousekey_send'
;------------------------------------------------------------
;selected      Allocated with name '_mousekey_send_selected_10000_149'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:56: void mousekey_send(void) {
;	-----------------------------------------
;	 function mousekey_send
;	-----------------------------------------
_mousekey_send:
;	keyboards/ajazz/ak820/ak820_mousekey.c:57: uint8_t selected = immediate;
	mov	dptr,#_immediate
	movx	a,@dptr
	mov	dptr,#_mousekey_send_selected_10000_149
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:58: immediate = 0; /* Relative movement never accumulates behind a busy endpoint. */
	mov	dptr,#_immediate
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:60: mouse_report.report_id = REPORT_ID_MOUSE;
	mov	dptr,#_mouse_report
	mov	a,#0x02
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:62: mouse_report.buttons = buttons;
	mov	dptr,#_buttons
	movx	a,@dptr
	mov	dptr,#(_mouse_report + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:63: mouse_report.x = axis(selected, 4, 8) * 8;
	mov	dptr,#_mousekey_send_selected_10000_149
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_axis_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	mov	dptr,#_axis_PARM_3
	rl	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	lcall	_axis
	mov	r6, dpl
	pop	ar7
	mov	a,r6
	swap	a
	rr	a
	anl	a,#0xf8
	mov	dptr,#(_mouse_report + 0x0002)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:64: mouse_report.y = axis(selected, 1, 2) * 8;
	mov	dptr,#_axis_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#_axis_PARM_3
	inc	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	lcall	_axis
	mov	r6, dpl
	pop	ar7
	mov	a,r6
	swap	a
	rr	a
	anl	a,#0xf8
	mov	dptr,#(_mouse_report + 0x0003)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:65: mouse_report.v = axis(selected, 0x20, 0x10);
	mov	dptr,#_axis_PARM_2
	mov	a,#0x20
	movx	@dptr,a
	mov	dptr,#_axis_PARM_3
	rr	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	lcall	_axis
	mov	r6, dpl
	pop	ar7
	mov	dptr,#(_mouse_report + 0x0004)
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:66: mouse_report.h = axis(selected, 0x40, 0x80);
	mov	dptr,#_axis_PARM_2
	mov	a,#0x40
	movx	@dptr,a
	mov	dptr,#_axis_PARM_3
	rl	a
	movx	@dptr,a
	mov	dpl, r7
	lcall	_axis
	mov	r7, dpl
	mov	dptr,#(_mouse_report + 0x0005)
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:67: if (!(mouse_report.x || mouse_report.y || mouse_report.v || mouse_report.h || buttons != accepted_buttons)) return;
	mov	dptr,#(_mouse_report + 0x0002)
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#(_mouse_report + 0x0003)
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#(_mouse_report + 0x0004)
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#(_mouse_report + 0x0005)
	movx	a,@dptr
	jnz	00102$
	mov	dptr,#_buttons
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_accepted_buttons
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00102$
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:68: if (ak820_usb_try_send(MOUSE_IN_EPNUM, (const uint8_t __xdata *)&mouse_report, sizeof(mouse_report))) accepted_buttons = buttons;
	mov	dptr,#_ak820_usb_try_send_PARM_2
	mov	a,#_mouse_report
	movx	@dptr,a
	mov	a,#(_mouse_report >> 8)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_usb_try_send_PARM_3
	mov	a,#0x06
	movx	@dptr,a
	mov	dpl, #0x02
	lcall	_ak820_usb_try_send
	mov	a, dpl
	jz	00109$
	mov	dptr,#_buttons
	movx	a,@dptr
	mov	dptr,#_accepted_buttons
	movx	@dptr,a
00109$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:69: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mousekey_task'
;------------------------------------------------------------
;now           Allocated with name '_mousekey_task_now_10000_153'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:71: void mousekey_task(void) {
;	-----------------------------------------
;	 function mousekey_task
;	-----------------------------------------
_mousekey_task:
;	keyboards/ajazz/ak820/ak820_mousekey.c:72: uint16_t now = timer_read();
	lcall	_timer_read
	mov	r6, dpl
	mov	r7, dph
;	keyboards/ajazz/ak820/ak820_mousekey.c:73: if ((uint16_t)(now - cursor_time) >= 20) {
	mov	dptr,#_cursor_time
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r4,a
	mov	a,r7
	subb	a,r5
	mov	r5,a
	clr	c
	mov	a,r4
	subb	a,#0x14
	mov	a,r5
	subb	a,#0x00
	jc	00102$
;	keyboards/ajazz/ak820/ak820_mousekey.c:74: cursor_time = now;
	mov	dptr,#_cursor_time
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:75: immediate |= directions & 0x0f;
	mov	dptr,#_directions
	movx	a,@dptr
	anl	a,#0x0f
	mov	r5,a
	mov	dptr,#_immediate
	movx	a,@dptr
	orl	a,r5
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:77: if ((uint16_t)(now - wheel_time) >= 80) {
	mov	dptr,#_wheel_time
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	clr	c
	subb	a,r4
	mov	r4,a
	mov	a,r7
	subb	a,r5
	mov	r5,a
	clr	c
	mov	a,r4
	subb	a,#0x50
	mov	a,r5
	subb	a,#0x00
	jc	00104$
;	keyboards/ajazz/ak820/ak820_mousekey.c:78: wheel_time = now;
	mov	dptr,#_wheel_time
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:79: immediate |= directions & 0xf0;
	mov	dptr,#_directions
	movx	a,@dptr
	anl	a,#0xf0
	mov	r7,a
	mov	dptr,#_immediate
	movx	a,@dptr
	orl	a,r7
	movx	@dptr,a
00104$:
;	keyboards/ajazz/ak820/ak820_mousekey.c:81: mousekey_send();
;	keyboards/ajazz/ak820/ak820_mousekey.c:82: }
	ljmp	_mousekey_send
;------------------------------------------------------------
;Allocation info for local variables in function 'mousekey_clear'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_mousekey.c:84: void mousekey_clear(void) {
;	-----------------------------------------
;	 function mousekey_clear
;	-----------------------------------------
_mousekey_clear:
;	keyboards/ajazz/ak820/ak820_mousekey.c:85: directions = 0;
	mov	dptr,#_directions
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:86: immediate = 0;
	mov	dptr,#_immediate
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:87: buttons = 0;
	mov	dptr,#_buttons
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_mousekey.c:89: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
