                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00052D                        109 _page_data:
      00052D                        110 	.ds 64
      00056D                        111 _cached_page:
      00056D                        112 	.ds 1
      00056E                        113 _batch_depth:
      00056E                        114 	.ds 1
      00056F                        115 _first_failure_stage:
      00056F                        116 	.ds 1
      000570                        117 _nvm_fail_stage_10000_20:
      000570                        118 	.ds 1
      000571                        119 _ak820_nvm_diagnostic_out_10000_23:
      000571                        120 	.ds 2
      000573                        121 _crc_byte_PARM_2:
      000573                        122 	.ds 1
      000574                        123 _crc_byte_crc_10000_25:
      000574                        124 	.ds 2
      000576                        125 _page_crc_crc_10000_30:
      000576                        126 	.ds 2
      000578                        127 _write_page_address_10000_32:
      000578                        128 	.ds 2
      00057A                        129 _journal_header_valid_header_10000_39:
      00057A                        130 	.ds 2
      00057C                        131 _recover_journal_header_10000_46:
      00057C                        132 	.ds 9
      000585                        133 _ak820_nvm_flush_header_10000_62:
      000585                        134 	.ds 9
      00058E                        135 _ak820_nvm_flush_stage_10000_62:
      00058E                        136 	.ds 1
      00058F                        137 _load_page_page_10000_87:
      00058F                        138 	.ds 1
      000590                        139 _read_offset_offset_10000_93:
      000590                        140 	.ds 2
      000592                        141 _eeprom_read_byte_addr_10000_97:
      000592                        142 	.ds 3
      000595                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000595                        144 	.ds 3
      000598                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000598                        146 	.ds 2
      00059A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00059A                        148 	.ds 2
      00059C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00059C                        150 	.ds 2
      00059E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059E                        152 	.ds 3
      0005A1                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005A1                        154 	.ds 2
      0005A3                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005A3                        156 	.ds 2
      0005A5                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A5                        158 	.ds 3
      0005A8                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A8                        160 	.ds 2
      0005AA                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005AA                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DF4                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DF4 E5 82            [12]  215 	mov	a,dpl
      003DF6 90 05 70         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003DF9 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003DFA 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      003DFD 90 05 70         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003E00 E0               [24]  221 	movx	a,@dptr
      003E01 90 05 6F         [24]  222 	mov	dptr,#_first_failure_stage
      003E04 F0               [24]  223 	movx	@dptr,a
      003E05                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E05 D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E07 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E08                        239 _ak820_nvm_diagnostic:
      003E08 12 3A F3         [24]  240 	lcall	_ak820_outline_0110
      003E0B 90 05 71         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E0E 12 3A F8         [24]  242 	lcall	_ak820_outline_0111
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003E11 90 05 71         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E14 12 3A B2         [24]  245 	lcall	_ak820_outline_0052
      003E17 A2 0C            [12]  246 	mov	c,_storage_failed
      003E19 E4               [12]  247 	clr	a
      003E1A 33               [12]  248 	rlc	a
      003E1B 12 3A FD         [24]  249 	lcall	_ak820_outline_0120
      003E1E 12 45 AF         [24]  250 	lcall	_ak820_outline_0079
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003E21 A3               [24]  252 	inc	dptr
      003E22 A2 0A            [12]  253 	mov	c,_page_valid
      003E24 E4               [12]  254 	clr	a
      003E25 33               [12]  255 	rlc	a
      003E26 12 45 7C         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E29 A2 0B            [12]  258 	mov	c,_page_dirty
      003E2B E4               [12]  259 	clr	a
      003E2C 33               [12]  260 	rlc	a
      003E2D F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E2E 74 03            [12]  263 	mov	a,#0x03
      003E30 12 45 EE         [24]  264 	lcall	_ak820_outline_0167
      003E33 90 05 6E         [24]  265 	mov	dptr,#_batch_depth
      003E36 E0               [24]  266 	movx	a,@dptr
      003E37 12 3B 08         [24]  267 	lcall	_ak820_outline_0126
      003E3A F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E3B 74 04            [12]  270 	mov	a,#0x04
      003E3D 12 45 EE         [24]  271 	lcall	_ak820_outline_0167
      003E40 90 05 6D         [24]  272 	mov	dptr,#_cached_page
      003E43 E0               [24]  273 	movx	a,@dptr
      003E44 12 3B 08         [24]  274 	lcall	_ak820_outline_0126
      003E47 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E48 12 45 72         [24]  277 	lcall	_ak820_outline_0011
      003E4B E4               [12]  278 	clr	a
      003E4C F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E4D 74 06            [12]  281 	mov	a,#0x06
      003E4F 12 45 D2         [24]  282 	lcall	_ak820_outline_0139
      003E52 90 05 6F         [24]  283 	mov	dptr,#_first_failure_stage
      003E55 E0               [24]  284 	movx	a,@dptr
      003E56 12 3A FD         [24]  285 	lcall	_ak820_outline_0120
      003E59 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E5A 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E5B                        300 _crc_byte:
      003E5B 12 3A F3         [24]  301 	lcall	_ak820_outline_0110
      003E5E 90 05 74         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E61 12 3A F8         [24]  303 	lcall	_ak820_outline_0111
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E64 90 05 73         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E67 E0               [24]  306 	movx	a,@dptr
      003E68 FF               [12]  307 	mov	r7,a
      003E69 7E 00            [12]  308 	mov	r6,#0x00
      003E6B 90 05 74         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E6E E0               [24]  310 	movx	a,@dptr
      003E6F 6E               [12]  311 	xrl	a,r6
      003E70 F0               [24]  312 	movx	@dptr,a
      003E71 A3               [24]  313 	inc	dptr
      003E72 E0               [24]  314 	movx	a,@dptr
      003E73 6F               [12]  315 	xrl	a,r7
      003E74 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E75 7F 00            [12]  318 	mov	r7,#0x00
      003E77                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E77 90 05 74         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E7A 12 3A D5         [24]  322 	lcall	_ak820_outline_0080
      003E7D 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E80 ED               [12]  324 	mov	a,r5
      003E81 2D               [12]  325 	add	a,r5
      003E82 FB               [12]  326 	mov	r3,a
      003E83 EE               [12]  327 	mov	a,r6
      003E84 33               [12]  328 	rlc	a
      003E85 FC               [12]  329 	mov	r4,a
      003E86 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E89 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E8C 80 06            [24]  332 	sjmp	00107$
      003E8E                        333 00106$:
      003E8E ED               [12]  334 	mov	a,r5
      003E8F 2D               [12]  335 	add	a,r5
      003E90 FB               [12]  336 	mov	r3,a
      003E91 EE               [12]  337 	mov	a,r6
      003E92 33               [12]  338 	rlc	a
      003E93 FC               [12]  339 	mov	r4,a
      003E94                        340 00107$:
      003E94 90 05 74         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E97 12 3A DB         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E9A 0F               [12]  344 	inc	r7
      003E9B BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E9E 12 36 78         [24]  347 	lcall	_ak820_outline_0125
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003EA1 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003EA2                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003EA2 90 05 76         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003EA5 74 FF            [12]  363 	mov	a,#0xff
      003EA7 F0               [24]  364 	movx	@dptr,a
      003EA8 A3               [24]  365 	inc	dptr
      003EA9 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003EAA 7F 00            [12]  368 	mov	r7,#0x00
      003EAC                        369 00102$:
      003EAC 90 05 76         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003EAF 12 3A D5         [24]  371 	lcall	_ak820_outline_0080
      003EB2 12 45 C1         [24]  372 	lcall	_ak820_outline_0108
      003EB5 90 05 73         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003EB8 F0               [24]  374 	movx	@dptr,a
      003EB9 12 3B 12         [24]  375 	lcall	_ak820_outline_0137
      003EBC C0 07            [24]  376 	push	ar7
      003EBE 12 3E 5B         [24]  377 	lcall	_crc_byte
      003EC1 AD 82            [24]  378 	mov	r5, dpl
      003EC3 AE 83            [24]  379 	mov	r6, dph
      003EC5 D0 07            [24]  380 	pop	ar7
      003EC7 90 05 76         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003ECA 12 45 D8         [24]  382 	lcall	_ak820_outline_0141
      003ECD 0F               [12]  383 	inc	r7
      003ECE BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003ED1 12 3B 12         [24]  386 	lcall	_ak820_outline_0137
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003ED4 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003ED5                        399 _write_page:
      003ED5 12 3A F3         [24]  400 	lcall	_ak820_outline_0110
      003ED8 90 05 78         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003EDB 12 3A F8         [24]  402 	lcall	_ak820_outline_0111
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EDE 90 05 78         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EE1 12 3A 65         [24]  405 	lcall	_ak820_outline_0005
      003EE4 C0 07            [24]  406 	push	ar7
      003EE6 C0 06            [24]  407 	push	ar6
      003EE8 12 3C 6D         [24]  408 	lcall	_ak820_flash_erase
      003EEB E5 82            [12]  409 	mov	a, dpl
      003EED D0 06            [24]  410 	pop	ar6
      003EEF D0 07            [24]  411 	pop	ar7
      003EF1 70 03            [24]  412 	jnz	00102$
      003EF3 F5 82            [12]  413 	mov	dpl,a
      003EF5 22               [24]  414 	ret
      003EF6                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003EF6 90 05 09         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003EF9 74 2D            [12]  418 	mov	a,#_page_data
      003EFB F0               [24]  419 	movx	@dptr,a
      003EFC 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003EFE A3               [24]  421 	inc	dptr
      003EFF 12 45 AF         [24]  422 	lcall	_ak820_outline_0079
      003F02 12 3D 81         [24]  423 	lcall	_ak820_flash_program_page
      003F05 E5 82            [12]  424 	mov	a, dpl
      003F07 70 03            [24]  425 	jnz	00120$
      003F09 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F0B 22               [24]  428 	ret
      003F0C                        429 00120$:
      003F0C 7F 00            [12]  430 	mov	r7,#0x00
      003F0E                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003F0E 8F 05            [24]  433 	mov	ar5,r7
      003F10 7E 00            [12]  434 	mov	r6,#0x00
      003F12 90 05 78         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003F15 12 3B 02         [24]  436 	lcall	_ak820_outline_0124
      003F18 ED               [12]  437 	mov	a,r5
      003F19 2B               [12]  438 	add	a, r3
      003F1A FB               [12]  439 	mov	r3,a
      003F1B EE               [12]  440 	mov	a,r6
      003F1C 3C               [12]  441 	addc	a, r4
      003F1D FC               [12]  442 	mov	r4,a
      003F1E 12 36 78         [24]  443 	lcall	_ak820_outline_0125
      003F21 12 3B 60         [24]  444 	lcall	_ak820_flash_read
      003F24 AE 82            [24]  445 	mov	r6, dpl
      003F26 12 45 C1         [24]  446 	lcall	_ak820_outline_0108
      003F29 FD               [12]  447 	mov	r5,a
      003F2A EE               [12]  448 	mov	a,r6
      003F2B B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F2E 80 04            [24]  450 	sjmp	00109$
      003F30                        451 00149$:
      003F30 75 82 00         [24]  452 	mov	dpl, #0x00
      003F33 22               [24]  453 	ret
      003F34                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F34 0F               [12]  456 	inc	r7
      003F35 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F38 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F3B 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F3C                        472 _journal_header_valid:
      003F3C 12 3A F3         [24]  473 	lcall	_ak820_outline_0110
      003F3F 90 05 7A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F42 12 3A F8         [24]  475 	lcall	_ak820_outline_0111
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F45 90 05 7A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F48 12 3A 65         [24]  478 	lcall	_ak820_outline_0005
      003F4B E0               [24]  479 	movx	a,@dptr
      003F4C FD               [12]  480 	mov	r5,a
      003F4D BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F50 80 04            [24]  482 	sjmp	00116$
      003F52                        483 00138$:
      003F52 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F55 22               [24]  486 	ret
      003F56                        487 00116$:
      003F56 7D 01            [12]  488 	mov	r5,#0x01
      003F58                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F58 ED               [12]  491 	mov	a,r5
      003F59 12 3A A2         [24]  492 	lcall	_ak820_outline_0022
      003F5C E0               [24]  493 	movx	a,@dptr
      003F5D FC               [12]  494 	mov	r4,a
      003F5E 8D 02            [24]  495 	mov	ar2,r5
      003F60 7B 00            [12]  496 	mov	r3,#0x00
      003F62 74 04            [12]  497 	mov	a,#0x04
      003F64 2A               [12]  498 	add	a, r2
      003F65 FA               [12]  499 	mov	r2,a
      003F66 E4               [12]  500 	clr	a
      003F67 3B               [12]  501 	addc	a, r3
      003F68 FB               [12]  502 	mov	r3,a
      003F69 EA               [12]  503 	mov	a,r2
      003F6A 2E               [12]  504 	add	a, r6
      003F6B F5 82            [12]  505 	mov	dpl,a
      003F6D EB               [12]  506 	mov	a,r3
      003F6E 3F               [12]  507 	addc	a, r7
      003F6F F5 83            [12]  508 	mov	dph,a
      003F71 E0               [24]  509 	movx	a,@dptr
      003F72 62 04            [12]  510 	xrl	ar4,a
      003F74 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003F77 80 04            [24]  512 	sjmp	00107$
      003F79                        513 00139$:
      003F79 75 82 00         [24]  514 	mov	dpl, #0x00
      003F7C 22               [24]  515 	ret
      003F7D                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F7D 0D               [12]  518 	inc	r5
      003F7E BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F81 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F84 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003F85                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F85 7F 00            [12]  538 	mov	r7,#0x00
      003F87                        539 00115$:
      003F87 EF               [12]  540 	mov	a,r7
      003F88 24 7C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003F8A FD               [12]  542 	mov	r5,a
      003F8B E4               [12]  543 	clr	a
      003F8C 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F8E FE               [12]  545 	mov	r6,a
      003F8F 8F 04            [24]  546 	mov	ar4,r7
      003F91 7B 00            [12]  547 	mov	r3,#0x00
      003F93 74 40            [12]  548 	mov	a,#0x40
      003F95 2C               [12]  549 	add	a, r4
      003F96 FC               [12]  550 	mov	r4,a
      003F97 74 EF            [12]  551 	mov	a,#0xef
      003F99 3B               [12]  552 	addc	a, r3
      003F9A FB               [12]  553 	mov	r3,a
      003F9B 12 45 F9         [24]  554 	lcall	_ak820_outline_0186
      003F9E 12 3B 60         [24]  555 	lcall	_ak820_flash_read
      003FA1 AC 82            [24]  556 	mov	r4, dpl
      003FA3 12 45 A8         [24]  557 	lcall	_ak820_outline_0065
      003FA6 0F               [12]  558 	inc	r7
      003FA7 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003FAA 90 05 7C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003FAD 12 3F 3C         [24]  562 	lcall	_journal_header_valid
      003FB0 E5 82            [12]  563 	mov	a, dpl
      003FB2 70 01            [24]  564 	jnz	00103$
      003FB4 22               [24]  565 	ret
      003FB5                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003FB5 90 05 7D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003FB8 E0               [24]  569 	movx	a,@dptr
      003FB9 FF               [12]  570 	mov	r7,a
      003FBA 7E 00            [12]  571 	mov	r6,#0x00
      003FBC 90 05 7E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003FBF E0               [24]  573 	movx	a,@dptr
      003FC0 FC               [12]  574 	mov	r4,a
      003FC1 E4               [12]  575 	clr	a
      003FC2 42 07            [12]  576 	orl	ar7,a
      003FC4 EC               [12]  577 	mov	a,r4
      003FC5 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FC7 90 05 7F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FCA E0               [24]  581 	movx	a,@dptr
      003FCB FD               [12]  582 	mov	r5,a
      003FCC 7C 00            [12]  583 	mov	r4,#0x00
      003FCE 90 05 80         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FD1 E0               [24]  585 	movx	a,@dptr
      003FD2 FA               [12]  586 	mov	r2,a
      003FD3 E4               [12]  587 	clr	a
      003FD4 12 45 DE         [24]  588 	lcall	_ak820_outline_0147
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FD7 C3               [12]  590 	clr	c
      003FD8 EF               [12]  591 	mov	a,r7
      003FD9 94 A0            [12]  592 	subb	a,#0xa0
      003FDB EE               [12]  593 	mov	a,r6
      003FDC 94 00            [12]  594 	subb	a,#0x00
      003FDE 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FE0 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FE3 02 3D F4         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FE6                        601 00134$:
      003FE6 7B 00            [12]  602 	mov	r3,#0x00
      003FE8                        603 00117$:
      003FE8 C0 05            [24]  604 	push	ar5
      003FEA C0 04            [24]  605 	push	ar4
      003FEC EB               [12]  606 	mov	a,r3
      003FED 24 2D            [12]  607 	add	a, #_page_data
      003FEF F9               [12]  608 	mov	r1,a
      003FF0 E4               [12]  609 	clr	a
      003FF1 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003FF3 FA               [12]  611 	mov	r2,a
      003FF4 8B 00            [24]  612 	mov	ar0,r3
      003FF6 7D 00            [12]  613 	mov	r5,#0x00
      003FF8 74 EF            [12]  614 	mov	a,#0xef
      003FFA 2D               [12]  615 	add	a, r5
      003FFB FD               [12]  616 	mov	r5,a
      003FFC 88 82            [24]  617 	mov	dpl, r0
      003FFE 8D 83            [24]  618 	mov	dph, r5
      004000 12 3B 60         [24]  619 	lcall	_ak820_flash_read
      004003 AD 82            [24]  620 	mov	r5, dpl
      004005 12 45 F4         [24]  621 	lcall	_ak820_outline_0185
      004008 ED               [12]  622 	mov	a,r5
      004009 F0               [24]  623 	movx	@dptr,a
      00400A 0B               [12]  624 	inc	r3
      00400B BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      00400E 80 06            [24]  626 	sjmp	00191$
      004010                        627 00190$:
      004010 D0 04            [24]  628 	pop	ar4
      004012 D0 05            [24]  629 	pop	ar5
      004014 80 D2            [24]  630 	sjmp	00117$
      004016                        631 00191$:
      004016 D0 04            [24]  632 	pop	ar4
      004018 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      00401A C0 07            [24]  635 	push	ar7
      00401C C0 06            [24]  636 	push	ar6
      00401E C0 05            [24]  637 	push	ar5
      004020 C0 04            [24]  638 	push	ar4
      004022 12 3E A2         [24]  639 	lcall	_page_crc
      004025 AA 82            [24]  640 	mov	r2, dpl
      004027 AB 83            [24]  641 	mov	r3, dph
      004029 D0 04            [24]  642 	pop	ar4
      00402B D0 05            [24]  643 	pop	ar5
      00402D D0 06            [24]  644 	pop	ar6
      00402F D0 07            [24]  645 	pop	ar7
      004031 EA               [12]  646 	mov	a,r2
      004032 B5 05 06         [24]  647 	cjne	a,ar5,00192$
      004035 EB               [12]  648 	mov	a,r3
      004036 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004039 80 06            [24]  650 	sjmp	00113$
      00403B                        651 00192$:
      00403B 75 82 02         [24]  652 	mov	dpl, #0x02
      00403E 02 3D F4         [24]  653 	ljmp	_nvm_fail
      004041                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      004041 EE               [12]  656 	mov	a,r6
      004042 54 03            [12]  657 	anl	a,#0x03
      004044 A2 E0            [12]  658 	mov	c,acc.0
      004046 CF               [12]  659 	xch	a,r7
      004047 13               [12]  660 	rrc	a
      004048 CF               [12]  661 	xch	a,r7
      004049 13               [12]  662 	rrc	a
      00404A A2 E0            [12]  663 	mov	c,acc.0
      00404C CF               [12]  664 	xch	a,r7
      00404D 13               [12]  665 	rrc	a
      00404E CF               [12]  666 	xch	a,r7
      00404F 13               [12]  667 	rrc	a
      004050 CF               [12]  668 	xch	a,r7
      004051 24 C7            [12]  669 	add	a,#0xc7
      004053 FE               [12]  670 	mov	r6,a
      004054 12 45 E9         [24]  671 	lcall	_ak820_outline_0165
      004057 12 3E D5         [24]  672 	lcall	_write_page
      00405A E5 82            [12]  673 	mov	a, dpl
      00405C 70 06            [24]  674 	jnz	00110$
      00405E 75 82 03         [24]  675 	mov	dpl, #0x03
      004061 02 3D F4         [24]  676 	ljmp	_nvm_fail
      004064                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004064 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004067 12 3C 6D         [24]  680 	lcall	_ak820_flash_erase
      00406A E5 82            [12]  681 	mov	a, dpl
      00406C 70 06            [24]  682 	jnz	00119$
      00406E 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004071 02 3D F4         [24]  685 	ljmp	_nvm_fail
      004074                        686 00119$:
      004074 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      004075                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      004075 C2 0C            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004077 90 05 6F         [24]  700 	mov	dptr,#_first_failure_stage
      00407A E4               [12]  701 	clr	a
      00407B F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      00407C C2 0B            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      00407E C2 0A            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004080 90 05 6E         [24]  709 	mov	dptr,#_batch_depth
      004083 E4               [12]  710 	clr	a
      004084 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004085 12 3F 85         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004088 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      00408B                        724 _ak820_nvm_ok:
      00408B A2 0C            [12]  725 	mov	c,_storage_failed
      00408D B3               [12]  726 	cpl	c
      00408E 92 0D            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004090 12 3B 22         [24]  728 	lcall	_ak820_outline_0163
      004093 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      004094                        737 _ak820_nvm_schema_fault:
      004094 75 82 10         [24]  738 	mov	dpl, #0x10
      004097 02 3D F4         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      00409A                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00409A 30 0B 03         [24]  754 	jnb	_page_dirty,00101$
      00409D 30 0C 01         [24]  755 	jnb	_storage_failed,00102$
      0040A0                        756 00101$:
      0040A0 22               [24]  757 	ret
      0040A1                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0040A1 12 3E A2         [24]  760 	lcall	_page_crc
      0040A4 12 45 CD         [24]  761 	lcall	_ak820_outline_0127
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0040A7 90 05 85         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0040AA 74 A5            [12]  764 	mov	a,#0xa5
      0040AC F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0040AD 90 05 6D         [24]  767 	mov	dptr,#_cached_page
      0040B0 E0               [24]  768 	movx	a,@dptr
      0040B1 90 05 86         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0040B4 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0040B5 90 05 87         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0040B8 E4               [12]  773 	clr	a
      0040B9 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0040BA 8E 05            [24]  776 	mov	ar5,r6
      0040BC 90 05 88         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0040BF ED               [12]  778 	mov	a,r5
      0040C0 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0040C1 8F 06            [24]  781 	mov	ar6,r7
      0040C3 90 05 89         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040C6 EE               [12]  783 	mov	a,r6
      0040C7 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040C8 7F 01            [12]  786 	mov	r7,#0x01
      0040CA                        787 00128$:
      0040CA 8F 06            [24]  788 	mov	ar6,r7
      0040CC EE               [12]  789 	mov	a,r6
      0040CD 24 04            [12]  790 	add	a,#0x04
      0040CF FE               [12]  791 	mov	r6,a
      0040D0 33               [12]  792 	rlc	a
      0040D1 95 E0            [12]  793 	subb	a,acc
      0040D3 FD               [12]  794 	mov	r5,a
      0040D4 EE               [12]  795 	mov	a,r6
      0040D5 24 85            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0040D7 FE               [12]  797 	mov	r6,a
      0040D8 ED               [12]  798 	mov	a,r5
      0040D9 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040DB FD               [12]  800 	mov	r5,a
      0040DC 12 45 8B         [24]  801 	lcall	_ak820_outline_0043
      0040DF FC               [12]  802 	mov	r4,a
      0040E0 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0040E3 8E 82            [24]  804 	mov	dpl,r6
      0040E5 8D 83            [24]  805 	mov	dph,r5
      0040E7 EC               [12]  806 	mov	a,r4
      0040E8 F0               [24]  807 	movx	@dptr,a
      0040E9 0F               [12]  808 	inc	r7
      0040EA BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040ED 90 05 8E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040F0 74 05            [12]  812 	mov	a,#0x05
      0040F2 F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040F3 90 EF 40         [24]  815 	mov	dptr,#0xef40
      0040F6 12 3C 6D         [24]  816 	lcall	_ak820_flash_erase
      0040F9 E5 82            [12]  817 	mov	a, dpl
      0040FB 70 03            [24]  818 	jnz	00269$
      0040FD 02 41 E4         [24]  819 	ljmp	00127$
      004100                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004100 90 05 8E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004103 74 06            [12]  823 	mov	a,#0x06
      004105 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004106 7F 00            [12]  826 	mov	r7,#0x00
      004108                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004108 12 45 97         [24]  829 	lcall	_ak820_outline_0053
      00410B 12 3B 60         [24]  830 	lcall	_ak820_flash_read
      00410E E5 82            [12]  831 	mov	a, dpl
      004110 60 03            [24]  832 	jz	00270$
      004112 02 41 E4         [24]  833 	ljmp	00127$
      004115                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004115 0F               [12]  836 	inc	r7
      004116 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      004119 90 05 8E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00411C 74 07            [12]  840 	mov	a,#0x07
      00411E F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      00411F 90 EF 00         [24]  843 	mov	dptr,#0xef00
      004122 12 3E D5         [24]  844 	lcall	_write_page
      004125 E5 82            [12]  845 	mov	a, dpl
      004127 70 03            [24]  846 	jnz	00273$
      004129 02 41 E4         [24]  847 	ljmp	00127$
      00412C                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      00412C 90 05 8E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00412F 74 08            [12]  851 	mov	a,#0x08
      004131 F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004132 7F 01            [12]  854 	mov	r7,#0x01
      004134                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004134 12 45 8B         [24]  857 	lcall	_ak820_outline_0043
      004137 FE               [12]  858 	mov	r6,a
      004138 60 23            [24]  859 	jz	00133$
      00413A 8F 05            [24]  860 	mov	ar5,r7
      00413C 7C 00            [12]  861 	mov	r4,#0x00
      00413E 74 40            [12]  862 	mov	a,#0x40
      004140 2D               [12]  863 	add	a, r5
      004141 FD               [12]  864 	mov	r5,a
      004142 74 EF            [12]  865 	mov	a,#0xef
      004144 3C               [12]  866 	addc	a, r4
      004145 FC               [12]  867 	mov	r4,a
      004146 90 05 06         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004149 EE               [12]  869 	mov	a,r6
      00414A F0               [24]  870 	movx	@dptr,a
      00414B 8D 82            [24]  871 	mov	dpl, r5
      00414D 8C 83            [24]  872 	mov	dph, r4
      00414F C0 07            [24]  873 	push	ar7
      004151 12 3C CD         [24]  874 	lcall	_ak820_flash_program
      004154 E5 82            [12]  875 	mov	a, dpl
      004156 D0 07            [24]  876 	pop	ar7
      004158 70 03            [24]  877 	jnz	00275$
      00415A 02 41 E4         [24]  878 	ljmp	00127$
      00415D                        879 00275$:
      00415D                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00415D 0F               [12]  882 	inc	r7
      00415E BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      004161 90 05 8E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004164 74 09            [12]  886 	mov	a,#0x09
      004166 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004167 7F 01            [12]  889 	mov	r7,#0x01
      004169                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004169 12 45 97         [24]  892 	lcall	_ak820_outline_0053
      00416C 12 3B 60         [24]  893 	lcall	_ak820_flash_read
      00416F AE 82            [24]  894 	mov	r6, dpl
      004171 12 45 8B         [24]  895 	lcall	_ak820_outline_0043
      004174 FD               [12]  896 	mov	r5,a
      004175 EE               [12]  897 	mov	a,r6
      004176 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004179 0F               [12]  900 	inc	r7
      00417A BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      00417D 90 05 8E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004180 74 0A            [12]  904 	mov	a,#0x0a
      004182 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004183 90 05 85         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004186 E0               [24]  908 	movx	a,@dptr
      004187 90 05 06         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      00418A F0               [24]  910 	movx	@dptr,a
      00418B 90 EF 40         [24]  911 	mov	dptr,#0xef40
      00418E 12 3C CD         [24]  912 	lcall	_ak820_flash_program
      004191 E5 82            [12]  913 	mov	a, dpl
      004193 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004195 90 05 8E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004198 74 0B            [12]  917 	mov	a,#0x0b
      00419A F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      00419B 90 EF 40         [24]  920 	mov	dptr,#0xef40
      00419E 12 3B 60         [24]  921 	lcall	_ak820_flash_read
      0041A1 AF 82            [24]  922 	mov	r7, dpl
      0041A3 90 05 85         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0041A6 E0               [24]  924 	movx	a,@dptr
      0041A7 FE               [12]  925 	mov	r6,a
      0041A8 EF               [12]  926 	mov	a,r7
      0041A9 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0041AC 90 05 8E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041AF 74 0C            [12]  930 	mov	a,#0x0c
      0041B1 F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0041B2 90 05 6D         [24]  933 	mov	dptr,#_cached_page
      0041B5 E0               [24]  934 	movx	a,@dptr
      0041B6 FE               [12]  935 	mov	r6,a
      0041B7 E4               [12]  936 	clr	a
      0041B8 C3               [12]  937 	clr	c
      0041B9 CE               [12]  938 	xch	a,r6
      0041BA 13               [12]  939 	rrc	a
      0041BB CE               [12]  940 	xch	a,r6
      0041BC 13               [12]  941 	rrc	a
      0041BD A2 E0            [12]  942 	mov	c,acc.0
      0041BF CE               [12]  943 	xch	a,r6
      0041C0 13               [12]  944 	rrc	a
      0041C1 CE               [12]  945 	xch	a,r6
      0041C2 13               [12]  946 	rrc	a
      0041C3 CE               [12]  947 	xch	a,r6
      0041C4 24 C7            [12]  948 	add	a,#0xc7
      0041C6 FF               [12]  949 	mov	r7,a
      0041C7 12 3A FD         [24]  950 	lcall	_ak820_outline_0120
      0041CA 12 3E D5         [24]  951 	lcall	_write_page
      0041CD E5 82            [12]  952 	mov	a, dpl
      0041CF 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041D1 90 05 8E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041D4 74 0D            [12]  956 	mov	a,#0x0d
      0041D6 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041D7 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0041DA 12 3C 6D         [24]  960 	lcall	_ak820_flash_erase
      0041DD E5 82            [12]  961 	mov	a, dpl
      0041DF 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0041E1 C2 0B            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041E3 22               [24]  968 	ret
      0041E4                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041E4 90 05 8E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041E7 E0               [24]  972 	movx	a,@dptr
      0041E8 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041EA 02 3D F4         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0041ED                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041ED 90 05 6E         [24]  985 	mov	dptr,#_batch_depth
      0041F0 E0               [24]  986 	movx	a,@dptr
      0041F1 FF               [12]  987 	mov	r7,a
      0041F2 BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      0041F5 75 82 0F         [24]  989 	mov	dpl, #0x0f
      0041F8 02 3D F4         [24]  990 	ljmp	_nvm_fail
      0041FB                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0041FB 90 05 6E         [24]  993 	mov	dptr,#_batch_depth
      0041FE EF               [12]  994 	mov	a,r7
      0041FF 04               [12]  995 	inc	a
      004200 F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004201 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      004202                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004202 90 05 6E         [24] 1008 	mov	dptr,#_batch_depth
      004205 E0               [24] 1009 	movx	a,@dptr
      004206 FF               [12] 1010 	mov	r7,a
      004207 E0               [24] 1011 	movx	a,@dptr
      004208 60 06            [24] 1012 	jz	00102$
      00420A EF               [12] 1013 	mov	a,r7
      00420B 14               [12] 1014 	dec	a
      00420C 90 05 6E         [24] 1015 	mov	dptr,#_batch_depth
      00420F F0               [24] 1016 	movx	@dptr,a
      004210                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004210 90 05 6E         [24] 1019 	mov	dptr,#_batch_depth
      004213 E0               [24] 1020 	movx	a,@dptr
      004214 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004216 02 40 9A         [24] 1023 	ljmp	_ak820_nvm_flush
      004219                       1024 00105$:
      004219 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      00421A                       1036 _load_page:
      00421A E5 82            [12] 1037 	mov	a,dpl
      00421C 90 05 8F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      00421F F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004220 30 0A 17         [24] 1041 	jnb	_page_valid,00102$
      004223 90 05 6D         [24] 1042 	mov	dptr,#_cached_page
      004226 E0               [24] 1043 	movx	a,@dptr
      004227 FF               [12] 1044 	mov	r7,a
      004228 90 05 8F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      00422B E0               [24] 1046 	movx	a,@dptr
      00422C FE               [12] 1047 	mov	r6,a
      00422D EF               [12] 1048 	mov	a,r7
      00422E B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      004231 A2 0C            [12] 1050 	mov	c,_storage_failed
      004233 B3               [12] 1051 	cpl	c
      004234 92 0E            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004236 12 3B 22         [24] 1053 	lcall	_ak820_outline_0163
      004239 22               [24] 1054 	ret
      00423A                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      00423A 12 40 9A         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      00423D 30 0C 04         [24] 1059 	jnb	_storage_failed,00119$
      004240 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004243 22               [24] 1062 	ret
      004244                       1063 00119$:
      004244 7F 00            [12] 1064 	mov	r7,#0x00
      004246                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004246 EF               [12] 1067 	mov	a,r7
      004247 24 2D            [12] 1068 	add	a, #_page_data
      004249 FD               [12] 1069 	mov	r5,a
      00424A E4               [12] 1070 	clr	a
      00424B 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      00424D FE               [12] 1072 	mov	r6,a
      00424E 90 05 8F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      004251 E0               [24] 1074 	movx	a,@dptr
      004252 FC               [12] 1075 	mov	r4,a
      004253 FA               [12] 1076 	mov	r2,a
      004254 E4               [12] 1077 	clr	a
      004255 C3               [12] 1078 	clr	c
      004256 CA               [12] 1079 	xch	a,r2
      004257 13               [12] 1080 	rrc	a
      004258 CA               [12] 1081 	xch	a,r2
      004259 13               [12] 1082 	rrc	a
      00425A A2 E0            [12] 1083 	mov	c,acc.0
      00425C CA               [12] 1084 	xch	a,r2
      00425D 13               [12] 1085 	rrc	a
      00425E CA               [12] 1086 	xch	a,r2
      00425F 13               [12] 1087 	rrc	a
      004260 CA               [12] 1088 	xch	a,r2
      004261 24 C7            [12] 1089 	add	a,#0xc7
      004263 FB               [12] 1090 	mov	r3,a
      004264 8F 01            [24] 1091 	mov	ar1,r7
      004266 89 00            [24] 1092 	mov	ar0,r1
      004268 79 00            [12] 1093 	mov	r1,#0x00
      00426A E8               [12] 1094 	mov	a,r0
      00426B 2A               [12] 1095 	add	a, r2
      00426C FA               [12] 1096 	mov	r2,a
      00426D E9               [12] 1097 	mov	a,r1
      00426E 3B               [12] 1098 	addc	a, r3
      00426F FB               [12] 1099 	mov	r3,a
      004270 12 3B 1D         [24] 1100 	lcall	_ak820_outline_0148
      004273 12 3B 60         [24] 1101 	lcall	_ak820_flash_read
      004276 AB 82            [24] 1102 	mov	r3, dpl
      004278 12 3B 12         [24] 1103 	lcall	_ak820_outline_0137
      00427B EB               [12] 1104 	mov	a,r3
      00427C F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00427D 0F               [12] 1107 	inc	r7
      00427E BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004281 90 05 6D         [24] 1110 	mov	dptr,#_cached_page
      004284 EC               [12] 1111 	mov	a,r4
      004285 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004286 D2 0A            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004288 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      00428B 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      00428C                       1129 _read_offset:
      00428C 12 3A F3         [24] 1130 	lcall	_ak820_outline_0110
      00428F 90 05 90         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      004292 12 3A F8         [24] 1132 	lcall	_ak820_outline_0111
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004295 90 05 90         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004298 12 3A B2         [24] 1135 	lcall	_ak820_outline_0052
      00429B C3               [12] 1136 	clr	c
      00429C 94 28            [12] 1137 	subb	a,#0x28
      00429E 40 04            [24] 1138 	jc	00102$
      0042A0 75 82 00         [24] 1139 	mov	dpl, #0x00
      0042A3 22               [24] 1140 	ret
      0042A4                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0042A4 30 0A 34         [24] 1143 	jnb	_page_valid,00104$
      0042A7 8E 04            [24] 1144 	mov	ar4,r6
      0042A9 EF               [12] 1145 	mov	a,r7
      0042AA A2 E7            [12] 1146 	mov	c,acc.7
      0042AC CC               [12] 1147 	xch	a,r4
      0042AD 33               [12] 1148 	rlc	a
      0042AE CC               [12] 1149 	xch	a,r4
      0042AF 33               [12] 1150 	rlc	a
      0042B0 A2 E7            [12] 1151 	mov	c,acc.7
      0042B2 CC               [12] 1152 	xch	a,r4
      0042B3 33               [12] 1153 	rlc	a
      0042B4 CC               [12] 1154 	xch	a,r4
      0042B5 33               [12] 1155 	rlc	a
      0042B6 CC               [12] 1156 	xch	a,r4
      0042B7 54 03            [12] 1157 	anl	a,#0x03
      0042B9 FD               [12] 1158 	mov	r5,a
      0042BA 90 05 6D         [24] 1159 	mov	dptr,#_cached_page
      0042BD E0               [24] 1160 	movx	a,@dptr
      0042BE FA               [12] 1161 	mov	r2,a
      0042BF 7B 00            [12] 1162 	mov	r3,#0x00
      0042C1 EC               [12] 1163 	mov	a,r4
      0042C2 B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0042C5 ED               [12] 1165 	mov	a,r5
      0042C6 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042C9 74 3F            [12] 1168 	mov	a,#0x3f
      0042CB 5E               [12] 1169 	anl	a,r6
      0042CC 7D 00            [12] 1170 	mov	r5,#0x00
      0042CE 24 2D            [12] 1171 	add	a, #_page_data
      0042D0 F5 82            [12] 1172 	mov	dpl,a
      0042D2 ED               [12] 1173 	mov	a,r5
      0042D3 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0042D5 F5 83            [12] 1175 	mov	dph,a
      0042D7 E0               [24] 1176 	movx	a,@dptr
      0042D8 F5 82            [12] 1177 	mov	dpl,a
      0042DA 22               [24] 1178 	ret
      0042DB                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042DB 74 C7            [12] 1181 	mov	a,#0xc7
      0042DD 2F               [12] 1182 	add	a, r7
      0042DE FF               [12] 1183 	mov	r7,a
      0042DF 12 3A FD         [24] 1184 	lcall	_ak820_outline_0120
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042E2 02 3B 60         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0042E5                       1196 _eeprom_read_byte:
      0042E5 C0 07            [24] 1197 	push	ar7
      0042E7 C0 06            [24] 1198 	push	ar6
      0042E9 12 45 84         [24] 1199 	lcall	_ak820_outline_0036
      0042EC 90 05 92         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042EF 12 3A 90         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042F2 90 05 92         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F5 12 3A 65         [24] 1204 	lcall	_ak820_outline_0005
      0042F8 C0 06            [24] 1205 	push	ar6
      0042FA C0 05            [24] 1206 	push	ar5
      0042FC C0 04            [24] 1207 	push	ar4
      0042FE C0 03            [24] 1208 	push	ar3
      004300 C0 02            [24] 1209 	push	ar2
      004302 C0 01            [24] 1210 	push	ar1
      004304 C0 00            [24] 1211 	push	ar0
      004306 12 42 8C         [24] 1212 	lcall	_read_offset
      004309 AF 82            [24] 1213 	mov	r7, dpl
      00430B D0 00            [24] 1214 	pop	ar0
      00430D D0 01            [24] 1215 	pop	ar1
      00430F D0 02            [24] 1216 	pop	ar2
      004311 D0 03            [24] 1217 	pop	ar3
      004313 D0 04            [24] 1218 	pop	ar4
      004315 D0 05            [24] 1219 	pop	ar5
      004317 D0 06            [24] 1220 	pop	ar6
      004319 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00431B D0 06            [24] 1223 	pop	ar6
      00431D D0 07            [24] 1224 	pop	ar7
      00431F 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      004320                       1239 _ak820_eeprom_read_block_xdata:
      004320 12 3A F3         [24] 1240 	lcall	_ak820_outline_0110
      004323 90 05 9A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004326 12 3A F8         [24] 1242 	lcall	_ak820_outline_0111
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004329 90 05 95         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00432C 12 3A B2         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00432F 90 05 9A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004332 12 3A C9         [24] 1248 	lcall	_ak820_outline_0061
      004335 90 05 9C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004338 12 3A CF         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00433B 90 05 98         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00433E 12 3A C9         [24] 1253 	lcall	_ak820_outline_0061
      004341                       1254 00103$:
      004341 8C 02            [24] 1255 	mov	ar2,r4
      004343 8D 03            [24] 1256 	mov	ar3,r5
      004345 1C               [12] 1257 	dec	r4
      004346 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004349 1D               [12] 1259 	dec	r5
      00434A                       1260 00130$:
      00434A EA               [12] 1261 	mov	a,r2
      00434B 4B               [12] 1262 	orl	a,r3
      00434C 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00434E 8E 02            [24] 1265 	mov	ar2,r6
      004350 8F 03            [24] 1266 	mov	ar3,r7
      004352 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004354 2B               [12] 1268 	add	a,r3
      004355 50 17            [24] 1269 	jnc	00102$
      004357 90 05 9C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00435A 12 45 BB         [24] 1271 	lcall	_ak820_outline_0106
      00435D 12 3B 1D         [24] 1272 	lcall	_ak820_outline_0148
      004360 E4               [12] 1273 	clr	a
      004361 F0               [24] 1274 	movx	@dptr,a
      004362 90 05 9C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004365 04               [12] 1276 	inc	a
      004366 2A               [12] 1277 	add	a, r2
      004367 F0               [24] 1278 	movx	@dptr,a
      004368 E4               [12] 1279 	clr	a
      004369 3B               [12] 1280 	addc	a, r3
      00436A A3               [24] 1281 	inc	dptr
      00436B F0               [24] 1282 	movx	@dptr,a
      00436C 80 D3            [24] 1283 	sjmp	00103$
      00436E                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00436E 90 05 9C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004371 12 45 BB         [24] 1287 	lcall	_ak820_outline_0106
      004374 12 3A FD         [24] 1288 	lcall	_ak820_outline_0120
      004377 C0 07            [24] 1289 	push	ar7
      004379 C0 06            [24] 1290 	push	ar6
      00437B C0 05            [24] 1291 	push	ar5
      00437D C0 04            [24] 1292 	push	ar4
      00437F C0 03            [24] 1293 	push	ar3
      004381 C0 02            [24] 1294 	push	ar2
      004383 12 42 8C         [24] 1295 	lcall	_read_offset
      004386 A9 82            [24] 1296 	mov	r1, dpl
      004388 D0 02            [24] 1297 	pop	ar2
      00438A D0 03            [24] 1298 	pop	ar3
      00438C D0 04            [24] 1299 	pop	ar4
      00438E D0 05            [24] 1300 	pop	ar5
      004390 D0 06            [24] 1301 	pop	ar6
      004392 D0 07            [24] 1302 	pop	ar7
      004394 12 3B 1D         [24] 1303 	lcall	_ak820_outline_0148
      004397 E9               [12] 1304 	mov	a,r1
      004398 F0               [24] 1305 	movx	@dptr,a
      004399 90 05 9C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00439C 74 01            [12] 1307 	mov	a,#0x01
      00439E 2A               [12] 1308 	add	a, r2
      00439F F0               [24] 1309 	movx	@dptr,a
      0043A0 E4               [12] 1310 	clr	a
      0043A1 3B               [12] 1311 	addc	a, r3
      0043A2 A3               [24] 1312 	inc	dptr
      0043A3 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0043A4 0E               [12] 1315 	inc	r6
      0043A5 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      0043A8 0F               [12] 1317 	inc	r7
      0043A9 80 96            [24] 1318 	sjmp	00103$
      0043AB                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0043AB 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      0043AC                       1337 _ak820_eeprom_write_block_xdata:
      0043AC 12 3A F3         [24] 1338 	lcall	_ak820_outline_0110
      0043AF 90 05 A3         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043B2 12 3A F8         [24] 1340 	lcall	_ak820_outline_0111
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043B5 90 05 9E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0043B8 12 3A B2         [24] 1343 	lcall	_ak820_outline_0052
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0043BB 90 05 A3         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043BE 12 3A C9         [24] 1346 	lcall	_ak820_outline_0061
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0043C1 8E 02            [24] 1348 	mov	ar2,r6
      0043C3 8F 03            [24] 1349 	mov	ar3,r7
      0043C5 C3               [12] 1350 	clr	c
      0043C6 E4               [12] 1351 	clr	a
      0043C7 9A               [12] 1352 	subb	a,r2
      0043C8 74 28            [12] 1353 	mov	a,#0x28
      0043CA 9B               [12] 1354 	subb	a,r3
      0043CB 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0043CD E4               [12] 1357 	clr	a
      0043CE C3               [12] 1358 	clr	c
      0043CF 9E               [12] 1359 	subb	a,r6
      0043D0 FA               [12] 1360 	mov	r2,a
      0043D1 74 28            [12] 1361 	mov	a,#0x28
      0043D3 9F               [12] 1362 	subb	a,r7
      0043D4 FB               [12] 1363 	mov	r3,a
      0043D5 90 05 A1         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043D8 12 3A ED         [24] 1365 	lcall	_ak820_outline_0105
      0043DB C3               [12] 1366 	clr	c
      0043DC EA               [12] 1367 	mov	a,r2
      0043DD 98               [12] 1368 	subb	a,r0
      0043DE EB               [12] 1369 	mov	a,r3
      0043DF 99               [12] 1370 	subb	a,r1
      0043E0 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0043E2                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043E2 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043E5 02 3D F4         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043E8                       1379 00125$:
      0043E8 90 05 A1         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043EB 12 45 BB         [24] 1381 	lcall	_ak820_outline_0106
      0043EE                       1382 00108$:
      0043EE 8A 00            [24] 1383 	mov	ar0,r2
      0043F0 8B 01            [24] 1384 	mov	ar1,r3
      0043F2 1A               [12] 1385 	dec	r2
      0043F3 BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      0043F6 1B               [12] 1387 	dec	r3
      0043F7                       1388 00159$:
      0043F7 E8               [12] 1389 	mov	a,r0
      0043F8 49               [12] 1390 	orl	a,r1
      0043F9 70 03            [24] 1391 	jnz	00160$
      0043FB 02 44 85         [24] 1392 	ljmp	00110$
      0043FE                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0043FE C0 02            [24] 1395 	push	ar2
      004400 C0 03            [24] 1396 	push	ar3
      004402 12 45 B5         [24] 1397 	lcall	_ak820_outline_0097
      004405 F9               [12] 1398 	mov	r1,a
      004406 A3               [24] 1399 	inc	dptr
      004407 12 45 E4         [24] 1400 	lcall	_ak820_outline_0155
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00440A 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00440C 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00440E A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004410 E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004412 A2 E7            [12] 1406 	mov	c,acc.7
      004414 C8               [12] 1407 	xch	a,r0
      004415 33               [12] 1408 	rlc	a
      004416 C8               [12] 1409 	xch	a,r0
      004417 33               [12] 1410 	rlc	a
      004418 A2 E7            [12] 1411 	mov	c,acc.7
      00441A C8               [12] 1412 	xch	a,r0
      00441B 33               [12] 1413 	rlc	a
      00441C C8               [12] 1414 	xch	a,r0
      00441D 33               [12] 1415 	rlc	a
      00441E C8               [12] 1416 	xch	a,r0
      00441F 54 03            [12] 1417 	anl	a,#0x03
      004421 FB               [12] 1418 	mov	r3,a
      004422 88 82            [24] 1419 	mov	dpl, r0
      004424 C0 07            [24] 1420 	push	ar7
      004426 C0 06            [24] 1421 	push	ar6
      004428 C0 05            [24] 1422 	push	ar5
      00442A C0 04            [24] 1423 	push	ar4
      00442C C0 03            [24] 1424 	push	ar3
      00442E C0 02            [24] 1425 	push	ar2
      004430 C0 01            [24] 1426 	push	ar1
      004432 12 42 1A         [24] 1427 	lcall	_load_page
      004435 E5 82            [12] 1428 	mov	a, dpl
      004437 D0 01            [24] 1429 	pop	ar1
      004439 D0 02            [24] 1430 	pop	ar2
      00443B D0 03            [24] 1431 	pop	ar3
      00443D D0 04            [24] 1432 	pop	ar4
      00443F D0 05            [24] 1433 	pop	ar5
      004441 D0 06            [24] 1434 	pop	ar6
      004443 D0 07            [24] 1435 	pop	ar7
      004445 D0 03            [24] 1436 	pop	ar3
      004447 D0 02            [24] 1437 	pop	ar2
      004449 70 01            [24] 1438 	jnz	00105$
      00444B 22               [24] 1439 	ret
      00444C                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00444C C0 06            [24] 1442 	push	ar6
      00444E C0 07            [24] 1443 	push	ar7
      004450 74 3F            [12] 1444 	mov	a,#0x3f
      004452 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004454 7F 00            [12] 1446 	mov	r7,#0x00
      004456 24 2D            [12] 1447 	add	a, #_page_data
      004458 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00445A EF               [12] 1449 	mov	a,r7
      00445B 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      00445D F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00445F 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004462 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004465 E0               [24] 1454 	movx	a,@dptr
      004466 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004469 D0 07            [24] 1456 	pop	ar7
      00446B D0 06            [24] 1457 	pop	ar6
      00446D 80 0E            [24] 1458 	sjmp	00107$
      00446F                       1459 00162$:
      00446F D0 07            [24] 1460 	pop	ar7
      004471 D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004473 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004476 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004479 E9               [12] 1465 	mov	a,r1
      00447A F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      00447B D2 0B            [12] 1469 	setb	_page_dirty
      00447D                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00447D 0E               [12] 1472 	inc	r6
      00447E BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      004481 0F               [12] 1474 	inc	r7
      004482                       1475 00163$:
      004482 02 43 EE         [24] 1476 	ljmp	00108$
      004485                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004485 90 05 6E         [24] 1479 	mov	dptr,#_batch_depth
      004488 E0               [24] 1480 	movx	a,@dptr
      004489 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      00448B 02 40 9A         [24] 1483 	ljmp	_ak820_nvm_flush
      00448E                       1484 00113$:
      00448E 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      00448F                       1503 _ak820_eeprom_update_block_xdata:
      00448F 12 3A F3         [24] 1504 	lcall	_ak820_outline_0110
      004492 90 05 AA         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004495 12 3A F8         [24] 1506 	lcall	_ak820_outline_0111
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004498 90 05 AA         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00449B 12 3A B2         [24] 1509 	lcall	_ak820_outline_0052
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00449E 90 05 A5         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0044A1 E0               [24] 1512 	movx	a,@dptr
      0044A2 F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0044A4 A3               [24] 1514 	inc	dptr
      0044A5 E0               [24] 1515 	movx	a,@dptr
      0044A6 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0044A8 A3               [24] 1517 	inc	dptr
      0044A9 E0               [24] 1518 	movx	a,@dptr
      0044AA F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0044AC A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044AE AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044B0 E4               [12] 1523 	clr	a
      0044B1 F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0044B3 F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0044B5                       1526 00105$:
      0044B5 90 05 A8         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0044B8 E0               [24] 1528 	movx	a,@dptr
      0044B9 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0044BB A3               [24] 1530 	inc	dptr
      0044BC E0               [24] 1531 	movx	a,@dptr
      0044BD F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0044BF C3               [12] 1533 	clr	c
      0044C0 E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C2 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044C4 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044C6 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044C8 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044CA 89 00            [24] 1540 	mov	ar0,r1
      0044CC 8A 05            [24] 1541 	mov	ar5,r2
      0044CE E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044D0 28               [12] 1543 	add	a, r0
      0044D1 F8               [12] 1544 	mov	r0,a
      0044D2 E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044D4 3D               [12] 1546 	addc	a, r5
      0044D5 FD               [12] 1547 	mov	r5,a
      0044D6 88 82            [24] 1548 	mov	dpl, r0
      0044D8 8D 83            [24] 1549 	mov	dph, r5
      0044DA C0 07            [24] 1550 	push	ar7
      0044DC C0 06            [24] 1551 	push	ar6
      0044DE C0 02            [24] 1552 	push	ar2
      0044E0 C0 01            [24] 1553 	push	ar1
      0044E2 12 42 8C         [24] 1554 	lcall	_read_offset
      0044E5 AD 82            [24] 1555 	mov	r5, dpl
      0044E7 D0 01            [24] 1556 	pop	ar1
      0044E9 D0 02            [24] 1557 	pop	ar2
      0044EB D0 06            [24] 1558 	pop	ar6
      0044ED D0 07            [24] 1559 	pop	ar7
      0044EF E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044F1 2E               [12] 1561 	add	a, r6
      0044F2 F5 82            [12] 1562 	mov	dpl,a
      0044F4 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044F6 3F               [12] 1564 	addc	a, r7
      0044F7 F5 83            [12] 1565 	mov	dph,a
      0044F9 E0               [24] 1566 	movx	a,@dptr
      0044FA FC               [12] 1567 	mov	r4,a
      0044FB ED               [12] 1568 	mov	a,r5
      0044FC B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      0044FF 80 27            [24] 1570 	sjmp	00106$
      004501                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004501 90 05 AA         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004504 E0               [24] 1574 	movx	a,@dptr
      004505 F8               [12] 1575 	mov	r0,a
      004506 A3               [24] 1576 	inc	dptr
      004507 E0               [24] 1577 	movx	a,@dptr
      004508 FD               [12] 1578 	mov	r5,a
      004509 90 05 9E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00450C E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00450E F0               [24] 1581 	movx	@dptr,a
      00450F E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004511 A3               [24] 1583 	inc	dptr
      004512 F0               [24] 1584 	movx	@dptr,a
      004513 E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004515 A3               [24] 1586 	inc	dptr
      004516 F0               [24] 1587 	movx	@dptr,a
      004517 90 05 A1         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00451A E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00451C F0               [24] 1590 	movx	@dptr,a
      00451D E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00451F A3               [24] 1592 	inc	dptr
      004520 F0               [24] 1593 	movx	@dptr,a
      004521 88 82            [24] 1594 	mov	dpl, r0
      004523 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004525 02 43 AC         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004528                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004528 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00452A E4               [12] 1601 	clr	a
      00452B B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00452E 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004530 80 83            [24] 1604 	sjmp	00105$
      004532                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004532 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      004533                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004533 12 40 9A         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004536 7F 00            [12] 1622 	mov	r7,#0x00
      004538                       1623 00111$:
      004538 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      00453B 22               [24] 1625 	ret
      00453C                       1626 00165$:
      00453C 20 0C 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00453F 8F 82            [24] 1629 	mov	dpl, r7
      004541 C0 07            [24] 1630 	push	ar7
      004543 12 42 1A         [24] 1631 	lcall	_load_page
      004546 E5 82            [12] 1632 	mov	a, dpl
      004548 D0 07            [24] 1633 	pop	ar7
      00454A 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00454C 22               [24] 1636 	ret
      00454D                       1637 00126$:
      00454D 7E 00            [12] 1638 	mov	r6,#0x00
      00454F                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00454F EE               [12] 1641 	mov	a,r6
      004550 24 2D            [12] 1642 	add	a, #_page_data
      004552 FC               [12] 1643 	mov	r4,a
      004553 E4               [12] 1644 	clr	a
      004554 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004556 FD               [12] 1646 	mov	r5,a
      004557 12 45 B5         [24] 1647 	lcall	_ak820_outline_0097
      00455A 60 07            [24] 1648 	jz	00108$
      00455C 12 3B 08         [24] 1649 	lcall	_ak820_outline_0126
      00455F E4               [12] 1650 	clr	a
      004560 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      004561 D2 0B            [12] 1653 	setb	_page_dirty
      004563                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004563 0E               [12] 1656 	inc	r6
      004564 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004567 C0 07            [24] 1659 	push	ar7
      004569 12 40 9A         [24] 1660 	lcall	_ak820_nvm_flush
      00456C D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00456E 0F               [12] 1663 	inc	r7
      00456F 80 C7            [24] 1664 	sjmp	00111$
      004571                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004571 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0031
                                   1679 	.globl _ak820_outline_0036
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0053
                                   1683 	.globl _ak820_outline_0061
                                   1684 	.globl _ak820_outline_0065
                                   1685 	.globl _ak820_outline_0072
                                   1686 	.globl _ak820_outline_0079
                                   1687 	.globl _ak820_outline_0080
                                   1688 	.globl _ak820_outline_0086
                                   1689 	.globl _ak820_outline_0097
                                   1690 	.globl _ak820_outline_0105
                                   1691 	.globl _ak820_outline_0106
                                   1692 	.globl _ak820_outline_0108
                                   1693 	.globl _ak820_outline_0110
                                   1694 	.globl _ak820_outline_0111
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0124
                                   1697 	.globl _ak820_outline_0125
                                   1698 	.globl _ak820_outline_0126
                                   1699 	.globl _ak820_outline_0127
                                   1700 	.globl _ak820_outline_0137
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0141
                                   1703 	.globl _ak820_outline_0147
                                   1704 	.globl _ak820_outline_0148
                                   1705 	.globl _ak820_outline_0155
                                   1706 	.globl _ak820_outline_0163
                                   1707 	.globl _ak820_outline_0165
                                   1708 	.globl _ak820_outline_0167
                                   1709 	.globl _ak820_outline_0185
                                   1710 	.globl _ak820_outline_0186
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0011
      004572                       1714 _ak820_outline_0011:
      004572 8E 82            [24] 1715 	mov	dpl,r6
      004574 8F 83            [24] 1716 	mov	dph,r7
      004576 A3               [24] 1717 	inc	dptr
      004577 A3               [24] 1718 	inc	dptr
      004578 A3               [24] 1719 	inc	dptr
      004579 A3               [24] 1720 	inc	dptr
      00457A A3               [24] 1721 	inc	dptr
      00457B 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0031
      00457C                       1726 _ak820_outline_0031:
      00457C F0               [24] 1727 	movx	@dptr,a
      00457D 8E 82            [24] 1728 	mov	dpl,r6
      00457F 8F 83            [24] 1729 	mov	dph,r7
      004581 A3               [24] 1730 	inc	dptr
      004582 A3               [24] 1731 	inc	dptr
      004583 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      004584                       1736 _ak820_outline_0036:
      004584 AF F0            [24] 1737 	mov	r7,b
      004586 AE 83            [24] 1738 	mov	r6,dph
      004588 E5 82            [12] 1739 	mov	a,dpl
      00458A 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      00458B                       1744 _ak820_outline_0043:
      00458B EF               [12] 1745 	mov	a,r7
      00458C 24 85            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      00458E F5 82            [12] 1747 	mov	dpl,a
      004590 E4               [12] 1748 	clr	a
      004591 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004593 F5 83            [12] 1750 	mov	dph,a
      004595 E0               [24] 1751 	movx	a,@dptr
      004596 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      004597                       1756 _ak820_outline_0053:
      004597 8F 06            [24] 1757 	mov	ar6,r7
      004599 7D 00            [12] 1758 	mov	r5,#0x00
      00459B 74 40            [12] 1759 	mov	a,#0x40
      00459D 2E               [12] 1760 	add	a,r6
      00459E FE               [12] 1761 	mov	r6,a
      00459F 74 EF            [12] 1762 	mov	a,#0xef
      0045A1 3D               [12] 1763 	addc	a,r5
      0045A2 FD               [12] 1764 	mov	r5,a
      0045A3 8E 82            [24] 1765 	mov	dpl,r6
      0045A5 8D 83            [24] 1766 	mov	dph,r5
      0045A7 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0065
      0045A8                       1771 _ak820_outline_0065:
      0045A8 8D 82            [24] 1772 	mov	dpl,r5
      0045AA 8E 83            [24] 1773 	mov	dph,r6
      0045AC EC               [12] 1774 	mov	a,r4
      0045AD F0               [24] 1775 	movx	@dptr,a
      0045AE 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0079
      0045AF                       1780 _ak820_outline_0079:
      0045AF F0               [24] 1781 	movx	@dptr,a
      0045B0 8E 82            [24] 1782 	mov	dpl,r6
      0045B2 8F 83            [24] 1783 	mov	dph,r7
      0045B4 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0097
      0045B5                       1788 _ak820_outline_0097:
      0045B5 8C 82            [24] 1789 	mov	dpl,r4
      0045B7 8D 83            [24] 1790 	mov	dph,r5
      0045B9 E0               [24] 1791 	movx	a,@dptr
      0045BA 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0106
      0045BB                       1796 _ak820_outline_0106:
      0045BB E0               [24] 1797 	movx	a,@dptr
      0045BC FA               [12] 1798 	mov	r2,a
      0045BD A3               [24] 1799 	inc	dptr
      0045BE E0               [24] 1800 	movx	a,@dptr
      0045BF FB               [12] 1801 	mov	r3,a
      0045C0 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0108
      0045C1                       1806 _ak820_outline_0108:
      0045C1 EF               [12] 1807 	mov	a,r7
      0045C2 24 2D            [12] 1808 	add	a,#_page_data
      0045C4 F5 82            [12] 1809 	mov	dpl,a
      0045C6 E4               [12] 1810 	clr	a
      0045C7 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0045C9 F5 83            [12] 1812 	mov	dph,a
      0045CB E0               [24] 1813 	movx	a,@dptr
      0045CC 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0127
      0045CD                       1818 _ak820_outline_0127:
      0045CD AE 82            [24] 1819 	mov	r6,dpl
      0045CF AF 83            [24] 1820 	mov	r7,dph
      0045D1 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0139
      0045D2                       1825 _ak820_outline_0139:
      0045D2 2E               [12] 1826 	add	a,r6
      0045D3 FE               [12] 1827 	mov	r6,a
      0045D4 E4               [12] 1828 	clr	a
      0045D5 3F               [12] 1829 	addc	a,r7
      0045D6 FF               [12] 1830 	mov	r7,a
      0045D7 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0141
      0045D8                       1835 _ak820_outline_0141:
      0045D8 ED               [12] 1836 	mov	a,r5
      0045D9 F0               [24] 1837 	movx	@dptr,a
      0045DA EE               [12] 1838 	mov	a,r6
      0045DB A3               [24] 1839 	inc	dptr
      0045DC F0               [24] 1840 	movx	@dptr,a
      0045DD 22               [24] 1841 	ret
                                   1842 
                                   1843 	.area CSEG (CODE)
                                   1844 ; function ak820_outline_0147
      0045DE                       1845 _ak820_outline_0147:
      0045DE 42 05            [12] 1846 	orl	ar5,a
      0045E0 EA               [12] 1847 	mov	a,r2
      0045E1 42 04            [12] 1848 	orl	ar4,a
      0045E3 22               [24] 1849 	ret
                                   1850 
                                   1851 	.area CSEG (CODE)
                                   1852 ; function ak820_outline_0155
      0045E4                       1853 _ak820_outline_0155:
      0045E4 AC 82            [24] 1854 	mov	r4,dpl
      0045E6 AD 83            [24] 1855 	mov	r5,dph
      0045E8 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0165
      0045E9                       1860 _ak820_outline_0165:
      0045E9 8F 82            [24] 1861 	mov	dpl,r7
      0045EB 8E 83            [24] 1862 	mov	dph,r6
      0045ED 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0167
      0045EE                       1867 _ak820_outline_0167:
      0045EE 2E               [12] 1868 	add	a,r6
      0045EF FC               [12] 1869 	mov	r4,a
      0045F0 E4               [12] 1870 	clr	a
      0045F1 3F               [12] 1871 	addc	a,r7
      0045F2 FD               [12] 1872 	mov	r5,a
      0045F3 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0185
      0045F4                       1877 _ak820_outline_0185:
      0045F4 89 82            [24] 1878 	mov	dpl,r1
      0045F6 8A 83            [24] 1879 	mov	dph,r2
      0045F8 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0186
      0045F9                       1884 _ak820_outline_0186:
      0045F9 8C 82            [24] 1885 	mov	dpl,r4
      0045FB 8B 83            [24] 1886 	mov	dph,r3
      0045FD 22               [24] 1887 	ret
