                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006D3                        611 _rgb_matrix_config::
      0006D3                        612 	.ds 8
      0006DB                        613 _changed_at:
      0006DB                        614 	.ds 2
      0006DD                        615 _frame_at:
      0006DD                        616 	.ds 2
      0006DF                        617 _phase:
      0006DF                        618 	.ds 2
      0006E1                        619 _led_index:
      0006E1                        620 	.ds 1
      0006E2                        621 _frame_mode:
      0006E2                        622 	.ds 1
      0006E3                        623 _frame_hue:
      0006E3                        624 	.ds 1
      0006E4                        625 _frame_sat:
      0006E4                        626 	.ds 1
      0006E5                        627 _frame_val:
      0006E5                        628 	.ds 1
      0006E6                        629 _frame_flags:
      0006E6                        630 	.ds 1
      0006E7                        631 _frame_phase:
      0006E7                        632 	.ds 1
      0006E8                        633 _reactive_age:
      0006E8                        634 	.ds 82
      00073A                        635 _reactive_at:
      00073A                        636 	.ds 2
      00073C                        637 _add_sat_PARM_2:
      00073C                        638 	.ds 1
      00073D                        639 _add_sat_x_10000_266:
      00073D                        640 	.ds 1
      00073E                        641 _sub_sat_PARM_2:
      00073E                        642 	.ds 1
      00073F                        643 _sub_sat_x_10000_268:
      00073F                        644 	.ds 1
      000740                        645 _rgb_matrix_set_color_PARM_2:
      000740                        646 	.ds 1
      000741                        647 _rgb_matrix_set_color_PARM_3:
      000741                        648 	.ds 1
      000742                        649 _rgb_matrix_set_color_PARM_4:
      000742                        650 	.ds 1
      000743                        651 _rgb_matrix_set_color_index_10000_284:
      000743                        652 	.ds 2
      000745                        653 _rgb_matrix_set_color_all_PARM_2:
      000745                        654 	.ds 1
      000746                        655 _rgb_matrix_set_color_all_PARM_3:
      000746                        656 	.ds 1
      000747                        657 _rgb_matrix_set_color_all_r_10000_287:
      000747                        658 	.ds 1
      000748                        659 _sine8_theta_10000_289:
      000748                        660 	.ds 1
      000749                        661 _sine8_offset_10000_290:
      000749                        662 	.ds 1
      00074A                        663 _sine8_fraction_10000_290:
      00074A                        664 	.ds 1
      00074B                        665 _breathing_cie_value_10000_293:
      00074B                        666 	.ds 1
      00074C                        667 _rgb_matrix_task_end_10000_298:
      00074C                        668 	.ds 1
      00074D                        669 _rgb_matrix_task_hsv_10000_298:
      00074D                        670 	.ds 3
      000750                        671 _rgb_matrix_task_rgb_10000_298:
      000750                        672 	.ds 3
      000753                        673 _process_rgb_matrix_PARM_2:
      000753                        674 	.ds 1
      000754                        675 _process_rgb_matrix_PARM_3:
      000754                        676 	.ds 1
      000755                        677 _process_rgb_matrix_row_10000_319:
      000755                        678 	.ds 1
      000756                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000756                        680 	.ds 1
      000757                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000757                        682 	.ds 1
      000758                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000758                        684 	.ds 1
      000759                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000759                        686 	.ds 1
      00075A                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      00075A                        688 	.ds 2
      00075C                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00075C                        690 	.ds 1
      00075D                        691 _rgb_matrix_mode_mode_10000_411:
      00075D                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      00545B                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      00545B 12 5C 28         [24]  746 	lcall	_ak820_outline_0181
      00545E 74 52            [12]  747 	mov	a,#0x52
      005460 12 3B 0D         [24]  748 	lcall	_ak820_outline_0136
      005463 90 06 E8         [24]  749 	mov	dptr,#_reactive_age
      005466 F5 F0            [12]  750 	mov	b,a
      005468 12 BD 70         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      00546B 12 4B 9F         [24]  753 	lcall	_timer_read
      00546E 12 3B 17         [24]  754 	lcall	_ak820_outline_0140
      005471 90 07 3A         [24]  755 	mov	dptr,#_reactive_at
      005474 12 5C 14         [24]  756 	lcall	_ak820_outline_0172
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      005477 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      005478                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      005478 90 07 3A         [24]  772 	mov	dptr,#_reactive_at
      00547B 12 3A 65         [24]  773 	lcall	_ak820_outline_0005
      00547E 12 4B A2         [24]  774 	lcall	_timer_elapsed
      005481 AE 82            [24]  775 	mov	r6, dpl
      005483 E5 83            [12]  776 	mov	a,dph
      005485 C4               [12]  777 	swap	a
      005486 CE               [12]  778 	xch	a,r6
      005487 C4               [12]  779 	swap	a
      005488 54 0F            [12]  780 	anl	a,#0x0f
      00548A 6E               [12]  781 	xrl	a,r6
      00548B CE               [12]  782 	xch	a,r6
      00548C 54 0F            [12]  783 	anl	a,#0x0f
      00548E CE               [12]  784 	xch	a,r6
      00548F 6E               [12]  785 	xrl	a,r6
      005490 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005491 FF               [12]  788 	mov	r7,a
      005492 4E               [12]  789 	orl	a,r6
      005493 70 01            [24]  790 	jnz	00102$
      005495 22               [24]  791 	ret
      005496                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      005496 8E 04            [24]  794 	mov	ar4,r6
      005498 EF               [12]  795 	mov	a,r7
      005499 C4               [12]  796 	swap	a
      00549A 54 F0            [12]  797 	anl	a,#0xf0
      00549C CC               [12]  798 	xch	a,r4
      00549D C4               [12]  799 	swap	a
      00549E CC               [12]  800 	xch	a,r4
      00549F 6C               [12]  801 	xrl	a,r4
      0054A0 CC               [12]  802 	xch	a,r4
      0054A1 54 F0            [12]  803 	anl	a,#0xf0
      0054A3 CC               [12]  804 	xch	a,r4
      0054A4 6C               [12]  805 	xrl	a,r4
      0054A5 FD               [12]  806 	mov	r5,a
      0054A6 90 07 3A         [24]  807 	mov	dptr,#_reactive_at
      0054A9 12 45 BB         [24]  808 	lcall	_ak820_outline_0106
      0054AC 90 07 3A         [24]  809 	mov	dptr,#_reactive_at
      0054AF EC               [12]  810 	mov	a,r4
      0054B0 2A               [12]  811 	add	a, r2
      0054B1 F0               [24]  812 	movx	@dptr,a
      0054B2 ED               [12]  813 	mov	a,r5
      0054B3 3B               [12]  814 	addc	a, r3
      0054B4 A3               [24]  815 	inc	dptr
      0054B5 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      0054B6 8E 04            [24]  818 	mov	ar4,r6
      0054B8 8F 05            [24]  819 	mov	ar5,r7
      0054BA C3               [12]  820 	clr	c
      0054BB 74 FF            [12]  821 	mov	a,#0xff
      0054BD 9C               [12]  822 	subb	a,r4
      0054BE E4               [12]  823 	clr	a
      0054BF 9D               [12]  824 	subb	a,r5
      0054C0 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      0054C2 7D FF            [12]  827 	mov	r5,#0xff
      0054C4 80 02            [24]  828 	sjmp	00109$
      0054C6                        829 00108$:
      0054C6 8E 05            [24]  830 	mov	ar5,r6
      0054C8                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054C8 7F 00            [12]  833 	mov	r7,#0x00
      0054CA                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      0054CA EF               [12]  836 	mov	a,r7
      0054CB 24 E8            [12]  837 	add	a, #_reactive_age
      0054CD FC               [12]  838 	mov	r4,a
      0054CE E4               [12]  839 	clr	a
      0054CF 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      0054D1 FE               [12]  841 	mov	r6,a
      0054D2 8C 82            [24]  842 	mov	dpl,r4
      0054D4 8E 83            [24]  843 	mov	dph,r6
      0054D6 E0               [24]  844 	movx	a,@dptr
      0054D7 FB               [12]  845 	mov	r3,a
      0054D8 C3               [12]  846 	clr	c
      0054D9 ED               [12]  847 	mov	a,r5
      0054DA 9B               [12]  848 	subb	a,r3
      0054DB 40 04            [24]  849 	jc	00110$
      0054DD 7B 00            [12]  850 	mov	r3,#0x00
      0054DF 80 08            [24]  851 	sjmp	00111$
      0054E1                        852 00110$:
      0054E1 8C 82            [24]  853 	mov	dpl,r4
      0054E3 8E 83            [24]  854 	mov	dph,r6
      0054E5 E0               [24]  855 	movx	a,@dptr
      0054E6 C3               [12]  856 	clr	c
      0054E7 9D               [12]  857 	subb	a,r5
      0054E8 FB               [12]  858 	mov	r3,a
      0054E9                        859 00111$:
      0054E9 8C 82            [24]  860 	mov	dpl,r4
      0054EB 8E 83            [24]  861 	mov	dph,r6
      0054ED EB               [12]  862 	mov	a,r3
      0054EE F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054EF 0F               [12]  865 	inc	r7
      0054F0 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      0054F3                        867 00144$:
      0054F3 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      0054F5 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      0054F6                        881 _add_sat:
      0054F6 E5 82            [12]  882 	mov	a,dpl
      0054F8 90 07 3D         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      0054FB F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0054FC 90 07 3C         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0054FF E0               [24]  887 	movx	a,@dptr
      005500 FF               [12]  888 	mov	r7,a
      005501 FE               [12]  889 	mov	r6,a
      005502 74 FF            [12]  890 	mov	a,#0xff
      005504 C3               [12]  891 	clr	c
      005505 9E               [12]  892 	subb	a,r6
      005506 FE               [12]  893 	mov	r6,a
      005507 90 07 3D         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      00550A E0               [24]  895 	movx	a,@dptr
      00550B FD               [12]  896 	mov	r5,a
      00550C C3               [12]  897 	clr	c
      00550D EE               [12]  898 	mov	a,r6
      00550E 9D               [12]  899 	subb	a,r5
      00550F 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      005511 7E FF            [12]  902 	mov	r6,#0xff
      005513 80 03            [24]  903 	sjmp	00104$
      005515                        904 00103$:
      005515 EF               [12]  905 	mov	a,r7
      005516 2D               [12]  906 	add	a, r5
      005517 FE               [12]  907 	mov	r6,a
      005518                        908 00104$:
      005518 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      00551A 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      00551B                        922 _sub_sat:
      00551B E5 82            [12]  923 	mov	a,dpl
      00551D 90 07 3F         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      005520 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      005521 E0               [24]  927 	movx	a,@dptr
      005522 FF               [12]  928 	mov	r7,a
      005523 90 07 3E         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      005526 E0               [24]  930 	movx	a,@dptr
      005527 FE               [12]  931 	mov	r6,a
      005528 C3               [12]  932 	clr	c
      005529 EF               [12]  933 	mov	a,r7
      00552A 9E               [12]  934 	subb	a,r6
      00552B 50 04            [24]  935 	jnc	00103$
      00552D 7D 00            [12]  936 	mov	r5,#0x00
      00552F 80 04            [24]  937 	sjmp	00104$
      005531                        938 00103$:
      005531 EF               [12]  939 	mov	a,r7
      005532 C3               [12]  940 	clr	c
      005533 9E               [12]  941 	subb	a,r6
      005534 FD               [12]  942 	mov	r5,a
      005535                        943 00104$:
      005535 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      005537 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      005538                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      005538 D2 13            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      00553A 12 4B 9F         [24]  959 	lcall	_timer_read
      00553D 12 3B 17         [24]  960 	lcall	_ak820_outline_0140
      005540 90 06 DB         [24]  961 	mov	dptr,#_changed_at
      005543 12 5C 14         [24]  962 	lcall	_ak820_outline_0172
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      005546 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      005547                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      005547 90 06 DA         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      00554A E4               [12]  978 	clr	a
      00554B F0               [24]  979 	movx	@dptr,a
      00554C 90 06 D9         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      00554F F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005550 90 05 A5         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005553 12 5B F7         [24]  984 	lcall	_ak820_outline_0087
      005556 90 05 A8         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      005559 12 5B DE         [24]  986 	lcall	_ak820_outline_0070
      00555C 12 44 8F         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      00555F C2 13            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005561 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005562                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005562 12 5C 28         [24] 1002 	lcall	_ak820_outline_0181
      005565 12 5B DE         [24] 1003 	lcall	_ak820_outline_0070
      005568 F5 F0            [12] 1004 	mov	b,a
      00556A 12 BD 70         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      00556D 12 5C 07         [24] 1007 	lcall	_ak820_outline_0117
      005570 44 01            [12] 1008 	orl	a,#0x01
      005572 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005573 12 5B D7         [24] 1011 	lcall	_ak820_outline_0066
      005576 44 04            [12] 1012 	orl	a,#0x04
      005578 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      005579 90 06 D4         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00557C E4               [12] 1016 	clr	a
      00557D F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      00557E 90 06 D5         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005581 14               [12] 1020 	dec	a
      005582 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005583 90 06 D6         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005586 74 50            [12] 1024 	mov	a,#0x50
      005588 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      005589 90 06 D7         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00558C 74 60            [12] 1028 	mov	a,#0x60
      00558E F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      00558F 90 06 D8         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005592 74 FF            [12] 1032 	mov	a,#0xff
      005594 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005595 A1 47            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      005597                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005597 90 05 95         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00559A 12 5B F7         [24] 1047 	lcall	_ak820_outline_0087
      00559D 90 05 98         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0055A0 12 5B DE         [24] 1049 	lcall	_ak820_outline_0070
      0055A3 12 43 20         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      0055A6 12 5C 07         [24] 1052 	lcall	_ak820_outline_0117
      0055A9 60 11            [24] 1053 	jz	00101$
      0055AB 12 5B B8         [24] 1054 	lcall	_ak820_outline_0019
      0055AE C3               [12] 1055 	clr	c
      0055AF 64 80            [12] 1056 	xrl	a,#0x80
      0055B1 94 87            [12] 1057 	subb	a,#0x87
      0055B3 50 07            [24] 1058 	jnc	00101$
      0055B5 12 5B D7         [24] 1059 	lcall	_ak820_outline_0066
      0055B8 24 FE            [12] 1060 	add	a,#0xff - 0x01
      0055BA 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      0055BC                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      0055BC B1 62            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      0055BE                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      0055BE 90 06 D6         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055C1 E0               [24] 1069 	movx	a,@dptr
      0055C2 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      0055C4 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      0055C6 90 06 D6         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055C9 74 A0            [12] 1075 	mov	a,#0xa0
      0055CB F0               [24] 1076 	movx	@dptr,a
      0055CC                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      0055CC C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      0055CE C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      0055D0 81 5B            [12] 1086 	ajmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0055D2                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0055D2 B1 97            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0055D4 12 4B 9F         [24] 1098 	lcall	_timer_read
      0055D7 12 45 CD         [24] 1099 	lcall	_ak820_outline_0127
      0055DA EE               [12] 1100 	mov	a,r6
      0055DB 24 F0            [12] 1101 	add	a,#0xf0
      0055DD FE               [12] 1102 	mov	r6,a
      0055DE EF               [12] 1103 	mov	a,r7
      0055DF 34 FF            [12] 1104 	addc	a,#0xff
      0055E1 FF               [12] 1105 	mov	r7,a
      0055E2 90 06 DD         [24] 1106 	mov	dptr,#_frame_at
      0055E5 12 4A EC         [24] 1107 	lcall	_ak820_outline_0060
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0055E8 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0055E9                       1122 _rgb_matrix_set_color:
      0055E9 12 3A F3         [24] 1123 	lcall	_ak820_outline_0110
      0055EC 90 07 43         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0055EF 12 3A F8         [24] 1125 	lcall	_ak820_outline_0111
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0055F2 90 07 43         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0055F5 12 3A B2         [24] 1128 	lcall	_ak820_outline_0052
      0055F8 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0055FB C3               [12] 1130 	clr	c
      0055FC EE               [12] 1131 	mov	a,r6
      0055FD 94 52            [12] 1132 	subb	a,#0x52
      0055FF EF               [12] 1133 	mov	a,r7
      005600 64 80            [12] 1134 	xrl	a,#0x80
      005602 94 80            [12] 1135 	subb	a,#0x80
      005604 50 23            [24] 1136 	jnc	00104$
      005606 90 07 40         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005609 E0               [24] 1138 	movx	a,@dptr
      00560A FF               [12] 1139 	mov	r7,a
      00560B 90 07 41         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00560E E0               [24] 1141 	movx	a,@dptr
      00560F FD               [12] 1142 	mov	r5,a
      005610 90 07 42         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005613 E0               [24] 1144 	movx	a,@dptr
      005614 FC               [12] 1145 	mov	r4,a
      005615 90 04 2A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005618 EF               [12] 1147 	mov	a,r7
      005619 F0               [24] 1148 	movx	@dptr,a
      00561A 90 04 2B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      00561D ED               [12] 1150 	mov	a,r5
      00561E F0               [24] 1151 	movx	@dptr,a
      00561F 90 04 2C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      005622 EC               [12] 1153 	mov	a,r4
      005623 F0               [24] 1154 	movx	@dptr,a
      005624 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      005626 02 35 FE         [24] 1157 	ljmp	_ak820_rgb_set_color
      005629                       1158 00104$:
      005629 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      00562A                       1171 _rgb_matrix_set_color_all:
      00562A E5 82            [12] 1172 	mov	a,dpl
      00562C 90 07 47         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      00562F F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      005630 E0               [24] 1176 	movx	a,@dptr
      005631 FF               [12] 1177 	mov	r7,a
      005632 90 07 45         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005635 E0               [24] 1179 	movx	a,@dptr
      005636 FE               [12] 1180 	mov	r6,a
      005637 90 07 46         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00563A E0               [24] 1182 	movx	a,@dptr
      00563B FD               [12] 1183 	mov	r5,a
      00563C 90 04 2E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      00563F EE               [12] 1185 	mov	a,r6
      005640 F0               [24] 1186 	movx	@dptr,a
      005641 90 04 2F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005644 ED               [12] 1188 	mov	a,r5
      005645 F0               [24] 1189 	movx	@dptr,a
      005646 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005648 02 36 35         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      00564B                       1206 _sine8:
      00564B E5 82            [12] 1207 	mov	a,dpl
      00564D 90 07 48         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      005650 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005651 E0               [24] 1211 	movx	a,@dptr
      005652 FF               [12] 1212 	mov	r7,a
      005653 90 07 49         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005656 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005657 EF               [12] 1216 	mov	a,r7
      005658 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      00565B 90 07 49         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      00565E 74 FF            [12] 1219 	mov	a,#0xff
      005660 C3               [12] 1220 	clr	c
      005661 9F               [12] 1221 	subb	a,r7
      005662 F0               [24] 1222 	movx	@dptr,a
      005663                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005663 90 07 49         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005666 E0               [24] 1226 	movx	a,@dptr
      005667 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      00566A F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00566B 90 07 49         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      00566E E0               [24] 1231 	movx	a,@dptr
      00566F 54 0F            [12] 1232 	anl	a,#0x0f
      005671 FF               [12] 1233 	mov	r7,a
      005672 90 07 4A         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005675 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005676 90 07 48         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005679 E0               [24] 1238 	movx	a,@dptr
      00567A 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      00567D 90 07 4A         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      005680 EF               [12] 1241 	mov	a,r7
      005681 04               [12] 1242 	inc	a
      005682 F0               [24] 1243 	movx	@dptr,a
      005683                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005683 90 07 49         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005686 E0               [24] 1247 	movx	a,@dptr
      005687 C4               [12] 1248 	swap	a
      005688 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00568A 25 E0            [12] 1251 	add	a,acc
      00568C FF               [12] 1252 	mov	r7,a
      00568D 90 BE 55         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      005690 93               [24] 1254 	movc	a,@a+dptr
      005691 FE               [12] 1255 	mov	r6,a
      005692 0F               [12] 1256 	inc	r7
      005693 EF               [12] 1257 	mov	a,r7
      005694 90 BE 55         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005697 93               [24] 1259 	movc	a,@a+dptr
      005698 FF               [12] 1260 	mov	r7,a
      005699 90 07 4A         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      00569C E0               [24] 1262 	movx	a,@dptr
      00569D 8F F0            [24] 1263 	mov	b,r7
      00569F A4               [48] 1264 	mul	ab
      0056A0 FF               [12] 1265 	mov	r7,a
      0056A1 E5 F0            [12] 1266 	mov	a,b
      0056A3 C4               [12] 1267 	swap	a
      0056A4 CF               [12] 1268 	xch	a,r7
      0056A5 C4               [12] 1269 	swap	a
      0056A6 54 0F            [12] 1270 	anl	a,#0x0f
      0056A8 6F               [12] 1271 	xrl	a,r7
      0056A9 CF               [12] 1272 	xch	a,r7
      0056AA 54 0F            [12] 1273 	anl	a,#0x0f
      0056AC CF               [12] 1274 	xch	a,r7
      0056AD 6F               [12] 1275 	xrl	a,r7
      0056AE CF               [12] 1276 	xch	a,r7
      0056AF EF               [12] 1277 	mov	a,r7
      0056B0 2E               [12] 1278 	add	a, r6
      0056B1 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      0056B2 90 07 48         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      0056B5 E0               [24] 1282 	movx	a,@dptr
      0056B6 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      0056B9 8F 06            [24] 1284 	mov	ar6,r7
      0056BB 74 80            [12] 1285 	mov	a,#0x80
      0056BD C3               [12] 1286 	clr	c
      0056BE 9E               [12] 1287 	subb	a,r6
      0056BF FE               [12] 1288 	mov	r6,a
      0056C0 80 04            [24] 1289 	sjmp	00108$
      0056C2                       1290 00107$:
      0056C2 74 80            [12] 1291 	mov	a,#0x80
      0056C4 2F               [12] 1292 	add	a, r7
      0056C5 FE               [12] 1293 	mov	r6,a
      0056C6                       1294 00108$:
      0056C6 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      0056C8 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      0056C9                       1312 _breathing_cie:
      0056C9 E5 82            [12] 1313 	mov	a,dpl
      0056CB 90 07 4B         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      0056CE F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      0056CF E0               [24] 1317 	movx	a,@dptr
      0056D0 FF               [12] 1318 	mov	r7,a
      0056D1 12 5C 36         [24] 1319 	lcall	_ak820_outline_0190
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0056D4 FE               [12] 1321 	mov	r6,a
      0056D5 90 C1 61         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0056D8 93               [24] 1323 	movc	a,@a+dptr
      0056D9 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0056DA BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0056DD 8D 82            [24] 1327 	mov	dpl, r5
      0056DF 22               [24] 1328 	ret
      0056E0                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0056E0 EE               [12] 1331 	mov	a,r6
      0056E1 04               [12] 1332 	inc	a
      0056E2 90 C1 61         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0056E5 93               [24] 1334 	movc	a,@a+dptr
      0056E6 C3               [12] 1335 	clr	c
      0056E7 9D               [12] 1336 	subb	a,r5
      0056E8 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0056E9 74 07            [12] 1339 	mov	a,#0x07
      0056EB 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0056EC F5 F0            [12] 1342 	mov	b,a
      0056EE EE               [12] 1343 	mov	a,r6
      0056EF A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0056F0 12 5C 36         [24] 1346 	lcall	_ak820_outline_0190
      0056F3 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0056F4 F5 82            [12] 1349 	mov	dpl,a
      0056F6 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      0056F7                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0056F7 91 78            [12] 1367 	acall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0056F9 30 13 17         [24] 1369 	jnb	_dirty,00102$
      0056FC 90 06 DB         [24] 1370 	mov	dptr,#_changed_at
      0056FF 12 3A 65         [24] 1371 	lcall	_ak820_outline_0005
      005702 12 4B A2         [24] 1372 	lcall	_timer_elapsed
      005705 12 45 CD         [24] 1373 	lcall	_ak820_outline_0127
      005708 C3               [12] 1374 	clr	c
      005709 EE               [12] 1375 	mov	a,r6
      00570A 94 E8            [12] 1376 	subb	a,#0xe8
      00570C EF               [12] 1377 	mov	a,r7
      00570D 94 03            [12] 1378 	subb	a,#0x03
      00570F 40 02            [24] 1379 	jc	00102$
      005711 B1 47            [12] 1380 	acall	_eeconfig_update_rgb_matrix
      005713                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      005713 30 14 02         [24] 1383 	jnb	_rendering,00254$
      005716 E1 CB            [12] 1384 	ajmp	00109$
      005718                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005718 90 06 DD         [24] 1387 	mov	dptr,#_frame_at
      00571B 12 3A 65         [24] 1388 	lcall	_ak820_outline_0005
      00571E 12 4B A2         [24] 1389 	lcall	_timer_elapsed
      005721 12 45 CD         [24] 1390 	lcall	_ak820_outline_0127
      005724 C3               [12] 1391 	clr	c
      005725 EE               [12] 1392 	mov	a,r6
      005726 94 10            [12] 1393 	subb	a,#0x10
      005728 EF               [12] 1394 	mov	a,r7
      005729 94 00            [12] 1395 	subb	a,#0x00
      00572B 50 01            [24] 1396 	jnc	00105$
      00572D 22               [24] 1397 	ret
      00572E                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      00572E 12 4B 9F         [24] 1400 	lcall	_timer_read
      005731 12 3B 17         [24] 1401 	lcall	_ak820_outline_0140
      005734 90 06 DD         [24] 1402 	mov	dptr,#_frame_at
      005737 12 5C 14         [24] 1403 	lcall	_ak820_outline_0172
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      00573A 90 06 D7         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00573D E0               [24] 1406 	movx	a,@dptr
      00573E FF               [12] 1407 	mov	r7,a
      00573F 7E 00            [12] 1408 	mov	r6,#0x00
      005741 74 20            [12] 1409 	mov	a,#0x20
      005743 2F               [12] 1410 	add	a, r7
      005744 FF               [12] 1411 	mov	r7,a
      005745 E4               [12] 1412 	clr	a
      005746 3E               [12] 1413 	addc	a, r6
      005747 FE               [12] 1414 	mov	r6,a
      005748 90 06 DF         [24] 1415 	mov	dptr,#_phase
      00574B 12 3A C9         [24] 1416 	lcall	_ak820_outline_0061
      00574E EF               [12] 1417 	mov	a,r7
      00574F 2C               [12] 1418 	add	a, r4
      005750 FF               [12] 1419 	mov	r7,a
      005751 EE               [12] 1420 	mov	a,r6
      005752 3D               [12] 1421 	addc	a, r5
      005753 FE               [12] 1422 	mov	r6,a
      005754 90 06 DF         [24] 1423 	mov	dptr,#_phase
      005757 EF               [12] 1424 	mov	a,r7
      005758 F0               [24] 1425 	movx	@dptr,a
      005759 EE               [12] 1426 	mov	a,r6
      00575A A3               [24] 1427 	inc	dptr
      00575B F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      00575C 90 06 DF         [24] 1430 	mov	dptr,#_phase
      00575F E0               [24] 1431 	movx	a,@dptr
      005760 A3               [24] 1432 	inc	dptr
      005761 E0               [24] 1433 	movx	a,@dptr
      005762 FF               [12] 1434 	mov	r7,a
      005763 90 06 E7         [24] 1435 	mov	dptr,#_frame_phase
      005766 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005767 20 12 05         [24] 1438 	jb	_suspended,00135$
      00576A 12 5B D7         [24] 1439 	lcall	_ak820_outline_0066
      00576D 70 04            [24] 1440 	jnz	00132$
      00576F                       1441 00135$:
      00576F 7E 00            [12] 1442 	mov	r6,#0x00
      005771 80 04            [24] 1443 	sjmp	00133$
      005773                       1444 00132$:
      005773 12 5B B8         [24] 1445 	lcall	_ak820_outline_0019
      005776 FE               [12] 1446 	mov	r6,a
      005777                       1447 00133$:
      005777 90 06 E2         [24] 1448 	mov	dptr,#_frame_mode
      00577A EE               [12] 1449 	mov	a,r6
      00577B F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      00577C 90 06 D4         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00577F E0               [24] 1453 	movx	a,@dptr
      005780 90 06 E3         [24] 1454 	mov	dptr,#_frame_hue
      005783 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005784 90 06 D5         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005787 E0               [24] 1458 	movx	a,@dptr
      005788 90 06 E4         [24] 1459 	mov	dptr,#_frame_sat
      00578B F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      00578C 90 06 D6         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00578F E0               [24] 1463 	movx	a,@dptr
      005790 FD               [12] 1464 	mov	r5,a
      005791 90 06 E5         [24] 1465 	mov	dptr,#_frame_val
      005794 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005795 90 06 D8         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005798 E0               [24] 1469 	movx	a,@dptr
      005799 90 06 E6         [24] 1470 	mov	dptr,#_frame_flags
      00579C F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00579D BE 02 24         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      0057A0 EF               [12] 1475 	mov	a,r7
      0057A1 24 C0            [12] 1476 	add	a,#0xc0
      0057A3 F5 82            [12] 1477 	mov	dpl,a
      0057A5 C0 05            [24] 1478 	push	ar5
      0057A7 D1 4B            [24] 1479 	acall	_sine8
      0057A9 AF 82            [24] 1480 	mov	r7, dpl
      0057AB D0 05            [24] 1481 	pop	ar5
      0057AD 8D F0            [24] 1482 	mov	b,r5
      0057AF EF               [12] 1483 	mov	a,r7
      0057B0 A4               [48] 1484 	mul	ab
      0057B1 AE F0            [24] 1485 	mov	r6,b
      0057B3 8E 05            [24] 1486 	mov	ar5,r6
      0057B5 90 06 E5         [24] 1487 	mov	dptr,#_frame_val
      0057B8 ED               [12] 1488 	mov	a,r5
      0057B9 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      0057BA 8D 82            [24] 1491 	mov	dpl, r5
      0057BC D1 C9            [24] 1492 	acall	_breathing_cie
      0057BE E5 82            [12] 1493 	mov	a, dpl
      0057C0 90 06 E5         [24] 1494 	mov	dptr,#_frame_val
      0057C3 F0               [24] 1495 	movx	@dptr,a
      0057C4                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      0057C4 90 06 E1         [24] 1498 	mov	dptr,#_led_index
      0057C7 E4               [12] 1499 	clr	a
      0057C8 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      0057C9 D2 14            [12] 1503 	setb	_rendering
      0057CB                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      0057CB 12 5C 31         [24] 1506 	lcall	_ak820_outline_0188
      0057CE 24 08            [12] 1507 	add	a,#0x08
      0057D0 FF               [12] 1508 	mov	r7,a
      0057D1 90 07 4C         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057D4 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0057D5 EF               [12] 1512 	mov	a,r7
      0057D6 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0057D8 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0057DA 90 07 4C         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057DD 74 52            [12] 1517 	mov	a,#0x52
      0057DF F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0057E0                       1520 00125$:
      0057E0 12 5C 31         [24] 1521 	lcall	_ak820_outline_0188
      0057E3 FF               [12] 1522 	mov	r7,a
      0057E4 90 07 4C         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057E7 E0               [24] 1524 	movx	a,@dptr
      0057E8 FE               [12] 1525 	mov	r6,a
      0057E9 C3               [12] 1526 	clr	c
      0057EA EF               [12] 1527 	mov	a,r7
      0057EB 9E               [12] 1528 	subb	a,r6
      0057EC 40 02            [24] 1529 	jc	00261$
?ASlink-Warning-2K Page relocation error
      0057EE 21 4E            [12] 1530 	ajmp	00127$
      0057F0                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0057F0 12 5C 0E         [24] 1533 	lcall	_ak820_outline_0143
      0057F3 E0               [24] 1534 	movx	a,@dptr
      0057F4 60 07            [24] 1535 	jz	00121$
      0057F6 90 06 E6         [24] 1536 	mov	dptr,#_frame_flags
      0057F9 E0               [24] 1537 	movx	a,@dptr
      0057FA 20 E2 1A         [24] 1538 	jb	acc.2,00122$
      0057FD                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0057FD 12 5C 31         [24] 1541 	lcall	_ak820_outline_0188
      005800 FC               [12] 1542 	mov	r4,a
      005801 7D 00            [12] 1543 	mov	r5,#0x00
      005803 90 07 40         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005806 E4               [12] 1545 	clr	a
      005807 F0               [24] 1546 	movx	@dptr,a
      005808 90 07 41         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00580B F0               [24] 1548 	movx	@dptr,a
      00580C 90 07 42         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00580F 12 3A E7         [24] 1550 	lcall	_ak820_outline_0104
      005812 12 55 E9         [24] 1551 	lcall	_rgb_matrix_set_color
      005815 21 45            [12] 1552 	ajmp	00123$
      005817                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005817 BE 05 20         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00581A EF               [12] 1557 	mov	a,r7
      00581B 75 F0 03         [24] 1558 	mov	b,#0x03
      00581E A4               [48] 1559 	mul	ab
      00581F 24 DE            [12] 1560 	add	a, #_g_direct_mode_colors
      005821 FD               [12] 1561 	mov	r5,a
      005822 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      005824 35 F0            [12] 1563 	addc	a, b
      005826 FE               [12] 1564 	mov	r6,a
      005827 90 0D F2         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      00582A ED               [12] 1566 	mov	a,r5
      00582B F0               [24] 1567 	movx	@dptr,a
      00582C EE               [12] 1568 	mov	a,r6
      00582D 12 5B E8         [24] 1569 	lcall	_ak820_outline_0073
      005830 90 07 4D         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005833 F5 F0            [12] 1571 	mov	b,a
      005835 12 BC FA         [24] 1572 	lcall	___memcpy
      005838 01 E9            [12] 1573 	ajmp	00120$
      00583A                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      00583A 90 06 E3         [24] 1576 	mov	dptr,#_frame_hue
      00583D E0               [24] 1577 	movx	a,@dptr
      00583E 90 07 4D         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005841 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005842 90 06 E4         [24] 1581 	mov	dptr,#_frame_sat
      005845 E0               [24] 1582 	movx	a,@dptr
      005846 90 07 4E         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005849 F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      00584A 90 06 E5         [24] 1586 	mov	dptr,#_frame_val
      00584D E0               [24] 1587 	movx	a,@dptr
      00584E 90 07 4F         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005851 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005852 12 5C 0E         [24] 1591 	lcall	_ak820_outline_0143
      005855 BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      005858 90 07 4D         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00585B E0               [24] 1594 	movx	a,@dptr
      00585C FE               [12] 1595 	mov	r6,a
      00585D 90 06 E7         [24] 1596 	mov	dptr,#_frame_phase
      005860 E0               [24] 1597 	movx	a,@dptr
      005861 2E               [12] 1598 	add	a, r6
      005862 90 07 4D         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005865 F0               [24] 1600 	movx	@dptr,a
      005866                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005866 12 5C 0E         [24] 1603 	lcall	_ak820_outline_0143
      005869 BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      00586C 90 07 4D         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00586F E0               [24] 1606 	movx	a,@dptr
      005870 FE               [12] 1607 	mov	r6,a
      005871 12 5C 31         [24] 1608 	lcall	_ak820_outline_0188
      005874 75 F0 02         [24] 1609 	mov	b,#0x02
      005877 A4               [48] 1610 	mul	ab
      005878 24 BD            [12] 1611 	add	a, #_ak820_led_points
      00587A F5 82            [12] 1612 	mov	dpl,a
      00587C 74 C0            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      00587E 12 5C 00         [24] 1614 	lcall	_ak820_outline_0112
      005881 FD               [12] 1615 	mov	r5,a
      005882 90 06 E7         [24] 1616 	mov	dptr,#_frame_phase
      005885 E0               [24] 1617 	movx	a,@dptr
      005886 FC               [12] 1618 	mov	r4,a
      005887 ED               [12] 1619 	mov	a,r5
      005888 C3               [12] 1620 	clr	c
      005889 9C               [12] 1621 	subb	a,r4
      00588A 2E               [12] 1622 	add	a, r6
      00588B 90 07 4D         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00588E F0               [24] 1624 	movx	@dptr,a
      00588F                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00588F 12 5C 0E         [24] 1627 	lcall	_ak820_outline_0143
      005892 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005895 12 5C 1F         [24] 1630 	lcall	_ak820_outline_0176
      005898 FE               [12] 1631 	mov	r6,a
      005899 74 07            [12] 1632 	mov	a,#0x07
      00589B C3               [12] 1633 	clr	c
      00589C 9E               [12] 1634 	subb	a,r6
      00589D FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00589E 8E F0            [24] 1637 	mov	b,r6
      0058A0 05 F0            [12] 1638 	inc	b
      0058A2 74 01            [12] 1639 	mov	a,#0x01
      0058A4 80 02            [24] 1640 	sjmp	00273$
      0058A6                       1641 00272$:
      0058A6 25 E0            [12] 1642 	add	a,acc
      0058A8                       1643 00273$:
      0058A8 D5 F0 FB         [24] 1644 	djnz	b,00272$
      0058AB FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      0058AC 12 5C 31         [24] 1647 	lcall	_ak820_outline_0188
      0058AF 24 E8            [12] 1648 	add	a, #_reactive_age
      0058B1 F5 82            [12] 1649 	mov	dpl,a
      0058B3 E4               [12] 1650 	clr	a
      0058B4 34 06            [12] 1651 	addc	a, #(_reactive_age >> 8)
      0058B6 F5 83            [12] 1652 	mov	dph,a
      0058B8 E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      0058B9 FC               [12] 1655 	mov	r4,a
      0058BA C3               [12] 1656 	clr	c
      0058BB 9D               [12] 1657 	subb	a,r5
      0058BC 40 07            [24] 1658 	jc	00137$
      0058BE 90 06 E5         [24] 1659 	mov	dptr,#_frame_val
      0058C1 E0               [24] 1660 	movx	a,@dptr
      0058C2 FB               [12] 1661 	mov	r3,a
      0058C3 80 1F            [24] 1662 	sjmp	00138$
      0058C5                       1663 00137$:
      0058C5 90 06 E5         [24] 1664 	mov	dptr,#_frame_val
      0058C8 E0               [24] 1665 	movx	a,@dptr
      0058C9 F5 F0            [12] 1666 	mov	b, a
      0058CB EC               [12] 1667 	mov	a,r4
      0058CC A4               [48] 1668 	mul	ab
      0058CD FC               [12] 1669 	mov	r4,a
      0058CE AA F0            [24] 1670 	mov	r2,b
      0058D0 8E F0            [24] 1671 	mov	b,r6
      0058D2 05 F0            [12] 1672 	inc	b
      0058D4 AB 04            [24] 1673 	mov	r3,ar4
      0058D6 AD 02            [24] 1674 	mov	r5,ar2
      0058D8 80 07            [24] 1675 	sjmp	00276$
      0058DA                       1676 00275$:
      0058DA C3               [12] 1677 	clr	c
      0058DB ED               [12] 1678 	mov	a,r5
      0058DC 13               [12] 1679 	rrc	a
      0058DD FD               [12] 1680 	mov	r5,a
      0058DE EB               [12] 1681 	mov	a,r3
      0058DF 13               [12] 1682 	rrc	a
      0058E0 FB               [12] 1683 	mov	r3,a
      0058E1                       1684 00276$:
      0058E1 D5 F0 F6         [24] 1685 	djnz	b,00275$
      0058E4                       1686 00138$:
      0058E4 90 07 4F         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0058E7 EB               [12] 1688 	mov	a,r3
      0058E8 F0               [24] 1689 	movx	@dptr,a
      0058E9                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0058E9 12 5C 0E         [24] 1692 	lcall	_ak820_outline_0143
      0058EC BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      0058EF D3               [12] 1694 	setb	c
      0058F0 80 01            [24] 1695 	sjmp	00278$
      0058F2                       1696 00277$:
      0058F2 C3               [12] 1697 	clr	c
      0058F3                       1698 00278$:
      0058F3 B3               [12] 1699 	cpl	c
      0058F4 92 15            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      0058F6 90 0D F2         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      0058F9 74 4D            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0058FB F0               [24] 1703 	movx	@dptr,a
      0058FC 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0058FE 12 5B E8         [24] 1705 	lcall	_ak820_outline_0073
      005901 90 0A F7         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005904 F5 F0            [12] 1707 	mov	b,a
      005906 12 BC FA         [24] 1708 	lcall	___memcpy
      005909 90 0A FA         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      00590C 74 50            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      00590E F0               [24] 1711 	movx	@dptr,a
      00590F 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005911 A3               [24] 1713 	inc	dptr
      005912 F0               [24] 1714 	movx	@dptr,a
      005913 A2 15            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      005915 12 3B 22         [24] 1716 	lcall	_ak820_outline_0163
      005918 12 86 C6         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00591B 12 5C 31         [24] 1719 	lcall	_ak820_outline_0188
      00591E FD               [12] 1720 	mov	r5,a
      00591F 7E 00            [12] 1721 	mov	r6,#0x00
      005921 90 07 51         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005924 E0               [24] 1723 	movx	a,@dptr
      005925 FC               [12] 1724 	mov	r4,a
      005926 90 07 50         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      005929 E0               [24] 1726 	movx	a,@dptr
      00592A FB               [12] 1727 	mov	r3,a
      00592B 90 07 52         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      00592E E0               [24] 1729 	movx	a,@dptr
      00592F FA               [12] 1730 	mov	r2,a
      005930 90 07 40         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005933 EC               [12] 1732 	mov	a,r4
      005934 F0               [24] 1733 	movx	@dptr,a
      005935 90 07 41         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005938 EB               [12] 1735 	mov	a,r3
      005939 F0               [24] 1736 	movx	@dptr,a
      00593A 90 07 42         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00593D EA               [12] 1738 	mov	a,r2
      00593E F0               [24] 1739 	movx	@dptr,a
      00593F 12 3B 12         [24] 1740 	lcall	_ak820_outline_0137
      005942 12 55 E9         [24] 1741 	lcall	_rgb_matrix_set_color
      005945                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005945 12 5C 31         [24] 1744 	lcall	_ak820_outline_0188
      005948 24 01            [12] 1745 	add	a, #0x01
      00594A F0               [24] 1746 	movx	@dptr,a
      00594B 02 57 E0         [24] 1747 	ljmp	00125$
      00594E                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      00594E BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      005951 C2 14            [12] 1753 	clr	_rendering
      005953                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005953 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      005954                       1770 _process_rgb_matrix:
      005954 E5 82            [12] 1771 	mov	a,dpl
      005956 90 07 55         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005959 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00595A 90 07 54         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      00595D E0               [24] 1776 	movx	a,@dptr
      00595E 60 23            [24] 1777 	jz	00101$
      005960 20 12 20         [24] 1778 	jb	_suspended,00101$
      005963 12 5B D7         [24] 1779 	lcall	_ak820_outline_0066
      005966 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005968 12 5B B8         [24] 1782 	lcall	_ak820_outline_0019
      00596B FF               [12] 1783 	mov	r7,a
      00596C BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      00596F 90 07 55         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005972 E0               [24] 1786 	movx	a,@dptr
      005973 FF               [12] 1787 	mov	r7,a
      005974 BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      005977                       1789 00169$:
      005977 50 0A            [24] 1790 	jnc	00101$
      005979 90 07 53         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      00597C E0               [24] 1792 	movx	a,@dptr
      00597D FE               [12] 1793 	mov	r6,a
      00597E BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      005981                       1795 00171$:
      005981 40 01            [24] 1796 	jc	00102$
      005983                       1797 00101$:
      005983 22               [24] 1798 	ret
      005984                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005984 C0 07            [24] 1801 	push	ar7
      005986 C0 06            [24] 1802 	push	ar6
      005988 12 54 78         [24] 1803 	lcall	_age_reactive
      00598B D0 06            [24] 1804 	pop	ar6
      00598D D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      00598F EF               [12] 1807 	mov	a,r7
      005990 12 3B 37         [24] 1808 	lcall	_ak820_outline_0193
      005993 2E               [12] 1809 	add	a,r6
      005994 FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005995 7E 00            [12] 1812 	mov	r6,#0x00
      005997                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005997 EE               [12] 1815 	mov	a,r6
      005998 90 BE 03         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      00599B 93               [24] 1817 	movc	a,@a+dptr
      00599C B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      00599F EE               [12] 1820 	mov	a,r6
      0059A0 24 E8            [12] 1821 	add	a, #_reactive_age
      0059A2 FC               [12] 1822 	mov	r4,a
      0059A3 E4               [12] 1823 	clr	a
      0059A4 34 06            [12] 1824 	addc	a, #(_reactive_age >> 8)
      0059A6 FD               [12] 1825 	mov	r5,a
      0059A7 12 5C 1F         [24] 1826 	lcall	_ak820_outline_0176
      0059AA F5 F0            [12] 1827 	mov	b, a
      0059AC 05 F0            [12] 1828 	inc	b
      0059AE 7B 80            [12] 1829 	mov	r3,#0x80
      0059B0 E4               [12] 1830 	clr	a
      0059B1 FA               [12] 1831 	mov	r2,a
      0059B2 33               [12] 1832 	rlc	a
      0059B3 92 D2            [24] 1833 	mov	ov,c
      0059B5 80 08            [24] 1834 	sjmp	00176$
      0059B7                       1835 00175$:
      0059B7 A2 D2            [12] 1836 	mov	c,ov
      0059B9 EA               [12] 1837 	mov	a,r2
      0059BA 13               [12] 1838 	rrc	a
      0059BB FA               [12] 1839 	mov	r2,a
      0059BC EB               [12] 1840 	mov	a,r3
      0059BD 13               [12] 1841 	rrc	a
      0059BE FB               [12] 1842 	mov	r3,a
      0059BF                       1843 00176$:
      0059BF D5 F0 F5         [24] 1844 	djnz	b,00175$
      0059C2 12 3B 08         [24] 1845 	lcall	_ak820_outline_0126
      0059C5 EB               [12] 1846 	mov	a,r3
      0059C6 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      0059C7 22               [24] 1849 	ret
      0059C8                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0059C8 0E               [12] 1852 	inc	r6
      0059C9 BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      0059CC                       1854 00177$:
      0059CC 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      0059CE 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      0059CF                       1868 _rgb_matrix_set_suspend_state:
      0059CF E5 82            [12] 1869 	mov	a,dpl
      0059D1 90 07 56         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0059D4 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0059D5 E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      0059D6 F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0059D8 13               [12] 1876 	rrc	a
      0059D9 92 12            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      0059DB C2 14            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0059DD 12 54 5B         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0059E0 E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0059E2 60 0F            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0059E4 90 07 45         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0059E7 E4               [12] 1888 	clr	a
      0059E8 F0               [24] 1889 	movx	@dptr,a
      0059E9 90 07 46         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0059EC F0               [24] 1891 	movx	@dptr,a
      0059ED 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0059F0 02 56 2A         [24] 1894 	ljmp	_rgb_matrix_set_color_all
      0059F3                       1895 00103$:
      0059F3 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      0059F4                       1904 _rgb_matrix_is_enabled:
      0059F4 12 5B D7         [24] 1905 	lcall	_ak820_outline_0066
      0059F7 F5 82            [12] 1906 	mov	dpl,a
      0059F9 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      0059FA                       1915 _rgb_matrix_get_mode:
      0059FA 12 5B B8         [24] 1916 	lcall	_ak820_outline_0019
      0059FD F5 82            [12] 1917 	mov	dpl,a
      0059FF 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      005A00                       1926 _rgb_matrix_get_hue:
      005A00 90 06 D4         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A03 E0               [24] 1928 	movx	a,@dptr
      005A04 F5 82            [12] 1929 	mov	dpl,a
      005A06 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      005A07                       1938 _rgb_matrix_get_sat:
      005A07 90 06 D5         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A0A E0               [24] 1940 	movx	a,@dptr
      005A0B F5 82            [12] 1941 	mov	dpl,a
      005A0D 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      005A0E                       1950 _rgb_matrix_get_val:
      005A0E 90 06 D6         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005A11 E0               [24] 1952 	movx	a,@dptr
      005A12 F5 82            [12] 1953 	mov	dpl,a
      005A14 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      005A15                       1962 _rgb_matrix_get_speed:
      005A15 90 06 D7         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005A18 E0               [24] 1964 	movx	a,@dptr
      005A19 F5 82            [12] 1965 	mov	dpl,a
      005A1B 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      005A1C                       1974 _rgb_matrix_toggle_noeeprom:
      005A1C 12 5B D7         [24] 1975 	lcall	_ak820_outline_0066
      005A1F FF               [12] 1976 	mov	r7,a
      005A20 63 07 01         [24] 1977 	xrl	ar7,#0x01
      005A23 90 06 D3         [24] 1978 	mov	dptr,#_rgb_matrix_config
      005A26 EF               [12] 1979 	mov	a,r7
      005A27 54 03            [12] 1980 	anl	a,#0x03
      005A29 F5 F0            [12] 1981 	mov	b,a
      005A2B E0               [24] 1982 	movx	a,@dptr
      005A2C 54 FC            [12] 1983 	anl	a,#0xfc
      005A2E 45 F0            [12] 1984 	orl	a,b
      005A30 F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      005A31 C2 14            [12] 1987 	clr	_rendering
      005A33 02 54 5B         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      005A36                       1996 _rgb_matrix_enable_noeeprom:
      005A36 12 5B D7         [24] 1997 	lcall	_ak820_outline_0066
      005A39 70 03            [24] 1998 	jnz	00102$
      005A3B 12 54 5B         [24] 1999 	lcall	_clear_reactive
      005A3E                       2000 00102$:
      005A3E 12 5C 07         [24] 2001 	lcall	_ak820_outline_0117
      005A41 44 01            [12] 2002 	orl	a,#0x01
      005A43 F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      005A44 C2 14            [12] 2005 	clr	_rendering
      005A46 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      005A47                       2014 _rgb_matrix_disable_noeeprom:
      005A47 12 5C 07         [24] 2015 	lcall	_ak820_outline_0117
      005A4A F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      005A4B C2 14            [12] 2018 	clr	_rendering
      005A4D 02 54 5B         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      005A50                       2029 _rgb_matrix_mode_noeeprom:
      005A50 E5 82            [12] 2030 	mov	a,dpl
      005A52 90 07 57         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A55 F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005A56 E0               [24] 2034 	movx	a,@dptr
      005A57 FF               [12] 2035 	mov	r7,a
      005A58 60 05            [24] 2036 	jz	00101$
      005A5A BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      005A5D                       2038 00123$:
      005A5D 40 01            [24] 2039 	jc	00102$
      005A5F                       2040 00101$:
      005A5F 22               [24] 2041 	ret
      005A60                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005A60 12 5B B8         [24] 2044 	lcall	_ak820_outline_0019
      005A63 FE               [12] 2045 	mov	r6,a
      005A64 EF               [12] 2046 	mov	a,r7
      005A65 B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      005A68 80 03            [24] 2048 	sjmp	00105$
      005A6A                       2049 00125$:
      005A6A 12 54 5B         [24] 2050 	lcall	_clear_reactive
      005A6D                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005A6D 90 07 57         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A70 E0               [24] 2054 	movx	a,@dptr
      005A71 90 06 D3         [24] 2055 	mov	dptr,#_rgb_matrix_config
      005A74 25 E0            [12] 2056 	add	a,acc
      005A76 25 E0            [12] 2057 	add	a,acc
      005A78 54 FC            [12] 2058 	anl	a,#0xfc
      005A7A F5 F0            [12] 2059 	mov	b,a
      005A7C E0               [24] 2060 	movx	a,@dptr
      005A7D 54 03            [12] 2061 	anl	a,#0x03
      005A7F 45 F0            [12] 2062 	orl	a,b
      005A81 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      005A82 C2 14            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005A84 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      005A85                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005A85 12 5B B8         [24] 2078 	lcall	_ak820_outline_0019
      005A88 FF               [12] 2079 	mov	r7,a
      005A89 0F               [12] 2080 	inc	r7
      005A8A BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      005A8D                       2082 00112$:
      005A8D 40 04            [24] 2083 	jc	00103$
      005A8F 7F 01            [12] 2084 	mov	r7,#0x01
      005A91 80 07            [24] 2085 	sjmp	00104$
      005A93                       2086 00103$:
      005A93 12 5B B8         [24] 2087 	lcall	_ak820_outline_0019
      005A96 FE               [12] 2088 	mov	r6,a
      005A97 0E               [12] 2089 	inc	r6
      005A98 8E 07            [24] 2090 	mov	ar7,r6
      005A9A                       2091 00104$:
      005A9A 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005A9C 41 50            [12] 2094 	ajmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      005A9E                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005A9E 12 5B B8         [24] 2104 	lcall	_ak820_outline_0019
      005AA1 24 FE            [12] 2105 	add	a,#0xff - 0x01
      005AA3 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      005AA5 7F 06            [12] 2108 	mov	r7,#0x06
      005AA7 80 05            [24] 2109 	sjmp	00104$
      005AA9                       2110 00103$:
      005AA9 12 5B B8         [24] 2111 	lcall	_ak820_outline_0019
      005AAC 14               [12] 2112 	dec	a
      005AAD FF               [12] 2113 	mov	r7,a
      005AAE                       2114 00104$:
      005AAE 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005AB0 41 50            [12] 2117 	ajmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      005AB2                       2129 _rgb_matrix_sethsv_noeeprom:
      005AB2 12 3A F3         [24] 2130 	lcall	_ak820_outline_0110
      005AB5 90 07 5A         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005AB8 12 3A F8         [24] 2132 	lcall	_ak820_outline_0111
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005ABB 90 07 5A         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005ABE E0               [24] 2135 	movx	a,@dptr
      005ABF 90 06 D4         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AC2 F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005AC3 90 07 58         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005AC6 E0               [24] 2140 	movx	a,@dptr
      005AC7 FF               [12] 2141 	mov	r7,a
      005AC8 90 06 D5         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005ACB F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005ACC 90 07 59         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005ACF E0               [24] 2146 	movx	a,@dptr
      005AD0 FF               [12] 2147 	mov  r7,a
      005AD1 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      005AD3 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      005AD5 7E A0            [12] 2151 	mov	r6,#0xa0
      005AD7 80 02            [24] 2152 	sjmp	00104$
      005AD9                       2153 00103$:
      005AD9 8F 06            [24] 2154 	mov	ar6,r7
      005ADB                       2155 00104$:
      005ADB 90 06 D6         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005ADE EE               [12] 2157 	mov	a,r6
      005ADF F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005AE0 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      005AE1                       2170 _rgb_matrix_set_speed_noeeprom:
      005AE1 E5 82            [12] 2171 	mov	a,dpl
      005AE3 90 07 5C         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005AE6 F0               [24] 2173 	movx	@dptr,a
      005AE7 E0               [24] 2174 	movx	a,@dptr
      005AE8 90 06 D7         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AEB F0               [24] 2176 	movx	@dptr,a
      005AEC 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      005AED                       2187 _rgb_matrix_increase_hue_noeeprom:
      005AED 90 06 D4         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AF0 E0               [24] 2189 	movx	a,@dptr
      005AF1 24 08            [12] 2190 	add	a,#0x08
      005AF3 90 06 D4         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AF6 F0               [24] 2192 	movx	@dptr,a
      005AF7 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      005AF8                       2201 _rgb_matrix_decrease_hue_noeeprom:
      005AF8 90 06 D4         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AFB E0               [24] 2203 	movx	a,@dptr
      005AFC 24 F8            [12] 2204 	add	a,#0xf8
      005AFE 90 06 D4         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005B01 F0               [24] 2206 	movx	@dptr,a
      005B02 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      005B03                       2215 _rgb_matrix_increase_sat_noeeprom:
      005B03 90 06 D5         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005B06 12 5B C1         [24] 2217 	lcall	_ak820_outline_0048
      005B09 12 54 F6         [24] 2218 	lcall	_add_sat
      005B0C AF 82            [24] 2219 	mov	r7, dpl
      005B0E 90 06 D5         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005B11 EF               [12] 2221 	mov	a,r7
      005B12 F0               [24] 2222 	movx	@dptr,a
      005B13 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      005B14                       2231 _rgb_matrix_decrease_sat_noeeprom:
      005B14 90 06 D5         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005B17 12 5B CC         [24] 2233 	lcall	_ak820_outline_0049
      005B1A 12 55 1B         [24] 2234 	lcall	_sub_sat
      005B1D AF 82            [24] 2235 	mov	r7, dpl
      005B1F 90 06 D5         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005B22 EF               [12] 2237 	mov	a,r7
      005B23 F0               [24] 2238 	movx	@dptr,a
      005B24 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      005B25                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005B25 90 06 D6         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B28 12 5B C1         [24] 2252 	lcall	_ak820_outline_0048
      005B2B 12 54 F6         [24] 2253 	lcall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005B2E E5 82            [12] 2255 	mov	a,dpl
      005B30 FF               [12] 2256 	mov	r7,a
      005B31 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      005B33 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      005B35 7E A0            [12] 2260 	mov	r6,#0xa0
      005B37 80 02            [24] 2261 	sjmp	00104$
      005B39                       2262 00103$:
      005B39 8F 06            [24] 2263 	mov	ar6,r7
      005B3B                       2264 00104$:
      005B3B 90 06 D6         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B3E EE               [12] 2266 	mov	a,r6
      005B3F F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005B40 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      005B41                       2277 _rgb_matrix_decrease_val_noeeprom:
      005B41 90 06 D6         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B44 12 5B CC         [24] 2279 	lcall	_ak820_outline_0049
      005B47 12 55 1B         [24] 2280 	lcall	_sub_sat
      005B4A AF 82            [24] 2281 	mov	r7, dpl
      005B4C 90 06 D6         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B4F EF               [12] 2283 	mov	a,r7
      005B50 F0               [24] 2284 	movx	@dptr,a
      005B51 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      005B52                       2293 _rgb_matrix_increase_speed_noeeprom:
      005B52 90 06 D7         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B55 12 5B C1         [24] 2295 	lcall	_ak820_outline_0048
      005B58 12 54 F6         [24] 2296 	lcall	_add_sat
      005B5B AF 82            [24] 2297 	mov	r7, dpl
      005B5D 90 06 D7         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B60 EF               [12] 2299 	mov	a,r7
      005B61 F0               [24] 2300 	movx	@dptr,a
      005B62 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      005B63                       2309 _rgb_matrix_decrease_speed_noeeprom:
      005B63 90 06 D7         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B66 12 5B CC         [24] 2311 	lcall	_ak820_outline_0049
      005B69 12 55 1B         [24] 2312 	lcall	_sub_sat
      005B6C AF 82            [24] 2313 	mov	r7, dpl
      005B6E 90 06 D7         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B71 EF               [12] 2315 	mov	a,r7
      005B72 F0               [24] 2316 	movx	@dptr,a
      005B73 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      005B74                       2325 _rgb_matrix_toggle:
      005B74 51 1C            [12] 2326 	acall	_rgb_matrix_toggle_noeeprom
      005B76 02 55 38         [24] 2327 	ljmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      005B79                       2335 _rgb_matrix_step:
      005B79 51 85            [12] 2336 	acall	_rgb_matrix_step_noeeprom
      005B7B 02 55 38         [24] 2337 	ljmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      005B7E                       2345 _rgb_matrix_step_reverse:
      005B7E 51 9E            [12] 2346 	acall	_rgb_matrix_step_reverse_noeeprom
      005B80 02 55 38         [24] 2347 	ljmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      005B83                       2355 _rgb_matrix_increase_hue:
      005B83 51 ED            [12] 2356 	acall	_rgb_matrix_increase_hue_noeeprom
      005B85 02 55 38         [24] 2357 	ljmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      005B88                       2365 _rgb_matrix_decrease_hue:
      005B88 51 F8            [12] 2366 	acall	_rgb_matrix_decrease_hue_noeeprom
      005B8A 02 55 38         [24] 2367 	ljmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      005B8D                       2375 _rgb_matrix_increase_sat:
      005B8D 71 03            [12] 2376 	acall	_rgb_matrix_increase_sat_noeeprom
      005B8F 02 55 38         [24] 2377 	ljmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      005B92                       2385 _rgb_matrix_decrease_sat:
      005B92 71 14            [12] 2386 	acall	_rgb_matrix_decrease_sat_noeeprom
      005B94 02 55 38         [24] 2387 	ljmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      005B97                       2395 _rgb_matrix_increase_val:
      005B97 71 25            [12] 2396 	acall	_rgb_matrix_increase_val_noeeprom
      005B99 02 55 38         [24] 2397 	ljmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      005B9C                       2405 _rgb_matrix_decrease_val:
      005B9C 71 41            [12] 2406 	acall	_rgb_matrix_decrease_val_noeeprom
      005B9E 02 55 38         [24] 2407 	ljmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      005BA1                       2415 _rgb_matrix_increase_speed:
      005BA1 71 52            [12] 2416 	acall	_rgb_matrix_increase_speed_noeeprom
      005BA3 02 55 38         [24] 2417 	ljmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      005BA6                       2425 _rgb_matrix_decrease_speed:
      005BA6 71 63            [12] 2426 	acall	_rgb_matrix_decrease_speed_noeeprom
      005BA8 02 55 38         [24] 2427 	ljmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      005BAB                       2437 _rgb_matrix_mode:
      005BAB E5 82            [12] 2438 	mov	a,dpl
      005BAD 90 07 5D         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005BB0 12 5C 1A         [24] 2440 	lcall	_ak820_outline_0173
      005BB3 51 50            [12] 2441 	acall	_rgb_matrix_mode_noeeprom
      005BB5 02 55 38         [24] 2442 	ljmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00BE55                       2455 _sine8_coefficients_10000_290:
      00BE55 00                    2456 	.db #0x00	; 0
      00BE56 31                    2457 	.db #0x31	; 49	'1'
      00BE57 31                    2458 	.db #0x31	; 49	'1'
      00BE58 29                    2459 	.db #0x29	; 41
      00BE59 5A                    2460 	.db #0x5a	; 90	'Z'
      00BE5A 1B                    2461 	.db #0x1b	; 27
      00BE5B 75                    2462 	.db #0x75	; 117	'u'
      00BE5C 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0052
                                   2474 	.globl _ak820_outline_0060
                                   2475 	.globl _ak820_outline_0061
                                   2476 	.globl _ak820_outline_0066
                                   2477 	.globl _ak820_outline_0070
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0087
                                   2480 	.globl _ak820_outline_0104
                                   2481 	.globl _ak820_outline_0106
                                   2482 	.globl _ak820_outline_0110
                                   2483 	.globl _ak820_outline_0111
                                   2484 	.globl _ak820_outline_0112
                                   2485 	.globl _ak820_outline_0117
                                   2486 	.globl _ak820_outline_0126
                                   2487 	.globl _ak820_outline_0127
                                   2488 	.globl _ak820_outline_0136
                                   2489 	.globl _ak820_outline_0137
                                   2490 	.globl _ak820_outline_0140
                                   2491 	.globl _ak820_outline_0143
                                   2492 	.globl _ak820_outline_0163
                                   2493 	.globl _ak820_outline_0172
                                   2494 	.globl _ak820_outline_0173
                                   2495 	.globl _ak820_outline_0176
                                   2496 	.globl _ak820_outline_0181
                                   2497 	.globl _ak820_outline_0188
                                   2498 	.globl _ak820_outline_0190
                                   2499 	.globl _ak820_outline_0193
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      005BB8                       2503 _ak820_outline_0019:
      005BB8 90 06 D3         [24] 2504 	mov	dptr,#_rgb_matrix_config
      005BBB E0               [24] 2505 	movx	a,@dptr
      005BBC 03               [12] 2506 	rr	a
      005BBD 03               [12] 2507 	rr	a
      005BBE 54 3F            [12] 2508 	anl	a,#0x3f
      005BC0 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      005BC1                       2513 _ak820_outline_0048:
      005BC1 E0               [24] 2514 	movx	a,@dptr
      005BC2 FF               [12] 2515 	mov	r7,a
      005BC3 90 07 3C         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      005BC6 74 10            [12] 2517 	mov	a,#0x10
      005BC8 F0               [24] 2518 	movx	@dptr,a
      005BC9 8F 82            [24] 2519 	mov	dpl,r7
      005BCB 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      005BCC                       2524 _ak820_outline_0049:
      005BCC E0               [24] 2525 	movx	a,@dptr
      005BCD FF               [12] 2526 	mov	r7,a
      005BCE 90 07 3E         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005BD1 74 10            [12] 2528 	mov	a,#0x10
      005BD3 F0               [24] 2529 	movx	@dptr,a
      005BD4 8F 82            [24] 2530 	mov	dpl,r7
      005BD6 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0066
      005BD7                       2535 _ak820_outline_0066:
      005BD7 90 06 D3         [24] 2536 	mov	dptr,#_rgb_matrix_config
      005BDA E0               [24] 2537 	movx	a,@dptr
      005BDB 54 03            [12] 2538 	anl	a,#0x03
      005BDD 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0070
      005BDE                       2543 _ak820_outline_0070:
      005BDE 74 08            [12] 2544 	mov	a,#0x08
      005BE0 F0               [24] 2545 	movx	@dptr,a
      005BE1 E4               [12] 2546 	clr	a
      005BE2 A3               [24] 2547 	inc	dptr
      005BE3 F0               [24] 2548 	movx	@dptr,a
      005BE4 90 06 D3         [24] 2549 	mov	dptr,#_rgb_matrix_config
      005BE7 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      005BE8                       2554 _ak820_outline_0073:
      005BE8 A3               [24] 2555 	inc	dptr
      005BE9 F0               [24] 2556 	movx	@dptr,a
      005BEA E4               [12] 2557 	clr	a
      005BEB A3               [24] 2558 	inc	dptr
      005BEC F0               [24] 2559 	movx	@dptr,a
      005BED 90 0D F5         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      005BF0 74 03            [12] 2561 	mov	a,#0x03
      005BF2 F0               [24] 2562 	movx	@dptr,a
      005BF3 E4               [12] 2563 	clr	a
      005BF4 A3               [24] 2564 	inc	dptr
      005BF5 F0               [24] 2565 	movx	@dptr,a
      005BF6 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0087
      005BF7                       2570 _ak820_outline_0087:
      005BF7 74 18            [12] 2571 	mov	a,#0x18
      005BF9 F0               [24] 2572 	movx	@dptr,a
      005BFA E4               [12] 2573 	clr	a
      005BFB A3               [24] 2574 	inc	dptr
      005BFC F0               [24] 2575 	movx	@dptr,a
      005BFD A3               [24] 2576 	inc	dptr
      005BFE F0               [24] 2577 	movx	@dptr,a
      005BFF 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0112
      005C00                       2582 _ak820_outline_0112:
      005C00 35 F0            [12] 2583 	addc	a,b
      005C02 F5 83            [12] 2584 	mov	dph,a
      005C04 E4               [12] 2585 	clr	a
      005C05 93               [24] 2586 	movc	a,@a+dptr
      005C06 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0117
      005C07                       2591 _ak820_outline_0117:
      005C07 90 06 D3         [24] 2592 	mov	dptr,#_rgb_matrix_config
      005C0A E0               [24] 2593 	movx	a,@dptr
      005C0B 54 FC            [12] 2594 	anl	a,#0xfc
      005C0D 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0143
      005C0E                       2599 _ak820_outline_0143:
      005C0E 90 06 E2         [24] 2600 	mov	dptr,#_frame_mode
      005C11 E0               [24] 2601 	movx	a,@dptr
      005C12 FE               [12] 2602 	mov	r6,a
      005C13 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0172
      005C14                       2607 _ak820_outline_0172:
      005C14 F0               [24] 2608 	movx	@dptr,a
      005C15 E5 F0            [12] 2609 	mov	a,b
      005C17 A3               [24] 2610 	inc	dptr
      005C18 F0               [24] 2611 	movx	@dptr,a
      005C19 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0173
      005C1A                       2616 _ak820_outline_0173:
      005C1A F0               [24] 2617 	movx	@dptr,a
      005C1B E0               [24] 2618 	movx	a,@dptr
      005C1C F5 82            [12] 2619 	mov	dpl,a
      005C1E 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0176
      005C1F                       2624 _ak820_outline_0176:
      005C1F 90 06 D7         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005C22 E0               [24] 2626 	movx	a,@dptr
      005C23 23               [12] 2627 	rl	a
      005C24 23               [12] 2628 	rl	a
      005C25 54 03            [12] 2629 	anl	a,#0x03
      005C27 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0181
      005C28                       2634 _ak820_outline_0181:
      005C28 90 0D FA         [24] 2635 	mov	dptr,#_memset_PARM_2
      005C2B E4               [12] 2636 	clr	a
      005C2C F0               [24] 2637 	movx	@dptr,a
      005C2D 90 0D FB         [24] 2638 	mov	dptr,#_memset_PARM_3
      005C30 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0188
      005C31                       2643 _ak820_outline_0188:
      005C31 90 06 E1         [24] 2644 	mov	dptr,#_led_index
      005C34 E0               [24] 2645 	movx	a,@dptr
      005C35 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0190
      005C36                       2650 _ak820_outline_0190:
      005C36 C4               [12] 2651 	swap	a
      005C37 23               [12] 2652 	rl	a
      005C38 54 1F            [12] 2653 	anl	a,#0x1f
      005C3A 22               [24] 2654 	ret
