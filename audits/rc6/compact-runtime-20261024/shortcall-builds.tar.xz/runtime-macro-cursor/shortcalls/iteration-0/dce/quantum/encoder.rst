                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoder
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _encoder_wait_pullup_charge
                                     12 	.globl _tap_code_delay
                                     13 	.globl _ak820_action_exec
                                     14 	.globl _is_keyboard_master
                                     15 	.globl _timer_read
                                     16 	.globl _mDelayuS
                                     17 	.globl _readPin
                                     18 	.globl _pinModeInputHighQMK
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _encoder_init
                                    263 	.globl _encoder_read
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000B8A                        550 _thisCount:
      000B8A                        551 	.ds 1
      000B8B                        552 _encoder_exec_mapping_PARM_2:
      000B8B                        553 	.ds 1
      000B8C                        554 _encoder_exec_mapping_index_10000_166:
      000B8C                        555 	.ds 1
      000B8D                        556 _encoder_exec_mapping_dummy_event_30000_169:
      000B8D                        557 	.ds 6
      000B93                        558 _encoder_exec_mapping_dummy_event_30000_170:
      000B93                        559 	.ds 6
      000B99                        560 _encoder_exec_mapping_dummy_event_30000_172:
      000B99                        561 	.ds 6
      000B9F                        562 _encoder_exec_mapping_dummy_event_30000_173:
      000B9F                        563 	.ds 6
      000BA5                        564 _encoder_update_PARM_2:
      000BA5                        565 	.ds 1
      000BA6                        566 _encoder_update_index_10000_174:
      000BA6                        567 	.ds 1
      000BA7                        568 _encoder_update_changed_10000_175:
      000BA7                        569 	.ds 1
      000BA8                        570 _encoder_read_changed_10000_181:
      000BA8                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000E3C                        580 _encoders_pad_a:
      000E3C                        581 	.ds 1
      000E3D                        582 _encoders_pad_b:
      000E3D                        583 	.ds 1
      000E3E                        584 _encoder_LUT:
      000E3E                        585 	.ds 16
      000E4E                        586 _encoder_state:
      000E4E                        587 	.ds 1
      000E4F                        588 _encoder_pulses:
      000E4F                        589 	.ds 1
      000E50                        590 _encoder_value:
      000E50                        591 	.ds 1
                                    592 	.area HOME    (CODE)
                                    593 	.area GSINIT0 (CODE)
                                    594 	.area GSINIT1 (CODE)
                                    595 	.area GSINIT2 (CODE)
                                    596 	.area GSINIT3 (CODE)
                                    597 	.area GSINIT4 (CODE)
                                    598 	.area GSINIT5 (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area CSEG    (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; global & static initialisations
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area GSINIT  (CODE)
                                    607 	.area GSFINAL (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 ;--------------------------------------------------------
                                    610 ; Home
                                    611 ;--------------------------------------------------------
                                    612 	.area HOME    (CODE)
                                    613 	.area HOME    (CODE)
                                    614 ;--------------------------------------------------------
                                    615 ; code
                                    616 ;--------------------------------------------------------
                                    617 	.area CSEG    (CODE)
                                    618 ;------------------------------------------------------------
                                    619 ;Allocation info for local variables in function 'encoder_wait_pullup_charge'
                                    620 ;------------------------------------------------------------
                                    621 ;i             Allocated with name '_encoder_wait_pullup_charge_i_30000_147'
                                    622 ;------------------------------------------------------------
                                    623 ;	quantum/encoder.c:77: __attribute__((weak)) void encoder_wait_pullup_charge(void) {
                                    624 ;	-----------------------------------------
                                    625 ;	 function encoder_wait_pullup_charge
                                    626 ;	-----------------------------------------
      00955B                        627 _encoder_wait_pullup_charge:
                           000007   628 	ar7 = 0x07
                           000006   629 	ar6 = 0x06
                           000005   630 	ar5 = 0x05
                           000004   631 	ar4 = 0x04
                           000003   632 	ar3 = 0x03
                           000002   633 	ar2 = 0x02
                           000001   634 	ar1 = 0x01
                           000000   635 	ar0 = 0x00
                                    636 ;	quantum/encoder.c:78: wait_us(100);
      00955B 7F 64            [12]  637 	mov	r7,#0x64
      00955D                        638 00106$:
      00955D EF               [12]  639 	mov	a,r7
      00955E 60 0D            [24]  640 	jz	00108$
      009560 90 00 01         [24]  641 	mov	dptr,#0x0001
      009563 C0 07            [24]  642 	push	ar7
      009565 12 5D 79         [24]  643 	lcall	_mDelayuS
      009568 D0 07            [24]  644 	pop	ar7
      00956A 1F               [12]  645 	dec	r7
      00956B 80 F0            [24]  646 	sjmp	00106$
      00956D                        647 00108$:
                                    648 ;	quantum/encoder.c:79: }
      00956D 22               [24]  649 	ret
                                    650 ;------------------------------------------------------------
                                    651 ;Allocation info for local variables in function 'encoder_update_user'
                                    652 ;------------------------------------------------------------
                                    653 ;clockwise     Allocated with name '_encoder_update_user_PARM_2'
                                    654 ;index         Allocated with name '_encoder_update_user_index_10000_149'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/encoder.c:81: __attribute__((weak)) bool encoder_update_user(uint8_t index, bool clockwise) {
                                    657 ;	-----------------------------------------
                                    658 ;	 function encoder_init
                                    659 ;	-----------------------------------------
      00956E                        660 _encoder_init:
                                    661 ;	quantum/encoder.c:122: thisCount                = NUM_ENCODERS;
      00956E 90 0B 8A         [24]  662 	mov	dptr,#_thisCount
      009571 74 01            [12]  663 	mov	a,#0x01
      009573 F0               [24]  664 	movx	@dptr,a
                                    665 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      009574 7F 00            [12]  666 	mov	r7,#0x00
      009576                        667 00104$:
      009576 12 97 C7         [24]  668 	lcall	_ak820_outline_0091
      009579 50 17            [24]  669 	jnc	00101$
                                    670 ;	quantum/encoder.c:166: setPinInputHigh(encoders_pad_a[i]);
      00957B 12 97 9B         [24]  671 	lcall	_ak820_outline_0028
      00957E C0 07            [24]  672 	push	ar7
      009580 12 5C 3B         [24]  673 	lcall	_pinModeInputHighQMK
      009583 D0 07            [24]  674 	pop	ar7
                                    675 ;	quantum/encoder.c:167: setPinInputHigh(encoders_pad_b[i]);
      009585 12 97 A9         [24]  676 	lcall	_ak820_outline_0029
      009588 C0 07            [24]  677 	push	ar7
      00958A 12 5C 3B         [24]  678 	lcall	_pinModeInputHighQMK
      00958D D0 07            [24]  679 	pop	ar7
                                    680 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      00958F 0F               [12]  681 	inc	r7
      009590 80 E4            [24]  682 	sjmp	00104$
      009592                        683 00101$:
                                    684 ;	quantum/encoder.c:169: encoder_wait_pullup_charge();
      009592 B1 5B            [12]  685 	acall	_encoder_wait_pullup_charge
                                    686 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      009594 7F 00            [12]  687 	mov	r7,#0x00
      009596                        688 00107$:
      009596 12 97 C7         [24]  689 	lcall	_ak820_outline_0091
      009599 50 22            [24]  690 	jnc	00109$
                                    691 ;	quantum/encoder.c:171: encoder_state[i] = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      00959B EF               [12]  692 	mov	a,r7
      00959C 24 4E            [12]  693 	add	a, #_encoder_state
      00959E FD               [12]  694 	mov	r5,a
      00959F E4               [12]  695 	clr	a
      0095A0 34 0E            [12]  696 	addc	a, #(_encoder_state >> 8)
      0095A2 FE               [12]  697 	mov	r6,a
      0095A3 12 97 9B         [24]  698 	lcall	_ak820_outline_0028
      0095A6 12 5C 87         [24]  699 	lcall	_readPin
      0095A9 AC 82            [24]  700 	mov	r4, dpl
      0095AB 12 97 A9         [24]  701 	lcall	_ak820_outline_0029
      0095AE 12 5C 87         [24]  702 	lcall	_readPin
      0095B1 E5 82            [12]  703 	mov	a,dpl
      0095B3 25 82            [12]  704 	add	a,dpl
      0095B5 42 04            [12]  705 	orl	ar4,a
      0095B7 12 45 A8         [24]  706 	lcall	_ak820_outline_0065
                                    707 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      0095BA 0F               [12]  708 	inc	r7
      0095BB 80 D9            [24]  709 	sjmp	00107$
      0095BD                        710 00109$:
                                    711 ;	quantum/encoder.c:173: }
      0095BD 22               [24]  712 	ret
                                    713 ;------------------------------------------------------------
                                    714 ;Allocation info for local variables in function 'encoder_exec_mapping'
                                    715 ;------------------------------------------------------------
                                    716 ;clockwise     Allocated with name '_encoder_exec_mapping_PARM_2'
                                    717 ;index         Allocated with name '_encoder_exec_mapping_index_10000_166'
                                    718 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_169'
                                    719 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_170'
                                    720 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_172'
                                    721 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_30000_173'
                                    722 ;------------------------------------------------------------
                                    723 ;	quantum/encoder.c:176: static void encoder_exec_mapping(uint8_t index, bool clockwise) {
                                    724 ;	-----------------------------------------
                                    725 ;	 function encoder_exec_mapping
                                    726 ;	-----------------------------------------
      0095BE                        727 _encoder_exec_mapping:
      0095BE E5 82            [12]  728 	mov	a,dpl
      0095C0 90 0B 8C         [24]  729 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      0095C3 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/encoder.c:179: if (clockwise) {
      0095C4 90 0B 8B         [24]  732 	mov	dptr,#_encoder_exec_mapping_PARM_2
      0095C7 E0               [24]  733 	movx	a,@dptr
      0095C8 FF               [12]  734 	mov	r7,a
      0095C9 E0               [24]  735 	movx	a,@dptr
      0095CA 60 32            [24]  736 	jz	00102$
                                    737 ;	quantum/encoder.c:180: MAKE_ENCODER_CW_EVENT(index, true);
      0095CC 90 0B 8C         [24]  738 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      0095CF E0               [24]  739 	movx	a,@dptr
      0095D0 90 0B 8D         [24]  740 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_169
      0095D3 F0               [24]  741 	movx	@dptr,a
      0095D4 90 0B 8E         [24]  742 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0001)
      0095D7 74 FD            [12]  743 	mov	a,#0xfd
      0095D9 F0               [24]  744 	movx	@dptr,a
      0095DA 12 4B 9F         [24]  745 	lcall	_timer_read
      0095DD AD 82            [24]  746 	mov	r5, dpl
      0095DF AE 83            [24]  747 	mov	r6, dph
      0095E1 90 0B 8F         [24]  748 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0002)
      0095E4 12 45 D8         [24]  749 	lcall	_ak820_outline_0141
      0095E7 90 0B 91         [24]  750 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0004)
      0095EA 74 02            [12]  751 	mov	a,#0x02
      0095EC F0               [24]  752 	movx	@dptr,a
      0095ED 90 0B 92         [24]  753 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_169 + 0x0005)
      0095F0 14               [12]  754 	dec	a
      0095F1 F0               [24]  755 	movx	@dptr,a
                                    756 ;	quantum/encoder.c:181: AK820_ACTION_EXEC(dummy_event);
      0095F2 90 0B 8D         [24]  757 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_169
      0095F5 C0 07            [24]  758 	push	ar7
      0095F7 12 75 B4         [24]  759 	lcall	_ak820_action_exec
      0095FA D0 07            [24]  760 	pop	ar7
      0095FC 80 31            [24]  761 	sjmp	00103$
      0095FE                        762 00102$:
                                    763 ;	quantum/encoder.c:183: MAKE_ENCODER_CCW_EVENT(index, true);
      0095FE 90 0B 8C         [24]  764 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      009601 E0               [24]  765 	movx	a,@dptr
      009602 90 0B 93         [24]  766 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_170
      009605 F0               [24]  767 	movx	@dptr,a
      009606 90 0B 94         [24]  768 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_170 + 0x0001)
      009609 74 FC            [12]  769 	mov	a,#0xfc
      00960B F0               [24]  770 	movx	@dptr,a
      00960C 12 4B 9F         [24]  771 	lcall	_timer_read
      00960F AD 82            [24]  772 	mov	r5, dpl
      009611 AE 83            [24]  773 	mov	r6, dph
      009613 90 0B 95         [24]  774 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_170 + 0x0002)
      009616 12 45 D8         [24]  775 	lcall	_ak820_outline_0141
      009619 90 0B 97         [24]  776 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_170 + 0x0004)
      00961C 74 03            [12]  777 	mov	a,#0x03
      00961E F0               [24]  778 	movx	@dptr,a
      00961F 90 0B 98         [24]  779 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_170 + 0x0005)
      009622 74 01            [12]  780 	mov	a,#0x01
      009624 F0               [24]  781 	movx	@dptr,a
                                    782 ;	quantum/encoder.c:184: AK820_ACTION_EXEC(dummy_event);
      009625 90 0B 93         [24]  783 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_170
      009628 C0 07            [24]  784 	push	ar7
      00962A 12 75 B4         [24]  785 	lcall	_ak820_action_exec
      00962D D0 07            [24]  786 	pop	ar7
      00962F                        787 00103$:
                                    788 ;	quantum/encoder.c:191: if (clockwise) {
      00962F EF               [12]  789 	mov	a,r7
      009630 60 2B            [24]  790 	jz	00105$
                                    791 ;	quantum/encoder.c:192: MAKE_ENCODER_CW_EVENT(index, false);
      009632 90 0B 8C         [24]  792 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      009635 E0               [24]  793 	movx	a,@dptr
      009636 90 0B 99         [24]  794 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_172
      009639 F0               [24]  795 	movx	@dptr,a
      00963A 90 0B 9A         [24]  796 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0001)
      00963D 74 FD            [12]  797 	mov	a,#0xfd
      00963F F0               [24]  798 	movx	@dptr,a
      009640 12 4B 9F         [24]  799 	lcall	_timer_read
      009643 12 45 CD         [24]  800 	lcall	_ak820_outline_0127
      009646 90 0B 9B         [24]  801 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0002)
      009649 12 4A EC         [24]  802 	lcall	_ak820_outline_0060
      00964C 90 0B 9D         [24]  803 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0004)
      00964F 74 02            [12]  804 	mov	a,#0x02
      009651 F0               [24]  805 	movx	@dptr,a
      009652 90 0B 9E         [24]  806 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_172 + 0x0005)
      009655 E4               [12]  807 	clr	a
      009656 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/encoder.c:193: AK820_ACTION_EXEC(dummy_event);
      009657 90 0B 99         [24]  810 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_172
      00965A 02 75 B4         [24]  811 	ljmp	_ak820_action_exec
      00965D                        812 00105$:
                                    813 ;	quantum/encoder.c:195: MAKE_ENCODER_CCW_EVENT(index, false);
      00965D 90 0B 8C         [24]  814 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      009660 E0               [24]  815 	movx	a,@dptr
      009661 90 0B 9F         [24]  816 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_173
      009664 F0               [24]  817 	movx	@dptr,a
      009665 90 0B A0         [24]  818 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_173 + 0x0001)
      009668 74 FC            [12]  819 	mov	a,#0xfc
      00966A F0               [24]  820 	movx	@dptr,a
      00966B 12 4B 9F         [24]  821 	lcall	_timer_read
      00966E 12 45 CD         [24]  822 	lcall	_ak820_outline_0127
      009671 90 0B A1         [24]  823 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_173 + 0x0002)
      009674 12 4A EC         [24]  824 	lcall	_ak820_outline_0060
      009677 90 0B A3         [24]  825 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_173 + 0x0004)
      00967A 74 03            [12]  826 	mov	a,#0x03
      00967C F0               [24]  827 	movx	@dptr,a
      00967D 90 0B A4         [24]  828 	mov	dptr,#(_encoder_exec_mapping_dummy_event_30000_173 + 0x0005)
      009680 E4               [12]  829 	clr	a
      009681 F0               [24]  830 	movx	@dptr,a
                                    831 ;	quantum/encoder.c:196: AK820_ACTION_EXEC(dummy_event);
      009682 90 0B 9F         [24]  832 	mov	dptr,#_encoder_exec_mapping_dummy_event_30000_173
                                    833 ;	quantum/encoder.c:201: }
      009685 02 75 B4         [24]  834 	ljmp	_ak820_action_exec
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'encoder_update'
                                    837 ;------------------------------------------------------------
                                    838 ;state         Allocated with name '_encoder_update_PARM_2'
                                    839 ;index         Allocated with name '_encoder_update_index_10000_174'
                                    840 ;changed       Allocated with name '_encoder_update_changed_10000_175'
                                    841 ;i             Allocated with name '_encoder_update_i_10000_175'
                                    842 ;resolution    Allocated with name '_encoder_update_resolution_10000_175'
                                    843 ;------------------------------------------------------------
                                    844 ;	quantum/encoder.c:204: static bool encoder_update(uint8_t index, uint8_t state) {
                                    845 ;	-----------------------------------------
                                    846 ;	 function encoder_update
                                    847 ;	-----------------------------------------
      009688                        848 _encoder_update:
      009688 E5 82            [12]  849 	mov	a,dpl
      00968A 90 0B A6         [24]  850 	mov	dptr,#_encoder_update_index_10000_174
      00968D F0               [24]  851 	movx	@dptr,a
                                    852 ;	quantum/encoder.c:205: bool    changed = false;
      00968E 90 0B A7         [24]  853 	mov	dptr,#_encoder_update_changed_10000_175
      009691 E4               [12]  854 	clr	a
      009692 F0               [24]  855 	movx	@dptr,a
                                    856 ;	quantum/encoder.c:206: uint8_t i       = index;
      009693 90 0B A6         [24]  857 	mov	dptr,#_encoder_update_index_10000_174
      009696 E0               [24]  858 	movx	a,@dptr
                                    859 ;	quantum/encoder.c:217: encoder_pulses[i] += encoder_LUT[state & 0xF];
      009697 FF               [12]  860 	mov	r7,a
      009698 24 4F            [12]  861 	add	a, #_encoder_pulses
      00969A FD               [12]  862 	mov	r5,a
      00969B E4               [12]  863 	clr	a
      00969C 34 0E            [12]  864 	addc	a, #(_encoder_pulses >> 8)
      00969E FE               [12]  865 	mov	r6,a
      00969F 12 4A F9         [24]  866 	lcall	_ak820_outline_0077
      0096A2 90 0B A5         [24]  867 	mov	dptr,#_encoder_update_PARM_2
      0096A5 E0               [24]  868 	movx	a,@dptr
      0096A6 FB               [12]  869 	mov	r3,a
      0096A7 74 0F            [12]  870 	mov	a,#0x0f
      0096A9 5B               [12]  871 	anl	a,r3
      0096AA 24 3E            [12]  872 	add	a, #_encoder_LUT
      0096AC F5 82            [12]  873 	mov	dpl,a
      0096AE E4               [12]  874 	clr	a
      0096AF 34 0E            [12]  875 	addc	a,#(_encoder_LUT >> 8)
      0096B1 F5 83            [12]  876 	mov	dph,a
      0096B3 E0               [24]  877 	movx	a,@dptr
      0096B4 2C               [12]  878 	add	a, r4
      0096B5 FC               [12]  879 	mov	r4,a
      0096B6 12 86 3E         [24]  880 	lcall	_ak820_outline_0123
                                    881 ;	quantum/encoder.c:223: if (encoder_pulses[i] >= resolution) {
      0096B9 EC               [12]  882 	mov	a,r4
      0096BA 33               [12]  883 	rlc	a
      0096BB 95 E0            [12]  884 	subb	a,acc
      0096BD FB               [12]  885 	mov	r3,a
      0096BE C3               [12]  886 	clr	c
      0096BF EC               [12]  887 	mov	a,r4
      0096C0 94 02            [12]  888 	subb	a,#0x02
      0096C2 EB               [12]  889 	mov	a,r3
      0096C3 64 80            [12]  890 	xrl	a,#0x80
      0096C5 94 80            [12]  891 	subb	a,#0x80
      0096C7 40 1B            [24]  892 	jc	00102$
                                    893 ;	quantum/encoder.c:226: encoder_value[index]++;
      0096C9 EF               [12]  894 	mov	a,r7
      0096CA 24 50            [12]  895 	add	a, #_encoder_value
      0096CC FB               [12]  896 	mov	r3,a
      0096CD E4               [12]  897 	clr	a
      0096CE 34 0E            [12]  898 	addc	a, #(_encoder_value >> 8)
      0096D0 12 4A E4         [24]  899 	lcall	_ak820_outline_0056
      0096D3 0A               [12]  900 	inc	r2
      0096D4 12 97 B7         [24]  901 	lcall	_ak820_outline_0062
                                    902 ;	quantum/encoder.c:227: changed = true;
                                    903 ;	quantum/encoder.c:232: encoder_exec_mapping(index, ENCODER_COUNTER_CLOCKWISE);
      0096D7 12 7C D0         [24]  904 	lcall	_ak820_outline_0191
      0096DA C0 06            [24]  905 	push	ar6
      0096DC C0 05            [24]  906 	push	ar5
      0096DE B1 BE            [12]  907 	acall	_encoder_exec_mapping
      0096E0 D0 05            [24]  908 	pop	ar5
      0096E2 D0 06            [24]  909 	pop	ar6
      0096E4                        910 00102$:
                                    911 ;	quantum/encoder.c:241: if (encoder_pulses[i] <= -resolution) { // direction is arbitrary here, but this clockwise
      0096E4 12 3B 12         [24]  912 	lcall	_ak820_outline_0137
      0096E7 E0               [24]  913 	movx	a,@dptr
      0096E8 FF               [12]  914 	mov	r7,a
      0096E9 33               [12]  915 	rlc	a
      0096EA 95 E0            [12]  916 	subb	a,acc
      0096EC FC               [12]  917 	mov	r4,a
      0096ED C3               [12]  918 	clr	c
      0096EE 74 FE            [12]  919 	mov	a,#0xfe
      0096F0 9F               [12]  920 	subb	a,r7
      0096F1 74 7F            [12]  921 	mov	a,#(0xff ^ 0x80)
      0096F3 8C F0            [24]  922 	mov	b,r4
      0096F5 63 F0 80         [24]  923 	xrl	b,#0x80
      0096F8 95 F0            [12]  924 	subb	a,b
      0096FA 40 1F            [24]  925 	jc	00104$
                                    926 ;	free result
                                    927 ;	quantum/encoder.c:243: encoder_value[index]--;
      0096FC 90 0B A6         [24]  928 	mov	dptr,#_encoder_update_index_10000_174
      0096FF E0               [24]  929 	movx	a,@dptr
      009700 FF               [12]  930 	mov	r7,a
      009701 24 50            [12]  931 	add	a, #_encoder_value
      009703 FB               [12]  932 	mov	r3,a
      009704 E4               [12]  933 	clr	a
      009705 34 0E            [12]  934 	addc	a, #(_encoder_value >> 8)
      009707 12 4A E4         [24]  935 	lcall	_ak820_outline_0056
      00970A 1A               [12]  936 	dec	r2
      00970B 12 97 B7         [24]  937 	lcall	_ak820_outline_0062
                                    938 ;	quantum/encoder.c:244: changed = true;
                                    939 ;	quantum/encoder.c:249: encoder_exec_mapping(index, ENCODER_CLOCKWISE);
      00970E F0               [24]  940 	movx	@dptr,a
      00970F 8F 82            [24]  941 	mov	dpl, r7
      009711 C0 06            [24]  942 	push	ar6
      009713 C0 05            [24]  943 	push	ar5
      009715 B1 BE            [12]  944 	acall	_encoder_exec_mapping
      009717 D0 05            [24]  945 	pop	ar5
      009719 D0 06            [24]  946 	pop	ar6
      00971B                        947 00104$:
                                    948 ;	quantum/encoder.c:254: encoder_pulses[i] %= resolution;
      00971B 12 3B 12         [24]  949 	lcall	_ak820_outline_0137
      00971E E0               [24]  950 	movx	a,@dptr
      00971F A2 E7            [12]  951 	mov	c,acc.7
      009721 54 01            [12]  952 	anl	a,#0x01
      009723 60 04            [24]  953 	jz	00123$
      009725 50 02            [24]  954 	jnc	00123$
      009727 44 FE            [12]  955 	orl	a,#0xfe
      009729                        956 00123$:
      009729 12 86 3E         [24]  957 	lcall	_ak820_outline_0123
                                    958 ;	quantum/encoder.c:259: return changed;
      00972C 90 0B A7         [24]  959 	mov	dptr,#_encoder_update_changed_10000_175
      00972F E0               [24]  960 	movx	a,@dptr
                                    961 ;	quantum/encoder.c:260: }
      009730 F5 82            [12]  962 	mov	dpl,a
      009732 22               [24]  963 	ret
                                    964 ;------------------------------------------------------------
                                    965 ;Allocation info for local variables in function 'encoder_read'
                                    966 ;------------------------------------------------------------
                                    967 ;changed       Allocated with name '_encoder_read_changed_10000_181'
                                    968 ;i             Allocated with name '_encoder_read_i_20000_182'
                                    969 ;new_status    Allocated with name '_encoder_read_new_status_30000_183'
                                    970 ;------------------------------------------------------------
                                    971 ;	quantum/encoder.c:262: bool encoder_read(void) {
                                    972 ;	-----------------------------------------
                                    973 ;	 function encoder_read
                                    974 ;	-----------------------------------------
      009733                        975 _encoder_read:
                                    976 ;	quantum/encoder.c:263: bool changed = false;
      009733 90 0B A8         [24]  977 	mov	dptr,#_encoder_read_changed_10000_181
      009736 E4               [12]  978 	clr	a
      009737 F0               [24]  979 	movx	@dptr,a
                                    980 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      009738 FF               [12]  981 	mov	r7,a
      009739                        982 00105$:
      009739 12 97 C7         [24]  983 	lcall	_ak820_outline_0091
      00973C 50 56            [24]  984 	jnc	00103$
                                    985 ;	quantum/encoder.c:265: uint8_t new_status = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      00973E 12 97 9B         [24]  986 	lcall	_ak820_outline_0028
      009741 12 5C 87         [24]  987 	lcall	_readPin
      009744 AE 82            [24]  988 	mov	r6, dpl
      009746 12 97 A9         [24]  989 	lcall	_ak820_outline_0029
      009749 12 5C 87         [24]  990 	lcall	_readPin
      00974C E5 82            [12]  991 	mov	a,dpl
      00974E 25 82            [12]  992 	add	a,dpl
      009750 42 06            [12]  993 	orl	ar6,a
                                    994 ;	quantum/encoder.c:266: if ((encoder_state[i] & 0x3) != new_status) {
      009752 EF               [12]  995 	mov	a,r7
      009753 24 4E            [12]  996 	add	a, #_encoder_state
      009755 FC               [12]  997 	mov	r4,a
      009756 E4               [12]  998 	clr	a
      009757 34 0E            [12]  999 	addc	a, #(_encoder_state >> 8)
      009759 FD               [12] 1000 	mov	r5,a
      00975A 12 45 B5         [24] 1001 	lcall	_ak820_outline_0097
      00975D FB               [12] 1002 	mov	r3,a
      00975E FA               [12] 1003 	mov	r2,a
      00975F 53 02 03         [24] 1004 	anl	ar2,#0x03
      009762 8E 01            [24] 1005 	mov	ar1,r6
      009764 EA               [12] 1006 	mov	a,r2
      009765 B5 01 02         [24] 1007 	cjne	a,ar1,00132$
      009768 80 27            [24] 1008 	sjmp	00106$
      00976A                       1009 00132$:
                                   1010 ;	quantum/encoder.c:267: encoder_state[i] <<= 2;
      00976A EB               [12] 1011 	mov	a,r3
      00976B 2B               [12] 1012 	add	a,r3
      00976C 25 E0            [12] 1013 	add	a,acc
      00976E FB               [12] 1014 	mov	r3,a
      00976F 12 3B 08         [24] 1015 	lcall	_ak820_outline_0126
      009772 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/encoder.c:268: encoder_state[i] |= new_status;
      009773 EB               [12] 1018 	mov	a,r3
      009774 42 06            [12] 1019 	orl	ar6,a
      009776 12 3B 08         [24] 1020 	lcall	_ak820_outline_0126
      009779 EE               [12] 1021 	mov	a,r6
      00977A F0               [24] 1022 	movx	@dptr,a
                                   1023 ;	quantum/encoder.c:269: changed |= encoder_update(i, encoder_state[i]);
      00977B 90 0B A5         [24] 1024 	mov	dptr,#_encoder_update_PARM_2
      00977E EE               [12] 1025 	mov	a,r6
      00977F F0               [24] 1026 	movx	@dptr,a
      009780 8F 82            [24] 1027 	mov	dpl, r7
      009782 C0 07            [24] 1028 	push	ar7
      009784 12 96 88         [24] 1029 	lcall	_encoder_update
      009787 AE 82            [24] 1030 	mov	r6, dpl
      009789 D0 07            [24] 1031 	pop	ar7
      00978B 90 0B A8         [24] 1032 	mov	dptr,#_encoder_read_changed_10000_181
      00978E E0               [24] 1033 	movx	a,@dptr
      00978F 4E               [12] 1034 	orl	a,r6
      009790 F0               [24] 1035 	movx	@dptr,a
      009791                       1036 00106$:
                                   1037 ;	quantum/encoder.c:264: for (uint8_t i = 0; i < thisCount; i++) {
      009791 0F               [12] 1038 	inc	r7
      009792 80 A5            [24] 1039 	sjmp	00105$
      009794                       1040 00103$:
                                   1041 ;	quantum/encoder.c:272: return changed;
      009794 90 0B A8         [24] 1042 	mov	dptr,#_encoder_read_changed_10000_181
      009797 E0               [24] 1043 	movx	a,@dptr
                                   1044 ;	quantum/encoder.c:273: }
      009798 F5 82            [12] 1045 	mov	dpl,a
      00979A 22               [24] 1046 	ret
                                   1047 	.area CSEG    (CODE)
                                   1048 	.area CONST   (CODE)
                                   1049 	.area XINIT   (CODE)
      00C645                       1050 __xinit__encoders_pad_a:
      00C645 39                    1051 	.db #0x39	; 57	'9'
      00C646                       1052 __xinit__encoders_pad_b:
      00C646 38                    1053 	.db #0x38	; 56	'8'
      00C647                       1054 __xinit__encoder_LUT:
      00C647 00                    1055 	.db #0x00	;  0
      00C648 FF                    1056 	.db #0xff	; -1
      00C649 01                    1057 	.db #0x01	;  1
      00C64A 00                    1058 	.db #0x00	;  0
      00C64B 01                    1059 	.db #0x01	;  1
      00C64C 00                    1060 	.db #0x00	;  0
      00C64D 00                    1061 	.db #0x00	;  0
      00C64E FF                    1062 	.db #0xff	; -1
      00C64F FF                    1063 	.db #0xff	; -1
      00C650 00                    1064 	.db #0x00	;  0
      00C651 00                    1065 	.db #0x00	;  0
      00C652 01                    1066 	.db #0x01	;  1
      00C653 00                    1067 	.db #0x00	;  0
      00C654 01                    1068 	.db #0x01	;  1
      00C655 FF                    1069 	.db #0xff	; -1
      00C656 00                    1070 	.db #0x00	;  0
      00C657                       1071 __xinit__encoder_state:
      00C657 00                    1072 	.db #0x00	; 0
      00C658                       1073 __xinit__encoder_pulses:
      00C658 00                    1074 	.db #0x00	;  0
      00C659                       1075 __xinit__encoder_value:
      00C659 00                    1076 	.db #0x00	; 0
                                   1077 	.area CABS    (ABS,CODE)
                                   1078 
                                   1079 ; Experimental exact instruction outlining.
                                   1080 	.globl _ak820_outline_0028
                                   1081 	.globl _ak820_outline_0029
                                   1082 	.globl _ak820_outline_0056
                                   1083 	.globl _ak820_outline_0060
                                   1084 	.globl _ak820_outline_0062
                                   1085 	.globl _ak820_outline_0065
                                   1086 	.globl _ak820_outline_0077
                                   1087 	.globl _ak820_outline_0091
                                   1088 	.globl _ak820_outline_0097
                                   1089 	.globl _ak820_outline_0123
                                   1090 	.globl _ak820_outline_0126
                                   1091 	.globl _ak820_outline_0127
                                   1092 	.globl _ak820_outline_0137
                                   1093 	.globl _ak820_outline_0141
                                   1094 	.globl _ak820_outline_0191
                                   1095 
                                   1096 	.area CSEG (CODE)
                                   1097 ; function ak820_outline_0028
      00979B                       1098 _ak820_outline_0028:
      00979B EF               [12] 1099 	mov	a,r7
      00979C 24 3C            [12] 1100 	add	a,#_encoders_pad_a
      00979E F5 82            [12] 1101 	mov	dpl,a
      0097A0 E4               [12] 1102 	clr	a
      0097A1 34 0E            [12] 1103 	addc	a,#(_encoders_pad_a>>8)
      0097A3 F5 83            [12] 1104 	mov	dph,a
      0097A5 E0               [24] 1105 	movx	a,@dptr
      0097A6 F5 82            [12] 1106 	mov	dpl,a
      0097A8 22               [24] 1107 	ret
                                   1108 
                                   1109 	.area CSEG (CODE)
                                   1110 ; function ak820_outline_0029
      0097A9                       1111 _ak820_outline_0029:
      0097A9 EF               [12] 1112 	mov	a,r7
      0097AA 24 3D            [12] 1113 	add	a,#_encoders_pad_b
      0097AC F5 82            [12] 1114 	mov	dpl,a
      0097AE E4               [12] 1115 	clr	a
      0097AF 34 0E            [12] 1116 	addc	a,#(_encoders_pad_b>>8)
      0097B1 F5 83            [12] 1117 	mov	dph,a
      0097B3 E0               [24] 1118 	movx	a,@dptr
      0097B4 F5 82            [12] 1119 	mov	dpl,a
      0097B6 22               [24] 1120 	ret
                                   1121 
                                   1122 	.area CSEG (CODE)
                                   1123 ; function ak820_outline_0062
      0097B7                       1124 _ak820_outline_0062:
      0097B7 8B 82            [24] 1125 	mov	dpl,r3
      0097B9 8C 83            [24] 1126 	mov	dph,r4
      0097BB EA               [12] 1127 	mov	a,r2
      0097BC F0               [24] 1128 	movx	@dptr,a
      0097BD 90 0B A7         [24] 1129 	mov	dptr,#_encoder_update_changed_10000_175
      0097C0 74 01            [12] 1130 	mov	a,#0x01
      0097C2 F0               [24] 1131 	movx	@dptr,a
      0097C3 90 0B 8B         [24] 1132 	mov	dptr,#_encoder_exec_mapping_PARM_2
      0097C6 22               [24] 1133 	ret
                                   1134 
                                   1135 	.area CSEG (CODE)
                                   1136 ; function ak820_outline_0091
      0097C7                       1137 _ak820_outline_0091:
      0097C7 90 0B 8A         [24] 1138 	mov	dptr,#_thisCount
      0097CA E0               [24] 1139 	movx	a,@dptr
      0097CB FE               [12] 1140 	mov	r6,a
      0097CC C3               [12] 1141 	clr	c
      0097CD EF               [12] 1142 	mov	a,r7
      0097CE 9E               [12] 1143 	subb	a,r6
      0097CF 22               [24] 1144 	ret
