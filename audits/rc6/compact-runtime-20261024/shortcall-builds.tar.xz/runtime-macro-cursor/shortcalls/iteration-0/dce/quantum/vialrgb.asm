;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module vialrgb
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _rgb_matrix_get_speed
	.globl _rgb_matrix_set_speed_noeeprom
	.globl _rgb_matrix_get_val
	.globl _rgb_matrix_get_sat
	.globl _rgb_matrix_get_hue
	.globl _rgb_matrix_sethsv_noeeprom
	.globl _rgb_matrix_get_mode
	.globl _rgb_matrix_mode_noeeprom
	.globl _rgb_matrix_is_enabled
	.globl _rgb_matrix_disable_noeeprom
	.globl _rgb_matrix_enable_noeeprom
	.globl _eeconfig_update_rgb_matrix
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _vialrgb_save_PARM_2
	.globl _vialrgb_set_value_PARM_2
	.globl _vialrgb_get_value_PARM_2
	.globl _g_direct_mode_colors
	.globl _vialrgb_get_value
	.globl _vialrgb_set_value
	.globl _vialrgb_save
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_fast_set_leds_sloc0_1_0:
	.ds 2
_fast_set_leds_sloc1_1_0:
	.ds 2
_vialrgb_get_value_sloc0_1_0:
	.ds 2
_vialrgb_get_value_sloc1_1_0:
	.ds 2
_vialrgb_set_value_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_g_direct_mode_colors::
	.ds 246
_get_supported_PARM_2:
	.ds 1
_get_supported_args_10000_255:
	.ds 2
_qmk_id_to_vialrgb_id_id_10000_262:
	.ds 2
_vialrgb_id_to_qmk_id_id_10000_267:
	.ds 2
_set_mode_mode_10000_275:
	.ds 2
_get_matrix_pos_for_led_PARM_2:
	.ds 2
_get_matrix_pos_for_led_led_10000_280:
	.ds 2
_fast_set_leds_PARM_2:
	.ds 1
_fast_set_leds_args_10000_282:
	.ds 2
_fast_set_leds_first_index_10001_285:
	.ds 2
_fast_set_leds_num_leds_10001_285:
	.ds 1
_vialrgb_get_value_PARM_2:
	.ds 1
_vialrgb_get_value_data_10000_291:
	.ds 3
_vialrgb_set_value_PARM_2:
	.ds 1
_vialrgb_set_value_data_10000_302:
	.ds 3
_vialrgb_save_PARM_2:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function get_supported
;	-----------------------------------------
_get_supported:
	lcall	_ak820_outline_0110
	mov	dptr,#_get_supported_args_10000_255
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
	mov	dptr,#_get_supported_args_10000_255
	lcall	_ak820_outline_0005
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	lcall	_ak820_outline_0120
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	clr	a
	lcall	_ak820_outline_0147
;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
	mov	dptr,#_get_supported_PARM_2
	movx	a,@dptr
	mov	r3,a
	mov	r2,#0x00
00107$:
	clr	c
	mov	a,r2
	subb	a,r3
	jnc	00101$
	mov	a,r2
	lcall	_ak820_outline_0022
	mov	a,#0xff
	movx	@dptr,a
	inc	r2
	sjmp	00107$
00101$:
;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	mov	ar6,r5
	mov	ar7,r4
	mov	ar5,r3
	mov	dptr,#_get_supported_args_10000_255
	lcall	_ak820_outline_0124
	mov	r2,#0x00
00110$:
	cjne	r2,#0x07,00159$
00159$:
	jnc	00127$
;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
	mov	a,r2
	mov	b,#0x02
	mul	ab
	add	a, #_supported_modes
	mov	dpl,a
	mov	a,#(_supported_modes >> 8)
	lcall	_ak820_outline_0112
	mov	r0,a
	mov	r1,#0x00
;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
	clr	c
	mov	a,r6
	subb	a,r0
	mov	a,r7
	subb	a,r1
	jnc	00111$
;	free result
	cjne	r5,#0x02,00162$
00162$:
	jc	00111$
;	quantum/vialrgb.c:49: args[0] = id;
	push	ar6
	push	ar7
	mov	ar7,r0
	lcall	_ak820_outline_0125
	mov	a,r7
	lcall	_ak820_outline_0103
;	quantum/vialrgb.c:50: args[1] = id >> 8;
	inc	dptr
	mov	ar0,r1
	mov	a,r0
	movx	@dptr,a
;	quantum/vialrgb.c:51: length -= sizeof(id);
	dec	r5
	dec	r5
;	quantum/vialrgb.c:52: args += sizeof(id);
	mov	a,#0x02
	add	a, r3
	mov	r3,a
	clr	a
	addc	a, r4
	mov	r4,a
	mov	dptr,#_get_supported_args_10000_255
	lcall	_ak820_outline_0086
;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	pop	ar7
	pop	ar6
;	quantum/vialrgb.c:52: args += sizeof(id);
00111$:
;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	inc	r2
	sjmp	00110$
00127$:
	mov	dptr,#_get_supported_args_10000_255
	lcall	_ak820_outline_0086
;	quantum/vialrgb.c:55: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
;------------------------------------------------------------
;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
;------------------------------------------------------------
;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
;	-----------------------------------------
;	 function qmk_id_to_vialrgb_id
;	-----------------------------------------
_qmk_id_to_vialrgb_id:
	lcall	_ak820_outline_0110
	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
	lcall	_ak820_outline_0052
	mov	r5,#0x00
00105$:
	cjne	r5,#0x07,00130$
00130$:
	jnc	00103$
;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
	lcall	_ak820_outline_0047
	inc	dptr
	clr	a
	movc	a,@a+dptr
;	quantum/vialrgb.c:60: if (qmk_id == id)
	mov	r2,#0x00
	cjne	a,ar6,00106$
	mov	a,r2
	cjne	a,ar7,00106$
;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
	lcall	_ak820_outline_0125
	lcall	_ak820_outline_0149
	ret
00106$:
;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	inc	r5
	sjmp	00105$
00103$:
;	quantum/vialrgb.c:63: return 0;
	mov	dptr,#0x0000
;	quantum/vialrgb.c:64: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
;------------------------------------------------------------
;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
;------------------------------------------------------------
;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
;	-----------------------------------------
;	 function vialrgb_id_to_qmk_id
;	-----------------------------------------
_vialrgb_id_to_qmk_id:
	lcall	_ak820_outline_0110
	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
	lcall	_ak820_outline_0052
	mov	r5,#0x00
00105$:
	cjne	r5,#0x07,00130$
00130$:
	jnc	00103$
;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
	lcall	_ak820_outline_0047
	clr	a
	movc	a,@a+dptr
;	quantum/vialrgb.c:69: if (vialrgb_id == id)
	mov	r2,#0x00
	cjne	a,ar6,00106$
	mov	a,r2
	cjne	a,ar7,00106$
;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
	lcall	_ak820_outline_0125
	inc	dptr
	lcall	_ak820_outline_0149
	ret
00106$:
;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
	inc	r5
	sjmp	00105$
00103$:
;	quantum/vialrgb.c:72: return 0;
	mov	dptr,#0x0000
;	quantum/vialrgb.c:73: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_mode'
;------------------------------------------------------------
;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
;	-----------------------------------------
;	 function get_mode
;	-----------------------------------------
_get_mode:
;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
	lcall	_rgb_matrix_is_enabled
	mov	a, dpl
	jnz	00102$
;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
	mov	dptr,#0x0000
	ret
00102$:
;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
	lcall	_rgb_matrix_get_mode
	mov	r6,#0x00
	mov	dph, r6
;	quantum/vialrgb.c:80: }
	ajmp	_qmk_id_to_vialrgb_id
;------------------------------------------------------------
;Allocation info for local variables in function 'set_mode'
;------------------------------------------------------------
;mode          Allocated with name '_set_mode_mode_10000_275'
;------------------------------------------------------------
;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
;	-----------------------------------------
;	 function set_mode
;	-----------------------------------------
_set_mode:
	lcall	_ak820_outline_0110
	mov	dptr,#_set_mode_mode_10000_275
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
	mov	dptr,#_set_mode_mode_10000_275
	lcall	_ak820_outline_0052
	mov	dptr,#_set_mode_mode_10000_275
	lcall	_ak820_outline_0040
	jnz	00102$
;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
	ljmp	_rgb_matrix_disable_noeeprom
00102$:
;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
	push	ar7
	push	ar6
	lcall	_rgb_matrix_enable_noeeprom
	pop	ar6
	pop	ar7
;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
	lcall	_ak820_outline_0120
	acall	_vialrgb_id_to_qmk_id
;	quantum/vialrgb.c:90: }
	ljmp	_rgb_matrix_mode_noeeprom
;------------------------------------------------------------
;Allocation info for local variables in function 'get_matrix_pos_for_led'
;------------------------------------------------------------
;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
;------------------------------------------------------------
;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
;	-----------------------------------------
;	 function get_matrix_pos_for_led
;	-----------------------------------------
_get_matrix_pos_for_led:
	lcall	_ak820_outline_0110
	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
	lcall	_ak820_outline_0052
	mov	a,r6
	add	a, #_ak820_rgb_slots
	mov	dpl,a
	mov	a,r7
	addc	a, #(_ak820_rgb_slots >> 8)
	mov	dph,a
	clr	a
	movc	a,@a+dptr
	mov	r7,a
;	quantum/vialrgb.c:96: output[0] = slot >> 3;
	mov	dptr,#_get_matrix_pos_for_led_PARM_2
	lcall	_ak820_outline_0080
	mov	a,r7
	lcall	_ak820_outline_0190
	lcall	_ak820_outline_0123
;	quantum/vialrgb.c:97: output[1] = slot & 7;
	lcall	_ak820_outline_0137
	inc	dptr
	anl	ar7,#0x07
	mov	a,r7
	movx	@dptr,a
;	quantum/vialrgb.c:110: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'fast_set_leds'
;------------------------------------------------------------
;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
;length        Allocated with name '_fast_set_leds_PARM_2'
;args          Allocated with name '_fast_set_leds_args_10000_282'
;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
;i             Allocated with name '_fast_set_leds_i_20001_288'
;color         Allocated with name '_fast_set_leds_color_30001_289'
;val           Allocated with name '_fast_set_leds_val_30002_290'
;------------------------------------------------------------
;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
;	-----------------------------------------
;	 function fast_set_leds
;	-----------------------------------------
_fast_set_leds:
	lcall	_ak820_outline_0110
	mov	dptr,#_fast_set_leds_args_10000_282
	lcall	_ak820_outline_0111
;	quantum/vialrgb.c:115: if (length < 3) return;
	mov	dptr,#_fast_set_leds_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00159$
00159$:
	jnc	00102$
	ret
00102$:
;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
	mov	dptr,#_fast_set_leds_args_10000_282
	lcall	_ak820_outline_0080
	lcall	_ak820_outline_0077
	mov	r3,#0x00
	lcall	_ak820_outline_0137
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	r1,#0x00
	mov	dptr,#_fast_set_leds_first_index_10001_285
	mov	a,r1
	orl	a,r4
	movx	@dptr,a
	mov	a,r2
	orl	a,r3
	inc	dptr
	movx	@dptr,a
;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
	lcall	_ak820_outline_0137
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	dptr,#_fast_set_leds_num_leds_10001_285
	movx	@dptr,a
;	quantum/vialrgb.c:119: length -= 3;
	mov	a,r7
	add	a,#0xfd
	mov	dptr,#_fast_set_leds_PARM_2
	movx	@dptr,a
;	quantum/vialrgb.c:120: args += 3;
	mov	dptr,#_fast_set_leds_args_10000_282
	mov	a,#0x03
	add	a, r5
	movx	@dptr,a
	clr	a
	addc	a, r6
	inc	dptr
	movx	@dptr,a
;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
	mov	dptr,#_fast_set_leds_num_leds_10001_285
	movx	a,@dptr
	mov	r7,a
	mov	b,#0x03
	mul	ab
	mov	r6,a
	mov	r5,b
	mov	dptr,#_fast_set_leds_PARM_2
	movx	a,@dptr
	mov	r3,a
	mov	r4,#0x00
	clr	c
	mov	a,r3
	subb	a,r6
	mov	a,r4
	subb	a,r5
	jc	00103$
;	free result
	mov	dptr,#_fast_set_leds_first_index_10001_285
	lcall	_ak820_outline_0080
	mov	ar3,r5
	mov	ar4,r6
	clr	c
	mov	a,r3
	subb	a,#0x52
	mov	a,r4
	subb	a,#0x00
	jc	00104$
00103$:
	ret
00104$:
;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
	mov	a,#0x52
	clr	c
	subb	a,r5
	mov	r3,a
	clr	a
	subb	a,r6
	mov	r4,a
	mov	r2,#0x00
	clr	c
	mov	a,r3
	subb	a,r7
	mov	a,r4
	subb	a,r2
	jnc	00127$
;	free result
	mov	dptr,#_fast_set_leds_num_leds_10001_285
	mov	a,#0x52
	clr	c
	subb	a,r5
	movx	@dptr,a
;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
00127$:
	mov	dptr,#_fast_set_leds_num_leds_10001_285
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_fast_set_leds_first_index_10001_285
	lcall	_ak820_outline_0080
	mov	r4,#0x00
00110$:
	clr	c
	mov	a,r4
	subb	a,r7
	jc	00164$
	ret
00164$:
;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
	push	ar7
	mov	dptr,#__mulint_PARM_2
	lcall	_ak820_outline_0141
	mov	dptr,#0x0003
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	acall	__mulint
	mov	r2, dpl
	mov	r3, dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	inc	r5
	cjne	r5,#0x00,00165$
	inc	r6
00165$:
	mov	a,r2
	add	a, #_g_direct_mode_colors
	mov	r2,a
	mov	a,r3
	addc	a, #(_g_direct_mode_colors >> 8)
	mov	r3,a
;	quantum/vialrgb.c:128: color->h = *args++;
	mov	_fast_set_leds_sloc0_1_0,r2
	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
	lcall	_ak820_outline_0085
	mov	r0,a
	lcall	_ak820_outline_0109
	mov	dpl,_fast_set_leds_sloc0_1_0
	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
	mov	a,r0
	movx	@dptr,a
;	quantum/vialrgb.c:129: color->s = *args++;
	mov	a,#0x01
	add	a, r2
	mov	_fast_set_leds_sloc0_1_0,a
	clr	a
	addc	a, r3
	mov	(_fast_set_leds_sloc0_1_0 + 1),a
	mov	dptr,#_fast_set_leds_args_10000_282
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r0
	mov	dph,r7
	movx	a,@dptr
	mov	r1,a
	mov	dptr,#_fast_set_leds_args_10000_282
	mov	a,#0x01
	add	a, r0
	movx	@dptr,a
	clr	a
	addc	a, r7
	inc	dptr
	movx	@dptr,a
	mov	dpl,_fast_set_leds_sloc0_1_0
	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
	mov	a,r1
	movx	@dptr,a
;	quantum/vialrgb.c:130: uint8_t val = *args++;
	lcall	_ak820_outline_0085
	mov	_fast_set_leds_sloc0_1_0,a
	lcall	_ak820_outline_0109
;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
	mov	a,#0x02
	add	a, r2
	mov	_fast_set_leds_sloc1_1_0,a
	clr	a
	addc	a, r3
	mov	(_fast_set_leds_sloc1_1_0 + 1),a
	clr	c
	mov	a,#0xa0
	subb	a,_fast_set_leds_sloc0_1_0
	pop	ar7
	jnc	00114$
;	free result
	mov	r3,#0xa0
	sjmp	00115$
00114$:
	mov	r2,_fast_set_leds_sloc0_1_0
	mov	ar3,r2
00115$:
	mov	dpl,_fast_set_leds_sloc1_1_0
	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
	mov	a,r3
	movx	@dptr,a
;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
	inc	r4
;	quantum/vialrgb.c:133: }
	ajmp	00110$
;------------------------------------------------------------
;Allocation info for local variables in function 'vialrgb_get_value'
;------------------------------------------------------------
;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
;length        Allocated with name '_vialrgb_get_value_PARM_2'
;data          Allocated with name '_vialrgb_get_value_data_10000_291'
;args          Allocated with name '_vialrgb_get_value_args_10001_294'
;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
;led           Allocated with name '_vialrgb_get_value_led_40001_300'
;------------------------------------------------------------
;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function vialrgb_get_value
;	-----------------------------------------
_vialrgb_get_value:
	lcall	_ak820_outline_0036
	mov	dptr,#_vialrgb_get_value_data_10000_291
	lcall	_ak820_outline_0016
;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
	mov	dptr,#_vialrgb_get_value_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x20,00162$
	sjmp	00102$
00162$:
	ret
00102$:
;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
	mov	dptr,#_vialrgb_get_value_data_10000_291
	lcall	_ak820_outline_0046
;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
;	quantum/vialrgb.c:142: switch (cmd) {
	cjne	r2,#0x40,00163$
	sjmp	00103$
00163$:
	cjne	r2,#0x41,00164$
	sjmp	00104$
00164$:
	cjne	r2,#0x42,00165$
	ajmp	00105$
00165$:
	cjne	r2,#0x43,00166$
	ajmp	00106$
00166$:
	cjne	r2,#0x44,00167$
	ajmp	00107$
00167$:
	ret
;	quantum/vialrgb.c:143: case vialrgb_get_info:
00103$:
;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
	lcall	_ak820_outline_0125
	mov	a,#0x01
	movx	@dptr,a
;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
	lcall	_ak820_outline_0039
	clr	a
	movx	@dptr,a
;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
	lcall	_ak820_outline_0039
	inc	dptr
	mov	a,#0xa0
	movx	@dptr,a
;	quantum/vialrgb.c:147: break;
	ret
;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
00104$:
;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	acall	_get_mode
	mov	r1, dpl
	mov	r2, dph
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
	mov	ar0,r1
	lcall	_ak820_outline_0125
	mov	a,r0
	movx	@dptr,a
;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
	lcall	_ak820_outline_0039
	mov	ar1,r2
	mov	a,r1
	movx	@dptr,a
;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
	mov	a,#0x04
	lcall	_ak820_outline_0138
	push	ar6
	push	ar5
	push	ar2
	push	ar1
	lcall	_rgb_matrix_get_speed
	mov	r0, dpl
	pop	ar1
	pop	ar2
	pop	ar5
	pop	ar6
	lcall	_ak820_outline_0064
;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
	mov	a,#0x05
	lcall	_ak820_outline_0138
	push	ar6
	push	ar5
	push	ar2
	push	ar1
	lcall	_rgb_matrix_get_hue
	mov	r0, dpl
	pop	ar1
	pop	ar2
	pop	ar5
	pop	ar6
	lcall	_ak820_outline_0064
;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
	mov	a,#0x06
	lcall	_ak820_outline_0138
	push	ar6
	push	ar5
	push	ar2
	push	ar1
	lcall	_rgb_matrix_get_sat
	mov	r0, dpl
	pop	ar1
	pop	ar2
	pop	ar5
	pop	ar6
	lcall	_ak820_outline_0064
;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
	mov	a,#0x07
	lcall	_ak820_outline_0138
	push	ar2
	push	ar1
	lcall	_rgb_matrix_get_val
	mov	r0, dpl
	pop	ar1
	pop	ar2
	lcall	_ak820_outline_0064
;	quantum/vialrgb.c:156: break;
	ret
;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
00105$:
;	quantum/vialrgb.c:159: get_supported(args, length - 2);
	mov	a,r7
	add	a,#0xfe
	mov	dptr,#_get_supported_PARM_2
	lcall	_ak820_outline_0103
;	quantum/vialrgb.c:160: break;
	ajmp	_get_supported
;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
00106$:
;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
	lcall	_ak820_outline_0125
	mov	a,#0x52
	movx	@dptr,a
;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
	lcall	_ak820_outline_0039
	clr	a
	movx	@dptr,a
;	quantum/vialrgb.c:166: break;
	ret
;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
00107$:
;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
	lcall	_ak820_outline_0125
	movx	a,@dptr
	mov	r7,a
	mov	r2,#0x00
	mov	a,#0x03
	add	a, r5
	mov	r0,a
	clr	a
	addc	a, r6
	mov	r1,a
	push	ar3
	push	ar4
	lcall	_ak820_outline_0164
	movx	a,@dptr
	mov	r3,a
	clr	a
	orl	a,r7
	mov	_vialrgb_get_value_sloc0_1_0,a
	mov	a,r3
	orl	a,r2
	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
	mov	r4,_vialrgb_get_value_sloc0_1_0
	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
	clr	c
	mov	a,r4
	subb	a,#0x52
	mov	a,r7
	subb	a,#0x00
	pop	ar4
	pop	ar3
	jc	00109$
	ret
00109$:
;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
	mov	a,_vialrgb_get_value_sloc0_1_0
	add	a,_vialrgb_get_value_sloc0_1_0
	mov	r2,a
	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
	rlc	a
	mov	r7,a
	mov	a,r2
	add	a, #_ak820_led_points
	mov	_vialrgb_get_value_sloc1_1_0,a
	mov	a,r7
	addc	a, #(_ak820_led_points >> 8)
	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
	mov	dpl,_vialrgb_get_value_sloc1_1_0
	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
	clr	a
	movc	a,@a+dptr
	lcall	_ak820_outline_0125
	movx	@dptr,a
;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
	mov	dpl,_vialrgb_get_value_sloc1_1_0
	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
	inc	dptr
	clr	a
	movc	a,@a+dptr
	lcall	_ak820_outline_0164
	movx	@dptr,a
;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
	lcall	_ak820_outline_0039
	inc	dptr
	mov	a,#0x04
	movx	@dptr,a
;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
	mov	dptr,#_get_matrix_pos_for_led_PARM_2
	inc	a
	add	a, r5
	movx	@dptr,a
	clr	a
	addc	a, r6
	inc	dptr
	movx	@dptr,a
	mov	dpl, _vialrgb_get_value_sloc0_1_0
	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
;	quantum/vialrgb.c:187: }
;	quantum/vialrgb.c:188: }
	ajmp	_get_matrix_pos_for_led
;------------------------------------------------------------
;Allocation info for local variables in function 'vialrgb_set_value'
;------------------------------------------------------------
;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
;length        Allocated with name '_vialrgb_set_value_PARM_2'
;data          Allocated with name '_vialrgb_set_value_data_10000_302'
;args          Allocated with name '_vialrgb_set_value_args_10001_305'
;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
;------------------------------------------------------------
;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function vialrgb_set_value
;	-----------------------------------------
_vialrgb_set_value:
	lcall	_ak820_outline_0036
	mov	dptr,#_vialrgb_set_value_data_10000_302
	lcall	_ak820_outline_0016
;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
	mov	dptr,#_vialrgb_set_value_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x20,00129$
	sjmp	00102$
00129$:
	ret
00102$:
;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
	mov	dptr,#_vialrgb_set_value_data_10000_302
	lcall	_ak820_outline_0046
;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
;	quantum/vialrgb.c:196: switch (cmd) {
	cjne	r2,#0x41,00130$
	sjmp	00103$
00130$:
	cjne	r2,#0x42,00131$
	sjmp	00104$
00131$:
	ret
;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
00103$:
;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
	lcall	_ak820_outline_0125
	movx	a,@dptr
	mov	r2,a
	lcall	_ak820_outline_0039
	movx	a,@dptr
	mov	r0,a
	mov	r1,#0x00
	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
	mov	_vialrgb_set_value_sloc0_1_0,r1
	mov	ar1,r2
	mov	r2,#0x00
	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
	orl	ar2,a
;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
	lcall	_ak820_outline_0185
	push	ar6
	push	ar5
	acall	_set_mode
	pop	ar5
	pop	ar6
;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
	lcall	_ak820_outline_0039
	inc	dptr
	movx	a,@dptr
	mov	dpl,a
	push	ar6
	push	ar5
	lcall	_rgb_matrix_set_speed_noeeprom
	pop	ar5
	pop	ar6
;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
	lcall	_ak820_outline_0039
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	mov	r2,#0x00
	mov	a,#0x06
	lcall	_ak820_outline_0174
	mov	r0,a
	mov	a,#0x07
	lcall	_ak820_outline_0174
	mov	r6,a
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
	mov	a,r0
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
	mov	a,r6
	movx	@dptr,a
	lcall	_ak820_outline_0185
;	quantum/vialrgb.c:202: break;
;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
	ljmp	_rgb_matrix_sethsv_noeeprom
00104$:
;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
	mov	a,r7
	add	a,#0xfe
	mov	dptr,#_fast_set_leds_PARM_2
	lcall	_ak820_outline_0103
;	quantum/vialrgb.c:210: }
;	quantum/vialrgb.c:211: }
	ajmp	_fast_set_leds
;------------------------------------------------------------
;Allocation info for local variables in function 'vialrgb_save'
;------------------------------------------------------------
;length        Allocated with name '_vialrgb_save_PARM_2'
;data          Allocated with name '_vialrgb_save_data_10000_310'
;------------------------------------------------------------
;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
;	-----------------------------------------
;	 function vialrgb_save
;	-----------------------------------------
_vialrgb_save:
;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
;	quantum/vialrgb.c:218: }
	ljmp	_eeconfig_update_rgb_matrix
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_supported_modes:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x05	; 5
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x06	; 6
	.db #0x02	; 2
	.db #0x0d	; 13
	.db #0x03	; 3
	.db #0x0e	; 14
	.db #0x04	; 4
	.db #0x1f	; 31
	.db #0x06	; 6
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0016
	.globl _ak820_outline_0022
	.globl _ak820_outline_0036
	.globl _ak820_outline_0039
	.globl _ak820_outline_0040
	.globl _ak820_outline_0046
	.globl _ak820_outline_0047
	.globl _ak820_outline_0052
	.globl _ak820_outline_0064
	.globl _ak820_outline_0077
	.globl _ak820_outline_0080
	.globl _ak820_outline_0085
	.globl _ak820_outline_0086
	.globl _ak820_outline_0103
	.globl _ak820_outline_0109
	.globl _ak820_outline_0110
	.globl _ak820_outline_0111
	.globl _ak820_outline_0112
	.globl _ak820_outline_0120
	.globl _ak820_outline_0123
	.globl _ak820_outline_0124
	.globl _ak820_outline_0125
	.globl _ak820_outline_0137
	.globl _ak820_outline_0138
	.globl _ak820_outline_0141
	.globl _ak820_outline_0147
	.globl _ak820_outline_0149
	.globl _ak820_outline_0164
	.globl _ak820_outline_0174
	.globl _ak820_outline_0185
	.globl _ak820_outline_0190

	.area CSEG (CODE)
; function ak820_outline_0039
_ak820_outline_0039:
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
	inc	dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0046
_ak820_outline_0046:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	a,#0x02
	add	a,r5
	mov	r3,a
	clr	a
	addc	a,r6
	mov	r4,a
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0047
_ak820_outline_0047:
	mov	a,r5
	mov	b,#0x02
	mul	ab
	add	a,#_supported_modes
	mov	r3,a
	mov	a,#(_supported_modes>>8)
	addc	a,b
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	ret

	.area CSEG (CODE)
; function ak820_outline_0085
_ak820_outline_0085:
	mov	dptr,#_fast_set_leds_args_10000_282
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r1
	mov	dph,r7
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0109
_ak820_outline_0109:
	mov	dptr,#_fast_set_leds_args_10000_282
	mov	a,#0x01
	add	a,r1
	movx	@dptr,a
	clr	a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0149
_ak820_outline_0149:
	clr	a
	movc	a,@a+dptr
	mov	r4,a
	mov	r3,#0x00
	mov	dpl,r4
	mov	dph,r3
	ret

	.area CSEG (CODE)
; function ak820_outline_0174
_ak820_outline_0174:
	add	a,r5
	mov	dpl,a
	clr	a
	addc	a,r6
	mov	dph,a
	movx	a,@dptr
	ret
