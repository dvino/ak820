                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CDE                        569 _g_direct_mode_colors::
      000CDE                        570 	.ds 246
      000DD4                        571 _get_supported_PARM_2:
      000DD4                        572 	.ds 1
      000DD5                        573 _get_supported_args_10000_255:
      000DD5                        574 	.ds 2
      000DD7                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DD7                        576 	.ds 2
      000DD9                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DD9                        578 	.ds 2
      000DDB                        579 _set_mode_mode_10000_275:
      000DDB                        580 	.ds 2
      000DDD                        581 _get_matrix_pos_for_led_PARM_2:
      000DDD                        582 	.ds 2
      000DDF                        583 _get_matrix_pos_for_led_led_10000_280:
      000DDF                        584 	.ds 2
      000DE1                        585 _fast_set_leds_PARM_2:
      000DE1                        586 	.ds 1
      000DE2                        587 _fast_set_leds_args_10000_282:
      000DE2                        588 	.ds 2
      000DE4                        589 _fast_set_leds_first_index_10001_285:
      000DE4                        590 	.ds 2
      000DE6                        591 _fast_set_leds_num_leds_10001_285:
      000DE6                        592 	.ds 1
      000DE7                        593 _vialrgb_get_value_PARM_2:
      000DE7                        594 	.ds 1
      000DE8                        595 _vialrgb_get_value_data_10000_291:
      000DE8                        596 	.ds 3
      000DEB                        597 _vialrgb_set_value_PARM_2:
      000DEB                        598 	.ds 1
      000DEC                        599 _vialrgb_set_value_data_10000_302:
      000DEC                        600 	.ds 3
      000DEF                        601 _vialrgb_save_PARM_2:
      000DEF                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B850                        654 _get_supported:
      00B850 12 3A FE         [24]  655 	lcall	_ak820_outline_0110
      00B853 90 0D D5         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B856 12 3B 03         [24]  657 	lcall	_ak820_outline_0111
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B859 90 0D D5         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B85C 12 3A 70         [24]  660 	lcall	_ak820_outline_0005
      00B85F E0               [24]  661 	movx	a,@dptr
      00B860 FD               [12]  662 	mov	r5,a
      00B861 7C 00            [12]  663 	mov	r4,#0x00
      00B863 12 3B 08         [24]  664 	lcall	_ak820_outline_0120
      00B866 A3               [24]  665 	inc	dptr
      00B867 E0               [24]  666 	movx	a,@dptr
      00B868 FA               [12]  667 	mov	r2,a
      00B869 E4               [12]  668 	clr	a
      00B86A 12 45 E9         [24]  669 	lcall	_ak820_outline_0147
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B86D 90 0D D4         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B870 E0               [24]  672 	movx	a,@dptr
      00B871 FB               [12]  673 	mov	r3,a
      00B872 7A 00            [12]  674 	mov	r2,#0x00
      00B874                        675 00107$:
      00B874 C3               [12]  676 	clr	c
      00B875 EA               [12]  677 	mov	a,r2
      00B876 9B               [12]  678 	subb	a,r3
      00B877 50 0A            [24]  679 	jnc	00101$
      00B879 EA               [12]  680 	mov	a,r2
      00B87A 12 3A AD         [24]  681 	lcall	_ak820_outline_0022
      00B87D 74 FF            [12]  682 	mov	a,#0xff
      00B87F F0               [24]  683 	movx	@dptr,a
      00B880 0A               [12]  684 	inc	r2
      00B881 80 F1            [24]  685 	sjmp	00107$
      00B883                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B883 8D 06            [24]  688 	mov	ar6,r5
      00B885 8C 07            [24]  689 	mov	ar7,r4
      00B887 8B 05            [24]  690 	mov	ar5,r3
      00B889 90 0D D5         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B88C 12 3B 0D         [24]  692 	lcall	_ak820_outline_0124
      00B88F 7A 00            [12]  693 	mov	r2,#0x00
      00B891                        694 00110$:
      00B891 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B894                        696 00159$:
      00B894 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B896 EA               [12]  699 	mov	a,r2
      00B897 75 F0 02         [24]  700 	mov	b,#0x02
      00B89A A4               [48]  701 	mul	ab
      00B89B 24 00            [12]  702 	add	a, #_supported_modes
      00B89D F5 82            [12]  703 	mov	dpl,a
      00B89F 74 C5            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B8A1 12 5C 2D         [24]  705 	lcall	_ak820_outline_0112
      00B8A4 F8               [12]  706 	mov	r0,a
      00B8A5 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B8A7 C3               [12]  709 	clr	c
      00B8A8 EE               [12]  710 	mov	a,r6
      00B8A9 98               [12]  711 	subb	a,r0
      00B8AA EF               [12]  712 	mov	a,r7
      00B8AB 99               [12]  713 	subb	a,r1
      00B8AC 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B8AE BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B8B1                        717 00162$:
      00B8B1 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B8B3 C0 06            [24]  720 	push	ar6
      00B8B5 C0 07            [24]  721 	push	ar7
      00B8B7 88 07            [24]  722 	mov	ar7,r0
      00B8B9 12 36 78         [24]  723 	lcall	_ak820_outline_0125
      00B8BC EF               [12]  724 	mov	a,r7
      00B8BD 12 74 DC         [24]  725 	lcall	_ak820_outline_0103
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B8C0 A3               [24]  727 	inc	dptr
      00B8C1 89 00            [24]  728 	mov	ar0,r1
      00B8C3 E8               [12]  729 	mov	a,r0
      00B8C4 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B8C5 1D               [12]  732 	dec	r5
      00B8C6 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B8C7 74 02            [12]  735 	mov	a,#0x02
      00B8C9 2B               [12]  736 	add	a, r3
      00B8CA FB               [12]  737 	mov	r3,a
      00B8CB E4               [12]  738 	clr	a
      00B8CC 3C               [12]  739 	addc	a, r4
      00B8CD FC               [12]  740 	mov	r4,a
      00B8CE 90 0D D5         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B8D1 12 3A E6         [24]  742 	lcall	_ak820_outline_0086
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8D4 D0 07            [24]  744 	pop	ar7
      00B8D6 D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B8D8                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8D8 0A               [12]  749 	inc	r2
      00B8D9 80 B6            [24]  750 	sjmp	00110$
      00B8DB                        751 00127$:
      00B8DB 90 0D D5         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B8DE 12 3A E6         [24]  753 	lcall	_ak820_outline_0086
                                    754 ;	quantum/vialrgb.c:55: }
      00B8E1 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B8E2                        767 _qmk_id_to_vialrgb_id:
      00B8E2 12 3A FE         [24]  768 	lcall	_ak820_outline_0110
      00B8E5 90 0D D7         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B8E8 12 3B 03         [24]  770 	lcall	_ak820_outline_0111
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B8EB 90 0D D7         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B8EE 12 3A BD         [24]  773 	lcall	_ak820_outline_0052
      00B8F1 7D 00            [12]  774 	mov	r5,#0x00
      00B8F3                        775 00105$:
      00B8F3 BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B8F6                        777 00130$:
      00B8F6 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B8F8 12 BD 17         [24]  780 	lcall	_ak820_outline_0047
      00B8FB A3               [24]  781 	inc	dptr
      00B8FC E4               [12]  782 	clr	a
      00B8FD 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B8FE 7A 00            [12]  785 	mov	r2,#0x00
      00B900 B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B903 EA               [12]  787 	mov	a,r2
      00B904 B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B907 12 36 78         [24]  790 	lcall	_ak820_outline_0125
      00B90A 12 BD 43         [24]  791 	lcall	_ak820_outline_0149
      00B90D 22               [24]  792 	ret
      00B90E                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B90E 0D               [12]  795 	inc	r5
      00B90F 80 E2            [24]  796 	sjmp	00105$
      00B911                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B911 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B914 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B915                        813 _vialrgb_id_to_qmk_id:
      00B915 12 3A FE         [24]  814 	lcall	_ak820_outline_0110
      00B918 90 0D D9         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B91B 12 3B 03         [24]  816 	lcall	_ak820_outline_0111
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B91E 90 0D D9         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B921 12 3A BD         [24]  819 	lcall	_ak820_outline_0052
      00B924 7D 00            [12]  820 	mov	r5,#0x00
      00B926                        821 00105$:
      00B926 BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B929                        823 00130$:
      00B929 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B92B 12 BD 17         [24]  826 	lcall	_ak820_outline_0047
      00B92E E4               [12]  827 	clr	a
      00B92F 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B930 7A 00            [12]  830 	mov	r2,#0x00
      00B932 B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B935 EA               [12]  832 	mov	a,r2
      00B936 B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B939 12 36 78         [24]  835 	lcall	_ak820_outline_0125
      00B93C A3               [24]  836 	inc	dptr
      00B93D 12 BD 43         [24]  837 	lcall	_ak820_outline_0149
      00B940 22               [24]  838 	ret
      00B941                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B941 0D               [12]  841 	inc	r5
      00B942 80 E2            [24]  842 	sjmp	00105$
      00B944                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B944 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B947 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B948                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B948 12 5A 13         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B94B E5 82            [12]  858 	mov	a, dpl
      00B94D 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B94F 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B952 22               [24]  862 	ret
      00B953                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B953 12 5A 19         [24]  865 	lcall	_rgb_matrix_get_mode
      00B956 7E 00            [12]  866 	mov	r6,#0x00
      00B958 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B95A 02 B8 E2         [24]  869 	ljmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B95D                        879 _set_mode:
      00B95D 12 3A FE         [24]  880 	lcall	_ak820_outline_0110
      00B960 90 0D DB         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B963 12 3B 03         [24]  882 	lcall	_ak820_outline_0111
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B966 90 0D DB         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B969 12 3A BD         [24]  885 	lcall	_ak820_outline_0052
      00B96C 90 0D DB         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B96F 12 72 A8         [24]  887 	lcall	_ak820_outline_0040
      00B972 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B974 02 5A 66         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B977                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B977 C0 07            [24]  893 	push	ar7
      00B979 C0 06            [24]  894 	push	ar6
      00B97B 12 5A 55         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B97E D0 06            [24]  896 	pop	ar6
      00B980 D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B982 12 3B 08         [24]  899 	lcall	_ak820_outline_0120
      00B985 12 B9 15         [24]  900 	lcall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B988 02 5A 6F         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B98B                        914 _get_matrix_pos_for_led:
      00B98B 12 3A FE         [24]  915 	lcall	_ak820_outline_0110
      00B98E 90 0D DF         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B991 12 3B 03         [24]  917 	lcall	_ak820_outline_0111
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B994 90 0D DF         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B997 12 3A BD         [24]  920 	lcall	_ak820_outline_0052
      00B99A EE               [12]  921 	mov	a,r6
      00B99B 24 FF            [12]  922 	add	a, #_ak820_rgb_slots
      00B99D F5 82            [12]  923 	mov	dpl,a
      00B99F EF               [12]  924 	mov	a,r7
      00B9A0 34 BE            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B9A2 F5 83            [12]  926 	mov	dph,a
      00B9A4 E4               [12]  927 	clr	a
      00B9A5 93               [24]  928 	movc	a,@a+dptr
      00B9A6 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B9A7 90 0D DD         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B9AA 12 3A E0         [24]  932 	lcall	_ak820_outline_0080
      00B9AD EF               [12]  933 	mov	a,r7
      00B9AE 12 5C 63         [24]  934 	lcall	_ak820_outline_0190
      00B9B1 12 86 9C         [24]  935 	lcall	_ak820_outline_0123
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B9B4 12 3B 1D         [24]  937 	lcall	_ak820_outline_0137
      00B9B7 A3               [24]  938 	inc	dptr
      00B9B8 53 07 07         [24]  939 	anl	ar7,#0x07
      00B9BB EF               [12]  940 	mov	a,r7
      00B9BC F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B9BD 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B9BE                        961 _fast_set_leds:
      00B9BE 12 3A FE         [24]  962 	lcall	_ak820_outline_0110
      00B9C1 90 0D E2         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9C4 12 3B 03         [24]  964 	lcall	_ak820_outline_0111
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B9C7 90 0D E1         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B9CA E0               [24]  967 	movx	a,@dptr
      00B9CB FF               [12]  968 	mov	r7,a
      00B9CC BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B9CF                        970 00159$:
      00B9CF 50 01            [24]  971 	jnc	00102$
      00B9D1 22               [24]  972 	ret
      00B9D2                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B9D2 90 0D E2         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9D5 12 3A E0         [24]  976 	lcall	_ak820_outline_0080
      00B9D8 12 4B 0C         [24]  977 	lcall	_ak820_outline_0077
      00B9DB 7B 00            [12]  978 	mov	r3,#0x00
      00B9DD 12 3B 1D         [24]  979 	lcall	_ak820_outline_0137
      00B9E0 A3               [24]  980 	inc	dptr
      00B9E1 E0               [24]  981 	movx	a,@dptr
      00B9E2 FA               [12]  982 	mov	r2,a
      00B9E3 79 00            [12]  983 	mov	r1,#0x00
      00B9E5 90 0D E4         [24]  984 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B9E8 E9               [12]  985 	mov	a,r1
      00B9E9 4C               [12]  986 	orl	a,r4
      00B9EA F0               [24]  987 	movx	@dptr,a
      00B9EB EA               [12]  988 	mov	a,r2
      00B9EC 4B               [12]  989 	orl	a,r3
      00B9ED A3               [24]  990 	inc	dptr
      00B9EE F0               [24]  991 	movx	@dptr,a
                                    992 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B9EF 12 3B 1D         [24]  993 	lcall	_ak820_outline_0137
      00B9F2 A3               [24]  994 	inc	dptr
      00B9F3 A3               [24]  995 	inc	dptr
      00B9F4 E0               [24]  996 	movx	a,@dptr
      00B9F5 90 0D E6         [24]  997 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B9F8 F0               [24]  998 	movx	@dptr,a
                                    999 ;	quantum/vialrgb.c:119: length -= 3;
      00B9F9 EF               [12] 1000 	mov	a,r7
      00B9FA 24 FD            [12] 1001 	add	a,#0xfd
      00B9FC 90 0D E1         [24] 1002 	mov	dptr,#_fast_set_leds_PARM_2
      00B9FF F0               [24] 1003 	movx	@dptr,a
                                   1004 ;	quantum/vialrgb.c:120: args += 3;
      00BA00 90 0D E2         [24] 1005 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA03 74 03            [12] 1006 	mov	a,#0x03
      00BA05 2D               [12] 1007 	add	a, r5
      00BA06 F0               [24] 1008 	movx	@dptr,a
      00BA07 E4               [12] 1009 	clr	a
      00BA08 3E               [12] 1010 	addc	a, r6
      00BA09 A3               [24] 1011 	inc	dptr
      00BA0A F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00BA0B 90 0D E6         [24] 1014 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA0E E0               [24] 1015 	movx	a,@dptr
      00BA0F FF               [12] 1016 	mov	r7,a
      00BA10 75 F0 03         [24] 1017 	mov	b,#0x03
      00BA13 A4               [48] 1018 	mul	ab
      00BA14 FE               [12] 1019 	mov	r6,a
      00BA15 AD F0            [24] 1020 	mov	r5,b
      00BA17 90 0D E1         [24] 1021 	mov	dptr,#_fast_set_leds_PARM_2
      00BA1A E0               [24] 1022 	movx	a,@dptr
      00BA1B FB               [12] 1023 	mov	r3,a
      00BA1C 7C 00            [12] 1024 	mov	r4,#0x00
      00BA1E C3               [12] 1025 	clr	c
      00BA1F EB               [12] 1026 	mov	a,r3
      00BA20 9E               [12] 1027 	subb	a,r6
      00BA21 EC               [12] 1028 	mov	a,r4
      00BA22 9D               [12] 1029 	subb	a,r5
      00BA23 40 13            [24] 1030 	jc	00103$
                                   1031 ;	free result
      00BA25 90 0D E4         [24] 1032 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BA28 12 3A E0         [24] 1033 	lcall	_ak820_outline_0080
      00BA2B 8D 03            [24] 1034 	mov	ar3,r5
      00BA2D 8E 04            [24] 1035 	mov	ar4,r6
      00BA2F C3               [12] 1036 	clr	c
      00BA30 EB               [12] 1037 	mov	a,r3
      00BA31 94 52            [12] 1038 	subb	a,#0x52
      00BA33 EC               [12] 1039 	mov	a,r4
      00BA34 94 00            [12] 1040 	subb	a,#0x00
      00BA36 40 01            [24] 1041 	jc	00104$
      00BA38                       1042 00103$:
      00BA38 22               [24] 1043 	ret
      00BA39                       1044 00104$:
                                   1045 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00BA39 74 52            [12] 1046 	mov	a,#0x52
      00BA3B C3               [12] 1047 	clr	c
      00BA3C 9D               [12] 1048 	subb	a,r5
      00BA3D FB               [12] 1049 	mov	r3,a
      00BA3E E4               [12] 1050 	clr	a
      00BA3F 9E               [12] 1051 	subb	a,r6
      00BA40 FC               [12] 1052 	mov	r4,a
      00BA41 7A 00            [12] 1053 	mov	r2,#0x00
      00BA43 C3               [12] 1054 	clr	c
      00BA44 EB               [12] 1055 	mov	a,r3
      00BA45 9F               [12] 1056 	subb	a,r7
      00BA46 EC               [12] 1057 	mov	a,r4
      00BA47 9A               [12] 1058 	subb	a,r2
      00BA48 50 08            [24] 1059 	jnc	00127$
                                   1060 ;	free result
      00BA4A 90 0D E6         [24] 1061 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA4D 74 52            [12] 1062 	mov	a,#0x52
      00BA4F C3               [12] 1063 	clr	c
      00BA50 9D               [12] 1064 	subb	a,r5
      00BA51 F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA52                       1067 00127$:
      00BA52 90 0D E6         [24] 1068 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00BA55 E0               [24] 1069 	movx	a,@dptr
      00BA56 FF               [12] 1070 	mov	r7,a
      00BA57 90 0D E4         [24] 1071 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00BA5A 12 3A E0         [24] 1072 	lcall	_ak820_outline_0080
      00BA5D 7C 00            [12] 1073 	mov	r4,#0x00
      00BA5F                       1074 00110$:
      00BA5F C3               [12] 1075 	clr	c
      00BA60 EC               [12] 1076 	mov	a,r4
      00BA61 9F               [12] 1077 	subb	a,r7
      00BA62 40 01            [24] 1078 	jc	00164$
      00BA64 22               [24] 1079 	ret
      00BA65                       1080 00164$:
                                   1081 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00BA65 C0 07            [24] 1082 	push	ar7
      00BA67 90 0D FE         [24] 1083 	mov	dptr,#__mulint_PARM_2
      00BA6A 12 45 E3         [24] 1084 	lcall	_ak820_outline_0141
      00BA6D 90 00 03         [24] 1085 	mov	dptr,#0x0003
      00BA70 C0 07            [24] 1086 	push	ar7
      00BA72 C0 06            [24] 1087 	push	ar6
      00BA74 C0 05            [24] 1088 	push	ar5
      00BA76 C0 04            [24] 1089 	push	ar4
      00BA78 12 BE AF         [24] 1090 	lcall	__mulint
      00BA7B AA 82            [24] 1091 	mov	r2, dpl
      00BA7D AB 83            [24] 1092 	mov	r3, dph
      00BA7F D0 04            [24] 1093 	pop	ar4
      00BA81 D0 05            [24] 1094 	pop	ar5
      00BA83 D0 06            [24] 1095 	pop	ar6
      00BA85 D0 07            [24] 1096 	pop	ar7
      00BA87 0D               [12] 1097 	inc	r5
      00BA88 BD 00 01         [24] 1098 	cjne	r5,#0x00,00165$
      00BA8B 0E               [12] 1099 	inc	r6
      00BA8C                       1100 00165$:
      00BA8C EA               [12] 1101 	mov	a,r2
      00BA8D 24 DE            [12] 1102 	add	a, #_g_direct_mode_colors
      00BA8F FA               [12] 1103 	mov	r2,a
      00BA90 EB               [12] 1104 	mov	a,r3
      00BA91 34 0C            [12] 1105 	addc	a, #(_g_direct_mode_colors >> 8)
      00BA93 FB               [12] 1106 	mov	r3,a
                                   1107 ;	quantum/vialrgb.c:128: color->h = *args++;
      00BA94 8A 4A            [24] 1108 	mov	_fast_set_leds_sloc0_1_0,r2
      00BA96 8B 4B            [24] 1109 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00BA98 12 BD 29         [24] 1110 	lcall	_ak820_outline_0085
      00BA9B F8               [12] 1111 	mov	r0,a
      00BA9C 12 BD 37         [24] 1112 	lcall	_ak820_outline_0109
      00BA9F 85 4A 82         [24] 1113 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BAA2 85 4B 83         [24] 1114 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BAA5 E8               [12] 1115 	mov	a,r0
      00BAA6 F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/vialrgb.c:129: color->s = *args++;
      00BAA7 74 01            [12] 1118 	mov	a,#0x01
      00BAA9 2A               [12] 1119 	add	a, r2
      00BAAA F5 4A            [12] 1120 	mov	_fast_set_leds_sloc0_1_0,a
      00BAAC E4               [12] 1121 	clr	a
      00BAAD 3B               [12] 1122 	addc	a, r3
      00BAAE F5 4B            [12] 1123 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BAB0 90 0D E2         [24] 1124 	mov	dptr,#_fast_set_leds_args_10000_282
      00BAB3 E0               [24] 1125 	movx	a,@dptr
      00BAB4 F8               [12] 1126 	mov	r0,a
      00BAB5 A3               [24] 1127 	inc	dptr
      00BAB6 E0               [24] 1128 	movx	a,@dptr
      00BAB7 FF               [12] 1129 	mov	r7,a
      00BAB8 88 82            [24] 1130 	mov	dpl,r0
      00BABA 8F 83            [24] 1131 	mov	dph,r7
      00BABC E0               [24] 1132 	movx	a,@dptr
      00BABD F9               [12] 1133 	mov	r1,a
      00BABE 90 0D E2         [24] 1134 	mov	dptr,#_fast_set_leds_args_10000_282
      00BAC1 74 01            [12] 1135 	mov	a,#0x01
      00BAC3 28               [12] 1136 	add	a, r0
      00BAC4 F0               [24] 1137 	movx	@dptr,a
      00BAC5 E4               [12] 1138 	clr	a
      00BAC6 3F               [12] 1139 	addc	a, r7
      00BAC7 A3               [24] 1140 	inc	dptr
      00BAC8 F0               [24] 1141 	movx	@dptr,a
      00BAC9 85 4A 82         [24] 1142 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BACC 85 4B 83         [24] 1143 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BACF E9               [12] 1144 	mov	a,r1
      00BAD0 F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BAD1 12 BD 29         [24] 1147 	lcall	_ak820_outline_0085
      00BAD4 F5 4A            [12] 1148 	mov	_fast_set_leds_sloc0_1_0,a
      00BAD6 12 BD 37         [24] 1149 	lcall	_ak820_outline_0109
                                   1150 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BAD9 74 02            [12] 1151 	mov	a,#0x02
      00BADB 2A               [12] 1152 	add	a, r2
      00BADC F5 4C            [12] 1153 	mov	_fast_set_leds_sloc1_1_0,a
      00BADE E4               [12] 1154 	clr	a
      00BADF 3B               [12] 1155 	addc	a, r3
      00BAE0 F5 4D            [12] 1156 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BAE2 C3               [12] 1157 	clr	c
      00BAE3 74 A0            [12] 1158 	mov	a,#0xa0
      00BAE5 95 4A            [12] 1159 	subb	a,_fast_set_leds_sloc0_1_0
      00BAE7 D0 07            [24] 1160 	pop	ar7
      00BAE9 50 04            [24] 1161 	jnc	00114$
                                   1162 ;	free result
      00BAEB 7B A0            [12] 1163 	mov	r3,#0xa0
      00BAED 80 04            [24] 1164 	sjmp	00115$
      00BAEF                       1165 00114$:
      00BAEF AA 4A            [24] 1166 	mov	r2,_fast_set_leds_sloc0_1_0
      00BAF1 8A 03            [24] 1167 	mov	ar3,r2
      00BAF3                       1168 00115$:
      00BAF3 85 4C 82         [24] 1169 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BAF6 85 4D 83         [24] 1170 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BAF9 EB               [12] 1171 	mov	a,r3
      00BAFA F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BAFB 0C               [12] 1174 	inc	r4
                                   1175 ;	quantum/vialrgb.c:133: }
      00BAFC 02 BA 5F         [24] 1176 	ljmp	00110$
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1179 ;------------------------------------------------------------
                                   1180 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1181 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1182 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1183 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1184 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1185 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1186 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1187 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function vialrgb_get_value
                                   1192 ;	-----------------------------------------
      00BAFF                       1193 _vialrgb_get_value:
      00BAFF 12 45 8F         [24] 1194 	lcall	_ak820_outline_0036
      00BB02 90 0D E8         [24] 1195 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BB05 12 3A 9B         [24] 1196 	lcall	_ak820_outline_0016
                                   1197 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BB08 90 0D E7         [24] 1198 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BB0B E0               [24] 1199 	movx	a,@dptr
      00BB0C FF               [12] 1200 	mov	r7,a
      00BB0D BF 20 02         [24] 1201 	cjne	r7,#0x20,00162$
      00BB10 80 01            [24] 1202 	sjmp	00102$
      00BB12                       1203 00162$:
      00BB12 22               [24] 1204 	ret
      00BB13                       1205 00102$:
                                   1206 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB13 90 0D E8         [24] 1207 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BB16 12 BD 03         [24] 1208 	lcall	_ak820_outline_0046
                                   1209 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1210 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BB19 BA 40 02         [24] 1211 	cjne	r2,#0x40,00163$
      00BB1C 80 18            [24] 1212 	sjmp	00103$
      00BB1E                       1213 00163$:
      00BB1E BA 41 02         [24] 1214 	cjne	r2,#0x41,00164$
      00BB21 80 26            [24] 1215 	sjmp	00104$
      00BB23                       1216 00164$:
      00BB23 BA 42 03         [24] 1217 	cjne	r2,#0x42,00165$
      00BB26 02 BB DB         [24] 1218 	ljmp	00105$
      00BB29                       1219 00165$:
      00BB29 BA 43 03         [24] 1220 	cjne	r2,#0x43,00166$
      00BB2C 02 BB E7         [24] 1221 	ljmp	00106$
      00BB2F                       1222 00166$:
      00BB2F BA 44 03         [24] 1223 	cjne	r2,#0x44,00167$
      00BB32 02 BB F3         [24] 1224 	ljmp	00107$
      00BB35                       1225 00167$:
      00BB35 22               [24] 1226 	ret
                                   1227 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BB36                       1228 00103$:
                                   1229 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BB36 12 36 78         [24] 1230 	lcall	_ak820_outline_0125
      00BB39 74 01            [12] 1231 	mov	a,#0x01
      00BB3B F0               [24] 1232 	movx	@dptr,a
                                   1233 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BB3C 12 BC FB         [24] 1234 	lcall	_ak820_outline_0039
      00BB3F E4               [12] 1235 	clr	a
      00BB40 F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BB41 12 BC FB         [24] 1238 	lcall	_ak820_outline_0039
      00BB44 A3               [24] 1239 	inc	dptr
      00BB45 74 A0            [12] 1240 	mov	a,#0xa0
      00BB47 F0               [24] 1241 	movx	@dptr,a
                                   1242 ;	quantum/vialrgb.c:147: break;
      00BB48 22               [24] 1243 	ret
                                   1244 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BB49                       1245 00104$:
                                   1246 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BB49 C0 06            [24] 1247 	push	ar6
      00BB4B C0 05            [24] 1248 	push	ar5
      00BB4D C0 04            [24] 1249 	push	ar4
      00BB4F C0 03            [24] 1250 	push	ar3
      00BB51 12 B9 48         [24] 1251 	lcall	_get_mode
      00BB54 A9 82            [24] 1252 	mov	r1, dpl
      00BB56 AA 83            [24] 1253 	mov	r2, dph
      00BB58 D0 03            [24] 1254 	pop	ar3
      00BB5A D0 04            [24] 1255 	pop	ar4
      00BB5C D0 05            [24] 1256 	pop	ar5
      00BB5E D0 06            [24] 1257 	pop	ar6
                                   1258 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BB60 89 00            [24] 1259 	mov	ar0,r1
      00BB62 12 36 78         [24] 1260 	lcall	_ak820_outline_0125
      00BB65 E8               [12] 1261 	mov	a,r0
      00BB66 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BB67 12 BC FB         [24] 1264 	lcall	_ak820_outline_0039
      00BB6A 8A 01            [24] 1265 	mov	ar1,r2
      00BB6C E9               [12] 1266 	mov	a,r1
      00BB6D F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BB6E 74 04            [12] 1269 	mov	a,#0x04
      00BB70 12 94 01         [24] 1270 	lcall	_ak820_outline_0138
      00BB73 C0 06            [24] 1271 	push	ar6
      00BB75 C0 05            [24] 1272 	push	ar5
      00BB77 C0 02            [24] 1273 	push	ar2
      00BB79 C0 01            [24] 1274 	push	ar1
      00BB7B 12 5A 34         [24] 1275 	lcall	_rgb_matrix_get_speed
      00BB7E A8 82            [24] 1276 	mov	r0, dpl
      00BB80 D0 01            [24] 1277 	pop	ar1
      00BB82 D0 02            [24] 1278 	pop	ar2
      00BB84 D0 05            [24] 1279 	pop	ar5
      00BB86 D0 06            [24] 1280 	pop	ar6
      00BB88 12 86 75         [24] 1281 	lcall	_ak820_outline_0064
                                   1282 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BB8B 74 05            [12] 1283 	mov	a,#0x05
      00BB8D 12 94 01         [24] 1284 	lcall	_ak820_outline_0138
      00BB90 C0 06            [24] 1285 	push	ar6
      00BB92 C0 05            [24] 1286 	push	ar5
      00BB94 C0 02            [24] 1287 	push	ar2
      00BB96 C0 01            [24] 1288 	push	ar1
      00BB98 12 5A 1F         [24] 1289 	lcall	_rgb_matrix_get_hue
      00BB9B A8 82            [24] 1290 	mov	r0, dpl
      00BB9D D0 01            [24] 1291 	pop	ar1
      00BB9F D0 02            [24] 1292 	pop	ar2
      00BBA1 D0 05            [24] 1293 	pop	ar5
      00BBA3 D0 06            [24] 1294 	pop	ar6
      00BBA5 12 86 75         [24] 1295 	lcall	_ak820_outline_0064
                                   1296 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BBA8 74 06            [12] 1297 	mov	a,#0x06
      00BBAA 12 94 01         [24] 1298 	lcall	_ak820_outline_0138
      00BBAD C0 06            [24] 1299 	push	ar6
      00BBAF C0 05            [24] 1300 	push	ar5
      00BBB1 C0 02            [24] 1301 	push	ar2
      00BBB3 C0 01            [24] 1302 	push	ar1
      00BBB5 12 5A 26         [24] 1303 	lcall	_rgb_matrix_get_sat
      00BBB8 A8 82            [24] 1304 	mov	r0, dpl
      00BBBA D0 01            [24] 1305 	pop	ar1
      00BBBC D0 02            [24] 1306 	pop	ar2
      00BBBE D0 05            [24] 1307 	pop	ar5
      00BBC0 D0 06            [24] 1308 	pop	ar6
      00BBC2 12 86 75         [24] 1309 	lcall	_ak820_outline_0064
                                   1310 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BBC5 74 07            [12] 1311 	mov	a,#0x07
      00BBC7 12 94 01         [24] 1312 	lcall	_ak820_outline_0138
      00BBCA C0 02            [24] 1313 	push	ar2
      00BBCC C0 01            [24] 1314 	push	ar1
      00BBCE 12 5A 2D         [24] 1315 	lcall	_rgb_matrix_get_val
      00BBD1 A8 82            [24] 1316 	mov	r0, dpl
      00BBD3 D0 01            [24] 1317 	pop	ar1
      00BBD5 D0 02            [24] 1318 	pop	ar2
      00BBD7 12 86 75         [24] 1319 	lcall	_ak820_outline_0064
                                   1320 ;	quantum/vialrgb.c:156: break;
      00BBDA 22               [24] 1321 	ret
                                   1322 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BBDB                       1323 00105$:
                                   1324 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BBDB EF               [12] 1325 	mov	a,r7
      00BBDC 24 FE            [12] 1326 	add	a,#0xfe
      00BBDE 90 0D D4         [24] 1327 	mov	dptr,#_get_supported_PARM_2
      00BBE1 12 74 DC         [24] 1328 	lcall	_ak820_outline_0103
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BBE4 02 B8 50         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BBE7                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BBE7 12 36 78         [24] 1334 	lcall	_ak820_outline_0125
      00BBEA 74 52            [12] 1335 	mov	a,#0x52
      00BBEC F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BBED 12 BC FB         [24] 1338 	lcall	_ak820_outline_0039
      00BBF0 E4               [12] 1339 	clr	a
      00BBF1 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BBF2 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BBF3                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BBF3 12 36 78         [24] 1346 	lcall	_ak820_outline_0125
      00BBF6 E0               [24] 1347 	movx	a,@dptr
      00BBF7 FF               [12] 1348 	mov	r7,a
      00BBF8 7A 00            [12] 1349 	mov	r2,#0x00
      00BBFA 74 03            [12] 1350 	mov	a,#0x03
      00BBFC 2D               [12] 1351 	add	a, r5
      00BBFD F8               [12] 1352 	mov	r0,a
      00BBFE E4               [12] 1353 	clr	a
      00BBFF 3E               [12] 1354 	addc	a, r6
      00BC00 F9               [12] 1355 	mov	r1,a
      00BC01 C0 03            [24] 1356 	push	ar3
      00BC03 C0 04            [24] 1357 	push	ar4
      00BC05 12 3B 32         [24] 1358 	lcall	_ak820_outline_0164
      00BC08 E0               [24] 1359 	movx	a,@dptr
      00BC09 FB               [12] 1360 	mov	r3,a
      00BC0A E4               [12] 1361 	clr	a
      00BC0B 4F               [12] 1362 	orl	a,r7
      00BC0C F5 4E            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BC0E EB               [12] 1364 	mov	a,r3
      00BC0F 4A               [12] 1365 	orl	a,r2
      00BC10 F5 4F            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BC12 AC 4E            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BC14 AF 4F            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BC16 C3               [12] 1370 	clr	c
      00BC17 EC               [12] 1371 	mov	a,r4
      00BC18 94 52            [12] 1372 	subb	a,#0x52
      00BC1A EF               [12] 1373 	mov	a,r7
      00BC1B 94 00            [12] 1374 	subb	a,#0x00
      00BC1D D0 04            [24] 1375 	pop	ar4
      00BC1F D0 03            [24] 1376 	pop	ar3
      00BC21 40 01            [24] 1377 	jc	00109$
      00BC23 22               [24] 1378 	ret
      00BC24                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BC24 E5 4E            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BC26 25 4E            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BC28 FA               [12] 1383 	mov	r2,a
      00BC29 E5 4F            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BC2B 33               [12] 1385 	rlc	a
      00BC2C FF               [12] 1386 	mov	r7,a
      00BC2D EA               [12] 1387 	mov	a,r2
      00BC2E 24 B9            [12] 1388 	add	a, #_ak820_led_points
      00BC30 F5 50            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BC32 EF               [12] 1390 	mov	a,r7
      00BC33 34 C1            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BC35 F5 51            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BC37 85 50 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BC3A 85 51 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BC3D E4               [12] 1395 	clr	a
      00BC3E 93               [24] 1396 	movc	a,@a+dptr
      00BC3F 12 36 78         [24] 1397 	lcall	_ak820_outline_0125
      00BC42 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BC43 85 50 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BC46 85 51 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BC49 A3               [24] 1402 	inc	dptr
      00BC4A E4               [12] 1403 	clr	a
      00BC4B 93               [24] 1404 	movc	a,@a+dptr
      00BC4C 12 3B 32         [24] 1405 	lcall	_ak820_outline_0164
      00BC4F F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BC50 12 BC FB         [24] 1408 	lcall	_ak820_outline_0039
      00BC53 A3               [24] 1409 	inc	dptr
      00BC54 74 04            [12] 1410 	mov	a,#0x04
      00BC56 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BC57 90 0D DD         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BC5A 04               [12] 1414 	inc	a
      00BC5B 2D               [12] 1415 	add	a, r5
      00BC5C F0               [24] 1416 	movx	@dptr,a
      00BC5D E4               [12] 1417 	clr	a
      00BC5E 3E               [12] 1418 	addc	a, r6
      00BC5F A3               [24] 1419 	inc	dptr
      00BC60 F0               [24] 1420 	movx	@dptr,a
      00BC61 85 4E 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BC64 85 4F 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BC67 02 B9 8B         [24] 1425 	ljmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BC6A                       1440 _vialrgb_set_value:
      00BC6A 12 45 8F         [24] 1441 	lcall	_ak820_outline_0036
      00BC6D 90 0D EC         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BC70 12 3A 9B         [24] 1443 	lcall	_ak820_outline_0016
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BC73 90 0D EB         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BC76 E0               [24] 1446 	movx	a,@dptr
      00BC77 FF               [12] 1447 	mov	r7,a
      00BC78 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BC7B 80 01            [24] 1449 	sjmp	00102$
      00BC7D                       1450 00129$:
      00BC7D 22               [24] 1451 	ret
      00BC7E                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BC7E 90 0D EC         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BC81 12 BD 03         [24] 1455 	lcall	_ak820_outline_0046
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BC84 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BC87 80 06            [24] 1459 	sjmp	00103$
      00BC89                       1460 00130$:
      00BC89 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BC8C 80 5E            [24] 1462 	sjmp	00104$
      00BC8E                       1463 00131$:
      00BC8E 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BC8F                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BC8F 12 36 78         [24] 1468 	lcall	_ak820_outline_0125
      00BC92 E0               [24] 1469 	movx	a,@dptr
      00BC93 FA               [12] 1470 	mov	r2,a
      00BC94 12 BC FB         [24] 1471 	lcall	_ak820_outline_0039
      00BC97 E0               [24] 1472 	movx	a,@dptr
      00BC98 F8               [12] 1473 	mov	r0,a
      00BC99 79 00            [12] 1474 	mov	r1,#0x00
      00BC9B 88 53            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BC9D 89 52            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BC9F 8A 01            [24] 1477 	mov	ar1,r2
      00BCA1 7A 00            [12] 1478 	mov	r2,#0x00
      00BCA3 E5 53            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BCA5 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BCA7 12 45 FF         [24] 1482 	lcall	_ak820_outline_0185
      00BCAA C0 06            [24] 1483 	push	ar6
      00BCAC C0 05            [24] 1484 	push	ar5
      00BCAE 12 B9 5D         [24] 1485 	lcall	_set_mode
      00BCB1 D0 05            [24] 1486 	pop	ar5
      00BCB3 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BCB5 12 BC FB         [24] 1489 	lcall	_ak820_outline_0039
      00BCB8 A3               [24] 1490 	inc	dptr
      00BCB9 E0               [24] 1491 	movx	a,@dptr
      00BCBA F5 82            [12] 1492 	mov	dpl,a
      00BCBC C0 06            [24] 1493 	push	ar6
      00BCBE C0 05            [24] 1494 	push	ar5
      00BCC0 12 5B 02         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BCC3 D0 05            [24] 1496 	pop	ar5
      00BCC5 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BCC7 12 BC FB         [24] 1499 	lcall	_ak820_outline_0039
      00BCCA A3               [24] 1500 	inc	dptr
      00BCCB A3               [24] 1501 	inc	dptr
      00BCCC E0               [24] 1502 	movx	a,@dptr
      00BCCD F9               [12] 1503 	mov	r1,a
      00BCCE 7A 00            [12] 1504 	mov	r2,#0x00
      00BCD0 74 06            [12] 1505 	mov	a,#0x06
      00BCD2 12 BD 4D         [24] 1506 	lcall	_ak820_outline_0174
      00BCD5 F8               [12] 1507 	mov	r0,a
      00BCD6 74 07            [12] 1508 	mov	a,#0x07
      00BCD8 12 BD 4D         [24] 1509 	lcall	_ak820_outline_0174
      00BCDB FE               [12] 1510 	mov	r6,a
      00BCDC 90 07 58         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BCDF E8               [12] 1512 	mov	a,r0
      00BCE0 F0               [24] 1513 	movx	@dptr,a
      00BCE1 90 07 59         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BCE4 EE               [12] 1515 	mov	a,r6
      00BCE5 F0               [24] 1516 	movx	@dptr,a
      00BCE6 12 45 FF         [24] 1517 	lcall	_ak820_outline_0185
                                   1518 ;	quantum/vialrgb.c:202: break;
                                   1519 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BCE9 02 5A D3         [24] 1520 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BCEC                       1521 00104$:
                                   1522 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BCEC EF               [12] 1523 	mov	a,r7
      00BCED 24 FE            [12] 1524 	add	a,#0xfe
      00BCEF 90 0D E1         [24] 1525 	mov	dptr,#_fast_set_leds_PARM_2
      00BCF2 12 74 DC         [24] 1526 	lcall	_ak820_outline_0103
                                   1527 ;	quantum/vialrgb.c:210: }
                                   1528 ;	quantum/vialrgb.c:211: }
      00BCF5 02 B9 BE         [24] 1529 	ljmp	_fast_set_leds
                                   1530 ;------------------------------------------------------------
                                   1531 ;Allocation info for local variables in function 'vialrgb_save'
                                   1532 ;------------------------------------------------------------
                                   1533 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1534 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1535 ;------------------------------------------------------------
                                   1536 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1537 ;	-----------------------------------------
                                   1538 ;	 function vialrgb_save
                                   1539 ;	-----------------------------------------
      00BCF8                       1540 _vialrgb_save:
                                   1541 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1542 ;	quantum/vialrgb.c:218: }
      00BCF8 02 55 5A         [24] 1543 	ljmp	_eeconfig_update_rgb_matrix
                                   1544 	.area CSEG    (CODE)
                                   1545 	.area CONST   (CODE)
                                   1546 	.area CONST   (CODE)
      00C500                       1547 _supported_modes:
      00C500 00                    1548 	.db #0x00	; 0
      00C501 00                    1549 	.db #0x00	; 0
      00C502 01                    1550 	.db #0x01	; 1
      00C503 05                    1551 	.db #0x05	; 5
      00C504 02                    1552 	.db #0x02	; 2
      00C505 01                    1553 	.db #0x01	; 1
      00C506 06                    1554 	.db #0x06	; 6
      00C507 02                    1555 	.db #0x02	; 2
      00C508 0D                    1556 	.db #0x0d	; 13
      00C509 03                    1557 	.db #0x03	; 3
      00C50A 0E                    1558 	.db #0x0e	; 14
      00C50B 04                    1559 	.db #0x04	; 4
      00C50C 1F                    1560 	.db #0x1f	; 31
      00C50D 06                    1561 	.db #0x06	; 6
                                   1562 	.area CSEG    (CODE)
                                   1563 	.area XINIT   (CODE)
                                   1564 	.area CABS    (ABS,CODE)
                                   1565 
                                   1566 ; Experimental exact instruction outlining.
                                   1567 	.globl _ak820_outline_0005
                                   1568 	.globl _ak820_outline_0016
                                   1569 	.globl _ak820_outline_0022
                                   1570 	.globl _ak820_outline_0036
                                   1571 	.globl _ak820_outline_0039
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0046
                                   1574 	.globl _ak820_outline_0047
                                   1575 	.globl _ak820_outline_0052
                                   1576 	.globl _ak820_outline_0064
                                   1577 	.globl _ak820_outline_0077
                                   1578 	.globl _ak820_outline_0080
                                   1579 	.globl _ak820_outline_0085
                                   1580 	.globl _ak820_outline_0086
                                   1581 	.globl _ak820_outline_0103
                                   1582 	.globl _ak820_outline_0109
                                   1583 	.globl _ak820_outline_0110
                                   1584 	.globl _ak820_outline_0111
                                   1585 	.globl _ak820_outline_0112
                                   1586 	.globl _ak820_outline_0120
                                   1587 	.globl _ak820_outline_0123
                                   1588 	.globl _ak820_outline_0124
                                   1589 	.globl _ak820_outline_0125
                                   1590 	.globl _ak820_outline_0137
                                   1591 	.globl _ak820_outline_0138
                                   1592 	.globl _ak820_outline_0141
                                   1593 	.globl _ak820_outline_0147
                                   1594 	.globl _ak820_outline_0149
                                   1595 	.globl _ak820_outline_0164
                                   1596 	.globl _ak820_outline_0174
                                   1597 	.globl _ak820_outline_0185
                                   1598 	.globl _ak820_outline_0190
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0039
      00BCFB                       1602 _ak820_outline_0039:
      00BCFB 8D 82            [24] 1603 	mov	dpl,r5
      00BCFD 8E 83            [24] 1604 	mov	dph,r6
      00BCFF A3               [24] 1605 	inc	dptr
      00BD00 A3               [24] 1606 	inc	dptr
      00BD01 A3               [24] 1607 	inc	dptr
      00BD02 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0046
      00BD03                       1612 _ak820_outline_0046:
      00BD03 E0               [24] 1613 	movx	a,@dptr
      00BD04 FD               [12] 1614 	mov	r5,a
      00BD05 A3               [24] 1615 	inc	dptr
      00BD06 E0               [24] 1616 	movx	a,@dptr
      00BD07 FE               [12] 1617 	mov	r6,a
      00BD08 74 02            [12] 1618 	mov	a,#0x02
      00BD0A 2D               [12] 1619 	add	a,r5
      00BD0B FB               [12] 1620 	mov	r3,a
      00BD0C E4               [12] 1621 	clr	a
      00BD0D 3E               [12] 1622 	addc	a,r6
      00BD0E FC               [12] 1623 	mov	r4,a
      00BD0F 8D 82            [24] 1624 	mov	dpl,r5
      00BD11 8E 83            [24] 1625 	mov	dph,r6
      00BD13 A3               [24] 1626 	inc	dptr
      00BD14 E0               [24] 1627 	movx	a,@dptr
      00BD15 FA               [12] 1628 	mov	r2,a
      00BD16 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0047
      00BD17                       1633 _ak820_outline_0047:
      00BD17 ED               [12] 1634 	mov	a,r5
      00BD18 75 F0 02         [24] 1635 	mov	b,#0x02
      00BD1B A4               [48] 1636 	mul	ab
      00BD1C 24 00            [12] 1637 	add	a,#_supported_modes
      00BD1E FB               [12] 1638 	mov	r3,a
      00BD1F 74 C5            [12] 1639 	mov	a,#(_supported_modes>>8)
      00BD21 35 F0            [12] 1640 	addc	a,b
      00BD23 FC               [12] 1641 	mov	r4,a
      00BD24 8B 82            [24] 1642 	mov	dpl,r3
      00BD26 8C 83            [24] 1643 	mov	dph,r4
      00BD28 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0085
      00BD29                       1648 _ak820_outline_0085:
      00BD29 90 0D E2         [24] 1649 	mov	dptr,#_fast_set_leds_args_10000_282
      00BD2C E0               [24] 1650 	movx	a,@dptr
      00BD2D F9               [12] 1651 	mov	r1,a
      00BD2E A3               [24] 1652 	inc	dptr
      00BD2F E0               [24] 1653 	movx	a,@dptr
      00BD30 FF               [12] 1654 	mov	r7,a
      00BD31 89 82            [24] 1655 	mov	dpl,r1
      00BD33 8F 83            [24] 1656 	mov	dph,r7
      00BD35 E0               [24] 1657 	movx	a,@dptr
      00BD36 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0109
      00BD37                       1662 _ak820_outline_0109:
      00BD37 90 0D E2         [24] 1663 	mov	dptr,#_fast_set_leds_args_10000_282
      00BD3A 74 01            [12] 1664 	mov	a,#0x01
      00BD3C 29               [12] 1665 	add	a,r1
      00BD3D F0               [24] 1666 	movx	@dptr,a
      00BD3E E4               [12] 1667 	clr	a
      00BD3F 3F               [12] 1668 	addc	a,r7
      00BD40 A3               [24] 1669 	inc	dptr
      00BD41 F0               [24] 1670 	movx	@dptr,a
      00BD42 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0149
      00BD43                       1675 _ak820_outline_0149:
      00BD43 E4               [12] 1676 	clr	a
      00BD44 93               [24] 1677 	movc	a,@a+dptr
      00BD45 FC               [12] 1678 	mov	r4,a
      00BD46 7B 00            [12] 1679 	mov	r3,#0x00
      00BD48 8C 82            [24] 1680 	mov	dpl,r4
      00BD4A 8B 83            [24] 1681 	mov	dph,r3
      00BD4C 22               [24] 1682 	ret
                                   1683 
                                   1684 	.area CSEG (CODE)
                                   1685 ; function ak820_outline_0174
      00BD4D                       1686 _ak820_outline_0174:
      00BD4D 2D               [12] 1687 	add	a,r5
      00BD4E F5 82            [12] 1688 	mov	dpl,a
      00BD50 E4               [12] 1689 	clr	a
      00BD51 3E               [12] 1690 	addc	a,r6
      00BD52 F5 83            [12] 1691 	mov	dph,a
      00BD54 E0               [24] 1692 	movx	a,@dptr
      00BD55 22               [24] 1693 	ret
