                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000026                        582 _get_record_keycode_sloc0_1_0:
      000026                        583 	.ds 1
      000027                        584 _pre_process_record_quantum_sloc0_1_0:
      000027                        585 	.ds 1
      000028                        586 _process_ak820_nkro_sloc0_1_0:
      000028                        587 	.ds 1
                                    588 ;--------------------------------------------------------
                                    589 ; paged external ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area PSEG    (PAG,XDATA)
                                    592 ;--------------------------------------------------------
                                    593 ; uninitialized external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XSEG    (XDATA)
      000C1F                        596 _extract_mod_bits_code_10000_600:
      000C1F                        597 	.ds 2
      000C21                        598 _register_code16_code_10000_606:
      000C21                        599 	.ds 2
      000C23                        600 _unregister_code16_code_10000_611:
      000C23                        601 	.ds 2
      000C25                        602 _pre_process_record_kb_PARM_2:
      000C25                        603 	.ds 3
      000C28                        604 _pre_process_record_kb_keycode_10000_625:
      000C28                        605 	.ds 2
      000C2A                        606 _pre_process_record_user_PARM_2:
      000C2A                        607 	.ds 3
      000C2D                        608 _process_record_kb_PARM_2:
      000C2D                        609 	.ds 3
      000C30                        610 _process_record_kb_keycode_10000_631:
      000C30                        611 	.ds 2
      000C32                        612 _process_record_user_PARM_2:
      000C32                        613 	.ds 3
      000C35                        614 _post_process_record_kb_PARM_2:
      000C35                        615 	.ds 3
      000C38                        616 _post_process_record_kb_keycode_10000_635:
      000C38                        617 	.ds 2
      000C3A                        618 _post_process_record_user_PARM_2:
      000C3A                        619 	.ds 3
      000C3D                        620 _get_record_keycode_PARM_2:
      000C3D                        621 	.ds 1
      000C3E                        622 _get_record_keycode_record_argument_10000_649:
      000C3E                        623 	.ds 3
      000C41                        624 _pre_process_record_quantum_record_argument_10000_655:
      000C41                        625 	.ds 3
      000C44                        626 _post_process_record_quantum_record_10000_657:
      000C44                        627 	.ds 3
      000C47                        628 _process_record_quantum_record_10000_659:
      000C47                        629 	.ds 3
      000C4A                        630 _process_ak820_nkro_PARM_2:
      000C4A                        631 	.ds 3
      000C4D                        632 _process_ak820_nkro_keycode_10000_661:
      000C4D                        633 	.ds 2
      000C4F                        634 _process_record_quantum_helper_PARM_2:
      000C4F                        635 	.ds 3
      000C52                        636 _process_record_quantum_helper_keycode_10000_666:
      000C52                        637 	.ds 2
      000C54                        638 _get_u8_str_buf_10000_692:
      000C54                        639 	.ds 4
      000C58                        640 _get_u8_str_last_num_10000_692:
      000C58                        641 	.ds 1
      000C59                        642 _get_u8_str_last_pad_10000_692:
      000C59                        643 	.ds 1
      000C5A                        644 _get_u16_str_buf_10000_696:
      000C5A                        645 	.ds 6
      000C60                        646 _get_u16_str_last_num_10000_696:
      000C60                        647 	.ds 2
      000C62                        648 _get_u16_str_last_pad_10000_696:
      000C62                        649 	.ds 1
                                    650 ;--------------------------------------------------------
                                    651 ; absolute external ram data
                                    652 ;--------------------------------------------------------
                                    653 	.area XABS    (ABS,XDATA)
                                    654 ;--------------------------------------------------------
                                    655 ; initialized external ram data
                                    656 ;--------------------------------------------------------
                                    657 	.area XISEG   (XDATA)
                                    658 	.area HOME    (CODE)
                                    659 	.area GSINIT0 (CODE)
                                    660 	.area GSINIT1 (CODE)
                                    661 	.area GSINIT2 (CODE)
                                    662 	.area GSINIT3 (CODE)
                                    663 	.area GSINIT4 (CODE)
                                    664 	.area GSINIT5 (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area CSEG    (CODE)
                                    668 ;--------------------------------------------------------
                                    669 ; global & static initialisations
                                    670 ;--------------------------------------------------------
                                    671 	.area HOME    (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 ;------------------------------------------------------------
                                    676 ;Allocation info for local variables in function 'get_u8_str'
                                    677 ;------------------------------------------------------------
                                    678 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    679 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_691'
                                    680 ;buf           Allocated with name '_get_u8_str_buf_10000_692'
                                    681 ;last_num      Allocated with name '_get_u8_str_last_num_10000_692'
                                    682 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_692'
                                    683 ;------------------------------------------------------------
                                    684 ;	quantum/quantum.c:735: static char    buf[4]   = {0};
      0030F3 90 0C 54         [24]  685 	mov	dptr,#_get_u8_str_buf_10000_692
      0030F6 E4               [12]  686 	clr	a
      0030F7 F0               [24]  687 	movx	@dptr,a
      0030F8 90 0C 55         [24]  688 	mov	dptr,#(_get_u8_str_buf_10000_692 + 0x0001)
      0030FB F0               [24]  689 	movx	@dptr,a
      0030FC 90 0C 56         [24]  690 	mov	dptr,#(_get_u8_str_buf_10000_692 + 0x0002)
      0030FF F0               [24]  691 	movx	@dptr,a
      003100 90 0C 57         [24]  692 	mov	dptr,#(_get_u8_str_buf_10000_692 + 0x0003)
      003103 F0               [24]  693 	movx	@dptr,a
                                    694 ;	quantum/quantum.c:736: static uint8_t last_num = 0xFF;
      003104 90 0C 58         [24]  695 	mov	dptr,#_get_u8_str_last_num_10000_692
      003107 14               [12]  696 	dec	a
      003108 F0               [24]  697 	movx	@dptr,a
                                    698 ;	quantum/quantum.c:737: static char    last_pad = '\0';
      003109 90 0C 59         [24]  699 	mov	dptr,#_get_u8_str_last_pad_10000_692
      00310C E4               [12]  700 	clr	a
      00310D F0               [24]  701 	movx	@dptr,a
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'get_u16_str'
                                    704 ;------------------------------------------------------------
                                    705 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    706 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_695'
                                    707 ;buf           Allocated with name '_get_u16_str_buf_10000_696'
                                    708 ;last_num      Allocated with name '_get_u16_str_last_num_10000_696'
                                    709 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_696'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/quantum.c:755: static char     buf[6]   = {0};
      00310E 90 0C 5A         [24]  712 	mov	dptr,#_get_u16_str_buf_10000_696
      003111 E4               [12]  713 	clr	a
      003112 F0               [24]  714 	movx	@dptr,a
      003113 90 0C 5B         [24]  715 	mov	dptr,#(_get_u16_str_buf_10000_696 + 0x0001)
      003116 F0               [24]  716 	movx	@dptr,a
      003117 90 0C 5C         [24]  717 	mov	dptr,#(_get_u16_str_buf_10000_696 + 0x0002)
      00311A F0               [24]  718 	movx	@dptr,a
      00311B 90 0C 5D         [24]  719 	mov	dptr,#(_get_u16_str_buf_10000_696 + 0x0003)
      00311E F0               [24]  720 	movx	@dptr,a
      00311F 90 0C 5E         [24]  721 	mov	dptr,#(_get_u16_str_buf_10000_696 + 0x0004)
      003122 F0               [24]  722 	movx	@dptr,a
      003123 90 0C 5F         [24]  723 	mov	dptr,#(_get_u16_str_buf_10000_696 + 0x0005)
      003126 F0               [24]  724 	movx	@dptr,a
                                    725 ;	quantum/quantum.c:756: static uint16_t last_num = 0xFF;
      003127 90 0C 60         [24]  726 	mov	dptr,#_get_u16_str_last_num_10000_696
      00312A 14               [12]  727 	dec	a
      00312B F0               [24]  728 	movx	@dptr,a
      00312C E4               [12]  729 	clr	a
      00312D A3               [24]  730 	inc	dptr
      00312E F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/quantum.c:757: static char     last_pad = '\0';
      00312F 90 0C 62         [24]  733 	mov	dptr,#_get_u16_str_last_pad_10000_696
      003132 F0               [24]  734 	movx	@dptr,a
                                    735 ;--------------------------------------------------------
                                    736 ; Home
                                    737 ;--------------------------------------------------------
                                    738 	.area HOME    (CODE)
                                    739 	.area HOME    (CODE)
                                    740 ;--------------------------------------------------------
                                    741 ; code
                                    742 ;--------------------------------------------------------
                                    743 	.area CSEG    (CODE)
                                    744 ;------------------------------------------------------------
                                    745 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    746 ;------------------------------------------------------------
                                    747 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    748 ;------------------------------------------------------------
                                    749 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    750 ;	-----------------------------------------
                           000007   751 	ar7 = 0x07
                           000006   752 	ar6 = 0x06
                           000005   753 	ar5 = 0x05
                           000004   754 	ar4 = 0x04
                           000003   755 	ar3 = 0x03
                           000002   756 	ar2 = 0x02
                           000001   757 	ar1 = 0x01
                           000000   758 	ar0 = 0x00
                                    759 ;	 function extract_mod_bits
                                    760 ;	-----------------------------------------
      00A326                        761 _extract_mod_bits:
      00A326 12 3A FE         [24]  762 	lcall	_ak820_outline_0110
      00A329 90 0C 1F         [24]  763 	mov	dptr,#_extract_mod_bits_code_10000_600
      00A32C 12 3B 03         [24]  764 	lcall	_ak820_outline_0111
                                    765 ;	quantum/quantum.c:104: uint8_t mods = (uint8_t)(code >> 8);
      00A32F 90 0C 1F         [24]  766 	mov	dptr,#_extract_mod_bits_code_10000_600
      00A332 E0               [24]  767 	movx	a,@dptr
      00A333 A3               [24]  768 	inc	dptr
      00A334 E0               [24]  769 	movx	a,@dptr
                                    770 ;	quantum/quantum.c:105: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A335 FF               [12]  771 	mov	r7,a
      00A336 60 05            [24]  772 	jz	00101$
      00A338 EF               [12]  773 	mov	a,r7
      00A339 24 E0            [12]  774 	add	a,#0xff - 0x1f
      00A33B 50 04            [24]  775 	jnc	00102$
                                    776 ;	free result
      00A33D                        777 00101$:
      00A33D 75 82 00         [24]  778 	mov	dpl, #0x00
      00A340 22               [24]  779 	ret
      00A341                        780 00102$:
                                    781 ;	quantum/quantum.c:106: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A341 EF               [12]  782 	mov	a,r7
      00A342 30 E4 07         [24]  783 	jnb	acc.4,00106$
      00A345 EF               [12]  784 	mov	a,r7
      00A346 C4               [12]  785 	swap	a
      00A347 54 F0            [12]  786 	anl	a,#0xf0
      00A349 FE               [12]  787 	mov	r6,a
      00A34A 80 02            [24]  788 	sjmp	00107$
      00A34C                        789 00106$:
      00A34C 8F 06            [24]  790 	mov	ar6,r7
      00A34E                        791 00107$:
      00A34E 8E 82            [24]  792 	mov	dpl, r6
                                    793 ;	quantum/quantum.c:134: }
      00A350 22               [24]  794 	ret
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'do_code16'
                                    797 ;------------------------------------------------------------
                                    798 ;f             Allocated with name '_do_code16_PARM_2'
                                    799 ;code          Allocated with name '_do_code16_code_10000_603'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/quantum.c:136: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function register_code16
                                    804 ;	-----------------------------------------
      00A351                        805 _register_code16:
      00A351 12 3A FE         [24]  806 	lcall	_ak820_outline_0110
      00A354 90 0C 21         [24]  807 	mov	dptr,#_register_code16_code_10000_606
      00A357 12 3B 03         [24]  808 	lcall	_ak820_outline_0111
                                    809 ;	quantum/quantum.c:142: uint8_t mods = extract_mod_bits(code);
      00A35A 90 0C 21         [24]  810 	mov	dptr,#_register_code16_code_10000_606
      00A35D 12 3A 70         [24]  811 	lcall	_ak820_outline_0005
      00A360 C0 07            [24]  812 	push	ar7
      00A362 C0 06            [24]  813 	push	ar6
      00A364 12 A3 26         [24]  814 	lcall	_extract_mod_bits
      00A367 AD 82            [24]  815 	mov	r5, dpl
      00A369 D0 06            [24]  816 	pop	ar6
      00A36B D0 07            [24]  817 	pop	ar7
                                    818 ;	quantum/quantum.c:143: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A36D 12 A1 60         [24]  819 	lcall	_ak820_outline_0121
      00A370 40 07            [24]  820 	jc	00105$
      00A372 74 E7            [12]  821 	mov	a,#0xe7
      00A374 9E               [12]  822 	subb	a,r6
      00A375 E4               [12]  823 	clr	a
      00A376 9F               [12]  824 	subb	a,r7
      00A377 50 08            [24]  825 	jnc	00101$
                                    826 ;	free result
      00A379                        827 00105$:
      00A379 90 0C 21         [24]  828 	mov	dptr,#_register_code16_code_10000_606
      00A37C 12 72 A8         [24]  829 	lcall	_ak820_outline_0040
      00A37F 70 07            [24]  830 	jnz	00102$
      00A381                        831 00101$:
                                    832 ;	quantum/quantum.c:144: register_mods(mods);
      00A381 8D 82            [24]  833 	mov	dpl, r5
      00A383 12 7B E5         [24]  834 	lcall	_register_mods
      00A386 80 05            [24]  835 	sjmp	00103$
      00A388                        836 00102$:
                                    837 ;	quantum/quantum.c:146: register_weak_mods(mods);
      00A388 8D 82            [24]  838 	mov	dpl, r5
      00A38A 12 7C 0D         [24]  839 	lcall	_register_weak_mods
      00A38D                        840 00103$:
                                    841 ;	quantum/quantum.c:148: register_code(code);
      00A38D 90 0C 21         [24]  842 	mov	dptr,#_register_code16_code_10000_606
      00A390 E0               [24]  843 	movx	a,@dptr
      00A391 F5 82            [12]  844 	mov	dpl,a
                                    845 ;	quantum/quantum.c:158: }
      00A393 02 7A 95         [24]  846 	ljmp	_register_code
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'unregister_code16'
                                    849 ;------------------------------------------------------------
                                    850 ;code          Allocated with name '_unregister_code16_code_10000_611'
                                    851 ;mods          Allocated with name '_unregister_code16_mods_10000_612'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/quantum.c:160: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function unregister_code16
                                    856 ;	-----------------------------------------
      00A396                        857 _unregister_code16:
      00A396 12 3A FE         [24]  858 	lcall	_ak820_outline_0110
      00A399 90 0C 23         [24]  859 	mov	dptr,#_unregister_code16_code_10000_611
      00A39C 12 3B 03         [24]  860 	lcall	_ak820_outline_0111
                                    861 ;	quantum/quantum.c:162: uint8_t mods = extract_mod_bits(code);
      00A39F 90 0C 23         [24]  862 	mov	dptr,#_unregister_code16_code_10000_611
      00A3A2 12 3A 70         [24]  863 	lcall	_ak820_outline_0005
      00A3A5 C0 07            [24]  864 	push	ar7
      00A3A7 C0 06            [24]  865 	push	ar6
      00A3A9 12 A3 26         [24]  866 	lcall	_extract_mod_bits
      00A3AC AD 82            [24]  867 	mov	r5, dpl
      00A3AE D0 06            [24]  868 	pop	ar6
                                    869 ;	quantum/quantum.c:163: unregister_code(code);
      00A3B0 8E 04            [24]  870 	mov	ar4,r6
      00A3B2 8C 82            [24]  871 	mov	dpl, r4
      00A3B4 C0 06            [24]  872 	push	ar6
      00A3B6 C0 05            [24]  873 	push	ar5
      00A3B8 12 7B 1A         [24]  874 	lcall	_unregister_code
      00A3BB D0 05            [24]  875 	pop	ar5
      00A3BD D0 06            [24]  876 	pop	ar6
      00A3BF D0 07            [24]  877 	pop	ar7
                                    878 ;	quantum/quantum.c:164: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A3C1 12 A1 60         [24]  879 	lcall	_ak820_outline_0121
      00A3C4 40 07            [24]  880 	jc	00105$
      00A3C6 74 E7            [12]  881 	mov	a,#0xe7
      00A3C8 9E               [12]  882 	subb	a,r6
      00A3C9 E4               [12]  883 	clr	a
      00A3CA 9F               [12]  884 	subb	a,r7
      00A3CB 50 08            [24]  885 	jnc	00101$
                                    886 ;	free result
      00A3CD                        887 00105$:
      00A3CD 90 0C 23         [24]  888 	mov	dptr,#_unregister_code16_code_10000_611
      00A3D0 12 72 A8         [24]  889 	lcall	_ak820_outline_0040
      00A3D3 70 05            [24]  890 	jnz	00102$
      00A3D5                        891 00101$:
                                    892 ;	quantum/quantum.c:165: unregister_mods(mods);
      00A3D5 8D 82            [24]  893 	mov	dpl, r5
      00A3D7 02 7B F9         [24]  894 	ljmp	_unregister_mods
      00A3DA                        895 00102$:
                                    896 ;	quantum/quantum.c:167: unregister_weak_mods(mods);
      00A3DA 8D 82            [24]  897 	mov	dpl, r5
                                    898 ;	quantum/quantum.c:178: }
      00A3DC 02 7C 21         [24]  899 	ljmp	_unregister_weak_mods
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'tap_code16_delay'
                                    902 ;------------------------------------------------------------
                                    903 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    904 ;code          Allocated with name '_tap_code16_delay_code_10000_616'
                                    905 ;i             Allocated with name '_tap_code16_delay_i_20000_618'
                                    906 ;i             Allocated with name '_tap_code16_delay_i_50000_621'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/quantum.c:185: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function pre_process_record_kb
                                    911 ;	-----------------------------------------
      00A3DF                        912 _pre_process_record_kb:
      00A3DF 12 3A FE         [24]  913 	lcall	_ak820_outline_0110
      00A3E2 90 0C 28         [24]  914 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A3E5 12 3B 03         [24]  915 	lcall	_ak820_outline_0111
                                    916 ;	quantum/quantum.c:202: return pre_process_record_user(keycode, record);
      00A3E8 90 0C 28         [24]  917 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A3EB 12 3A BD         [24]  918 	lcall	_ak820_outline_0052
      00A3EE 90 0C 25         [24]  919 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A3F1 12 A1 57         [24]  920 	lcall	_ak820_outline_0026
      00A3F4 90 0C 2A         [24]  921 	mov	dptr,#_pre_process_record_user_PARM_2
      00A3F7 12 A7 3D         [24]  922 	lcall	_ak820_outline_0010
                                    923 ;	quantum/quantum.c:203: }
      00A3FA 02 A3 FD         [24]  924 	ljmp	_pre_process_record_user
                                    925 ;------------------------------------------------------------
                                    926 ;Allocation info for local variables in function 'pre_process_record_user'
                                    927 ;------------------------------------------------------------
                                    928 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    929 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_627'
                                    930 ;------------------------------------------------------------
                                    931 ;	quantum/quantum.c:205: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    932 ;	-----------------------------------------
                                    933 ;	 function pre_process_record_user
                                    934 ;	-----------------------------------------
      00A3FD                        935 _pre_process_record_user:
                                    936 ;	quantum/quantum.c:206: return true;
      00A3FD 75 82 01         [24]  937 	mov	dpl, #0x01
                                    938 ;	quantum/quantum.c:207: }
      00A400 22               [24]  939 	ret
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'process_action_kb'
                                    942 ;------------------------------------------------------------
                                    943 ;record        Allocated with name '_process_action_kb_record_10000_629'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:209: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_action_kb
                                    948 ;	-----------------------------------------
      00A401                        949 _process_action_kb:
                                    950 ;	quantum/quantum.c:210: return true;
      00A401 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:211: }
      00A404 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_process_record_kb_keycode_10000_631'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:213: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function process_record_kb
                                    963 ;	-----------------------------------------
      00A405                        964 _process_record_kb:
      00A405 12 3A FE         [24]  965 	lcall	_ak820_outline_0110
      00A408 90 0C 30         [24]  966 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A40B 12 3B 03         [24]  967 	lcall	_ak820_outline_0111
                                    968 ;	quantum/quantum.c:214: return process_record_user(keycode, record);
      00A40E 90 0C 30         [24]  969 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A411 12 3A BD         [24]  970 	lcall	_ak820_outline_0052
      00A414 90 0C 2D         [24]  971 	mov	dptr,#_process_record_kb_PARM_2
      00A417 12 A1 57         [24]  972 	lcall	_ak820_outline_0026
      00A41A 90 0C 32         [24]  973 	mov	dptr,#_process_record_user_PARM_2
      00A41D 12 A7 3D         [24]  974 	lcall	_ak820_outline_0010
                                    975 ;	quantum/quantum.c:215: }
      00A420 02 A4 23         [24]  976 	ljmp	_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_process_record_user_keycode_10000_633'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:217: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function process_record_user
                                    986 ;	-----------------------------------------
      00A423                        987 _process_record_user:
                                    988 ;	quantum/quantum.c:218: return true;
      00A423 75 82 01         [24]  989 	mov	dpl, #0x01
                                    990 ;	quantum/quantum.c:219: }
      00A426 22               [24]  991 	ret
                                    992 ;------------------------------------------------------------
                                    993 ;Allocation info for local variables in function 'post_process_record_kb'
                                    994 ;------------------------------------------------------------
                                    995 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    996 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_635'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/quantum.c:221: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    999 ;	-----------------------------------------
                                   1000 ;	 function post_process_record_kb
                                   1001 ;	-----------------------------------------
      00A427                       1002 _post_process_record_kb:
      00A427 12 3A FE         [24] 1003 	lcall	_ak820_outline_0110
      00A42A 90 0C 38         [24] 1004 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A42D 12 3B 03         [24] 1005 	lcall	_ak820_outline_0111
                                   1006 ;	quantum/quantum.c:222: post_process_record_user(keycode, record);
      00A430 90 0C 38         [24] 1007 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A433 12 3A BD         [24] 1008 	lcall	_ak820_outline_0052
      00A436 90 0C 35         [24] 1009 	mov	dptr,#_post_process_record_kb_PARM_2
      00A439 12 A1 57         [24] 1010 	lcall	_ak820_outline_0026
      00A43C 90 0C 3A         [24] 1011 	mov	dptr,#_post_process_record_user_PARM_2
      00A43F 12 A7 3D         [24] 1012 	lcall	_ak820_outline_0010
                                   1013 ;	quantum/quantum.c:223: }
      00A442 02 A4 45         [24] 1014 	ljmp	_post_process_record_user
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'post_process_record_user'
                                   1017 ;------------------------------------------------------------
                                   1018 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                   1019 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_637'
                                   1020 ;------------------------------------------------------------
                                   1021 ;	quantum/quantum.c:225: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                   1022 ;	-----------------------------------------
                                   1023 ;	 function post_process_record_user
                                   1024 ;	-----------------------------------------
      00A445                       1025 _post_process_record_user:
      00A445 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'shutdown_quantum'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_shutdown_quantum_i_30000_643'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/quantum.c:227: void shutdown_quantum(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function shutdown_quantum
                                   1035 ;	-----------------------------------------
      00A446                       1036 _shutdown_quantum:
                                   1037 ;	quantum/quantum.c:228: clear_keyboard();
      00A446 12 7C 35         [24] 1038 	lcall	_clear_keyboard
                                   1039 ;	quantum/quantum.c:243: shutdown_user();
      00A449 12 A7 2F         [24] 1040 	lcall	_shutdown_user
                                   1041 ;	quantum/quantum.c:244: wait_ms(250);
      00A44C 7F FA            [12] 1042 	mov	r7,#0xfa
      00A44E                       1043 00106$:
      00A44E EF               [12] 1044 	mov	a,r7
      00A44F 60 09            [24] 1045 	jz	00108$
      00A451 90 00 01         [24] 1046 	mov	dptr,#0x0001
      00A454 12 5D E2         [24] 1047 	lcall	_mDelaymS
      00A457 1F               [12] 1048 	dec	r7
      00A458 80 F4            [24] 1049 	sjmp	00106$
      00A45A                       1050 00108$:
                                   1051 ;	quantum/quantum.c:249: }
      00A45A 22               [24] 1052 	ret
                                   1053 ;------------------------------------------------------------
                                   1054 ;Allocation info for local variables in function 'reset_keyboard'
                                   1055 ;------------------------------------------------------------
                                   1056 ;	quantum/quantum.c:251: void reset_keyboard(void) {
                                   1057 ;	-----------------------------------------
                                   1058 ;	 function reset_keyboard
                                   1059 ;	-----------------------------------------
      00A45B                       1060 _reset_keyboard:
                                   1061 ;	quantum/quantum.c:252: shutdown_quantum();
      00A45B 12 A4 46         [24] 1062 	lcall	_shutdown_quantum
                                   1063 ;	quantum/quantum.c:253: bootloader_jump();
                                   1064 ;	quantum/quantum.c:254: }
      00A45E 02 36 8A         [24] 1065 	ljmp	_bootloader_jump
                                   1066 ;------------------------------------------------------------
                                   1067 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1068 ;------------------------------------------------------------
                                   1069 ;	quantum/quantum.c:256: void soft_reset_keyboard(void) {
                                   1070 ;	-----------------------------------------
                                   1071 ;	 function soft_reset_keyboard
                                   1072 ;	-----------------------------------------
      00A461                       1073 _soft_reset_keyboard:
                                   1074 ;	quantum/quantum.c:257: shutdown_quantum();
      00A461 12 A4 46         [24] 1075 	lcall	_shutdown_quantum
                                   1076 ;	quantum/quantum.c:258: mcu_reset();
                                   1077 ;	quantum/quantum.c:259: }
      00A464 02 36 7D         [24] 1078 	ljmp	_mcu_reset
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'get_record_keycode'
                                   1081 ;------------------------------------------------------------
                                   1082 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1083 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_649'
                                   1084 ;record        Allocated with name '_get_record_keycode_record_10000_650'
                                   1085 ;------------------------------------------------------------
                                   1086 ;	quantum/quantum.c:262: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1087 ;	-----------------------------------------
                                   1088 ;	 function get_record_keycode
                                   1089 ;	-----------------------------------------
      00A467                       1090 _get_record_keycode:
      00A467 12 45 8F         [24] 1091 	lcall	_ak820_outline_0036
      00A46A 90 0C 3E         [24] 1092 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A46D 12 3A 9B         [24] 1093 	lcall	_ak820_outline_0016
                                   1094 ;	quantum/quantum.c:264: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A470 90 0C 3E         [24] 1095 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A473 12 3A 7A         [24] 1096 	lcall	_ak820_outline_0007
                                   1097 ;	quantum/quantum.c:269: if (record->keycode) {
      00A476 4C               [12] 1098 	orl	a,r4
      00A477 60 04            [24] 1099 	jz	00102$
                                   1100 ;	quantum/quantum.c:270: return record->keycode;
      00A479 12 3B 13         [24] 1101 	lcall	_ak820_outline_0126
      00A47C 22               [24] 1102 	ret
      00A47D                       1103 00102$:
                                   1104 ;	quantum/quantum.c:274: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A47D 12 7C A2         [24] 1105 	lcall	_ak820_outline_0021
      00A480 7A 00            [12] 1106 	mov	r2,#0x00
      00A482 12 45 E9         [24] 1107 	lcall	_ak820_outline_0147
      00A485 12 3A 8E         [24] 1108 	lcall	_ak820_outline_0009
      00A488 60 06            [24] 1109 	jz	00105$
      00A48A 90 0C 3D         [24] 1110 	mov	dptr,#_get_record_keycode_PARM_2
      00A48D E0               [24] 1111 	movx	a,@dptr
      00A48E 70 04            [24] 1112 	jnz	00106$
      00A490                       1113 00105$:
                                   1114 ;	assignBit
      00A490 C2 26            [12] 1115 	clr	_get_record_keycode_sloc0_1_0
      00A492 80 02            [24] 1116 	sjmp	00107$
      00A494                       1117 00106$:
                                   1118 ;	assignBit
      00A494 D2 26            [12] 1119 	setb	_get_record_keycode_sloc0_1_0
      00A496                       1120 00107$:
      00A496 90 09 A0         [24] 1121 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A499 A2 26            [12] 1122 	mov	c,_get_record_keycode_sloc0_1_0
      00A49B E4               [12] 1123 	clr	a
      00A49C 33               [12] 1124 	rlc	a
      00A49D F0               [24] 1125 	movx	@dptr,a
      00A49E 8D 82            [24] 1126 	mov	dpl, r5
      00A4A0 8C 83            [24] 1127 	mov	dph, r4
                                   1128 ;	quantum/quantum.c:278: }
      00A4A2 02 80 4E         [24] 1129 	ljmp	_ak820_resolve_key
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'get_event_keycode'
                                   1132 ;------------------------------------------------------------
                                   1133 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1134 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_653'
                                   1135 ;------------------------------------------------------------
                                   1136 ;	quantum/quantum.c:286: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1137 ;	-----------------------------------------
                                   1138 ;	 function pre_process_record_quantum
                                   1139 ;	-----------------------------------------
      00A4A5                       1140 _pre_process_record_quantum:
      00A4A5 12 45 8F         [24] 1141 	lcall	_ak820_outline_0036
      00A4A8 90 0C 41         [24] 1142 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A4AB 12 3A 9B         [24] 1143 	lcall	_ak820_outline_0016
                                   1144 ;	quantum/quantum.c:319: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A4AE 90 0C 41         [24] 1145 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A4B1 12 3A BD         [24] 1146 	lcall	_ak820_outline_0052
                                   1147 ;	quantum/quantum.c:323: uint16_t keycode = get_record_keycode(record, true);
      00A4B4 12 74 F7         [24] 1148 	lcall	_ak820_outline_0157
      00A4B7 90 0C 3D         [24] 1149 	mov	dptr,#_get_record_keycode_PARM_2
      00A4BA 74 01            [12] 1150 	mov	a,#0x01
      00A4BC 12 74 DC         [24] 1151 	lcall	_ak820_outline_0103
      00A4BF 8D F0            [24] 1152 	mov	b, r5
      00A4C1 C0 07            [24] 1153 	push	ar7
      00A4C3 C0 06            [24] 1154 	push	ar6
      00A4C5 12 A4 67         [24] 1155 	lcall	_get_record_keycode
      00A4C8 12 45 EF         [24] 1156 	lcall	_ak820_outline_0155
      00A4CB D0 06            [24] 1157 	pop	ar6
      00A4CD D0 07            [24] 1158 	pop	ar7
                                   1159 ;	quantum/quantum.c:325: record->keycode = keycode;
      00A4CF 74 07            [12] 1160 	mov	a,#0x07
      00A4D1 12 3A AD         [24] 1161 	lcall	_ak820_outline_0022
      00A4D4 12 3A DA         [24] 1162 	lcall	_ak820_outline_0072
                                   1163 ;	quantum/quantum.c:327: return pre_process_record_kb(keycode, record) &&
      00A4D7 90 0C 25         [24] 1164 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A4DA 12 A7 30         [24] 1165 	lcall	_ak820_outline_0002
      00A4DD C0 07            [24] 1166 	push	ar7
      00A4DF C0 06            [24] 1167 	push	ar6
      00A4E1 12 A3 DF         [24] 1168 	lcall	_pre_process_record_kb
      00A4E4 E5 82            [12] 1169 	mov	a, dpl
      00A4E6 D0 06            [24] 1170 	pop	ar6
      00A4E8 D0 07            [24] 1171 	pop	ar7
      00A4EA 60 0A            [24] 1172 	jz	00103$
                                   1173 ;	quantum/quantum.c:330: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A4EC 12 3B 08         [24] 1174 	lcall	_ak820_outline_0120
      00A4EF 12 38 B7         [24] 1175 	lcall	_ak820_combo_process
      00A4F2 E5 82            [12] 1176 	mov	a, dpl
      00A4F4 70 04            [24] 1177 	jnz	00104$
                                   1178 ;	quantum/quantum.c:335: true;
      00A4F6                       1179 00103$:
                                   1180 ;	assignBit
      00A4F6 C2 27            [12] 1181 	clr	_pre_process_record_quantum_sloc0_1_0
      00A4F8 80 02            [24] 1182 	sjmp	00105$
      00A4FA                       1183 00104$:
                                   1184 ;	assignBit
      00A4FA D2 27            [12] 1185 	setb	_pre_process_record_quantum_sloc0_1_0
      00A4FC                       1186 00105$:
      00A4FC A2 27            [12] 1187 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A4FE 12 3B 2D         [24] 1188 	lcall	_ak820_outline_0163
                                   1189 ;	quantum/quantum.c:336: }
      00A501 22               [24] 1190 	ret
                                   1191 ;------------------------------------------------------------
                                   1192 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1193 ;------------------------------------------------------------
                                   1194 ;record        Allocated with name '_post_process_record_quantum_record_10000_657'
                                   1195 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_658'
                                   1196 ;------------------------------------------------------------
                                   1197 ;	quantum/quantum.c:339: void post_process_record_quantum(keyrecord_t *record) {
                                   1198 ;	-----------------------------------------
                                   1199 ;	 function post_process_record_quantum
                                   1200 ;	-----------------------------------------
      00A502                       1201 _post_process_record_quantum:
      00A502 12 45 8F         [24] 1202 	lcall	_ak820_outline_0036
      00A505 90 0C 44         [24] 1203 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A508 12 3A 9B         [24] 1204 	lcall	_ak820_outline_0016
                                   1205 ;	quantum/quantum.c:340: uint16_t keycode = get_record_keycode(record, false);
      00A50B 90 0C 44         [24] 1206 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A50E 12 51 90         [24] 1207 	lcall	_ak820_outline_0012
      00A511 90 0C 3D         [24] 1208 	mov	dptr,#_get_record_keycode_PARM_2
      00A514 E4               [12] 1209 	clr	a
      00A515 12 51 99         [24] 1210 	lcall	_ak820_outline_0034
      00A518 12 A4 67         [24] 1211 	lcall	_get_record_keycode
      00A51B 12 45 D8         [24] 1212 	lcall	_ak820_outline_0127
                                   1213 ;	quantum/quantum.c:341: post_process_record_kb(keycode, record);
      00A51E 90 0C 44         [24] 1214 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A521 12 A1 57         [24] 1215 	lcall	_ak820_outline_0026
      00A524 90 0C 35         [24] 1216 	mov	dptr,#_post_process_record_kb_PARM_2
      00A527 12 A7 3D         [24] 1217 	lcall	_ak820_outline_0010
                                   1218 ;	quantum/quantum.c:342: }
      00A52A 02 A4 27         [24] 1219 	ljmp	_post_process_record_kb
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'process_record_quantum'
                                   1222 ;------------------------------------------------------------
                                   1223 ;record        Allocated with name '_process_record_quantum_record_10000_659'
                                   1224 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_660'
                                   1225 ;------------------------------------------------------------
                                   1226 ;	quantum/quantum.c:344: bool process_record_quantum(keyrecord_t *record) {
                                   1227 ;	-----------------------------------------
                                   1228 ;	 function process_record_quantum
                                   1229 ;	-----------------------------------------
      00A52D                       1230 _process_record_quantum:
      00A52D 12 45 8F         [24] 1231 	lcall	_ak820_outline_0036
      00A530 90 0C 47         [24] 1232 	mov	dptr,#_process_record_quantum_record_10000_659
      00A533 12 3A 9B         [24] 1233 	lcall	_ak820_outline_0016
                                   1234 ;	quantum/quantum.c:346: uint16_t keycode = get_record_keycode(record, false);
      00A536 90 0C 47         [24] 1235 	mov	dptr,#_process_record_quantum_record_10000_659
      00A539 12 51 90         [24] 1236 	lcall	_ak820_outline_0012
      00A53C 90 0C 3D         [24] 1237 	mov	dptr,#_get_record_keycode_PARM_2
      00A53F E4               [12] 1238 	clr	a
      00A540 12 51 99         [24] 1239 	lcall	_ak820_outline_0034
      00A543 12 A4 67         [24] 1240 	lcall	_get_record_keycode
      00A546 12 45 D8         [24] 1241 	lcall	_ak820_outline_0127
                                   1242 ;	quantum/quantum.c:350: return process_record_quantum_helper(keycode, record);
      00A549 90 0C 47         [24] 1243 	mov	dptr,#_process_record_quantum_record_10000_659
      00A54C 12 A1 57         [24] 1244 	lcall	_ak820_outline_0026
      00A54F 90 0C 4F         [24] 1245 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A552 12 A7 3D         [24] 1246 	lcall	_ak820_outline_0010
                                   1247 ;	quantum/quantum.c:351: }
      00A555 02 A5 C3         [24] 1248 	ljmp	_process_record_quantum_helper
                                   1249 ;------------------------------------------------------------
                                   1250 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1251 ;------------------------------------------------------------
                                   1252 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1253 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_661'
                                   1254 ;record        Allocated with name '_process_ak820_nkro_record_10000_662'
                                   1255 ;------------------------------------------------------------
                                   1256 ;	quantum/quantum.c:358: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1257 ;	-----------------------------------------
                                   1258 ;	 function process_ak820_nkro
                                   1259 ;	-----------------------------------------
      00A558                       1260 _process_ak820_nkro:
      00A558 12 3A FE         [24] 1261 	lcall	_ak820_outline_0110
      00A55B 90 0C 4D         [24] 1262 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A55E 12 3B 03         [24] 1263 	lcall	_ak820_outline_0111
                                   1264 ;	quantum/quantum.c:360: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A561 90 0C 4A         [24] 1265 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A564 12 3A BD         [24] 1266 	lcall	_ak820_outline_0052
                                   1267 ;	quantum/quantum.c:364: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A567 90 0C 4D         [24] 1268 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A56A 12 3A D4         [24] 1269 	lcall	_ak820_outline_0061
      00A56D C3               [12] 1270 	clr	c
      00A56E EC               [12] 1271 	mov	a,r4
      00A56F 94 11            [12] 1272 	subb	a,#0x11
      00A571 ED               [12] 1273 	mov	a,r5
      00A572 94 70            [12] 1274 	subb	a,#0x70
      00A574 40 08            [24] 1275 	jc	00101$
      00A576 74 13            [12] 1276 	mov	a,#0x13
      00A578 9C               [12] 1277 	subb	a,r4
      00A579 74 70            [12] 1278 	mov	a,#0x70
      00A57B 9D               [12] 1279 	subb	a,r5
      00A57C 50 04            [24] 1280 	jnc	00102$
                                   1281 ;	free result
      00A57E                       1282 00101$:
      00A57E 75 82 01         [24] 1283 	mov	dpl, #0x01
      00A581 22               [24] 1284 	ret
      00A582                       1285 00102$:
                                   1286 ;	quantum/quantum.c:365: if (record->event.pressed) {
      00A582 12 3A 8E         [24] 1287 	lcall	_ak820_outline_0009
      00A585 60 38            [24] 1288 	jz	00105$
                                   1289 ;	quantum/quantum.c:366: clear_keyboard();
      00A587 C0 05            [24] 1290 	push	ar5
      00A589 C0 04            [24] 1291 	push	ar4
      00A58B 12 7C 35         [24] 1292 	lcall	_clear_keyboard
      00A58E D0 04            [24] 1293 	pop	ar4
      00A590 D0 05            [24] 1294 	pop	ar5
                                   1295 ;	quantum/quantum.c:367: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A592 BC 13 14         [24] 1296 	cjne	r4,#0x13,00108$
      00A595 BD 70 11         [24] 1297 	cjne	r5,#0x70,00108$
      00A598 90 0A F2         [24] 1298 	mov	dptr,#_keymap_config
      00A59B E0               [24] 1299 	movx	a,@dptr
      00A59C 23               [12] 1300 	rl	a
      00A59D 54 01            [12] 1301 	anl	a,#0x01
      00A59F B4 01 00         [24] 1302 	cjne	a,#0x01,00136$
      00A5A2                       1303 00136$:
      00A5A2 92 28            [24] 1304 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A5A4 E4               [12] 1305 	clr	a
      00A5A5 33               [12] 1306 	rlc	a
      00A5A6 FF               [12] 1307 	mov	r7,a
      00A5A7 80 09            [24] 1308 	sjmp	00109$
      00A5A9                       1309 00108$:
      00A5A9 E4               [12] 1310 	clr	a
      00A5AA BC 11 04         [24] 1311 	cjne	r4,#0x11,00137$
      00A5AD BD 70 01         [24] 1312 	cjne	r5,#0x70,00137$
      00A5B0 04               [12] 1313 	inc	a
      00A5B1                       1314 00137$:
      00A5B1 FF               [12] 1315 	mov	r7,a
      00A5B2                       1316 00109$:
                                   1317 ;	assignBit
      00A5B2 EF               [12] 1318 	mov	a,r7
      00A5B3 24 FF            [12] 1319 	add	a,#0xff
      00A5B5 E4               [12] 1320 	clr	a
      00A5B6 33               [12] 1321 	rlc	a
      00A5B7 90 0A F2         [24] 1322 	mov	dptr,#_keymap_config
      00A5BA 13               [12] 1323 	rrc	a
      00A5BB E0               [24] 1324 	movx	a,@dptr
      00A5BC 92 E7            [24] 1325 	mov	acc.7,c
      00A5BE F0               [24] 1326 	movx	@dptr,a
      00A5BF                       1327 00105$:
                                   1328 ;	quantum/quantum.c:369: return false;
      00A5BF 75 82 00         [24] 1329 	mov	dpl, #0x00
                                   1330 ;	quantum/quantum.c:370: }
      00A5C2 22               [24] 1331 	ret
                                   1332 ;------------------------------------------------------------
                                   1333 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1334 ;------------------------------------------------------------
                                   1335 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1336 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_666'
                                   1337 ;record        Allocated with name '_process_record_quantum_helper_record_10000_667'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/quantum.c:373: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function process_record_quantum_helper
                                   1342 ;	-----------------------------------------
      00A5C3                       1343 _process_record_quantum_helper:
      00A5C3 12 3A FE         [24] 1344 	lcall	_ak820_outline_0110
      00A5C6 90 0C 52         [24] 1345 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A5C9 12 3B 03         [24] 1346 	lcall	_ak820_outline_0111
                                   1347 ;	quantum/quantum.c:375: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A5CC 90 0C 4F         [24] 1348 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A5CF 12 3A BD         [24] 1349 	lcall	_ak820_outline_0052
                                   1350 ;	quantum/quantum.c:415: process_ak820_nkro(keycode, record) &&
      00A5D2 90 0C 52         [24] 1351 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A5D5 12 3A D4         [24] 1352 	lcall	_ak820_outline_0061
      00A5D8 90 0C 4A         [24] 1353 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A5DB 12 A7 30         [24] 1354 	lcall	_ak820_outline_0002
      00A5DE C0 07            [24] 1355 	push	ar7
      00A5E0 C0 06            [24] 1356 	push	ar6
      00A5E2 C0 05            [24] 1357 	push	ar5
      00A5E4 C0 04            [24] 1358 	push	ar4
      00A5E6 12 A5 58         [24] 1359 	lcall	_process_ak820_nkro
      00A5E9 E5 82            [12] 1360 	mov	a, dpl
      00A5EB D0 04            [24] 1361 	pop	ar4
      00A5ED D0 05            [24] 1362 	pop	ar5
      00A5EF D0 06            [24] 1363 	pop	ar6
      00A5F1 D0 07            [24] 1364 	pop	ar7
      00A5F3 70 03            [24] 1365 	jnz	00204$
      00A5F5 02 A6 EC         [24] 1366 	ljmp	00101$
      00A5F8                       1367 00204$:
                                   1368 ;	quantum/quantum.c:426: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A5F8 90 0C 08         [24] 1369 	mov	dptr,#_process_last_key_PARM_2
      00A5FB 12 A7 30         [24] 1370 	lcall	_ak820_outline_0002
      00A5FE C0 07            [24] 1371 	push	ar7
      00A600 C0 06            [24] 1372 	push	ar6
      00A602 C0 05            [24] 1373 	push	ar5
      00A604 C0 04            [24] 1374 	push	ar4
      00A606 12 A0 90         [24] 1375 	lcall	_process_last_key
      00A609 E5 82            [12] 1376 	mov	a, dpl
      00A60B D0 04            [24] 1377 	pop	ar4
      00A60D D0 05            [24] 1378 	pop	ar5
      00A60F D0 06            [24] 1379 	pop	ar6
      00A611 D0 07            [24] 1380 	pop	ar7
      00A613 70 03            [24] 1381 	jnz	00205$
      00A615 02 A6 EC         [24] 1382 	ljmp	00101$
      00A618                       1383 00205$:
      00A618 90 0C 0E         [24] 1384 	mov	dptr,#_process_repeat_key_PARM_2
      00A61B 12 A7 30         [24] 1385 	lcall	_ak820_outline_0002
      00A61E C0 07            [24] 1386 	push	ar7
      00A620 C0 06            [24] 1387 	push	ar6
      00A622 C0 05            [24] 1388 	push	ar5
      00A624 C0 04            [24] 1389 	push	ar4
      00A626 12 A1 0E         [24] 1390 	lcall	_process_repeat_key
      00A629 E5 82            [12] 1391 	mov	a, dpl
      00A62B D0 04            [24] 1392 	pop	ar4
      00A62D D0 05            [24] 1393 	pop	ar5
      00A62F D0 06            [24] 1394 	pop	ar6
      00A631 D0 07            [24] 1395 	pop	ar7
      00A633 70 03            [24] 1396 	jnz	00206$
      00A635 02 A6 EC         [24] 1397 	ljmp	00101$
      00A638                       1398 00206$:
                                   1399 ;	quantum/quantum.c:435: process_record_via(keycode, record) &&
      00A638 90 0C 9B         [24] 1400 	mov	dptr,#_process_record_via_PARM_2
      00A63B 12 A7 30         [24] 1401 	lcall	_ak820_outline_0002
      00A63E C0 07            [24] 1402 	push	ar7
      00A640 C0 06            [24] 1403 	push	ar6
      00A642 C0 05            [24] 1404 	push	ar5
      00A644 C0 04            [24] 1405 	push	ar4
      00A646 12 AC 41         [24] 1406 	lcall	_process_record_via
      00A649 E5 82            [12] 1407 	mov	a, dpl
      00A64B D0 04            [24] 1408 	pop	ar4
      00A64D D0 05            [24] 1409 	pop	ar5
      00A64F D0 06            [24] 1410 	pop	ar6
      00A651 D0 07            [24] 1411 	pop	ar7
      00A653 70 03            [24] 1412 	jnz	00207$
      00A655 02 A6 EC         [24] 1413 	ljmp	00101$
      00A658                       1414 00207$:
                                   1415 ;	quantum/quantum.c:445: process_record_kb(keycode, record) &&
      00A658 90 0C 2D         [24] 1416 	mov	dptr,#_process_record_kb_PARM_2
      00A65B 12 A7 30         [24] 1417 	lcall	_ak820_outline_0002
      00A65E C0 07            [24] 1418 	push	ar7
      00A660 C0 06            [24] 1419 	push	ar6
      00A662 C0 05            [24] 1420 	push	ar5
      00A664 C0 04            [24] 1421 	push	ar4
      00A666 12 A4 05         [24] 1422 	lcall	_process_record_kb
      00A669 E5 82            [12] 1423 	mov	a, dpl
      00A66B D0 04            [24] 1424 	pop	ar4
      00A66D D0 05            [24] 1425 	pop	ar5
      00A66F D0 06            [24] 1426 	pop	ar6
      00A671 D0 07            [24] 1427 	pop	ar7
      00A673 70 03            [24] 1428 	jnz	00208$
      00A675 02 A6 EC         [24] 1429 	ljmp	00101$
      00A678                       1430 00208$:
                                   1431 ;	quantum/quantum.c:468: process_caps_word(keycode, record) &&
      00A678 90 0B F0         [24] 1432 	mov	dptr,#_process_caps_word_PARM_2
      00A67B 12 A7 30         [24] 1433 	lcall	_ak820_outline_0002
      00A67E C0 07            [24] 1434 	push	ar7
      00A680 C0 06            [24] 1435 	push	ar6
      00A682 C0 05            [24] 1436 	push	ar5
      00A684 C0 04            [24] 1437 	push	ar4
      00A686 12 9E 18         [24] 1438 	lcall	_process_caps_word
      00A689 E5 82            [12] 1439 	mov	a, dpl
      00A68B D0 04            [24] 1440 	pop	ar4
      00A68D D0 05            [24] 1441 	pop	ar5
      00A68F D0 06            [24] 1442 	pop	ar6
      00A691 D0 07            [24] 1443 	pop	ar7
      00A693 60 57            [24] 1444 	jz	00101$
                                   1445 ;	quantum/quantum.c:495: process_grave_esc(keycode, record) &&
      00A695 90 0B F5         [24] 1446 	mov	dptr,#_process_grave_esc_PARM_2
      00A698 12 A7 30         [24] 1447 	lcall	_ak820_outline_0002
      00A69B C0 07            [24] 1448 	push	ar7
      00A69D C0 06            [24] 1449 	push	ar6
      00A69F C0 05            [24] 1450 	push	ar5
      00A6A1 C0 04            [24] 1451 	push	ar4
      00A6A3 12 9F 2B         [24] 1452 	lcall	_process_grave_esc
      00A6A6 E5 82            [12] 1453 	mov	a, dpl
      00A6A8 D0 04            [24] 1454 	pop	ar4
      00A6AA D0 05            [24] 1455 	pop	ar5
      00A6AC D0 06            [24] 1456 	pop	ar6
      00A6AE D0 07            [24] 1457 	pop	ar7
      00A6B0 60 3A            [24] 1458 	jz	00101$
                                   1459 ;	quantum/quantum.c:498: process_rgb(keycode, record) &&
      00A6B2 90 0C 13         [24] 1460 	mov	dptr,#_process_rgb_PARM_2
      00A6B5 12 A7 30         [24] 1461 	lcall	_ak820_outline_0002
      00A6B8 C0 07            [24] 1462 	push	ar7
      00A6BA C0 06            [24] 1463 	push	ar6
      00A6BC C0 05            [24] 1464 	push	ar5
      00A6BE C0 04            [24] 1465 	push	ar4
      00A6C0 12 A1 68         [24] 1466 	lcall	_process_rgb
      00A6C3 E5 82            [12] 1467 	mov	a, dpl
      00A6C5 D0 04            [24] 1468 	pop	ar4
      00A6C7 D0 05            [24] 1469 	pop	ar5
      00A6C9 D0 06            [24] 1470 	pop	ar6
      00A6CB D0 07            [24] 1471 	pop	ar7
      00A6CD 60 1D            [24] 1472 	jz	00101$
                                   1473 ;	quantum/quantum.c:510: process_tri_layer(keycode, record) &&
      00A6CF 90 0C 19         [24] 1474 	mov	dptr,#_process_tri_layer_PARM_2
      00A6D2 12 A7 30         [24] 1475 	lcall	_ak820_outline_0002
      00A6D5 C0 07            [24] 1476 	push	ar7
      00A6D7 C0 06            [24] 1477 	push	ar6
      00A6D9 C0 05            [24] 1478 	push	ar5
      00A6DB C0 04            [24] 1479 	push	ar4
      00A6DD 12 A2 19         [24] 1480 	lcall	_process_tri_layer
      00A6E0 E5 82            [12] 1481 	mov	a, dpl
      00A6E2 D0 04            [24] 1482 	pop	ar4
      00A6E4 D0 05            [24] 1483 	pop	ar5
      00A6E6 D0 06            [24] 1484 	pop	ar6
      00A6E8 D0 07            [24] 1485 	pop	ar7
      00A6EA 70 04            [24] 1486 	jnz	00102$
                                   1487 ;	quantum/quantum.c:512: true)) {
      00A6EC                       1488 00101$:
                                   1489 ;	quantum/quantum.c:513: return false;
      00A6EC 75 82 00         [24] 1490 	mov	dpl, #0x00
      00A6EF 22               [24] 1491 	ret
      00A6F0                       1492 00102$:
                                   1493 ;	quantum/quantum.c:516: if (record->event.pressed) {
      00A6F0 74 05            [12] 1494 	mov	a,#0x05
      00A6F2 12 4A E1         [24] 1495 	lcall	_ak820_outline_0032
      00A6F5 60 30            [24] 1496 	jz	00117$
                                   1497 ;	quantum/quantum.c:517: switch (keycode) {
      00A6F7 BC 00 05         [24] 1498 	cjne	r4,#0x00,00214$
      00A6FA BD 7C 02         [24] 1499 	cjne	r5,#0x7c,00214$
      00A6FD 80 10            [24] 1500 	sjmp	00112$
      00A6FF                       1501 00214$:
      00A6FF BC 01 05         [24] 1502 	cjne	r4,#0x01,00215$
      00A702 BD 7C 02         [24] 1503 	cjne	r5,#0x7c,00215$
      00A705 80 0F            [24] 1504 	sjmp	00113$
      00A707                       1505 00215$:
                                   1506 ;	quantum/quantum.c:519: case QK_BOOTLOADER:
      00A707 BC 03 1D         [24] 1507 	cjne	r4,#0x03,00117$
      00A70A BD 7C 1A         [24] 1508 	cjne	r5,#0x7c,00117$
      00A70D 80 0E            [24] 1509 	sjmp	00114$
      00A70F                       1510 00112$:
                                   1511 ;	quantum/quantum.c:520: reset_keyboard();
      00A70F 12 A4 5B         [24] 1512 	lcall	_reset_keyboard
                                   1513 ;	quantum/quantum.c:521: return false;
      00A712 75 82 00         [24] 1514 	mov	dpl, #0x00
                                   1515 ;	quantum/quantum.c:522: case QK_REBOOT:
      00A715 22               [24] 1516 	ret
      00A716                       1517 00113$:
                                   1518 ;	quantum/quantum.c:523: soft_reset_keyboard();
      00A716 12 A4 61         [24] 1519 	lcall	_soft_reset_keyboard
                                   1520 ;	quantum/quantum.c:524: return false;
      00A719 75 82 00         [24] 1521 	mov	dpl, #0x00
                                   1522 ;	quantum/quantum.c:536: case QK_CLEAR_EEPROM:
      00A71C 22               [24] 1523 	ret
      00A71D                       1524 00114$:
                                   1525 ;	quantum/quantum.c:543: eeconfig_disable();
      00A71D 12 95 10         [24] 1526 	lcall	_eeconfig_disable
                                   1527 ;	quantum/quantum.c:544: soft_reset_keyboard();
      00A720 12 A4 61         [24] 1528 	lcall	_soft_reset_keyboard
                                   1529 ;	quantum/quantum.c:546: return false;
      00A723 75 82 00         [24] 1530 	mov	dpl, #0x00
                                   1531 ;	quantum/quantum.c:601: }
      00A726 22               [24] 1532 	ret
      00A727                       1533 00117$:
                                   1534 ;	quantum/quantum.c:604: return process_action_kb(record);
      00A727 7D 00            [12] 1535 	mov	r5,#0x00
      00A729 12 74 D5         [24] 1536 	lcall	_ak820_outline_0050
                                   1537 ;	quantum/quantum.c:605: }
      00A72C 02 A4 01         [24] 1538 	ljmp	_process_action_kb
                                   1539 ;------------------------------------------------------------
                                   1540 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1541 ;------------------------------------------------------------
                                   1542 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_674'
                                   1543 ;------------------------------------------------------------
                                   1544 ;	quantum/quantum.c:607: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1545 ;	-----------------------------------------
                                   1546 ;	 function shutdown_user
                                   1547 ;	-----------------------------------------
      00A72F                       1548 _shutdown_user:
      00A72F 22               [24] 1549 	ret
                                   1550 ;------------------------------------------------------------
                                   1551 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1552 ;------------------------------------------------------------
                                   1553 ;	quantum/quantum.c:623: void suspend_power_down_quantum(void) {
                                   1554 ;	-----------------------------------------
                                   1555 	.area CSEG    (CODE)
                                   1556 	.area CONST   (CODE)
                                   1557 	.area XINIT   (CODE)
                                   1558 	.area CABS    (ABS,CODE)
                                   1559 
                                   1560 ; Experimental exact instruction outlining.
                                   1561 	.globl _ak820_outline_0002
                                   1562 	.globl _ak820_outline_0005
                                   1563 	.globl _ak820_outline_0007
                                   1564 	.globl _ak820_outline_0009
                                   1565 	.globl _ak820_outline_0010
                                   1566 	.globl _ak820_outline_0012
                                   1567 	.globl _ak820_outline_0016
                                   1568 	.globl _ak820_outline_0021
                                   1569 	.globl _ak820_outline_0022
                                   1570 	.globl _ak820_outline_0026
                                   1571 	.globl _ak820_outline_0032
                                   1572 	.globl _ak820_outline_0034
                                   1573 	.globl _ak820_outline_0036
                                   1574 	.globl _ak820_outline_0040
                                   1575 	.globl _ak820_outline_0050
                                   1576 	.globl _ak820_outline_0052
                                   1577 	.globl _ak820_outline_0061
                                   1578 	.globl _ak820_outline_0072
                                   1579 	.globl _ak820_outline_0103
                                   1580 	.globl _ak820_outline_0110
                                   1581 	.globl _ak820_outline_0111
                                   1582 	.globl _ak820_outline_0120
                                   1583 	.globl _ak820_outline_0121
                                   1584 	.globl _ak820_outline_0126
                                   1585 	.globl _ak820_outline_0127
                                   1586 	.globl _ak820_outline_0147
                                   1587 	.globl _ak820_outline_0155
                                   1588 	.globl _ak820_outline_0157
                                   1589 	.globl _ak820_outline_0163
                                   1590 
                                   1591 	.area CSEG (CODE)
                                   1592 ; function ak820_outline_0002
      00A730                       1593 _ak820_outline_0002:
      00A730 EE               [12] 1594 	mov	a,r6
      00A731 F0               [24] 1595 	movx	@dptr,a
      00A732 EF               [12] 1596 	mov	a,r7
      00A733 A3               [24] 1597 	inc	dptr
      00A734 F0               [24] 1598 	movx	@dptr,a
      00A735 E4               [12] 1599 	clr	a
      00A736 A3               [24] 1600 	inc	dptr
      00A737 F0               [24] 1601 	movx	@dptr,a
      00A738 8C 82            [24] 1602 	mov	dpl,r4
      00A73A 8D 83            [24] 1603 	mov	dph,r5
      00A73C 22               [24] 1604 	ret
                                   1605 
                                   1606 	.area CSEG (CODE)
                                   1607 ; function ak820_outline_0010
      00A73D                       1608 _ak820_outline_0010:
      00A73D EB               [12] 1609 	mov	a,r3
      00A73E F0               [24] 1610 	movx	@dptr,a
      00A73F EC               [12] 1611 	mov	a,r4
      00A740 A3               [24] 1612 	inc	dptr
      00A741 F0               [24] 1613 	movx	@dptr,a
      00A742 ED               [12] 1614 	mov	a,r5
      00A743 A3               [24] 1615 	inc	dptr
      00A744 F0               [24] 1616 	movx	@dptr,a
      00A745 8E 82            [24] 1617 	mov	dpl,r6
      00A747 8F 83            [24] 1618 	mov	dph,r7
      00A749 22               [24] 1619 	ret
