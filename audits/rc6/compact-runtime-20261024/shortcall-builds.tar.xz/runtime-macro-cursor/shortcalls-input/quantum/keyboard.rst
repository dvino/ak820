                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _mousekey_task
                                     28 	.globl _ak820_action_exec
                                     29 	.globl _print_set_sendchar
                                     30 	.globl _sendchar
                                     31 	.globl _led_task
                                     32 	.globl _led_init_ports
                                     33 	.globl _magic
                                     34 	.globl _matrix_print
                                     35 	.globl _matrix_get_row
                                     36 	.globl _matrix_scan
                                     37 	.globl _matrix_init
                                     38 	.globl _keyboard_post_init_user
                                     39 	.globl _timer_elapsed32
                                     40 	.globl _timer_read32
                                     41 	.globl _timer_read
                                     42 	.globl _timer_init
                                     43 	.globl _ADC_START
                                     44 	.globl _S0_R_FIFO
                                     45 	.globl _S0_T_FIFO
                                     46 	.globl _S0_FREE
                                     47 	.globl _S0_IF_BYTE
                                     48 	.globl _S0_IF_FIRST
                                     49 	.globl _S0_IF_OV
                                     50 	.globl _S0_FST_ACT
                                     51 	.globl _CP_RL2
                                     52 	.globl _C_T2
                                     53 	.globl _TR2
                                     54 	.globl _EXEN2
                                     55 	.globl _TCLK
                                     56 	.globl _RCLK
                                     57 	.globl _EXF2
                                     58 	.globl _CAP1F
                                     59 	.globl _TF2
                                     60 	.globl _RI
                                     61 	.globl _TI
                                     62 	.globl _RB8
                                     63 	.globl _TB8
                                     64 	.globl _REN
                                     65 	.globl _SM2
                                     66 	.globl _SM1
                                     67 	.globl _SM0
                                     68 	.globl _IT0
                                     69 	.globl _IE0
                                     70 	.globl _IT1
                                     71 	.globl _IE1
                                     72 	.globl _TR0
                                     73 	.globl _TF0
                                     74 	.globl _TR1
                                     75 	.globl _TF1
                                     76 	.globl _P4_0
                                     77 	.globl _P4_1
                                     78 	.globl _P4_2
                                     79 	.globl _P4_3
                                     80 	.globl _P4_4
                                     81 	.globl _P4_5
                                     82 	.globl _P4_6
                                     83 	.globl _RXD
                                     84 	.globl _TXD
                                     85 	.globl _INT0
                                     86 	.globl _INT1
                                     87 	.globl _T0
                                     88 	.globl _T1
                                     89 	.globl _MOSI1
                                     90 	.globl _MISO1
                                     91 	.globl _SCK1
                                     92 	.globl _P3_0
                                     93 	.globl _P3_1
                                     94 	.globl _P3_2
                                     95 	.globl _P3_3
                                     96 	.globl _P3_4
                                     97 	.globl _P3_5
                                     98 	.globl _P3_6
                                     99 	.globl _P3_7
                                    100 	.globl _CAP1_
                                    101 	.globl _T2_
                                    102 	.globl _CAP2_
                                    103 	.globl _T2EX_
                                    104 	.globl _RXD1
                                    105 	.globl _TXD1
                                    106 	.globl _P2_0
                                    107 	.globl _P2_1
                                    108 	.globl _P2_2
                                    109 	.globl _P2_3
                                    110 	.globl _P2_4
                                    111 	.globl _P2_5
                                    112 	.globl _P2_6
                                    113 	.globl _P2_7
                                    114 	.globl _AIN0
                                    115 	.globl _AIN1
                                    116 	.globl _AIN2
                                    117 	.globl _AIN3
                                    118 	.globl _AIN4
                                    119 	.globl _AIN5
                                    120 	.globl _AIN6
                                    121 	.globl _AIN7
                                    122 	.globl _CAP1
                                    123 	.globl _T2
                                    124 	.globl _CAP2
                                    125 	.globl _T2EX
                                    126 	.globl _INT0_
                                    127 	.globl _SCS
                                    128 	.globl _MOSI
                                    129 	.globl _MISO
                                    130 	.globl _SCK
                                    131 	.globl _RXD1_
                                    132 	.globl _TXD1_
                                    133 	.globl _P1_0
                                    134 	.globl _P1_1
                                    135 	.globl _P1_2
                                    136 	.globl _P1_3
                                    137 	.globl _P1_4
                                    138 	.globl _P1_5
                                    139 	.globl _P1_6
                                    140 	.globl _P1_7
                                    141 	.globl _AIN8
                                    142 	.globl _AIN9
                                    143 	.globl _AIN10
                                    144 	.globl _AIN11
                                    145 	.globl _AIN12
                                    146 	.globl _AIN13
                                    147 	.globl _RXD_
                                    148 	.globl _TXD_
                                    149 	.globl _SCL0
                                    150 	.globl _SDA0
                                    151 	.globl _P0_0
                                    152 	.globl _P0_1
                                    153 	.globl _P0_2
                                    154 	.globl _P0_3
                                    155 	.globl _P0_4
                                    156 	.globl _P0_5
                                    157 	.globl _P0_6
                                    158 	.globl _P0_7
                                    159 	.globl _IE_SPI0
                                    160 	.globl _IE_USB
                                    161 	.globl _IE_ADC
                                    162 	.globl _IE_UART1
                                    163 	.globl _IE_PWM_I2C
                                    164 	.globl _IE_GPIO
                                    165 	.globl _IE_WDOG
                                    166 	.globl _PX0
                                    167 	.globl _PT0
                                    168 	.globl _PX1
                                    169 	.globl _PT1
                                    170 	.globl _PS
                                    171 	.globl _PT2
                                    172 	.globl _PL_FLAG
                                    173 	.globl _PH_FLAG
                                    174 	.globl _EX0
                                    175 	.globl _ET0
                                    176 	.globl _EX1
                                    177 	.globl _ET1
                                    178 	.globl _ES
                                    179 	.globl _ET2
                                    180 	.globl _E_DIS
                                    181 	.globl _EA
                                    182 	.globl _P
                                    183 	.globl _F1
                                    184 	.globl _OV
                                    185 	.globl _RS0
                                    186 	.globl _RS1
                                    187 	.globl _F0
                                    188 	.globl _AC
                                    189 	.globl _CY
                                    190 	.globl _I2CS_INT_ST
                                    191 	.globl _I2CX_INT
                                    192 	.globl _LED_STATUS
                                    193 	.globl _LED_DMA_H
                                    194 	.globl _LED_DMA_L
                                    195 	.globl _LED_DMA
                                    196 	.globl _LED_PWM_OE
                                    197 	.globl _LED_COMMON
                                    198 	.globl _ADC_CHAN
                                    199 	.globl _ADC_DAT_H
                                    200 	.globl _ADC_DAT_L
                                    201 	.globl _ADC_DAT
                                    202 	.globl _ADC_CTRL
                                    203 	.globl _SPI1_CK_SE
                                    204 	.globl _SPI1_CTRL
                                    205 	.globl _SPI1_DATA
                                    206 	.globl _SPI1_STAT
                                    207 	.globl _SIF1
                                    208 	.globl _SBAUD1
                                    209 	.globl _SBUF1
                                    210 	.globl _SCON1
                                    211 	.globl _SPI0_SETUP
                                    212 	.globl _SPI0_CK_SE
                                    213 	.globl _SPI0_CTRL
                                    214 	.globl _SPI0_DATA
                                    215 	.globl _SPI0_STAT
                                    216 	.globl _T2CAP1H
                                    217 	.globl _T2CAP1L
                                    218 	.globl _T2CAP1
                                    219 	.globl _TH2
                                    220 	.globl _TL2
                                    221 	.globl _T2COUNT
                                    222 	.globl _RCAP2H
                                    223 	.globl _RCAP2L
                                    224 	.globl _RCAP2
                                    225 	.globl _T2MOD
                                    226 	.globl _T2CON
                                    227 	.globl _SBUF
                                    228 	.globl _SCON
                                    229 	.globl _TH1
                                    230 	.globl _TH0
                                    231 	.globl _TL1
                                    232 	.globl _TL0
                                    233 	.globl _TMOD
                                    234 	.globl _TCON
                                    235 	.globl _XBUS_AUX
                                    236 	.globl _P7
                                    237 	.globl _P6_DIR
                                    238 	.globl _P6_OUT_PU
                                    239 	.globl _P6_IN
                                    240 	.globl _P5_DIR
                                    241 	.globl _P5_OUT_PU
                                    242 	.globl _P5_IN
                                    243 	.globl _P4_LED_KEY
                                    244 	.globl _P4_DIR_PU
                                    245 	.globl _P4_MOD_OC
                                    246 	.globl _P4
                                    247 	.globl _P3_DIR_PU
                                    248 	.globl _P3_MOD_OC
                                    249 	.globl _P3
                                    250 	.globl _P2_DIR_PU
                                    251 	.globl _P2_MOD_OC
                                    252 	.globl _P2
                                    253 	.globl _P1_DIR_PU
                                    254 	.globl _P1_MOD_OC
                                    255 	.globl _P1
                                    256 	.globl _P0_DIR_PU
                                    257 	.globl _P0_MOD_OC
                                    258 	.globl _P0
                                    259 	.globl _ROM_CTRL
                                    260 	.globl _ROM_DATA_HH
                                    261 	.globl _ROM_DATA_HL
                                    262 	.globl _ROM_DATA_HI
                                    263 	.globl _ROM_ADDR_H
                                    264 	.globl _ROM_ADDR_L
                                    265 	.globl _ROM_ADDR
                                    266 	.globl _GPIO_IE
                                    267 	.globl _IP_EX
                                    268 	.globl _IE_EX
                                    269 	.globl _IP
                                    270 	.globl _IE
                                    271 	.globl _WDOG_COUNT
                                    272 	.globl _RESET_KEEP
                                    273 	.globl _WAKE_CTRL
                                    274 	.globl _CLOCK_CFG
                                    275 	.globl _POWER_CFG
                                    276 	.globl _PCON
                                    277 	.globl _GLOBAL_CFG
                                    278 	.globl _SAFE_MOD
                                    279 	.globl _DPH
                                    280 	.globl _DPL
                                    281 	.globl _SP
                                    282 	.globl _A_INV
                                    283 	.globl _B
                                    284 	.globl _ACC
                                    285 	.globl _PSW
                                    286 	.globl _switch_events_PARM_3
                                    287 	.globl _switch_events_PARM_2
                                    288 	.globl _keyboard_post_init_kb
                                    289 	.globl _matrix_can_read
                                    290 	.globl _keyboard_setup
                                    291 	.globl _is_keyboard_master
                                    292 	.globl _housekeeping_task
                                    293 	.globl _keyboard_init
                                    294 	.globl _keyboard_task
                                    295 ;--------------------------------------------------------
                                    296 ; special function registers
                                    297 ;--------------------------------------------------------
                                    298 	.area RSEG    (ABS,DATA)
      000000                        299 	.org 0x0000
                           0000D0   300 _PSW	=	0x00d0
                           0000E0   301 _ACC	=	0x00e0
                           0000F0   302 _B	=	0x00f0
                           0000FD   303 _A_INV	=	0x00fd
                           000081   304 _SP	=	0x0081
                           000082   305 _DPL	=	0x0082
                           000083   306 _DPH	=	0x0083
                           0000A1   307 _SAFE_MOD	=	0x00a1
                           0000B1   308 _GLOBAL_CFG	=	0x00b1
                           000087   309 _PCON	=	0x0087
                           0000BA   310 _POWER_CFG	=	0x00ba
                           0000B9   311 _CLOCK_CFG	=	0x00b9
                           0000A9   312 _WAKE_CTRL	=	0x00a9
                           0000FE   313 _RESET_KEEP	=	0x00fe
                           0000FF   314 _WDOG_COUNT	=	0x00ff
                           0000A8   315 _IE	=	0x00a8
                           0000B8   316 _IP	=	0x00b8
                           0000E8   317 _IE_EX	=	0x00e8
                           0000E9   318 _IP_EX	=	0x00e9
                           0000B2   319 _GPIO_IE	=	0x00b2
                           008584   320 _ROM_ADDR	=	0x8584
                           000084   321 _ROM_ADDR_L	=	0x0084
                           000085   322 _ROM_ADDR_H	=	0x0085
                           008F8E   323 _ROM_DATA_HI	=	0x8f8e
                           00008E   324 _ROM_DATA_HL	=	0x008e
                           00008F   325 _ROM_DATA_HH	=	0x008f
                           000086   326 _ROM_CTRL	=	0x0086
                           000080   327 _P0	=	0x0080
                           0000C4   328 _P0_MOD_OC	=	0x00c4
                           0000C5   329 _P0_DIR_PU	=	0x00c5
                           000090   330 _P1	=	0x0090
                           000092   331 _P1_MOD_OC	=	0x0092
                           000093   332 _P1_DIR_PU	=	0x0093
                           0000A0   333 _P2	=	0x00a0
                           000094   334 _P2_MOD_OC	=	0x0094
                           000095   335 _P2_DIR_PU	=	0x0095
                           0000B0   336 _P3	=	0x00b0
                           000096   337 _P3_MOD_OC	=	0x0096
                           000097   338 _P3_DIR_PU	=	0x0097
                           0000C0   339 _P4	=	0x00c0
                           0000C2   340 _P4_MOD_OC	=	0x00c2
                           0000C3   341 _P4_DIR_PU	=	0x00c3
                           0000C1   342 _P4_LED_KEY	=	0x00c1
                           0000AA   343 _P5_IN	=	0x00aa
                           0000AB   344 _P5_OUT_PU	=	0x00ab
                           0000AC   345 _P5_DIR	=	0x00ac
                           0000AD   346 _P6_IN	=	0x00ad
                           0000AE   347 _P6_OUT_PU	=	0x00ae
                           0000AF   348 _P6_DIR	=	0x00af
                           0000F1   349 _P7	=	0x00f1
                           0000A2   350 _XBUS_AUX	=	0x00a2
                           000088   351 _TCON	=	0x0088
                           000089   352 _TMOD	=	0x0089
                           00008A   353 _TL0	=	0x008a
                           00008B   354 _TL1	=	0x008b
                           00008C   355 _TH0	=	0x008c
                           00008D   356 _TH1	=	0x008d
                           000098   357 _SCON	=	0x0098
                           000099   358 _SBUF	=	0x0099
                           0000C8   359 _T2CON	=	0x00c8
                           0000C9   360 _T2MOD	=	0x00c9
                           00CBCA   361 _RCAP2	=	0xcbca
                           0000CA   362 _RCAP2L	=	0x00ca
                           0000CB   363 _RCAP2H	=	0x00cb
                           00CDCC   364 _T2COUNT	=	0xcdcc
                           0000CC   365 _TL2	=	0x00cc
                           0000CD   366 _TH2	=	0x00cd
                           00CFCE   367 _T2CAP1	=	0xcfce
                           0000CE   368 _T2CAP1L	=	0x00ce
                           0000CF   369 _T2CAP1H	=	0x00cf
                           0000F8   370 _SPI0_STAT	=	0x00f8
                           0000F9   371 _SPI0_DATA	=	0x00f9
                           0000FA   372 _SPI0_CTRL	=	0x00fa
                           0000FB   373 _SPI0_CK_SE	=	0x00fb
                           0000FC   374 _SPI0_SETUP	=	0x00fc
                           0000BC   375 _SCON1	=	0x00bc
                           0000BD   376 _SBUF1	=	0x00bd
                           0000BE   377 _SBAUD1	=	0x00be
                           0000BF   378 _SIF1	=	0x00bf
                           0000B4   379 _SPI1_STAT	=	0x00b4
                           0000B5   380 _SPI1_DATA	=	0x00b5
                           0000B6   381 _SPI1_CTRL	=	0x00b6
                           0000B7   382 _SPI1_CK_SE	=	0x00b7
                           0000F3   383 _ADC_CTRL	=	0x00f3
                           00F5F4   384 _ADC_DAT	=	0xf5f4
                           0000F4   385 _ADC_DAT_L	=	0x00f4
                           0000F5   386 _ADC_DAT_H	=	0x00f5
                           0000F6   387 _ADC_CHAN	=	0x00f6
                           0000A6   388 _LED_COMMON	=	0x00a6
                           0000A7   389 _LED_PWM_OE	=	0x00a7
                           00C7C6   390 _LED_DMA	=	0xc7c6
                           0000C6   391 _LED_DMA_L	=	0x00c6
                           0000C7   392 _LED_DMA_H	=	0x00c7
                           0000F7   393 _LED_STATUS	=	0x00f7
                           0000B3   394 _I2CX_INT	=	0x00b3
                           0000BB   395 _I2CS_INT_ST	=	0x00bb
                                    396 ;--------------------------------------------------------
                                    397 ; special function bits
                                    398 ;--------------------------------------------------------
                                    399 	.area RSEG    (ABS,DATA)
      000000                        400 	.org 0x0000
                           0000D7   401 _CY	=	0x00d7
                           0000D6   402 _AC	=	0x00d6
                           0000D5   403 _F0	=	0x00d5
                           0000D4   404 _RS1	=	0x00d4
                           0000D3   405 _RS0	=	0x00d3
                           0000D2   406 _OV	=	0x00d2
                           0000D1   407 _F1	=	0x00d1
                           0000D0   408 _P	=	0x00d0
                           0000AF   409 _EA	=	0x00af
                           0000AE   410 _E_DIS	=	0x00ae
                           0000AD   411 _ET2	=	0x00ad
                           0000AC   412 _ES	=	0x00ac
                           0000AB   413 _ET1	=	0x00ab
                           0000AA   414 _EX1	=	0x00aa
                           0000A9   415 _ET0	=	0x00a9
                           0000A8   416 _EX0	=	0x00a8
                           0000BF   417 _PH_FLAG	=	0x00bf
                           0000BE   418 _PL_FLAG	=	0x00be
                           0000BD   419 _PT2	=	0x00bd
                           0000BC   420 _PS	=	0x00bc
                           0000BB   421 _PT1	=	0x00bb
                           0000BA   422 _PX1	=	0x00ba
                           0000B9   423 _PT0	=	0x00b9
                           0000B8   424 _PX0	=	0x00b8
                           0000EF   425 _IE_WDOG	=	0x00ef
                           0000EE   426 _IE_GPIO	=	0x00ee
                           0000ED   427 _IE_PWM_I2C	=	0x00ed
                           0000EC   428 _IE_UART1	=	0x00ec
                           0000EB   429 _IE_ADC	=	0x00eb
                           0000E9   430 _IE_USB	=	0x00e9
                           0000E8   431 _IE_SPI0	=	0x00e8
                           000087   432 _P0_7	=	0x0087
                           000086   433 _P0_6	=	0x0086
                           000085   434 _P0_5	=	0x0085
                           000084   435 _P0_4	=	0x0084
                           000083   436 _P0_3	=	0x0083
                           000082   437 _P0_2	=	0x0082
                           000081   438 _P0_1	=	0x0081
                           000080   439 _P0_0	=	0x0080
                           000081   440 _SDA0	=	0x0081
                           000080   441 _SCL0	=	0x0080
                           000083   442 _TXD_	=	0x0083
                           000082   443 _RXD_	=	0x0082
                           000085   444 _AIN13	=	0x0085
                           000084   445 _AIN12	=	0x0084
                           000083   446 _AIN11	=	0x0083
                           000082   447 _AIN10	=	0x0082
                           000081   448 _AIN9	=	0x0081
                           000080   449 _AIN8	=	0x0080
                           000097   450 _P1_7	=	0x0097
                           000096   451 _P1_6	=	0x0096
                           000095   452 _P1_5	=	0x0095
                           000094   453 _P1_4	=	0x0094
                           000093   454 _P1_3	=	0x0093
                           000092   455 _P1_2	=	0x0092
                           000091   456 _P1_1	=	0x0091
                           000090   457 _P1_0	=	0x0090
                           000097   458 _TXD1_	=	0x0097
                           000096   459 _RXD1_	=	0x0096
                           000097   460 _SCK	=	0x0097
                           000096   461 _MISO	=	0x0096
                           000095   462 _MOSI	=	0x0095
                           000094   463 _SCS	=	0x0094
                           000092   464 _INT0_	=	0x0092
                           000091   465 _T2EX	=	0x0091
                           000091   466 _CAP2	=	0x0091
                           000090   467 _T2	=	0x0090
                           000090   468 _CAP1	=	0x0090
                           000097   469 _AIN7	=	0x0097
                           000096   470 _AIN6	=	0x0096
                           000095   471 _AIN5	=	0x0095
                           000094   472 _AIN4	=	0x0094
                           000093   473 _AIN3	=	0x0093
                           000092   474 _AIN2	=	0x0092
                           000091   475 _AIN1	=	0x0091
                           000090   476 _AIN0	=	0x0090
                           0000A7   477 _P2_7	=	0x00a7
                           0000A6   478 _P2_6	=	0x00a6
                           0000A5   479 _P2_5	=	0x00a5
                           0000A4   480 _P2_4	=	0x00a4
                           0000A3   481 _P2_3	=	0x00a3
                           0000A2   482 _P2_2	=	0x00a2
                           0000A1   483 _P2_1	=	0x00a1
                           0000A0   484 _P2_0	=	0x00a0
                           0000A7   485 _TXD1	=	0x00a7
                           0000A6   486 _RXD1	=	0x00a6
                           0000A5   487 _T2EX_	=	0x00a5
                           0000A5   488 _CAP2_	=	0x00a5
                           0000A4   489 _T2_	=	0x00a4
                           0000A4   490 _CAP1_	=	0x00a4
                           0000B7   491 _P3_7	=	0x00b7
                           0000B6   492 _P3_6	=	0x00b6
                           0000B5   493 _P3_5	=	0x00b5
                           0000B4   494 _P3_4	=	0x00b4
                           0000B3   495 _P3_3	=	0x00b3
                           0000B2   496 _P3_2	=	0x00b2
                           0000B1   497 _P3_1	=	0x00b1
                           0000B0   498 _P3_0	=	0x00b0
                           0000B7   499 _SCK1	=	0x00b7
                           0000B6   500 _MISO1	=	0x00b6
                           0000B5   501 _MOSI1	=	0x00b5
                           0000B5   502 _T1	=	0x00b5
                           0000B4   503 _T0	=	0x00b4
                           0000B3   504 _INT1	=	0x00b3
                           0000B2   505 _INT0	=	0x00b2
                           0000B1   506 _TXD	=	0x00b1
                           0000B0   507 _RXD	=	0x00b0
                           0000C6   508 _P4_6	=	0x00c6
                           0000C5   509 _P4_5	=	0x00c5
                           0000C4   510 _P4_4	=	0x00c4
                           0000C3   511 _P4_3	=	0x00c3
                           0000C2   512 _P4_2	=	0x00c2
                           0000C1   513 _P4_1	=	0x00c1
                           0000C0   514 _P4_0	=	0x00c0
                           00008F   515 _TF1	=	0x008f
                           00008E   516 _TR1	=	0x008e
                           00008D   517 _TF0	=	0x008d
                           00008C   518 _TR0	=	0x008c
                           00008B   519 _IE1	=	0x008b
                           00008A   520 _IT1	=	0x008a
                           000089   521 _IE0	=	0x0089
                           000088   522 _IT0	=	0x0088
                           00009F   523 _SM0	=	0x009f
                           00009E   524 _SM1	=	0x009e
                           00009D   525 _SM2	=	0x009d
                           00009C   526 _REN	=	0x009c
                           00009B   527 _TB8	=	0x009b
                           00009A   528 _RB8	=	0x009a
                           000099   529 _TI	=	0x0099
                           000098   530 _RI	=	0x0098
                           0000CF   531 _TF2	=	0x00cf
                           0000CF   532 _CAP1F	=	0x00cf
                           0000CE   533 _EXF2	=	0x00ce
                           0000CD   534 _RCLK	=	0x00cd
                           0000CC   535 _TCLK	=	0x00cc
                           0000CB   536 _EXEN2	=	0x00cb
                           0000CA   537 _TR2	=	0x00ca
                           0000C9   538 _C_T2	=	0x00c9
                           0000C8   539 _CP_RL2	=	0x00c8
                           0000FF   540 _S0_FST_ACT	=	0x00ff
                           0000FE   541 _S0_IF_OV	=	0x00fe
                           0000FD   542 _S0_IF_FIRST	=	0x00fd
                           0000FC   543 _S0_IF_BYTE	=	0x00fc
                           0000FB   544 _S0_FREE	=	0x00fb
                           0000FA   545 _S0_T_FIFO	=	0x00fa
                           0000F8   546 _S0_R_FIFO	=	0x00f8
                           0000F7   547 _ADC_START	=	0x00f7
                                    548 ;--------------------------------------------------------
                                    549 ; overlayable register banks
                                    550 ;--------------------------------------------------------
                                    551 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        552 	.ds 8
                                    553 ;--------------------------------------------------------
                                    554 ; internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area DSEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable items in internal ram
                                    559 ;--------------------------------------------------------
                                    560 	.area	OSEG    (OVR,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; indirectly addressable internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area ISEG    (DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; absolute internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area IABS    (ABS,DATA)
                                    569 	.area IABS    (ABS,DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; bit data
                                    572 ;--------------------------------------------------------
                                    573 	.area BSEG    (BIT)
                                    574 ;--------------------------------------------------------
                                    575 ; paged external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area PSEG    (PAG,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; uninitialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XSEG    (XDATA)
      000BA9                        582 _switch_events_PARM_2:
      000BA9                        583 	.ds 1
      000BAA                        584 _switch_events_PARM_3:
      000BAA                        585 	.ds 1
      000BAB                        586 _switch_events_row_10000_500:
      000BAB                        587 	.ds 1
      000BAC                        588 _generate_tick_event_last_tick_10000_503:
      000BAC                        589 	.ds 2
      000BAE                        590 _matrix_task_last_tick_60000_532:
      000BAE                        591 	.ds 2
      000BB0                        592 _matrix_task_dummy_event_70000_533:
      000BB0                        593 	.ds 6
      000BB6                        594 _matrix_task_matrix_previous_10001_510:
      000BB6                        595 	.ds 16
      000BC6                        596 _matrix_task_matrix_changed_10002_511:
      000BC6                        597 	.ds 1
      000BC7                        598 _matrix_task_last_tick_60002_536:
      000BC7                        599 	.ds 2
      000BC9                        600 _matrix_task_dummy_event_70002_537:
      000BC9                        601 	.ds 6
      000BCF                        602 _matrix_task_row_changes_30003_520:
      000BCF                        603 	.ds 1
      000BD0                        604 _matrix_task_col_mask_30004_523:
      000BD0                        605 	.ds 1
      000BD1                        606 _matrix_task_dummy_event_90004_529:
      000BD1                        607 	.ds 6
                                    608 ;--------------------------------------------------------
                                    609 ; absolute external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area XABS    (ABS,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; initialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XISEG   (XDATA)
      000E51                        616 _last_input_modification_time:
      000E51                        617 	.ds 4
      000E55                        618 _last_matrix_modification_time:
      000E55                        619 	.ds 4
      000E59                        620 _last_encoder_modification_time:
      000E59                        621 	.ds 4
      000E5D                        622 _last_pointing_device_modification_time:
      000E5D                        623 	.ds 4
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT0 (CODE)
                                    626 	.area GSINIT1 (CODE)
                                    627 	.area GSINIT2 (CODE)
                                    628 	.area GSINIT3 (CODE)
                                    629 	.area GSINIT4 (CODE)
                                    630 	.area GSINIT5 (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area CSEG    (CODE)
                                    634 ;--------------------------------------------------------
                                    635 ; global & static initialisations
                                    636 ;--------------------------------------------------------
                                    637 	.area HOME    (CODE)
                                    638 	.area GSINIT  (CODE)
                                    639 	.area GSFINAL (CODE)
                                    640 	.area GSINIT  (CODE)
                                    641 ;------------------------------------------------------------
                                    642 ;Allocation info for local variables in function 'generate_tick_event'
                                    643 ;------------------------------------------------------------
                                    644 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_503'
                                    645 ;now           Allocated with name '_generate_tick_event_now_10000_503'
                                    646 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_505'
                                    647 ;------------------------------------------------------------
                                    648 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030DA 90 0B AC         [24]  649 	mov	dptr,#_generate_tick_event_last_tick_10000_503
      0030DD E4               [12]  650 	clr	a
      0030DE F0               [24]  651 	movx	@dptr,a
      0030DF A3               [24]  652 	inc	dptr
      0030E0 F0               [24]  653 	movx	@dptr,a
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'matrix_task'
                                    656 ;------------------------------------------------------------
                                    657 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_532'
                                    658 ;now           Allocated with name '_matrix_task_now_60000_532'
                                    659 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_533'
                                    660 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_510'
                                    661 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_511'
                                    662 ;row           Allocated with name '_matrix_task_row_20002_512'
                                    663 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_536'
                                    664 ;now           Allocated with name '_matrix_task_now_60002_536'
                                    665 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_537'
                                    666 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_518'
                                    667 ;row           Allocated with name '_matrix_task_row_20003_519'
                                    668 ;__400030089   Allocated with name '_matrix_task___400030089_40003_520'
                                    669 ;current_row   Allocated with name '_matrix_task_current_row_30003_520'
                                    670 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_520'
                                    671 ;__500030090   Allocated with name '_matrix_task___500030090_50003_538'
                                    672 ;__500030091   Allocated with name '_matrix_task___500030091_50003_538'
                                    673 ;row           Allocated with name '_matrix_task_row_60003_539'
                                    674 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_539'
                                    675 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_523'
                                    676 ;col           Allocated with name '_matrix_task_col_40004_524'
                                    677 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_527'
                                    678 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_529'
                                    679 ;------------------------------------------------------------
                                    680 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030E1 90 0B AE         [24]  681 	mov	dptr,#_matrix_task_last_tick_60000_532
      0030E4 E4               [12]  682 	clr	a
      0030E5 F0               [24]  683 	movx	@dptr,a
      0030E6 A3               [24]  684 	inc	dptr
      0030E7 F0               [24]  685 	movx	@dptr,a
      0030E8 90 0B C7         [24]  686 	mov	dptr,#_matrix_task_last_tick_60002_536
      0030EB F0               [24]  687 	movx	@dptr,a
      0030EC A3               [24]  688 	inc	dptr
      0030ED F0               [24]  689 	movx	@dptr,a
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    701 ;------------------------------------------------------------
                                    702 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    703 ;------------------------------------------------------------
                                    704 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function last_matrix_activity_trigger
                                    715 ;	-----------------------------------------
      009855                        716 _last_matrix_activity_trigger:
                                    717 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      009855 12 4B 81         [24]  718 	lcall	_timer_read32
      009858 12 51 BB         [24]  719 	lcall	_ak820_outline_0057
      00985B 90 0E 51         [24]  720 	mov	dptr,#_last_input_modification_time
      00985E 12 95 A9         [24]  721 	lcall	_ak820_outline_0006
      009861 90 0E 55         [24]  722 	mov	dptr,#_last_matrix_modification_time
      009864 12 95 A9         [24]  723 	lcall	_ak820_outline_0006
                                    724 ;	quantum/keyboard.c:191: }
      009867 22               [24]  725 	ret
                                    726 ;------------------------------------------------------------
                                    727 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    728 ;------------------------------------------------------------
                                    729 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    730 ;	-----------------------------------------
                                    731 ;	 function last_encoder_activity_trigger
                                    732 ;	-----------------------------------------
      009868                        733 _last_encoder_activity_trigger:
                                    734 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      009868 12 4B 81         [24]  735 	lcall	_timer_read32
      00986B 12 51 BB         [24]  736 	lcall	_ak820_outline_0057
      00986E 90 0E 51         [24]  737 	mov	dptr,#_last_input_modification_time
      009871 12 95 A9         [24]  738 	lcall	_ak820_outline_0006
      009874 90 0E 59         [24]  739 	mov	dptr,#_last_encoder_modification_time
      009877 12 95 A9         [24]  740 	lcall	_ak820_outline_0006
                                    741 ;	quantum/keyboard.c:202: }
      00987A 22               [24]  742 	ret
                                    743 ;------------------------------------------------------------
                                    744 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    745 ;------------------------------------------------------------
                                    746 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    747 ;	-----------------------------------------
                                    748 ;	 function keyboard_post_init_kb
                                    749 ;	-----------------------------------------
      00987B                        750 _keyboard_post_init_kb:
                                    751 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    752 ;	quantum/keyboard.c:346: }
      00987B 02 9C 86         [24]  753 	ljmp	_keyboard_post_init_user
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'matrix_can_read'
                                    756 ;------------------------------------------------------------
                                    757 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    758 ;	-----------------------------------------
                                    759 ;	 function matrix_can_read
                                    760 ;	-----------------------------------------
      00987E                        761 _matrix_can_read:
                                    762 ;	quantum/keyboard.c:353: return true;
      00987E 75 82 01         [24]  763 	mov	dpl, #0x01
                                    764 ;	quantum/keyboard.c:354: }
      009881 22               [24]  765 	ret
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'keyboard_setup'
                                    768 ;------------------------------------------------------------
                                    769 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function keyboard_setup
                                    772 ;	-----------------------------------------
      009882                        773 _keyboard_setup:
                                    774 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      009882 90 9D EE         [24]  775 	mov	dptr,#_sendchar
      009885 12 9D C2         [24]  776 	lcall	_print_set_sendchar
                                    777 ;	quantum/keyboard.c:363: eeprom_driver_init();
      009888 12 40 80         [24]  778 	lcall	_eeprom_driver_init
                                    779 ;	quantum/keyboard.c:366: vial_init();
                                    780 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    781 ;	quantum/keyboard.c:373: }
      00988B 02 B3 15         [24]  782 	ljmp	_vial_init
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'is_keyboard_master'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function is_keyboard_master
                                    789 ;	-----------------------------------------
      00988E                        790 _is_keyboard_master:
                                    791 ;	quantum/keyboard.c:382: return true;
      00988E 75 82 01         [24]  792 	mov	dpl, #0x01
                                    793 ;	quantum/keyboard.c:383: }
      009891 22               [24]  794 	ret
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'is_keyboard_left'
                                    797 ;------------------------------------------------------------
                                    798 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    799 ;	-----------------------------------------
                                    800 ;	 function should_process_keypress
                                    801 ;	-----------------------------------------
      009892                        802 _should_process_keypress:
                                    803 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    804 ;	quantum/keyboard.c:402: }
      009892 02 98 8E         [24]  805 	ljmp	_is_keyboard_master
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    810 ;	-----------------------------------------
                                    811 ;	 function housekeeping_task
                                    812 ;	-----------------------------------------
      009895                        813 _housekeeping_task:
                                    814 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    815 ;	quantum/keyboard.c:425: }
      009895 22               [24]  816 	ret
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'quantum_init'
                                    819 ;------------------------------------------------------------
                                    820 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    821 ;	-----------------------------------------
                                    822 ;	 function quantum_init
                                    823 ;	-----------------------------------------
      009896                        824 _quantum_init:
                                    825 ;	quantum/keyboard.c:432: magic();
      009896 12 86 E9         [24]  826 	lcall	_magic
                                    827 ;	quantum/keyboard.c:433: led_init_ports();
      009899 12 9D 58         [24]  828 	lcall	_led_init_ports
                                    829 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    830 ;	quantum/keyboard.c:452: }
      00989C 02 55 E8         [24]  831 	ljmp	_rgb_matrix_init
                                    832 ;------------------------------------------------------------
                                    833 ;Allocation info for local variables in function 'keyboard_init'
                                    834 ;------------------------------------------------------------
                                    835 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    836 ;	-----------------------------------------
                                    837 ;	 function keyboard_init
                                    838 ;	-----------------------------------------
      00989F                        839 _keyboard_init:
                                    840 ;	quantum/keyboard.c:459: timer_init();
      00989F 12 4B 43         [24]  841 	lcall	_timer_init
                                    842 ;	quantum/keyboard.c:462: via_init();
      0098A2 12 AB E5         [24]  843 	lcall	_via_init
                                    844 ;	quantum/keyboard.c:468: encoder_init();
      0098A5 12 95 F0         [24]  845 	lcall	_encoder_init
                                    846 ;	quantum/keyboard.c:470: matrix_init();
      0098A8 12 5F 0E         [24]  847 	lcall	_matrix_init
                                    848 ;	quantum/keyboard.c:471: quantum_init();
      0098AB 12 98 96         [24]  849 	lcall	_quantum_init
                                    850 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    851 ;	quantum/keyboard.c:522: }
      0098AE 02 98 7B         [24]  852 	ljmp	_keyboard_post_init_kb
                                    853 ;------------------------------------------------------------
                                    854 ;Allocation info for local variables in function 'switch_events'
                                    855 ;------------------------------------------------------------
                                    856 ;col           Allocated with name '_switch_events_PARM_2'
                                    857 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    858 ;row           Allocated with name '_switch_events_row_10000_500'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function switch_events
                                    863 ;	-----------------------------------------
      0098B1                        864 _switch_events:
      0098B1 E5 82            [12]  865 	mov	a,dpl
      0098B3 90 0B AB         [24]  866 	mov	dptr,#_switch_events_row_10000_500
      0098B6 F0               [24]  867 	movx	@dptr,a
                                    868 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      0098B7 E0               [24]  869 	movx	a,@dptr
      0098B8 FF               [12]  870 	mov	r7,a
      0098B9 90 0B A9         [24]  871 	mov	dptr,#_switch_events_PARM_2
      0098BC E0               [24]  872 	movx	a,@dptr
      0098BD FE               [12]  873 	mov	r6,a
      0098BE 90 0B AA         [24]  874 	mov	dptr,#_switch_events_PARM_3
      0098C1 E0               [24]  875 	movx	a,@dptr
      0098C2 FD               [12]  876 	mov	r5,a
      0098C3 90 07 53         [24]  877 	mov	dptr,#_process_rgb_matrix_PARM_2
      0098C6 EE               [12]  878 	mov	a,r6
      0098C7 F0               [24]  879 	movx	@dptr,a
      0098C8 90 07 54         [24]  880 	mov	dptr,#_process_rgb_matrix_PARM_3
      0098CB ED               [12]  881 	mov	a,r5
      0098CC F0               [24]  882 	movx	@dptr,a
      0098CD 8F 82            [24]  883 	mov	dpl, r7
                                    884 ;	quantum/keyboard.c:536: }
      0098CF 02 59 73         [24]  885 	ljmp	_process_rgb_matrix
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'generate_tick_event'
                                    888 ;------------------------------------------------------------
                                    889 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_503'
                                    890 ;now           Allocated with name '_generate_tick_event_now_10000_503'
                                    891 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_505'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function matrix_task
                                    896 ;	-----------------------------------------
      0098D2                        897 _matrix_task:
                                    898 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      0098D2 12 98 7E         [24]  899 	lcall	_matrix_can_read
      0098D5 E5 82            [12]  900 	mov	a, dpl
      0098D7 70 4B            [24]  901 	jnz	00102$
                                    902 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      0098D9 12 4B B2         [24]  903 	lcall	_timer_read
      0098DC 12 45 D8         [24]  904 	lcall	_ak820_outline_0127
                                    905 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      0098DF 90 0B AE         [24]  906 	mov	dptr,#_matrix_task_last_tick_60000_532
      0098E2 12 3A D4         [24]  907 	lcall	_ak820_outline_0061
      0098E5 EE               [12]  908 	mov	a,r6
      0098E6 C3               [12]  909 	clr	c
      0098E7 9C               [12]  910 	subb	a,r4
      0098E8 FC               [12]  911 	mov	r4,a
      0098E9 EF               [12]  912 	mov	a,r7
      0098EA 9D               [12]  913 	subb	a,r5
      0098EB 4C               [12]  914 	orl	a,r4
      0098EC 60 32            [24]  915 	jz	00120$
                                    916 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      0098EE 90 0B B0         [24]  917 	mov	dptr,#_matrix_task_dummy_event_70000_533
      0098F1 E4               [12]  918 	clr	a
      0098F2 F0               [24]  919 	movx	@dptr,a
      0098F3 90 0B B1         [24]  920 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0001)
      0098F6 F0               [24]  921 	movx	@dptr,a
      0098F7 12 4B B2         [24]  922 	lcall	_timer_read
      0098FA 12 45 EF         [24]  923 	lcall	_ak820_outline_0155
      0098FD 90 0B B2         [24]  924 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0002)
      009900 12 3A DA         [24]  925 	lcall	_ak820_outline_0072
      009903 90 0B B4         [24]  926 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0004)
      009906 E4               [12]  927 	clr	a
      009907 F0               [24]  928 	movx	@dptr,a
      009908 90 0B B5         [24]  929 	mov	dptr,#(_matrix_task_dummy_event_70000_533 + 0x0005)
      00990B F0               [24]  930 	movx	@dptr,a
                                    931 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      00990C 90 0B B0         [24]  932 	mov	dptr,#_matrix_task_dummy_event_70000_533
      00990F C0 07            [24]  933 	push	ar7
      009911 C0 06            [24]  934 	push	ar6
      009913 12 75 E8         [24]  935 	lcall	_ak820_action_exec
      009916 D0 06            [24]  936 	pop	ar6
      009918 D0 07            [24]  937 	pop	ar7
                                    938 ;	quantum/keyboard.c:550: last_tick = now;
      00991A 90 0B AE         [24]  939 	mov	dptr,#_matrix_task_last_tick_60000_532
      00991D 12 4A FF         [24]  940 	lcall	_ak820_outline_0060
                                    941 ;	quantum/keyboard.c:563: generate_tick_event();
      009920                        942 00120$:
                                    943 ;	quantum/keyboard.c:564: return false;
      009920 75 82 00         [24]  944 	mov	dpl, #0x00
      009923 22               [24]  945 	ret
      009924                        946 00102$:
                                    947 ;	quantum/keyboard.c:569: matrix_scan();
      009924 12 5F 37         [24]  948 	lcall	_matrix_scan
                                    949 ;	quantum/keyboard.c:573: vial_unlock_task();
      009927 12 B2 80         [24]  950 	lcall	_vial_unlock_task
                                    951 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      00992A 90 0B C6         [24]  952 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      00992D E4               [12]  953 	clr	a
      00992E F0               [24]  954 	movx	@dptr,a
                                    955 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      00992F FF               [12]  956 	mov	r7,a
      009930                        957 00127$:
      009930 BF 10 00         [24]  958 	cjne	r7,#0x10,00247$
      009933                        959 00247$:
      009933 50 1F            [24]  960 	jnc	00103$
      009935 90 0B C6         [24]  961 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      009938 E0               [24]  962 	movx	a,@dptr
      009939 70 19            [24]  963 	jnz	00103$
                                    964 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      00993B EF               [12]  965 	mov	a,r7
      00993C 12 9A 9A         [24]  966 	lcall	_ak820_outline_0067
      00993F E0               [24]  967 	movx	a,@dptr
      009940 FE               [12]  968 	mov	r6,a
      009941 8F 82            [24]  969 	mov	dpl, r7
      009943 12 5E C3         [24]  970 	lcall	_matrix_get_row
      009946 E5 82            [12]  971 	mov	a,dpl
      009948 6E               [12]  972 	xrl	a,r6
                                    973 ;	assignBit
      009949 90 0B C6         [24]  974 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      00994C 24 FF            [12]  975 	add	a,#0xff
      00994E E4               [12]  976 	clr	a
      00994F 33               [12]  977 	rlc	a
      009950 F0               [24]  978 	movx	@dptr,a
                                    979 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009951 0F               [12]  980 	inc	r7
      009952 80 DC            [24]  981 	sjmp	00127$
      009954                        982 00103$:
                                    983 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      009954 90 0B C6         [24]  984 	mov	dptr,#_matrix_task_matrix_changed_10002_511
      009957 E0               [24]  985 	movx	a,@dptr
      009958 70 4B            [24]  986 	jnz	00105$
                                    987 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      00995A 12 4B B2         [24]  988 	lcall	_timer_read
      00995D 12 45 D8         [24]  989 	lcall	_ak820_outline_0127
                                    990 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009960 90 0B C7         [24]  991 	mov	dptr,#_matrix_task_last_tick_60002_536
      009963 12 3A D4         [24]  992 	lcall	_ak820_outline_0061
      009966 EE               [12]  993 	mov	a,r6
      009967 C3               [12]  994 	clr	c
      009968 9C               [12]  995 	subb	a,r4
      009969 FC               [12]  996 	mov	r4,a
      00996A EF               [12]  997 	mov	a,r7
      00996B 9D               [12]  998 	subb	a,r5
      00996C 4C               [12]  999 	orl	a,r4
      00996D 60 32            [24] 1000 	jz	00123$
                                   1001 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      00996F 90 0B C9         [24] 1002 	mov	dptr,#_matrix_task_dummy_event_70002_537
      009972 E4               [12] 1003 	clr	a
      009973 F0               [24] 1004 	movx	@dptr,a
      009974 90 0B CA         [24] 1005 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0001)
      009977 F0               [24] 1006 	movx	@dptr,a
      009978 12 4B B2         [24] 1007 	lcall	_timer_read
      00997B 12 45 EF         [24] 1008 	lcall	_ak820_outline_0155
      00997E 90 0B CB         [24] 1009 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0002)
      009981 12 3A DA         [24] 1010 	lcall	_ak820_outline_0072
      009984 90 0B CD         [24] 1011 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0004)
      009987 E4               [12] 1012 	clr	a
      009988 F0               [24] 1013 	movx	@dptr,a
      009989 90 0B CE         [24] 1014 	mov	dptr,#(_matrix_task_dummy_event_70002_537 + 0x0005)
      00998C F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      00998D 90 0B C9         [24] 1017 	mov	dptr,#_matrix_task_dummy_event_70002_537
      009990 C0 07            [24] 1018 	push	ar7
      009992 C0 06            [24] 1019 	push	ar6
      009994 12 75 E8         [24] 1020 	lcall	_ak820_action_exec
      009997 D0 06            [24] 1021 	pop	ar6
      009999 D0 07            [24] 1022 	pop	ar7
                                   1023 ;	quantum/keyboard.c:550: last_tick = now;
      00999B 90 0B C7         [24] 1024 	mov	dptr,#_matrix_task_last_tick_60002_536
      00999E 12 4A FF         [24] 1025 	lcall	_ak820_outline_0060
                                   1026 ;	quantum/keyboard.c:584: generate_tick_event();
      0099A1                       1027 00123$:
                                   1028 ;	quantum/keyboard.c:585: return matrix_changed;
      0099A1 75 82 00         [24] 1029 	mov	dpl, #0x00
      0099A4 22               [24] 1030 	ret
      0099A5                       1031 00105$:
                                   1032 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      0099A5 90 0E 65         [24] 1033 	mov	dptr,#_debug_config
      0099A8 E0               [24] 1034 	movx	a,@dptr
      0099A9 30 E1 03         [24] 1035 	jnb	acc.1,00107$
                                   1036 ;	quantum/keyboard.c:589: matrix_print();
      0099AC 12 5F 63         [24] 1037 	lcall	_matrix_print
      0099AF                       1038 00107$:
                                   1039 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      0099AF 12 98 92         [24] 1040 	lcall	_should_process_keypress
      0099B2 AF 82            [24] 1041 	mov	r7, dpl
                                   1042 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      0099B4 7E 00            [12] 1043 	mov	r6,#0x00
      0099B6                       1044 00133$:
      0099B6 BE 10 00         [24] 1045 	cjne	r6,#0x10,00253$
      0099B9                       1046 00253$:
      0099B9 40 03            [24] 1047 	jc	00254$
      0099BB 02 9A 73         [24] 1048 	ljmp	00117$
      0099BE                       1049 00254$:
                                   1050 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      0099BE 8E 82            [24] 1051 	mov	dpl, r6
      0099C0 12 5E C3         [24] 1052 	lcall	_matrix_get_row
      0099C3 AD 82            [24] 1053 	mov	r5, dpl
                                   1054 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      0099C5 EE               [12] 1055 	mov	a,r6
      0099C6 12 9A 9A         [24] 1056 	lcall	_ak820_outline_0067
      0099C9 E0               [24] 1057 	movx	a,@dptr
      0099CA FC               [12] 1058 	mov	r4,a
      0099CB ED               [12] 1059 	mov	a,r5
      0099CC 62 04            [12] 1060 	xrl	ar4,a
      0099CE 90 0B CF         [24] 1061 	mov	dptr,#_matrix_task_row_changes_30003_520
      0099D1 EC               [12] 1062 	mov	a,r4
      0099D2 F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      0099D3 EC               [12] 1065 	mov	a,r4
      0099D4 70 03            [24] 1066 	jnz	00255$
      0099D6 02 9A 6F         [24] 1067 	ljmp	00116$
      0099D9                       1068 00255$:
                                   1069 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      0099D9 90 0B D0         [24] 1070 	mov	dptr,#_matrix_task_col_mask_30004_523
      0099DC 74 01            [12] 1071 	mov	a,#0x01
      0099DE F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      0099DF 7C 00            [12] 1074 	mov	r4,#0x00
      0099E1                       1075 00130$:
      0099E1 BC 08 00         [24] 1076 	cjne	r4,#0x08,00256$
      0099E4                       1077 00256$:
      0099E4 40 03            [24] 1078 	jc	00257$
      0099E6 02 9A 69         [24] 1079 	ljmp	00115$
      0099E9                       1080 00257$:
                                   1081 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      0099E9 90 0B CF         [24] 1082 	mov	dptr,#_matrix_task_row_changes_30003_520
      0099EC E0               [24] 1083 	movx	a,@dptr
      0099ED FB               [12] 1084 	mov	r3,a
      0099EE 90 0B D0         [24] 1085 	mov	dptr,#_matrix_task_col_mask_30004_523
      0099F1 E0               [24] 1086 	movx	a,@dptr
      0099F2 FA               [12] 1087 	mov	r2,a
      0099F3 5B               [12] 1088 	anl	a,r3
      0099F4 60 68            [24] 1089 	jz	00131$
                                   1090 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      0099F6 ED               [12] 1091 	mov	a,r5
      0099F7 52 02            [12] 1092 	anl	ar2,a
                                   1093 ;	assignBit
      0099F9 EA               [12] 1094 	mov	a,r2
      0099FA 24 FF            [12] 1095 	add	a,#0xff
      0099FC E4               [12] 1096 	clr	a
      0099FD 33               [12] 1097 	rlc	a
      0099FE FA               [12] 1098 	mov	r2,a
                                   1099 ;	quantum/keyboard.c:607: if (process_keypress) {
      0099FF EF               [12] 1100 	mov	a,r7
      009A00 60 3D            [24] 1101 	jz	00112$
                                   1102 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      009A02 90 0B D1         [24] 1103 	mov	dptr,#_matrix_task_dummy_event_90004_529
      009A05 EC               [12] 1104 	mov	a,r4
      009A06 F0               [24] 1105 	movx	@dptr,a
      009A07 90 0B D2         [24] 1106 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0001)
      009A0A EE               [12] 1107 	mov	a,r6
      009A0B F0               [24] 1108 	movx	@dptr,a
      009A0C 12 4B B2         [24] 1109 	lcall	_timer_read
      009A0F A9 82            [24] 1110 	mov	r1, dpl
      009A11 AB 83            [24] 1111 	mov	r3, dph
      009A13 90 0B D3         [24] 1112 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0002)
      009A16 E9               [12] 1113 	mov	a,r1
      009A17 12 7D 08         [24] 1114 	lcall	_ak820_outline_0189
      009A1A 90 0B D5         [24] 1115 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0004)
      009A1D 74 01            [12] 1116 	mov	a,#0x01
      009A1F F0               [24] 1117 	movx	@dptr,a
      009A20 90 0B D6         [24] 1118 	mov	dptr,#(_matrix_task_dummy_event_90004_529 + 0x0005)
      009A23 EA               [12] 1119 	mov	a,r2
      009A24 F0               [24] 1120 	movx	@dptr,a
                                   1121 ;	quantum/keyboard.c:610: AK820_ACTION_EXEC(dummy_event);
      009A25 90 0B D1         [24] 1122 	mov	dptr,#_matrix_task_dummy_event_90004_529
      009A28 C0 07            [24] 1123 	push	ar7
      009A2A C0 06            [24] 1124 	push	ar6
      009A2C C0 05            [24] 1125 	push	ar5
      009A2E C0 04            [24] 1126 	push	ar4
      009A30 C0 02            [24] 1127 	push	ar2
      009A32 12 75 E8         [24] 1128 	lcall	_ak820_action_exec
      009A35 D0 02            [24] 1129 	pop	ar2
      009A37 D0 04            [24] 1130 	pop	ar4
      009A39 D0 05            [24] 1131 	pop	ar5
      009A3B D0 06            [24] 1132 	pop	ar6
      009A3D D0 07            [24] 1133 	pop	ar7
      009A3F                       1134 00112$:
                                   1135 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      009A3F 90 0B A9         [24] 1136 	mov	dptr,#_switch_events_PARM_2
      009A42 EC               [12] 1137 	mov	a,r4
      009A43 F0               [24] 1138 	movx	@dptr,a
      009A44 90 0B AA         [24] 1139 	mov	dptr,#_switch_events_PARM_3
      009A47 EA               [12] 1140 	mov	a,r2
      009A48 F0               [24] 1141 	movx	@dptr,a
      009A49 8E 82            [24] 1142 	mov	dpl, r6
      009A4B C0 07            [24] 1143 	push	ar7
      009A4D C0 06            [24] 1144 	push	ar6
      009A4F C0 05            [24] 1145 	push	ar5
      009A51 C0 04            [24] 1146 	push	ar4
      009A53 12 98 B1         [24] 1147 	lcall	_switch_events
      009A56 D0 04            [24] 1148 	pop	ar4
      009A58 D0 05            [24] 1149 	pop	ar5
      009A5A D0 06            [24] 1150 	pop	ar6
      009A5C D0 07            [24] 1151 	pop	ar7
      009A5E                       1152 00131$:
                                   1153 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009A5E 0C               [12] 1154 	inc	r4
      009A5F 90 0B D0         [24] 1155 	mov	dptr,#_matrix_task_col_mask_30004_523
      009A62 E0               [24] 1156 	movx	a,@dptr
      009A63 25 E0            [12] 1157 	add	a,acc
      009A65 F0               [24] 1158 	movx	@dptr,a
      009A66 02 99 E1         [24] 1159 	ljmp	00130$
      009A69                       1160 00115$:
                                   1161 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      009A69 EE               [12] 1162 	mov	a,r6
      009A6A 12 9A 9A         [24] 1163 	lcall	_ak820_outline_0067
      009A6D ED               [12] 1164 	mov	a,r5
      009A6E F0               [24] 1165 	movx	@dptr,a
      009A6F                       1166 00116$:
                                   1167 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009A6F 0E               [12] 1168 	inc	r6
      009A70 02 99 B6         [24] 1169 	ljmp	00133$
      009A73                       1170 00117$:
                                   1171 ;	quantum/keyboard.c:620: return matrix_changed;
      009A73 75 82 01         [24] 1172 	mov	dpl, #0x01
                                   1173 ;	quantum/keyboard.c:621: }
      009A76 22               [24] 1174 	ret
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'quantum_task'
                                   1177 ;------------------------------------------------------------
                                   1178 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1179 ;	-----------------------------------------
                                   1180 ;	 function quantum_task
                                   1181 ;	-----------------------------------------
      009A77                       1182 _quantum_task:
                                   1183 ;	quantum/keyboard.c:694: caps_word_task();
                                   1184 ;	quantum/keyboard.c:700: }
      009A77 02 2E FF         [24] 1185 	ljmp	_caps_word_task
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'keyboard_task'
                                   1188 ;------------------------------------------------------------
                                   1189 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_544'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function keyboard_task
                                   1194 ;	-----------------------------------------
      009A7A                       1195 _keyboard_task:
                                   1196 ;	quantum/keyboard.c:705: if (matrix_task()) {
      009A7A 12 98 D2         [24] 1197 	lcall	_matrix_task
      009A7D E5 82            [12] 1198 	mov	a, dpl
      009A7F 60 03            [24] 1199 	jz	00102$
                                   1200 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      009A81 12 98 55         [24] 1201 	lcall	_last_matrix_activity_trigger
                                   1202 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      009A84                       1203 00102$:
                                   1204 ;	quantum/keyboard.c:710: quantum_task();
      009A84 12 9A 77         [24] 1205 	lcall	_quantum_task
                                   1206 ;	quantum/keyboard.c:724: rgb_matrix_task();
      009A87 12 57 0E         [24] 1207 	lcall	_rgb_matrix_task
                                   1208 ;	quantum/keyboard.c:734: if (encoder_read()) {
      009A8A 12 97 B8         [24] 1209 	lcall	_encoder_read
      009A8D E5 82            [12] 1210 	mov	a, dpl
      009A8F 60 03            [24] 1211 	jz	00104$
                                   1212 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      009A91 12 98 68         [24] 1213 	lcall	_last_encoder_activity_trigger
                                   1214 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      009A94                       1215 00104$:
                                   1216 ;	quantum/keyboard.c:765: mousekey_task();
      009A94 12 53 FC         [24] 1217 	lcall	_mousekey_task
                                   1218 ;	quantum/keyboard.c:790: led_task();
                                   1219 ;	quantum/keyboard.c:791: }
      009A97 02 9D 7A         [24] 1220 	ljmp	_led_task
                                   1221 	.area CSEG    (CODE)
                                   1222 	.area CONST   (CODE)
                                   1223 	.area XINIT   (CODE)
      00C756                       1224 __xinit__last_input_modification_time:
      00C756 00 00 00 00           1225 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C75A                       1226 __xinit__last_matrix_modification_time:
      00C75A 00 00 00 00           1227 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C75E                       1228 __xinit__last_encoder_modification_time:
      00C75E 00 00 00 00           1229 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C762                       1230 __xinit__last_pointing_device_modification_time:
      00C762 00 00 00 00           1231 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1232 	.area CABS    (ABS,CODE)
                                   1233 
                                   1234 ; Experimental exact instruction outlining.
                                   1235 	.globl _ak820_outline_0006
                                   1236 	.globl _ak820_outline_0057
                                   1237 	.globl _ak820_outline_0060
                                   1238 	.globl _ak820_outline_0061
                                   1239 	.globl _ak820_outline_0067
                                   1240 	.globl _ak820_outline_0072
                                   1241 	.globl _ak820_outline_0127
                                   1242 	.globl _ak820_outline_0155
                                   1243 	.globl _ak820_outline_0189
                                   1244 
                                   1245 	.area CSEG (CODE)
                                   1246 ; function ak820_outline_0067
      009A9A                       1247 _ak820_outline_0067:
      009A9A 24 B6            [12] 1248 	add	a,#_matrix_task_matrix_previous_10001_510
      009A9C F5 82            [12] 1249 	mov	dpl,a
      009A9E E4               [12] 1250 	clr	a
      009A9F 34 0B            [12] 1251 	addc	a,#(_matrix_task_matrix_previous_10001_510>>8)
      009AA1 F5 83            [12] 1252 	mov	dph,a
      009AA3 22               [24] 1253 	ret
