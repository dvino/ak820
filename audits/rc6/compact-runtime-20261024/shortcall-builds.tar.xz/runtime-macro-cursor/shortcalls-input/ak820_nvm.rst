                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00052D                        109 _page_data:
      00052D                        110 	.ds 64
      00056D                        111 _cached_page:
      00056D                        112 	.ds 1
      00056E                        113 _batch_depth:
      00056E                        114 	.ds 1
      00056F                        115 _first_failure_stage:
      00056F                        116 	.ds 1
      000570                        117 _nvm_fail_stage_10000_20:
      000570                        118 	.ds 1
      000571                        119 _ak820_nvm_diagnostic_out_10000_23:
      000571                        120 	.ds 2
      000573                        121 _crc_byte_PARM_2:
      000573                        122 	.ds 1
      000574                        123 _crc_byte_crc_10000_25:
      000574                        124 	.ds 2
      000576                        125 _page_crc_crc_10000_30:
      000576                        126 	.ds 2
      000578                        127 _write_page_address_10000_32:
      000578                        128 	.ds 2
      00057A                        129 _journal_header_valid_header_10000_39:
      00057A                        130 	.ds 2
      00057C                        131 _recover_journal_header_10000_46:
      00057C                        132 	.ds 9
      000585                        133 _ak820_nvm_flush_header_10000_62:
      000585                        134 	.ds 9
      00058E                        135 _ak820_nvm_flush_stage_10000_62:
      00058E                        136 	.ds 1
      00058F                        137 _load_page_page_10000_87:
      00058F                        138 	.ds 1
      000590                        139 _read_offset_offset_10000_93:
      000590                        140 	.ds 2
      000592                        141 _eeprom_read_byte_addr_10000_97:
      000592                        142 	.ds 3
      000595                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000595                        144 	.ds 3
      000598                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000598                        146 	.ds 2
      00059A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00059A                        148 	.ds 2
      00059C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00059C                        150 	.ds 2
      00059E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059E                        152 	.ds 3
      0005A1                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005A1                        154 	.ds 2
      0005A3                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005A3                        156 	.ds 2
      0005A5                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A5                        158 	.ds 3
      0005A8                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A8                        160 	.ds 2
      0005AA                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005AA                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DFF                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DFF E5 82            [12]  215 	mov	a,dpl
      003E01 90 05 70         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003E04 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003E05 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      003E08 90 05 70         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003E0B E0               [24]  221 	movx	a,@dptr
      003E0C 90 05 6F         [24]  222 	mov	dptr,#_first_failure_stage
      003E0F F0               [24]  223 	movx	@dptr,a
      003E10                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E10 D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E12 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E13                        239 _ak820_nvm_diagnostic:
      003E13 12 3A FE         [24]  240 	lcall	_ak820_outline_0110
      003E16 90 05 71         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E19 12 3B 03         [24]  242 	lcall	_ak820_outline_0111
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003E1C 90 05 71         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E1F 12 3A BD         [24]  245 	lcall	_ak820_outline_0052
      003E22 A2 0C            [12]  246 	mov	c,_storage_failed
      003E24 E4               [12]  247 	clr	a
      003E25 33               [12]  248 	rlc	a
      003E26 12 3B 08         [24]  249 	lcall	_ak820_outline_0120
      003E29 12 45 BA         [24]  250 	lcall	_ak820_outline_0079
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003E2C A3               [24]  252 	inc	dptr
      003E2D A2 0A            [12]  253 	mov	c,_page_valid
      003E2F E4               [12]  254 	clr	a
      003E30 33               [12]  255 	rlc	a
      003E31 12 45 87         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E34 A2 0B            [12]  258 	mov	c,_page_dirty
      003E36 E4               [12]  259 	clr	a
      003E37 33               [12]  260 	rlc	a
      003E38 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E39 74 03            [12]  263 	mov	a,#0x03
      003E3B 12 45 F9         [24]  264 	lcall	_ak820_outline_0167
      003E3E 90 05 6E         [24]  265 	mov	dptr,#_batch_depth
      003E41 E0               [24]  266 	movx	a,@dptr
      003E42 12 3B 13         [24]  267 	lcall	_ak820_outline_0126
      003E45 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E46 74 04            [12]  270 	mov	a,#0x04
      003E48 12 45 F9         [24]  271 	lcall	_ak820_outline_0167
      003E4B 90 05 6D         [24]  272 	mov	dptr,#_cached_page
      003E4E E0               [24]  273 	movx	a,@dptr
      003E4F 12 3B 13         [24]  274 	lcall	_ak820_outline_0126
      003E52 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E53 12 45 7D         [24]  277 	lcall	_ak820_outline_0011
      003E56 E4               [12]  278 	clr	a
      003E57 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E58 74 06            [12]  281 	mov	a,#0x06
      003E5A 12 45 DD         [24]  282 	lcall	_ak820_outline_0139
      003E5D 90 05 6F         [24]  283 	mov	dptr,#_first_failure_stage
      003E60 E0               [24]  284 	movx	a,@dptr
      003E61 12 3B 08         [24]  285 	lcall	_ak820_outline_0120
      003E64 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E65 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E66                        300 _crc_byte:
      003E66 12 3A FE         [24]  301 	lcall	_ak820_outline_0110
      003E69 90 05 74         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E6C 12 3B 03         [24]  303 	lcall	_ak820_outline_0111
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E6F 90 05 73         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E72 E0               [24]  306 	movx	a,@dptr
      003E73 FF               [12]  307 	mov	r7,a
      003E74 7E 00            [12]  308 	mov	r6,#0x00
      003E76 90 05 74         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E79 E0               [24]  310 	movx	a,@dptr
      003E7A 6E               [12]  311 	xrl	a,r6
      003E7B F0               [24]  312 	movx	@dptr,a
      003E7C A3               [24]  313 	inc	dptr
      003E7D E0               [24]  314 	movx	a,@dptr
      003E7E 6F               [12]  315 	xrl	a,r7
      003E7F F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E80 7F 00            [12]  318 	mov	r7,#0x00
      003E82                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E82 90 05 74         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E85 12 3A E0         [24]  322 	lcall	_ak820_outline_0080
      003E88 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E8B ED               [12]  324 	mov	a,r5
      003E8C 2D               [12]  325 	add	a,r5
      003E8D FB               [12]  326 	mov	r3,a
      003E8E EE               [12]  327 	mov	a,r6
      003E8F 33               [12]  328 	rlc	a
      003E90 FC               [12]  329 	mov	r4,a
      003E91 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E94 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E97 80 06            [24]  332 	sjmp	00107$
      003E99                        333 00106$:
      003E99 ED               [12]  334 	mov	a,r5
      003E9A 2D               [12]  335 	add	a,r5
      003E9B FB               [12]  336 	mov	r3,a
      003E9C EE               [12]  337 	mov	a,r6
      003E9D 33               [12]  338 	rlc	a
      003E9E FC               [12]  339 	mov	r4,a
      003E9F                        340 00107$:
      003E9F 90 05 74         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003EA2 12 3A E6         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003EA5 0F               [12]  344 	inc	r7
      003EA6 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003EA9 12 36 78         [24]  347 	lcall	_ak820_outline_0125
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003EAC 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003EAD                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003EAD 90 05 76         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003EB0 74 FF            [12]  363 	mov	a,#0xff
      003EB2 F0               [24]  364 	movx	@dptr,a
      003EB3 A3               [24]  365 	inc	dptr
      003EB4 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003EB5 7F 00            [12]  368 	mov	r7,#0x00
      003EB7                        369 00102$:
      003EB7 90 05 76         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003EBA 12 3A E0         [24]  371 	lcall	_ak820_outline_0080
      003EBD 12 45 CC         [24]  372 	lcall	_ak820_outline_0108
      003EC0 90 05 73         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003EC3 F0               [24]  374 	movx	@dptr,a
      003EC4 12 3B 1D         [24]  375 	lcall	_ak820_outline_0137
      003EC7 C0 07            [24]  376 	push	ar7
      003EC9 12 3E 66         [24]  377 	lcall	_crc_byte
      003ECC AD 82            [24]  378 	mov	r5, dpl
      003ECE AE 83            [24]  379 	mov	r6, dph
      003ED0 D0 07            [24]  380 	pop	ar7
      003ED2 90 05 76         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003ED5 12 45 E3         [24]  382 	lcall	_ak820_outline_0141
      003ED8 0F               [12]  383 	inc	r7
      003ED9 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003EDC 12 3B 1D         [24]  386 	lcall	_ak820_outline_0137
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003EDF 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003EE0                        399 _write_page:
      003EE0 12 3A FE         [24]  400 	lcall	_ak820_outline_0110
      003EE3 90 05 78         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003EE6 12 3B 03         [24]  402 	lcall	_ak820_outline_0111
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EE9 90 05 78         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EEC 12 3A 70         [24]  405 	lcall	_ak820_outline_0005
      003EEF C0 07            [24]  406 	push	ar7
      003EF1 C0 06            [24]  407 	push	ar6
      003EF3 12 3C 78         [24]  408 	lcall	_ak820_flash_erase
      003EF6 E5 82            [12]  409 	mov	a, dpl
      003EF8 D0 06            [24]  410 	pop	ar6
      003EFA D0 07            [24]  411 	pop	ar7
      003EFC 70 03            [24]  412 	jnz	00102$
      003EFE F5 82            [12]  413 	mov	dpl,a
      003F00 22               [24]  414 	ret
      003F01                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003F01 90 05 09         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003F04 74 2D            [12]  418 	mov	a,#_page_data
      003F06 F0               [24]  419 	movx	@dptr,a
      003F07 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003F09 A3               [24]  421 	inc	dptr
      003F0A 12 45 BA         [24]  422 	lcall	_ak820_outline_0079
      003F0D 12 3D 8C         [24]  423 	lcall	_ak820_flash_program_page
      003F10 E5 82            [12]  424 	mov	a, dpl
      003F12 70 03            [24]  425 	jnz	00120$
      003F14 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F16 22               [24]  428 	ret
      003F17                        429 00120$:
      003F17 7F 00            [12]  430 	mov	r7,#0x00
      003F19                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003F19 8F 05            [24]  433 	mov	ar5,r7
      003F1B 7E 00            [12]  434 	mov	r6,#0x00
      003F1D 90 05 78         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003F20 12 3B 0D         [24]  436 	lcall	_ak820_outline_0124
      003F23 ED               [12]  437 	mov	a,r5
      003F24 2B               [12]  438 	add	a, r3
      003F25 FB               [12]  439 	mov	r3,a
      003F26 EE               [12]  440 	mov	a,r6
      003F27 3C               [12]  441 	addc	a, r4
      003F28 FC               [12]  442 	mov	r4,a
      003F29 12 36 78         [24]  443 	lcall	_ak820_outline_0125
      003F2C 12 3B 6B         [24]  444 	lcall	_ak820_flash_read
      003F2F AE 82            [24]  445 	mov	r6, dpl
      003F31 12 45 CC         [24]  446 	lcall	_ak820_outline_0108
      003F34 FD               [12]  447 	mov	r5,a
      003F35 EE               [12]  448 	mov	a,r6
      003F36 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F39 80 04            [24]  450 	sjmp	00109$
      003F3B                        451 00149$:
      003F3B 75 82 00         [24]  452 	mov	dpl, #0x00
      003F3E 22               [24]  453 	ret
      003F3F                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F3F 0F               [12]  456 	inc	r7
      003F40 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F43 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F46 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F47                        472 _journal_header_valid:
      003F47 12 3A FE         [24]  473 	lcall	_ak820_outline_0110
      003F4A 90 05 7A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F4D 12 3B 03         [24]  475 	lcall	_ak820_outline_0111
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F50 90 05 7A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F53 12 3A 70         [24]  478 	lcall	_ak820_outline_0005
      003F56 E0               [24]  479 	movx	a,@dptr
      003F57 FD               [12]  480 	mov	r5,a
      003F58 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F5B 80 04            [24]  482 	sjmp	00116$
      003F5D                        483 00138$:
      003F5D 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F60 22               [24]  486 	ret
      003F61                        487 00116$:
      003F61 7D 01            [12]  488 	mov	r5,#0x01
      003F63                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F63 ED               [12]  491 	mov	a,r5
      003F64 12 3A AD         [24]  492 	lcall	_ak820_outline_0022
      003F67 E0               [24]  493 	movx	a,@dptr
      003F68 FC               [12]  494 	mov	r4,a
      003F69 8D 02            [24]  495 	mov	ar2,r5
      003F6B 7B 00            [12]  496 	mov	r3,#0x00
      003F6D 74 04            [12]  497 	mov	a,#0x04
      003F6F 2A               [12]  498 	add	a, r2
      003F70 FA               [12]  499 	mov	r2,a
      003F71 E4               [12]  500 	clr	a
      003F72 3B               [12]  501 	addc	a, r3
      003F73 FB               [12]  502 	mov	r3,a
      003F74 EA               [12]  503 	mov	a,r2
      003F75 2E               [12]  504 	add	a, r6
      003F76 F5 82            [12]  505 	mov	dpl,a
      003F78 EB               [12]  506 	mov	a,r3
      003F79 3F               [12]  507 	addc	a, r7
      003F7A F5 83            [12]  508 	mov	dph,a
      003F7C E0               [24]  509 	movx	a,@dptr
      003F7D 62 04            [12]  510 	xrl	ar4,a
      003F7F BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003F82 80 04            [24]  512 	sjmp	00107$
      003F84                        513 00139$:
      003F84 75 82 00         [24]  514 	mov	dpl, #0x00
      003F87 22               [24]  515 	ret
      003F88                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F88 0D               [12]  518 	inc	r5
      003F89 BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F8C 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F8F 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003F90                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F90 7F 00            [12]  538 	mov	r7,#0x00
      003F92                        539 00115$:
      003F92 EF               [12]  540 	mov	a,r7
      003F93 24 7C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003F95 FD               [12]  542 	mov	r5,a
      003F96 E4               [12]  543 	clr	a
      003F97 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F99 FE               [12]  545 	mov	r6,a
      003F9A 8F 04            [24]  546 	mov	ar4,r7
      003F9C 7B 00            [12]  547 	mov	r3,#0x00
      003F9E 74 40            [12]  548 	mov	a,#0x40
      003FA0 2C               [12]  549 	add	a, r4
      003FA1 FC               [12]  550 	mov	r4,a
      003FA2 74 EF            [12]  551 	mov	a,#0xef
      003FA4 3B               [12]  552 	addc	a, r3
      003FA5 FB               [12]  553 	mov	r3,a
      003FA6 12 46 04         [24]  554 	lcall	_ak820_outline_0186
      003FA9 12 3B 6B         [24]  555 	lcall	_ak820_flash_read
      003FAC AC 82            [24]  556 	mov	r4, dpl
      003FAE 12 45 B3         [24]  557 	lcall	_ak820_outline_0065
      003FB1 0F               [12]  558 	inc	r7
      003FB2 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003FB5 90 05 7C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003FB8 12 3F 47         [24]  562 	lcall	_journal_header_valid
      003FBB E5 82            [12]  563 	mov	a, dpl
      003FBD 70 01            [24]  564 	jnz	00103$
      003FBF 22               [24]  565 	ret
      003FC0                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003FC0 90 05 7D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003FC3 E0               [24]  569 	movx	a,@dptr
      003FC4 FF               [12]  570 	mov	r7,a
      003FC5 7E 00            [12]  571 	mov	r6,#0x00
      003FC7 90 05 7E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003FCA E0               [24]  573 	movx	a,@dptr
      003FCB FC               [12]  574 	mov	r4,a
      003FCC E4               [12]  575 	clr	a
      003FCD 42 07            [12]  576 	orl	ar7,a
      003FCF EC               [12]  577 	mov	a,r4
      003FD0 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FD2 90 05 7F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FD5 E0               [24]  581 	movx	a,@dptr
      003FD6 FD               [12]  582 	mov	r5,a
      003FD7 7C 00            [12]  583 	mov	r4,#0x00
      003FD9 90 05 80         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FDC E0               [24]  585 	movx	a,@dptr
      003FDD FA               [12]  586 	mov	r2,a
      003FDE E4               [12]  587 	clr	a
      003FDF 12 45 E9         [24]  588 	lcall	_ak820_outline_0147
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FE2 C3               [12]  590 	clr	c
      003FE3 EF               [12]  591 	mov	a,r7
      003FE4 94 A0            [12]  592 	subb	a,#0xa0
      003FE6 EE               [12]  593 	mov	a,r6
      003FE7 94 00            [12]  594 	subb	a,#0x00
      003FE9 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FEB 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FEE 02 3D FF         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FF1                        601 00134$:
      003FF1 7B 00            [12]  602 	mov	r3,#0x00
      003FF3                        603 00117$:
      003FF3 C0 05            [24]  604 	push	ar5
      003FF5 C0 04            [24]  605 	push	ar4
      003FF7 EB               [12]  606 	mov	a,r3
      003FF8 24 2D            [12]  607 	add	a, #_page_data
      003FFA F9               [12]  608 	mov	r1,a
      003FFB E4               [12]  609 	clr	a
      003FFC 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003FFE FA               [12]  611 	mov	r2,a
      003FFF 8B 00            [24]  612 	mov	ar0,r3
      004001 7D 00            [12]  613 	mov	r5,#0x00
      004003 74 EF            [12]  614 	mov	a,#0xef
      004005 2D               [12]  615 	add	a, r5
      004006 FD               [12]  616 	mov	r5,a
      004007 88 82            [24]  617 	mov	dpl, r0
      004009 8D 83            [24]  618 	mov	dph, r5
      00400B 12 3B 6B         [24]  619 	lcall	_ak820_flash_read
      00400E AD 82            [24]  620 	mov	r5, dpl
      004010 12 45 FF         [24]  621 	lcall	_ak820_outline_0185
      004013 ED               [12]  622 	mov	a,r5
      004014 F0               [24]  623 	movx	@dptr,a
      004015 0B               [12]  624 	inc	r3
      004016 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      004019 80 06            [24]  626 	sjmp	00191$
      00401B                        627 00190$:
      00401B D0 04            [24]  628 	pop	ar4
      00401D D0 05            [24]  629 	pop	ar5
      00401F 80 D2            [24]  630 	sjmp	00117$
      004021                        631 00191$:
      004021 D0 04            [24]  632 	pop	ar4
      004023 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      004025 C0 07            [24]  635 	push	ar7
      004027 C0 06            [24]  636 	push	ar6
      004029 C0 05            [24]  637 	push	ar5
      00402B C0 04            [24]  638 	push	ar4
      00402D 12 3E AD         [24]  639 	lcall	_page_crc
      004030 AA 82            [24]  640 	mov	r2, dpl
      004032 AB 83            [24]  641 	mov	r3, dph
      004034 D0 04            [24]  642 	pop	ar4
      004036 D0 05            [24]  643 	pop	ar5
      004038 D0 06            [24]  644 	pop	ar6
      00403A D0 07            [24]  645 	pop	ar7
      00403C EA               [12]  646 	mov	a,r2
      00403D B5 05 06         [24]  647 	cjne	a,ar5,00192$
      004040 EB               [12]  648 	mov	a,r3
      004041 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004044 80 06            [24]  650 	sjmp	00113$
      004046                        651 00192$:
      004046 75 82 02         [24]  652 	mov	dpl, #0x02
      004049 02 3D FF         [24]  653 	ljmp	_nvm_fail
      00404C                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00404C EE               [12]  656 	mov	a,r6
      00404D 54 03            [12]  657 	anl	a,#0x03
      00404F A2 E0            [12]  658 	mov	c,acc.0
      004051 CF               [12]  659 	xch	a,r7
      004052 13               [12]  660 	rrc	a
      004053 CF               [12]  661 	xch	a,r7
      004054 13               [12]  662 	rrc	a
      004055 A2 E0            [12]  663 	mov	c,acc.0
      004057 CF               [12]  664 	xch	a,r7
      004058 13               [12]  665 	rrc	a
      004059 CF               [12]  666 	xch	a,r7
      00405A 13               [12]  667 	rrc	a
      00405B CF               [12]  668 	xch	a,r7
      00405C 24 C7            [12]  669 	add	a,#0xc7
      00405E FE               [12]  670 	mov	r6,a
      00405F 12 45 F4         [24]  671 	lcall	_ak820_outline_0165
      004062 12 3E E0         [24]  672 	lcall	_write_page
      004065 E5 82            [12]  673 	mov	a, dpl
      004067 70 06            [24]  674 	jnz	00110$
      004069 75 82 03         [24]  675 	mov	dpl, #0x03
      00406C 02 3D FF         [24]  676 	ljmp	_nvm_fail
      00406F                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      00406F 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004072 12 3C 78         [24]  680 	lcall	_ak820_flash_erase
      004075 E5 82            [12]  681 	mov	a, dpl
      004077 70 06            [24]  682 	jnz	00119$
      004079 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00407C 02 3D FF         [24]  685 	ljmp	_nvm_fail
      00407F                        686 00119$:
      00407F 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      004080                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      004080 C2 0C            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004082 90 05 6F         [24]  700 	mov	dptr,#_first_failure_stage
      004085 E4               [12]  701 	clr	a
      004086 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      004087 C2 0B            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      004089 C2 0A            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00408B 90 05 6E         [24]  709 	mov	dptr,#_batch_depth
      00408E E4               [12]  710 	clr	a
      00408F F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004090 12 3F 90         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004093 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      004096                        724 _ak820_nvm_ok:
      004096 A2 0C            [12]  725 	mov	c,_storage_failed
      004098 B3               [12]  726 	cpl	c
      004099 92 0D            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00409B 12 3B 2D         [24]  728 	lcall	_ak820_outline_0163
      00409E 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      00409F                        737 _ak820_nvm_schema_fault:
      00409F 75 82 10         [24]  738 	mov	dpl, #0x10
      0040A2 02 3D FF         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      0040A5                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      0040A5 30 0B 03         [24]  754 	jnb	_page_dirty,00101$
      0040A8 30 0C 01         [24]  755 	jnb	_storage_failed,00102$
      0040AB                        756 00101$:
      0040AB 22               [24]  757 	ret
      0040AC                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0040AC 12 3E AD         [24]  760 	lcall	_page_crc
      0040AF 12 45 D8         [24]  761 	lcall	_ak820_outline_0127
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0040B2 90 05 85         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0040B5 74 A5            [12]  764 	mov	a,#0xa5
      0040B7 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0040B8 90 05 6D         [24]  767 	mov	dptr,#_cached_page
      0040BB E0               [24]  768 	movx	a,@dptr
      0040BC 90 05 86         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0040BF F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0040C0 90 05 87         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0040C3 E4               [12]  773 	clr	a
      0040C4 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0040C5 8E 05            [24]  776 	mov	ar5,r6
      0040C7 90 05 88         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0040CA ED               [12]  778 	mov	a,r5
      0040CB F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0040CC 8F 06            [24]  781 	mov	ar6,r7
      0040CE 90 05 89         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040D1 EE               [12]  783 	mov	a,r6
      0040D2 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040D3 7F 01            [12]  786 	mov	r7,#0x01
      0040D5                        787 00128$:
      0040D5 8F 06            [24]  788 	mov	ar6,r7
      0040D7 EE               [12]  789 	mov	a,r6
      0040D8 24 04            [12]  790 	add	a,#0x04
      0040DA FE               [12]  791 	mov	r6,a
      0040DB 33               [12]  792 	rlc	a
      0040DC 95 E0            [12]  793 	subb	a,acc
      0040DE FD               [12]  794 	mov	r5,a
      0040DF EE               [12]  795 	mov	a,r6
      0040E0 24 85            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0040E2 FE               [12]  797 	mov	r6,a
      0040E3 ED               [12]  798 	mov	a,r5
      0040E4 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040E6 FD               [12]  800 	mov	r5,a
      0040E7 12 45 96         [24]  801 	lcall	_ak820_outline_0043
      0040EA FC               [12]  802 	mov	r4,a
      0040EB 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0040EE 8E 82            [24]  804 	mov	dpl,r6
      0040F0 8D 83            [24]  805 	mov	dph,r5
      0040F2 EC               [12]  806 	mov	a,r4
      0040F3 F0               [24]  807 	movx	@dptr,a
      0040F4 0F               [12]  808 	inc	r7
      0040F5 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040F8 90 05 8E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040FB 74 05            [12]  812 	mov	a,#0x05
      0040FD F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040FE 90 EF 40         [24]  815 	mov	dptr,#0xef40
      004101 12 3C 78         [24]  816 	lcall	_ak820_flash_erase
      004104 E5 82            [12]  817 	mov	a, dpl
      004106 70 03            [24]  818 	jnz	00269$
      004108 02 41 EF         [24]  819 	ljmp	00127$
      00410B                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      00410B 90 05 8E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00410E 74 06            [12]  823 	mov	a,#0x06
      004110 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004111 7F 00            [12]  826 	mov	r7,#0x00
      004113                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004113 12 45 A2         [24]  829 	lcall	_ak820_outline_0053
      004116 12 3B 6B         [24]  830 	lcall	_ak820_flash_read
      004119 E5 82            [12]  831 	mov	a, dpl
      00411B 60 03            [24]  832 	jz	00270$
      00411D 02 41 EF         [24]  833 	ljmp	00127$
      004120                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004120 0F               [12]  836 	inc	r7
      004121 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      004124 90 05 8E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004127 74 07            [12]  840 	mov	a,#0x07
      004129 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      00412A 90 EF 00         [24]  843 	mov	dptr,#0xef00
      00412D 12 3E E0         [24]  844 	lcall	_write_page
      004130 E5 82            [12]  845 	mov	a, dpl
      004132 70 03            [24]  846 	jnz	00273$
      004134 02 41 EF         [24]  847 	ljmp	00127$
      004137                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004137 90 05 8E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00413A 74 08            [12]  851 	mov	a,#0x08
      00413C F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00413D 7F 01            [12]  854 	mov	r7,#0x01
      00413F                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      00413F 12 45 96         [24]  857 	lcall	_ak820_outline_0043
      004142 FE               [12]  858 	mov	r6,a
      004143 60 23            [24]  859 	jz	00133$
      004145 8F 05            [24]  860 	mov	ar5,r7
      004147 7C 00            [12]  861 	mov	r4,#0x00
      004149 74 40            [12]  862 	mov	a,#0x40
      00414B 2D               [12]  863 	add	a, r5
      00414C FD               [12]  864 	mov	r5,a
      00414D 74 EF            [12]  865 	mov	a,#0xef
      00414F 3C               [12]  866 	addc	a, r4
      004150 FC               [12]  867 	mov	r4,a
      004151 90 05 06         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004154 EE               [12]  869 	mov	a,r6
      004155 F0               [24]  870 	movx	@dptr,a
      004156 8D 82            [24]  871 	mov	dpl, r5
      004158 8C 83            [24]  872 	mov	dph, r4
      00415A C0 07            [24]  873 	push	ar7
      00415C 12 3C D8         [24]  874 	lcall	_ak820_flash_program
      00415F E5 82            [12]  875 	mov	a, dpl
      004161 D0 07            [24]  876 	pop	ar7
      004163 70 03            [24]  877 	jnz	00275$
      004165 02 41 EF         [24]  878 	ljmp	00127$
      004168                        879 00275$:
      004168                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004168 0F               [12]  882 	inc	r7
      004169 BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00416C 90 05 8E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00416F 74 09            [12]  886 	mov	a,#0x09
      004171 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004172 7F 01            [12]  889 	mov	r7,#0x01
      004174                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004174 12 45 A2         [24]  892 	lcall	_ak820_outline_0053
      004177 12 3B 6B         [24]  893 	lcall	_ak820_flash_read
      00417A AE 82            [24]  894 	mov	r6, dpl
      00417C 12 45 96         [24]  895 	lcall	_ak820_outline_0043
      00417F FD               [12]  896 	mov	r5,a
      004180 EE               [12]  897 	mov	a,r6
      004181 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004184 0F               [12]  900 	inc	r7
      004185 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004188 90 05 8E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00418B 74 0A            [12]  904 	mov	a,#0x0a
      00418D F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00418E 90 05 85         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004191 E0               [24]  908 	movx	a,@dptr
      004192 90 05 06         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      004195 F0               [24]  910 	movx	@dptr,a
      004196 90 EF 40         [24]  911 	mov	dptr,#0xef40
      004199 12 3C D8         [24]  912 	lcall	_ak820_flash_program
      00419C E5 82            [12]  913 	mov	a, dpl
      00419E 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      0041A0 90 05 8E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041A3 74 0B            [12]  917 	mov	a,#0x0b
      0041A5 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      0041A6 90 EF 40         [24]  920 	mov	dptr,#0xef40
      0041A9 12 3B 6B         [24]  921 	lcall	_ak820_flash_read
      0041AC AF 82            [24]  922 	mov	r7, dpl
      0041AE 90 05 85         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0041B1 E0               [24]  924 	movx	a,@dptr
      0041B2 FE               [12]  925 	mov	r6,a
      0041B3 EF               [12]  926 	mov	a,r7
      0041B4 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0041B7 90 05 8E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041BA 74 0C            [12]  930 	mov	a,#0x0c
      0041BC F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0041BD 90 05 6D         [24]  933 	mov	dptr,#_cached_page
      0041C0 E0               [24]  934 	movx	a,@dptr
      0041C1 FE               [12]  935 	mov	r6,a
      0041C2 E4               [12]  936 	clr	a
      0041C3 C3               [12]  937 	clr	c
      0041C4 CE               [12]  938 	xch	a,r6
      0041C5 13               [12]  939 	rrc	a
      0041C6 CE               [12]  940 	xch	a,r6
      0041C7 13               [12]  941 	rrc	a
      0041C8 A2 E0            [12]  942 	mov	c,acc.0
      0041CA CE               [12]  943 	xch	a,r6
      0041CB 13               [12]  944 	rrc	a
      0041CC CE               [12]  945 	xch	a,r6
      0041CD 13               [12]  946 	rrc	a
      0041CE CE               [12]  947 	xch	a,r6
      0041CF 24 C7            [12]  948 	add	a,#0xc7
      0041D1 FF               [12]  949 	mov	r7,a
      0041D2 12 3B 08         [24]  950 	lcall	_ak820_outline_0120
      0041D5 12 3E E0         [24]  951 	lcall	_write_page
      0041D8 E5 82            [12]  952 	mov	a, dpl
      0041DA 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041DC 90 05 8E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041DF 74 0D            [12]  956 	mov	a,#0x0d
      0041E1 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041E2 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0041E5 12 3C 78         [24]  960 	lcall	_ak820_flash_erase
      0041E8 E5 82            [12]  961 	mov	a, dpl
      0041EA 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0041EC C2 0B            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041EE 22               [24]  968 	ret
      0041EF                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041EF 90 05 8E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041F2 E0               [24]  972 	movx	a,@dptr
      0041F3 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041F5 02 3D FF         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0041F8                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041F8 90 05 6E         [24]  985 	mov	dptr,#_batch_depth
      0041FB E0               [24]  986 	movx	a,@dptr
      0041FC FF               [12]  987 	mov	r7,a
      0041FD BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      004200 75 82 0F         [24]  989 	mov	dpl, #0x0f
      004203 02 3D FF         [24]  990 	ljmp	_nvm_fail
      004206                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      004206 90 05 6E         [24]  993 	mov	dptr,#_batch_depth
      004209 EF               [12]  994 	mov	a,r7
      00420A 04               [12]  995 	inc	a
      00420B F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      00420C 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      00420D                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      00420D 90 05 6E         [24] 1008 	mov	dptr,#_batch_depth
      004210 E0               [24] 1009 	movx	a,@dptr
      004211 FF               [12] 1010 	mov	r7,a
      004212 E0               [24] 1011 	movx	a,@dptr
      004213 60 06            [24] 1012 	jz	00102$
      004215 EF               [12] 1013 	mov	a,r7
      004216 14               [12] 1014 	dec	a
      004217 90 05 6E         [24] 1015 	mov	dptr,#_batch_depth
      00421A F0               [24] 1016 	movx	@dptr,a
      00421B                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00421B 90 05 6E         [24] 1019 	mov	dptr,#_batch_depth
      00421E E0               [24] 1020 	movx	a,@dptr
      00421F 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004221 02 40 A5         [24] 1023 	ljmp	_ak820_nvm_flush
      004224                       1024 00105$:
      004224 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      004225                       1036 _load_page:
      004225 E5 82            [12] 1037 	mov	a,dpl
      004227 90 05 8F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      00422A F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      00422B 30 0A 17         [24] 1041 	jnb	_page_valid,00102$
      00422E 90 05 6D         [24] 1042 	mov	dptr,#_cached_page
      004231 E0               [24] 1043 	movx	a,@dptr
      004232 FF               [12] 1044 	mov	r7,a
      004233 90 05 8F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      004236 E0               [24] 1046 	movx	a,@dptr
      004237 FE               [12] 1047 	mov	r6,a
      004238 EF               [12] 1048 	mov	a,r7
      004239 B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      00423C A2 0C            [12] 1050 	mov	c,_storage_failed
      00423E B3               [12] 1051 	cpl	c
      00423F 92 0E            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004241 12 3B 2D         [24] 1053 	lcall	_ak820_outline_0163
      004244 22               [24] 1054 	ret
      004245                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004245 12 40 A5         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004248 30 0C 04         [24] 1059 	jnb	_storage_failed,00119$
      00424B 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00424E 22               [24] 1062 	ret
      00424F                       1063 00119$:
      00424F 7F 00            [12] 1064 	mov	r7,#0x00
      004251                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004251 EF               [12] 1067 	mov	a,r7
      004252 24 2D            [12] 1068 	add	a, #_page_data
      004254 FD               [12] 1069 	mov	r5,a
      004255 E4               [12] 1070 	clr	a
      004256 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      004258 FE               [12] 1072 	mov	r6,a
      004259 90 05 8F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00425C E0               [24] 1074 	movx	a,@dptr
      00425D FC               [12] 1075 	mov	r4,a
      00425E FA               [12] 1076 	mov	r2,a
      00425F E4               [12] 1077 	clr	a
      004260 C3               [12] 1078 	clr	c
      004261 CA               [12] 1079 	xch	a,r2
      004262 13               [12] 1080 	rrc	a
      004263 CA               [12] 1081 	xch	a,r2
      004264 13               [12] 1082 	rrc	a
      004265 A2 E0            [12] 1083 	mov	c,acc.0
      004267 CA               [12] 1084 	xch	a,r2
      004268 13               [12] 1085 	rrc	a
      004269 CA               [12] 1086 	xch	a,r2
      00426A 13               [12] 1087 	rrc	a
      00426B CA               [12] 1088 	xch	a,r2
      00426C 24 C7            [12] 1089 	add	a,#0xc7
      00426E FB               [12] 1090 	mov	r3,a
      00426F 8F 01            [24] 1091 	mov	ar1,r7
      004271 89 00            [24] 1092 	mov	ar0,r1
      004273 79 00            [12] 1093 	mov	r1,#0x00
      004275 E8               [12] 1094 	mov	a,r0
      004276 2A               [12] 1095 	add	a, r2
      004277 FA               [12] 1096 	mov	r2,a
      004278 E9               [12] 1097 	mov	a,r1
      004279 3B               [12] 1098 	addc	a, r3
      00427A FB               [12] 1099 	mov	r3,a
      00427B 12 3B 28         [24] 1100 	lcall	_ak820_outline_0148
      00427E 12 3B 6B         [24] 1101 	lcall	_ak820_flash_read
      004281 AB 82            [24] 1102 	mov	r3, dpl
      004283 12 3B 1D         [24] 1103 	lcall	_ak820_outline_0137
      004286 EB               [12] 1104 	mov	a,r3
      004287 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004288 0F               [12] 1107 	inc	r7
      004289 BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00428C 90 05 6D         [24] 1110 	mov	dptr,#_cached_page
      00428F EC               [12] 1111 	mov	a,r4
      004290 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004291 D2 0A            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004293 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004296 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004297                       1129 _read_offset:
      004297 12 3A FE         [24] 1130 	lcall	_ak820_outline_0110
      00429A 90 05 90         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00429D 12 3B 03         [24] 1132 	lcall	_ak820_outline_0111
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      0042A0 90 05 90         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      0042A3 12 3A BD         [24] 1135 	lcall	_ak820_outline_0052
      0042A6 C3               [12] 1136 	clr	c
      0042A7 94 28            [12] 1137 	subb	a,#0x28
      0042A9 40 04            [24] 1138 	jc	00102$
      0042AB 75 82 00         [24] 1139 	mov	dpl, #0x00
      0042AE 22               [24] 1140 	ret
      0042AF                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0042AF 30 0A 34         [24] 1143 	jnb	_page_valid,00104$
      0042B2 8E 04            [24] 1144 	mov	ar4,r6
      0042B4 EF               [12] 1145 	mov	a,r7
      0042B5 A2 E7            [12] 1146 	mov	c,acc.7
      0042B7 CC               [12] 1147 	xch	a,r4
      0042B8 33               [12] 1148 	rlc	a
      0042B9 CC               [12] 1149 	xch	a,r4
      0042BA 33               [12] 1150 	rlc	a
      0042BB A2 E7            [12] 1151 	mov	c,acc.7
      0042BD CC               [12] 1152 	xch	a,r4
      0042BE 33               [12] 1153 	rlc	a
      0042BF CC               [12] 1154 	xch	a,r4
      0042C0 33               [12] 1155 	rlc	a
      0042C1 CC               [12] 1156 	xch	a,r4
      0042C2 54 03            [12] 1157 	anl	a,#0x03
      0042C4 FD               [12] 1158 	mov	r5,a
      0042C5 90 05 6D         [24] 1159 	mov	dptr,#_cached_page
      0042C8 E0               [24] 1160 	movx	a,@dptr
      0042C9 FA               [12] 1161 	mov	r2,a
      0042CA 7B 00            [12] 1162 	mov	r3,#0x00
      0042CC EC               [12] 1163 	mov	a,r4
      0042CD B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0042D0 ED               [12] 1165 	mov	a,r5
      0042D1 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042D4 74 3F            [12] 1168 	mov	a,#0x3f
      0042D6 5E               [12] 1169 	anl	a,r6
      0042D7 7D 00            [12] 1170 	mov	r5,#0x00
      0042D9 24 2D            [12] 1171 	add	a, #_page_data
      0042DB F5 82            [12] 1172 	mov	dpl,a
      0042DD ED               [12] 1173 	mov	a,r5
      0042DE 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0042E0 F5 83            [12] 1175 	mov	dph,a
      0042E2 E0               [24] 1176 	movx	a,@dptr
      0042E3 F5 82            [12] 1177 	mov	dpl,a
      0042E5 22               [24] 1178 	ret
      0042E6                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042E6 74 C7            [12] 1181 	mov	a,#0xc7
      0042E8 2F               [12] 1182 	add	a, r7
      0042E9 FF               [12] 1183 	mov	r7,a
      0042EA 12 3B 08         [24] 1184 	lcall	_ak820_outline_0120
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042ED 02 3B 6B         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0042F0                       1196 _eeprom_read_byte:
      0042F0 C0 07            [24] 1197 	push	ar7
      0042F2 C0 06            [24] 1198 	push	ar6
      0042F4 12 45 8F         [24] 1199 	lcall	_ak820_outline_0036
      0042F7 90 05 92         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042FA 12 3A 9B         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042FD 90 05 92         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004300 12 3A 70         [24] 1204 	lcall	_ak820_outline_0005
      004303 C0 06            [24] 1205 	push	ar6
      004305 C0 05            [24] 1206 	push	ar5
      004307 C0 04            [24] 1207 	push	ar4
      004309 C0 03            [24] 1208 	push	ar3
      00430B C0 02            [24] 1209 	push	ar2
      00430D C0 01            [24] 1210 	push	ar1
      00430F C0 00            [24] 1211 	push	ar0
      004311 12 42 97         [24] 1212 	lcall	_read_offset
      004314 AF 82            [24] 1213 	mov	r7, dpl
      004316 D0 00            [24] 1214 	pop	ar0
      004318 D0 01            [24] 1215 	pop	ar1
      00431A D0 02            [24] 1216 	pop	ar2
      00431C D0 03            [24] 1217 	pop	ar3
      00431E D0 04            [24] 1218 	pop	ar4
      004320 D0 05            [24] 1219 	pop	ar5
      004322 D0 06            [24] 1220 	pop	ar6
      004324 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004326 D0 06            [24] 1223 	pop	ar6
      004328 D0 07            [24] 1224 	pop	ar7
      00432A 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      00432B                       1239 _ak820_eeprom_read_block_xdata:
      00432B 12 3A FE         [24] 1240 	lcall	_ak820_outline_0110
      00432E 90 05 9A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004331 12 3B 03         [24] 1242 	lcall	_ak820_outline_0111
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004334 90 05 95         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004337 12 3A BD         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00433A 90 05 9A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00433D 12 3A D4         [24] 1248 	lcall	_ak820_outline_0061
      004340 90 05 9C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004343 12 3A DA         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004346 90 05 98         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004349 12 3A D4         [24] 1253 	lcall	_ak820_outline_0061
      00434C                       1254 00103$:
      00434C 8C 02            [24] 1255 	mov	ar2,r4
      00434E 8D 03            [24] 1256 	mov	ar3,r5
      004350 1C               [12] 1257 	dec	r4
      004351 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004354 1D               [12] 1259 	dec	r5
      004355                       1260 00130$:
      004355 EA               [12] 1261 	mov	a,r2
      004356 4B               [12] 1262 	orl	a,r3
      004357 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004359 8E 02            [24] 1265 	mov	ar2,r6
      00435B 8F 03            [24] 1266 	mov	ar3,r7
      00435D 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      00435F 2B               [12] 1268 	add	a,r3
      004360 50 17            [24] 1269 	jnc	00102$
      004362 90 05 9C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004365 12 45 C6         [24] 1271 	lcall	_ak820_outline_0106
      004368 12 3B 28         [24] 1272 	lcall	_ak820_outline_0148
      00436B E4               [12] 1273 	clr	a
      00436C F0               [24] 1274 	movx	@dptr,a
      00436D 90 05 9C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004370 04               [12] 1276 	inc	a
      004371 2A               [12] 1277 	add	a, r2
      004372 F0               [24] 1278 	movx	@dptr,a
      004373 E4               [12] 1279 	clr	a
      004374 3B               [12] 1280 	addc	a, r3
      004375 A3               [24] 1281 	inc	dptr
      004376 F0               [24] 1282 	movx	@dptr,a
      004377 80 D3            [24] 1283 	sjmp	00103$
      004379                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004379 90 05 9C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00437C 12 45 C6         [24] 1287 	lcall	_ak820_outline_0106
      00437F 12 3B 08         [24] 1288 	lcall	_ak820_outline_0120
      004382 C0 07            [24] 1289 	push	ar7
      004384 C0 06            [24] 1290 	push	ar6
      004386 C0 05            [24] 1291 	push	ar5
      004388 C0 04            [24] 1292 	push	ar4
      00438A C0 03            [24] 1293 	push	ar3
      00438C C0 02            [24] 1294 	push	ar2
      00438E 12 42 97         [24] 1295 	lcall	_read_offset
      004391 A9 82            [24] 1296 	mov	r1, dpl
      004393 D0 02            [24] 1297 	pop	ar2
      004395 D0 03            [24] 1298 	pop	ar3
      004397 D0 04            [24] 1299 	pop	ar4
      004399 D0 05            [24] 1300 	pop	ar5
      00439B D0 06            [24] 1301 	pop	ar6
      00439D D0 07            [24] 1302 	pop	ar7
      00439F 12 3B 28         [24] 1303 	lcall	_ak820_outline_0148
      0043A2 E9               [12] 1304 	mov	a,r1
      0043A3 F0               [24] 1305 	movx	@dptr,a
      0043A4 90 05 9C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0043A7 74 01            [12] 1307 	mov	a,#0x01
      0043A9 2A               [12] 1308 	add	a, r2
      0043AA F0               [24] 1309 	movx	@dptr,a
      0043AB E4               [12] 1310 	clr	a
      0043AC 3B               [12] 1311 	addc	a, r3
      0043AD A3               [24] 1312 	inc	dptr
      0043AE F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0043AF 0E               [12] 1315 	inc	r6
      0043B0 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      0043B3 0F               [12] 1317 	inc	r7
      0043B4 80 96            [24] 1318 	sjmp	00103$
      0043B6                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0043B6 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      0043B7                       1337 _ak820_eeprom_write_block_xdata:
      0043B7 12 3A FE         [24] 1338 	lcall	_ak820_outline_0110
      0043BA 90 05 A3         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043BD 12 3B 03         [24] 1340 	lcall	_ak820_outline_0111
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043C0 90 05 9E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0043C3 12 3A BD         [24] 1343 	lcall	_ak820_outline_0052
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0043C6 90 05 A3         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043C9 12 3A D4         [24] 1346 	lcall	_ak820_outline_0061
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0043CC 8E 02            [24] 1348 	mov	ar2,r6
      0043CE 8F 03            [24] 1349 	mov	ar3,r7
      0043D0 C3               [12] 1350 	clr	c
      0043D1 E4               [12] 1351 	clr	a
      0043D2 9A               [12] 1352 	subb	a,r2
      0043D3 74 28            [12] 1353 	mov	a,#0x28
      0043D5 9B               [12] 1354 	subb	a,r3
      0043D6 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0043D8 E4               [12] 1357 	clr	a
      0043D9 C3               [12] 1358 	clr	c
      0043DA 9E               [12] 1359 	subb	a,r6
      0043DB FA               [12] 1360 	mov	r2,a
      0043DC 74 28            [12] 1361 	mov	a,#0x28
      0043DE 9F               [12] 1362 	subb	a,r7
      0043DF FB               [12] 1363 	mov	r3,a
      0043E0 90 05 A1         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043E3 12 3A F8         [24] 1365 	lcall	_ak820_outline_0105
      0043E6 C3               [12] 1366 	clr	c
      0043E7 EA               [12] 1367 	mov	a,r2
      0043E8 98               [12] 1368 	subb	a,r0
      0043E9 EB               [12] 1369 	mov	a,r3
      0043EA 99               [12] 1370 	subb	a,r1
      0043EB 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0043ED                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043ED 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043F0 02 3D FF         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043F3                       1379 00125$:
      0043F3 90 05 A1         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043F6 12 45 C6         [24] 1381 	lcall	_ak820_outline_0106
      0043F9                       1382 00108$:
      0043F9 8A 00            [24] 1383 	mov	ar0,r2
      0043FB 8B 01            [24] 1384 	mov	ar1,r3
      0043FD 1A               [12] 1385 	dec	r2
      0043FE BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004401 1B               [12] 1387 	dec	r3
      004402                       1388 00159$:
      004402 E8               [12] 1389 	mov	a,r0
      004403 49               [12] 1390 	orl	a,r1
      004404 70 03            [24] 1391 	jnz	00160$
      004406 02 44 90         [24] 1392 	ljmp	00110$
      004409                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004409 C0 02            [24] 1395 	push	ar2
      00440B C0 03            [24] 1396 	push	ar3
      00440D 12 45 C0         [24] 1397 	lcall	_ak820_outline_0097
      004410 F9               [12] 1398 	mov	r1,a
      004411 A3               [24] 1399 	inc	dptr
      004412 12 45 EF         [24] 1400 	lcall	_ak820_outline_0155
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004415 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004417 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004419 A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00441B E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00441D A2 E7            [12] 1406 	mov	c,acc.7
      00441F C8               [12] 1407 	xch	a,r0
      004420 33               [12] 1408 	rlc	a
      004421 C8               [12] 1409 	xch	a,r0
      004422 33               [12] 1410 	rlc	a
      004423 A2 E7            [12] 1411 	mov	c,acc.7
      004425 C8               [12] 1412 	xch	a,r0
      004426 33               [12] 1413 	rlc	a
      004427 C8               [12] 1414 	xch	a,r0
      004428 33               [12] 1415 	rlc	a
      004429 C8               [12] 1416 	xch	a,r0
      00442A 54 03            [12] 1417 	anl	a,#0x03
      00442C FB               [12] 1418 	mov	r3,a
      00442D 88 82            [24] 1419 	mov	dpl, r0
      00442F C0 07            [24] 1420 	push	ar7
      004431 C0 06            [24] 1421 	push	ar6
      004433 C0 05            [24] 1422 	push	ar5
      004435 C0 04            [24] 1423 	push	ar4
      004437 C0 03            [24] 1424 	push	ar3
      004439 C0 02            [24] 1425 	push	ar2
      00443B C0 01            [24] 1426 	push	ar1
      00443D 12 42 25         [24] 1427 	lcall	_load_page
      004440 E5 82            [12] 1428 	mov	a, dpl
      004442 D0 01            [24] 1429 	pop	ar1
      004444 D0 02            [24] 1430 	pop	ar2
      004446 D0 03            [24] 1431 	pop	ar3
      004448 D0 04            [24] 1432 	pop	ar4
      00444A D0 05            [24] 1433 	pop	ar5
      00444C D0 06            [24] 1434 	pop	ar6
      00444E D0 07            [24] 1435 	pop	ar7
      004450 D0 03            [24] 1436 	pop	ar3
      004452 D0 02            [24] 1437 	pop	ar2
      004454 70 01            [24] 1438 	jnz	00105$
      004456 22               [24] 1439 	ret
      004457                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004457 C0 06            [24] 1442 	push	ar6
      004459 C0 07            [24] 1443 	push	ar7
      00445B 74 3F            [12] 1444 	mov	a,#0x3f
      00445D 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00445F 7F 00            [12] 1446 	mov	r7,#0x00
      004461 24 2D            [12] 1447 	add	a, #_page_data
      004463 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004465 EF               [12] 1449 	mov	a,r7
      004466 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      004468 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00446A 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00446D 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004470 E0               [24] 1454 	movx	a,@dptr
      004471 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004474 D0 07            [24] 1456 	pop	ar7
      004476 D0 06            [24] 1457 	pop	ar6
      004478 80 0E            [24] 1458 	sjmp	00107$
      00447A                       1459 00162$:
      00447A D0 07            [24] 1460 	pop	ar7
      00447C D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00447E 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004481 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004484 E9               [12] 1465 	mov	a,r1
      004485 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004486 D2 0B            [12] 1469 	setb	_page_dirty
      004488                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004488 0E               [12] 1472 	inc	r6
      004489 BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00448C 0F               [12] 1474 	inc	r7
      00448D                       1475 00163$:
      00448D 02 43 F9         [24] 1476 	ljmp	00108$
      004490                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004490 90 05 6E         [24] 1479 	mov	dptr,#_batch_depth
      004493 E0               [24] 1480 	movx	a,@dptr
      004494 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004496 02 40 A5         [24] 1483 	ljmp	_ak820_nvm_flush
      004499                       1484 00113$:
      004499 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      00449A                       1503 _ak820_eeprom_update_block_xdata:
      00449A 12 3A FE         [24] 1504 	lcall	_ak820_outline_0110
      00449D 90 05 AA         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0044A0 12 3B 03         [24] 1506 	lcall	_ak820_outline_0111
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0044A3 90 05 AA         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0044A6 12 3A BD         [24] 1509 	lcall	_ak820_outline_0052
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0044A9 90 05 A5         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0044AC E0               [24] 1512 	movx	a,@dptr
      0044AD F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0044AF A3               [24] 1514 	inc	dptr
      0044B0 E0               [24] 1515 	movx	a,@dptr
      0044B1 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0044B3 A3               [24] 1517 	inc	dptr
      0044B4 E0               [24] 1518 	movx	a,@dptr
      0044B5 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0044B7 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044B9 AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044BB E4               [12] 1523 	clr	a
      0044BC F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0044BE F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0044C0                       1526 00105$:
      0044C0 90 05 A8         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0044C3 E0               [24] 1528 	movx	a,@dptr
      0044C4 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0044C6 A3               [24] 1530 	inc	dptr
      0044C7 E0               [24] 1531 	movx	a,@dptr
      0044C8 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0044CA C3               [12] 1533 	clr	c
      0044CB E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044CD 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044CF E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044D1 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044D3 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044D5 89 00            [24] 1540 	mov	ar0,r1
      0044D7 8A 05            [24] 1541 	mov	ar5,r2
      0044D9 E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044DB 28               [12] 1543 	add	a, r0
      0044DC F8               [12] 1544 	mov	r0,a
      0044DD E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044DF 3D               [12] 1546 	addc	a, r5
      0044E0 FD               [12] 1547 	mov	r5,a
      0044E1 88 82            [24] 1548 	mov	dpl, r0
      0044E3 8D 83            [24] 1549 	mov	dph, r5
      0044E5 C0 07            [24] 1550 	push	ar7
      0044E7 C0 06            [24] 1551 	push	ar6
      0044E9 C0 02            [24] 1552 	push	ar2
      0044EB C0 01            [24] 1553 	push	ar1
      0044ED 12 42 97         [24] 1554 	lcall	_read_offset
      0044F0 AD 82            [24] 1555 	mov	r5, dpl
      0044F2 D0 01            [24] 1556 	pop	ar1
      0044F4 D0 02            [24] 1557 	pop	ar2
      0044F6 D0 06            [24] 1558 	pop	ar6
      0044F8 D0 07            [24] 1559 	pop	ar7
      0044FA E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044FC 2E               [12] 1561 	add	a, r6
      0044FD F5 82            [12] 1562 	mov	dpl,a
      0044FF E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004501 3F               [12] 1564 	addc	a, r7
      004502 F5 83            [12] 1565 	mov	dph,a
      004504 E0               [24] 1566 	movx	a,@dptr
      004505 FC               [12] 1567 	mov	r4,a
      004506 ED               [12] 1568 	mov	a,r5
      004507 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      00450A 80 27            [24] 1570 	sjmp	00106$
      00450C                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00450C 90 05 AA         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00450F E0               [24] 1574 	movx	a,@dptr
      004510 F8               [12] 1575 	mov	r0,a
      004511 A3               [24] 1576 	inc	dptr
      004512 E0               [24] 1577 	movx	a,@dptr
      004513 FD               [12] 1578 	mov	r5,a
      004514 90 05 9E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004517 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004519 F0               [24] 1581 	movx	@dptr,a
      00451A E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00451C A3               [24] 1583 	inc	dptr
      00451D F0               [24] 1584 	movx	@dptr,a
      00451E E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004520 A3               [24] 1586 	inc	dptr
      004521 F0               [24] 1587 	movx	@dptr,a
      004522 90 05 A1         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004525 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004527 F0               [24] 1590 	movx	@dptr,a
      004528 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00452A A3               [24] 1592 	inc	dptr
      00452B F0               [24] 1593 	movx	@dptr,a
      00452C 88 82            [24] 1594 	mov	dpl, r0
      00452E 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004530 02 43 B7         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004533                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004533 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004535 E4               [12] 1601 	clr	a
      004536 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004539 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00453B 80 83            [24] 1604 	sjmp	00105$
      00453D                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00453D 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      00453E                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00453E 12 40 A5         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004541 7F 00            [12] 1622 	mov	r7,#0x00
      004543                       1623 00111$:
      004543 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      004546 22               [24] 1625 	ret
      004547                       1626 00165$:
      004547 20 0C 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00454A 8F 82            [24] 1629 	mov	dpl, r7
      00454C C0 07            [24] 1630 	push	ar7
      00454E 12 42 25         [24] 1631 	lcall	_load_page
      004551 E5 82            [12] 1632 	mov	a, dpl
      004553 D0 07            [24] 1633 	pop	ar7
      004555 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004557 22               [24] 1636 	ret
      004558                       1637 00126$:
      004558 7E 00            [12] 1638 	mov	r6,#0x00
      00455A                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00455A EE               [12] 1641 	mov	a,r6
      00455B 24 2D            [12] 1642 	add	a, #_page_data
      00455D FC               [12] 1643 	mov	r4,a
      00455E E4               [12] 1644 	clr	a
      00455F 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004561 FD               [12] 1646 	mov	r5,a
      004562 12 45 C0         [24] 1647 	lcall	_ak820_outline_0097
      004565 60 07            [24] 1648 	jz	00108$
      004567 12 3B 13         [24] 1649 	lcall	_ak820_outline_0126
      00456A E4               [12] 1650 	clr	a
      00456B F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      00456C D2 0B            [12] 1653 	setb	_page_dirty
      00456E                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00456E 0E               [12] 1656 	inc	r6
      00456F BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004572 C0 07            [24] 1659 	push	ar7
      004574 12 40 A5         [24] 1660 	lcall	_ak820_nvm_flush
      004577 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004579 0F               [12] 1663 	inc	r7
      00457A 80 C7            [24] 1664 	sjmp	00111$
      00457C                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00457C 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0031
                                   1679 	.globl _ak820_outline_0036
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0053
                                   1683 	.globl _ak820_outline_0061
                                   1684 	.globl _ak820_outline_0065
                                   1685 	.globl _ak820_outline_0072
                                   1686 	.globl _ak820_outline_0079
                                   1687 	.globl _ak820_outline_0080
                                   1688 	.globl _ak820_outline_0086
                                   1689 	.globl _ak820_outline_0097
                                   1690 	.globl _ak820_outline_0105
                                   1691 	.globl _ak820_outline_0106
                                   1692 	.globl _ak820_outline_0108
                                   1693 	.globl _ak820_outline_0110
                                   1694 	.globl _ak820_outline_0111
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0124
                                   1697 	.globl _ak820_outline_0125
                                   1698 	.globl _ak820_outline_0126
                                   1699 	.globl _ak820_outline_0127
                                   1700 	.globl _ak820_outline_0137
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0141
                                   1703 	.globl _ak820_outline_0147
                                   1704 	.globl _ak820_outline_0148
                                   1705 	.globl _ak820_outline_0155
                                   1706 	.globl _ak820_outline_0163
                                   1707 	.globl _ak820_outline_0165
                                   1708 	.globl _ak820_outline_0167
                                   1709 	.globl _ak820_outline_0185
                                   1710 	.globl _ak820_outline_0186
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0011
      00457D                       1714 _ak820_outline_0011:
      00457D 8E 82            [24] 1715 	mov	dpl,r6
      00457F 8F 83            [24] 1716 	mov	dph,r7
      004581 A3               [24] 1717 	inc	dptr
      004582 A3               [24] 1718 	inc	dptr
      004583 A3               [24] 1719 	inc	dptr
      004584 A3               [24] 1720 	inc	dptr
      004585 A3               [24] 1721 	inc	dptr
      004586 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0031
      004587                       1726 _ak820_outline_0031:
      004587 F0               [24] 1727 	movx	@dptr,a
      004588 8E 82            [24] 1728 	mov	dpl,r6
      00458A 8F 83            [24] 1729 	mov	dph,r7
      00458C A3               [24] 1730 	inc	dptr
      00458D A3               [24] 1731 	inc	dptr
      00458E 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      00458F                       1736 _ak820_outline_0036:
      00458F AF F0            [24] 1737 	mov	r7,b
      004591 AE 83            [24] 1738 	mov	r6,dph
      004593 E5 82            [12] 1739 	mov	a,dpl
      004595 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      004596                       1744 _ak820_outline_0043:
      004596 EF               [12] 1745 	mov	a,r7
      004597 24 85            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004599 F5 82            [12] 1747 	mov	dpl,a
      00459B E4               [12] 1748 	clr	a
      00459C 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00459E F5 83            [12] 1750 	mov	dph,a
      0045A0 E0               [24] 1751 	movx	a,@dptr
      0045A1 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      0045A2                       1756 _ak820_outline_0053:
      0045A2 8F 06            [24] 1757 	mov	ar6,r7
      0045A4 7D 00            [12] 1758 	mov	r5,#0x00
      0045A6 74 40            [12] 1759 	mov	a,#0x40
      0045A8 2E               [12] 1760 	add	a,r6
      0045A9 FE               [12] 1761 	mov	r6,a
      0045AA 74 EF            [12] 1762 	mov	a,#0xef
      0045AC 3D               [12] 1763 	addc	a,r5
      0045AD FD               [12] 1764 	mov	r5,a
      0045AE 8E 82            [24] 1765 	mov	dpl,r6
      0045B0 8D 83            [24] 1766 	mov	dph,r5
      0045B2 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0065
      0045B3                       1771 _ak820_outline_0065:
      0045B3 8D 82            [24] 1772 	mov	dpl,r5
      0045B5 8E 83            [24] 1773 	mov	dph,r6
      0045B7 EC               [12] 1774 	mov	a,r4
      0045B8 F0               [24] 1775 	movx	@dptr,a
      0045B9 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0079
      0045BA                       1780 _ak820_outline_0079:
      0045BA F0               [24] 1781 	movx	@dptr,a
      0045BB 8E 82            [24] 1782 	mov	dpl,r6
      0045BD 8F 83            [24] 1783 	mov	dph,r7
      0045BF 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0097
      0045C0                       1788 _ak820_outline_0097:
      0045C0 8C 82            [24] 1789 	mov	dpl,r4
      0045C2 8D 83            [24] 1790 	mov	dph,r5
      0045C4 E0               [24] 1791 	movx	a,@dptr
      0045C5 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0106
      0045C6                       1796 _ak820_outline_0106:
      0045C6 E0               [24] 1797 	movx	a,@dptr
      0045C7 FA               [12] 1798 	mov	r2,a
      0045C8 A3               [24] 1799 	inc	dptr
      0045C9 E0               [24] 1800 	movx	a,@dptr
      0045CA FB               [12] 1801 	mov	r3,a
      0045CB 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0108
      0045CC                       1806 _ak820_outline_0108:
      0045CC EF               [12] 1807 	mov	a,r7
      0045CD 24 2D            [12] 1808 	add	a,#_page_data
      0045CF F5 82            [12] 1809 	mov	dpl,a
      0045D1 E4               [12] 1810 	clr	a
      0045D2 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0045D4 F5 83            [12] 1812 	mov	dph,a
      0045D6 E0               [24] 1813 	movx	a,@dptr
      0045D7 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0127
      0045D8                       1818 _ak820_outline_0127:
      0045D8 AE 82            [24] 1819 	mov	r6,dpl
      0045DA AF 83            [24] 1820 	mov	r7,dph
      0045DC 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0139
      0045DD                       1825 _ak820_outline_0139:
      0045DD 2E               [12] 1826 	add	a,r6
      0045DE FE               [12] 1827 	mov	r6,a
      0045DF E4               [12] 1828 	clr	a
      0045E0 3F               [12] 1829 	addc	a,r7
      0045E1 FF               [12] 1830 	mov	r7,a
      0045E2 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0141
      0045E3                       1835 _ak820_outline_0141:
      0045E3 ED               [12] 1836 	mov	a,r5
      0045E4 F0               [24] 1837 	movx	@dptr,a
      0045E5 EE               [12] 1838 	mov	a,r6
      0045E6 A3               [24] 1839 	inc	dptr
      0045E7 F0               [24] 1840 	movx	@dptr,a
      0045E8 22               [24] 1841 	ret
                                   1842 
                                   1843 	.area CSEG (CODE)
                                   1844 ; function ak820_outline_0147
      0045E9                       1845 _ak820_outline_0147:
      0045E9 42 05            [12] 1846 	orl	ar5,a
      0045EB EA               [12] 1847 	mov	a,r2
      0045EC 42 04            [12] 1848 	orl	ar4,a
      0045EE 22               [24] 1849 	ret
                                   1850 
                                   1851 	.area CSEG (CODE)
                                   1852 ; function ak820_outline_0155
      0045EF                       1853 _ak820_outline_0155:
      0045EF AC 82            [24] 1854 	mov	r4,dpl
      0045F1 AD 83            [24] 1855 	mov	r5,dph
      0045F3 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0165
      0045F4                       1860 _ak820_outline_0165:
      0045F4 8F 82            [24] 1861 	mov	dpl,r7
      0045F6 8E 83            [24] 1862 	mov	dph,r6
      0045F8 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0167
      0045F9                       1867 _ak820_outline_0167:
      0045F9 2E               [12] 1868 	add	a,r6
      0045FA FC               [12] 1869 	mov	r4,a
      0045FB E4               [12] 1870 	clr	a
      0045FC 3F               [12] 1871 	addc	a,r7
      0045FD FD               [12] 1872 	mov	r5,a
      0045FE 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0185
      0045FF                       1877 _ak820_outline_0185:
      0045FF 89 82            [24] 1878 	mov	dpl,r1
      004601 8A 83            [24] 1879 	mov	dph,r2
      004603 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0186
      004604                       1884 _ak820_outline_0186:
      004604 8C 82            [24] 1885 	mov	dpl,r4
      004606 8B 83            [24] 1886 	mov	dph,r3
      004608 22               [24] 1887 	ret
