                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_mousekey
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_usb_try_send
                                     12 	.globl _timer_read
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _mousekey_on
                                    257 	.globl _mousekey_off
                                    258 	.globl _mousekey_send
                                    259 	.globl _mousekey_task
                                    260 	.globl _mousekey_clear
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      0006BE                        547 _directions:
      0006BE                        548 	.ds 1
      0006BF                        549 _immediate:
      0006BF                        550 	.ds 1
      0006C0                        551 _buttons:
      0006C0                        552 	.ds 1
      0006C1                        553 _accepted_buttons:
      0006C1                        554 	.ds 1
      0006C2                        555 _cursor_time:
      0006C2                        556 	.ds 2
      0006C4                        557 _wheel_time:
      0006C4                        558 	.ds 2
      0006C6                        559 _mouse_report:
      0006C6                        560 	.ds 6
      0006CC                        561 _direction_bit_code_10000_129:
      0006CC                        562 	.ds 1
      0006CD                        563 _mousekey_on_code_10000_133:
      0006CD                        564 	.ds 1
      0006CE                        565 _mousekey_off_code_10000_140:
      0006CE                        566 	.ds 1
      0006CF                        567 _axis_PARM_2:
      0006CF                        568 	.ds 1
      0006D0                        569 _axis_PARM_3:
      0006D0                        570 	.ds 1
      0006D1                        571 _axis_selected_10000_143:
      0006D1                        572 	.ds 1
      0006D2                        573 _mousekey_send_selected_10000_149:
      0006D2                        574 	.ds 1
                                    575 ;--------------------------------------------------------
                                    576 ; absolute external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area XABS    (ABS,XDATA)
                                    579 ;--------------------------------------------------------
                                    580 ; initialized external ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area XISEG   (XDATA)
                                    583 	.area HOME    (CODE)
                                    584 	.area GSINIT0 (CODE)
                                    585 	.area GSINIT1 (CODE)
                                    586 	.area GSINIT2 (CODE)
                                    587 	.area GSINIT3 (CODE)
                                    588 	.area GSINIT4 (CODE)
                                    589 	.area GSINIT5 (CODE)
                                    590 	.area GSINIT  (CODE)
                                    591 	.area GSFINAL (CODE)
                                    592 	.area CSEG    (CODE)
                                    593 ;--------------------------------------------------------
                                    594 ; global & static initialisations
                                    595 ;--------------------------------------------------------
                                    596 	.area HOME    (CODE)
                                    597 	.area GSINIT  (CODE)
                                    598 	.area GSFINAL (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 ;--------------------------------------------------------
                                    601 ; Home
                                    602 ;--------------------------------------------------------
                                    603 	.area HOME    (CODE)
                                    604 	.area HOME    (CODE)
                                    605 ;--------------------------------------------------------
                                    606 ; code
                                    607 ;--------------------------------------------------------
                                    608 	.area CSEG    (CODE)
                                    609 ;------------------------------------------------------------
                                    610 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    611 ;------------------------------------------------------------
                                    612 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    613 ;------------------------------------------------------------
                                    614 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    615 ;	-----------------------------------------
                           000007   616 	ar7 = 0x07
                           000006   617 	ar6 = 0x06
                           000005   618 	ar5 = 0x05
                           000004   619 	ar4 = 0x04
                           000003   620 	ar3 = 0x03
                           000002   621 	ar2 = 0x02
                           000001   622 	ar1 = 0x01
                           000000   623 	ar0 = 0x00
                                    624 ;	 function direction_bit
                                    625 ;	-----------------------------------------
      0051E8                        626 _direction_bit:
      0051E8 E5 82            [12]  627 	mov	a,dpl
      0051EA 90 06 CC         [24]  628 	mov	dptr,#_direction_bit_code_10000_129
      0051ED F0               [24]  629 	movx	@dptr,a
                                    630 ;	keyboards/ajazz/ak820/ak820_mousekey.c:24: if (code >= KC_MS_UP && code <= KC_MS_RIGHT) return (uint8_t)(1u << (code - KC_MS_UP));
      0051EE E0               [24]  631 	movx	a,@dptr
      0051EF FF               [12]  632 	mov	r7,a
      0051F0 BF CD 00         [24]  633 	cjne	r7,#0xcd,00137$
      0051F3                        634 00137$:
      0051F3 40 18            [24]  635 	jc	00102$
      0051F5 EF               [12]  636 	mov	a,r7
      0051F6 24 2F            [12]  637 	add	a,#0xff - 0xd0
      0051F8 40 13            [24]  638 	jc	00102$
                                    639 ;	free result
      0051FA EF               [12]  640 	mov	a,r7
      0051FB 24 33            [12]  641 	add	a,#0x33
      0051FD F5 F0            [12]  642 	mov	b,a
      0051FF 05 F0            [12]  643 	inc	b
      005201 74 01            [12]  644 	mov	a,#0x01
      005203 80 02            [24]  645 	sjmp	00141$
      005205                        646 00140$:
      005205 25 E0            [12]  647 	add	a,acc
      005207                        648 00141$:
      005207 D5 F0 FB         [24]  649 	djnz	b,00140$
      00520A F5 82            [12]  650 	mov	dpl,a
      00520C 22               [24]  651 	ret
      00520D                        652 00102$:
                                    653 ;	keyboards/ajazz/ak820/ak820_mousekey.c:25: if (code >= KC_MS_WH_UP && code <= KC_MS_WH_RIGHT) return (uint8_t)(0x10u << (code - KC_MS_WH_UP));
      00520D 90 06 CC         [24]  654 	mov	dptr,#_direction_bit_code_10000_129
      005210 E0               [24]  655 	movx	a,@dptr
      005211 FF               [12]  656 	mov	r7,a
      005212 BF D9 00         [24]  657 	cjne	r7,#0xd9,00142$
      005215                        658 00142$:
      005215 40 18            [24]  659 	jc	00105$
      005217 EF               [12]  660 	mov	a,r7
      005218 24 23            [12]  661 	add	a,#0xff - 0xdc
      00521A 40 13            [24]  662 	jc	00105$
                                    663 ;	free result
      00521C EF               [12]  664 	mov	a,r7
      00521D 24 27            [12]  665 	add	a,#0x27
      00521F F5 F0            [12]  666 	mov	b,a
      005221 05 F0            [12]  667 	inc	b
      005223 74 10            [12]  668 	mov	a,#0x10
      005225 80 02            [24]  669 	sjmp	00146$
      005227                        670 00145$:
      005227 25 E0            [12]  671 	add	a,acc
      005229                        672 00146$:
      005229 D5 F0 FB         [24]  673 	djnz	b,00145$
      00522C F5 82            [12]  674 	mov	dpl,a
      00522E 22               [24]  675 	ret
      00522F                        676 00105$:
                                    677 ;	keyboards/ajazz/ak820/ak820_mousekey.c:26: return 0;
      00522F 75 82 00         [24]  678 	mov	dpl, #0x00
                                    679 ;	keyboards/ajazz/ak820/ak820_mousekey.c:27: }
      005232 22               [24]  680 	ret
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'mousekey_on'
                                    683 ;------------------------------------------------------------
                                    684 ;code          Allocated with name '_mousekey_on_code_10000_133'
                                    685 ;bit           Allocated with name '_mousekey_on_bit_10000_134'
                                    686 ;------------------------------------------------------------
                                    687 ;	keyboards/ajazz/ak820/ak820_mousekey.c:29: void mousekey_on(uint8_t code) {
                                    688 ;	-----------------------------------------
                                    689 ;	 function mousekey_on
                                    690 ;	-----------------------------------------
      005233                        691 _mousekey_on:
      005233 E5 82            [12]  692 	mov	a,dpl
      005235 90 06 CD         [24]  693 	mov	dptr,#_mousekey_on_code_10000_133
      005238 F0               [24]  694 	movx	@dptr,a
                                    695 ;	keyboards/ajazz/ak820/ak820_mousekey.c:30: uint8_t bit = direction_bit(code);
      005239 E0               [24]  696 	movx	a,@dptr
      00523A F5 82            [12]  697 	mov	dpl,a
      00523C 12 51 E8         [24]  698 	lcall	_direction_bit
                                    699 ;	keyboards/ajazz/ak820/ak820_mousekey.c:31: if (bit && !(directions & bit)) {
      00523F E5 82            [12]  700 	mov	a,dpl
      005241 FF               [12]  701 	mov	r7,a
      005242 60 3C            [24]  702 	jz	00108$
      005244 90 06 BE         [24]  703 	mov	dptr,#_directions
      005247 E0               [24]  704 	movx	a,@dptr
      005248 FE               [12]  705 	mov	r6,a
      005249 EF               [12]  706 	mov	a,r7
      00524A 5E               [12]  707 	anl	a,r6
      00524B 70 33            [24]  708 	jnz	00108$
                                    709 ;	keyboards/ajazz/ak820/ak820_mousekey.c:32: immediate |= bit;
      00524D 90 06 BF         [24]  710 	mov	dptr,#_immediate
      005250 E0               [24]  711 	movx	a,@dptr
      005251 4F               [12]  712 	orl	a,r7
      005252 F0               [24]  713 	movx	@dptr,a
                                    714 ;	keyboards/ajazz/ak820/ak820_mousekey.c:33: directions |= bit;
      005253 90 06 BE         [24]  715 	mov	dptr,#_directions
      005256 EF               [12]  716 	mov	a,r7
      005257 4E               [12]  717 	orl	a,r6
      005258 F0               [24]  718 	movx	@dptr,a
                                    719 ;	keyboards/ajazz/ak820/ak820_mousekey.c:34: if (bit & 0x0f) cursor_time = timer_read();
      005259 EF               [12]  720 	mov	a,r7
      00525A 54 0F            [12]  721 	anl	a,#0x0f
      00525C 60 11            [24]  722 	jz	00102$
      00525E 12 4B B2         [24]  723 	lcall	_timer_read
      005261 E5 82            [12]  724 	mov	a, dpl
      005263 85 83 F0         [24]  725 	mov	b, dph
      005266 90 06 C2         [24]  726 	mov	dptr,#_cursor_time
      005269 F0               [24]  727 	movx	@dptr,a
      00526A E5 F0            [12]  728 	mov	a,b
      00526C A3               [24]  729 	inc	dptr
      00526D F0               [24]  730 	movx	@dptr,a
      00526E 22               [24]  731 	ret
      00526F                        732 00102$:
                                    733 ;	keyboards/ajazz/ak820/ak820_mousekey.c:35: else wheel_time = timer_read();
      00526F 12 4B B2         [24]  734 	lcall	_timer_read
      005272 E5 82            [12]  735 	mov	a, dpl
      005274 85 83 F0         [24]  736 	mov	b, dph
      005277 90 06 C4         [24]  737 	mov	dptr,#_wheel_time
      00527A F0               [24]  738 	movx	@dptr,a
      00527B E5 F0            [12]  739 	mov	a,b
      00527D A3               [24]  740 	inc	dptr
      00527E F0               [24]  741 	movx	@dptr,a
      00527F 22               [24]  742 	ret
      005280                        743 00108$:
                                    744 ;	keyboards/ajazz/ak820/ak820_mousekey.c:36: } else if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) {
      005280 90 06 CD         [24]  745 	mov	dptr,#_mousekey_on_code_10000_133
      005283 E0               [24]  746 	movx	a,@dptr
      005284 FF               [12]  747 	mov	r7,a
      005285 BF D1 00         [24]  748 	cjne	r7,#0xd1,00151$
      005288                        749 00151$:
      005288 40 1C            [24]  750 	jc	00111$
      00528A EF               [12]  751 	mov	a,r7
      00528B 24 2A            [12]  752 	add	a,#0xff - 0xd5
      00528D 40 17            [24]  753 	jc	00111$
                                    754 ;	free result
                                    755 ;	keyboards/ajazz/ak820/ak820_mousekey.c:37: buttons |= (uint8_t)(1u << (code - KC_MS_BTN1));
      00528F EF               [12]  756 	mov	a,r7
      005290 24 2F            [12]  757 	add	a,#0x2f
      005292 F5 F0            [12]  758 	mov	b,a
      005294 05 F0            [12]  759 	inc	b
      005296 74 01            [12]  760 	mov	a,#0x01
      005298 80 02            [24]  761 	sjmp	00155$
      00529A                        762 00154$:
      00529A 25 E0            [12]  763 	add	a,acc
      00529C                        764 00155$:
      00529C D5 F0 FB         [24]  765 	djnz	b,00154$
      00529F FF               [12]  766 	mov	r7,a
      0052A0 90 06 C0         [24]  767 	mov	dptr,#_buttons
      0052A3 E0               [24]  768 	movx	a,@dptr
      0052A4 4F               [12]  769 	orl	a,r7
      0052A5 F0               [24]  770 	movx	@dptr,a
      0052A6                        771 00111$:
                                    772 ;	keyboards/ajazz/ak820/ak820_mousekey.c:39: }
      0052A6 22               [24]  773 	ret
                                    774 ;------------------------------------------------------------
                                    775 ;Allocation info for local variables in function 'mousekey_off'
                                    776 ;------------------------------------------------------------
                                    777 ;code          Allocated with name '_mousekey_off_code_10000_140'
                                    778 ;bit           Allocated with name '_mousekey_off_bit_10000_141'
                                    779 ;------------------------------------------------------------
                                    780 ;	keyboards/ajazz/ak820/ak820_mousekey.c:41: void mousekey_off(uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function mousekey_off
                                    783 ;	-----------------------------------------
      0052A7                        784 _mousekey_off:
      0052A7 E5 82            [12]  785 	mov	a,dpl
      0052A9 90 06 CE         [24]  786 	mov	dptr,#_mousekey_off_code_10000_140
      0052AC F0               [24]  787 	movx	@dptr,a
                                    788 ;	keyboards/ajazz/ak820/ak820_mousekey.c:42: uint8_t bit = direction_bit(code);
      0052AD E0               [24]  789 	movx	a,@dptr
      0052AE FF               [12]  790 	mov	r7,a
      0052AF F5 82            [12]  791 	mov	dpl,a
      0052B1 C0 07            [24]  792 	push	ar7
      0052B3 12 51 E8         [24]  793 	lcall	_direction_bit
      0052B6 E5 82            [12]  794 	mov	a, dpl
      0052B8 D0 07            [24]  795 	pop	ar7
                                    796 ;	keyboards/ajazz/ak820/ak820_mousekey.c:43: directions &= (uint8_t)~bit;
      0052BA F4               [12]  797 	cpl	a
      0052BB FE               [12]  798 	mov	r6,a
      0052BC 90 06 BE         [24]  799 	mov	dptr,#_directions
      0052BF E0               [24]  800 	movx	a,@dptr
      0052C0 5E               [12]  801 	anl	a,r6
      0052C1 F0               [24]  802 	movx	@dptr,a
                                    803 ;	keyboards/ajazz/ak820/ak820_mousekey.c:44: immediate &= (uint8_t)~bit;
      0052C2 90 06 BF         [24]  804 	mov	dptr,#_immediate
      0052C5 E0               [24]  805 	movx	a,@dptr
      0052C6 5E               [12]  806 	anl	a,r6
      0052C7 F0               [24]  807 	movx	@dptr,a
                                    808 ;	keyboards/ajazz/ak820/ak820_mousekey.c:45: if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) buttons &= (uint8_t)~(1u << (code - KC_MS_BTN1));
      0052C8 BF D1 00         [24]  809 	cjne	r7,#0xd1,00120$
      0052CB                        810 00120$:
      0052CB 40 1D            [24]  811 	jc	00104$
      0052CD EF               [12]  812 	mov	a,r7
      0052CE 24 2A            [12]  813 	add	a,#0xff - 0xd5
      0052D0 40 18            [24]  814 	jc	00104$
                                    815 ;	free result
      0052D2 EF               [12]  816 	mov	a,r7
      0052D3 24 2F            [12]  817 	add	a,#0x2f
      0052D5 F5 F0            [12]  818 	mov	b,a
      0052D7 05 F0            [12]  819 	inc	b
      0052D9 74 01            [12]  820 	mov	a,#0x01
      0052DB 80 02            [24]  821 	sjmp	00124$
      0052DD                        822 00123$:
      0052DD 25 E0            [12]  823 	add	a,acc
      0052DF                        824 00124$:
      0052DF D5 F0 FB         [24]  825 	djnz	b,00123$
      0052E2 F4               [12]  826 	cpl	a
      0052E3 FF               [12]  827 	mov	r7,a
      0052E4 90 06 C0         [24]  828 	mov	dptr,#_buttons
      0052E7 E0               [24]  829 	movx	a,@dptr
      0052E8 5F               [12]  830 	anl	a,r7
      0052E9 F0               [24]  831 	movx	@dptr,a
      0052EA                        832 00104$:
                                    833 ;	keyboards/ajazz/ak820/ak820_mousekey.c:46: }
      0052EA 22               [24]  834 	ret
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'axis'
                                    837 ;------------------------------------------------------------
                                    838 ;negative      Allocated with name '_axis_PARM_2'
                                    839 ;positive      Allocated with name '_axis_PARM_3'
                                    840 ;selected      Allocated with name '_axis_selected_10000_143'
                                    841 ;------------------------------------------------------------
                                    842 ;	keyboards/ajazz/ak820/ak820_mousekey.c:49: static int8_t axis(uint8_t selected, uint8_t negative, uint8_t positive) {
                                    843 ;	-----------------------------------------
                                    844 ;	 function axis
                                    845 ;	-----------------------------------------
      0052EB                        846 _axis:
      0052EB E5 82            [12]  847 	mov	a,dpl
      0052ED 90 06 D1         [24]  848 	mov	dptr,#_axis_selected_10000_143
      0052F0 F0               [24]  849 	movx	@dptr,a
                                    850 ;	keyboards/ajazz/ak820/ak820_mousekey.c:50: if ((directions & (negative | positive)) == (negative | positive)) return 0;
      0052F1 90 06 D0         [24]  851 	mov	dptr,#_axis_PARM_3
      0052F4 E0               [24]  852 	movx	a,@dptr
      0052F5 FF               [12]  853 	mov	r7,a
      0052F6 90 06 CF         [24]  854 	mov	dptr,#_axis_PARM_2
      0052F9 E0               [24]  855 	movx	a,@dptr
      0052FA FE               [12]  856 	mov	r6,a
      0052FB 4F               [12]  857 	orl	a,r7
      0052FC FD               [12]  858 	mov	r5,a
      0052FD 90 06 BE         [24]  859 	mov	dptr,#_directions
      005300 E0               [24]  860 	movx	a,@dptr
      005301 5D               [12]  861 	anl	a,r5
      005302 B5 05 04         [24]  862 	cjne	a,ar5,00102$
      005305 75 82 00         [24]  863 	mov	dpl, #0x00
      005308 22               [24]  864 	ret
      005309                        865 00102$:
                                    866 ;	keyboards/ajazz/ak820/ak820_mousekey.c:51: if (selected & negative) return -1;
      005309 90 06 D1         [24]  867 	mov	dptr,#_axis_selected_10000_143
      00530C E0               [24]  868 	movx	a,@dptr
      00530D FD               [12]  869 	mov	r5,a
      00530E EE               [12]  870 	mov	a,r6
      00530F 5D               [12]  871 	anl	a,r5
      005310 60 04            [24]  872 	jz	00104$
      005312 75 82 FF         [24]  873 	mov	dpl, #0xff
      005315 22               [24]  874 	ret
      005316                        875 00104$:
                                    876 ;	keyboards/ajazz/ak820/ak820_mousekey.c:52: if (selected & positive) return 1;
      005316 EF               [12]  877 	mov	a,r7
      005317 5D               [12]  878 	anl	a,r5
      005318 60 04            [24]  879 	jz	00106$
      00531A 75 82 01         [24]  880 	mov	dpl, #0x01
      00531D 22               [24]  881 	ret
      00531E                        882 00106$:
                                    883 ;	keyboards/ajazz/ak820/ak820_mousekey.c:53: return 0;
      00531E 75 82 00         [24]  884 	mov	dpl, #0x00
                                    885 ;	keyboards/ajazz/ak820/ak820_mousekey.c:54: }
      005321 22               [24]  886 	ret
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'mousekey_send'
                                    889 ;------------------------------------------------------------
                                    890 ;selected      Allocated with name '_mousekey_send_selected_10000_149'
                                    891 ;------------------------------------------------------------
                                    892 ;	keyboards/ajazz/ak820/ak820_mousekey.c:56: void mousekey_send(void) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function mousekey_send
                                    895 ;	-----------------------------------------
      005322                        896 _mousekey_send:
                                    897 ;	keyboards/ajazz/ak820/ak820_mousekey.c:57: uint8_t selected = immediate;
      005322 90 06 BF         [24]  898 	mov	dptr,#_immediate
      005325 E0               [24]  899 	movx	a,@dptr
      005326 90 06 D2         [24]  900 	mov	dptr,#_mousekey_send_selected_10000_149
      005329 F0               [24]  901 	movx	@dptr,a
                                    902 ;	keyboards/ajazz/ak820/ak820_mousekey.c:58: immediate = 0; /* Relative movement never accumulates behind a busy endpoint. */
      00532A 90 06 BF         [24]  903 	mov	dptr,#_immediate
      00532D E4               [12]  904 	clr	a
      00532E F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_mousekey.c:60: mouse_report.report_id = REPORT_ID_MOUSE;
      00532F 90 06 C6         [24]  907 	mov	dptr,#_mouse_report
      005332 74 02            [12]  908 	mov	a,#0x02
      005334 F0               [24]  909 	movx	@dptr,a
                                    910 ;	keyboards/ajazz/ak820/ak820_mousekey.c:62: mouse_report.buttons = buttons;
      005335 90 06 C0         [24]  911 	mov	dptr,#_buttons
      005338 E0               [24]  912 	movx	a,@dptr
      005339 90 06 C7         [24]  913 	mov	dptr,#(_mouse_report + 0x0001)
      00533C F0               [24]  914 	movx	@dptr,a
                                    915 ;	keyboards/ajazz/ak820/ak820_mousekey.c:63: mouse_report.x = axis(selected, 4, 8) * 8;
      00533D 90 06 D2         [24]  916 	mov	dptr,#_mousekey_send_selected_10000_149
      005340 E0               [24]  917 	movx	a,@dptr
      005341 FF               [12]  918 	mov	r7,a
      005342 90 06 CF         [24]  919 	mov	dptr,#_axis_PARM_2
      005345 74 04            [12]  920 	mov	a,#0x04
      005347 F0               [24]  921 	movx	@dptr,a
      005348 90 06 D0         [24]  922 	mov	dptr,#_axis_PARM_3
      00534B 23               [12]  923 	rl	a
      00534C F0               [24]  924 	movx	@dptr,a
      00534D 8F 82            [24]  925 	mov	dpl, r7
      00534F C0 07            [24]  926 	push	ar7
      005351 12 52 EB         [24]  927 	lcall	_axis
      005354 AE 82            [24]  928 	mov	r6, dpl
      005356 D0 07            [24]  929 	pop	ar7
      005358 EE               [12]  930 	mov	a,r6
      005359 C4               [12]  931 	swap	a
      00535A 03               [12]  932 	rr	a
      00535B 54 F8            [12]  933 	anl	a,#0xf8
      00535D 90 06 C8         [24]  934 	mov	dptr,#(_mouse_report + 0x0002)
      005360 F0               [24]  935 	movx	@dptr,a
                                    936 ;	keyboards/ajazz/ak820/ak820_mousekey.c:64: mouse_report.y = axis(selected, 1, 2) * 8;
      005361 90 06 CF         [24]  937 	mov	dptr,#_axis_PARM_2
      005364 74 01            [12]  938 	mov	a,#0x01
      005366 F0               [24]  939 	movx	@dptr,a
      005367 90 06 D0         [24]  940 	mov	dptr,#_axis_PARM_3
      00536A 04               [12]  941 	inc	a
      00536B F0               [24]  942 	movx	@dptr,a
      00536C 8F 82            [24]  943 	mov	dpl, r7
      00536E C0 07            [24]  944 	push	ar7
      005370 12 52 EB         [24]  945 	lcall	_axis
      005373 AE 82            [24]  946 	mov	r6, dpl
      005375 D0 07            [24]  947 	pop	ar7
      005377 EE               [12]  948 	mov	a,r6
      005378 C4               [12]  949 	swap	a
      005379 03               [12]  950 	rr	a
      00537A 54 F8            [12]  951 	anl	a,#0xf8
      00537C 90 06 C9         [24]  952 	mov	dptr,#(_mouse_report + 0x0003)
      00537F F0               [24]  953 	movx	@dptr,a
                                    954 ;	keyboards/ajazz/ak820/ak820_mousekey.c:65: mouse_report.v = axis(selected, 0x20, 0x10);
      005380 90 06 CF         [24]  955 	mov	dptr,#_axis_PARM_2
      005383 74 20            [12]  956 	mov	a,#0x20
      005385 F0               [24]  957 	movx	@dptr,a
      005386 90 06 D0         [24]  958 	mov	dptr,#_axis_PARM_3
      005389 03               [12]  959 	rr	a
      00538A F0               [24]  960 	movx	@dptr,a
      00538B 8F 82            [24]  961 	mov	dpl, r7
      00538D C0 07            [24]  962 	push	ar7
      00538F 12 52 EB         [24]  963 	lcall	_axis
      005392 AE 82            [24]  964 	mov	r6, dpl
      005394 D0 07            [24]  965 	pop	ar7
      005396 90 06 CA         [24]  966 	mov	dptr,#(_mouse_report + 0x0004)
      005399 EE               [12]  967 	mov	a,r6
      00539A F0               [24]  968 	movx	@dptr,a
                                    969 ;	keyboards/ajazz/ak820/ak820_mousekey.c:66: mouse_report.h = axis(selected, 0x40, 0x80);
      00539B 90 06 CF         [24]  970 	mov	dptr,#_axis_PARM_2
      00539E 74 40            [12]  971 	mov	a,#0x40
      0053A0 F0               [24]  972 	movx	@dptr,a
      0053A1 90 06 D0         [24]  973 	mov	dptr,#_axis_PARM_3
      0053A4 23               [12]  974 	rl	a
      0053A5 F0               [24]  975 	movx	@dptr,a
      0053A6 8F 82            [24]  976 	mov	dpl, r7
      0053A8 12 52 EB         [24]  977 	lcall	_axis
      0053AB AF 82            [24]  978 	mov	r7, dpl
      0053AD 90 06 CB         [24]  979 	mov	dptr,#(_mouse_report + 0x0005)
      0053B0 EF               [12]  980 	mov	a,r7
      0053B1 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_mousekey.c:67: if (!(mouse_report.x || mouse_report.y || mouse_report.v || mouse_report.h || buttons != accepted_buttons)) return;
      0053B2 90 06 C8         [24]  983 	mov	dptr,#(_mouse_report + 0x0002)
      0053B5 E0               [24]  984 	movx	a,@dptr
      0053B6 70 21            [24]  985 	jnz	00102$
      0053B8 90 06 C9         [24]  986 	mov	dptr,#(_mouse_report + 0x0003)
      0053BB E0               [24]  987 	movx	a,@dptr
      0053BC 70 1B            [24]  988 	jnz	00102$
      0053BE 90 06 CA         [24]  989 	mov	dptr,#(_mouse_report + 0x0004)
      0053C1 E0               [24]  990 	movx	a,@dptr
      0053C2 70 15            [24]  991 	jnz	00102$
      0053C4 90 06 CB         [24]  992 	mov	dptr,#(_mouse_report + 0x0005)
      0053C7 E0               [24]  993 	movx	a,@dptr
      0053C8 70 0F            [24]  994 	jnz	00102$
      0053CA 90 06 C0         [24]  995 	mov	dptr,#_buttons
      0053CD E0               [24]  996 	movx	a,@dptr
      0053CE FF               [12]  997 	mov	r7,a
      0053CF 90 06 C1         [24]  998 	mov	dptr,#_accepted_buttons
      0053D2 E0               [24]  999 	movx	a,@dptr
      0053D3 FE               [12] 1000 	mov	r6,a
      0053D4 EF               [12] 1001 	mov	a,r7
      0053D5 B5 06 01         [24] 1002 	cjne	a,ar6,00102$
      0053D8 22               [24] 1003 	ret
      0053D9                       1004 00102$:
                                   1005 ;	keyboards/ajazz/ak820/ak820_mousekey.c:68: if (ak820_usb_try_send(MOUSE_IN_EPNUM, (const uint8_t __xdata *)&mouse_report, sizeof(mouse_report))) accepted_buttons = buttons;
      0053D9 90 08 04         [24] 1006 	mov	dptr,#_ak820_usb_try_send_PARM_2
      0053DC 74 C6            [12] 1007 	mov	a,#_mouse_report
      0053DE F0               [24] 1008 	movx	@dptr,a
      0053DF 74 06            [12] 1009 	mov	a,#(_mouse_report >> 8)
      0053E1 A3               [24] 1010 	inc	dptr
      0053E2 F0               [24] 1011 	movx	@dptr,a
      0053E3 90 08 06         [24] 1012 	mov	dptr,#_ak820_usb_try_send_PARM_3
      0053E6 74 06            [12] 1013 	mov	a,#0x06
      0053E8 F0               [24] 1014 	movx	@dptr,a
      0053E9 75 82 02         [24] 1015 	mov	dpl, #0x02
      0053EC 12 6E 00         [24] 1016 	lcall	_ak820_usb_try_send
      0053EF E5 82            [12] 1017 	mov	a, dpl
      0053F1 60 08            [24] 1018 	jz	00109$
      0053F3 90 06 C0         [24] 1019 	mov	dptr,#_buttons
      0053F6 E0               [24] 1020 	movx	a,@dptr
      0053F7 90 06 C1         [24] 1021 	mov	dptr,#_accepted_buttons
      0053FA F0               [24] 1022 	movx	@dptr,a
      0053FB                       1023 00109$:
                                   1024 ;	keyboards/ajazz/ak820/ak820_mousekey.c:69: }
      0053FB 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'mousekey_task'
                                   1028 ;------------------------------------------------------------
                                   1029 ;now           Allocated with name '_mousekey_task_now_10000_153'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_mousekey.c:71: void mousekey_task(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function mousekey_task
                                   1034 ;	-----------------------------------------
      0053FC                       1035 _mousekey_task:
                                   1036 ;	keyboards/ajazz/ak820/ak820_mousekey.c:72: uint16_t now = timer_read();
      0053FC 12 4B B2         [24] 1037 	lcall	_timer_read
      0053FF AE 82            [24] 1038 	mov	r6, dpl
      005401 AF 83            [24] 1039 	mov	r7, dph
                                   1040 ;	keyboards/ajazz/ak820/ak820_mousekey.c:73: if ((uint16_t)(now - cursor_time) >= 20) {
      005403 90 06 C2         [24] 1041 	mov	dptr,#_cursor_time
      005406 E0               [24] 1042 	movx	a,@dptr
      005407 FC               [12] 1043 	mov	r4,a
      005408 A3               [24] 1044 	inc	dptr
      005409 E0               [24] 1045 	movx	a,@dptr
      00540A FD               [12] 1046 	mov	r5,a
      00540B EE               [12] 1047 	mov	a,r6
      00540C C3               [12] 1048 	clr	c
      00540D 9C               [12] 1049 	subb	a,r4
      00540E FC               [12] 1050 	mov	r4,a
      00540F EF               [12] 1051 	mov	a,r7
      005410 9D               [12] 1052 	subb	a,r5
      005411 FD               [12] 1053 	mov	r5,a
      005412 C3               [12] 1054 	clr	c
      005413 EC               [12] 1055 	mov	a,r4
      005414 94 14            [12] 1056 	subb	a,#0x14
      005416 ED               [12] 1057 	mov	a,r5
      005417 94 00            [12] 1058 	subb	a,#0x00
      005419 40 15            [24] 1059 	jc	00102$
                                   1060 ;	keyboards/ajazz/ak820/ak820_mousekey.c:74: cursor_time = now;
      00541B 90 06 C2         [24] 1061 	mov	dptr,#_cursor_time
      00541E EE               [12] 1062 	mov	a,r6
      00541F F0               [24] 1063 	movx	@dptr,a
      005420 EF               [12] 1064 	mov	a,r7
      005421 A3               [24] 1065 	inc	dptr
      005422 F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	keyboards/ajazz/ak820/ak820_mousekey.c:75: immediate |= directions & 0x0f;
      005423 90 06 BE         [24] 1068 	mov	dptr,#_directions
      005426 E0               [24] 1069 	movx	a,@dptr
      005427 54 0F            [12] 1070 	anl	a,#0x0f
      005429 FD               [12] 1071 	mov	r5,a
      00542A 90 06 BF         [24] 1072 	mov	dptr,#_immediate
      00542D E0               [24] 1073 	movx	a,@dptr
      00542E 4D               [12] 1074 	orl	a,r5
      00542F F0               [24] 1075 	movx	@dptr,a
      005430                       1076 00102$:
                                   1077 ;	keyboards/ajazz/ak820/ak820_mousekey.c:77: if ((uint16_t)(now - wheel_time) >= 80) {
      005430 90 06 C4         [24] 1078 	mov	dptr,#_wheel_time
      005433 E0               [24] 1079 	movx	a,@dptr
      005434 FC               [12] 1080 	mov	r4,a
      005435 A3               [24] 1081 	inc	dptr
      005436 E0               [24] 1082 	movx	a,@dptr
      005437 FD               [12] 1083 	mov	r5,a
      005438 EE               [12] 1084 	mov	a,r6
      005439 C3               [12] 1085 	clr	c
      00543A 9C               [12] 1086 	subb	a,r4
      00543B FC               [12] 1087 	mov	r4,a
      00543C EF               [12] 1088 	mov	a,r7
      00543D 9D               [12] 1089 	subb	a,r5
      00543E FD               [12] 1090 	mov	r5,a
      00543F C3               [12] 1091 	clr	c
      005440 EC               [12] 1092 	mov	a,r4
      005441 94 50            [12] 1093 	subb	a,#0x50
      005443 ED               [12] 1094 	mov	a,r5
      005444 94 00            [12] 1095 	subb	a,#0x00
      005446 40 15            [24] 1096 	jc	00104$
                                   1097 ;	keyboards/ajazz/ak820/ak820_mousekey.c:78: wheel_time = now;
      005448 90 06 C4         [24] 1098 	mov	dptr,#_wheel_time
      00544B EE               [12] 1099 	mov	a,r6
      00544C F0               [24] 1100 	movx	@dptr,a
      00544D EF               [12] 1101 	mov	a,r7
      00544E A3               [24] 1102 	inc	dptr
      00544F F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_mousekey.c:79: immediate |= directions & 0xf0;
      005450 90 06 BE         [24] 1105 	mov	dptr,#_directions
      005453 E0               [24] 1106 	movx	a,@dptr
      005454 54 F0            [12] 1107 	anl	a,#0xf0
      005456 FF               [12] 1108 	mov	r7,a
      005457 90 06 BF         [24] 1109 	mov	dptr,#_immediate
      00545A E0               [24] 1110 	movx	a,@dptr
      00545B 4F               [12] 1111 	orl	a,r7
      00545C F0               [24] 1112 	movx	@dptr,a
      00545D                       1113 00104$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_mousekey.c:81: mousekey_send();
                                   1115 ;	keyboards/ajazz/ak820/ak820_mousekey.c:82: }
      00545D 02 53 22         [24] 1116 	ljmp	_mousekey_send
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'mousekey_clear'
                                   1119 ;------------------------------------------------------------
                                   1120 ;	keyboards/ajazz/ak820/ak820_mousekey.c:84: void mousekey_clear(void) {
                                   1121 ;	-----------------------------------------
                                   1122 ;	 function mousekey_clear
                                   1123 ;	-----------------------------------------
      005460                       1124 _mousekey_clear:
                                   1125 ;	keyboards/ajazz/ak820/ak820_mousekey.c:85: directions = 0;
      005460 90 06 BE         [24] 1126 	mov	dptr,#_directions
      005463 E4               [12] 1127 	clr	a
      005464 F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_mousekey.c:86: immediate = 0;
      005465 90 06 BF         [24] 1130 	mov	dptr,#_immediate
      005468 F0               [24] 1131 	movx	@dptr,a
                                   1132 ;	keyboards/ajazz/ak820/ak820_mousekey.c:87: buttons = 0;
      005469 90 06 C0         [24] 1133 	mov	dptr,#_buttons
      00546C F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_mousekey.c:89: }
      00546D 22               [24] 1136 	ret
                                   1137 	.area CSEG    (CODE)
                                   1138 	.area CONST   (CODE)
                                   1139 	.area XINIT   (CODE)
                                   1140 	.area CABS    (ABS,CODE)
