                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005AE                        562 _source_state:
      0005AE                        563 	.ds 130
      000630                        564 _pending_time:
      000630                        565 	.ds 2
      000632                        566 _pending_code:
      000632                        567 	.ds 2
      000634                        568 _ak820_tapping_source_PARM_1:
      000634                        569 	.ds 2
      000636                        570 _hold_PARM_2:
      000636                        571 	.ds 1
      000637                        572 _hold_code_10000_602:
      000637                        573 	.ds 2
      000639                        574 _hold_mods_30000_605:
      000639                        575 	.ds 1
      00063A                        576 _commit_pending_id_10000_611:
      00063A                        577 	.ds 1
      00063B                        578 _ak820_tapping_before_event_10000_612:
      00063B                        579 	.ds 2
      00063D                        580 _ak820_tapping_process_record_10000_623:
      00063D                        581 	.ds 2
      00063F                        582 _ak820_tapping_process_code_10000_624:
      00063F                        583 	.ds 2
      000641                        584 _ak820_tapping_process_sc_mods_10000_624:
      000641                        585 	.ds 1
      000642                        586 _ak820_oneshot_mods::
      000642                        587 	.ds 1
      000643                        588 _ak820_oneshot_consumed::
      000643                        589 	.ds 1
      000644                        590 _ak820_oneshot_process_PARM_2:
      000644                        591 	.ds 1
      000645                        592 _ak820_oneshot_process_PARM_3:
      000645                        593 	.ds 1
      000646                        594 _ak820_oneshot_process_code_10000_649:
      000646                        595 	.ds 2
      000648                        596 _ak820_oneshot_process_mods_10000_650:
      000648                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E03                        606 _pending:
      000E03                        607 	.ds 1
      000E04                        608 _ak820_oneshot_target::
      000E04                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004609                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004609 90 06 35         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00460C E0               [24]  656 	movx	a,@dptr
      00460D FF               [12]  657 	mov	r7,a
      00460E BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004611                        659 00147$:
      004611 50 14            [24]  660 	jnc	00102$
      004613 90 06 34         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004616 E0               [24]  662 	movx	a,@dptr
      004617 FE               [12]  663 	mov	r6,a
      004618 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      00461B                        665 00149$:
      00461B 50 0A            [24]  666 	jnc	00102$
      00461D 8F 05            [24]  667 	mov	ar5,r7
      00461F ED               [12]  668 	mov	a,r5
      004620 12 3B 42         [24]  669 	lcall	_ak820_outline_0193
      004623 2E               [12]  670 	add	a,r6
      004624 F5 82            [12]  671 	mov	dpl,a
      004626 22               [24]  672 	ret
      004627                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      004627 90 06 34         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      00462A E0               [24]  676 	movx	a,@dptr
      00462B FE               [12]  677 	mov	r6,a
      00462C BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      00462F                        679 00151$:
      00462F 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004631 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004634 75 82 80         [24]  683 	mov	dpl, #0x80
      004637 22               [24]  684 	ret
      004638                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004638 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      00463B 75 82 81         [24]  688 	mov	dpl, #0x81
      00463E 22               [24]  689 	ret
      00463F                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      00463F 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004642 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004643                        707 _hold:
      004643 12 3A FE         [24]  708 	lcall	_ak820_outline_0110
      004646 90 06 37         [24]  709 	mov	dptr,#_hold_code_10000_602
      004649 12 3B 03         [24]  710 	lcall	_ak820_outline_0111
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00464C 90 06 37         [24]  712 	mov	dptr,#_hold_code_10000_602
      00464F 12 4A A2         [24]  713 	lcall	_ak820_outline_0008
      004652 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004654 2D               [12]  715 	add	a,r5
      004655 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004657 8F 05            [24]  718 	mov	ar5,r7
      004659 53 05 1F         [24]  719 	anl	ar5,#0x1f
      00465C 90 06 39         [24]  720 	mov	dptr,#_hold_mods_30000_605
      00465F ED               [12]  721 	mov	a,r5
      004660 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004661 ED               [12]  724 	mov	a,r5
      004662 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004665 ED               [12]  726 	mov	a,r5
      004666 C4               [12]  727 	swap	a
      004667 54 F0            [12]  728 	anl	a,#0xf0
      004669 90 06 39         [24]  729 	mov	dptr,#_hold_mods_30000_605
      00466C F0               [24]  730 	movx	@dptr,a
      00466D                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      00466D 90 06 36         [24]  733 	mov	dptr,#_hold_PARM_2
      004670 E0               [24]  734 	movx	a,@dptr
      004671 60 09            [24]  735 	jz	00104$
      004673 90 06 39         [24]  736 	mov	dptr,#_hold_mods_30000_605
      004676 E0               [24]  737 	movx	a,@dptr
      004677 F5 82            [12]  738 	mov	dpl,a
      004679 02 7B E5         [24]  739 	ljmp	_register_mods
      00467C                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00467C 90 06 39         [24]  742 	mov	dptr,#_hold_mods_30000_605
      00467F E0               [24]  743 	movx	a,@dptr
      004680 F5 82            [12]  744 	mov	dpl,a
      004682 02 7B F9         [24]  745 	ljmp	_unregister_mods
      004685                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004685 8F 06            [24]  748 	mov	ar6,r7
      004687 74 0F            [12]  749 	mov	a,#0x0f
      004689 5E               [12]  750 	anl	a,r6
      00468A FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00468B 90 06 36         [24]  753 	mov	dptr,#_hold_PARM_2
      00468E E0               [24]  754 	movx	a,@dptr
      00468F 60 05            [24]  755 	jz	00107$
      004691 8F 82            [24]  756 	mov	dpl, r7
      004693 02 7D E2         [24]  757 	ljmp	_layer_hold_on
      004696                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004696 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004698 02 7E 1A         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00469B                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00469B 90 0E 03         [24]  774 	mov	dptr,#_pending
      00469E E0               [24]  775 	movx	a,@dptr
      00469F 90 06 3A         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      0046A2 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      0046A3 12 4B 35         [24]  779 	lcall	_ak820_outline_0161
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      0046A6 90 06 3A         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      0046A9 E0               [24]  782 	movx	a,@dptr
      0046AA 24 AE            [12]  783 	add	a,#_source_state
      0046AC FF               [12]  784 	mov	r7,a
      0046AD E4               [12]  785 	clr	a
      0046AE 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      0046B0 FE               [12]  787 	mov	r6,a
      0046B1 12 45 F4         [24]  788 	lcall	_ak820_outline_0165
      0046B4 E0               [24]  789 	movx	a,@dptr
      0046B5 FD               [12]  790 	mov	r5,a
      0046B6 43 05 04         [24]  791 	orl	ar5,#0x04
      0046B9 12 45 F4         [24]  792 	lcall	_ak820_outline_0165
      0046BC ED               [12]  793 	mov	a,r5
      0046BD F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      0046BE 90 06 32         [24]  796 	mov	dptr,#_pending_code
      0046C1 12 3A BD         [24]  797 	lcall	_ak820_outline_0052
      0046C4 90 06 36         [24]  798 	mov	dptr,#_hold_PARM_2
      0046C7 74 01            [12]  799 	mov	a,#0x01
      0046C9 12 45 BA         [24]  800 	lcall	_ak820_outline_0079
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0046CC 02 46 43         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0046CF                        813 _ak820_tapping_before:
      0046CF 12 3A FE         [24]  814 	lcall	_ak820_outline_0110
      0046D2 90 06 3B         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0046D5 12 3B 03         [24]  816 	lcall	_ak820_outline_0111
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0046D8 90 06 3B         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0046DB 12 4A A2         [24]  819 	lcall	_ak820_outline_0008
      0046DE 12 4A C7         [24]  820 	lcall	_ak820_outline_0024
      0046E1 C0 07            [24]  821 	push	ar7
      0046E3 C0 06            [24]  822 	push	ar6
      0046E5 12 BD F6         [24]  823 	lcall	___memcpy
      0046E8 12 46 09         [24]  824 	lcall	_ak820_tapping_source
      0046EB AD 82            [24]  825 	mov	r5, dpl
      0046ED D0 06            [24]  826 	pop	ar6
      0046EF D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0046F1 90 0E 74         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0046F4 E0               [24]  830 	movx	a,@dptr
      0046F5 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0046F7 12 4B 28         [24]  833 	lcall	_ak820_outline_0099
      0046FA 60 1D            [24]  834 	jz	00102$
      0046FC BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0046FF 80 18            [24]  836 	sjmp	00102$
      004701                        837 00218$:
      004701 12 4A AC         [24]  838 	lcall	_ak820_outline_0015
      004704 E0               [24]  839 	movx	a,@dptr
      004705 70 12            [24]  840 	jnz	00102$
      004707 ED               [12]  841 	mov	a,r5
      004708 24 AE            [12]  842 	add	a, #_source_state
      00470A FB               [12]  843 	mov	r3,a
      00470B E4               [12]  844 	clr	a
      00470C 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      00470E 12 4A F7         [24]  846 	lcall	_ak820_outline_0056
      004711 53 02 FD         [24]  847 	anl	ar2,#0xfd
      004714 12 36 78         [24]  848 	lcall	_ak820_outline_0125
      004717 EA               [12]  849 	mov	a,r2
      004718 F0               [24]  850 	movx	@dptr,a
      004719                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      004719 75 82 00         [24]  853 	mov	dpl, #0x00
      00471C 22               [24]  854 	ret
      00471D                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      00471D 90 0E 03         [24]  857 	mov	dptr,#_pending
      004720 E0               [24]  858 	movx	a,@dptr
      004721 FC               [12]  859 	mov	r4,a
      004722 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004725 80 3B            [24]  861 	sjmp	00108$
      004727                        862 00220$:
      004727 12 3A B5         [24]  863 	lcall	_ak820_outline_0037
      00472A FA               [12]  864 	mov	r2,a
      00472B A3               [24]  865 	inc	dptr
      00472C E0               [24]  866 	movx	a,@dptr
      00472D FB               [12]  867 	mov	r3,a
      00472E 90 06 30         [24]  868 	mov	dptr,#_pending_time
      004731 12 3A F8         [24]  869 	lcall	_ak820_outline_0105
      004734 EA               [12]  870 	mov	a,r2
      004735 C3               [12]  871 	clr	c
      004736 98               [12]  872 	subb	a,r0
      004737 FA               [12]  873 	mov	r2,a
      004738 EB               [12]  874 	mov	a,r3
      004739 99               [12]  875 	subb	a,r1
      00473A FB               [12]  876 	mov	r3,a
      00473B C3               [12]  877 	clr	c
      00473C EA               [12]  878 	mov	a,r2
      00473D 94 C8            [12]  879 	subb	a,#0xc8
      00473F EB               [12]  880 	mov	a,r3
      004740 94 00            [12]  881 	subb	a,#0x00
      004742 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004744 74 04            [12]  884 	mov	a,#0x04
      004746 12 4A E1         [24]  885 	lcall	_ak820_outline_0032
      004749 60 17            [24]  886 	jz	00108$
      00474B 12 3A 8E         [24]  887 	lcall	_ak820_outline_0009
      00474E 60 12            [24]  888 	jz	00108$
      004750 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004753 80 06            [24]  890 	sjmp	00107$
      004755                        891 00224$:
      004755 ED               [12]  892 	mov	a,r5
      004756 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004759 80 07            [24]  894 	sjmp	00108$
      00475B                        895 00225$:
      00475B                        896 00107$:
      00475B C0 05            [24]  897 	push	ar5
      00475D 12 46 9B         [24]  898 	lcall	_commit_pending
      004760 D0 05            [24]  899 	pop	ar5
      004762                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004762 90 06 3B         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004765 12 3A BD         [24]  903 	lcall	_ak820_outline_0052
      004768 12 4B 28         [24]  904 	lcall	_ak820_outline_0099
      00476B 60 03            [24]  905 	jz	00114$
      00476D BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004770                        907 00114$:
      004770 75 82 01         [24]  908 	mov	dpl, #0x01
      004773 22               [24]  909 	ret
      004774                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004774 ED               [12]  912 	mov	a,r5
      004775 12 4B 13         [24]  913 	lcall	_ak820_outline_0081
      004778 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00477B 74 05            [12]  916 	mov	a,#0x05
      00477D 2E               [12]  917 	add	a, r6
      00477E 12 3A A3         [24]  918 	lcall	_ak820_outline_0017
      004781 70 07            [24]  919 	jnz	00118$
      004783 74 FD            [12]  920 	mov	a,#0xfd
      004785 5B               [12]  921 	anl	a,r3
      004786 12 3B 13         [24]  922 	lcall	_ak820_outline_0126
      004789 F0               [24]  923 	movx	@dptr,a
      00478A                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00478A 75 82 00         [24]  926 	mov	dpl, #0x00
      00478D 22               [24]  927 	ret
      00478E                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00478E 12 45 7D         [24]  930 	lcall	_ak820_outline_0011
      004791 E0               [24]  931 	movx	a,@dptr
      004792 FF               [12]  932 	mov	r7,a
      004793 8B 06            [24]  933 	mov	ar6,r3
      004795 53 06 01         [24]  934 	anl	ar6,#0x01
      004798 EE               [12]  935 	mov	a,r6
      004799 B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      00479C                        937 00231$:
      00479C B3               [12]  938 	cpl	c
      00479D 92 0F            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      00479F 8F F0            [24]  940 	mov	b,r7
      0047A1 E4               [12]  941 	clr	a
      0047A2 33               [12]  942 	rlc	a
      0047A3 B5 F0 04         [24]  943 	cjne	a,b,00122$
      0047A6 75 82 00         [24]  944 	mov	dpl, #0x00
      0047A9 22               [24]  945 	ret
      0047AA                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      0047AA 63 03 01         [24]  948 	xrl	ar3,#0x01
      0047AD 12 3B 13         [24]  949 	lcall	_ak820_outline_0126
      0047B0 EB               [12]  950 	mov	a,r3
      0047B1 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      0047B2 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      0047B5 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      0047B6                        969 _ak820_tapping_process:
      0047B6 12 3A FE         [24]  970 	lcall	_ak820_outline_0110
      0047B9 90 06 3D         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0047BC 12 3B 03         [24]  972 	lcall	_ak820_outline_0111
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      0047BF 90 06 41         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0047C2 E4               [12]  975 	clr	a
      0047C3 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      0047C4 90 06 3D         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0047C7 12 3A BD         [24]  979 	lcall	_ak820_outline_0052
      0047CA 74 04            [12]  980 	mov	a,#0x04
      0047CC 12 4A EC         [24]  981 	lcall	_ak820_outline_0033
      0047CF 70 04            [24]  982 	jnz	00102$
      0047D1 75 82 01         [24]  983 	mov	dpl, #0x01
      0047D4 22               [24]  984 	ret
      0047D5                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      0047D5 8E 04            [24]  987 	mov	ar4,r6
      0047D7 8F 05            [24]  988 	mov	ar5,r7
      0047D9 12 4A C7         [24]  989 	lcall	_ak820_outline_0024
      0047DC C0 07            [24]  990 	push	ar7
      0047DE C0 06            [24]  991 	push	ar6
      0047E0 12 BD F6         [24]  992 	lcall	___memcpy
      0047E3 12 46 09         [24]  993 	lcall	_ak820_tapping_source
      0047E6 AD 82            [24]  994 	mov	r5, dpl
      0047E8 D0 06            [24]  995 	pop	ar6
      0047EA D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0047EC BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      0047EF 75 82 01         [24]  999 	mov	dpl, #0x01
      0047F2 22               [24] 1000 	ret
      0047F3                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0047F3 74 07            [12] 1003 	mov	a,#0x07
      0047F5 12 3A AD         [24] 1004 	lcall	_ak820_outline_0022
      0047F8 12 3A BD         [24] 1005 	lcall	_ak820_outline_0052
      0047FB 90 06 3F         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0047FE 12 4A FF         [24] 1007 	lcall	_ak820_outline_0060
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004801 BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      004804 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      004807 90 06 3F         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00480A 74 26            [12] 1012 	mov	a,#0x26
      00480C F0               [24] 1013 	movx	@dptr,a
      00480D 74 22            [12] 1014 	mov	a,#0x22
      00480F A3               [24] 1015 	inc	dptr
      004810 F0               [24] 1016 	movx	@dptr,a
      004811 90 06 41         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004814 74 02            [12] 1018 	mov	a,#0x02
      004816 F0               [24] 1019 	movx	@dptr,a
      004817 80 28            [24] 1020 	sjmp	00112$
      004819                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004819 BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      00481C BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      00481F 90 06 3F         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004822 74 27            [12] 1026 	mov	a,#0x27
      004824 F0               [24] 1027 	movx	@dptr,a
      004825 74 32            [12] 1028 	mov	a,#0x32
      004827 A3               [24] 1029 	inc	dptr
      004828 F0               [24] 1030 	movx	@dptr,a
      004829 90 06 41         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00482C 74 20            [12] 1032 	mov	a,#0x20
      00482E F0               [24] 1033 	movx	@dptr,a
      00482F 80 10            [24] 1034 	sjmp	00112$
      004831                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004831 BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      004834 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      004837 90 06 3F         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00483A 74 28            [12] 1040 	mov	a,#0x28
      00483C F0               [24] 1041 	movx	@dptr,a
      00483D 74 32            [12] 1042 	mov	a,#0x32
      00483F A3               [24] 1043 	inc	dptr
      004840 F0               [24] 1044 	movx	@dptr,a
      004841                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004841 90 06 3F         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004844 E0               [24] 1048 	movx	a,@dptr
      004845 A3               [24] 1049 	inc	dptr
      004846 E0               [24] 1050 	movx	a,@dptr
      004847 FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004848 BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      00484B                       1054 00242$:
      00484B 40 05            [24] 1055 	jc	00113$
      00484D BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      004850                       1057 00244$:
      004850 40 04            [24] 1058 	jc	00114$
      004852                       1059 00113$:
      004852 75 82 01         [24] 1060 	mov	dpl, #0x01
      004855 22               [24] 1061 	ret
      004856                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004856 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      004859                       1065 00246$:
      004859 40 0C            [24] 1066 	jc	00117$
      00485B 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      00485E BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      004861                       1069 00248$:
      004861 40 04            [24] 1070 	jc	00117$
      004863 75 82 00         [24] 1071 	mov	dpl, #0x00
      004866 22               [24] 1072 	ret
      004867                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      004867 90 06 3D         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00486A 12 3A BD         [24] 1076 	lcall	_ak820_outline_0052
      00486D 12 4A AC         [24] 1077 	lcall	_ak820_outline_0015
      004870 E0               [24] 1078 	movx	a,@dptr
      004871 60 1F            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004873 90 0E 03         [24] 1081 	mov	dptr,#_pending
      004876 ED               [12] 1082 	mov	a,r5
      004877 12 45 87         [24] 1083 	lcall	_ak820_outline_0031
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      00487A 12 3A BD         [24] 1085 	lcall	_ak820_outline_0052
      00487D 90 06 30         [24] 1086 	mov	dptr,#_pending_time
      004880 12 4A FF         [24] 1087 	lcall	_ak820_outline_0060
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004883 90 06 3F         [24] 1089 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004886 12 3A BD         [24] 1090 	lcall	_ak820_outline_0052
      004889 90 06 32         [24] 1091 	mov	dptr,#_pending_code
      00488C 12 4A FF         [24] 1092 	lcall	_ak820_outline_0060
      00488F 02 49 43         [24] 1093 	ljmp	00132$
      004892                       1094 00131$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004892 90 0E 03         [24] 1096 	mov	dptr,#_pending
      004895 E0               [24] 1097 	movx	a,@dptr
      004896 FF               [12] 1098 	mov	r7,a
      004897 ED               [12] 1099 	mov	a,r5
      004898 B5 07 02         [24] 1100 	cjne	a,ar7,00251$
      00489B 80 03            [24] 1101 	sjmp	00252$
      00489D                       1102 00251$:
      00489D 02 49 1B         [24] 1103 	ljmp	00128$
      0048A0                       1104 00252$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      0048A0 12 4B 35         [24] 1106 	lcall	_ak820_outline_0161
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      0048A3 90 06 41         [24] 1108 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0048A6 E0               [24] 1109 	movx	a,@dptr
      0048A7 FF               [12] 1110 	mov	r7,a
      0048A8 E0               [24] 1111 	movx	a,@dptr
      0048A9 60 05            [24] 1112 	jz	00120$
      0048AB 8F 82            [24] 1113 	mov	dpl, r7
      0048AD 12 82 68         [24] 1114 	lcall	_add_owned_mods
      0048B0                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      0048B0 90 06 3D         [24] 1117 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0048B3 12 3A BD         [24] 1118 	lcall	_ak820_outline_0052
      0048B6 74 07            [12] 1119 	mov	a,#0x07
      0048B8 2E               [12] 1120 	add	a, r6
      0048B9 FB               [12] 1121 	mov	r3,a
      0048BA E4               [12] 1122 	clr	a
      0048BB 3F               [12] 1123 	addc	a, r7
      0048BC FC               [12] 1124 	mov	r4,a
      0048BD 90 06 3F         [24] 1125 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048C0 E0               [24] 1126 	movx	a,@dptr
      0048C1 F9               [12] 1127 	mov	r1,a
      0048C2 7A 00            [12] 1128 	mov	r2,#0x00
      0048C4 12 36 78         [24] 1129 	lcall	_ak820_outline_0125
      0048C7 E9               [12] 1130 	mov	a,r1
      0048C8 F0               [24] 1131 	movx	@dptr,a
      0048C9 EA               [12] 1132 	mov	a,r2
      0048CA A3               [24] 1133 	inc	dptr
      0048CB F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0048CC C3               [12] 1136 	clr	c
      0048CD 04               [12] 1137 	inc	a
      0048CE 99               [12] 1138 	subb	a,r1
      0048CF 50 38            [24] 1139 	jnc	00122$
                                   1140 ;	free result
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0048D1 74 06            [12] 1142 	mov	a,#0x06
      0048D3 12 3A AD         [24] 1143 	lcall	_ak820_outline_0022
      0048D6 E0               [24] 1144 	movx	a,@dptr
      0048D7 54 0F            [12] 1145 	anl	a,#0x0f
      0048D9 44 10            [12] 1146 	orl	a,#0x10
      0048DB F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0048DC 12 4A AC         [24] 1149 	lcall	_ak820_outline_0015
      0048DF 74 01            [12] 1150 	mov	a,#0x01
      0048E1 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0048E2 12 4B 05         [24] 1153 	lcall	_ak820_outline_0076
      0048E5 12 4B 21         [24] 1154 	lcall	_ak820_outline_0096
      0048E8 C0 07            [24] 1155 	push	ar7
      0048EA C0 06            [24] 1156 	push	ar6
      0048EC C0 04            [24] 1157 	push	ar4
      0048EE C0 03            [24] 1158 	push	ar3
      0048F0 12 76 24         [24] 1159 	lcall	_process_record
      0048F3 D0 03            [24] 1160 	pop	ar3
      0048F5 D0 04            [24] 1161 	pop	ar4
      0048F7 D0 06            [24] 1162 	pop	ar6
      0048F9 D0 07            [24] 1163 	pop	ar7
                                   1164 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0048FB 12 36 78         [24] 1165 	lcall	_ak820_outline_0125
      0048FE E4               [12] 1166 	clr	a
      0048FF F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      004900 FC               [12] 1169 	mov	r4,a
      004901 12 3B 08         [24] 1170 	lcall	_ak820_outline_0120
      004904 8C F0            [24] 1171 	mov	b, r4
      004906 12 76 24         [24] 1172 	lcall	_process_record
      004909                       1173 00122$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      004909 90 06 41         [24] 1175 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00490C E0               [24] 1176 	movx	a,@dptr
      00490D FF               [12] 1177 	mov	r7,a
      00490E E0               [24] 1178 	movx	a,@dptr
      00490F 60 32            [24] 1179 	jz	00132$
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      004911 8F 82            [24] 1181 	mov	dpl, r7
      004913 12 82 78         [24] 1182 	lcall	_del_owned_mods
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      004916 12 85 A9         [24] 1184 	lcall	_send_keyboard_report
      004919 80 28            [24] 1185 	sjmp	00132$
      00491B                       1186 00128$:
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      00491B ED               [12] 1188 	mov	a,r5
      00491C 24 AE            [12] 1189 	add	a, #_source_state
      00491E FE               [12] 1190 	mov	r6,a
      00491F E4               [12] 1191 	clr	a
      004920 34 05            [12] 1192 	addc	a, #(_source_state >> 8)
      004922 FF               [12] 1193 	mov	r7,a
      004923 12 3B 08         [24] 1194 	lcall	_ak820_outline_0120
      004926 E0               [24] 1195 	movx	a,@dptr
      004927 FD               [12] 1196 	mov	r5,a
      004928 30 E2 18         [24] 1197 	jnb	acc.2,00132$
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      00492B 53 05 FB         [24] 1199 	anl	ar5,#0xfb
      00492E 12 3B 08         [24] 1200 	lcall	_ak820_outline_0120
      004931 ED               [12] 1201 	mov	a,r5
      004932 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      004933 90 06 3F         [24] 1204 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004936 12 3A BD         [24] 1205 	lcall	_ak820_outline_0052
      004939 90 06 36         [24] 1206 	mov	dptr,#_hold_PARM_2
      00493C E4               [12] 1207 	clr	a
      00493D 12 45 BA         [24] 1208 	lcall	_ak820_outline_0079
      004940 12 46 43         [24] 1209 	lcall	_hold
      004943                       1210 00132$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      004943 75 82 00         [24] 1212 	mov	dpl, #0x00
                                   1213 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004946 22               [24] 1214 	ret
                                   1215 ;------------------------------------------------------------
                                   1216 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1217 ;------------------------------------------------------------
                                   1218 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1219 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1220 ;------------------------------------------------------------
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1222 ;	-----------------------------------------
                                   1223 ;	 function ak820_tapping_cancel
                                   1224 ;	-----------------------------------------
      004947                       1225 _ak820_tapping_cancel:
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004947 12 4B 35         [24] 1227 	lcall	_ak820_outline_0161
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      00494A 7F 00            [12] 1229 	mov	r7,#0x00
      00494C                       1230 00103$:
      00494C BF 82 00         [24] 1231 	cjne	r7,#0x82,00122$
      00494F                       1232 00122$:
      00494F 50 16            [24] 1233 	jnc	00105$
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004951 12 4A B8         [24] 1235 	lcall	_ak820_outline_0020
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004954 74 02            [12] 1237 	mov	a,#0x02
      004956 5C               [12] 1238 	anl	a,r4
      004957 FB               [12] 1239 	mov	r3,a
      004958 53 04 01         [24] 1240 	anl	ar4,#0x01
      00495B EC               [12] 1241 	mov	a,r4
      00495C 2C               [12] 1242 	add	a,r4
      00495D 42 03            [12] 1243 	orl	ar3,a
      00495F 12 3B 1D         [24] 1244 	lcall	_ak820_outline_0137
      004962 EB               [12] 1245 	mov	a,r3
      004963 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004964 0F               [12] 1248 	inc	r7
      004965 80 E5            [24] 1249 	sjmp	00103$
      004967                       1250 00105$:
                                   1251 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004967 22               [24] 1252 	ret
                                   1253 ;------------------------------------------------------------
                                   1254 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1255 ;------------------------------------------------------------
                                   1256 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1257 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1258 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1259 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1260 ;i             Allocated with name '_ak820_oneshot_process_i_40000_664'
                                   1261 ;------------------------------------------------------------
                                   1262 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1263 ;	-----------------------------------------
                                   1264 ;	 function ak820_oneshot_process
                                   1265 ;	-----------------------------------------
      004968                       1266 _ak820_oneshot_process:
      004968 12 3A FE         [24] 1267 	lcall	_ak820_outline_0110
      00496B 90 06 46         [24] 1268 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00496E 12 3B 03         [24] 1269 	lcall	_ak820_outline_0111
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004971 90 06 44         [24] 1271 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004974 E0               [24] 1272 	movx	a,@dptr
      004975 FF               [12] 1273 	mov	r7,a
      004976 BF FF 02         [24] 1274 	cjne	r7,#0xff,00248$
      004979 80 0B            [24] 1275 	sjmp	00101$
      00497B                       1276 00248$:
      00497B C0 07            [24] 1277 	push	ar7
      00497D 12 A7 DE         [24] 1278 	lcall	_get_repeat_key_count
      004980 E5 82            [12] 1279 	mov	a, dpl
      004982 D0 07            [24] 1280 	pop	ar7
      004984 60 04            [24] 1281 	jz	00102$
      004986                       1282 00101$:
      004986 75 82 01         [24] 1283 	mov	dpl, #0x01
      004989 22               [24] 1284 	ret
      00498A                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_tapping.c:146: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00498A 90 06 46         [24] 1287 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00498D E0               [24] 1288 	movx	a,@dptr
      00498E FD               [12] 1289 	mov	r5,a
      00498F A3               [24] 1290 	inc	dptr
      004990 E0               [24] 1291 	movx	a,@dptr
      004991 FB               [12] 1292 	mov	r3,a
      004992 BB 52 02         [24] 1293 	cjne	r3,#0x52,00250$
      004995 80 03            [24] 1294 	sjmp	00251$
      004997                       1295 00250$:
      004997 02 4A 3C         [24] 1296 	ljmp	00116$
      00499A                       1297 00251$:
      00499A 8D 04            [24] 1298 	mov	ar4,r5
      00499C 53 04 E0         [24] 1299 	anl	ar4,#0xe0
      00499F BC A0 02         [24] 1300 	cjne	r4,#0xa0,00252$
      0049A2 80 03            [24] 1301 	sjmp	00253$
      0049A4                       1302 00252$:
      0049A4 02 4A 3C         [24] 1303 	ljmp	00116$
      0049A7                       1304 00253$:
                                   1305 ;	keyboards/ajazz/ak820/ak820_tapping.c:147: mods = code & 15;
      0049A7 8D 04            [24] 1306 	mov	ar4,r5
      0049A9 53 04 0F         [24] 1307 	anl	ar4,#0x0f
      0049AC 90 06 48         [24] 1308 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0049AF EC               [12] 1309 	mov	a,r4
      0049B0 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:148: if (code & 16) mods <<= 4;
      0049B1 ED               [12] 1312 	mov	a,r5
      0049B2 30 E4 08         [24] 1313 	jnb	acc.4,00105$
      0049B5 EC               [12] 1314 	mov	a,r4
      0049B6 C4               [12] 1315 	swap	a
      0049B7 54 F0            [12] 1316 	anl	a,#0xf0
      0049B9 90 06 48         [24] 1317 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0049BC F0               [24] 1318 	movx	@dptr,a
      0049BD                       1319 00105$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: if (pressed) {
      0049BD 90 06 45         [24] 1321 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0049C0 E0               [24] 1322 	movx	a,@dptr
      0049C1 60 2D            [24] 1323 	jz	00113$
                                   1324 ;	keyboards/ajazz/ak820/ak820_tapping.c:150: source_state[id] |= SOURCE_ONESHOT;
      0049C3 12 4A B8         [24] 1325 	lcall	_ak820_outline_0020
      0049C6 43 04 08         [24] 1326 	orl	ar4,#0x08
      0049C9 12 45 B3         [24] 1327 	lcall	_ak820_outline_0065
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0049CC 53 04 EF         [24] 1329 	anl	ar4,#0xef
      0049CF 12 45 B3         [24] 1330 	lcall	_ak820_outline_0065
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:152: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0049D2 90 0E 04         [24] 1332 	mov	dptr,#_ak820_oneshot_target
      0049D5 E0               [24] 1333 	movx	a,@dptr
      0049D6 FC               [12] 1334 	mov	r4,a
      0049D7 BC FF 02         [24] 1335 	cjne	r4,#0xff,00256$
      0049DA 80 09            [24] 1336 	sjmp	00107$
      0049DC                       1337 00256$:
      0049DC 12 4B 0C         [24] 1338 	lcall	_ak820_outline_0077
      0049DF 43 04 10         [24] 1339 	orl	ar4,#0x10
      0049E2 12 45 B3         [24] 1340 	lcall	_ak820_outline_0065
      0049E5                       1341 00107$:
                                   1342 ;	keyboards/ajazz/ak820/ak820_tapping.c:153: register_mods(mods);
      0049E5 90 06 48         [24] 1343 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0049E8 E0               [24] 1344 	movx	a,@dptr
      0049E9 F5 82            [12] 1345 	mov	dpl,a
      0049EB 12 7B E5         [24] 1346 	lcall	_register_mods
      0049EE 80 48            [24] 1347 	sjmp	00114$
      0049F0                       1348 00113$:
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: } else if (source_state[id] & SOURCE_ONESHOT) {
      0049F0 12 4A B8         [24] 1350 	lcall	_ak820_outline_0020
      0049F3 30 E3 42         [24] 1351 	jnb	acc.3,00114$
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0049F6 EC               [12] 1353 	mov	a,r4
      0049F7 20 E4 24         [24] 1354 	jb	acc.4,00109$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: add_owned_mods(mods & ~ak820_oneshot_mods);
      0049FA 90 06 42         [24] 1356 	mov	dptr,#_ak820_oneshot_mods
      0049FD E0               [24] 1357 	movx	a,@dptr
      0049FE F4               [12] 1358 	cpl	a
      0049FF FC               [12] 1359 	mov	r4,a
      004A00 90 06 48         [24] 1360 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A03 E0               [24] 1361 	movx	a,@dptr
      004A04 FB               [12] 1362 	mov	r3,a
      004A05 52 04            [12] 1363 	anl	ar4,a
      004A07 8C 82            [24] 1364 	mov	dpl, r4
      004A09 C0 06            [24] 1365 	push	ar6
      004A0B C0 05            [24] 1366 	push	ar5
      004A0D C0 03            [24] 1367 	push	ar3
      004A0F 12 82 68         [24] 1368 	lcall	_add_owned_mods
      004A12 D0 03            [24] 1369 	pop	ar3
      004A14 D0 05            [24] 1370 	pop	ar5
      004A16 D0 06            [24] 1371 	pop	ar6
                                   1372 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: ak820_oneshot_mods |= mods;
      004A18 90 06 42         [24] 1373 	mov	dptr,#_ak820_oneshot_mods
      004A1B E0               [24] 1374 	movx	a,@dptr
      004A1C 4B               [12] 1375 	orl	a,r3
      004A1D F0               [24] 1376 	movx	@dptr,a
      004A1E                       1377 00109$:
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: unregister_mods(mods);
      004A1E 90 06 48         [24] 1379 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A21 E0               [24] 1380 	movx	a,@dptr
      004A22 F5 82            [12] 1381 	mov	dpl,a
      004A24 C0 06            [24] 1382 	push	ar6
      004A26 C0 05            [24] 1383 	push	ar5
      004A28 12 7B F9         [24] 1384 	lcall	_unregister_mods
      004A2B D0 05            [24] 1385 	pop	ar5
      004A2D D0 06            [24] 1386 	pop	ar6
                                   1387 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004A2F 12 4B 0C         [24] 1388 	lcall	_ak820_outline_0077
      004A32 53 04 E7         [24] 1389 	anl	ar4,#0xe7
      004A35 12 45 B3         [24] 1390 	lcall	_ak820_outline_0065
      004A38                       1391 00114$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: return false;
      004A38 75 82 00         [24] 1393 	mov	dpl, #0x00
      004A3B 22               [24] 1394 	ret
      004A3C                       1395 00116$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (pressed && code > KC_TRANSPARENT &&
      004A3C 90 06 45         [24] 1397 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A3F E0               [24] 1398 	movx	a,@dptr
      004A40 60 5C            [24] 1399 	jz	00124$
      004A42 90 06 46         [24] 1400 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A45 12 3A E0         [24] 1401 	lcall	_ak820_outline_0080
      004A48 C3               [12] 1402 	clr	c
      004A49 74 01            [12] 1403 	mov	a,#0x01
      004A4B 9D               [12] 1404 	subb	a,r5
      004A4C E4               [12] 1405 	clr	a
      004A4D 9E               [12] 1406 	subb	a,r6
      004A4E 50 4E            [24] 1407 	jnc	00124$
                                   1408 ;	free result
                                   1409 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004A50 C3               [12] 1410 	clr	c
      004A51 ED               [12] 1411 	mov	a,r5
      004A52 94 E0            [12] 1412 	subb	a,#0xe0
      004A54 EE               [12] 1413 	mov	a,r6
      004A55 94 00            [12] 1414 	subb	a,#0x00
      004A57 40 07            [24] 1415 	jc	00129$
      004A59 74 E7            [12] 1416 	mov	a,#0xe7
      004A5B 9D               [12] 1417 	subb	a,r5
      004A5C E4               [12] 1418 	clr	a
      004A5D 9E               [12] 1419 	subb	a,r6
      004A5E 50 3E            [24] 1420 	jnc	00124$
                                   1421 ;	free result
      004A60                       1422 00129$:
                                   1423 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004A60 74 AE            [12] 1424 	mov	a,#0x100 - 0x52
      004A62 2E               [12] 1425 	add	a,r6
      004A63 50 09            [24] 1426 	jnc	00165$
      004A65 C3               [12] 1427 	clr	c
      004A66 74 DF            [12] 1428 	mov	a,#0xdf
      004A68 9D               [12] 1429 	subb	a,r5
      004A69 74 52            [12] 1430 	mov	a,#0x52
      004A6B 9E               [12] 1431 	subb	a,r6
      004A6C 50 30            [24] 1432 	jnc	00124$
                                   1433 ;	free result
                                   1434 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: for (uint8_t i = 0; i < SOURCES; ++i)
      004A6E                       1435 00165$:
      004A6E 7E 00            [12] 1436 	mov	r6,#0x00
      004A70                       1437 00131$:
      004A70 BE 82 00         [24] 1438 	cjne	r6,#0x82,00265$
      004A73                       1439 00265$:
      004A73 50 12            [24] 1440 	jnc	00120$
                                   1441 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004A75 EE               [12] 1442 	mov	a,r6
      004A76 12 4B 13         [24] 1443 	lcall	_ak820_outline_0081
      004A79 30 E3 08         [24] 1444 	jnb	acc.3,00132$
      004A7C 43 03 10         [24] 1445 	orl	ar3,#0x10
      004A7F 12 3B 13         [24] 1446 	lcall	_ak820_outline_0126
      004A82 EB               [12] 1447 	mov	a,r3
      004A83 F0               [24] 1448 	movx	@dptr,a
      004A84                       1449 00132$:
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: for (uint8_t i = 0; i < SOURCES; ++i)
      004A84 0E               [12] 1451 	inc	r6
      004A85 80 E9            [24] 1452 	sjmp	00131$
      004A87                       1453 00120$:
                                   1454 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: if (ak820_oneshot_mods) {
      004A87 90 06 42         [24] 1455 	mov	dptr,#_ak820_oneshot_mods
      004A8A E0               [24] 1456 	movx	a,@dptr
      004A8B FE               [12] 1457 	mov	r6,a
      004A8C E0               [24] 1458 	movx	a,@dptr
      004A8D 60 0F            [24] 1459 	jz	00124$
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A8F 90 06 43         [24] 1461 	mov	dptr,#_ak820_oneshot_consumed
      004A92 EE               [12] 1462 	mov	a,r6
      004A93 F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: ak820_oneshot_target = id;
      004A94 90 0E 04         [24] 1465 	mov	dptr,#_ak820_oneshot_target
      004A97 EF               [12] 1466 	mov	a,r7
      004A98 F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: ak820_oneshot_mods = 0;
      004A99 90 06 42         [24] 1469 	mov	dptr,#_ak820_oneshot_mods
      004A9C E4               [12] 1470 	clr	a
      004A9D F0               [24] 1471 	movx	@dptr,a
      004A9E                       1472 00124$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: return true;
      004A9E 75 82 01         [24] 1474 	mov	dpl, #0x01
                                   1475 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: }
      004AA1 22               [24] 1476 	ret
                                   1477 	.area CSEG    (CODE)
                                   1478 	.area CONST   (CODE)
                                   1479 	.area XINIT   (CODE)
      00C708                       1480 __xinit__pending:
      00C708 FF                    1481 	.db #0xff	; 255
      00C709                       1482 __xinit__ak820_oneshot_target:
      00C709 FF                    1483 	.db #0xff	; 255
                                   1484 	.area CABS    (ABS,CODE)
                                   1485 
                                   1486 ; Experimental exact instruction outlining.
                                   1487 	.globl _ak820_outline_0008
                                   1488 	.globl _ak820_outline_0009
                                   1489 	.globl _ak820_outline_0011
                                   1490 	.globl _ak820_outline_0015
                                   1491 	.globl _ak820_outline_0017
                                   1492 	.globl _ak820_outline_0020
                                   1493 	.globl _ak820_outline_0022
                                   1494 	.globl _ak820_outline_0024
                                   1495 	.globl _ak820_outline_0031
                                   1496 	.globl _ak820_outline_0032
                                   1497 	.globl _ak820_outline_0033
                                   1498 	.globl _ak820_outline_0037
                                   1499 	.globl _ak820_outline_0052
                                   1500 	.globl _ak820_outline_0056
                                   1501 	.globl _ak820_outline_0060
                                   1502 	.globl _ak820_outline_0065
                                   1503 	.globl _ak820_outline_0076
                                   1504 	.globl _ak820_outline_0077
                                   1505 	.globl _ak820_outline_0079
                                   1506 	.globl _ak820_outline_0080
                                   1507 	.globl _ak820_outline_0081
                                   1508 	.globl _ak820_outline_0096
                                   1509 	.globl _ak820_outline_0099
                                   1510 	.globl _ak820_outline_0105
                                   1511 	.globl _ak820_outline_0110
                                   1512 	.globl _ak820_outline_0111
                                   1513 	.globl _ak820_outline_0120
                                   1514 	.globl _ak820_outline_0125
                                   1515 	.globl _ak820_outline_0126
                                   1516 	.globl _ak820_outline_0137
                                   1517 	.globl _ak820_outline_0161
                                   1518 	.globl _ak820_outline_0165
                                   1519 	.globl _ak820_outline_0193
                                   1520 
                                   1521 	.area CSEG (CODE)
                                   1522 ; function ak820_outline_0008
      004AA2                       1523 _ak820_outline_0008:
      004AA2 E0               [24] 1524 	movx	a,@dptr
      004AA3 FE               [12] 1525 	mov	r6,a
      004AA4 A3               [24] 1526 	inc	dptr
      004AA5 E0               [24] 1527 	movx	a,@dptr
      004AA6 FF               [12] 1528 	mov	r7,a
      004AA7 8E 04            [24] 1529 	mov	ar4,r6
      004AA9 8F 05            [24] 1530 	mov	ar5,r7
      004AAB 22               [24] 1531 	ret
                                   1532 
                                   1533 	.area CSEG (CODE)
                                   1534 ; function ak820_outline_0015
      004AAC                       1535 _ak820_outline_0015:
      004AAC 74 05            [12] 1536 	mov	a,#0x05
      004AAE 2E               [12] 1537 	add	a,r6
      004AAF FB               [12] 1538 	mov	r3,a
      004AB0 E4               [12] 1539 	clr	a
      004AB1 3F               [12] 1540 	addc	a,r7
      004AB2 FC               [12] 1541 	mov	r4,a
      004AB3 8B 82            [24] 1542 	mov	dpl,r3
      004AB5 8C 83            [24] 1543 	mov	dph,r4
      004AB7 22               [24] 1544 	ret
                                   1545 
                                   1546 	.area CSEG (CODE)
                                   1547 ; function ak820_outline_0020
      004AB8                       1548 _ak820_outline_0020:
      004AB8 EF               [12] 1549 	mov	a,r7
      004AB9 24 AE            [12] 1550 	add	a,#_source_state
      004ABB FD               [12] 1551 	mov	r5,a
      004ABC E4               [12] 1552 	clr	a
      004ABD 34 05            [12] 1553 	addc	a,#(_source_state>>8)
      004ABF FE               [12] 1554 	mov	r6,a
      004AC0 8D 82            [24] 1555 	mov	dpl,r5
      004AC2 8E 83            [24] 1556 	mov	dph,r6
      004AC4 E0               [24] 1557 	movx	a,@dptr
      004AC5 FC               [12] 1558 	mov	r4,a
      004AC6 22               [24] 1559 	ret
                                   1560 
                                   1561 	.area CSEG (CODE)
                                   1562 ; function ak820_outline_0024
      004AC7                       1563 _ak820_outline_0024:
      004AC7 90 0D F2         [24] 1564 	mov	dptr,#___memcpy_PARM_2
      004ACA EC               [12] 1565 	mov	a,r4
      004ACB F0               [24] 1566 	movx	@dptr,a
      004ACC ED               [12] 1567 	mov	a,r5
      004ACD A3               [24] 1568 	inc	dptr
      004ACE F0               [24] 1569 	movx	@dptr,a
      004ACF E4               [12] 1570 	clr	a
      004AD0 A3               [24] 1571 	inc	dptr
      004AD1 F0               [24] 1572 	movx	@dptr,a
      004AD2 90 0D F5         [24] 1573 	mov	dptr,#___memcpy_PARM_3
      004AD5 74 02            [12] 1574 	mov	a,#0x02
      004AD7 F0               [24] 1575 	movx	@dptr,a
      004AD8 E4               [12] 1576 	clr	a
      004AD9 A3               [24] 1577 	inc	dptr
      004ADA F0               [24] 1578 	movx	@dptr,a
      004ADB 90 06 34         [24] 1579 	mov	dptr,#_ak820_tapping_source_PARM_1
      004ADE F5 F0            [12] 1580 	mov	b,a
      004AE0 22               [24] 1581 	ret
                                   1582 
                                   1583 	.area CSEG (CODE)
                                   1584 ; function ak820_outline_0032
      004AE1                       1585 _ak820_outline_0032:
      004AE1 2E               [12] 1586 	add	a,r6
      004AE2 FA               [12] 1587 	mov	r2,a
      004AE3 E4               [12] 1588 	clr	a
      004AE4 3F               [12] 1589 	addc	a,r7
      004AE5 FB               [12] 1590 	mov	r3,a
      004AE6 8A 82            [24] 1591 	mov	dpl,r2
      004AE8 8B 83            [24] 1592 	mov	dph,r3
      004AEA E0               [24] 1593 	movx	a,@dptr
      004AEB 22               [24] 1594 	ret
                                   1595 
                                   1596 	.area CSEG (CODE)
                                   1597 ; function ak820_outline_0033
      004AEC                       1598 _ak820_outline_0033:
      004AEC 2E               [12] 1599 	add	a,r6
      004AED FC               [12] 1600 	mov	r4,a
      004AEE E4               [12] 1601 	clr	a
      004AEF 3F               [12] 1602 	addc	a,r7
      004AF0 FD               [12] 1603 	mov	r5,a
      004AF1 8C 82            [24] 1604 	mov	dpl,r4
      004AF3 8D 83            [24] 1605 	mov	dph,r5
      004AF5 E0               [24] 1606 	movx	a,@dptr
      004AF6 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0056
      004AF7                       1611 _ak820_outline_0056:
      004AF7 FC               [12] 1612 	mov	r4,a
      004AF8 8B 82            [24] 1613 	mov	dpl,r3
      004AFA 8C 83            [24] 1614 	mov	dph,r4
      004AFC E0               [24] 1615 	movx	a,@dptr
      004AFD FA               [12] 1616 	mov	r2,a
      004AFE 22               [24] 1617 	ret
                                   1618 
                                   1619 	.area CSEG (CODE)
                                   1620 ; function ak820_outline_0060
      004AFF                       1621 _ak820_outline_0060:
      004AFF EE               [12] 1622 	mov	a,r6
      004B00 F0               [24] 1623 	movx	@dptr,a
      004B01 EF               [12] 1624 	mov	a,r7
      004B02 A3               [24] 1625 	inc	dptr
      004B03 F0               [24] 1626 	movx	@dptr,a
      004B04 22               [24] 1627 	ret
                                   1628 
                                   1629 	.area CSEG (CODE)
                                   1630 ; function ak820_outline_0076
      004B05                       1631 _ak820_outline_0076:
      004B05 8E 00            [24] 1632 	mov	ar0,r6
      004B07 8F 01            [24] 1633 	mov	ar1,r7
      004B09 7A 00            [12] 1634 	mov	r2,#0x00
      004B0B 22               [24] 1635 	ret
                                   1636 
                                   1637 	.area CSEG (CODE)
                                   1638 ; function ak820_outline_0077
      004B0C                       1639 _ak820_outline_0077:
      004B0C 8D 82            [24] 1640 	mov	dpl,r5
      004B0E 8E 83            [24] 1641 	mov	dph,r6
      004B10 E0               [24] 1642 	movx	a,@dptr
      004B11 FC               [12] 1643 	mov	r4,a
      004B12 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0081
      004B13                       1648 _ak820_outline_0081:
      004B13 24 AE            [12] 1649 	add	a,#_source_state
      004B15 FC               [12] 1650 	mov	r4,a
      004B16 E4               [12] 1651 	clr	a
      004B17 34 05            [12] 1652 	addc	a,#(_source_state>>8)
      004B19 FD               [12] 1653 	mov	r5,a
      004B1A 8C 82            [24] 1654 	mov	dpl,r4
      004B1C 8D 83            [24] 1655 	mov	dph,r5
      004B1E E0               [24] 1656 	movx	a,@dptr
      004B1F FB               [12] 1657 	mov	r3,a
      004B20 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0096
      004B21                       1662 _ak820_outline_0096:
      004B21 88 82            [24] 1663 	mov	dpl,r0
      004B23 89 83            [24] 1664 	mov	dph,r1
      004B25 8A F0            [24] 1665 	mov	b,r2
      004B27 22               [24] 1666 	ret
                                   1667 
                                   1668 	.area CSEG (CODE)
                                   1669 ; function ak820_outline_0099
      004B28                       1670 _ak820_outline_0099:
      004B28 74 04            [12] 1671 	mov	a,#0x04
      004B2A 2E               [12] 1672 	add	a,r6
      004B2B FB               [12] 1673 	mov	r3,a
      004B2C E4               [12] 1674 	clr	a
      004B2D 3F               [12] 1675 	addc	a,r7
      004B2E FC               [12] 1676 	mov	r4,a
      004B2F 8B 82            [24] 1677 	mov	dpl,r3
      004B31 8C 83            [24] 1678 	mov	dph,r4
      004B33 E0               [24] 1679 	movx	a,@dptr
      004B34 22               [24] 1680 	ret
                                   1681 
                                   1682 	.area CSEG (CODE)
                                   1683 ; function ak820_outline_0161
      004B35                       1684 _ak820_outline_0161:
      004B35 90 0E 03         [24] 1685 	mov	dptr,#_pending
      004B38 74 FF            [12] 1686 	mov	a,#0xff
      004B3A F0               [24] 1687 	movx	@dptr,a
      004B3B 22               [24] 1688 	ret
