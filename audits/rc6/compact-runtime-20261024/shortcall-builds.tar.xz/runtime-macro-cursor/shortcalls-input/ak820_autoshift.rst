                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_autoshift
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _del_owned_mods
                                     12 	.globl _add_owned_mods
                                     13 	.globl _get_weak_mods
                                     14 	.globl _get_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _process_record
                                     17 	.globl _ADC_START
                                     18 	.globl _S0_R_FIFO
                                     19 	.globl _S0_T_FIFO
                                     20 	.globl _S0_FREE
                                     21 	.globl _S0_IF_BYTE
                                     22 	.globl _S0_IF_FIRST
                                     23 	.globl _S0_IF_OV
                                     24 	.globl _S0_FST_ACT
                                     25 	.globl _CP_RL2
                                     26 	.globl _C_T2
                                     27 	.globl _TR2
                                     28 	.globl _EXEN2
                                     29 	.globl _TCLK
                                     30 	.globl _RCLK
                                     31 	.globl _EXF2
                                     32 	.globl _CAP1F
                                     33 	.globl _TF2
                                     34 	.globl _RI
                                     35 	.globl _TI
                                     36 	.globl _RB8
                                     37 	.globl _TB8
                                     38 	.globl _REN
                                     39 	.globl _SM2
                                     40 	.globl _SM1
                                     41 	.globl _SM0
                                     42 	.globl _IT0
                                     43 	.globl _IE0
                                     44 	.globl _IT1
                                     45 	.globl _IE1
                                     46 	.globl _TR0
                                     47 	.globl _TF0
                                     48 	.globl _TR1
                                     49 	.globl _TF1
                                     50 	.globl _P4_0
                                     51 	.globl _P4_1
                                     52 	.globl _P4_2
                                     53 	.globl _P4_3
                                     54 	.globl _P4_4
                                     55 	.globl _P4_5
                                     56 	.globl _P4_6
                                     57 	.globl _RXD
                                     58 	.globl _TXD
                                     59 	.globl _INT0
                                     60 	.globl _INT1
                                     61 	.globl _T0
                                     62 	.globl _T1
                                     63 	.globl _MOSI1
                                     64 	.globl _MISO1
                                     65 	.globl _SCK1
                                     66 	.globl _P3_0
                                     67 	.globl _P3_1
                                     68 	.globl _P3_2
                                     69 	.globl _P3_3
                                     70 	.globl _P3_4
                                     71 	.globl _P3_5
                                     72 	.globl _P3_6
                                     73 	.globl _P3_7
                                     74 	.globl _CAP1_
                                     75 	.globl _T2_
                                     76 	.globl _CAP2_
                                     77 	.globl _T2EX_
                                     78 	.globl _RXD1
                                     79 	.globl _TXD1
                                     80 	.globl _P2_0
                                     81 	.globl _P2_1
                                     82 	.globl _P2_2
                                     83 	.globl _P2_3
                                     84 	.globl _P2_4
                                     85 	.globl _P2_5
                                     86 	.globl _P2_6
                                     87 	.globl _P2_7
                                     88 	.globl _AIN0
                                     89 	.globl _AIN1
                                     90 	.globl _AIN2
                                     91 	.globl _AIN3
                                     92 	.globl _AIN4
                                     93 	.globl _AIN5
                                     94 	.globl _AIN6
                                     95 	.globl _AIN7
                                     96 	.globl _CAP1
                                     97 	.globl _T2
                                     98 	.globl _CAP2
                                     99 	.globl _T2EX
                                    100 	.globl _INT0_
                                    101 	.globl _SCS
                                    102 	.globl _MOSI
                                    103 	.globl _MISO
                                    104 	.globl _SCK
                                    105 	.globl _RXD1_
                                    106 	.globl _TXD1_
                                    107 	.globl _P1_0
                                    108 	.globl _P1_1
                                    109 	.globl _P1_2
                                    110 	.globl _P1_3
                                    111 	.globl _P1_4
                                    112 	.globl _P1_5
                                    113 	.globl _P1_6
                                    114 	.globl _P1_7
                                    115 	.globl _AIN8
                                    116 	.globl _AIN9
                                    117 	.globl _AIN10
                                    118 	.globl _AIN11
                                    119 	.globl _AIN12
                                    120 	.globl _AIN13
                                    121 	.globl _RXD_
                                    122 	.globl _TXD_
                                    123 	.globl _SCL0
                                    124 	.globl _SDA0
                                    125 	.globl _P0_0
                                    126 	.globl _P0_1
                                    127 	.globl _P0_2
                                    128 	.globl _P0_3
                                    129 	.globl _P0_4
                                    130 	.globl _P0_5
                                    131 	.globl _P0_6
                                    132 	.globl _P0_7
                                    133 	.globl _IE_SPI0
                                    134 	.globl _IE_USB
                                    135 	.globl _IE_ADC
                                    136 	.globl _IE_UART1
                                    137 	.globl _IE_PWM_I2C
                                    138 	.globl _IE_GPIO
                                    139 	.globl _IE_WDOG
                                    140 	.globl _PX0
                                    141 	.globl _PT0
                                    142 	.globl _PX1
                                    143 	.globl _PT1
                                    144 	.globl _PS
                                    145 	.globl _PT2
                                    146 	.globl _PL_FLAG
                                    147 	.globl _PH_FLAG
                                    148 	.globl _EX0
                                    149 	.globl _ET0
                                    150 	.globl _EX1
                                    151 	.globl _ET1
                                    152 	.globl _ES
                                    153 	.globl _ET2
                                    154 	.globl _E_DIS
                                    155 	.globl _EA
                                    156 	.globl _P
                                    157 	.globl _F1
                                    158 	.globl _OV
                                    159 	.globl _RS0
                                    160 	.globl _RS1
                                    161 	.globl _F0
                                    162 	.globl _AC
                                    163 	.globl _CY
                                    164 	.globl _I2CS_INT_ST
                                    165 	.globl _I2CX_INT
                                    166 	.globl _LED_STATUS
                                    167 	.globl _LED_DMA_H
                                    168 	.globl _LED_DMA_L
                                    169 	.globl _LED_DMA
                                    170 	.globl _LED_PWM_OE
                                    171 	.globl _LED_COMMON
                                    172 	.globl _ADC_CHAN
                                    173 	.globl _ADC_DAT_H
                                    174 	.globl _ADC_DAT_L
                                    175 	.globl _ADC_DAT
                                    176 	.globl _ADC_CTRL
                                    177 	.globl _SPI1_CK_SE
                                    178 	.globl _SPI1_CTRL
                                    179 	.globl _SPI1_DATA
                                    180 	.globl _SPI1_STAT
                                    181 	.globl _SIF1
                                    182 	.globl _SBAUD1
                                    183 	.globl _SBUF1
                                    184 	.globl _SCON1
                                    185 	.globl _SPI0_SETUP
                                    186 	.globl _SPI0_CK_SE
                                    187 	.globl _SPI0_CTRL
                                    188 	.globl _SPI0_DATA
                                    189 	.globl _SPI0_STAT
                                    190 	.globl _T2CAP1H
                                    191 	.globl _T2CAP1L
                                    192 	.globl _T2CAP1
                                    193 	.globl _TH2
                                    194 	.globl _TL2
                                    195 	.globl _T2COUNT
                                    196 	.globl _RCAP2H
                                    197 	.globl _RCAP2L
                                    198 	.globl _RCAP2
                                    199 	.globl _T2MOD
                                    200 	.globl _T2CON
                                    201 	.globl _SBUF
                                    202 	.globl _SCON
                                    203 	.globl _TH1
                                    204 	.globl _TH0
                                    205 	.globl _TL1
                                    206 	.globl _TL0
                                    207 	.globl _TMOD
                                    208 	.globl _TCON
                                    209 	.globl _XBUS_AUX
                                    210 	.globl _P7
                                    211 	.globl _P6_DIR
                                    212 	.globl _P6_OUT_PU
                                    213 	.globl _P6_IN
                                    214 	.globl _P5_DIR
                                    215 	.globl _P5_OUT_PU
                                    216 	.globl _P5_IN
                                    217 	.globl _P4_LED_KEY
                                    218 	.globl _P4_DIR_PU
                                    219 	.globl _P4_MOD_OC
                                    220 	.globl _P4
                                    221 	.globl _P3_DIR_PU
                                    222 	.globl _P3_MOD_OC
                                    223 	.globl _P3
                                    224 	.globl _P2_DIR_PU
                                    225 	.globl _P2_MOD_OC
                                    226 	.globl _P2
                                    227 	.globl _P1_DIR_PU
                                    228 	.globl _P1_MOD_OC
                                    229 	.globl _P1
                                    230 	.globl _P0_DIR_PU
                                    231 	.globl _P0_MOD_OC
                                    232 	.globl _P0
                                    233 	.globl _ROM_CTRL
                                    234 	.globl _ROM_DATA_HH
                                    235 	.globl _ROM_DATA_HL
                                    236 	.globl _ROM_DATA_HI
                                    237 	.globl _ROM_ADDR_H
                                    238 	.globl _ROM_ADDR_L
                                    239 	.globl _ROM_ADDR
                                    240 	.globl _GPIO_IE
                                    241 	.globl _IP_EX
                                    242 	.globl _IE_EX
                                    243 	.globl _IP
                                    244 	.globl _IE
                                    245 	.globl _WDOG_COUNT
                                    246 	.globl _RESET_KEEP
                                    247 	.globl _WAKE_CTRL
                                    248 	.globl _CLOCK_CFG
                                    249 	.globl _POWER_CFG
                                    250 	.globl _PCON
                                    251 	.globl _GLOBAL_CFG
                                    252 	.globl _SAFE_MOD
                                    253 	.globl _DPH
                                    254 	.globl _DPL
                                    255 	.globl _SP
                                    256 	.globl _A_INV
                                    257 	.globl _B
                                    258 	.globl _ACC
                                    259 	.globl _PSW
                                    260 	.globl _ak820_autoshift_before
                                    261 	.globl _ak820_autoshift_process
                                    262 	.globl _ak820_autoshift_cancel
                                    263 ;--------------------------------------------------------
                                    264 ; special function registers
                                    265 ;--------------------------------------------------------
                                    266 	.area RSEG    (ABS,DATA)
      000000                        267 	.org 0x0000
                           0000D0   268 _PSW	=	0x00d0
                           0000E0   269 _ACC	=	0x00e0
                           0000F0   270 _B	=	0x00f0
                           0000FD   271 _A_INV	=	0x00fd
                           000081   272 _SP	=	0x0081
                           000082   273 _DPL	=	0x0082
                           000083   274 _DPH	=	0x0083
                           0000A1   275 _SAFE_MOD	=	0x00a1
                           0000B1   276 _GLOBAL_CFG	=	0x00b1
                           000087   277 _PCON	=	0x0087
                           0000BA   278 _POWER_CFG	=	0x00ba
                           0000B9   279 _CLOCK_CFG	=	0x00b9
                           0000A9   280 _WAKE_CTRL	=	0x00a9
                           0000FE   281 _RESET_KEEP	=	0x00fe
                           0000FF   282 _WDOG_COUNT	=	0x00ff
                           0000A8   283 _IE	=	0x00a8
                           0000B8   284 _IP	=	0x00b8
                           0000E8   285 _IE_EX	=	0x00e8
                           0000E9   286 _IP_EX	=	0x00e9
                           0000B2   287 _GPIO_IE	=	0x00b2
                           008584   288 _ROM_ADDR	=	0x8584
                           000084   289 _ROM_ADDR_L	=	0x0084
                           000085   290 _ROM_ADDR_H	=	0x0085
                           008F8E   291 _ROM_DATA_HI	=	0x8f8e
                           00008E   292 _ROM_DATA_HL	=	0x008e
                           00008F   293 _ROM_DATA_HH	=	0x008f
                           000086   294 _ROM_CTRL	=	0x0086
                           000080   295 _P0	=	0x0080
                           0000C4   296 _P0_MOD_OC	=	0x00c4
                           0000C5   297 _P0_DIR_PU	=	0x00c5
                           000090   298 _P1	=	0x0090
                           000092   299 _P1_MOD_OC	=	0x0092
                           000093   300 _P1_DIR_PU	=	0x0093
                           0000A0   301 _P2	=	0x00a0
                           000094   302 _P2_MOD_OC	=	0x0094
                           000095   303 _P2_DIR_PU	=	0x0095
                           0000B0   304 _P3	=	0x00b0
                           000096   305 _P3_MOD_OC	=	0x0096
                           000097   306 _P3_DIR_PU	=	0x0097
                           0000C0   307 _P4	=	0x00c0
                           0000C2   308 _P4_MOD_OC	=	0x00c2
                           0000C3   309 _P4_DIR_PU	=	0x00c3
                           0000C1   310 _P4_LED_KEY	=	0x00c1
                           0000AA   311 _P5_IN	=	0x00aa
                           0000AB   312 _P5_OUT_PU	=	0x00ab
                           0000AC   313 _P5_DIR	=	0x00ac
                           0000AD   314 _P6_IN	=	0x00ad
                           0000AE   315 _P6_OUT_PU	=	0x00ae
                           0000AF   316 _P6_DIR	=	0x00af
                           0000F1   317 _P7	=	0x00f1
                           0000A2   318 _XBUS_AUX	=	0x00a2
                           000088   319 _TCON	=	0x0088
                           000089   320 _TMOD	=	0x0089
                           00008A   321 _TL0	=	0x008a
                           00008B   322 _TL1	=	0x008b
                           00008C   323 _TH0	=	0x008c
                           00008D   324 _TH1	=	0x008d
                           000098   325 _SCON	=	0x0098
                           000099   326 _SBUF	=	0x0099
                           0000C8   327 _T2CON	=	0x00c8
                           0000C9   328 _T2MOD	=	0x00c9
                           00CBCA   329 _RCAP2	=	0xcbca
                           0000CA   330 _RCAP2L	=	0x00ca
                           0000CB   331 _RCAP2H	=	0x00cb
                           00CDCC   332 _T2COUNT	=	0xcdcc
                           0000CC   333 _TL2	=	0x00cc
                           0000CD   334 _TH2	=	0x00cd
                           00CFCE   335 _T2CAP1	=	0xcfce
                           0000CE   336 _T2CAP1L	=	0x00ce
                           0000CF   337 _T2CAP1H	=	0x00cf
                           0000F8   338 _SPI0_STAT	=	0x00f8
                           0000F9   339 _SPI0_DATA	=	0x00f9
                           0000FA   340 _SPI0_CTRL	=	0x00fa
                           0000FB   341 _SPI0_CK_SE	=	0x00fb
                           0000FC   342 _SPI0_SETUP	=	0x00fc
                           0000BC   343 _SCON1	=	0x00bc
                           0000BD   344 _SBUF1	=	0x00bd
                           0000BE   345 _SBAUD1	=	0x00be
                           0000BF   346 _SIF1	=	0x00bf
                           0000B4   347 _SPI1_STAT	=	0x00b4
                           0000B5   348 _SPI1_DATA	=	0x00b5
                           0000B6   349 _SPI1_CTRL	=	0x00b6
                           0000B7   350 _SPI1_CK_SE	=	0x00b7
                           0000F3   351 _ADC_CTRL	=	0x00f3
                           00F5F4   352 _ADC_DAT	=	0xf5f4
                           0000F4   353 _ADC_DAT_L	=	0x00f4
                           0000F5   354 _ADC_DAT_H	=	0x00f5
                           0000F6   355 _ADC_CHAN	=	0x00f6
                           0000A6   356 _LED_COMMON	=	0x00a6
                           0000A7   357 _LED_PWM_OE	=	0x00a7
                           00C7C6   358 _LED_DMA	=	0xc7c6
                           0000C6   359 _LED_DMA_L	=	0x00c6
                           0000C7   360 _LED_DMA_H	=	0x00c7
                           0000F7   361 _LED_STATUS	=	0x00f7
                           0000B3   362 _I2CX_INT	=	0x00b3
                           0000BB   363 _I2CS_INT_ST	=	0x00bb
                                    364 ;--------------------------------------------------------
                                    365 ; special function bits
                                    366 ;--------------------------------------------------------
                                    367 	.area RSEG    (ABS,DATA)
      000000                        368 	.org 0x0000
                           0000D7   369 _CY	=	0x00d7
                           0000D6   370 _AC	=	0x00d6
                           0000D5   371 _F0	=	0x00d5
                           0000D4   372 _RS1	=	0x00d4
                           0000D3   373 _RS0	=	0x00d3
                           0000D2   374 _OV	=	0x00d2
                           0000D1   375 _F1	=	0x00d1
                           0000D0   376 _P	=	0x00d0
                           0000AF   377 _EA	=	0x00af
                           0000AE   378 _E_DIS	=	0x00ae
                           0000AD   379 _ET2	=	0x00ad
                           0000AC   380 _ES	=	0x00ac
                           0000AB   381 _ET1	=	0x00ab
                           0000AA   382 _EX1	=	0x00aa
                           0000A9   383 _ET0	=	0x00a9
                           0000A8   384 _EX0	=	0x00a8
                           0000BF   385 _PH_FLAG	=	0x00bf
                           0000BE   386 _PL_FLAG	=	0x00be
                           0000BD   387 _PT2	=	0x00bd
                           0000BC   388 _PS	=	0x00bc
                           0000BB   389 _PT1	=	0x00bb
                           0000BA   390 _PX1	=	0x00ba
                           0000B9   391 _PT0	=	0x00b9
                           0000B8   392 _PX0	=	0x00b8
                           0000EF   393 _IE_WDOG	=	0x00ef
                           0000EE   394 _IE_GPIO	=	0x00ee
                           0000ED   395 _IE_PWM_I2C	=	0x00ed
                           0000EC   396 _IE_UART1	=	0x00ec
                           0000EB   397 _IE_ADC	=	0x00eb
                           0000E9   398 _IE_USB	=	0x00e9
                           0000E8   399 _IE_SPI0	=	0x00e8
                           000087   400 _P0_7	=	0x0087
                           000086   401 _P0_6	=	0x0086
                           000085   402 _P0_5	=	0x0085
                           000084   403 _P0_4	=	0x0084
                           000083   404 _P0_3	=	0x0083
                           000082   405 _P0_2	=	0x0082
                           000081   406 _P0_1	=	0x0081
                           000080   407 _P0_0	=	0x0080
                           000081   408 _SDA0	=	0x0081
                           000080   409 _SCL0	=	0x0080
                           000083   410 _TXD_	=	0x0083
                           000082   411 _RXD_	=	0x0082
                           000085   412 _AIN13	=	0x0085
                           000084   413 _AIN12	=	0x0084
                           000083   414 _AIN11	=	0x0083
                           000082   415 _AIN10	=	0x0082
                           000081   416 _AIN9	=	0x0081
                           000080   417 _AIN8	=	0x0080
                           000097   418 _P1_7	=	0x0097
                           000096   419 _P1_6	=	0x0096
                           000095   420 _P1_5	=	0x0095
                           000094   421 _P1_4	=	0x0094
                           000093   422 _P1_3	=	0x0093
                           000092   423 _P1_2	=	0x0092
                           000091   424 _P1_1	=	0x0091
                           000090   425 _P1_0	=	0x0090
                           000097   426 _TXD1_	=	0x0097
                           000096   427 _RXD1_	=	0x0096
                           000097   428 _SCK	=	0x0097
                           000096   429 _MISO	=	0x0096
                           000095   430 _MOSI	=	0x0095
                           000094   431 _SCS	=	0x0094
                           000092   432 _INT0_	=	0x0092
                           000091   433 _T2EX	=	0x0091
                           000091   434 _CAP2	=	0x0091
                           000090   435 _T2	=	0x0090
                           000090   436 _CAP1	=	0x0090
                           000097   437 _AIN7	=	0x0097
                           000096   438 _AIN6	=	0x0096
                           000095   439 _AIN5	=	0x0095
                           000094   440 _AIN4	=	0x0094
                           000093   441 _AIN3	=	0x0093
                           000092   442 _AIN2	=	0x0092
                           000091   443 _AIN1	=	0x0091
                           000090   444 _AIN0	=	0x0090
                           0000A7   445 _P2_7	=	0x00a7
                           0000A6   446 _P2_6	=	0x00a6
                           0000A5   447 _P2_5	=	0x00a5
                           0000A4   448 _P2_4	=	0x00a4
                           0000A3   449 _P2_3	=	0x00a3
                           0000A2   450 _P2_2	=	0x00a2
                           0000A1   451 _P2_1	=	0x00a1
                           0000A0   452 _P2_0	=	0x00a0
                           0000A7   453 _TXD1	=	0x00a7
                           0000A6   454 _RXD1	=	0x00a6
                           0000A5   455 _T2EX_	=	0x00a5
                           0000A5   456 _CAP2_	=	0x00a5
                           0000A4   457 _T2_	=	0x00a4
                           0000A4   458 _CAP1_	=	0x00a4
                           0000B7   459 _P3_7	=	0x00b7
                           0000B6   460 _P3_6	=	0x00b6
                           0000B5   461 _P3_5	=	0x00b5
                           0000B4   462 _P3_4	=	0x00b4
                           0000B3   463 _P3_3	=	0x00b3
                           0000B2   464 _P3_2	=	0x00b2
                           0000B1   465 _P3_1	=	0x00b1
                           0000B0   466 _P3_0	=	0x00b0
                           0000B7   467 _SCK1	=	0x00b7
                           0000B6   468 _MISO1	=	0x00b6
                           0000B5   469 _MOSI1	=	0x00b5
                           0000B5   470 _T1	=	0x00b5
                           0000B4   471 _T0	=	0x00b4
                           0000B3   472 _INT1	=	0x00b3
                           0000B2   473 _INT0	=	0x00b2
                           0000B1   474 _TXD	=	0x00b1
                           0000B0   475 _RXD	=	0x00b0
                           0000C6   476 _P4_6	=	0x00c6
                           0000C5   477 _P4_5	=	0x00c5
                           0000C4   478 _P4_4	=	0x00c4
                           0000C3   479 _P4_3	=	0x00c3
                           0000C2   480 _P4_2	=	0x00c2
                           0000C1   481 _P4_1	=	0x00c1
                           0000C0   482 _P4_0	=	0x00c0
                           00008F   483 _TF1	=	0x008f
                           00008E   484 _TR1	=	0x008e
                           00008D   485 _TF0	=	0x008d
                           00008C   486 _TR0	=	0x008c
                           00008B   487 _IE1	=	0x008b
                           00008A   488 _IT1	=	0x008a
                           000089   489 _IE0	=	0x0089
                           000088   490 _IT0	=	0x0088
                           00009F   491 _SM0	=	0x009f
                           00009E   492 _SM1	=	0x009e
                           00009D   493 _SM2	=	0x009d
                           00009C   494 _REN	=	0x009c
                           00009B   495 _TB8	=	0x009b
                           00009A   496 _RB8	=	0x009a
                           000099   497 _TI	=	0x0099
                           000098   498 _RI	=	0x0098
                           0000CF   499 _TF2	=	0x00cf
                           0000CF   500 _CAP1F	=	0x00cf
                           0000CE   501 _EXF2	=	0x00ce
                           0000CD   502 _RCLK	=	0x00cd
                           0000CC   503 _TCLK	=	0x00cc
                           0000CB   504 _EXEN2	=	0x00cb
                           0000CA   505 _TR2	=	0x00ca
                           0000C9   506 _C_T2	=	0x00c9
                           0000C8   507 _CP_RL2	=	0x00c8
                           0000FF   508 _S0_FST_ACT	=	0x00ff
                           0000FE   509 _S0_IF_OV	=	0x00fe
                           0000FD   510 _S0_IF_FIRST	=	0x00fd
                           0000FC   511 _S0_IF_BYTE	=	0x00fc
                           0000FB   512 _S0_FREE	=	0x00fb
                           0000FA   513 _S0_T_FIFO	=	0x00fa
                           0000F8   514 _S0_R_FIFO	=	0x00f8
                           0000F7   515 _ADC_START	=	0x00f7
                                    516 ;--------------------------------------------------------
                                    517 ; overlayable register banks
                                    518 ;--------------------------------------------------------
                                    519 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        520 	.ds 8
                                    521 ;--------------------------------------------------------
                                    522 ; internal ram data
                                    523 ;--------------------------------------------------------
                                    524 	.area DSEG    (DATA)
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable items in internal ram
                                    527 ;--------------------------------------------------------
                                    528 ;--------------------------------------------------------
                                    529 ; indirectly addressable internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area ISEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; absolute internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area IABS    (ABS,DATA)
                                    536 	.area IABS    (ABS,DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; bit data
                                    539 ;--------------------------------------------------------
                                    540 	.area BSEG    (BIT)
      000000                        541 _ak820_autoshift_process_sloc0_1_0:
      000000                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000400                        551 _as_saved:
      000400                        552 	.ds 9
      000409                        553 _as_state:
      000409                        554 	.ds 1
      00040A                        555 _as_emit_shifted_10000_591:
      00040A                        556 	.ds 1
      00040B                        557 _ak820_autoshift_before_event_10000_594:
      00040B                        558 	.ds 2
      00040D                        559 _ak820_autoshift_before_state_50001_608:
      00040D                        560 	.ds 1
      00040E                        561 _ak820_autoshift_process_record_10000_612:
      00040E                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; absolute external ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area XABS    (ABS,XDATA)
                                    567 ;--------------------------------------------------------
                                    568 ; initialized external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area XISEG   (XDATA)
      000E00                        571 _as_enabled:
      000E00                        572 	.ds 1
                                    573 	.area HOME    (CODE)
                                    574 	.area GSINIT0 (CODE)
                                    575 	.area GSINIT1 (CODE)
                                    576 	.area GSINIT2 (CODE)
                                    577 	.area GSINIT3 (CODE)
                                    578 	.area GSINIT4 (CODE)
                                    579 	.area GSINIT5 (CODE)
                                    580 	.area GSINIT  (CODE)
                                    581 	.area GSFINAL (CODE)
                                    582 	.area CSEG    (CODE)
                                    583 ;--------------------------------------------------------
                                    584 ; global & static initialisations
                                    585 ;--------------------------------------------------------
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT  (CODE)
                                    588 	.area GSFINAL (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; Home
                                    592 ;--------------------------------------------------------
                                    593 	.area HOME    (CODE)
                                    594 	.area HOME    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; code
                                    597 ;--------------------------------------------------------
                                    598 	.area CSEG    (CODE)
                                    599 ;------------------------------------------------------------
                                    600 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    601 ;------------------------------------------------------------
                                    602 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    603 ;------------------------------------------------------------
                                    604 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    605 ;	-----------------------------------------
                           000007   606 	ar7 = 0x07
                           000006   607 	ar6 = 0x06
                           000005   608 	ar5 = 0x05
                           000004   609 	ar4 = 0x04
                           000003   610 	ar3 = 0x03
                           000002   611 	ar2 = 0x02
                           000001   612 	ar1 = 0x01
                           000000   613 	ar0 = 0x00
                                    614 ;	 function as_emit
                                    615 ;	-----------------------------------------
      003136                        616 _as_emit:
      003136 E5 82            [12]  617 	mov	a,dpl
      003138 90 04 0A         [24]  618 	mov	dptr,#_as_emit_shifted_10000_591
      00313B F0               [24]  619 	movx	@dptr,a
                                    620 ;	keyboards/ajazz/ak820/ak820_autoshift.c:13: as_state = shifted ? 3 : 2;
      00313C E0               [24]  621 	movx	a,@dptr
      00313D FF               [12]  622 	mov	r7,a
      00313E E0               [24]  623 	movx	a,@dptr
      00313F 60 04            [24]  624 	jz	00105$
      003141 7E 03            [12]  625 	mov	r6,#0x03
      003143 80 02            [24]  626 	sjmp	00106$
      003145                        627 00105$:
      003145 7E 02            [12]  628 	mov	r6,#0x02
      003147                        629 00106$:
      003147 90 04 09         [24]  630 	mov	dptr,#_as_state
      00314A EE               [12]  631 	mov	a,r6
      00314B F0               [24]  632 	movx	@dptr,a
                                    633 ;	keyboards/ajazz/ak820/ak820_autoshift.c:14: if (shifted) add_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
      00314C EF               [12]  634 	mov	a,r7
      00314D 60 06            [24]  635 	jz	00102$
      00314F 75 82 02         [24]  636 	mov	dpl, #0x02
      003152 12 82 68         [24]  637 	lcall	_add_owned_mods
      003155                        638 00102$:
                                    639 ;	keyboards/ajazz/ak820/ak820_autoshift.c:15: process_record(&as_saved);
      003155 90 04 00         [24]  640 	mov	dptr,#_as_saved
      003158 75 F0 00         [24]  641 	mov	b, #0x00
                                    642 ;	keyboards/ajazz/ak820/ak820_autoshift.c:16: }
      00315B 02 76 24         [24]  643 	ljmp	_process_record
                                    644 ;------------------------------------------------------------
                                    645 ;Allocation info for local variables in function 'ak820_autoshift_before'
                                    646 ;------------------------------------------------------------
                                    647 ;event         Allocated with name '_ak820_autoshift_before_event_10000_594'
                                    648 ;state         Allocated with name '_ak820_autoshift_before_state_50001_608'
                                    649 ;------------------------------------------------------------
                                    650 ;	keyboards/ajazz/ak820/ak820_autoshift.c:17: bool ak820_autoshift_before(const keyevent_t AK820_STATE_MEM *event) {
                                    651 ;	-----------------------------------------
                                    652 ;	 function ak820_autoshift_before
                                    653 ;	-----------------------------------------
      00315E                        654 _ak820_autoshift_before:
      00315E AF 83            [24]  655 	mov	r7,dph
      003160 E5 82            [12]  656 	mov	a,dpl
      003162 90 04 0B         [24]  657 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003165 F0               [24]  658 	movx	@dptr,a
      003166 EF               [12]  659 	mov	a,r7
      003167 A3               [24]  660 	inc	dptr
      003168 F0               [24]  661 	movx	@dptr,a
                                    662 ;	keyboards/ajazz/ak820/ak820_autoshift.c:18: if (!as_state) return true;
      003169 90 04 09         [24]  663 	mov	dptr,#_as_state
      00316C E0               [24]  664 	movx	a,@dptr
      00316D FF               [12]  665 	mov	r7,a
      00316E E0               [24]  666 	movx	a,@dptr
      00316F 70 04            [24]  667 	jnz	00102$
      003171 75 82 01         [24]  668 	mov	dpl, #0x01
      003174 22               [24]  669 	ret
      003175                        670 00102$:
                                    671 ;	keyboards/ajazz/ak820/ak820_autoshift.c:19: if (as_state == 1 && (uint16_t)(event->time - as_saved.event.time) >= 175) {
      003175 BF 01 3A         [24]  672 	cjne	r7,#0x01,00106$
      003178 90 04 0B         [24]  673 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      00317B E0               [24]  674 	movx	a,@dptr
      00317C FE               [12]  675 	mov	r6,a
      00317D A3               [24]  676 	inc	dptr
      00317E E0               [24]  677 	movx	a,@dptr
      00317F FF               [12]  678 	mov	r7,a
      003180 8E 82            [24]  679 	mov	dpl,r6
      003182 8F 83            [24]  680 	mov	dph,r7
      003184 A3               [24]  681 	inc	dptr
      003185 A3               [24]  682 	inc	dptr
      003186 E0               [24]  683 	movx	a,@dptr
      003187 FE               [12]  684 	mov	r6,a
      003188 A3               [24]  685 	inc	dptr
      003189 E0               [24]  686 	movx	a,@dptr
      00318A FF               [12]  687 	mov	r7,a
      00318B 90 04 02         [24]  688 	mov	dptr,#(_as_saved + 0x0002)
      00318E E0               [24]  689 	movx	a,@dptr
      00318F FC               [12]  690 	mov	r4,a
      003190 A3               [24]  691 	inc	dptr
      003191 E0               [24]  692 	movx	a,@dptr
      003192 FD               [12]  693 	mov	r5,a
      003193 EE               [12]  694 	mov	a,r6
      003194 C3               [12]  695 	clr	c
      003195 9C               [12]  696 	subb	a,r4
      003196 FE               [12]  697 	mov	r6,a
      003197 EF               [12]  698 	mov	a,r7
      003198 9D               [12]  699 	subb	a,r5
      003199 FF               [12]  700 	mov	r7,a
      00319A C3               [12]  701 	clr	c
      00319B EE               [12]  702 	mov	a,r6
      00319C 94 AF            [12]  703 	subb	a,#0xaf
      00319E EF               [12]  704 	mov	a,r7
      00319F 94 00            [12]  705 	subb	a,#0x00
      0031A1 40 0F            [24]  706 	jc	00106$
                                    707 ;	keyboards/ajazz/ak820/ak820_autoshift.c:20: as_emit(true);
      0031A3 75 82 01         [24]  708 	mov	dpl, #0x01
      0031A6 12 31 36         [24]  709 	lcall	_as_emit
                                    710 ;	keyboards/ajazz/ak820/ak820_autoshift.c:21: if (!as_state) return false;
      0031A9 90 04 09         [24]  711 	mov	dptr,#_as_state
      0031AC E0               [24]  712 	movx	a,@dptr
      0031AD 70 03            [24]  713 	jnz	00106$
      0031AF F5 82            [12]  714 	mov	dpl,a
      0031B1 22               [24]  715 	ret
      0031B2                        716 00106$:
                                    717 ;	keyboards/ajazz/ak820/ak820_autoshift.c:23: if (IS_NOEVENT(*event)) return true;
      0031B2 90 04 0B         [24]  718 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      0031B5 E0               [24]  719 	movx	a,@dptr
      0031B6 FE               [12]  720 	mov	r6,a
      0031B7 A3               [24]  721 	inc	dptr
      0031B8 E0               [24]  722 	movx	a,@dptr
      0031B9 FF               [12]  723 	mov	r7,a
      0031BA 74 04            [12]  724 	mov	a,#0x04
      0031BC 2E               [12]  725 	add	a, r6
      0031BD FC               [12]  726 	mov	r4,a
      0031BE E4               [12]  727 	clr	a
      0031BF 3F               [12]  728 	addc	a, r7
      0031C0 FD               [12]  729 	mov	r5,a
      0031C1 8C 82            [24]  730 	mov	dpl,r4
      0031C3 8D 83            [24]  731 	mov	dph,r5
      0031C5 E0               [24]  732 	movx	a,@dptr
      0031C6 70 04            [24]  733 	jnz	00109$
      0031C8 75 82 01         [24]  734 	mov	dpl, #0x01
      0031CB 22               [24]  735 	ret
      0031CC                        736 00109$:
                                    737 ;	keyboards/ajazz/ak820/ak820_autoshift.c:24: if (event->key.row == as_saved.event.key.row && event->key.col == as_saved.event.key.col) {
      0031CC 8E 82            [24]  738 	mov	dpl,r6
      0031CE 8F 83            [24]  739 	mov	dph,r7
      0031D0 A3               [24]  740 	inc	dptr
      0031D1 E0               [24]  741 	movx	a,@dptr
      0031D2 FD               [12]  742 	mov	r5,a
      0031D3 90 04 01         [24]  743 	mov	dptr,#(_as_saved + 0x0001)
      0031D6 E0               [24]  744 	movx	a,@dptr
      0031D7 FC               [12]  745 	mov	r4,a
      0031D8 ED               [12]  746 	mov	a,r5
      0031D9 B5 04 62         [24]  747 	cjne	a,ar4,00119$
      0031DC 8E 82            [24]  748 	mov	dpl,r6
      0031DE 8F 83            [24]  749 	mov	dph,r7
      0031E0 E0               [24]  750 	movx	a,@dptr
      0031E1 FD               [12]  751 	mov	r5,a
      0031E2 90 04 00         [24]  752 	mov	dptr,#_as_saved
      0031E5 E0               [24]  753 	movx	a,@dptr
      0031E6 FC               [12]  754 	mov	r4,a
      0031E7 ED               [12]  755 	mov	a,r5
      0031E8 B5 04 53         [24]  756 	cjne	a,ar4,00119$
                                    757 ;	keyboards/ajazz/ak820/ak820_autoshift.c:25: if (!event->pressed) {
      0031EB 74 05            [12]  758 	mov	a,#0x05
      0031ED 2E               [12]  759 	add	a, r6
      0031EE FE               [12]  760 	mov	r6,a
      0031EF E4               [12]  761 	clr	a
      0031F0 3F               [12]  762 	addc	a, r7
      0031F1 FF               [12]  763 	mov	r7,a
      0031F2 8E 82            [24]  764 	mov	dpl,r6
      0031F4 8F 83            [24]  765 	mov	dph,r7
      0031F6 E0               [24]  766 	movx	a,@dptr
      0031F7 70 41            [24]  767 	jnz	00117$
                                    768 ;	keyboards/ajazz/ak820/ak820_autoshift.c:26: if (as_state == 1) {
      0031F9 90 04 09         [24]  769 	mov	dptr,#_as_state
      0031FC E0               [24]  770 	movx	a,@dptr
      0031FD FF               [12]  771 	mov	r7,a
      0031FE BF 01 0F         [24]  772 	cjne	r7,#0x01,00113$
                                    773 ;	keyboards/ajazz/ak820/ak820_autoshift.c:27: as_emit(false);
      003201 75 82 00         [24]  774 	mov	dpl, #0x00
      003204 12 31 36         [24]  775 	lcall	_as_emit
                                    776 ;	keyboards/ajazz/ak820/ak820_autoshift.c:28: if (!as_state) return false;
      003207 90 04 09         [24]  777 	mov	dptr,#_as_state
      00320A E0               [24]  778 	movx	a,@dptr
      00320B 70 03            [24]  779 	jnz	00113$
      00320D F5 82            [12]  780 	mov	dpl,a
      00320F 22               [24]  781 	ret
      003210                        782 00113$:
                                    783 ;	keyboards/ajazz/ak820/ak820_autoshift.c:30: uint8_t state = as_state;
      003210 90 04 09         [24]  784 	mov	dptr,#_as_state
      003213 E0               [24]  785 	movx	a,@dptr
      003214 90 04 0D         [24]  786 	mov	dptr,#_ak820_autoshift_before_state_50001_608
      003217 F0               [24]  787 	movx	@dptr,a
                                    788 ;	keyboards/ajazz/ak820/ak820_autoshift.c:31: as_state = 0;
      003218 90 04 09         [24]  789 	mov	dptr,#_as_state
      00321B E4               [12]  790 	clr	a
      00321C F0               [24]  791 	movx	@dptr,a
                                    792 ;	keyboards/ajazz/ak820/ak820_autoshift.c:32: as_saved.event.pressed = false;
      00321D 90 04 05         [24]  793 	mov	dptr,#(_as_saved + 0x0005)
      003220 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_autoshift.c:33: process_record(&as_saved);
      003221 90 04 00         [24]  796 	mov	dptr,#_as_saved
      003224 F5 F0            [12]  797 	mov	b,a
      003226 12 76 24         [24]  798 	lcall	_process_record
                                    799 ;	keyboards/ajazz/ak820/ak820_autoshift.c:34: if (state == 3) {
      003229 90 04 0D         [24]  800 	mov	dptr,#_ak820_autoshift_before_state_50001_608
      00322C E0               [24]  801 	movx	a,@dptr
      00322D FF               [12]  802 	mov	r7,a
      00322E BF 03 09         [24]  803 	cjne	r7,#0x03,00117$
                                    804 ;	keyboards/ajazz/ak820/ak820_autoshift.c:35: del_owned_mods(MOD_BIT(KC_LEFT_SHIFT));
      003231 75 82 02         [24]  805 	mov	dpl, #0x02
      003234 12 82 78         [24]  806 	lcall	_del_owned_mods
                                    807 ;	keyboards/ajazz/ak820/ak820_autoshift.c:36: send_keyboard_report();
      003237 12 85 A9         [24]  808 	lcall	_send_keyboard_report
      00323A                        809 00117$:
                                    810 ;	keyboards/ajazz/ak820/ak820_autoshift.c:39: return false;
      00323A 75 82 00         [24]  811 	mov	dpl, #0x00
      00323D 22               [24]  812 	ret
      00323E                        813 00119$:
                                    814 ;	keyboards/ajazz/ak820/ak820_autoshift.c:41: if (as_state == 1 && event->pressed) as_emit(false);
      00323E 90 04 09         [24]  815 	mov	dptr,#_as_state
      003241 E0               [24]  816 	movx	a,@dptr
      003242 FF               [12]  817 	mov	r7,a
      003243 BF 01 1C         [24]  818 	cjne	r7,#0x01,00122$
      003246 90 04 0B         [24]  819 	mov	dptr,#_ak820_autoshift_before_event_10000_594
      003249 E0               [24]  820 	movx	a,@dptr
      00324A FE               [12]  821 	mov	r6,a
      00324B A3               [24]  822 	inc	dptr
      00324C E0               [24]  823 	movx	a,@dptr
      00324D FF               [12]  824 	mov	r7,a
      00324E 74 05            [12]  825 	mov	a,#0x05
      003250 2E               [12]  826 	add	a, r6
      003251 FE               [12]  827 	mov	r6,a
      003252 E4               [12]  828 	clr	a
      003253 3F               [12]  829 	addc	a, r7
      003254 FF               [12]  830 	mov	r7,a
      003255 8E 82            [24]  831 	mov	dpl,r6
      003257 8F 83            [24]  832 	mov	dph,r7
      003259 E0               [24]  833 	movx	a,@dptr
      00325A 60 06            [24]  834 	jz	00122$
      00325C 75 82 00         [24]  835 	mov	dpl, #0x00
      00325F 12 31 36         [24]  836 	lcall	_as_emit
      003262                        837 00122$:
                                    838 ;	keyboards/ajazz/ak820/ak820_autoshift.c:42: return true;
      003262 75 82 01         [24]  839 	mov	dpl, #0x01
                                    840 ;	keyboards/ajazz/ak820/ak820_autoshift.c:43: }
      003265 22               [24]  841 	ret
                                    842 ;------------------------------------------------------------
                                    843 ;Allocation info for local variables in function 'ak820_autoshift_process'
                                    844 ;------------------------------------------------------------
                                    845 ;record        Allocated with name '_ak820_autoshift_process_record_10000_612'
                                    846 ;code          Allocated with name '_ak820_autoshift_process_code_10000_613'
                                    847 ;------------------------------------------------------------
                                    848 ;	keyboards/ajazz/ak820/ak820_autoshift.c:44: bool ak820_autoshift_process(keyrecord_t AK820_STATE_MEM *record) {
                                    849 ;	-----------------------------------------
                                    850 ;	 function ak820_autoshift_process
                                    851 ;	-----------------------------------------
      003266                        852 _ak820_autoshift_process:
      003266 AF 83            [24]  853 	mov	r7,dph
      003268 E5 82            [12]  854 	mov	a,dpl
      00326A 90 04 0E         [24]  855 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      00326D F0               [24]  856 	movx	@dptr,a
      00326E EF               [12]  857 	mov	a,r7
      00326F A3               [24]  858 	inc	dptr
      003270 F0               [24]  859 	movx	@dptr,a
                                    860 ;	keyboards/ajazz/ak820/ak820_autoshift.c:45: uint16_t code = record->keycode;
      003271 90 04 0E         [24]  861 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      003274 E0               [24]  862 	movx	a,@dptr
      003275 FE               [12]  863 	mov	r6,a
      003276 A3               [24]  864 	inc	dptr
      003277 E0               [24]  865 	movx	a,@dptr
      003278 FF               [12]  866 	mov	r7,a
      003279 74 07            [12]  867 	mov	a,#0x07
      00327B 2E               [12]  868 	add	a, r6
      00327C F5 82            [12]  869 	mov	dpl,a
      00327E E4               [12]  870 	clr	a
      00327F 3F               [12]  871 	addc	a, r7
      003280 F5 83            [12]  872 	mov	dph,a
      003282 E0               [24]  873 	movx	a,@dptr
      003283 FC               [12]  874 	mov	r4,a
      003284 A3               [24]  875 	inc	dptr
      003285 E0               [24]  876 	movx	a,@dptr
      003286 FD               [12]  877 	mov	r5,a
                                    878 ;	keyboards/ajazz/ak820/ak820_autoshift.c:46: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) return true;
      003287 8E 82            [24]  879 	mov	dpl,r6
      003289 8F 83            [24]  880 	mov	dph,r7
      00328B A3               [24]  881 	inc	dptr
      00328C E0               [24]  882 	movx	a,@dptr
      00328D FB               [12]  883 	mov	r3,a
      00328E BB 10 00         [24]  884 	cjne	r3,#0x10,00209$
      003291                        885 00209$:
      003291 50 0B            [24]  886 	jnc	00101$
      003293 8E 82            [24]  887 	mov	dpl,r6
      003295 8F 83            [24]  888 	mov	dph,r7
      003297 E0               [24]  889 	movx	a,@dptr
      003298 FB               [12]  890 	mov	r3,a
      003299 BB 08 00         [24]  891 	cjne	r3,#0x08,00211$
      00329C                        892 00211$:
      00329C 40 04            [24]  893 	jc	00102$
      00329E                        894 00101$:
      00329E 75 82 01         [24]  895 	mov	dpl, #0x01
      0032A1 22               [24]  896 	ret
      0032A2                        897 00102$:
                                    898 ;	keyboards/ajazz/ak820/ak820_autoshift.c:47: if (code >= QK_AUTO_SHIFT_ON && code <= QK_AUTO_SHIFT_TOGGLE) {
      0032A2 C3               [12]  899 	clr	c
      0032A3 EC               [12]  900 	mov	a,r4
      0032A4 94 13            [12]  901 	subb	a,#0x13
      0032A6 ED               [12]  902 	mov	a,r5
      0032A7 94 7C            [12]  903 	subb	a,#0x7c
      0032A9 40 40            [24]  904 	jc	00107$
      0032AB 74 15            [12]  905 	mov	a,#0x15
      0032AD 9C               [12]  906 	subb	a,r4
      0032AE 74 7C            [12]  907 	mov	a,#0x7c
      0032B0 9D               [12]  908 	subb	a,r5
      0032B1 40 38            [24]  909 	jc	00107$
                                    910 ;	free result
                                    911 ;	keyboards/ajazz/ak820/ak820_autoshift.c:48: if (record->event.pressed)
      0032B3 74 05            [12]  912 	mov	a,#0x05
      0032B5 2E               [12]  913 	add	a, r6
      0032B6 FE               [12]  914 	mov	r6,a
      0032B7 E4               [12]  915 	clr	a
      0032B8 3F               [12]  916 	addc	a, r7
      0032B9 FF               [12]  917 	mov	r7,a
      0032BA 8E 82            [24]  918 	mov	dpl,r6
      0032BC 8F 83            [24]  919 	mov	dph,r7
      0032BE E0               [24]  920 	movx	a,@dptr
      0032BF 60 26            [24]  921 	jz	00105$
                                    922 ;	keyboards/ajazz/ak820/ak820_autoshift.c:49: as_enabled = code == QK_AUTO_SHIFT_TOGGLE ? !as_enabled : code == QK_AUTO_SHIFT_ON;
      0032C1 BC 15 11         [24]  923 	cjne	r4,#0x15,00123$
      0032C4 BD 7C 0E         [24]  924 	cjne	r5,#0x7c,00123$
      0032C7 90 0E 00         [24]  925 	mov	dptr,#_as_enabled
      0032CA E0               [24]  926 	movx	a,@dptr
      0032CB B4 01 00         [24]  927 	cjne	a,#0x01,00218$
      0032CE                        928 00218$:
      0032CE 92 00            [24]  929 	mov  _ak820_autoshift_process_sloc0_1_0,c
      0032D0 E4               [12]  930 	clr	a
      0032D1 33               [12]  931 	rlc	a
      0032D2 FF               [12]  932 	mov	r7,a
      0032D3 80 09            [24]  933 	sjmp	00124$
      0032D5                        934 00123$:
      0032D5 E4               [12]  935 	clr	a
      0032D6 BC 13 04         [24]  936 	cjne	r4,#0x13,00219$
      0032D9 BD 7C 01         [24]  937 	cjne	r5,#0x7c,00219$
      0032DC 04               [12]  938 	inc	a
      0032DD                        939 00219$:
      0032DD FF               [12]  940 	mov	r7,a
      0032DE                        941 00124$:
      0032DE 90 0E 00         [24]  942 	mov	dptr,#_as_enabled
                                    943 ;	assignBit
      0032E1 EF               [12]  944 	mov	a,r7
      0032E2 24 FF            [12]  945 	add	a,#0xff
      0032E4 E4               [12]  946 	clr	a
      0032E5 33               [12]  947 	rlc	a
      0032E6 F0               [24]  948 	movx	@dptr,a
      0032E7                        949 00105$:
                                    950 ;	keyboards/ajazz/ak820/ak820_autoshift.c:50: return false;
      0032E7 75 82 00         [24]  951 	mov	dpl, #0x00
      0032EA 22               [24]  952 	ret
      0032EB                        953 00107$:
                                    954 ;	keyboards/ajazz/ak820/ak820_autoshift.c:52: if (!as_enabled || as_state || !record->event.pressed || get_mods() || get_weak_mods()) return true;
      0032EB 90 0E 00         [24]  955 	mov	dptr,#_as_enabled
      0032EE E0               [24]  956 	movx	a,@dptr
      0032EF 60 2A            [24]  957 	jz	00109$
      0032F1 90 04 09         [24]  958 	mov	dptr,#_as_state
      0032F4 E0               [24]  959 	movx	a,@dptr
      0032F5 70 24            [24]  960 	jnz	00109$
      0032F7 90 04 0E         [24]  961 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      0032FA E0               [24]  962 	movx	a,@dptr
      0032FB FE               [12]  963 	mov	r6,a
      0032FC A3               [24]  964 	inc	dptr
      0032FD E0               [24]  965 	movx	a,@dptr
      0032FE FF               [12]  966 	mov	r7,a
      0032FF 74 05            [12]  967 	mov	a,#0x05
      003301 2E               [12]  968 	add	a, r6
      003302 FE               [12]  969 	mov	r6,a
      003303 E4               [12]  970 	clr	a
      003304 3F               [12]  971 	addc	a, r7
      003305 FF               [12]  972 	mov	r7,a
      003306 8E 82            [24]  973 	mov	dpl,r6
      003308 8F 83            [24]  974 	mov	dph,r7
      00330A E0               [24]  975 	movx	a,@dptr
      00330B 60 0E            [24]  976 	jz	00109$
      00330D 12 86 14         [24]  977 	lcall	_get_mods
      003310 E5 82            [12]  978 	mov	a, dpl
      003312 70 07            [24]  979 	jnz	00109$
      003314 12 86 2A         [24]  980 	lcall	_get_weak_mods
      003317 E5 82            [12]  981 	mov	a, dpl
      003319 60 04            [24]  982 	jz	00110$
      00331B                        983 00109$:
      00331B 75 82 01         [24]  984 	mov	dpl, #0x01
      00331E 22               [24]  985 	ret
      00331F                        986 00110$:
                                    987 ;	keyboards/ajazz/ak820/ak820_autoshift.c:53: if (!((code >= KC_A && code <= KC_0) ||
      00331F C3               [12]  988 	clr	c
      003320 EC               [12]  989 	mov	a,r4
      003321 94 04            [12]  990 	subb	a,#0x04
      003323 ED               [12]  991 	mov	a,r5
      003324 94 00            [12]  992 	subb	a,#0x00
      003326 40 07            [24]  993 	jc	00119$
      003328 74 27            [12]  994 	mov	a,#0x27
      00332A 9C               [12]  995 	subb	a,r4
      00332B E4               [12]  996 	clr	a
      00332C 9D               [12]  997 	subb	a,r5
      00332D 50 1C            [24]  998 	jnc	00116$
                                    999 ;	free result
      00332F                       1000 00119$:
                                   1001 ;	keyboards/ajazz/ak820/ak820_autoshift.c:54: (code >= KC_MINUS && code <= KC_SLASH) || code == KC_NONUS_BACKSLASH)) return true;
      00332F C3               [12] 1002 	clr	c
      003330 EC               [12] 1003 	mov	a,r4
      003331 94 2D            [12] 1004 	subb	a,#0x2d
      003333 ED               [12] 1005 	mov	a,r5
      003334 94 00            [12] 1006 	subb	a,#0x00
      003336 40 07            [24] 1007 	jc	00120$
      003338 74 38            [12] 1008 	mov	a,#0x38
      00333A 9C               [12] 1009 	subb	a,r4
      00333B E4               [12] 1010 	clr	a
      00333C 9D               [12] 1011 	subb	a,r5
      00333D 50 0C            [24] 1012 	jnc	00116$
                                   1013 ;	free result
      00333F                       1014 00120$:
      00333F BC 64 05         [24] 1015 	cjne	r4,#0x64,00230$
      003342 BD 00 02         [24] 1016 	cjne	r5,#0x00,00230$
      003345 80 04            [24] 1017 	sjmp	00116$
      003347                       1018 00230$:
      003347 75 82 01         [24] 1019 	mov	dpl, #0x01
      00334A 22               [24] 1020 	ret
      00334B                       1021 00116$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_autoshift.c:55: as_saved = *record;
      00334B 90 04 0E         [24] 1023 	mov	dptr,#_ak820_autoshift_process_record_10000_612
      00334E E0               [24] 1024 	movx	a,@dptr
      00334F FD               [12] 1025 	mov	r5,a
      003350 A3               [24] 1026 	inc	dptr
      003351 E0               [24] 1027 	movx	a,@dptr
      003352 FE               [12] 1028 	mov	r6,a
      003353 7F 00            [12] 1029 	mov	r7,#0x00
      003355 90 0D F2         [24] 1030 	mov	dptr,#___memcpy_PARM_2
      003358 ED               [12] 1031 	mov	a,r5
      003359 F0               [24] 1032 	movx	@dptr,a
      00335A EE               [12] 1033 	mov	a,r6
      00335B A3               [24] 1034 	inc	dptr
      00335C F0               [24] 1035 	movx	@dptr,a
      00335D EF               [12] 1036 	mov	a,r7
      00335E A3               [24] 1037 	inc	dptr
      00335F F0               [24] 1038 	movx	@dptr,a
      003360 90 0D F5         [24] 1039 	mov	dptr,#___memcpy_PARM_3
      003363 74 09            [12] 1040 	mov	a,#0x09
      003365 F0               [24] 1041 	movx	@dptr,a
      003366 E4               [12] 1042 	clr	a
      003367 A3               [24] 1043 	inc	dptr
      003368 F0               [24] 1044 	movx	@dptr,a
      003369 90 04 00         [24] 1045 	mov	dptr,#_as_saved
      00336C F5 F0            [12] 1046 	mov	b,a
      00336E 12 BD F6         [24] 1047 	lcall	___memcpy
                                   1048 ;	keyboards/ajazz/ak820/ak820_autoshift.c:56: as_state = 1;
      003371 90 04 09         [24] 1049 	mov	dptr,#_as_state
      003374 74 01            [12] 1050 	mov	a,#0x01
      003376 F0               [24] 1051 	movx	@dptr,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_autoshift.c:57: return false;
      003377 75 82 00         [24] 1053 	mov	dpl, #0x00
                                   1054 ;	keyboards/ajazz/ak820/ak820_autoshift.c:58: }
      00337A 22               [24] 1055 	ret
                                   1056 ;------------------------------------------------------------
                                   1057 ;Allocation info for local variables in function 'ak820_autoshift_cancel'
                                   1058 ;------------------------------------------------------------
                                   1059 ;	keyboards/ajazz/ak820/ak820_autoshift.c:59: void ak820_autoshift_cancel(void) { as_state = 0; }
                                   1060 ;	-----------------------------------------
                                   1061 ;	 function ak820_autoshift_cancel
                                   1062 ;	-----------------------------------------
      00337B                       1063 _ak820_autoshift_cancel:
      00337B 90 04 09         [24] 1064 	mov	dptr,#_as_state
      00337E E4               [12] 1065 	clr	a
      00337F F0               [24] 1066 	movx	@dptr,a
      003380 22               [24] 1067 	ret
                                   1068 	.area CSEG    (CODE)
                                   1069 	.area CONST   (CODE)
                                   1070 	.area XINIT   (CODE)
      00C705                       1071 __xinit__as_enabled:
      00C705 01                    1072 	.db #0x01	;  1
                                   1073 	.area CABS    (ABS,CODE)
