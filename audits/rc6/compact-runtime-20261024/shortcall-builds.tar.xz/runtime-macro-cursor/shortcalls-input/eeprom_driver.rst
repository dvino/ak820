                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000692                         85 _eeprom_read_word_addr_10000_91:
      000692                         86 	.ds 3
      000695                         87 _eeprom_read_word_ret_10000_92:
      000695                         88 	.ds 2
      000697                         89 _eeprom_read_dword_addr_10000_93:
      000697                         90 	.ds 3
      00069A                         91 _eeprom_read_dword_ret_10000_94:
      00069A                         92 	.ds 4
      00069E                         93 _eeprom_write_byte_PARM_2:
      00069E                         94 	.ds 1
      00069F                         95 _eeprom_write_byte_addr_10000_95:
      00069F                         96 	.ds 3
      0006A2                         97 _eeprom_write_word_PARM_2:
      0006A2                         98 	.ds 2
      0006A4                         99 _eeprom_write_word_addr_10000_97:
      0006A4                        100 	.ds 3
      0006A7                        101 _eeprom_write_dword_PARM_2:
      0006A7                        102 	.ds 4
      0006AB                        103 _eeprom_write_dword_addr_10000_99:
      0006AB                        104 	.ds 3
      0006AE                        105 _eeprom_update_byte_PARM_2:
      0006AE                        106 	.ds 1
      0006AF                        107 _eeprom_update_byte_addr_10000_107:
      0006AF                        108 	.ds 3
      0006B2                        109 _eeprom_update_word_PARM_2:
      0006B2                        110 	.ds 2
      0006B4                        111 _eeprom_update_word_addr_10000_111:
      0006B4                        112 	.ds 3
      0006B7                        113 _eeprom_update_dword_PARM_2:
      0006B7                        114 	.ds 4
      0006BB                        115 _eeprom_update_dword_addr_10000_115:
      0006BB                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004FD8                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004FD8 12 45 8F         [24]  170 	lcall	_ak820_outline_0036
      004FDB 90 06 92         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004FDE 12 3A 9B         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004FE1 90 06 95         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004FE4 12 51 E3         [24]  175 	lcall	_ak820_outline_0184
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004FE7 90 06 92         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004FEA 12 51 90         [24]  178 	lcall	_ak820_outline_0012
      004FED 90 05 95         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004FF0 ED               [12]  180 	mov	a,r5
      004FF1 12 3A 9B         [24]  181 	lcall	_ak820_outline_0016
      004FF4 90 05 98         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004FF7 12 51 D5         [24]  183 	lcall	_ak820_outline_0113
      004FFA 90 06 95         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004FFD 12 43 2B         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005000 90 06 95         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005003 12 51 CC         [24]  188 	lcall	_ak820_outline_0093
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005006 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005007                        201 _eeprom_read_dword:
      005007 12 45 8F         [24]  202 	lcall	_ak820_outline_0036
      00500A 90 06 97         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00500D 12 3A 9B         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005010 90 06 9A         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005013 12 51 A1         [24]  207 	lcall	_ak820_outline_0051
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      005016 90 06 97         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005019 12 51 90         [24]  210 	lcall	_ak820_outline_0012
      00501C 90 05 95         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00501F ED               [12]  212 	mov	a,r5
      005020 12 3A 9B         [24]  213 	lcall	_ak820_outline_0016
      005023 90 05 98         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005026 74 04            [12]  215 	mov	a,#0x04
      005028 12 3B 18         [24]  216 	lcall	_ak820_outline_0136
      00502B 90 06 9A         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00502E 12 43 2B         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005031 90 06 9A         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005034 12 51 AA         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005037 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      005038                        234 _eeprom_write_byte:
      005038 12 45 8F         [24]  235 	lcall	_ak820_outline_0036
      00503B 90 06 9F         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00503E 12 3A 9B         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005041 90 06 9F         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005044 12 51 79         [24]  240 	lcall	_ak820_outline_0004
      005047 74 01            [12]  241 	mov	a,#0x01
      005049 12 3B 18         [24]  242 	lcall	_ak820_outline_0136
      00504C 90 06 9E         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      00504F 02 43 B7         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005052                        256 _eeprom_write_word:
      005052 12 45 8F         [24]  257 	lcall	_ak820_outline_0036
      005055 90 06 A4         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005058 12 3A 9B         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00505B 90 06 A4         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00505E 12 51 79         [24]  262 	lcall	_ak820_outline_0004
      005061 12 51 D5         [24]  263 	lcall	_ak820_outline_0113
      005064 90 06 A2         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005067 02 43 B7         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00506A                        277 _eeprom_write_dword:
      00506A 12 45 8F         [24]  278 	lcall	_ak820_outline_0036
      00506D 90 06 AB         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005070 12 3A 9B         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005073 90 06 AB         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005076 12 51 79         [24]  283 	lcall	_ak820_outline_0004
      005079 74 04            [12]  284 	mov	a,#0x04
      00507B 12 3B 18         [24]  285 	lcall	_ak820_outline_0136
      00507E 90 06 A7         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005081 02 43 B7         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005084                        307 _eeprom_update_byte:
      005084 C0 07            [24]  308 	push	ar7
      005086 C0 06            [24]  309 	push	ar6
      005088 C0 05            [24]  310 	push	ar5
      00508A C0 04            [24]  311 	push	ar4
      00508C 12 45 8F         [24]  312 	lcall	_ak820_outline_0036
      00508F 90 06 AF         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005092 12 3A 9B         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005095 90 06 AF         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005098 12 51 6A         [24]  317 	lcall	_ak820_outline_0001
      00509B 12 42 F0         [24]  318 	lcall	_eeprom_read_byte
      00509E AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      0050A0 90 06 AE         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      0050A3 E0               [24]  322 	movx	a,@dptr
      0050A4 FE               [12]  323 	mov	r6,a
      0050A5 EF               [12]  324 	mov	a,r7
      0050A6 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0050A9 80 35            [24]  326 	sjmp	00103$
      0050AB                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0050AB 90 06 AF         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0050AE 12 3A D4         [24]  330 	lcall	_ak820_outline_0061
      0050B1 A3               [24]  331 	inc	dptr
      0050B2 E0               [24]  332 	movx	a,@dptr
      0050B3 FF               [12]  333 	mov	r7,a
      0050B4 90 06 9E         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0050B7 EE               [12]  335 	mov	a,r6
      0050B8 12 3A F2         [24]  336 	lcall	_ak820_outline_0104
      0050BB 8F F0            [24]  337 	mov	b, r7
      0050BD C0 07            [24]  338 	push	ar7
      0050BF C0 06            [24]  339 	push	ar6
      0050C1 C0 05            [24]  340 	push	ar5
      0050C3 C0 04            [24]  341 	push	ar4
      0050C5 C0 03            [24]  342 	push	ar3
      0050C7 C0 02            [24]  343 	push	ar2
      0050C9 C0 01            [24]  344 	push	ar1
      0050CB C0 00            [24]  345 	push	ar0
      0050CD 12 50 38         [24]  346 	lcall	_eeprom_write_byte
      0050D0 D0 00            [24]  347 	pop	ar0
      0050D2 D0 01            [24]  348 	pop	ar1
      0050D4 D0 02            [24]  349 	pop	ar2
      0050D6 D0 03            [24]  350 	pop	ar3
      0050D8 D0 04            [24]  351 	pop	ar4
      0050DA D0 05            [24]  352 	pop	ar5
      0050DC D0 06            [24]  353 	pop	ar6
      0050DE D0 07            [24]  354 	pop	ar7
      0050E0                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0050E0 D0 04            [24]  357 	pop	ar4
      0050E2 D0 05            [24]  358 	pop	ar5
      0050E4 D0 06            [24]  359 	pop	ar6
      0050E6 D0 07            [24]  360 	pop	ar7
      0050E8 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0050E9                        373 _eeprom_update_word:
      0050E9 12 45 8F         [24]  374 	lcall	_ak820_outline_0036
      0050EC 90 06 B4         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0050EF 12 3A 9B         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0050F2 90 06 B4         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0050F5 12 51 6A         [24]  379 	lcall	_ak820_outline_0001
      0050F8 12 4F D8         [24]  380 	lcall	_eeprom_read_word
      0050FB 12 45 D8         [24]  381 	lcall	_ak820_outline_0127
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0050FE 90 06 B2         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      005101 12 3A D4         [24]  384 	lcall	_ak820_outline_0061
      005104 EE               [12]  385 	mov	a,r6
      005105 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      005108 EF               [12]  387 	mov	a,r7
      005109 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      00510C 22               [24]  389 	ret
      00510D                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00510D 90 06 B4         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005110 E0               [24]  393 	movx	a,@dptr
      005111 FB               [12]  394 	mov	r3,a
      005112 A3               [24]  395 	inc	dptr
      005113 12 3A BD         [24]  396 	lcall	_ak820_outline_0052
      005116 90 06 A2         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      005119 12 3A DA         [24]  398 	lcall	_ak820_outline_0072
      00511C 8B 82            [24]  399 	mov	dpl, r3
      00511E 8E 83            [24]  400 	mov	dph, r6
      005120 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      005122 02 50 52         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      005125                        415 _eeprom_update_dword:
      005125 12 45 8F         [24]  416 	lcall	_ak820_outline_0036
      005128 90 06 BB         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00512B 12 3A 9B         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      00512E 90 06 BB         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005131 12 51 6A         [24]  421 	lcall	_ak820_outline_0001
      005134 12 50 07         [24]  422 	lcall	_eeprom_read_dword
      005137 12 51 BB         [24]  423 	lcall	_ak820_outline_0057
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00513A 90 06 B7         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      00513D E0               [24]  426 	movx	a,@dptr
      00513E F8               [12]  427 	mov	r0,a
      00513F A3               [24]  428 	inc	dptr
      005140 12 51 C3         [24]  429 	lcall	_ak820_outline_0092
      005143 EC               [12]  430 	mov	a,r4
      005144 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      005147 ED               [12]  432 	mov	a,r5
      005148 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      00514B EE               [12]  434 	mov	a,r6
      00514C B5 02 05         [24]  435 	cjne	a,ar2,00112$
      00514F EF               [12]  436 	mov	a,r7
      005150 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005153 22               [24]  438 	ret
      005154                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005154 90 06 BB         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005157 12 51 90         [24]  442 	lcall	_ak820_outline_0012
      00515A 90 06 A7         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      00515D E8               [12]  444 	mov	a,r0
      00515E F0               [24]  445 	movx	@dptr,a
      00515F E9               [12]  446 	mov	a,r1
      005160 A3               [24]  447 	inc	dptr
      005161 12 51 DC         [24]  448 	lcall	_ak820_outline_0162
      005164 12 51 99         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      005167 02 50 6A         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0051
                                    465 	.globl _ak820_outline_0052
                                    466 	.globl _ak820_outline_0055
                                    467 	.globl _ak820_outline_0057
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0092
                                    471 	.globl _ak820_outline_0093
                                    472 	.globl _ak820_outline_0104
                                    473 	.globl _ak820_outline_0113
                                    474 	.globl _ak820_outline_0127
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0162
                                    477 	.globl _ak820_outline_0184
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      00516A                        481 _ak820_outline_0001:
      00516A E0               [24]  482 	movx	a,@dptr
      00516B FD               [12]  483 	mov	r5,a
      00516C A3               [24]  484 	inc	dptr
      00516D E0               [24]  485 	movx	a,@dptr
      00516E FE               [12]  486 	mov	r6,a
      00516F A3               [24]  487 	inc	dptr
      005170 E0               [24]  488 	movx	a,@dptr
      005171 FF               [12]  489 	mov	r7,a
      005172 8D 82            [24]  490 	mov	dpl,r5
      005174 8E 83            [24]  491 	mov	dph,r6
      005176 8F F0            [24]  492 	mov	b,r7
      005178 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      005179                        497 _ak820_outline_0004:
      005179 E0               [24]  498 	movx	a,@dptr
      00517A FD               [12]  499 	mov	r5,a
      00517B A3               [24]  500 	inc	dptr
      00517C E0               [24]  501 	movx	a,@dptr
      00517D FE               [12]  502 	mov	r6,a
      00517E A3               [24]  503 	inc	dptr
      00517F E0               [24]  504 	movx	a,@dptr
      005180 FF               [12]  505 	mov	r7,a
      005181 90 05 9E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005184 ED               [12]  507 	mov	a,r5
      005185 F0               [24]  508 	movx	@dptr,a
      005186 EE               [12]  509 	mov	a,r6
      005187 A3               [24]  510 	inc	dptr
      005188 F0               [24]  511 	movx	@dptr,a
      005189 EF               [12]  512 	mov	a,r7
      00518A A3               [24]  513 	inc	dptr
      00518B F0               [24]  514 	movx	@dptr,a
      00518C 90 05 A1         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00518F 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      005190                        520 _ak820_outline_0012:
      005190 E0               [24]  521 	movx	a,@dptr
      005191 FD               [12]  522 	mov	r5,a
      005192 A3               [24]  523 	inc	dptr
      005193 E0               [24]  524 	movx	a,@dptr
      005194 FE               [12]  525 	mov	r6,a
      005195 A3               [24]  526 	inc	dptr
      005196 E0               [24]  527 	movx	a,@dptr
      005197 FF               [12]  528 	mov	r7,a
      005198 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      005199                        533 _ak820_outline_0034:
      005199 F0               [24]  534 	movx	@dptr,a
      00519A 8D 82            [24]  535 	mov	dpl,r5
      00519C 8E 83            [24]  536 	mov	dph,r6
      00519E 8F F0            [24]  537 	mov	b,r7
      0051A0 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0051
      0051A1                        542 _ak820_outline_0051:
      0051A1 E4               [12]  543 	clr	a
      0051A2 F0               [24]  544 	movx	@dptr,a
      0051A3 A3               [24]  545 	inc	dptr
      0051A4 F0               [24]  546 	movx	@dptr,a
      0051A5 A3               [24]  547 	inc	dptr
      0051A6 F0               [24]  548 	movx	@dptr,a
      0051A7 A3               [24]  549 	inc	dptr
      0051A8 F0               [24]  550 	movx	@dptr,a
      0051A9 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      0051AA                        555 _ak820_outline_0055:
      0051AA E0               [24]  556 	movx	a,@dptr
      0051AB FC               [12]  557 	mov	r4,a
      0051AC A3               [24]  558 	inc	dptr
      0051AD E0               [24]  559 	movx	a,@dptr
      0051AE FD               [12]  560 	mov	r5,a
      0051AF A3               [24]  561 	inc	dptr
      0051B0 E0               [24]  562 	movx	a,@dptr
      0051B1 FE               [12]  563 	mov	r6,a
      0051B2 A3               [24]  564 	inc	dptr
      0051B3 E0               [24]  565 	movx	a,@dptr
      0051B4 8C 82            [24]  566 	mov	dpl,r4
      0051B6 8D 83            [24]  567 	mov	dph,r5
      0051B8 8E F0            [24]  568 	mov	b,r6
      0051BA 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0057
      0051BB                        573 _ak820_outline_0057:
      0051BB AC 82            [24]  574 	mov	r4,dpl
      0051BD AD 83            [24]  575 	mov	r5,dph
      0051BF AE F0            [24]  576 	mov	r6,b
      0051C1 FF               [12]  577 	mov	r7,a
      0051C2 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0092
      0051C3                        582 _ak820_outline_0092:
      0051C3 E0               [24]  583 	movx	a,@dptr
      0051C4 F9               [12]  584 	mov	r1,a
      0051C5 A3               [24]  585 	inc	dptr
      0051C6 E0               [24]  586 	movx	a,@dptr
      0051C7 FA               [12]  587 	mov	r2,a
      0051C8 A3               [24]  588 	inc	dptr
      0051C9 E0               [24]  589 	movx	a,@dptr
      0051CA FB               [12]  590 	mov	r3,a
      0051CB 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0093
      0051CC                        595 _ak820_outline_0093:
      0051CC E0               [24]  596 	movx	a,@dptr
      0051CD FE               [12]  597 	mov	r6,a
      0051CE A3               [24]  598 	inc	dptr
      0051CF E0               [24]  599 	movx	a,@dptr
      0051D0 8E 82            [24]  600 	mov	dpl,r6
      0051D2 F5 83            [12]  601 	mov	dph,a
      0051D4 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0113
      0051D5                        606 _ak820_outline_0113:
      0051D5 74 02            [12]  607 	mov	a,#0x02
      0051D7 F0               [24]  608 	movx	@dptr,a
      0051D8 E4               [12]  609 	clr	a
      0051D9 A3               [24]  610 	inc	dptr
      0051DA F0               [24]  611 	movx	@dptr,a
      0051DB 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0162
      0051DC                        616 _ak820_outline_0162:
      0051DC F0               [24]  617 	movx	@dptr,a
      0051DD EA               [12]  618 	mov	a,r2
      0051DE A3               [24]  619 	inc	dptr
      0051DF F0               [24]  620 	movx	@dptr,a
      0051E0 EB               [12]  621 	mov	a,r3
      0051E1 A3               [24]  622 	inc	dptr
      0051E2 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0184
      0051E3                        627 _ak820_outline_0184:
      0051E3 E4               [12]  628 	clr	a
      0051E4 F0               [24]  629 	movx	@dptr,a
      0051E5 A3               [24]  630 	inc	dptr
      0051E6 F0               [24]  631 	movx	@dptr,a
      0051E7 22               [24]  632 	ret
