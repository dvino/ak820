                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000055                        551 _change_owned_sloc1_1_0:
      000055                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000023                        566 _ak820_macro_change_sloc0_1_0:
      000023                        567 	.ds 1
      000024                        568 _change_owned_sloc0_1_0:
      000024                        569 	.ds 1
      000025                        570 _owned_usage_key_sloc0_1_0:
      000025                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      0009FA                        580 _owned_mod_refs:
      0009FA                        581 	.ds 8
      000A02                        582 _owned_weak_refs:
      000A02                        583 	.ds 8
      000A0A                        584 _owned_mods:
      000A0A                        585 	.ds 1
      000A0B                        586 _owned_weak_mods:
      000A0B                        587 	.ds 1
      000A0C                        588 _macro_mods:
      000A0C                        589 	.ds 2
      000A0E                        590 _ak820_macro_primitive::
      000A0E                        591 	.ds 1
      000A0F                        592 _ak820_macro_cancelled::
      000A0F                        593 	.ds 1
      000A10                        594 _ak820_macro_change_PARM_2:
      000A10                        595 	.ds 1
      000A11                        596 _ak820_macro_change_PARM_3:
      000A11                        597 	.ds 1
      000A12                        598 _ak820_macro_change_bits_10000_294:
      000A12                        599 	.ds 2
      000A14                        600 _change_owned_PARM_2:
      000A14                        601 	.ds 1
      000A15                        602 _change_owned_mods_10000_299:
      000A15                        603 	.ds 1
      000A16                        604 _change_owned_result_10001_303:
      000A16                        605 	.ds 1
      000A17                        606 _change_owned_bit_20001_304:
      000A17                        607 	.ds 1
      000A18                        608 _add_owned_mods_mods_10000_312:
      000A18                        609 	.ds 1
      000A19                        610 _del_owned_mods_mods_10000_314:
      000A19                        611 	.ds 1
      000A1A                        612 _add_owned_weak_mods_mods_10000_316:
      000A1A                        613 	.ds 1
      000A1B                        614 _del_owned_weak_mods_mods_10000_318:
      000A1B                        615 	.ds 1
      000A1C                        616 _key_refs:
      000A1C                        617 	.ds 165
      000AC1                        618 _distinct_keys:
      000AC1                        619 	.ds 1
      000AC2                        620 _macro_keys:
      000AC2                        621 	.ds 21
      000AD7                        622 _add_owned_key_code_10000_327:
      000AD7                        623 	.ds 1
      000AD8                        624 _del_owned_key_code_10000_342:
      000AD8                        625 	.ds 1
      000AD9                        626 _usage_refs:
      000AD9                        627 	.ds 30
      000AF7                        628 _usage_order:
      000AF7                        629 	.ds 30
      000B15                        630 _usage_lengths:
      000B15                        631 	.ds 2
      000B17                        632 _macro_usages:
      000B17                        633 	.ds 4
      000B1B                        634 _owned_usage_key_PARM_2:
      000B1B                        635 	.ds 1
      000B1C                        636 _owned_usage_key_code_10000_369:
      000B1C                        637 	.ds 1
      000B1D                        638 _owned_usage_key___200000085_20000_370:
      000B1D                        639 	.ds 2
      000B1F                        640 _owned_usage_key_which_10000_370:
      000B1F                        641 	.ds 1
      000B20                        642 _owned_usage_key_count_10000_370:
      000B20                        643 	.ds 1
      000B21                        644 _owned_usage_key_pos_30001_377:
      000B21                        645 	.ds 1
      000B22                        646 _owned_usage_key_key_40000_382:
      000B22                        647 	.ds 1
      000B23                        648 _send_keyboard_report_last_report_10001_389:
      000B23                        649 	.ds 32
      000B43                        650 _send_keyboard_report_changed_10001_389:
      000B43                        651 	.ds 1
      000B44                        652 _add_weak_mods_mods_10000_407:
      000B44                        653 	.ds 1
      000B45                        654 _del_weak_mods_mods_10000_409:
      000B45                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E4C                        664 _real_mods:
      000E4C                        665 	.ds 1
      000E4D                        666 _weak_mods:
      000E4D                        667 	.ds 1
      000E4E                        668 _actual_keyboard_report::
      000E4E                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      0084CA                        713 _ak820_macro_change:
      0084CA 12 3A C2         [24]  714 	lcall	_ak820_outline_0110
      0084CD 90 0A 12         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0084D0 12 3A C7         [24]  716 	lcall	_ak820_outline_0111
                                    717 ;	quantum/action_util.c:57: if (!ak820_macro_primitive) return true;
      0084D3 90 0A 0E         [24]  718 	mov	dptr,#_ak820_macro_primitive
      0084D6 E0               [24]  719 	movx	a,@dptr
      0084D7 70 04            [24]  720 	jnz	00102$
      0084D9 75 82 01         [24]  721 	mov	dpl, #0x01
      0084DC 22               [24]  722 	ret
      0084DD                        723 00102$:
                                    724 ;	quantum/action_util.c:58: uint8_t mask = 1u << (index & 7);
      0084DD 90 0A 10         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      0084E0 E0               [24]  726 	movx	a,@dptr
      0084E1 FF               [12]  727 	mov	r7,a
      0084E2 74 07            [12]  728 	mov	a,#0x07
      0084E4 5F               [12]  729 	anl	a,r7
      0084E5 12 80 6A         [24]  730 	lcall	_ak820_outline_0063
      0084E8 80 02            [24]  731 	sjmp	00123$
      0084EA                        732 00122$:
      0084EA 25 E0            [12]  733 	add	a,acc
      0084EC                        734 00123$:
      0084EC D5 F0 FB         [24]  735 	djnz	b,00122$
      0084EF FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:59: bits += index >> 3;
      0084F0 EF               [12]  738 	mov	a,r7
      0084F1 12 5F 32         [24]  739 	lcall	_ak820_outline_0191
      0084F4 FF               [12]  740 	mov	r7,a
      0084F5 90 0A 12         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0084F8 12 3A 98         [24]  742 	lcall	_ak820_outline_0061
      0084FB 90 0A 12         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_294
      0084FE EF               [12]  744 	mov	a,r7
      0084FF 2C               [12]  745 	add	a, r4
      008500 F0               [24]  746 	movx	@dptr,a
      008501 E4               [12]  747 	clr	a
      008502 3D               [12]  748 	addc	a, r5
      008503 A3               [24]  749 	inc	dptr
      008504 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:60: if (((*bits & mask) != 0) == pressed) return false;
      008505 90 0A 12         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_294
      008508 E0               [24]  753 	movx	a,@dptr
      008509 FD               [12]  754 	mov	r5,a
      00850A A3               [24]  755 	inc	dptr
      00850B E0               [24]  756 	movx	a,@dptr
      00850C FF               [12]  757 	mov	r7,a
      00850D 12 8A 4C         [24]  758 	lcall	_ak820_outline_0192
      008510 E0               [24]  759 	movx	a,@dptr
      008511 FC               [12]  760 	mov	r4,a
      008512 EE               [12]  761 	mov	a,r6
      008513 5C               [12]  762 	anl	a,r4
      008514 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      008517                        764 00124$:
      008517 B3               [12]  765 	cpl	c
      008518 92 23            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      00851A 90 0A 11         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      00851D E0               [24]  768 	movx	a,@dptr
      00851E FB               [12]  769 	mov	r3,a
      00851F A2 23            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      008521 E4               [12]  771 	clr	a
      008522 33               [12]  772 	rlc	a
      008523 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      008526 75 82 00         [24]  774 	mov	dpl, #0x00
      008529 22               [24]  775 	ret
      00852A                        776 00104$:
                                    777 ;	quantum/action_util.c:61: *bits ^= mask;
      00852A EC               [12]  778 	mov	a,r4
      00852B 62 06            [12]  779 	xrl	ar6,a
      00852D 12 8A 4C         [24]  780 	lcall	_ak820_outline_0192
      008530 EE               [12]  781 	mov	a,r6
      008531 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:62: return true;
      008532 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:63: }
      008535 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_299'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_300'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_300'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_300'
                                    795 ;old           Allocated with name '_change_owned_old_30000_302'
                                    796 ;result        Allocated with name '_change_owned_result_10001_303'
                                    797 ;i             Allocated with name '_change_owned_i_20001_304'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_304'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:64: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      008536                        805 _change_owned:
      008536 E5 82            [12]  806 	mov	a,dpl
      008538 90 0A 15         [24]  807 	mov	dptr,#_change_owned_mods_10000_299
      00853B F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:65: uint8_t kind = mode >> 1;
      00853C 90 0A 14         [24]  810 	mov	dptr,#_change_owned_PARM_2
      00853F E0               [24]  811 	movx	a,@dptr
      008540 FF               [12]  812 	mov	r7,a
      008541 C3               [12]  813 	clr	c
      008542 13               [12]  814 	rrc	a
      008543 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:66: bool pressed = (mode & 1) != 0;
      008544 53 07 01         [24]  817 	anl	ar7,#0x01
      008547 EF               [12]  818 	mov	a,r7
      008548 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      00854B                        820 00205$:
      00854B 92 24            [24]  821 	mov  _change_owned_sloc0_1_0,c
      00854D B3               [12]  822 	cpl	c
      00854E E4               [12]  823 	clr	a
      00854F 33               [12]  824 	rlc	a
      008550 F5 55            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:67: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      008552 EE               [12]  827 	mov	a,r6
      008553 60 06            [24]  828 	jz	00121$
      008555 7D 02            [12]  829 	mov	r5,#_owned_weak_refs
      008557 7F 0A            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      008559 80 04            [24]  831 	sjmp	00122$
      00855B                        832 00121$:
      00855B 7D FA            [12]  833 	mov	r5,#_owned_mod_refs
      00855D 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      00855F                        835 00122$:
                                    836 ;	quantum/action_util.c:68: if (ak820_macro_primitive) {
      00855F 90 0A 0E         [24]  837 	mov	dptr,#_ak820_macro_primitive
      008562 E0               [24]  838 	movx	a,@dptr
      008563 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:69: uint8_t old = macro_mods[kind];
      008565 EE               [12]  841 	mov	a,r6
      008566 24 0C            [12]  842 	add	a, #_macro_mods
      008568 FB               [12]  843 	mov	r3,a
      008569 E4               [12]  844 	clr	a
      00856A 34 0A            [12]  845 	addc	a, #(_macro_mods >> 8)
      00856C 12 4E 01         [24]  846 	lcall	_ak820_outline_0057
                                    847 ;	quantum/action_util.c:70: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00856F E5 55            [12]  848 	mov	a,_change_owned_sloc1_1_0
      008571 60 0A            [24]  849 	jz	00123$
      008573 90 0A 15         [24]  850 	mov	dptr,#_change_owned_mods_10000_299
      008576 E0               [24]  851 	movx	a,@dptr
      008577 F9               [12]  852 	mov	r1,a
      008578 EA               [12]  853 	mov	a,r2
      008579 42 01            [12]  854 	orl	ar1,a
      00857B 80 07            [24]  855 	sjmp	00124$
      00857D                        856 00123$:
      00857D 90 0A 15         [24]  857 	mov	dptr,#_change_owned_mods_10000_299
      008580 E0               [24]  858 	movx	a,@dptr
      008581 F4               [12]  859 	cpl	a
      008582 5A               [12]  860 	anl	a,r2
      008583 F9               [12]  861 	mov	r1,a
      008584                        862 00124$:
      008584 12 36 47         [24]  863 	lcall	_ak820_outline_0125
      008587 E9               [12]  864 	mov	a,r1
      008588 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:71: mods &= pressed ? ~old : old;
      008589 E5 55            [12]  867 	mov	a,_change_owned_sloc1_1_0
      00858B 60 06            [24]  868 	jz	00125$
      00858D 74 FF            [12]  869 	mov	a,#0xff
      00858F 6A               [12]  870 	xrl	a,r2
      008590 FC               [12]  871 	mov	r4,a
      008591 80 02            [24]  872 	sjmp	00126$
      008593                        873 00125$:
      008593 8A 04            [24]  874 	mov	ar4,r2
      008595                        875 00126$:
      008595 90 0A 15         [24]  876 	mov	dptr,#_change_owned_mods_10000_299
      008598 E0               [24]  877 	movx	a,@dptr
      008599 5C               [12]  878 	anl	a,r4
      00859A F0               [24]  879 	movx	@dptr,a
      00859B                        880 00102$:
                                    881 ;	quantum/action_util.c:73: uint8_t result = 0;
      00859B 90 0A 16         [24]  882 	mov	dptr,#_change_owned_result_10001_303
      00859E E4               [12]  883 	clr	a
      00859F F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0085A0 90 0A 17         [24]  886 	mov	dptr,#_change_owned_bit_20001_304
      0085A3 04               [12]  887 	inc	a
      0085A4 F0               [24]  888 	movx	@dptr,a
      0085A5 90 0A 15         [24]  889 	mov	dptr,#_change_owned_mods_10000_299
      0085A8 E0               [24]  890 	movx	a,@dptr
      0085A9 FC               [12]  891 	mov	r4,a
      0085AA 7B 00            [12]  892 	mov	r3,#0x00
      0085AC                        893 00117$:
      0085AC BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      0085AF                        895 00210$:
      0085AF 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:75: if (mods & bit) {
      0085B1 90 0A 17         [24]  898 	mov	dptr,#_change_owned_bit_20001_304
      0085B4 E0               [24]  899 	movx	a,@dptr
      0085B5 5C               [12]  900 	anl	a,r4
      0085B6 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:76: if (pressed) ++refs[i];
      0085B8 E5 55            [12]  903 	mov	a,_change_owned_sloc1_1_0
      0085BA 60 0C            [24]  904 	jz	00106$
      0085BC EB               [12]  905 	mov	a,r3
      0085BD 2D               [12]  906 	add	a, r5
      0085BE 12 3A 67         [24]  907 	lcall	_ak820_outline_0017
      0085C1 F8               [12]  908 	mov	r0,a
      0085C2 08               [12]  909 	inc	r0
      0085C3 12 8A 09         [24]  910 	lcall	_ak820_outline_0064
      0085C6 80 0C            [24]  911 	sjmp	00109$
      0085C8                        912 00106$:
                                    913 ;	quantum/action_util.c:77: else if (refs[i]) --refs[i];
      0085C8 EB               [12]  914 	mov	a,r3
      0085C9 2D               [12]  915 	add	a, r5
      0085CA 12 3A 67         [24]  916 	lcall	_ak820_outline_0017
      0085CD F8               [12]  917 	mov	r0,a
      0085CE 60 04            [24]  918 	jz	00109$
      0085D0 18               [12]  919 	dec	r0
      0085D1 12 8A 09         [24]  920 	lcall	_ak820_outline_0064
      0085D4                        921 00109$:
                                    922 ;	quantum/action_util.c:79: if (refs[i]) result |= bit;
      0085D4 EB               [12]  923 	mov	a,r3
      0085D5 2D               [12]  924 	add	a, r5
      0085D6 12 3A 67         [24]  925 	lcall	_ak820_outline_0017
      0085D9 60 0B            [24]  926 	jz	00118$
      0085DB 90 0A 17         [24]  927 	mov	dptr,#_change_owned_bit_20001_304
      0085DE E0               [24]  928 	movx	a,@dptr
      0085DF FA               [12]  929 	mov	r2,a
      0085E0 90 0A 16         [24]  930 	mov	dptr,#_change_owned_result_10001_303
      0085E3 E0               [24]  931 	movx	a,@dptr
      0085E4 4A               [12]  932 	orl	a,r2
      0085E5 F0               [24]  933 	movx	@dptr,a
      0085E6                        934 00118$:
                                    935 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0085E6 0B               [12]  936 	inc	r3
      0085E7 90 0A 17         [24]  937 	mov	dptr,#_change_owned_bit_20001_304
      0085EA E0               [24]  938 	movx	a,@dptr
      0085EB 25 E0            [12]  939 	add	a,acc
      0085ED F0               [24]  940 	movx	@dptr,a
      0085EE 80 BC            [24]  941 	sjmp	00117$
      0085F0                        942 00112$:
                                    943 ;	quantum/action_util.c:81: if (kind) owned_weak_mods = result;
      0085F0 EE               [12]  944 	mov	a,r6
      0085F1 60 09            [24]  945 	jz	00114$
      0085F3 90 0A 16         [24]  946 	mov	dptr,#_change_owned_result_10001_303
      0085F6 E0               [24]  947 	movx	a,@dptr
      0085F7 90 0A 0B         [24]  948 	mov	dptr,#_owned_weak_mods
      0085FA F0               [24]  949 	movx	@dptr,a
      0085FB 22               [24]  950 	ret
      0085FC                        951 00114$:
                                    952 ;	quantum/action_util.c:82: else owned_mods = result;
      0085FC 90 0A 16         [24]  953 	mov	dptr,#_change_owned_result_10001_303
      0085FF E0               [24]  954 	movx	a,@dptr
      008600 90 0A 0A         [24]  955 	mov	dptr,#_owned_mods
      008603 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:83: }
      008604 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_312'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:84: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      008605                        968 _add_owned_mods:
      008605 E5 82            [12]  969 	mov	a,dpl
      008607 90 0A 18         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_312
      00860A 12 8A 29         [24]  971 	lcall	_ak820_outline_0119
      00860D 12 80 BC         [24]  972 	lcall	_ak820_outline_0166
      008610 A1 36            [12]  973 	ajmp	_change_owned
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'del_owned_mods'
                                    976 ;------------------------------------------------------------
                                    977 ;mods          Allocated with name '_del_owned_mods_mods_10000_314'
                                    978 ;------------------------------------------------------------
                                    979 ;	quantum/action_util.c:85: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    980 ;	-----------------------------------------
                                    981 ;	 function del_owned_mods
                                    982 ;	-----------------------------------------
      008612                        983 _del_owned_mods:
      008612 E5 82            [12]  984 	mov	a,dpl
      008614 90 0A 19         [24]  985 	mov	dptr,#_del_owned_mods_mods_10000_314
      008617 12 8A 29         [24]  986 	lcall	_ak820_outline_0119
      00861A 12 80 C2         [24]  987 	lcall	_ak820_outline_0185
      00861D A1 36            [12]  988 	ajmp	_change_owned
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    991 ;------------------------------------------------------------
                                    992 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_316'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/action_util.c:86: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    995 ;	-----------------------------------------
                                    996 ;	 function add_owned_weak_mods
                                    997 ;	-----------------------------------------
      00861F                        998 _add_owned_weak_mods:
      00861F E5 82            [12]  999 	mov	a,dpl
      008621 90 0A 1A         [24] 1000 	mov	dptr,#_add_owned_weak_mods_mods_10000_316
      008624 12 8A 29         [24] 1001 	lcall	_ak820_outline_0119
      008627 74 03            [12] 1002 	mov	a,#0x03
      008629 F0               [24] 1003 	movx	@dptr,a
      00862A 8F 82            [24] 1004 	mov	dpl, r7
      00862C A1 36            [12] 1005 	ajmp	_change_owned
                                   1006 ;------------------------------------------------------------
                                   1007 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1008 ;------------------------------------------------------------
                                   1009 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_318'
                                   1010 ;------------------------------------------------------------
                                   1011 ;	quantum/action_util.c:87: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1012 ;	-----------------------------------------
                                   1013 ;	 function del_owned_weak_mods
                                   1014 ;	-----------------------------------------
      00862E                       1015 _del_owned_weak_mods:
      00862E E5 82            [12] 1016 	mov	a,dpl
      008630 90 0A 1B         [24] 1017 	mov	dptr,#_del_owned_weak_mods_mods_10000_318
      008633 12 8A 29         [24] 1018 	lcall	_ak820_outline_0119
      008636 74 02            [12] 1019 	mov	a,#0x02
      008638 F0               [24] 1020 	movx	@dptr,a
      008639 8F 82            [24] 1021 	mov	dpl, r7
      00863B A1 36            [12] 1022 	ajmp	_change_owned
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1025 ;------------------------------------------------------------
                                   1026 ;i             Allocated with name '_clear_owned_mods_i_20000_322'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	quantum/action_util.c:88: void clear_owned_mods(void) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function clear_owned_mods
                                   1031 ;	-----------------------------------------
      00863D                       1032 _clear_owned_mods:
                                   1033 ;	quantum/action_util.c:89: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00863D 7F 00            [12] 1034 	mov	r7,#0x00
      00863F                       1035 00103$:
      00863F BF 08 00         [24] 1036 	cjne	r7,#0x08,00122$
      008642                       1037 00122$:
      008642 50 1A            [24] 1038 	jnc	00101$
      008644 EF               [12] 1039 	mov	a,r7
      008645 24 FA            [12] 1040 	add	a, #_owned_mod_refs
      008647 FD               [12] 1041 	mov	r5,a
      008648 E4               [12] 1042 	clr	a
      008649 34 09            [12] 1043 	addc	a, #(_owned_mod_refs >> 8)
      00864B FE               [12] 1044 	mov	r6,a
      00864C EF               [12] 1045 	mov	a,r7
      00864D 24 02            [12] 1046 	add	a, #_owned_weak_refs
      00864F F5 82            [12] 1047 	mov	dpl,a
      008651 E4               [12] 1048 	clr	a
      008652 34 0A            [12] 1049 	addc	a, #(_owned_weak_refs >> 8)
      008654 F5 83            [12] 1050 	mov	dph,a
      008656 E4               [12] 1051 	clr	a
      008657 F0               [24] 1052 	movx	@dptr,a
      008658 12 8A 30         [24] 1053 	lcall	_ak820_outline_0123
      00865B 0F               [12] 1054 	inc	r7
      00865C 80 E1            [24] 1055 	sjmp	00103$
      00865E                       1056 00101$:
                                   1057 ;	quantum/action_util.c:90: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00865E 90 0A 0D         [24] 1058 	mov	dptr,#(_macro_mods + 0x0001)
      008661 E4               [12] 1059 	clr	a
      008662 F0               [24] 1060 	movx	@dptr,a
      008663 90 0A 0C         [24] 1061 	mov	dptr,#_macro_mods
      008666 F0               [24] 1062 	movx	@dptr,a
      008667 90 0A 0B         [24] 1063 	mov	dptr,#_owned_weak_mods
      00866A F0               [24] 1064 	movx	@dptr,a
      00866B 90 0A 0A         [24] 1065 	mov	dptr,#_owned_mods
      00866E F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	quantum/action_util.c:91: ak820_macro_cancelled = true;
      00866F 90 0A 0F         [24] 1068 	mov	dptr,#_ak820_macro_cancelled
      008672 04               [12] 1069 	inc	a
      008673 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:92: }
      008674 22               [24] 1072 	ret
                                   1073 ;------------------------------------------------------------
                                   1074 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1075 ;------------------------------------------------------------
                                   1076 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1077 ;i             Allocated with name '_clear_owned_keys_i_20000_326'
                                   1078 ;------------------------------------------------------------
                                   1079 ;	quantum/action_util.c:98: void clear_owned_keys(void) {
                                   1080 ;	-----------------------------------------
                                   1081 ;	 function clear_owned_keys
                                   1082 ;	-----------------------------------------
      008675                       1083 _clear_owned_keys:
                                   1084 ;	quantum/action_util.c:99: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008675 7F 00            [12] 1085 	mov	r7,#0x00
      008677                       1086 00104$:
      008677 EF               [12] 1087 	mov	a,r7
      008678 24 5B            [12] 1088 	add	a,#0xff - 0xa4
      00867A 40 0D            [24] 1089 	jc	00101$
                                   1090 ;	free result
      00867C EF               [12] 1091 	mov	a,r7
      00867D 24 1C            [12] 1092 	add	a, #_key_refs
      00867F F5 82            [12] 1093 	mov	dpl,a
      008681 E4               [12] 1094 	clr	a
      008682 34 0A            [12] 1095 	addc	a, #(_key_refs >> 8)
      008684 12 84 BB         [24] 1096 	lcall	_ak820_outline_0168
      008687 80 EE            [24] 1097 	sjmp	00104$
      008689                       1098 00101$:
                                   1099 ;	quantum/action_util.c:100: distinct_keys = 0;
      008689 90 0A C1         [24] 1100 	mov	dptr,#_distinct_keys
      00868C E4               [12] 1101 	clr	a
      00868D F0               [24] 1102 	movx	@dptr,a
                                   1103 ;	quantum/action_util.c:101: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00868E FF               [12] 1104 	mov	r7,a
      00868F                       1105 00107$:
      00868F BF 15 00         [24] 1106 	cjne	r7,#0x15,00142$
      008692                       1107 00142$:
      008692 50 0D            [24] 1108 	jnc	00109$
      008694 EF               [12] 1109 	mov	a,r7
      008695 24 C2            [12] 1110 	add	a, #_macro_keys
      008697 F5 82            [12] 1111 	mov	dpl,a
      008699 E4               [12] 1112 	clr	a
      00869A 34 0A            [12] 1113 	addc	a, #(_macro_keys >> 8)
      00869C 12 84 BB         [24] 1114 	lcall	_ak820_outline_0168
      00869F 80 EE            [24] 1115 	sjmp	00107$
      0086A1                       1116 00109$:
                                   1117 ;	quantum/action_util.c:102: }
      0086A1 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'add_owned_key'
                                   1121 ;------------------------------------------------------------
                                   1122 ;code          Allocated with name '_add_owned_key_code_10000_327'
                                   1123 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_336'
                                   1124 ;key           Allocated with name '_add_owned_key_key_50000_337'
                                   1125 ;i             Allocated with name '_add_owned_key_i_40000_335'
                                   1126 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_339'
                                   1127 ;key           Allocated with name '_add_owned_key_key_40000_340'
                                   1128 ;------------------------------------------------------------
                                   1129 ;	quantum/action_util.c:103: bool add_owned_key(uint8_t code) {
                                   1130 ;	-----------------------------------------
                                   1131 ;	 function add_owned_key
                                   1132 ;	-----------------------------------------
      0086A2                       1133 _add_owned_key:
      0086A2 E5 82            [12] 1134 	mov	a,dpl
      0086A4 90 0A D7         [24] 1135 	mov	dptr,#_add_owned_key_code_10000_327
      0086A7 12 8A 41         [24] 1136 	lcall	_ak820_outline_0135
                                   1137 ;	quantum/action_util.c:104: if (!ak820_macro_change(macro_keys, code, true)) return false;
      0086AA 74 01            [12] 1138 	mov	a,#0x01
      0086AC F0               [24] 1139 	movx	@dptr,a
      0086AD 90 0A C2         [24] 1140 	mov	dptr,#_macro_keys
      0086B0 C0 07            [24] 1141 	push	ar7
      0086B2 91 CA            [12] 1142 	acall	_ak820_macro_change
      0086B4 E5 82            [12] 1143 	mov	a, dpl
      0086B6 D0 07            [24] 1144 	pop	ar7
      0086B8 70 03            [24] 1145 	jnz	00102$
      0086BA F5 82            [12] 1146 	mov	dpl,a
      0086BC 22               [24] 1147 	ret
      0086BD                       1148 00102$:
                                   1149 ;	quantum/action_util.c:105: if (key_refs[code]++) return false;
      0086BD 12 89 F3         [24] 1150 	lcall	_ak820_outline_0030
      0086C0 FC               [12] 1151 	mov	r4,a
      0086C1 04               [12] 1152 	inc	a
      0086C2 12 8A 30         [24] 1153 	lcall	_ak820_outline_0123
      0086C5 EC               [12] 1154 	mov	a,r4
      0086C6 60 04            [24] 1155 	jz	00104$
      0086C8 75 82 00         [24] 1156 	mov	dpl, #0x00
      0086CB 22               [24] 1157 	ret
      0086CC                       1158 00104$:
                                   1159 ;	quantum/action_util.c:106: ++distinct_keys;
      0086CC 90 0A C1         [24] 1160 	mov	dptr,#_distinct_keys
      0086CF E0               [24] 1161 	movx	a,@dptr
      0086D0 24 01            [12] 1162 	add	a, #0x01
      0086D2 F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0086D3 90 0E 3B         [24] 1165 	mov	dptr,#_keyboard_protocol
      0086D6 E0               [24] 1166 	movx	a,@dptr
      0086D7 60 15            [24] 1167 	jz	00106$
      0086D9 90 0B 46         [24] 1168 	mov	dptr,#_keymap_config
      0086DC E0               [24] 1169 	movx	a,@dptr
      0086DD 30 E7 0E         [24] 1170 	jnb	acc.7,00106$
                                   1171 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0086E0 90 08 85         [24] 1172 	mov	dptr,#_add_key_to_report_PARM_2
      0086E3 EF               [12] 1173 	mov	a,r7
      0086E4 12 8A 01         [24] 1174 	lcall	_ak820_outline_0059
      0086E7 12 76 E9         [24] 1175 	lcall	_add_key_to_report
                                   1176 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0086EA 75 82 01         [24] 1177 	mov	dpl, #0x01
      0086ED 22               [24] 1178 	ret
      0086EE                       1179 00106$:
                                   1180 ;	quantum/action_util.c:110: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0086EE 90 0A C1         [24] 1181 	mov	dptr,#_distinct_keys
      0086F1 E0               [24] 1182 	movx	a,@dptr
      0086F2 24 F9            [12] 1183 	add	a,#0xff - 0x06
      0086F4 50 17            [24] 1184 	jnc	00110$
                                   1185 ;	free result
                                   1186 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0086F6 7F 00            [12] 1187 	mov	r7,#0x00
      0086F8                       1188 00115$:
      0086F8 BF 06 00         [24] 1189 	cjne	r7,#0x06,00174$
      0086FB                       1190 00174$:
      0086FB 50 1D            [24] 1191 	jnc	00111$
      0086FD EF               [12] 1192 	mov	a,r7
      0086FE 24 50            [12] 1193 	add	a, #(_actual_keyboard_report + 0x0002)
      008700 F5 82            [12] 1194 	mov	dpl,a
      008702 E4               [12] 1195 	clr	a
      008703 34 0E            [12] 1196 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      008705 F5 83            [12] 1197 	mov	dph,a
      008707 74 01            [12] 1198 	mov	a,#0x01
      008709 F0               [24] 1199 	movx	@dptr,a
      00870A 0F               [12] 1200 	inc	r7
      00870B 80 EB            [24] 1201 	sjmp	00115$
      00870D                       1202 00110$:
                                   1203 ;	quantum/action_util.c:112: } else add_key(code);
      00870D 90 0A D7         [24] 1204 	mov	dptr,#_add_owned_key_code_10000_327
      008710 E0               [24] 1205 	movx	a,@dptr
                                   1206 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008711 90 08 85         [24] 1207 	mov	dptr,#_add_key_to_report_PARM_2
      008714 12 8A 01         [24] 1208 	lcall	_ak820_outline_0059
      008717 12 76 E9         [24] 1209 	lcall	_add_key_to_report
                                   1210 ;	quantum/action_util.c:112: } else add_key(code);
      00871A                       1211 00111$:
                                   1212 ;	quantum/action_util.c:113: return true;
      00871A 75 82 01         [24] 1213 	mov	dpl, #0x01
                                   1214 ;	quantum/action_util.c:114: }
      00871D 22               [24] 1215 	ret
                                   1216 ;------------------------------------------------------------
                                   1217 ;Allocation info for local variables in function 'del_owned_key'
                                   1218 ;------------------------------------------------------------
                                   1219 ;code          Allocated with name '_del_owned_key_code_10000_342'
                                   1220 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_353'
                                   1221 ;key           Allocated with name '_del_owned_key_key_50000_354'
                                   1222 ;key           Allocated with name '_del_owned_key_key_40000_351'
                                   1223 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_359'
                                   1224 ;key           Allocated with name '_del_owned_key_key_70000_360'
                                   1225 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_362'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_363'
                                   1227 ;------------------------------------------------------------
                                   1228 ;	quantum/action_util.c:115: bool del_owned_key(uint8_t code) {
                                   1229 ;	-----------------------------------------
                                   1230 ;	 function del_owned_key
                                   1231 ;	-----------------------------------------
      00871E                       1232 _del_owned_key:
      00871E E5 82            [12] 1233 	mov	a,dpl
      008720 90 0A D8         [24] 1234 	mov	dptr,#_del_owned_key_code_10000_342
      008723 12 8A 41         [24] 1235 	lcall	_ak820_outline_0135
                                   1236 ;	quantum/action_util.c:116: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008726 E4               [12] 1237 	clr	a
      008727 F0               [24] 1238 	movx	@dptr,a
      008728 90 0A C2         [24] 1239 	mov	dptr,#_macro_keys
      00872B C0 07            [24] 1240 	push	ar7
      00872D 91 CA            [12] 1241 	acall	_ak820_macro_change
      00872F E5 82            [12] 1242 	mov	a, dpl
      008731 D0 07            [24] 1243 	pop	ar7
      008733 70 03            [24] 1244 	jnz	00102$
      008735 F5 82            [12] 1245 	mov	dpl,a
      008737 22               [24] 1246 	ret
      008738                       1247 00102$:
                                   1248 ;	quantum/action_util.c:117: if (!key_refs[code] || --key_refs[code]) return false;
      008738 12 89 F3         [24] 1249 	lcall	_ak820_outline_0030
      00873B FC               [12] 1250 	mov	r4,a
      00873C 60 07            [24] 1251 	jz	00103$
      00873E 1C               [12] 1252 	dec	r4
      00873F 12 48 C4         [24] 1253 	lcall	_ak820_outline_0065
      008742 EC               [12] 1254 	mov	a,r4
      008743 60 04            [24] 1255 	jz	00104$
      008745                       1256 00103$:
      008745 75 82 00         [24] 1257 	mov	dpl, #0x00
      008748 22               [24] 1258 	ret
      008749                       1259 00104$:
                                   1260 ;	quantum/action_util.c:118: --distinct_keys;
      008749 90 0A C1         [24] 1261 	mov	dptr,#_distinct_keys
      00874C E0               [24] 1262 	movx	a,@dptr
      00874D 14               [12] 1263 	dec	a
      00874E F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00874F 90 0E 3B         [24] 1266 	mov	dptr,#_keyboard_protocol
      008752 E0               [24] 1267 	movx	a,@dptr
      008753 60 15            [24] 1268 	jz	00107$
      008755 90 0B 46         [24] 1269 	mov	dptr,#_keymap_config
      008758 E0               [24] 1270 	movx	a,@dptr
      008759 30 E7 0E         [24] 1271 	jnb	acc.7,00107$
                                   1272 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00875C 90 08 89         [24] 1273 	mov	dptr,#_del_key_from_report_PARM_2
      00875F EF               [12] 1274 	mov	a,r7
      008760 12 8A 01         [24] 1275 	lcall	_ak820_outline_0059
      008763 12 77 24         [24] 1276 	lcall	_del_key_from_report
                                   1277 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008766 75 82 01         [24] 1278 	mov	dpl, #0x01
      008769 22               [24] 1279 	ret
      00876A                       1280 00107$:
                                   1281 ;	quantum/action_util.c:122: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00876A 90 0A C1         [24] 1282 	mov	dptr,#_distinct_keys
      00876D E0               [24] 1283 	movx	a,@dptr
      00876E FF               [12] 1284 	mov  r7,a
      00876F 24 F9            [12] 1285 	add	a,#0xff - 0x06
      008771 50 04            [24] 1286 	jnc	00110$
                                   1287 ;	free result
      008773 75 82 01         [24] 1288 	mov	dpl, #0x01
      008776 22               [24] 1289 	ret
      008777                       1290 00110$:
                                   1291 ;	quantum/action_util.c:123: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008777 BF 06 26         [24] 1292 	cjne	r7,#0x06,00115$
                                   1293 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00877A 90 0E 4E         [24] 1294 	mov	dptr,#_actual_keyboard_report
      00877D 75 F0 00         [24] 1295 	mov	b, #0x00
      008780 12 77 5F         [24] 1296 	lcall	_clear_keys_from_report
                                   1297 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008783 7F 04            [12] 1298 	mov	r7,#0x04
      008785                       1299 00122$:
      008785 EF               [12] 1300 	mov	a,r7
      008786 24 5B            [12] 1301 	add	a,#0xff - 0xa4
      008788 40 23            [24] 1302 	jc	00116$
                                   1303 ;	free result
      00878A 12 89 F3         [24] 1304 	lcall	_ak820_outline_0030
      00878D 60 0E            [24] 1305 	jz	00123$
                                   1306 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00878F 90 08 85         [24] 1307 	mov	dptr,#_add_key_to_report_PARM_2
      008792 EF               [12] 1308 	mov	a,r7
      008793 12 8A 01         [24] 1309 	lcall	_ak820_outline_0059
      008796 C0 07            [24] 1310 	push	ar7
      008798 12 76 E9         [24] 1311 	lcall	_add_key_to_report
      00879B D0 07            [24] 1312 	pop	ar7
                                   1313 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00879D                       1314 00123$:
      00879D 0F               [12] 1315 	inc	r7
      00879E 80 E5            [24] 1316 	sjmp	00122$
      0087A0                       1317 00115$:
                                   1318 ;	quantum/action_util.c:127: } else del_key(code);
      0087A0 90 0A D8         [24] 1319 	mov	dptr,#_del_owned_key_code_10000_342
      0087A3 E0               [24] 1320 	movx	a,@dptr
                                   1321 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0087A4 90 08 89         [24] 1322 	mov	dptr,#_del_key_from_report_PARM_2
      0087A7 12 8A 01         [24] 1323 	lcall	_ak820_outline_0059
      0087AA 12 77 24         [24] 1324 	lcall	_del_key_from_report
                                   1325 ;	quantum/action_util.c:127: } else del_key(code);
      0087AD                       1326 00116$:
                                   1327 ;	quantum/action_util.c:128: return true;
      0087AD 75 82 01         [24] 1328 	mov	dpl, #0x01
                                   1329 ;	quantum/action_util.c:129: }
      0087B0 22               [24] 1330 	ret
                                   1331 ;------------------------------------------------------------
                                   1332 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1333 ;------------------------------------------------------------
                                   1334 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1335 ;i             Allocated with name '_clear_owned_usages_i_20000_368'
                                   1336 ;------------------------------------------------------------
                                   1337 ;	quantum/action_util.c:139: void clear_owned_usages(void) {
                                   1338 ;	-----------------------------------------
                                   1339 ;	 function clear_owned_usages
                                   1340 ;	-----------------------------------------
      0087B1                       1341 _clear_owned_usages:
                                   1342 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0087B1 7F 00            [12] 1343 	mov	r7,#0x00
      0087B3                       1344 00104$:
      0087B3 BF 1E 00         [24] 1345 	cjne	r7,#0x1e,00141$
      0087B6                       1346 00141$:
      0087B6 50 14            [24] 1347 	jnc	00101$
      0087B8 EF               [12] 1348 	mov	a,r7
      0087B9 24 D9            [12] 1349 	add	a, #_usage_refs
      0087BB FD               [12] 1350 	mov	r5,a
      0087BC E4               [12] 1351 	clr	a
      0087BD 34 0A            [12] 1352 	addc	a, #(_usage_refs >> 8)
      0087BF FE               [12] 1353 	mov	r6,a
      0087C0 EF               [12] 1354 	mov	a,r7
      0087C1 12 8A 10         [24] 1355 	lcall	_ak820_outline_0068
      0087C4 E4               [12] 1356 	clr	a
      0087C5 F0               [24] 1357 	movx	@dptr,a
      0087C6 12 8A 30         [24] 1358 	lcall	_ak820_outline_0123
      0087C9 0F               [12] 1359 	inc	r7
      0087CA 80 E7            [24] 1360 	sjmp	00104$
      0087CC                       1361 00101$:
                                   1362 ;	quantum/action_util.c:141: usage_lengths[0] = usage_lengths[1] = 0;
      0087CC 90 0B 16         [24] 1363 	mov	dptr,#(_usage_lengths + 0x0001)
      0087CF E4               [12] 1364 	clr	a
      0087D0 F0               [24] 1365 	movx	@dptr,a
      0087D1 90 0B 15         [24] 1366 	mov	dptr,#_usage_lengths
      0087D4 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/action_util.c:142: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0087D5 FF               [12] 1369 	mov	r7,a
      0087D6                       1370 00107$:
      0087D6 BF 04 00         [24] 1371 	cjne	r7,#0x04,00143$
      0087D9                       1372 00143$:
      0087D9 50 0D            [24] 1373 	jnc	00109$
      0087DB EF               [12] 1374 	mov	a,r7
      0087DC 24 17            [12] 1375 	add	a, #_macro_usages
      0087DE F5 82            [12] 1376 	mov	dpl,a
      0087E0 E4               [12] 1377 	clr	a
      0087E1 34 0B            [12] 1378 	addc	a, #(_macro_usages >> 8)
      0087E3 12 84 BB         [24] 1379 	lcall	_ak820_outline_0168
      0087E6 80 EE            [24] 1380 	sjmp	00107$
      0087E8                       1381 00109$:
                                   1382 ;	quantum/action_util.c:143: }
      0087E8 22               [24] 1383 	ret
                                   1384 ;------------------------------------------------------------
                                   1385 ;Allocation info for local variables in function 'owned_usage_key'
                                   1386 ;------------------------------------------------------------
                                   1387 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1388 ;code          Allocated with name '_owned_usage_key_code_10000_369'
                                   1389 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_370'
                                   1390 ;which         Allocated with name '_owned_usage_key_which_10000_370'
                                   1391 ;base          Allocated with name '_owned_usage_key_base_10000_370'
                                   1392 ;count         Allocated with name '_owned_usage_key_count_10000_370'
                                   1393 ;index         Allocated with name '_owned_usage_key_index_10000_370'
                                   1394 ;pos           Allocated with name '_owned_usage_key_pos_30001_377'
                                   1395 ;i             Allocated with name '_owned_usage_key_i_40001_378'
                                   1396 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_381'
                                   1397 ;key           Allocated with name '_owned_usage_key_key_40000_382'
                                   1398 ;------------------------------------------------------------
                                   1399 ;	quantum/action_util.c:144: void owned_usage_key(uint8_t code, bool pressed) {
                                   1400 ;	-----------------------------------------
                                   1401 ;	 function owned_usage_key
                                   1402 ;	-----------------------------------------
      0087E9                       1403 _owned_usage_key:
      0087E9 E5 82            [12] 1404 	mov	a,dpl
      0087EB 90 0B 1C         [24] 1405 	mov	dptr,#_owned_usage_key_code_10000_369
      0087EE F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/action_util.c:145: uint8_t which = code >= KC_AUDIO_MUTE;
      0087EF E0               [24] 1408 	movx	a,@dptr
      0087F0 FF               [12] 1409 	mov	r7,a
      0087F1 BF A8 00         [24] 1410 	cjne	r7,#0xa8,00244$
      0087F4                       1411 00244$:
      0087F4 B3               [12] 1412 	cpl	c
      0087F5 92 25            [24] 1413 	mov	_owned_usage_key_sloc0_1_0,c
      0087F7 E4               [12] 1414 	clr	a
      0087F8 33               [12] 1415 	rlc	a
      0087F9 FF               [12] 1416 	mov	r7,a
      0087FA 90 0B 1F         [24] 1417 	mov	dptr,#_owned_usage_key_which_10000_370
      0087FD F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/action_util.c:146: uint8_t base = which ? SYSTEM_COUNT : 0;
      0087FE EF               [12] 1420 	mov	a,r7
      0087FF 60 02            [24] 1421 	jz	00129$
      008801 74 03            [12] 1422 	mov	a,#0x03
      008803                       1423 00129$:
      008803 FE               [12] 1424 	mov	r6,a
                                   1425 ;	quantum/action_util.c:147: uint8_t count = usage_lengths[which];
      008804 EF               [12] 1426 	mov	a,r7
      008805 24 15            [12] 1427 	add	a, #_usage_lengths
      008807 FD               [12] 1428 	mov	r5,a
      008808 E4               [12] 1429 	clr	a
      008809 34 0B            [12] 1430 	addc	a, #(_usage_lengths >> 8)
      00880B FF               [12] 1431 	mov	r7,a
      00880C 12 8A 4C         [24] 1432 	lcall	_ak820_outline_0192
      00880F E0               [24] 1433 	movx	a,@dptr
      008810 FC               [12] 1434 	mov	r4,a
                                   1435 ;	quantum/action_util.c:148: uint8_t index = code - KC_SYSTEM_POWER;
      008811 90 0B 1C         [24] 1436 	mov	dptr,#_owned_usage_key_code_10000_369
      008814 E0               [24] 1437 	movx	a,@dptr
      008815 24 5B            [12] 1438 	add	a,#0x5b
      008817 FB               [12] 1439 	mov	r3,a
                                   1440 ;	quantum/action_util.c:149: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      008818 90 0B 1B         [24] 1441 	mov	dptr,#_owned_usage_key_PARM_2
      00881B E0               [24] 1442 	movx	a,@dptr
      00881C FA               [12] 1443 	mov	r2,a
      00881D 90 0A 10         [24] 1444 	mov	dptr,#_ak820_macro_change_PARM_2
      008820 EB               [12] 1445 	mov	a,r3
      008821 F0               [24] 1446 	movx	@dptr,a
      008822 90 0A 11         [24] 1447 	mov	dptr,#_ak820_macro_change_PARM_3
      008825 EA               [12] 1448 	mov	a,r2
      008826 F0               [24] 1449 	movx	@dptr,a
      008827 90 0B 17         [24] 1450 	mov	dptr,#_macro_usages
      00882A C0 07            [24] 1451 	push	ar7
      00882C C0 06            [24] 1452 	push	ar6
      00882E C0 05            [24] 1453 	push	ar5
      008830 C0 04            [24] 1454 	push	ar4
      008832 C0 03            [24] 1455 	push	ar3
      008834 C0 02            [24] 1456 	push	ar2
      008836 12 84 CA         [24] 1457 	lcall	_ak820_macro_change
      008839 E5 82            [12] 1458 	mov	a, dpl
      00883B D0 02            [24] 1459 	pop	ar2
      00883D D0 03            [24] 1460 	pop	ar3
      00883F D0 04            [24] 1461 	pop	ar4
      008841 D0 05            [24] 1462 	pop	ar5
      008843 D0 06            [24] 1463 	pop	ar6
      008845 D0 07            [24] 1464 	pop	ar7
      008847 70 01            [24] 1465 	jnz	00102$
      008849 22               [24] 1466 	ret
      00884A                       1467 00102$:
                                   1468 ;	quantum/action_util.c:150: if (pressed) {
      00884A EA               [12] 1469 	mov	a,r2
      00884B 60 1A            [24] 1470 	jz	00115$
                                   1471 ;	quantum/action_util.c:151: if (usage_refs[index]++) return;
      00884D 12 8A 1A         [24] 1472 	lcall	_ak820_outline_0075
      008850 04               [12] 1473 	inc	a
      008851 12 74 68         [24] 1474 	lcall	_ak820_outline_0141
      008854 E8               [12] 1475 	mov	a,r0
      008855 60 01            [24] 1476 	jz	00104$
      008857 22               [24] 1477 	ret
      008858                       1478 00104$:
                                   1479 ;	quantum/action_util.c:152: usage_order[base + count++] = index;
      008858 90 0B 20         [24] 1480 	mov	dptr,#_owned_usage_key_count_10000_370
      00885B EC               [12] 1481 	mov	a,r4
      00885C 04               [12] 1482 	inc	a
      00885D F0               [24] 1483 	movx	@dptr,a
      00885E EC               [12] 1484 	mov	a,r4
      00885F 2E               [12] 1485 	add	a, r6
      008860 12 8A 10         [24] 1486 	lcall	_ak820_outline_0068
      008863 EB               [12] 1487 	mov	a,r3
      008864 F0               [24] 1488 	movx	@dptr,a
      008865 01 C8            [12] 1489 	ajmp	00116$
      008867                       1490 00115$:
                                   1491 ;	quantum/action_util.c:154: if (!usage_refs[index] || --usage_refs[index]) return;
      008867 12 8A 1A         [24] 1492 	lcall	_ak820_outline_0075
      00886A 60 07            [24] 1493 	jz	00105$
      00886C 18               [12] 1494 	dec	r0
      00886D 12 8A 09         [24] 1495 	lcall	_ak820_outline_0064
      008870 E8               [12] 1496 	mov	a,r0
      008871 60 01            [24] 1497 	jz	00106$
      008873                       1498 00105$:
      008873 22               [24] 1499 	ret
      008874                       1500 00106$:
                                   1501 ;	quantum/action_util.c:156: while (usage_order[base + pos] != index) ++pos;
      008874 7A 00            [12] 1502 	mov	r2,#0x00
      008876                       1503 00108$:
      008876 EA               [12] 1504 	mov	a,r2
      008877 2E               [12] 1505 	add	a, r6
      008878 12 8A 10         [24] 1506 	lcall	_ak820_outline_0068
      00887B E0               [24] 1507 	movx	a,@dptr
      00887C B5 03 02         [24] 1508 	cjne	a,ar3,00251$
      00887F 80 03            [24] 1509 	sjmp	00167$
      008881                       1510 00251$:
      008881 0A               [12] 1511 	inc	r2
      008882 80 F2            [24] 1512 	sjmp	00108$
      008884                       1513 00167$:
      008884 90 0B 21         [24] 1514 	mov	dptr,#_owned_usage_key_pos_30001_377
      008887 EA               [12] 1515 	mov	a,r2
      008888 F0               [24] 1516 	movx	@dptr,a
                                   1517 ;	quantum/action_util.c:157: --count;
      008889 1C               [12] 1518 	dec	r4
      00888A 90 0B 20         [24] 1519 	mov	dptr,#_owned_usage_key_count_10000_370
      00888D EC               [12] 1520 	mov	a,r4
      00888E F0               [24] 1521 	movx	@dptr,a
                                   1522 ;	quantum/action_util.c:158: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00888F 8A 03            [24] 1523 	mov	ar3,r2
      008891                       1524 00125$:
      008891 C3               [12] 1525 	clr	c
      008892 EB               [12] 1526 	mov	a,r3
      008893 9C               [12] 1527 	subb	a,r4
      008894 50 23            [24] 1528 	jnc	00111$
      008896 C0 05            [24] 1529 	push	ar5
      008898 C0 07            [24] 1530 	push	ar7
      00889A EB               [12] 1531 	mov	a,r3
      00889B 2E               [12] 1532 	add	a, r6
      00889C FA               [12] 1533 	mov	r2,a
      00889D 24 F7            [12] 1534 	add	a, #_usage_order
      00889F F8               [12] 1535 	mov	r0,a
      0088A0 E4               [12] 1536 	clr	a
      0088A1 34 0A            [12] 1537 	addc	a, #(_usage_order >> 8)
      0088A3 F9               [12] 1538 	mov	r1,a
      0088A4 0A               [12] 1539 	inc	r2
      0088A5 EA               [12] 1540 	mov	a,r2
      0088A6 33               [12] 1541 	rlc	a
      0088A7 95 E0            [12] 1542 	subb	a,acc
      0088A9 FF               [12] 1543 	mov	r7,a
      0088AA EA               [12] 1544 	mov	a,r2
      0088AB 12 8A 36         [24] 1545 	lcall	_ak820_outline_0128
      0088AE 12 3A F1         [24] 1546 	lcall	_ak820_outline_0148
      0088B1 F0               [24] 1547 	movx	@dptr,a
      0088B2 0B               [12] 1548 	inc	r3
      0088B3 D0 07            [24] 1549 	pop	ar7
      0088B5 D0 05            [24] 1550 	pop	ar5
      0088B7 80 D8            [24] 1551 	sjmp	00125$
      0088B9                       1552 00111$:
                                   1553 ;	quantum/action_util.c:159: usage_lengths[which] = count;
      0088B9 12 8A 4C         [24] 1554 	lcall	_ak820_outline_0192
      0088BC EC               [12] 1555 	mov	a,r4
      0088BD F0               [24] 1556 	movx	@dptr,a
                                   1557 ;	quantum/action_util.c:160: if (pos != count) return; /* A non-winning owner changed only storage. */
      0088BE 90 0B 21         [24] 1558 	mov	dptr,#_owned_usage_key_pos_30001_377
      0088C1 E0               [24] 1559 	movx	a,@dptr
      0088C2 B5 04 02         [24] 1560 	cjne	a,ar4,00253$
      0088C5 80 01            [24] 1561 	sjmp	00116$
      0088C7                       1562 00253$:
      0088C7 22               [24] 1563 	ret
      0088C8                       1564 00116$:
                                   1565 ;	quantum/action_util.c:162: usage_lengths[which] = count;
      0088C8 90 0B 20         [24] 1566 	mov	dptr,#_owned_usage_key_count_10000_370
      0088CB E0               [24] 1567 	movx	a,@dptr
      0088CC FC               [12] 1568 	mov	r4,a
      0088CD 12 8A 4C         [24] 1569 	lcall	_ak820_outline_0192
      0088D0 F0               [24] 1570 	movx	@dptr,a
                                   1571 ;	quantum/action_util.c:163: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0088D1 EC               [12] 1572 	mov	a,r4
      0088D2 60 15            [24] 1573 	jz	00131$
      0088D4 EC               [12] 1574 	mov	a,r4
      0088D5 2E               [12] 1575 	add	a, r6
      0088D6 FE               [12] 1576 	mov	r6,a
      0088D7 1E               [12] 1577 	dec	r6
      0088D8 EE               [12] 1578 	mov	a,r6
      0088D9 33               [12] 1579 	rlc	a
      0088DA 95 E0            [12] 1580 	subb	a,acc
      0088DC FF               [12] 1581 	mov	r7,a
      0088DD EE               [12] 1582 	mov	a,r6
      0088DE 12 8A 36         [24] 1583 	lcall	_ak820_outline_0128
      0088E1 24 A5            [12] 1584 	add	a,#0xa5
      0088E3 FE               [12] 1585 	mov	r6,a
      0088E4 33               [12] 1586 	rlc	a
      0088E5 95 E0            [12] 1587 	subb	a,acc
      0088E7 80 02            [24] 1588 	sjmp	00132$
      0088E9                       1589 00131$:
      0088E9 7E 00            [12] 1590 	mov	r6,#0x00
      0088EB                       1591 00132$:
      0088EB 90 0B 1C         [24] 1592 	mov	dptr,#_owned_usage_key_code_10000_369
      0088EE EE               [12] 1593 	mov	a,r6
      0088EF F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/action_util.c:164: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0088F0 90 0B 1F         [24] 1596 	mov	dptr,#_owned_usage_key_which_10000_370
      0088F3 E0               [24] 1597 	movx	a,@dptr
      0088F4 60 18            [24] 1598 	jz	00118$
      0088F6 EE               [12] 1599 	mov	a,r6
      0088F7 60 0B            [24] 1600 	jz	00133$
      0088F9 8E 82            [24] 1601 	mov	dpl, r6
      0088FB 12 75 A6         [24] 1602 	lcall	_KEYCODE2CONSUMER
      0088FE AD 82            [24] 1603 	mov	r5, dpl
      008900 AF 83            [24] 1604 	mov	r7, dph
      008902 80 04            [24] 1605 	sjmp	00134$
      008904                       1606 00133$:
      008904 7D 00            [12] 1607 	mov	r5,#0x00
      008906 7F 00            [12] 1608 	mov	r7,#0x00
      008908                       1609 00134$:
      008908 12 8A 4C         [24] 1610 	lcall	_ak820_outline_0192
      00890B 02 75 5A         [24] 1611 	ljmp	_host_consumer_send
      00890E                       1612 00118$:
                                   1613 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00890E EE               [12] 1614 	mov	a,r6
      00890F 60 22            [24] 1615 	jz	00135$
                                   1616 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008911 BE A5 00         [24] 1617 	cjne	r6,#0xa5,00258$
      008914                       1618 00258$:
      008914 40 05            [24] 1619 	jc	00121$
      008916 EE               [12] 1620 	mov	a,r6
      008917 24 58            [12] 1621 	add	a,#0xff - 0xa7
      008919 50 08            [24] 1622 	jnc	00122$
                                   1623 ;	free result
      00891B                       1624 00121$:
      00891B 90 0B 1D         [24] 1625 	mov	dptr,#_owned_usage_key___200000085_20000_370
      00891E 12 55 02         [24] 1626 	lcall	_ak820_outline_0184
      008921 80 09            [24] 1627 	sjmp	00123$
      008923                       1628 00122$:
                                   1629 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008923 74 DC            [12] 1630 	mov	a,#0xdc
      008925 2E               [12] 1631 	add	a, r6
      008926 90 0B 1D         [24] 1632 	mov	dptr,#_owned_usage_key___200000085_20000_370
      008929 12 3A DC         [24] 1633 	lcall	_ak820_outline_0136
                                   1634 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00892C                       1635 00123$:
      00892C 90 0B 1D         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_370
      00892F E0               [24] 1637 	movx	a,@dptr
      008930 FF               [12] 1638 	mov	r7,a
      008931 80 02            [24] 1639 	sjmp	00136$
      008933                       1640 00135$:
      008933 7F 00            [12] 1641 	mov	r7,#0x00
      008935                       1642 00136$:
      008935 7E 00            [12] 1643 	mov	r6,#0x00
      008937 12 48 FF         [24] 1644 	lcall	_ak820_outline_0163
                                   1645 ;	quantum/action_util.c:166: }
      00893A 02 75 2B         [24] 1646 	ljmp	_host_system_send
                                   1647 ;------------------------------------------------------------
                                   1648 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1649 ;------------------------------------------------------------
                                   1650 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_389'
                                   1651 ;changed       Allocated with name '_send_keyboard_report_changed_10001_389'
                                   1652 ;dest          Allocated with name '_send_keyboard_report_dest_10001_389'
                                   1653 ;src           Allocated with name '_send_keyboard_report_src_10001_389'
                                   1654 ;i             Allocated with name '_send_keyboard_report_i_20001_390'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action_util.c:388: void send_keyboard_report(void) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function send_keyboard_report
                                   1659 ;	-----------------------------------------
      00893D                       1660 _send_keyboard_report:
                                   1661 ;	quantum/action_util.c:389: keyboard_report->mods = real_mods;
      00893D 90 0E 4C         [24] 1662 	mov	dptr,#_real_mods
      008940 E0               [24] 1663 	movx	a,@dptr
      008941 FF               [12] 1664 	mov	r7,a
      008942 90 0E 4E         [24] 1665 	mov	dptr,#_actual_keyboard_report
      008945 F0               [24] 1666 	movx	@dptr,a
                                   1667 ;	quantum/action_util.c:390: keyboard_report->mods |= weak_mods;
      008946 90 0E 4D         [24] 1668 	mov	dptr,#_weak_mods
      008949 E0               [24] 1669 	movx	a,@dptr
      00894A 42 07            [12] 1670 	orl	ar7,a
      00894C 90 0E 4E         [24] 1671 	mov	dptr,#_actual_keyboard_report
      00894F EF               [12] 1672 	mov	a,r7
      008950 F0               [24] 1673 	movx	@dptr,a
                                   1674 ;	quantum/action_util.c:392: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008951 90 0A 0B         [24] 1675 	mov	dptr,#_owned_weak_mods
      008954 E0               [24] 1676 	movx	a,@dptr
      008955 FE               [12] 1677 	mov	r6,a
      008956 90 0A 0A         [24] 1678 	mov	dptr,#_owned_mods
      008959 E0               [24] 1679 	movx	a,@dptr
      00895A 4E               [12] 1680 	orl	a,r6
      00895B 42 07            [12] 1681 	orl	ar7,a
      00895D 90 0E 4E         [24] 1682 	mov	dptr,#_actual_keyboard_report
      008960 EF               [12] 1683 	mov	a,r7
      008961 F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:427: bool changed = false;
      008962 90 0B 43         [24] 1686 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008965 E4               [12] 1687 	clr	a
      008966 F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:429: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1690 ;	quantum/action_util.c:430: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1691 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008967 FF               [12] 1692 	mov	r7,a
      008968                       1693 00107$:
      008968 BF 20 00         [24] 1694 	cjne	r7,#0x20,00140$
      00896B                       1695 00140$:
      00896B 50 2B            [24] 1696 	jnc	00103$
                                   1697 ;	quantum/action_util.c:436: if (dest[i] != src[i]) {
      00896D EF               [12] 1698 	mov	a,r7
      00896E 24 23            [12] 1699 	add	a, #_send_keyboard_report_last_report_10001_389
      008970 FD               [12] 1700 	mov	r5,a
      008971 E4               [12] 1701 	clr	a
      008972 34 0B            [12] 1702 	addc	a, #(_send_keyboard_report_last_report_10001_389 >> 8)
      008974 FE               [12] 1703 	mov	r6,a
      008975 12 4E 16         [24] 1704 	lcall	_ak820_outline_0078
      008978 EF               [12] 1705 	mov	a,r7
      008979 24 4E            [12] 1706 	add	a, #_actual_keyboard_report
      00897B F5 82            [12] 1707 	mov	dpl,a
      00897D E4               [12] 1708 	clr	a
      00897E 34 0E            [12] 1709 	addc	a, #(_actual_keyboard_report >> 8)
      008980 F5 83            [12] 1710 	mov	dph,a
      008982 E0               [24] 1711 	movx	a,@dptr
      008983 FB               [12] 1712 	mov	r3,a
      008984 EC               [12] 1713 	mov	a,r4
      008985 B5 03 02         [24] 1714 	cjne	a,ar3,00142$
      008988 80 0B            [24] 1715 	sjmp	00108$
      00898A                       1716 00142$:
                                   1717 ;	quantum/action_util.c:437: dest[i] = src[i];
      00898A 12 3A E1         [24] 1718 	lcall	_ak820_outline_0137
      00898D EB               [12] 1719 	mov	a,r3
      00898E F0               [24] 1720 	movx	@dptr,a
                                   1721 ;	quantum/action_util.c:438: changed = true;
      00898F 90 0B 43         [24] 1722 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008992 74 01            [12] 1723 	mov	a,#0x01
      008994 F0               [24] 1724 	movx	@dptr,a
      008995                       1725 00108$:
                                   1726 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008995 0F               [12] 1727 	inc	r7
      008996 80 D0            [24] 1728 	sjmp	00107$
      008998                       1729 00103$:
                                   1730 ;	quantum/action_util.c:441: if (changed) host_keyboard_send(keyboard_report);
      008998 90 0B 43         [24] 1731 	mov	dptr,#_send_keyboard_report_changed_10001_389
      00899B E0               [24] 1732 	movx	a,@dptr
      00899C 60 09            [24] 1733 	jz	00109$
      00899E 90 0E 4E         [24] 1734 	mov	dptr,#_actual_keyboard_report
      0089A1 75 F0 00         [24] 1735 	mov	b, #0x00
                                   1736 ;	quantum/action_util.c:449: }
      0089A4 02 74 A0         [24] 1737 	ljmp	_host_keyboard_send
      0089A7                       1738 00109$:
      0089A7 22               [24] 1739 	ret
                                   1740 ;------------------------------------------------------------
                                   1741 ;Allocation info for local variables in function 'get_mods'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/action_util.c:455: uint8_t get_mods(void) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function get_mods
                                   1746 ;	-----------------------------------------
      0089A8                       1747 _get_mods:
      0089A8 C0 07            [24] 1748 	push	ar7
                                   1749 ;	quantum/action_util.c:460: ;
      0089AA 90 0A 0A         [24] 1750 	mov	dptr,#_owned_mods
      0089AD E0               [24] 1751 	movx	a,@dptr
      0089AE FF               [12] 1752 	mov	r7,a
      0089AF 90 0E 4C         [24] 1753 	mov	dptr,#_real_mods
      0089B2 12 84 B5         [24] 1754 	lcall	_ak820_outline_0145
                                   1755 ;	quantum/action_util.c:461: }
      0089B5 D0 07            [24] 1756 	pop	ar7
      0089B7 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'add_mods'
                                   1760 ;------------------------------------------------------------
                                   1761 ;mods          Allocated with name '_add_mods_mods_10000_397'
                                   1762 ;------------------------------------------------------------
                                   1763 ;	quantum/action_util.c:466: void add_mods(uint8_t mods) {
                                   1764 ;	-----------------------------------------
                                   1765 ;	 function clear_mods
                                   1766 ;	-----------------------------------------
      0089B8                       1767 _clear_mods:
                                   1768 ;	quantum/action_util.c:488: real_mods = 0;
      0089B8 90 0E 4C         [24] 1769 	mov	dptr,#_real_mods
      0089BB E4               [12] 1770 	clr	a
      0089BC F0               [24] 1771 	movx	@dptr,a
                                   1772 ;	quantum/action_util.c:489: }
      0089BD 22               [24] 1773 	ret
                                   1774 ;------------------------------------------------------------
                                   1775 ;Allocation info for local variables in function 'get_weak_mods'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	quantum/action_util.c:495: uint8_t get_weak_mods(void) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function get_weak_mods
                                   1780 ;	-----------------------------------------
      0089BE                       1781 _get_weak_mods:
      0089BE C0 07            [24] 1782 	push	ar7
                                   1783 ;	quantum/action_util.c:500: ;
      0089C0 90 0A 0B         [24] 1784 	mov	dptr,#_owned_weak_mods
      0089C3 E0               [24] 1785 	movx	a,@dptr
      0089C4 FF               [12] 1786 	mov	r7,a
      0089C5 90 0E 4D         [24] 1787 	mov	dptr,#_weak_mods
      0089C8 12 84 B5         [24] 1788 	lcall	_ak820_outline_0145
                                   1789 ;	quantum/action_util.c:501: }
      0089CB D0 07            [24] 1790 	pop	ar7
      0089CD 22               [24] 1791 	ret
                                   1792 ;------------------------------------------------------------
                                   1793 ;Allocation info for local variables in function 'add_weak_mods'
                                   1794 ;------------------------------------------------------------
                                   1795 ;mods          Allocated with name '_add_weak_mods_mods_10000_407'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action_util.c:506: void add_weak_mods(uint8_t mods) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function add_weak_mods
                                   1800 ;	-----------------------------------------
      0089CE                       1801 _add_weak_mods:
      0089CE E5 82            [12] 1802 	mov	a,dpl
      0089D0 90 0B 44         [24] 1803 	mov	dptr,#_add_weak_mods_mods_10000_407
      0089D3 F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action_util.c:507: weak_mods |= mods;
      0089D4 E0               [24] 1806 	movx	a,@dptr
      0089D5 FF               [12] 1807 	mov	r7,a
      0089D6 90 0E 4D         [24] 1808 	mov	dptr,#_weak_mods
      0089D9 E0               [24] 1809 	movx	a,@dptr
      0089DA 4F               [12] 1810 	orl	a,r7
      0089DB F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	quantum/action_util.c:508: }
      0089DC 22               [24] 1813 	ret
                                   1814 ;------------------------------------------------------------
                                   1815 ;Allocation info for local variables in function 'del_weak_mods'
                                   1816 ;------------------------------------------------------------
                                   1817 ;mods          Allocated with name '_del_weak_mods_mods_10000_409'
                                   1818 ;------------------------------------------------------------
                                   1819 ;	quantum/action_util.c:513: void del_weak_mods(uint8_t mods) {
                                   1820 ;	-----------------------------------------
                                   1821 ;	 function del_weak_mods
                                   1822 ;	-----------------------------------------
      0089DD                       1823 _del_weak_mods:
      0089DD E5 82            [12] 1824 	mov	a,dpl
      0089DF 90 0B 45         [24] 1825 	mov	dptr,#_del_weak_mods_mods_10000_409
      0089E2 F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	quantum/action_util.c:514: weak_mods &= ~mods;
      0089E3 E0               [24] 1828 	movx	a,@dptr
      0089E4 F4               [12] 1829 	cpl	a
      0089E5 FF               [12] 1830 	mov	r7,a
      0089E6 90 0E 4D         [24] 1831 	mov	dptr,#_weak_mods
      0089E9 E0               [24] 1832 	movx	a,@dptr
      0089EA 5F               [12] 1833 	anl	a,r7
      0089EB F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	quantum/action_util.c:515: }
      0089EC 22               [24] 1836 	ret
                                   1837 ;------------------------------------------------------------
                                   1838 ;Allocation info for local variables in function 'set_weak_mods'
                                   1839 ;------------------------------------------------------------
                                   1840 ;mods          Allocated with name '_set_weak_mods_mods_10000_411'
                                   1841 ;------------------------------------------------------------
                                   1842 ;	quantum/action_util.c:520: void set_weak_mods(uint8_t mods) {
                                   1843 ;	-----------------------------------------
                                   1844 ;	 function clear_weak_mods
                                   1845 ;	-----------------------------------------
      0089ED                       1846 _clear_weak_mods:
                                   1847 ;	quantum/action_util.c:528: weak_mods = 0;
      0089ED 90 0E 4D         [24] 1848 	mov	dptr,#_weak_mods
      0089F0 E4               [12] 1849 	clr	a
      0089F1 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/action_util.c:529: }
      0089F2 22               [24] 1852 	ret
                                   1853 ;------------------------------------------------------------
                                   1854 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1855 ;------------------------------------------------------------
                                   1856 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_415'
                                   1857 ;------------------------------------------------------------
                                   1858 ;	quantum/action_util.c:611: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1859 ;	-----------------------------------------
                                   1860 	.area CSEG    (CODE)
                                   1861 	.area CONST   (CODE)
                                   1862 	.area XINIT   (CODE)
      00C99F                       1863 __xinit__real_mods:
      00C99F 00                    1864 	.db #0x00	; 0
      00C9A0                       1865 __xinit__weak_mods:
      00C9A0 00                    1866 	.db #0x00	; 0
      00C9A1                       1867 __xinit__actual_keyboard_report:
      00C9A1 00                    1868 	.db #0x00	; 0
      00C9A2 00                    1869 	.db #0x00	; 0
      00C9A3 00                    1870 	.db #0x00	; 0
      00C9A4 00                    1871 	.db #0x00	; 0
      00C9A5 00                    1872 	.db #0x00	; 0
      00C9A6 00                    1873 	.db #0x00	; 0
      00C9A7 00                    1874 	.db #0x00	; 0
      00C9A8 00                    1875 	.db #0x00	; 0
      00C9A9 00                    1876 	.db 0x00
      00C9AA 00                    1877 	.db 0x00
      00C9AB 00                    1878 	.db 0x00
      00C9AC 00                    1879 	.db 0x00
      00C9AD 00                    1880 	.db 0x00
      00C9AE 00                    1881 	.db 0x00
      00C9AF 00                    1882 	.db 0x00
      00C9B0 00                    1883 	.db 0x00
      00C9B1 00                    1884 	.db 0x00
      00C9B2 00                    1885 	.db 0x00
      00C9B3 00                    1886 	.db 0x00
      00C9B4 00                    1887 	.db 0x00
      00C9B5 00                    1888 	.db 0x00
      00C9B6 00                    1889 	.db 0x00
      00C9B7 00                    1890 	.db 0x00
      00C9B8 00                    1891 	.db 0x00
      00C9B9 00                    1892 	.db 0x00
      00C9BA 00                    1893 	.db 0x00
      00C9BB 00                    1894 	.db 0x00
      00C9BC 00                    1895 	.db 0x00
      00C9BD 00                    1896 	.db 0x00
      00C9BE 00                    1897 	.db 0x00
      00C9BF 00                    1898 	.db 0x00
      00C9C0 00                    1899 	.db 0x00
                                   1900 	.area CABS    (ABS,CODE)
                                   1901 
                                   1902 ; Experimental exact instruction outlining.
                                   1903 	.globl _ak820_outline_0017
                                   1904 	.globl _ak820_outline_0030
                                   1905 	.globl _ak820_outline_0057
                                   1906 	.globl _ak820_outline_0059
                                   1907 	.globl _ak820_outline_0061
                                   1908 	.globl _ak820_outline_0063
                                   1909 	.globl _ak820_outline_0064
                                   1910 	.globl _ak820_outline_0065
                                   1911 	.globl _ak820_outline_0068
                                   1912 	.globl _ak820_outline_0075
                                   1913 	.globl _ak820_outline_0078
                                   1914 	.globl _ak820_outline_0110
                                   1915 	.globl _ak820_outline_0111
                                   1916 	.globl _ak820_outline_0119
                                   1917 	.globl _ak820_outline_0123
                                   1918 	.globl _ak820_outline_0125
                                   1919 	.globl _ak820_outline_0128
                                   1920 	.globl _ak820_outline_0135
                                   1921 	.globl _ak820_outline_0136
                                   1922 	.globl _ak820_outline_0137
                                   1923 	.globl _ak820_outline_0141
                                   1924 	.globl _ak820_outline_0145
                                   1925 	.globl _ak820_outline_0148
                                   1926 	.globl _ak820_outline_0163
                                   1927 	.globl _ak820_outline_0166
                                   1928 	.globl _ak820_outline_0168
                                   1929 	.globl _ak820_outline_0184
                                   1930 	.globl _ak820_outline_0185
                                   1931 	.globl _ak820_outline_0191
                                   1932 	.globl _ak820_outline_0192
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0030
      0089F3                       1936 _ak820_outline_0030:
      0089F3 EF               [12] 1937 	mov	a,r7
      0089F4 24 1C            [12] 1938 	add	a,#_key_refs
      0089F6 FD               [12] 1939 	mov	r5,a
      0089F7 E4               [12] 1940 	clr	a
      0089F8 34 0A            [12] 1941 	addc	a,#(_key_refs>>8)
      0089FA FE               [12] 1942 	mov	r6,a
      0089FB 8D 82            [24] 1943 	mov	dpl,r5
      0089FD 8E 83            [24] 1944 	mov	dph,r6
      0089FF E0               [24] 1945 	movx	a,@dptr
      008A00 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0059
      008A01                       1950 _ak820_outline_0059:
      008A01 F0               [24] 1951 	movx	@dptr,a
      008A02 90 0E 4E         [24] 1952 	mov	dptr,#_actual_keyboard_report
      008A05 75 F0 00         [24] 1953 	mov	b,#0x00
      008A08 22               [24] 1954 	ret
                                   1955 
                                   1956 	.area CSEG (CODE)
                                   1957 ; function ak820_outline_0064
      008A09                       1958 _ak820_outline_0064:
      008A09 89 82            [24] 1959 	mov	dpl,r1
      008A0B 8A 83            [24] 1960 	mov	dph,r2
      008A0D E8               [12] 1961 	mov	a,r0
      008A0E F0               [24] 1962 	movx	@dptr,a
      008A0F 22               [24] 1963 	ret
                                   1964 
                                   1965 	.area CSEG (CODE)
                                   1966 ; function ak820_outline_0068
      008A10                       1967 _ak820_outline_0068:
      008A10 24 F7            [12] 1968 	add	a,#_usage_order
      008A12 F5 82            [12] 1969 	mov	dpl,a
      008A14 E4               [12] 1970 	clr	a
      008A15 34 0A            [12] 1971 	addc	a,#(_usage_order>>8)
      008A17 F5 83            [12] 1972 	mov	dph,a
      008A19 22               [24] 1973 	ret
                                   1974 
                                   1975 	.area CSEG (CODE)
                                   1976 ; function ak820_outline_0075
      008A1A                       1977 _ak820_outline_0075:
      008A1A EB               [12] 1978 	mov	a,r3
      008A1B 24 D9            [12] 1979 	add	a,#_usage_refs
      008A1D F9               [12] 1980 	mov	r1,a
      008A1E E4               [12] 1981 	clr	a
      008A1F 34 0A            [12] 1982 	addc	a,#(_usage_refs>>8)
      008A21 FA               [12] 1983 	mov	r2,a
      008A22 89 82            [24] 1984 	mov	dpl,r1
      008A24 8A 83            [24] 1985 	mov	dph,r2
      008A26 E0               [24] 1986 	movx	a,@dptr
      008A27 F8               [12] 1987 	mov	r0,a
      008A28 22               [24] 1988 	ret
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0119
      008A29                       1992 _ak820_outline_0119:
      008A29 F0               [24] 1993 	movx	@dptr,a
      008A2A E0               [24] 1994 	movx	a,@dptr
      008A2B FF               [12] 1995 	mov	r7,a
      008A2C 90 0A 14         [24] 1996 	mov	dptr,#_change_owned_PARM_2
      008A2F 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0123
      008A30                       2001 _ak820_outline_0123:
      008A30 8D 82            [24] 2002 	mov	dpl,r5
      008A32 8E 83            [24] 2003 	mov	dph,r6
      008A34 F0               [24] 2004 	movx	@dptr,a
      008A35 22               [24] 2005 	ret
                                   2006 
                                   2007 	.area CSEG (CODE)
                                   2008 ; function ak820_outline_0128
      008A36                       2009 _ak820_outline_0128:
      008A36 24 F7            [12] 2010 	add	a,#_usage_order
      008A38 F5 82            [12] 2011 	mov	dpl,a
      008A3A EF               [12] 2012 	mov	a,r7
      008A3B 34 0A            [12] 2013 	addc	a,#(_usage_order>>8)
      008A3D F5 83            [12] 2014 	mov	dph,a
      008A3F E0               [24] 2015 	movx	a,@dptr
      008A40 22               [24] 2016 	ret
                                   2017 
                                   2018 	.area CSEG (CODE)
                                   2019 ; function ak820_outline_0135
      008A41                       2020 _ak820_outline_0135:
      008A41 F0               [24] 2021 	movx	@dptr,a
      008A42 E0               [24] 2022 	movx	a,@dptr
      008A43 FF               [12] 2023 	mov	r7,a
      008A44 90 0A 10         [24] 2024 	mov	dptr,#_ak820_macro_change_PARM_2
      008A47 F0               [24] 2025 	movx	@dptr,a
      008A48 90 0A 11         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_3
      008A4B 22               [24] 2027 	ret
                                   2028 
                                   2029 	.area CSEG (CODE)
                                   2030 ; function ak820_outline_0192
      008A4C                       2031 _ak820_outline_0192:
      008A4C 8D 82            [24] 2032 	mov	dpl,r5
      008A4E 8F 83            [24] 2033 	mov	dph,r7
      008A50 22               [24] 2034 	ret
