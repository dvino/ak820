                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000018                        577 _control_setup_valid_interface_10000_288:
      000018                        578 	.ds 1
      000019                        579 _control_setup_zero_index_10000_288:
      000019                        580 	.ds 1
      00001A                        581 _control_setup_zero_value_10000_288:
      00001A                        582 	.ds 1
      00001B                        583 _control_setup_zero_length_10000_288:
      00001B                        584 	.ds 1
      00001C                        585 _control_setup_sloc0_1_0:
      00001C                        586 	.ds 1
      00001D                        587 _control_setup_sloc2_1_0:
      00001D                        588 	.ds 1
      00001E                        589 _ak820_usb_try_send_sloc0_1_0:
      00001E                        590 	.ds 1
      00001F                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001F                        592 	.ds 1
      000020                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      000020                        594 	.ds 1
      000021                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000021                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007E1                        605 _D0SetupReqCode::
      0007E1                        606 	.ds 1
      0007E2                        607 _D0SetupLen::
      0007E2                        608 	.ds 2
      0007E4                        609 _pD0Descr::
      0007E4                        610 	.ds 3
      0007E7                        611 _D0UsbConfig::
      0007E7                        612 	.ds 1
      0007E8                        613 _USB_EnumStatus::
      0007E8                        614 	.ds 1
      0007E9                        615 _USB_SleepStatus::
      0007E9                        616 	.ds 1
      0007EA                        617 _MCU_Sleep_Operate::
      0007EA                        618 	.ds 1
      0007EB                        619 _KB_USB_UpStatus::
      0007EB                        620 	.ds 1
      0007EC                        621 _KB_USB_SetReport::
      0007EC                        622 	.ds 1
      0007ED                        623 _ak820_boot_stage::
      0007ED                        624 	.ds 1
      0007EE                        625 _ak820_main_heartbeat::
      0007EE                        626 	.ds 1
      0007EF                        627 _raw_state:
      0007EF                        628 	.ds 1
      0007F0                        629 _raw_buffer:
      0007F0                        630 	.ds 32
      000810                        631 _raw_reply_without_nvm:
      000810                        632 	.ds 1
      000811                        633 _keyboard_reset:
      000811                        634 	.ds 1
      000812                        635 _input_snapshot:
      000812                        636 	.ds 52
      000846                        637 _control_phase:
      000846                        638 	.ds 1
      000847                        639 _output_kind:
      000847                        640 	.ds 1
      000848                        641 _output_report_id:
      000848                        642 	.ds 1
      000849                        643 _control_zlp:
      000849                        644 	.ds 1
      00084A                        645 _control_pointer:
      00084A                        646 	.ds 2
      00084C                        647 _descriptor_select_PARM_2:
      00084C                        648 	.ds 1
      00084D                        649 _descriptor_select_PARM_3:
      00084D                        650 	.ds 2
      00084F                        651 _descriptor_select_type_10000_270:
      00084F                        652 	.ds 1
      000850                        653 _control_setup_length_10000_288:
      000850                        654 	.ds 2
      000852                        655 _control_setup_offset_10000_288:
      000852                        656 	.ds 1
      000853                        657 _ak820_usb_send_PARM_2:
      000853                        658 	.ds 2
      000855                        659 _ak820_usb_send_PARM_3:
      000855                        660 	.ds 1
      000856                        661 _ak820_usb_send_endpoint_10000_424:
      000856                        662 	.ds 1
      000857                        663 _ak820_usb_send_offset_10000_425:
      000857                        664 	.ds 1
      000858                        665 _ak820_usb_try_send_PARM_2:
      000858                        666 	.ds 2
      00085A                        667 _ak820_usb_try_send_PARM_3:
      00085A                        668 	.ds 1
      00085B                        669 _ak820_usb_try_send_endpoint_10000_445:
      00085B                        670 	.ds 1
      00085C                        671 _ak820_usb_try_send_sent_10000_446:
      00085C                        672 	.ds 1
      00085D                        673 _ak820_usb_raw_send_PARM_2:
      00085D                        674 	.ds 1
      00085E                        675 _ak820_usb_raw_send_report_10000_461:
      00085E                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      006234                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      006234 90 07 EF         [24]  730 	mov	dptr,#_raw_state
      006237 E0               [24]  731 	movx	a,@dptr
      006238 FF               [12]  732 	mov	r7,a
      006239 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      00623C 80 1C            [24]  734 	sjmp	00101$
      00623E                        735 00130$:
      00623E 90 07 EF         [24]  736 	mov	dptr,#_raw_state
      006241 E0               [24]  737 	movx	a,@dptr
      006242 FF               [12]  738 	mov	r7,a
      006243 BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      006246 80 12            [24]  740 	sjmp	00101$
      006248                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      006248 90 07 EF         [24]  743 	mov	dptr,#_raw_state
      00624B E0               [24]  744 	movx	a,@dptr
      00624C FF               [12]  745 	mov	r7,a
      00624D BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      006250 80 08            [24]  747 	sjmp	00101$
      006252                        748 00132$:
      006252 90 07 EF         [24]  749 	mov	dptr,#_raw_state
      006255 E0               [24]  750 	movx	a,@dptr
      006256 FF               [12]  751 	mov	r7,a
      006257 BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      00625A                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      00625A 90 07 EF         [24]  755 	mov	dptr,#_raw_state
      00625D 74 07            [12]  756 	mov	a,#0x07
      00625F F0               [24]  757 	movx	@dptr,a
      006260 80 05            [24]  758 	sjmp	00103$
      006262                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      006262 90 07 EF         [24]  761 	mov	dptr,#_raw_state
      006265 E4               [12]  762 	clr	a
      006266 F0               [24]  763 	movx	@dptr,a
      006267                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      006267 90 08 47         [24]  766 	mov	dptr,#_output_kind
      00626A E4               [12]  767 	clr	a
      00626B F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      00626C 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      00626D                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      00626D 90 07 EF         [24]  780 	mov	dptr,#_raw_state
      006270 E0               [24]  781 	movx	a,@dptr
      006271 FF               [12]  782 	mov	r7,a
      006272 BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      006275 90 07 EF         [24]  784 	mov	dptr,#_raw_state
      006278 74 06            [12]  785 	mov	a,#0x06
      00627A F0               [24]  786 	movx	@dptr,a
      00627B 22               [24]  787 	ret
      00627C                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      00627C 90 07 EF         [24]  790 	mov	dptr,#_raw_state
      00627F E0               [24]  791 	movx	a,@dptr
      006280 FF               [12]  792 	mov	r7,a
      006281 BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      006284 90 07 EF         [24]  794 	mov	dptr,#_raw_state
      006287 E4               [12]  795 	clr	a
      006288 F0               [24]  796 	movx	@dptr,a
      006289                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      006289 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_260'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      00628A                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      00628A 90 22 0C         [24]  811 	mov	dptr,#0x220c
      00628D 74 01            [12]  812 	mov	a,#0x01
      00628F F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006290 F5 82            [12]  815 	mov	dpl,a
      006292 74 12            [12]  816 	mov	a,#0x12
      006294 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006295 A3               [24]  819 	inc	dptr
      006296 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006297 A3               [24]  822 	inc	dptr
      006298 F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      006299 90 22 0B         [24]  825 	mov	dptr,#0x220b
      00629C E4               [12]  826 	clr	a
      00629D F0               [24]  827 	movx	@dptr,a
      00629E 15 82            [12]  828 	dec	dpl
      0062A0 F0               [24]  829 	movx	@dptr,a
      0062A1 15 82            [12]  830 	dec	dpl
      0062A3 F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      0062A4 FF               [12]  833 	mov	r7,a
      0062A5                        834 00103$:
      0062A5 EF               [12]  835 	mov	a,r7
      0062A6 24 12            [12]  836 	add	a, #_input_snapshot
      0062A8 F5 82            [12]  837 	mov	dpl,a
      0062AA E4               [12]  838 	clr	a
      0062AB 34 08            [12]  839 	addc	a, #(_input_snapshot >> 8)
      0062AD F5 83            [12]  840 	mov	dph,a
      0062AF E4               [12]  841 	clr	a
      0062B0 F0               [24]  842 	movx	@dptr,a
      0062B1 0F               [12]  843 	inc	r7
      0062B2 BF 34 00         [24]  844 	cjne	r7,#0x34,00139$
      0062B5                        845 00139$:
      0062B5 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      0062B7 90 08 1A         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      0062BA 74 06            [12]  849 	mov	a,#0x06
      0062BC F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:118: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      0062BD 90 08 3A         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      0062C0 74 02            [12]  853 	mov	a,#0x02
      0062C2 F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      0062C3 90 08 40         [24]  856 	mov	dptr,#(_input_snapshot + 0x002e)
      0062C6 04               [12]  857 	inc	a
      0062C7 F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      0062C8 90 08 43         [24]  860 	mov	dptr,#(_input_snapshot + 0x0031)
      0062CB 04               [12]  861 	inc	a
      0062CC F0               [24]  862 	movx	@dptr,a
                                    863 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      0062CD 7F 00            [12]  864 	mov	r7,#0x00
      0062CF                        865 00105$:
      0062CF 8F 06            [24]  866 	mov	ar6,r7
      0062D1 74 C0            [12]  867 	mov	a,#0xc0
      0062D3 2E               [12]  868 	add	a, r6
      0062D4 F5 82            [12]  869 	mov	dpl,a
      0062D6 74 10            [12]  870 	mov	a,#0x10
      0062D8 24 00            [12]  871 	add	a, #0x00
      0062DA F5 83            [12]  872 	mov	dph,a
      0062DC E4               [12]  873 	clr	a
      0062DD F0               [24]  874 	movx	@dptr,a
      0062DE 0F               [12]  875 	inc	r7
      0062DF BF 20 00         [24]  876 	cjne	r7,#0x20,00141$
      0062E2                        877 00141$:
      0062E2 40 EB            [24]  878 	jc	00105$
                                    879 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    880 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      0062E4 02 62 34         [24]  881 	ljmp	_raw_abort
                                    882 ;------------------------------------------------------------
                                    883 ;Allocation info for local variables in function 'control_stall'
                                    884 ;------------------------------------------------------------
                                    885 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    886 ;	-----------------------------------------
                                    887 ;	 function control_stall
                                    888 ;	-----------------------------------------
      0062E7                        889 _control_stall:
                                    890 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      0062E7 90 07 EF         [24]  891 	mov	dptr,#_raw_state
      0062EA E0               [24]  892 	movx	a,@dptr
      0062EB FF               [12]  893 	mov	r7,a
      0062EC BF 01 05         [24]  894 	cjne	r7,#0x01,00102$
      0062EF 90 07 EF         [24]  895 	mov	dptr,#_raw_state
      0062F2 E4               [12]  896 	clr	a
      0062F3 F0               [24]  897 	movx	@dptr,a
      0062F4                        898 00102$:
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      0062F4 90 08 47         [24]  900 	mov	dptr,#_output_kind
      0062F7 E4               [12]  901 	clr	a
      0062F8 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      0062F9 90 08 46         [24]  904 	mov	dptr,#_control_phase
      0062FC F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      0062FD 90 07 E1         [24]  907 	mov	dptr,#_D0SetupReqCode
      006300 14               [12]  908 	dec	a
      006301 F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      006302 90 22 00         [24]  911 	mov	dptr,#0x2200
      006305 74 CF            [12]  912 	mov	a,#0xcf
      006307 F0               [24]  913 	movx	@dptr,a
                                    914 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      006308 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'control_next'
                                    918 ;------------------------------------------------------------
                                    919 ;i             Allocated with name '_control_next_i_10000_267'
                                    920 ;length        Allocated with name '_control_next_length_10000_267'
                                    921 ;------------------------------------------------------------
                                    922 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function control_next
                                    925 ;	-----------------------------------------
      006309                        926 _control_next:
                                    927 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      006309 90 07 E2         [24]  928 	mov	dptr,#_D0SetupLen
      00630C E0               [24]  929 	movx	a,@dptr
      00630D FE               [12]  930 	mov	r6,a
      00630E A3               [24]  931 	inc	dptr
      00630F E0               [24]  932 	movx	a,@dptr
      006310 FF               [12]  933 	mov	r7,a
      006311 C3               [12]  934 	clr	c
      006312 74 40            [12]  935 	mov	a,#0x40
      006314 9E               [12]  936 	subb	a,r6
      006315 E4               [12]  937 	clr	a
      006316 9F               [12]  938 	subb	a,r7
      006317 50 04            [24]  939 	jnc	00109$
                                    940 ;	free result
      006319 7E 40            [12]  941 	mov	r6,#0x40
      00631B 80 07            [24]  942 	sjmp	00110$
      00631D                        943 00109$:
      00631D 90 07 E2         [24]  944 	mov	dptr,#_D0SetupLen
      006320 E0               [24]  945 	movx	a,@dptr
      006321 FE               [12]  946 	mov	r6,a
      006322 A3               [24]  947 	inc	dptr
      006323 E0               [24]  948 	movx	a,@dptr
      006324                        949 00110$:
                                    950 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      006324 7F 00            [12]  951 	mov	r7,#0x00
      006326                        952 00105$:
      006326 C3               [12]  953 	clr	c
      006327 EF               [12]  954 	mov	a,r7
      006328 9E               [12]  955 	subb	a,r6
      006329 50 2A            [24]  956 	jnc	00101$
      00632B 8F 04            [24]  957 	mov	ar4,r7
      00632D 74 10            [12]  958 	mov	a,#0x10
      00632F 24 00            [12]  959 	add	a, #0x00
      006331 FD               [12]  960 	mov	r5,a
      006332 90 08 4A         [24]  961 	mov	dptr,#_control_pointer
      006335 E0               [24]  962 	movx	a,@dptr
      006336 FA               [12]  963 	mov	r2,a
      006337 A3               [24]  964 	inc	dptr
      006338 E0               [24]  965 	movx	a,@dptr
      006339 FB               [12]  966 	mov	r3,a
      00633A 8A 82            [24]  967 	mov	dpl,r2
      00633C 8B 83            [24]  968 	mov	dph,r3
      00633E E4               [12]  969 	clr	a
      00633F 93               [24]  970 	movc	a,@a+dptr
      006340 F9               [12]  971 	mov	r1,a
      006341 90 08 4A         [24]  972 	mov	dptr,#_control_pointer
      006344 74 01            [12]  973 	mov	a,#0x01
      006346 2A               [12]  974 	add	a, r2
      006347 F0               [24]  975 	movx	@dptr,a
      006348 E4               [12]  976 	clr	a
      006349 3B               [12]  977 	addc	a, r3
      00634A A3               [24]  978 	inc	dptr
      00634B F0               [24]  979 	movx	@dptr,a
      00634C 8C 82            [24]  980 	mov	dpl,r4
      00634E 8D 83            [24]  981 	mov	dph,r5
      006350 E9               [12]  982 	mov	a,r1
      006351 F0               [24]  983 	movx	@dptr,a
      006352 0F               [12]  984 	inc	r7
      006353 80 D1            [24]  985 	sjmp	00105$
      006355                        986 00101$:
                                    987 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      006355 8E 05            [24]  988 	mov	ar5,r6
      006357 7F 00            [12]  989 	mov	r7,#0x00
      006359 90 07 E2         [24]  990 	mov	dptr,#_D0SetupLen
      00635C E0               [24]  991 	movx	a,@dptr
      00635D FB               [12]  992 	mov	r3,a
      00635E A3               [24]  993 	inc	dptr
      00635F E0               [24]  994 	movx	a,@dptr
      006360 FC               [12]  995 	mov	r4,a
      006361 EB               [12]  996 	mov	a,r3
      006362 C3               [12]  997 	clr	c
      006363 9D               [12]  998 	subb	a,r5
      006364 FB               [12]  999 	mov	r3,a
      006365 EC               [12] 1000 	mov	a,r4
      006366 9F               [12] 1001 	subb	a,r7
      006367 FC               [12] 1002 	mov	r4,a
      006368 90 07 E2         [24] 1003 	mov	dptr,#_D0SetupLen
      00636B EB               [12] 1004 	mov	a,r3
      00636C F0               [24] 1005 	movx	@dptr,a
      00636D EC               [12] 1006 	mov	a,r4
      00636E A3               [24] 1007 	inc	dptr
      00636F F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      006370 EE               [12] 1010 	mov	a,r6
      006371 70 05            [24] 1011 	jnz	00103$
      006373 90 08 49         [24] 1012 	mov	dptr,#_control_zlp
      006376 E4               [12] 1013 	clr	a
      006377 F0               [24] 1014 	movx	@dptr,a
      006378                       1015 00103$:
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      006378 90 22 08         [24] 1017 	mov	dptr,#0x2208
      00637B EE               [12] 1018 	mov	a,r6
      00637C F0               [24] 1019 	movx	@dptr,a
                                   1020 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      00637D 90 22 00         [24] 1021 	mov	dptr,#0x2200
      006380 E0               [24] 1022 	movx	a,@dptr
      006381 54 C0            [12] 1023 	anl	a,#0xc0
      006383 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      006384 22               [24] 1026 	ret
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'descriptor_select'
                                   1029 ;------------------------------------------------------------
                                   1030 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1031 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1032 ;type          Allocated with name '_descriptor_select_type_10000_270'
                                   1033 ;hid           Allocated with name '_descriptor_select_hid_30000_283'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function descriptor_select
                                   1038 ;	-----------------------------------------
      006385                       1039 _descriptor_select:
      006385 E5 82            [12] 1040 	mov	a,dpl
      006387 90 08 4F         [24] 1041 	mov	dptr,#_descriptor_select_type_10000_270
      00638A F0               [24] 1042 	movx	@dptr,a
                                   1043 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      00638B E0               [24] 1044 	movx	a,@dptr
      00638C FF               [12] 1045 	mov	r7,a
      00638D BF 01 20         [24] 1046 	cjne	r7,#0x01,00102$
      006390 90 08 4C         [24] 1047 	mov	dptr,#_descriptor_select_PARM_2
      006393 E0               [24] 1048 	movx	a,@dptr
      006394 70 1A            [24] 1049 	jnz	00102$
      006396 90 08 4D         [24] 1050 	mov	dptr,#_descriptor_select_PARM_3
      006399 E0               [24] 1051 	movx	a,@dptr
      00639A F5 F0            [12] 1052 	mov	b,a
      00639C A3               [24] 1053 	inc	dptr
      00639D E0               [24] 1054 	movx	a,@dptr
      00639E 45 F0            [12] 1055 	orl	a,b
      0063A0 70 0E            [24] 1056 	jnz	00102$
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      0063A2 90 08 4A         [24] 1058 	mov	dptr,#_control_pointer
      0063A5 74 BB            [12] 1059 	mov	a,#_DeviceDescriptor
      0063A7 F0               [24] 1060 	movx	@dptr,a
      0063A8 74 C8            [12] 1061 	mov	a,#(_DeviceDescriptor >> 8)
      0063AA A3               [24] 1062 	inc	dptr
      0063AB F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      0063AC 90 00 12         [24] 1065 	mov	dptr,#0x0012
      0063AF 22               [24] 1066 	ret
      0063B0                       1067 00102$:
                                   1068 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      0063B0 90 08 4F         [24] 1069 	mov	dptr,#_descriptor_select_type_10000_270
      0063B3 E0               [24] 1070 	movx	a,@dptr
      0063B4 FF               [12] 1071 	mov	r7,a
      0063B5 BF 02 20         [24] 1072 	cjne	r7,#0x02,00106$
      0063B8 90 08 4C         [24] 1073 	mov	dptr,#_descriptor_select_PARM_2
      0063BB E0               [24] 1074 	movx	a,@dptr
      0063BC 70 1A            [24] 1075 	jnz	00106$
      0063BE 90 08 4D         [24] 1076 	mov	dptr,#_descriptor_select_PARM_3
      0063C1 E0               [24] 1077 	movx	a,@dptr
      0063C2 F5 F0            [12] 1078 	mov	b,a
      0063C4 A3               [24] 1079 	inc	dptr
      0063C5 E0               [24] 1080 	movx	a,@dptr
      0063C6 45 F0            [12] 1081 	orl	a,b
      0063C8 70 0E            [24] 1082 	jnz	00106$
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      0063CA 90 08 4A         [24] 1084 	mov	dptr,#_control_pointer
      0063CD 74 CD            [12] 1085 	mov	a,#_ConfigurationDescriptor
      0063CF F0               [24] 1086 	movx	@dptr,a
      0063D0 74 C8            [12] 1087 	mov	a,#(_ConfigurationDescriptor >> 8)
      0063D2 A3               [24] 1088 	inc	dptr
      0063D3 F0               [24] 1089 	movx	@dptr,a
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      0063D4 90 00 54         [24] 1091 	mov	dptr,#0x0054
      0063D7 22               [24] 1092 	ret
      0063D8                       1093 00106$:
                                   1094 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      0063D8 90 08 4F         [24] 1095 	mov	dptr,#_descriptor_select_type_10000_270
      0063DB E0               [24] 1096 	movx	a,@dptr
      0063DC FF               [12] 1097 	mov	r7,a
      0063DD BF 03 02         [24] 1098 	cjne	r7,#0x03,00238$
      0063E0 80 03            [24] 1099 	sjmp	00239$
      0063E2                       1100 00238$:
      0063E2 02 64 7C         [24] 1101 	ljmp	00119$
      0063E5                       1102 00239$:
                                   1103 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      0063E5 90 08 4D         [24] 1104 	mov	dptr,#_descriptor_select_PARM_3
      0063E8 E0               [24] 1105 	movx	a,@dptr
      0063E9 FD               [12] 1106 	mov	r5,a
      0063EA A3               [24] 1107 	inc	dptr
      0063EB E0               [24] 1108 	movx	a,@dptr
      0063EC FE               [12] 1109 	mov	r6,a
      0063ED 90 08 4D         [24] 1110 	mov	dptr,#_descriptor_select_PARM_3
      0063F0 E0               [24] 1111 	movx	a,@dptr
      0063F1 F5 F0            [12] 1112 	mov	b,a
      0063F3 A3               [24] 1113 	inc	dptr
      0063F4 E0               [24] 1114 	movx	a,@dptr
      0063F5 45 F0            [12] 1115 	orl	a,b
      0063F7 60 0C            [24] 1116 	jz	00110$
      0063F9 BD 09 05         [24] 1117 	cjne	r5,#0x09,00241$
      0063FC BE 04 02         [24] 1118 	cjne	r6,#0x04,00241$
      0063FF 80 04            [24] 1119 	sjmp	00110$
      006401                       1120 00241$:
      006401 90 00 00         [24] 1121 	mov	dptr,#0x0000
      006404 22               [24] 1122 	ret
      006405                       1123 00110$:
                                   1124 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      006405 90 08 4C         [24] 1125 	mov	dptr,#_descriptor_select_PARM_2
      006408 E0               [24] 1126 	movx	a,@dptr
      006409 FE               [12] 1127 	mov  r6,a
      00640A 24 FC            [12] 1128 	add	a,#0xff - 0x03
      00640C 40 6A            [24] 1129 	jc	00116$
                                   1130 ;	free result
      00640E EE               [12] 1131 	mov	a,r6
      00640F 2E               [12] 1132 	add	a,r6
                                   1133 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      006410 90 64 14         [24] 1134 	mov	dptr,#00243$
      006413 73               [24] 1135 	jmp	@a+dptr
      006414                       1136 00243$:
      006414 80 06            [24] 1137 	sjmp	00112$
      006416 80 1B            [24] 1138 	sjmp	00113$
      006418 80 30            [24] 1139 	sjmp	00114$
      00641A 80 45            [24] 1140 	sjmp	00115$
      00641C                       1141 00112$:
      00641C 90 08 4A         [24] 1142 	mov	dptr,#_control_pointer
      00641F 74 21            [12] 1143 	mov	a,#_LanguageString
      006421 F0               [24] 1144 	movx	@dptr,a
      006422 74 C9            [12] 1145 	mov	a,#(_LanguageString >> 8)
      006424 A3               [24] 1146 	inc	dptr
      006425 F0               [24] 1147 	movx	@dptr,a
      006426 90 C9 21         [24] 1148 	mov	dptr,#_LanguageString
      006429 E4               [12] 1149 	clr	a
      00642A 93               [24] 1150 	movc	a,@a+dptr
      00642B FE               [12] 1151 	mov	r6,a
      00642C 7D 00            [12] 1152 	mov	r5,#0x00
      00642E 8E 82            [24] 1153 	mov	dpl, r6
      006430 8D 83            [24] 1154 	mov	dph, r5
      006432 22               [24] 1155 	ret
                                   1156 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      006433                       1157 00113$:
      006433 90 08 4A         [24] 1158 	mov	dptr,#_control_pointer
      006436 74 25            [12] 1159 	mov	a,#_ManufacturerString
      006438 F0               [24] 1160 	movx	@dptr,a
      006439 74 C9            [12] 1161 	mov	a,#(_ManufacturerString >> 8)
      00643B A3               [24] 1162 	inc	dptr
      00643C F0               [24] 1163 	movx	@dptr,a
      00643D 90 C9 25         [24] 1164 	mov	dptr,#_ManufacturerString
      006440 E4               [12] 1165 	clr	a
      006441 93               [24] 1166 	movc	a,@a+dptr
      006442 FE               [12] 1167 	mov	r6,a
      006443 7D 00            [12] 1168 	mov	r5,#0x00
      006445 8E 82            [24] 1169 	mov	dpl, r6
      006447 8D 83            [24] 1170 	mov	dph, r5
      006449 22               [24] 1171 	ret
                                   1172 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      00644A                       1173 00114$:
      00644A 90 08 4A         [24] 1174 	mov	dptr,#_control_pointer
      00644D 74 33            [12] 1175 	mov	a,#_ProductString
      00644F F0               [24] 1176 	movx	@dptr,a
      006450 74 C9            [12] 1177 	mov	a,#(_ProductString >> 8)
      006452 A3               [24] 1178 	inc	dptr
      006453 F0               [24] 1179 	movx	@dptr,a
      006454 90 C9 33         [24] 1180 	mov	dptr,#_ProductString
      006457 E4               [12] 1181 	clr	a
      006458 93               [24] 1182 	movc	a,@a+dptr
      006459 FE               [12] 1183 	mov	r6,a
      00645A 7D 00            [12] 1184 	mov	r5,#0x00
      00645C 8E 82            [24] 1185 	mov	dpl, r6
      00645E 8D 83            [24] 1186 	mov	dph, r5
      006460 22               [24] 1187 	ret
                                   1188 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      006461                       1189 00115$:
      006461 90 08 4A         [24] 1190 	mov	dptr,#_control_pointer
      006464 74 6B            [12] 1191 	mov	a,#_SerialNumberString
      006466 F0               [24] 1192 	movx	@dptr,a
      006467 74 C9            [12] 1193 	mov	a,#(_SerialNumberString >> 8)
      006469 A3               [24] 1194 	inc	dptr
      00646A F0               [24] 1195 	movx	@dptr,a
      00646B 90 C9 6B         [24] 1196 	mov	dptr,#_SerialNumberString
      00646E E4               [12] 1197 	clr	a
      00646F 93               [24] 1198 	movc	a,@a+dptr
      006470 FE               [12] 1199 	mov	r6,a
      006471 7D 00            [12] 1200 	mov	r5,#0x00
      006473 8E 82            [24] 1201 	mov	dpl, r6
      006475 8D 83            [24] 1202 	mov	dph, r5
      006477 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      006478                       1205 00116$:
      006478 90 00 00         [24] 1206 	mov	dptr,#0x0000
      00647B 22               [24] 1207 	ret
                                   1208 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      00647C                       1209 00119$:
                                   1210 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      00647C 90 08 4C         [24] 1211 	mov	dptr,#_descriptor_select_PARM_2
      00647F E0               [24] 1212 	movx	a,@dptr
      006480 70 11            [24] 1213 	jnz	00120$
      006482 90 08 4D         [24] 1214 	mov	dptr,#_descriptor_select_PARM_3
      006485 E0               [24] 1215 	movx	a,@dptr
      006486 FD               [12] 1216 	mov	r5,a
      006487 A3               [24] 1217 	inc	dptr
      006488 E0               [24] 1218 	movx	a,@dptr
      006489 FE               [12] 1219 	mov	r6,a
      00648A C3               [12] 1220 	clr	c
      00648B ED               [12] 1221 	mov	a,r5
      00648C 94 03            [12] 1222 	subb	a,#0x03
      00648E EE               [12] 1223 	mov	a,r6
      00648F 94 00            [12] 1224 	subb	a,#0x00
      006491 40 04            [24] 1225 	jc	00121$
      006493                       1226 00120$:
      006493 90 00 00         [24] 1227 	mov	dptr,#0x0000
      006496 22               [24] 1228 	ret
      006497                       1229 00121$:
                                   1230 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006497 BF 22 02         [24] 1231 	cjne	r7,#0x22,00246$
      00649A 80 03            [24] 1232 	sjmp	00127$
      00649C                       1233 00246$:
      00649C BF 21 5D         [24] 1234 	cjne	r7,#0x21,00128$
      00649F                       1235 00127$:
                                   1236 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      00649F ED               [12] 1237 	mov	a,r5
      0064A0 75 F0 04         [24] 1238 	mov	b,#0x04
      0064A3 A4               [48] 1239 	mul	ab
      0064A4 24 F3            [12] 1240 	add	a, #_interface_descriptors
      0064A6 FE               [12] 1241 	mov	r6,a
      0064A7 74 C1            [12] 1242 	mov	a,#(_interface_descriptors >> 8)
      0064A9 35 F0            [12] 1243 	addc	a, b
      0064AB FF               [12] 1244 	mov	r7,a
      0064AC 8E 82            [24] 1245 	mov	dpl,r6
      0064AE 8F 83            [24] 1246 	mov	dph,r7
      0064B0 A3               [24] 1247 	inc	dptr
      0064B1 A3               [24] 1248 	inc	dptr
      0064B2 E4               [12] 1249 	clr	a
      0064B3 93               [24] 1250 	movc	a,@a+dptr
      0064B4 FC               [12] 1251 	mov	r4,a
      0064B5 A3               [24] 1252 	inc	dptr
      0064B6 E4               [12] 1253 	clr	a
      0064B7 93               [24] 1254 	movc	a,@a+dptr
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      0064B8 FD               [12] 1256 	mov	r5,a
      0064B9 4C               [12] 1257 	orl	a,r4
      0064BA 70 04            [24] 1258 	jnz	00124$
      0064BC 90 00 00         [24] 1259 	mov	dptr,#0x0000
      0064BF 22               [24] 1260 	ret
      0064C0                       1261 00124$:
                                   1262 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      0064C0 90 08 4F         [24] 1263 	mov	dptr,#_descriptor_select_type_10000_270
      0064C3 E0               [24] 1264 	movx	a,@dptr
      0064C4 FB               [12] 1265 	mov	r3,a
      0064C5 BB 22 28         [24] 1266 	cjne	r3,#0x22,00126$
                                   1267 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      0064C8 8E 82            [24] 1268 	mov	dpl,r6
      0064CA 8F 83            [24] 1269 	mov	dph,r7
      0064CC E4               [12] 1270 	clr	a
      0064CD 93               [24] 1271 	movc	a,@a+dptr
      0064CE FE               [12] 1272 	mov	r6,a
      0064CF A3               [24] 1273 	inc	dptr
      0064D0 E4               [12] 1274 	clr	a
      0064D1 93               [24] 1275 	movc	a,@a+dptr
      0064D2 FF               [12] 1276 	mov	r7,a
      0064D3 90 08 4A         [24] 1277 	mov	dptr,#_control_pointer
      0064D6 EE               [12] 1278 	mov	a,r6
      0064D7 F0               [24] 1279 	movx	@dptr,a
      0064D8 EF               [12] 1280 	mov	a,r7
      0064D9 A3               [24] 1281 	inc	dptr
      0064DA F0               [24] 1282 	movx	@dptr,a
                                   1283 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      0064DB 74 07            [12] 1284 	mov	a,#0x07
      0064DD 2C               [12] 1285 	add	a, r4
      0064DE F5 82            [12] 1286 	mov	dpl,a
      0064E0 E4               [12] 1287 	clr	a
      0064E1 3D               [12] 1288 	addc	a, r5
      0064E2 F5 83            [12] 1289 	mov	dph,a
      0064E4 E4               [12] 1290 	clr	a
      0064E5 93               [24] 1291 	movc	a,@a+dptr
      0064E6 FE               [12] 1292 	mov	r6,a
      0064E7 A3               [24] 1293 	inc	dptr
      0064E8 E4               [12] 1294 	clr	a
      0064E9 93               [24] 1295 	movc	a,@a+dptr
      0064EA FF               [12] 1296 	mov	r7,a
      0064EB 8E 82            [24] 1297 	mov	dpl, r6
      0064ED 8F 83            [24] 1298 	mov	dph, r7
      0064EF 22               [24] 1299 	ret
      0064F0                       1300 00126$:
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      0064F0 90 08 4A         [24] 1302 	mov	dptr,#_control_pointer
      0064F3 EC               [12] 1303 	mov	a,r4
      0064F4 F0               [24] 1304 	movx	@dptr,a
      0064F5 ED               [12] 1305 	mov	a,r5
      0064F6 A3               [24] 1306 	inc	dptr
      0064F7 F0               [24] 1307 	movx	@dptr,a
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      0064F8 90 00 09         [24] 1309 	mov	dptr,#0x0009
      0064FB 22               [24] 1310 	ret
      0064FC                       1311 00128$:
                                   1312 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      0064FC 90 00 00         [24] 1313 	mov	dptr,#0x0000
                                   1314 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      0064FF 22               [24] 1315 	ret
                                   1316 ;------------------------------------------------------------
                                   1317 ;Allocation info for local variables in function 'control_setup'
                                   1318 ;------------------------------------------------------------
                                   1319 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1320 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1321 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1322 ;type          Allocated with name '_control_setup_type_10000_288'
                                   1323 ;value         Allocated with name '_control_setup_value_10000_288'
                                   1324 ;index         Allocated with name '_control_setup_index_10000_288'
                                   1325 ;length        Allocated with name '_control_setup_length_10000_288'
                                   1326 ;endpoint      Allocated with name '_control_setup_endpoint_10000_288'
                                   1327 ;i             Allocated with name '_control_setup_i_10000_288'
                                   1328 ;offset        Allocated with name '_control_setup_offset_10000_288'
                                   1329 ;report_id     Allocated with name '_control_setup_report_id_10000_288'
                                   1330 ;------------------------------------------------------------
                                   1331 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1332 ;	-----------------------------------------
                                   1333 ;	 function control_setup
                                   1334 ;	-----------------------------------------
      006500                       1335 _control_setup:
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006500 90 10 00         [24] 1337 	mov	dptr,#0x1000
      006503 E0               [24] 1338 	movx	a,@dptr
      006504 FF               [12] 1339 	mov	r7,a
                                   1340 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006505 A3               [24] 1341 	inc	dptr
      006506 A3               [24] 1342 	inc	dptr
      006507 E0               [24] 1343 	movx	a,@dptr
      006508 FE               [12] 1344 	mov	r6,a
      006509 A3               [24] 1345 	inc	dptr
      00650A E0               [24] 1346 	movx	a,@dptr
      00650B FC               [12] 1347 	mov	r4,a
      00650C 7D 00            [12] 1348 	mov	r5,#0x00
      00650E 8E 03            [24] 1349 	mov	ar3,r6
      006510 7E 00            [12] 1350 	mov	r6,#0x00
      006512 ED               [12] 1351 	mov	a,r5
      006513 4B               [12] 1352 	orl	a,r3
      006514 FD               [12] 1353 	mov	r5,a
      006515 EC               [12] 1354 	mov	a,r4
      006516 4E               [12] 1355 	orl	a,r6
      006517 FE               [12] 1356 	mov	r6,a
                                   1357 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006518 A3               [24] 1358 	inc	dptr
      006519 E0               [24] 1359 	movx	a,@dptr
      00651A FC               [12] 1360 	mov	r4,a
      00651B A3               [24] 1361 	inc	dptr
      00651C E0               [24] 1362 	movx	a,@dptr
      00651D FA               [12] 1363 	mov	r2,a
      00651E 7B 00            [12] 1364 	mov	r3,#0x00
      006520 8C 01            [24] 1365 	mov	ar1,r4
      006522 7C 00            [12] 1366 	mov	r4,#0x00
      006524 EB               [12] 1367 	mov	a,r3
      006525 49               [12] 1368 	orl	a,r1
      006526 FB               [12] 1369 	mov	r3,a
      006527 EA               [12] 1370 	mov	a,r2
      006528 4C               [12] 1371 	orl	a,r4
      006529 FC               [12] 1372 	mov	r4,a
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      00652A C3               [12] 1374 	clr	c
      00652B EB               [12] 1375 	mov	a,r3
      00652C 94 03            [12] 1376 	subb	a,#0x03
      00652E EC               [12] 1377 	mov	a,r4
      00652F 94 00            [12] 1378 	subb	a,#0x00
      006531 92 18            [24] 1379 	mov	_control_setup_valid_interface_10000_288,c
                                   1380 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      006533 EB               [12] 1381 	mov	a,r3
      006534 4C               [12] 1382 	orl	a,r4
      006535 B4 01 00         [24] 1383 	cjne	a,#0x01,01201$
      006538                       1384 01201$:
      006538 92 19            [24] 1385 	mov	_control_setup_zero_index_10000_288,c
                                   1386 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      00653A ED               [12] 1387 	mov	a,r5
      00653B 4E               [12] 1388 	orl	a,r6
      00653C B4 01 00         [24] 1389 	cjne	a,#0x01,01202$
      00653F                       1390 01202$:
                                   1391 ;	assignBit
      00653F 92 1C            [24] 1392 	mov  _control_setup_sloc0_1_0,c
      006541 92 1A            [24] 1393 	mov	_control_setup_zero_value_10000_288,c
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      006543 90 08 52         [24] 1395 	mov	dptr,#_control_setup_offset_10000_288
      006546 E4               [12] 1396 	clr	a
      006547 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006548 90 07 EF         [24] 1399 	mov	dptr,#_raw_state
      00654B E0               [24] 1400 	movx	a,@dptr
      00654C FA               [12] 1401 	mov	r2,a
      00654D BA 01 05         [24] 1402 	cjne	r2,#0x01,00102$
      006550 90 07 EF         [24] 1403 	mov	dptr,#_raw_state
      006553 E4               [12] 1404 	clr	a
      006554 F0               [24] 1405 	movx	@dptr,a
      006555                       1406 00102$:
                                   1407 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      006555 C0 07            [24] 1408 	push	ar7
      006557 90 08 47         [24] 1409 	mov	dptr,#_output_kind
      00655A E4               [12] 1410 	clr	a
      00655B F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      00655C 90 08 46         [24] 1413 	mov	dptr,#_control_phase
      00655F F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      006560 90 08 49         [24] 1416 	mov	dptr,#_control_zlp
      006563 F0               [24] 1417 	movx	@dptr,a
                                   1418 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006564 90 10 01         [24] 1419 	mov	dptr,#0x1001
      006567 E0               [24] 1420 	movx	a,@dptr
      006568 90 07 E1         [24] 1421 	mov	dptr,#_D0SetupReqCode
      00656B F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00656C 90 10 06         [24] 1424 	mov	dptr,#0x1006
      00656F E0               [24] 1425 	movx	a,@dptr
      006570 FA               [12] 1426 	mov	r2,a
      006571 A3               [24] 1427 	inc	dptr
      006572 E0               [24] 1428 	movx	a,@dptr
      006573 F9               [12] 1429 	mov	r1,a
      006574 78 00            [12] 1430 	mov	r0,#0x00
      006576 7F 00            [12] 1431 	mov	r7,#0x00
      006578 90 07 E2         [24] 1432 	mov	dptr,#_D0SetupLen
      00657B E8               [12] 1433 	mov	a,r0
      00657C 4A               [12] 1434 	orl	a,r2
      00657D F0               [24] 1435 	movx	@dptr,a
      00657E E9               [12] 1436 	mov	a,r1
      00657F 4F               [12] 1437 	orl	a,r7
      006580 A3               [24] 1438 	inc	dptr
      006581 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      006582 90 07 E2         [24] 1441 	mov	dptr,#_D0SetupLen
      006585 E0               [24] 1442 	movx	a,@dptr
      006586 FA               [12] 1443 	mov	r2,a
      006587 A3               [24] 1444 	inc	dptr
      006588 E0               [24] 1445 	movx	a,@dptr
      006589 4A               [12] 1446 	orl	a,r2
      00658A B4 01 00         [24] 1447 	cjne	a,#0x01,01205$
      00658D                       1448 01205$:
      00658D 92 1B            [24] 1449 	mov	_control_setup_zero_length_10000_288,c
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00658F 90 22 00         [24] 1451 	mov	dptr,#0x2200
      006592 74 C2            [12] 1452 	mov	a,#0xc2
      006594 F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      006595 90 22 08         [24] 1455 	mov	dptr,#0x2208
      006598 E4               [12] 1456 	clr	a
      006599 F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      00659A 90 07 E1         [24] 1459 	mov	dptr,#_D0SetupReqCode
      00659D E0               [24] 1460 	movx	a,@dptr
      00659E F5 16            [12] 1461 	mov	_control_setup_sloc1_1_0,a
      0065A0 C3               [12] 1462 	clr	c
      0065A1 74 0B            [12] 1463 	mov	a,#0x0b
      0065A3 95 16            [12] 1464 	subb	a,_control_setup_sloc1_1_0
      0065A5 D0 07            [24] 1465 	pop	ar7
      0065A7 50 03            [24] 1466 	jnc	01206$
      0065A9 02 62 E7         [24] 1467 	ljmp	_control_stall
      0065AC                       1468 01206$:
                                   1469 ;	free result
      0065AC E5 16            [12] 1470 	mov	a,_control_setup_sloc1_1_0
      0065AE F5 F0            [12] 1471 	mov	b,a
      0065B0 24 0B            [12] 1472 	add	a,#(01207$-3-.)
      0065B2 83               [24] 1473 	movc	a,@a+pc
      0065B3 F5 82            [12] 1474 	mov	dpl,a
      0065B5 E5 F0            [12] 1475 	mov	a,b
      0065B7 24 10            [12] 1476 	add	a,#(01208$-3-.)
      0065B9 83               [24] 1477 	movc	a,@a+pc
      0065BA F5 83            [12] 1478 	mov	dph,a
      0065BC E4               [12] 1479 	clr	a
      0065BD 73               [24] 1480 	jmp	@a+dptr
      0065BE                       1481 01207$:
      0065BE 66                    1482 	.db	00188$
      0065BF 0C                    1483 	.db	00205$
      0065C0 4F                    1484 	.db	00282$
      0065C1 0C                    1485 	.db	00205$
      0065C2 93                    1486 	.db	00290$
      0065C3 90                    1487 	.db	00116$
      0065C4 D6                    1488 	.db	00103$
      0065C5 93                    1489 	.db	00290$
      0065C6 95                    1490 	.db	00150$
      0065C7 B9                    1491 	.db	00123$
      0065C8 C5                    1492 	.db	00157$
      0065C9 18                    1493 	.db	00173$
      0065CA                       1494 01208$:
      0065CA 68                    1495 	.db	00188$>>8
      0065CB 69                    1496 	.db	00205$>>8
      0065CC 6C                    1497 	.db	00282$>>8
      0065CD 69                    1498 	.db	00205$>>8
      0065CE 6C                    1499 	.db	00290$>>8
      0065CF 66                    1500 	.db	00116$>>8
      0065D0 65                    1501 	.db	00103$>>8
      0065D1 6C                    1502 	.db	00290$>>8
      0065D2 67                    1503 	.db	00150$>>8
      0065D3 66                    1504 	.db	00123$>>8
      0065D4 67                    1505 	.db	00157$>>8
      0065D5 68                    1506 	.db	00173$>>8
                                   1507 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      0065D6                       1508 00103$:
                                   1509 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      0065D6 BF 80 02         [24] 1510 	cjne	r7,#0x80,01209$
      0065D9 80 08            [24] 1511 	sjmp	00112$
      0065DB                       1512 01209$:
      0065DB BF 81 02         [24] 1513 	cjne	r7,#0x81,01210$
      0065DE 80 03            [24] 1514 	sjmp	01211$
      0065E0                       1515 01210$:
      0065E0 02 62 E7         [24] 1516 	ljmp	_control_stall
      0065E3                       1517 01211$:
      0065E3                       1518 00112$:
                                   1519 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0065E3 8E 01            [24] 1520 	mov	ar1,r6
      0065E5 B9 21 02         [24] 1521 	cjne	r1,#0x21,01212$
      0065E8 80 09            [24] 1522 	sjmp	00301$
      0065EA                       1523 01212$:
      0065EA B9 22 02         [24] 1524 	cjne	r1,#0x22,01213$
      0065ED 80 04            [24] 1525 	sjmp	00301$
      0065EF                       1526 01213$:
                                   1527 ;	assignBit
      0065EF C2 1D            [12] 1528 	clr	_control_setup_sloc2_1_0
      0065F1 80 02            [24] 1529 	sjmp	00302$
      0065F3                       1530 00301$:
                                   1531 ;	assignBit
      0065F3 D2 1D            [12] 1532 	setb	_control_setup_sloc2_1_0
      0065F5                       1533 00302$:
      0065F5 E4               [12] 1534 	clr	a
      0065F6 BF 81 01         [24] 1535 	cjne	r7,#0x81,01214$
      0065F9 04               [12] 1536 	inc	a
      0065FA                       1537 01214$:
      0065FA FA               [12] 1538 	mov	r2,a
      0065FB A2 1D            [12] 1539 	mov	c,_control_setup_sloc2_1_0
      0065FD E4               [12] 1540 	clr	a
      0065FE 33               [12] 1541 	rlc	a
      0065FF B5 02 02         [24] 1542 	cjne	a,ar2,01216$
      006602 80 03            [24] 1543 	sjmp	00105$
      006604                       1544 01216$:
                                   1545 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      006604 02 62 E7         [24] 1546 	ljmp	_control_stall
      006607                       1547 00105$:
                                   1548 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      006607 8E 02            [24] 1549 	mov	ar2,r6
      006609 90 08 4C         [24] 1550 	mov	dptr,#_descriptor_select_PARM_2
      00660C ED               [12] 1551 	mov	a,r5
      00660D F0               [24] 1552 	movx	@dptr,a
      00660E 90 08 4D         [24] 1553 	mov	dptr,#_descriptor_select_PARM_3
      006611 EB               [12] 1554 	mov	a,r3
      006612 F0               [24] 1555 	movx	@dptr,a
      006613 EC               [12] 1556 	mov	a,r4
      006614 A3               [24] 1557 	inc	dptr
      006615 F0               [24] 1558 	movx	@dptr,a
      006616 8A 82            [24] 1559 	mov	dpl, r2
      006618 12 63 85         [24] 1560 	lcall	_descriptor_select
      00661B 85 82 17         [24] 1561 	mov	_control_setup_sloc3_1_0,dpl
      00661E 85 83 18         [24] 1562 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1563 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      006621 E5 17            [12] 1564 	mov	a,_control_setup_sloc3_1_0
      006623 45 18            [12] 1565 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006625 70 03            [24] 1566 	jnz	00107$
      006627 02 62 E7         [24] 1567 	ljmp	_control_stall
      00662A                       1568 00107$:
                                   1569 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00662A 90 07 E2         [24] 1570 	mov	dptr,#_D0SetupLen
      00662D E0               [24] 1571 	movx	a,@dptr
      00662E F8               [12] 1572 	mov	r0,a
      00662F A3               [24] 1573 	inc	dptr
      006630 E0               [24] 1574 	movx	a,@dptr
      006631 FA               [12] 1575 	mov	r2,a
      006632 C3               [12] 1576 	clr	c
      006633 E5 17            [12] 1577 	mov	a,_control_setup_sloc3_1_0
      006635 98               [12] 1578 	subb	a,r0
      006636 E5 18            [12] 1579 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006638 9A               [12] 1580 	subb	a,r2
      006639 50 06            [24] 1581 	jnc	00303$
      00663B E5 17            [12] 1582 	mov	a,_control_setup_sloc3_1_0
      00663D 54 3F            [12] 1583 	anl	a,#0x3f
      00663F 60 04            [24] 1584 	jz	00304$
      006641                       1585 00303$:
                                   1586 ;	assignBit
      006641 C2 1D            [12] 1587 	clr	_control_setup_sloc2_1_0
      006643 80 02            [24] 1588 	sjmp	00305$
      006645                       1589 00304$:
                                   1590 ;	assignBit
      006645 D2 1D            [12] 1591 	setb	_control_setup_sloc2_1_0
      006647                       1592 00305$:
      006647 90 08 49         [24] 1593 	mov	dptr,#_control_zlp
      00664A A2 1D            [12] 1594 	mov	c,_control_setup_sloc2_1_0
      00664C E4               [12] 1595 	clr	a
      00664D 33               [12] 1596 	rlc	a
      00664E F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      00664F 90 07 E2         [24] 1599 	mov	dptr,#_D0SetupLen
      006652 E0               [24] 1600 	movx	a,@dptr
      006653 F9               [12] 1601 	mov	r1,a
      006654 A3               [24] 1602 	inc	dptr
      006655 E0               [24] 1603 	movx	a,@dptr
      006656 FA               [12] 1604 	mov	r2,a
      006657 C3               [12] 1605 	clr	c
      006658 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      00665A 99               [12] 1607 	subb	a,r1
      00665B E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00665D 9A               [12] 1609 	subb	a,r2
      00665E 50 0A            [24] 1610 	jnc	00109$
                                   1611 ;	free result
      006660 90 07 E2         [24] 1612 	mov	dptr,#_D0SetupLen
      006663 E5 17            [12] 1613 	mov	a,_control_setup_sloc3_1_0
      006665 F0               [24] 1614 	movx	@dptr,a
      006666 E5 18            [12] 1615 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006668 A3               [24] 1616 	inc	dptr
      006669 F0               [24] 1617 	movx	@dptr,a
      00666A                       1618 00109$:
                                   1619 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00666A 90 07 E2         [24] 1620 	mov	dptr,#_D0SetupLen
      00666D E0               [24] 1621 	movx	a,@dptr
      00666E F9               [12] 1622 	mov	r1,a
      00666F A3               [24] 1623 	inc	dptr
      006670 E0               [24] 1624 	movx	a,@dptr
      006671 49               [12] 1625 	orl	a,r1
      006672 60 04            [24] 1626 	jz	00306$
      006674 7A 01            [12] 1627 	mov	r2,#0x01
      006676 80 02            [24] 1628 	sjmp	00307$
      006678                       1629 00306$:
      006678 7A 02            [12] 1630 	mov	r2,#0x02
      00667A                       1631 00307$:
      00667A 90 08 46         [24] 1632 	mov	dptr,#_control_phase
      00667D EA               [12] 1633 	mov	a,r2
      00667E F0               [24] 1634 	movx	@dptr,a
                                   1635 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      00667F 90 07 E2         [24] 1636 	mov	dptr,#_D0SetupLen
      006682 E0               [24] 1637 	movx	a,@dptr
      006683 F9               [12] 1638 	mov	r1,a
      006684 A3               [24] 1639 	inc	dptr
      006685 E0               [24] 1640 	movx	a,@dptr
      006686 49               [12] 1641 	orl	a,r1
      006687 60 03            [24] 1642 	jz	00111$
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      006689 02 63 09         [24] 1644 	ljmp	_control_next
      00668C                       1645 00111$:
      00668C 22               [24] 1646 	ret
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      00668D 02 62 E7         [24] 1648 	ljmp	_control_stall
                                   1649 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      006690                       1650 00116$:
                                   1651 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006690 EF               [12] 1652 	mov	a,r7
      006691 70 23            [24] 1653 	jnz	00118$
      006693 30 19 20         [24] 1654 	jnb	_control_setup_zero_index_10000_288,00118$
      006696 30 1B 1D         [24] 1655 	jnb	_control_setup_zero_length_10000_288,00118$
      006699 8D 01            [24] 1656 	mov	ar1,r5
      00669B 8E 02            [24] 1657 	mov	ar2,r6
      00669D C3               [12] 1658 	clr	c
      00669E 74 7F            [12] 1659 	mov	a,#0x7f
      0066A0 99               [12] 1660 	subb	a,r1
      0066A1 E4               [12] 1661 	clr	a
      0066A2 9A               [12] 1662 	subb	a,r2
      0066A3 40 11            [24] 1663 	jc	00118$
                                   1664 ;	free result
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      0066A5 90 07 E2         [24] 1666 	mov	dptr,#_D0SetupLen
      0066A8 ED               [12] 1667 	mov	a,r5
      0066A9 F0               [24] 1668 	movx	@dptr,a
      0066AA EE               [12] 1669 	mov	a,r6
      0066AB A3               [24] 1670 	inc	dptr
      0066AC F0               [24] 1671 	movx	@dptr,a
                                   1672 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      0066AD 90 08 46         [24] 1673 	mov	dptr,#_control_phase
      0066B0 74 03            [12] 1674 	mov	a,#0x03
      0066B2 F0               [24] 1675 	movx	@dptr,a
      0066B3 02 6C 96         [24] 1676 	ljmp	00291$
      0066B6                       1677 00118$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      0066B6 02 62 E7         [24] 1679 	ljmp	_control_stall
                                   1680 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0066B9                       1681 00123$:
                                   1682 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0066B9 EF               [12] 1683 	mov	a,r7
      0066BA 70 3C            [24] 1684 	jnz	00145$
      0066BC 30 19 39         [24] 1685 	jnb	_control_setup_zero_index_10000_288,00145$
      0066BF 30 1B 36         [24] 1686 	jnb	_control_setup_zero_length_10000_288,00145$
      0066C2 8D 01            [24] 1687 	mov	ar1,r5
      0066C4 8E 02            [24] 1688 	mov	ar2,r6
      0066C6 C3               [12] 1689 	clr	c
      0066C7 74 01            [12] 1690 	mov	a,#0x01
      0066C9 99               [12] 1691 	subb	a,r1
      0066CA E4               [12] 1692 	clr	a
      0066CB 9A               [12] 1693 	subb	a,r2
      0066CC 40 2A            [24] 1694 	jc	00145$
                                   1695 ;	free result
                                   1696 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      0066CE C0 06            [24] 1697 	push	ar6
      0066D0 C0 05            [24] 1698 	push	ar5
      0066D2 12 62 8A         [24] 1699 	lcall	_endpoints_reset
      0066D5 D0 05            [24] 1700 	pop	ar5
      0066D7 D0 06            [24] 1701 	pop	ar6
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      0066D9 90 07 E7         [24] 1703 	mov	dptr,#_D0UsbConfig
      0066DC ED               [12] 1704 	mov	a,r5
      0066DD F0               [24] 1705 	movx	@dptr,a
                                   1706 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      0066DE A2 1C            [12] 1707 	mov	c,_control_setup_sloc0_1_0
      0066E0 B3               [12] 1708 	cpl	c
      0066E1 92 1D            [24] 1709 	mov	_control_setup_sloc2_1_0,c
      0066E3 90 07 E8         [24] 1710 	mov	dptr,#_USB_EnumStatus
      0066E6 E4               [12] 1711 	clr	a
      0066E7 33               [12] 1712 	rlc	a
      0066E8 F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      0066E9 90 08 11         [24] 1715 	mov	dptr,#_keyboard_reset
      0066EC 74 01            [12] 1716 	mov	a,#0x01
      0066EE F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      0066EF 90 08 46         [24] 1719 	mov	dptr,#_control_phase
      0066F2 74 03            [12] 1720 	mov	a,#0x03
      0066F4 F0               [24] 1721 	movx	@dptr,a
      0066F5 02 6C 96         [24] 1722 	ljmp	00291$
      0066F8                       1723 00145$:
                                   1724 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      0066F8 BF 21 02         [24] 1725 	cjne	r7,#0x21,01231$
      0066FB 80 03            [24] 1726 	sjmp	01232$
      0066FD                       1727 01231$:
      0066FD 02 62 E7         [24] 1728 	ljmp	_control_stall
      006700                       1729 01232$:
      006700 90 07 E7         [24] 1730 	mov	dptr,#_D0UsbConfig
      006703 E0               [24] 1731 	movx	a,@dptr
      006704 70 03            [24] 1732 	jnz	01233$
      006706 02 62 E7         [24] 1733 	ljmp	_control_stall
      006709                       1734 01233$:
                                   1735 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006709 BB 01 2D         [24] 1736 	cjne	r3,#0x01,00135$
      00670C BC 00 2A         [24] 1737 	cjne	r4,#0x00,00135$
      00670F 8D 01            [24] 1738 	mov	ar1,r5
      006711 8E 02            [24] 1739 	mov	ar2,r6
      006713 B9 00 23         [24] 1740 	cjne	r1,#0x00,00135$
      006716 BA 02 20         [24] 1741 	cjne	r2,#0x02,00135$
      006719 90 07 E2         [24] 1742 	mov	dptr,#_D0SetupLen
      00671C E0               [24] 1743 	movx	a,@dptr
      00671D F9               [12] 1744 	mov	r1,a
      00671E A3               [24] 1745 	inc	dptr
      00671F E0               [24] 1746 	movx	a,@dptr
      006720 FA               [12] 1747 	mov	r2,a
      006721 B9 20 15         [24] 1748 	cjne	r1,#0x20,00135$
      006724 BA 00 12         [24] 1749 	cjne	r2,#0x00,00135$
      006727 90 07 EF         [24] 1750 	mov	dptr,#_raw_state
      00672A E0               [24] 1751 	movx	a,@dptr
      00672B 70 0C            [24] 1752 	jnz	00135$
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      00672D 90 07 EF         [24] 1754 	mov	dptr,#_raw_state
      006730 74 01            [12] 1755 	mov	a,#0x01
      006732 F0               [24] 1756 	movx	@dptr,a
                                   1757 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      006733 90 08 47         [24] 1758 	mov	dptr,#_output_kind
      006736 F0               [24] 1759 	movx	@dptr,a
      006737 80 52            [24] 1760 	sjmp	00136$
      006739                       1761 00135$:
                                   1762 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006739 EB               [12] 1763 	mov	a,r3
      00673A 4C               [12] 1764 	orl	a,r4
      00673B 70 20            [24] 1765 	jnz	00130$
      00673D 8D 01            [24] 1766 	mov	ar1,r5
      00673F 8E 02            [24] 1767 	mov	ar2,r6
      006741 B9 00 19         [24] 1768 	cjne	r1,#0x00,00130$
      006744 BA 02 16         [24] 1769 	cjne	r2,#0x02,00130$
      006747 90 07 E2         [24] 1770 	mov	dptr,#_D0SetupLen
      00674A E0               [24] 1771 	movx	a,@dptr
      00674B F9               [12] 1772 	mov	r1,a
      00674C A3               [24] 1773 	inc	dptr
      00674D E0               [24] 1774 	movx	a,@dptr
      00674E FA               [12] 1775 	mov	r2,a
      00674F B9 01 0B         [24] 1776 	cjne	r1,#0x01,00130$
      006752 BA 00 08         [24] 1777 	cjne	r2,#0x00,00130$
                                   1778 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      006755 90 08 47         [24] 1779 	mov	dptr,#_output_kind
      006758 74 02            [12] 1780 	mov	a,#0x02
      00675A F0               [24] 1781 	movx	@dptr,a
      00675B 80 2E            [24] 1782 	sjmp	00136$
      00675D                       1783 00130$:
                                   1784 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00675D BB 02 28         [24] 1785 	cjne	r3,#0x02,00125$
      006760 BC 00 25         [24] 1786 	cjne	r4,#0x00,00125$
      006763 8D 01            [24] 1787 	mov	ar1,r5
      006765 8E 02            [24] 1788 	mov	ar2,r6
      006767 B9 06 1E         [24] 1789 	cjne	r1,#0x06,00125$
      00676A BA 02 1B         [24] 1790 	cjne	r2,#0x02,00125$
      00676D 90 07 E2         [24] 1791 	mov	dptr,#_D0SetupLen
      006770 E0               [24] 1792 	movx	a,@dptr
      006771 F9               [12] 1793 	mov	r1,a
      006772 A3               [24] 1794 	inc	dptr
      006773 E0               [24] 1795 	movx	a,@dptr
      006774 FA               [12] 1796 	mov	r2,a
      006775 B9 02 10         [24] 1797 	cjne	r1,#0x02,00125$
      006778 BA 00 0D         [24] 1798 	cjne	r2,#0x00,00125$
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      00677B 90 08 47         [24] 1800 	mov	dptr,#_output_kind
      00677E 74 03            [12] 1801 	mov	a,#0x03
      006780 F0               [24] 1802 	movx	@dptr,a
                                   1803 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      006781 90 08 48         [24] 1804 	mov	dptr,#_output_report_id
      006784 23               [12] 1805 	rl	a
      006785 F0               [24] 1806 	movx	@dptr,a
      006786 80 03            [24] 1807 	sjmp	00136$
      006788                       1808 00125$:
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      006788 02 62 E7         [24] 1810 	ljmp	_control_stall
      00678B                       1811 00136$:
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      00678B 90 08 46         [24] 1813 	mov	dptr,#_control_phase
      00678E 74 04            [12] 1814 	mov	a,#0x04
      006790 F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      006791 22               [24] 1817 	ret
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      006792 02 62 E7         [24] 1819 	ljmp	_control_stall
                                   1820 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006795                       1821 00150$:
                                   1822 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006795 BF 80 2A         [24] 1823 	cjne	r7,#0x80,00152$
      006798 30 19 27         [24] 1824 	jnb	_control_setup_zero_index_10000_288,00152$
      00679B 30 1A 24         [24] 1825 	jnb	_control_setup_zero_value_10000_288,00152$
      00679E 90 07 E2         [24] 1826 	mov	dptr,#_D0SetupLen
      0067A1 E0               [24] 1827 	movx	a,@dptr
      0067A2 F9               [12] 1828 	mov	r1,a
      0067A3 A3               [24] 1829 	inc	dptr
      0067A4 E0               [24] 1830 	movx	a,@dptr
      0067A5 FA               [12] 1831 	mov	r2,a
      0067A6 B9 01 19         [24] 1832 	cjne	r1,#0x01,00152$
      0067A9 BA 00 16         [24] 1833 	cjne	r2,#0x00,00152$
                                   1834 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      0067AC 90 07 E7         [24] 1835 	mov	dptr,#_D0UsbConfig
      0067AF E0               [24] 1836 	movx	a,@dptr
      0067B0 90 10 00         [24] 1837 	mov	dptr,#0x1000
      0067B3 F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      0067B4 90 22 08         [24] 1840 	mov	dptr,#0x2208
      0067B7 74 01            [12] 1841 	mov	a,#0x01
      0067B9 F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      0067BA 90 08 46         [24] 1844 	mov	dptr,#_control_phase
      0067BD 04               [12] 1845 	inc	a
      0067BE F0               [24] 1846 	movx	@dptr,a
      0067BF 02 6C 96         [24] 1847 	ljmp	00291$
      0067C2                       1848 00152$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      0067C2 02 62 E7         [24] 1850 	ljmp	_control_stall
                                   1851 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0067C5                       1852 00157$:
                                   1853 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0067C5 BF 81 2C         [24] 1854 	cjne	r7,#0x81,00167$
      0067C8 30 18 29         [24] 1855 	jnb	_control_setup_valid_interface_10000_288,00167$
      0067CB 30 1A 26         [24] 1856 	jnb	_control_setup_zero_value_10000_288,00167$
      0067CE 90 07 E2         [24] 1857 	mov	dptr,#_D0SetupLen
      0067D1 E0               [24] 1858 	movx	a,@dptr
      0067D2 F9               [12] 1859 	mov	r1,a
      0067D3 A3               [24] 1860 	inc	dptr
      0067D4 E0               [24] 1861 	movx	a,@dptr
      0067D5 FA               [12] 1862 	mov	r2,a
      0067D6 B9 01 1B         [24] 1863 	cjne	r1,#0x01,00167$
      0067D9 BA 00 18         [24] 1864 	cjne	r2,#0x00,00167$
      0067DC 90 07 E7         [24] 1865 	mov	dptr,#_D0UsbConfig
      0067DF E0               [24] 1866 	movx	a,@dptr
      0067E0 60 12            [24] 1867 	jz	00167$
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      0067E2 90 10 00         [24] 1869 	mov	dptr,#0x1000
      0067E5 E4               [12] 1870 	clr	a
      0067E6 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      0067E7 90 22 08         [24] 1873 	mov	dptr,#0x2208
      0067EA 04               [12] 1874 	inc	a
      0067EB F0               [24] 1875 	movx	@dptr,a
                                   1876 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      0067EC 90 08 46         [24] 1877 	mov	dptr,#_control_phase
      0067EF 04               [12] 1878 	inc	a
      0067F0 F0               [24] 1879 	movx	@dptr,a
      0067F1 02 6C 96         [24] 1880 	ljmp	00291$
      0067F4                       1881 00167$:
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0067F4 30 18 1E         [24] 1883 	jnb	_control_setup_valid_interface_10000_288,00161$
      0067F7 90 07 E7         [24] 1884 	mov	dptr,#_D0UsbConfig
      0067FA E0               [24] 1885 	movx	a,@dptr
      0067FB 60 18            [24] 1886 	jz	00161$
      0067FD BF 21 15         [24] 1887 	cjne	r7,#0x21,00161$
      006800 30 1B 12         [24] 1888 	jnb	_control_setup_zero_length_10000_288,00161$
                                   1889 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006803 EB               [12] 1890 	mov	a,r3
      006804 4C               [12] 1891 	orl	a,r4
      006805 70 05            [24] 1892 	jnz	00159$
      006807 90 06 A9         [24] 1893 	mov	dptr,#_keyboard_idle
      00680A EE               [12] 1894 	mov	a,r6
      00680B F0               [24] 1895 	movx	@dptr,a
      00680C                       1896 00159$:
                                   1897 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      00680C 90 08 46         [24] 1898 	mov	dptr,#_control_phase
      00680F 74 03            [12] 1899 	mov	a,#0x03
      006811 F0               [24] 1900 	movx	@dptr,a
      006812 02 6C 96         [24] 1901 	ljmp	00291$
      006815                       1902 00161$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      006815 02 62 E7         [24] 1904 	ljmp	_control_stall
                                   1905 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006818                       1906 00173$:
                                   1907 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006818 BF 01 18         [24] 1908 	cjne	r7,#0x01,00182$
      00681B 30 18 15         [24] 1909 	jnb	_control_setup_valid_interface_10000_288,00182$
      00681E 30 1A 12         [24] 1910 	jnb	_control_setup_zero_value_10000_288,00182$
      006821 30 1B 0F         [24] 1911 	jnb	_control_setup_zero_length_10000_288,00182$
      006824 90 07 E7         [24] 1912 	mov	dptr,#_D0UsbConfig
      006827 E0               [24] 1913 	movx	a,@dptr
      006828 60 09            [24] 1914 	jz	00182$
                                   1915 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      00682A 90 08 46         [24] 1916 	mov	dptr,#_control_phase
      00682D 74 03            [12] 1917 	mov	a,#0x03
      00682F F0               [24] 1918 	movx	@dptr,a
      006830 02 6C 96         [24] 1919 	ljmp	00291$
      006833                       1920 00182$:
                                   1921 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006833 EB               [12] 1922 	mov	a,r3
      006834 4C               [12] 1923 	orl	a,r4
      006835 70 2C            [24] 1924 	jnz	00175$
      006837 90 07 E7         [24] 1925 	mov	dptr,#_D0UsbConfig
      00683A E0               [24] 1926 	movx	a,@dptr
      00683B 60 26            [24] 1927 	jz	00175$
      00683D BF 21 23         [24] 1928 	cjne	r7,#0x21,00175$
      006840 30 1B 20         [24] 1929 	jnb	_control_setup_zero_length_10000_288,00175$
      006843 8D 01            [24] 1930 	mov	ar1,r5
      006845 8E 02            [24] 1931 	mov	ar2,r6
      006847 C3               [12] 1932 	clr	c
      006848 74 01            [12] 1933 	mov	a,#0x01
      00684A 99               [12] 1934 	subb	a,r1
      00684B E4               [12] 1935 	clr	a
      00684C 9A               [12] 1936 	subb	a,r2
      00684D 40 14            [24] 1937 	jc	00175$
                                   1938 ;	free result
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      00684F 90 0E 3B         [24] 1940 	mov	dptr,#_keyboard_protocol
      006852 ED               [12] 1941 	mov	a,r5
      006853 F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      006854 90 08 11         [24] 1944 	mov	dptr,#_keyboard_reset
      006857 74 01            [12] 1945 	mov	a,#0x01
      006859 F0               [24] 1946 	movx	@dptr,a
                                   1947 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      00685A 90 08 46         [24] 1948 	mov	dptr,#_control_phase
      00685D 74 03            [12] 1949 	mov	a,#0x03
      00685F F0               [24] 1950 	movx	@dptr,a
      006860 02 6C 96         [24] 1951 	ljmp	00291$
      006863                       1952 00175$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006863 02 62 E7         [24] 1954 	ljmp	_control_stall
                                   1955 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      006866                       1956 00188$:
                                   1957 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      006866 20 1A 03         [24] 1958 	jb	_control_setup_zero_value_10000_288,01283$
      006869 02 62 E7         [24] 1959 	ljmp	_control_stall
      00686C                       1960 01283$:
      00686C 90 07 E2         [24] 1961 	mov	dptr,#_D0SetupLen
      00686F E0               [24] 1962 	movx	a,@dptr
      006870 F9               [12] 1963 	mov	r1,a
      006871 A3               [24] 1964 	inc	dptr
      006872 E0               [24] 1965 	movx	a,@dptr
      006873 FA               [12] 1966 	mov	r2,a
      006874 B9 02 05         [24] 1967 	cjne	r1,#0x02,01284$
      006877 BA 00 02         [24] 1968 	cjne	r2,#0x00,01284$
      00687A 80 03            [24] 1969 	sjmp	01285$
      00687C                       1970 01284$:
      00687C 02 62 E7         [24] 1971 	ljmp	_control_stall
      00687F                       1972 01285$:
                                   1973 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00687F E4               [12] 1974 	clr	a
      006880 BF 80 01         [24] 1975 	cjne	r7,#0x80,01286$
      006883 04               [12] 1976 	inc	a
      006884                       1977 01286$:
      006884 FA               [12] 1978 	mov	r2,a
      006885 60 03            [24] 1979 	jz	00196$
      006887 20 19 35         [24] 1980 	jb	_control_setup_zero_index_10000_288,00189$
      00688A                       1981 00196$:
      00688A BF 81 09         [24] 1982 	cjne	r7,#0x81,00202$
      00688D 30 18 06         [24] 1983 	jnb	_control_setup_valid_interface_10000_288,00202$
      006890 90 07 E7         [24] 1984 	mov	dptr,#_D0UsbConfig
      006893 E0               [24] 1985 	movx	a,@dptr
      006894 70 29            [24] 1986 	jnz	00189$
      006896                       1987 00202$:
                                   1988 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006896 BF 82 70         [24] 1989 	cjne	r7,#0x82,00190$
      006899 90 07 E7         [24] 1990 	mov	dptr,#_D0UsbConfig
      00689C E0               [24] 1991 	movx	a,@dptr
      00689D 60 6A            [24] 1992 	jz	00190$
      00689F EB               [12] 1993 	mov	a,r3
      0068A0 4C               [12] 1994 	orl	a,r4
      0068A1 60 1C            [24] 1995 	jz	00189$
      0068A3 8B 00            [24] 1996 	mov	ar0,r3
      0068A5 8C 01            [24] 1997 	mov	ar1,r4
      0068A7 B8 80 05         [24] 1998 	cjne	r0,#0x80,01298$
      0068AA B9 00 02         [24] 1999 	cjne	r1,#0x00,01298$
      0068AD 80 10            [24] 2000 	sjmp	00189$
      0068AF                       2001 01298$:
      0068AF C3               [12] 2002 	clr	c
      0068B0 E8               [12] 2003 	mov	a,r0
      0068B1 94 81            [12] 2004 	subb	a,#0x81
      0068B3 E9               [12] 2005 	mov	a,r1
      0068B4 94 00            [12] 2006 	subb	a,#0x00
      0068B6 40 51            [24] 2007 	jc	00190$
      0068B8 74 83            [12] 2008 	mov	a,#0x83
      0068BA 98               [12] 2009 	subb	a,r0
      0068BB E4               [12] 2010 	clr	a
      0068BC 99               [12] 2011 	subb	a,r1
      0068BD 40 4A            [24] 2012 	jc	00190$
                                   2013 ;	free result
      0068BF                       2014 00189$:
                                   2015 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      0068BF 8B 01            [24] 2016 	mov	ar1,r3
      0068C1 53 01 07         [24] 2017 	anl	ar1,#0x07
                                   2018 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0068C4 EA               [12] 2019 	mov	a,r2
      0068C5 60 0B            [24] 2020 	jz	00308$
      0068C7 90 07 E9         [24] 2021 	mov	dptr,#_USB_SleepStatus
      0068CA E0               [24] 2022 	movx	a,@dptr
      0068CB 54 01            [12] 2023 	anl	a,#0x01
      0068CD 25 E0            [12] 2024 	add	a,acc
      0068CF FA               [12] 2025 	mov	r2,a
      0068D0 80 22            [24] 2026 	sjmp	00309$
      0068D2                       2027 00308$:
                                   2028 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0068D2 BF 82 1B         [24] 2029 	cjne	r7,#0x82,00310$
      0068D5 E9               [12] 2030 	mov	a,r1
      0068D6 60 18            [24] 2031 	jz	00310$
      0068D8 89 00            [24] 2032 	mov	ar0,r1
      0068DA 79 00            [12] 2033 	mov	r1,#0x00
      0068DC 74 22            [12] 2034 	mov	a,#0x22
      0068DE 29               [12] 2035 	add	a, r1
      0068DF F9               [12] 2036 	mov	r1,a
      0068E0 88 82            [24] 2037 	mov	dpl,r0
      0068E2 89 83            [24] 2038 	mov	dph,r1
      0068E4 E0               [24] 2039 	movx	a,@dptr
      0068E5 F9               [12] 2040 	mov	r1,a
      0068E6 53 01 03         [24] 2041 	anl	ar1,#0x03
      0068E9 B9 03 04         [24] 2042 	cjne	r1,#0x03,00310$
      0068EC 79 01            [12] 2043 	mov	r1,#0x01
      0068EE 80 02            [24] 2044 	sjmp	00311$
      0068F0                       2045 00310$:
      0068F0 79 00            [12] 2046 	mov	r1,#0x00
      0068F2                       2047 00311$:
      0068F2 89 02            [24] 2048 	mov	ar2,r1
      0068F4                       2049 00309$:
      0068F4 90 10 00         [24] 2050 	mov	dptr,#0x1000
      0068F7 EA               [12] 2051 	mov	a,r2
      0068F8 F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0068F9 A3               [24] 2054 	inc	dptr
      0068FA E4               [12] 2055 	clr	a
      0068FB F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0068FC 90 22 08         [24] 2058 	mov	dptr,#0x2208
      0068FF 74 02            [12] 2059 	mov	a,#0x02
      006901 F0               [24] 2060 	movx	@dptr,a
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      006902 90 08 46         [24] 2062 	mov	dptr,#_control_phase
      006905 F0               [24] 2063 	movx	@dptr,a
      006906 02 6C 96         [24] 2064 	ljmp	00291$
      006909                       2065 00190$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      006909 02 62 E7         [24] 2067 	ljmp	_control_stall
                                   2068 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00690C                       2069 00205$:
                                   2070 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      00690C 20 1B 03         [24] 2071 	jb	_control_setup_zero_length_10000_288,01307$
      00690F 02 69 9F         [24] 2072 	ljmp	00279$
      006912                       2073 01307$:
      006912 90 07 E7         [24] 2074 	mov	dptr,#_D0UsbConfig
      006915 E0               [24] 2075 	movx	a,@dptr
      006916 70 03            [24] 2076 	jnz	01308$
      006918 02 69 9F         [24] 2077 	ljmp	00279$
      00691B                       2078 01308$:
                                   2079 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      00691B EF               [12] 2080 	mov	a,r7
      00691C 70 29            [24] 2081 	jnz	00218$
      00691E 8D 01            [24] 2082 	mov	ar1,r5
      006920 8E 02            [24] 2083 	mov	ar2,r6
      006922 B9 01 22         [24] 2084 	cjne	r1,#0x01,00218$
      006925 BA 00 1F         [24] 2085 	cjne	r2,#0x00,00218$
      006928 30 19 1C         [24] 2086 	jnb	_control_setup_zero_index_10000_288,00218$
                                   2087 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00692B 90 07 E1         [24] 2088 	mov	dptr,#_D0SetupReqCode
      00692E E0               [24] 2089 	movx	a,@dptr
      00692F FA               [12] 2090 	mov	r2,a
      006930 BA 03 0A         [24] 2091 	cjne	r2,#0x03,00207$
      006933 90 07 E9         [24] 2092 	mov	dptr,#_USB_SleepStatus
      006936 E0               [24] 2093 	movx	a,@dptr
      006937 43 E0 01         [24] 2094 	orl	acc,#0x01
      00693A F0               [24] 2095 	movx	@dptr,a
      00693B 80 59            [24] 2096 	sjmp	00219$
      00693D                       2097 00207$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      00693D 90 07 E9         [24] 2099 	mov	dptr,#_USB_SleepStatus
      006940 E0               [24] 2100 	movx	a,@dptr
      006941 53 E0 FE         [24] 2101 	anl	acc,#0xfe
      006944 F0               [24] 2102 	movx	@dptr,a
      006945 80 4F            [24] 2103 	sjmp	00219$
      006947                       2104 00218$:
                                   2105 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006947 BF 02 49         [24] 2106 	cjne	r7,#0x02,00212$
      00694A 30 1A 46         [24] 2107 	jnb	_control_setup_zero_value_10000_288,00212$
      00694D 8B 01            [24] 2108 	mov	ar1,r3
      00694F 8C 02            [24] 2109 	mov	ar2,r4
      006951 C3               [12] 2110 	clr	c
      006952 E9               [12] 2111 	mov	a,r1
      006953 94 81            [12] 2112 	subb	a,#0x81
      006955 EA               [12] 2113 	mov	a,r2
      006956 94 00            [12] 2114 	subb	a,#0x00
      006958 40 39            [24] 2115 	jc	00212$
      00695A 74 83            [12] 2116 	mov	a,#0x83
      00695C 99               [12] 2117 	subb	a,r1
      00695D E4               [12] 2118 	clr	a
      00695E 9A               [12] 2119 	subb	a,r2
      00695F 40 32            [24] 2120 	jc	00212$
                                   2121 ;	free result
                                   2122 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      006961 8B 02            [24] 2123 	mov	ar2,r3
      006963 53 02 07         [24] 2124 	anl	ar2,#0x07
                                   2125 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006966 8A 00            [24] 2126 	mov	ar0,r2
      006968 79 00            [12] 2127 	mov	r1,#0x00
      00696A 74 22            [12] 2128 	mov	a,#0x22
      00696C 29               [12] 2129 	add	a, r1
      00696D F9               [12] 2130 	mov	r1,a
      00696E 88 17            [24] 2131 	mov	_control_setup_sloc3_1_0,r0
      006970 89 18            [24] 2132 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006972 90 07 E1         [24] 2133 	mov	dptr,#_D0SetupReqCode
      006975 E0               [24] 2134 	movx	a,@dptr
      006976 F9               [12] 2135 	mov	r1,a
      006977 B9 03 04         [24] 2136 	cjne	r1,#0x03,00318$
      00697A 79 03            [12] 2137 	mov	r1,#0x03
      00697C 80 02            [24] 2138 	sjmp	00319$
      00697E                       2139 00318$:
      00697E 79 02            [12] 2140 	mov	r1,#0x02
      006980                       2141 00319$:
      006980 43 01 10         [24] 2142 	orl	ar1,#0x10
      006983 85 17 82         [24] 2143 	mov	dpl,_control_setup_sloc3_1_0
      006986 85 18 83         [24] 2144 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006989 E9               [12] 2145 	mov	a,r1
      00698A F0               [24] 2146 	movx	@dptr,a
                                   2147 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00698B BA 03 08         [24] 2148 	cjne	r2,#0x03,00219$
      00698E 12 62 6D         [24] 2149 	lcall	_raw_complete
      006991 80 03            [24] 2150 	sjmp	00219$
      006993                       2151 00212$:
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006993 02 62 E7         [24] 2153 	ljmp	_control_stall
      006996                       2154 00219$:
                                   2155 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006996 90 08 46         [24] 2156 	mov	dptr,#_control_phase
      006999 74 03            [12] 2157 	mov	a,#0x03
      00699B F0               [24] 2158 	movx	@dptr,a
      00699C 02 6C 96         [24] 2159 	ljmp	00291$
      00699F                       2160 00279$:
                                   2161 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00699F E4               [12] 2162 	clr	a
      0069A0 BF A1 01         [24] 2163 	cjne	r7,#0xa1,01324$
      0069A3 04               [12] 2164 	inc	a
      0069A4                       2165 01324$:
      0069A4 FA               [12] 2166 	mov	r2,a
      0069A5 70 03            [24] 2167 	jnz	01326$
      0069A7 02 6C 11         [24] 2168 	ljmp	00273$
      0069AA                       2169 01326$:
      0069AA 90 07 E1         [24] 2170 	mov	dptr,#_D0SetupReqCode
      0069AD E0               [24] 2171 	movx	a,@dptr
      0069AE F9               [12] 2172 	mov	r1,a
      0069AF B9 01 02         [24] 2173 	cjne	r1,#0x01,01327$
      0069B2 80 03            [24] 2174 	sjmp	01328$
      0069B4                       2175 01327$:
      0069B4 02 6C 11         [24] 2176 	ljmp	00273$
      0069B7                       2177 01328$:
      0069B7 90 07 E7         [24] 2178 	mov	dptr,#_D0UsbConfig
      0069BA E0               [24] 2179 	movx	a,@dptr
      0069BB 70 03            [24] 2180 	jnz	01329$
      0069BD 02 6C 11         [24] 2181 	ljmp	00273$
      0069C0                       2182 01329$:
      0069C0 90 07 E2         [24] 2183 	mov	dptr,#_D0SetupLen
      0069C3 E0               [24] 2184 	movx	a,@dptr
      0069C4 F8               [12] 2185 	mov	r0,a
      0069C5 A3               [24] 2186 	inc	dptr
      0069C6 E0               [24] 2187 	movx	a,@dptr
      0069C7 48               [12] 2188 	orl	a,r0
      0069C8 70 03            [24] 2189 	jnz	01330$
      0069CA 02 6C 11         [24] 2190 	ljmp	00273$
      0069CD                       2191 01330$:
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0069CD C0 03            [24] 2193 	push	ar3
      0069CF C0 04            [24] 2194 	push	ar4
      0069D1 8D 01            [24] 2195 	mov	ar1,r5
                                   2196 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0069D3 8E 00            [24] 2197 	mov	ar0,r6
      0069D5 B8 01 03         [24] 2198 	cjne	r0,#0x01,01331$
      0069D8 E8               [12] 2199 	mov	a,r0
      0069D9 80 01            [24] 2200 	sjmp	01332$
      0069DB                       2201 01331$:
      0069DB E4               [12] 2202 	clr	a
      0069DC                       2203 01332$:
      0069DC F5 17            [12] 2204 	mov	_control_setup_sloc3_1_0,a
      0069DE D0 04            [24] 2205 	pop	ar4
      0069E0 D0 03            [24] 2206 	pop	ar3
      0069E2 E5 17            [12] 2207 	mov	a,_control_setup_sloc3_1_0
      0069E4 60 17            [24] 2208 	jz	00251$
      0069E6 EB               [12] 2209 	mov	a,r3
      0069E7 4C               [12] 2210 	orl	a,r4
      0069E8 70 13            [24] 2211 	jnz	00251$
      0069EA E9               [12] 2212 	mov	a,r1
      0069EB 70 10            [24] 2213 	jnz	00251$
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0069ED 90 08 50         [24] 2215 	mov	dptr,#_control_setup_length_10000_288
      0069F0 74 08            [12] 2216 	mov	a,#0x08
      0069F2 F0               [24] 2217 	movx	@dptr,a
      0069F3 E4               [12] 2218 	clr	a
      0069F4 A3               [24] 2219 	inc	dptr
      0069F5 F0               [24] 2220 	movx	@dptr,a
                                   2221 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0069F6 90 08 52         [24] 2222 	mov	dptr,#_control_setup_offset_10000_288
      0069F9 F0               [24] 2223 	movx	@dptr,a
      0069FA 02 6B 81         [24] 2224 	ljmp	00252$
      0069FD                       2225 00251$:
                                   2226 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0069FD E5 17            [12] 2227 	mov	a,_control_setup_sloc3_1_0
      0069FF 60 27            [24] 2228 	jz	00245$
      006A01 BB 02 24         [24] 2229 	cjne	r3,#0x02,00245$
      006A04 BC 00 21         [24] 2230 	cjne	r4,#0x00,00245$
                                   2231 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006A07 B9 07 00         [24] 2232 	cjne	r1,#0x07,01339$
      006A0A                       2233 01339$:
      006A0A 50 1C            [24] 2234 	jnc	00245$
      006A0C E9               [12] 2235 	mov	a,r1
      006A0D 90 C1 EC         [24] 2236 	mov	dptr,#_shared_lengths
      006A10 93               [24] 2237 	movc	a,@a+dptr
      006A11 F8               [12] 2238 	mov	r0,a
      006A12 60 14            [24] 2239 	jz	00245$
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      006A14 90 08 50         [24] 2241 	mov	dptr,#_control_setup_length_10000_288
      006A17 E8               [12] 2242 	mov	a,r0
      006A18 F0               [24] 2243 	movx	@dptr,a
      006A19 E4               [12] 2244 	clr	a
      006A1A A3               [24] 2245 	inc	dptr
      006A1B F0               [24] 2246 	movx	@dptr,a
                                   2247 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      006A1C E9               [12] 2248 	mov	a,r1
      006A1D 90 C1 E5         [24] 2249 	mov	dptr,#_shared_offsets
      006A20 93               [24] 2250 	movc	a,@a+dptr
      006A21 90 08 52         [24] 2251 	mov	dptr,#_control_setup_offset_10000_288
      006A24 F0               [24] 2252 	movx	@dptr,a
      006A25 02 6B 81         [24] 2253 	ljmp	00252$
      006A28                       2254 00245$:
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006A28 E5 17            [12] 2256 	mov	a,_control_setup_sloc3_1_0
      006A2A 60 7A            [24] 2257 	jz	00240$
      006A2C BB 01 77         [24] 2258 	cjne	r3,#0x01,00240$
      006A2F BC 00 74         [24] 2259 	cjne	r4,#0x00,00240$
      006A32 E9               [12] 2260 	mov	a,r1
      006A33 70 71            [24] 2261 	jnz	00240$
                                   2262 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006A35 90 07 E2         [24] 2263 	mov	dptr,#_D0SetupLen
      006A38 E0               [24] 2264 	movx	a,@dptr
      006A39 F8               [12] 2265 	mov	r0,a
      006A3A A3               [24] 2266 	inc	dptr
      006A3B E0               [24] 2267 	movx	a,@dptr
      006A3C F9               [12] 2268 	mov	r1,a
      006A3D C3               [12] 2269 	clr	c
      006A3E E8               [12] 2270 	mov	a,r0
      006A3F 94 20            [12] 2271 	subb	a,#0x20
      006A41 E9               [12] 2272 	mov	a,r1
      006A42 94 00            [12] 2273 	subb	a,#0x00
      006A44 50 0A            [24] 2274 	jnc	00320$
      006A46 90 07 E2         [24] 2275 	mov	dptr,#_D0SetupLen
      006A49 E0               [24] 2276 	movx	a,@dptr
      006A4A F8               [12] 2277 	mov	r0,a
      006A4B A3               [24] 2278 	inc	dptr
      006A4C E0               [24] 2279 	movx	a,@dptr
      006A4D F9               [12] 2280 	mov	r1,a
      006A4E 80 04            [24] 2281 	sjmp	00321$
      006A50                       2282 00320$:
      006A50 78 20            [12] 2283 	mov	r0,#0x20
      006A52 79 00            [12] 2284 	mov	r1,#0x00
      006A54                       2285 00321$:
                                   2286 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006A54 75 17 00         [24] 2287 	mov	_control_setup_sloc3_1_0,#0x00
      006A57                       2288 00293$:
      006A57 C0 03            [24] 2289 	push	ar3
      006A59 C0 04            [24] 2290 	push	ar4
      006A5B AB 17            [24] 2291 	mov	r3,_control_setup_sloc3_1_0
      006A5D 7C 00            [12] 2292 	mov	r4,#0x00
      006A5F C3               [12] 2293 	clr	c
      006A60 EB               [12] 2294 	mov	a,r3
      006A61 98               [12] 2295 	subb	a,r0
      006A62 EC               [12] 2296 	mov	a,r4
      006A63 99               [12] 2297 	subb	a,r1
      006A64 D0 04            [24] 2298 	pop	ar4
      006A66 D0 03            [24] 2299 	pop	ar3
      006A68 50 32            [24] 2300 	jnc	00222$
      006A6A C0 00            [24] 2301 	push	ar0
      006A6C C0 01            [24] 2302 	push	ar1
      006A6E 85 17 19         [24] 2303 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006A71 74 10            [12] 2304 	mov	a,#0x10
      006A73 24 00            [12] 2305 	add	a, #0x00
      006A75 F5 1A            [12] 2306 	mov	(_control_setup_sloc4_1_0 + 1),a
      006A77 A8 17            [24] 2307 	mov	r0,_control_setup_sloc3_1_0
      006A79 79 00            [12] 2308 	mov	r1,#0x00
      006A7B 74 C0            [12] 2309 	mov	a,#0xc0
      006A7D 28               [12] 2310 	add	a, r0
      006A7E F8               [12] 2311 	mov	r0,a
      006A7F E4               [12] 2312 	clr	a
      006A80 39               [12] 2313 	addc	a, r1
      006A81 F9               [12] 2314 	mov	r1,a
      006A82 88 82            [24] 2315 	mov	dpl,r0
      006A84 74 10            [12] 2316 	mov	a,#0x10
      006A86 29               [12] 2317 	add	a, r1
      006A87 F5 83            [12] 2318 	mov	dph,a
      006A89 E0               [24] 2319 	movx	a,@dptr
      006A8A 85 19 82         [24] 2320 	mov	dpl,_control_setup_sloc4_1_0
      006A8D 85 1A 83         [24] 2321 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006A90 F0               [24] 2322 	movx	@dptr,a
      006A91 E5 17            [12] 2323 	mov	a,_control_setup_sloc3_1_0
      006A93 04               [12] 2324 	inc	a
      006A94 F5 17            [12] 2325 	mov	_control_setup_sloc3_1_0,a
      006A96 D0 01            [24] 2326 	pop	ar1
      006A98 D0 00            [24] 2327 	pop	ar0
      006A9A 80 BB            [24] 2328 	sjmp	00293$
      006A9C                       2329 00222$:
                                   2330 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      006A9C 90 08 50         [24] 2331 	mov	dptr,#_control_setup_length_10000_288
      006A9F E4               [12] 2332 	clr	a
      006AA0 F0               [24] 2333 	movx	@dptr,a
      006AA1 A3               [24] 2334 	inc	dptr
      006AA2 F0               [24] 2335 	movx	@dptr,a
      006AA3 02 6B 81         [24] 2336 	ljmp	00252$
      006AA6                       2337 00240$:
                                   2338 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006AA6 8D 00            [24] 2339 	mov	ar0,r5
      006AA8 8E 01            [24] 2340 	mov	ar1,r6
      006AAA B8 00 21         [24] 2341 	cjne	r0,#0x00,00236$
      006AAD B9 02 1E         [24] 2342 	cjne	r1,#0x02,00236$
      006AB0 EB               [12] 2343 	mov	a,r3
      006AB1 4C               [12] 2344 	orl	a,r4
      006AB2 70 1A            [24] 2345 	jnz	00236$
                                   2346 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006AB4 90 07 EC         [24] 2347 	mov	dptr,#_KB_USB_SetReport
      006AB7 E0               [24] 2348 	movx	a,@dptr
      006AB8 90 10 00         [24] 2349 	mov	dptr,#0x1000
      006ABB F0               [24] 2350 	movx	@dptr,a
                                   2351 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      006ABC 90 08 50         [24] 2352 	mov	dptr,#_control_setup_length_10000_288
      006ABF E4               [12] 2353 	clr	a
      006AC0 F0               [24] 2354 	movx	@dptr,a
      006AC1 A3               [24] 2355 	inc	dptr
      006AC2 F0               [24] 2356 	movx	@dptr,a
                                   2357 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006AC3 90 07 E2         [24] 2358 	mov	dptr,#_D0SetupLen
      006AC6 04               [12] 2359 	inc	a
      006AC7 F0               [24] 2360 	movx	@dptr,a
      006AC8 E4               [12] 2361 	clr	a
      006AC9 A3               [24] 2362 	inc	dptr
      006ACA F0               [24] 2363 	movx	@dptr,a
      006ACB 02 6B 81         [24] 2364 	ljmp	00252$
      006ACE                       2365 00236$:
                                   2366 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006ACE B8 06 41         [24] 2367 	cjne	r0,#0x06,00232$
      006AD1 B9 02 3E         [24] 2368 	cjne	r1,#0x02,00232$
      006AD4 BB 02 3B         [24] 2369 	cjne	r3,#0x02,00232$
      006AD7 BC 00 38         [24] 2370 	cjne	r4,#0x00,00232$
                                   2371 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006ADA C0 03            [24] 2372 	push	ar3
      006ADC C0 04            [24] 2373 	push	ar4
      006ADE 90 10 00         [24] 2374 	mov	dptr,#0x1000
      006AE1 74 06            [12] 2375 	mov	a,#0x06
      006AE3 F0               [24] 2376 	movx	@dptr,a
                                   2377 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006AE4 90 07 EC         [24] 2378 	mov	dptr,#_KB_USB_SetReport
      006AE7 E0               [24] 2379 	movx	a,@dptr
      006AE8 90 10 01         [24] 2380 	mov	dptr,#0x1001
      006AEB F0               [24] 2381 	movx	@dptr,a
                                   2382 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      006AEC 90 08 50         [24] 2383 	mov	dptr,#_control_setup_length_10000_288
      006AEF E4               [12] 2384 	clr	a
      006AF0 F0               [24] 2385 	movx	@dptr,a
      006AF1 A3               [24] 2386 	inc	dptr
      006AF2 F0               [24] 2387 	movx	@dptr,a
                                   2388 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006AF3 90 07 E2         [24] 2389 	mov	dptr,#_D0SetupLen
      006AF6 E0               [24] 2390 	movx	a,@dptr
      006AF7 FB               [12] 2391 	mov	r3,a
      006AF8 A3               [24] 2392 	inc	dptr
      006AF9 E0               [24] 2393 	movx	a,@dptr
      006AFA FC               [12] 2394 	mov	r4,a
      006AFB C3               [12] 2395 	clr	c
      006AFC 74 02            [12] 2396 	mov	a,#0x02
      006AFE 9B               [12] 2397 	subb	a,r3
      006AFF E4               [12] 2398 	clr	a
      006B00 9C               [12] 2399 	subb	a,r4
      006B01 D0 04            [24] 2400 	pop	ar4
      006B03 D0 03            [24] 2401 	pop	ar3
      006B05 50 7A            [24] 2402 	jnc	00252$
                                   2403 ;	free result
      006B07 90 07 E2         [24] 2404 	mov	dptr,#_D0SetupLen
      006B0A 74 02            [12] 2405 	mov	a,#0x02
      006B0C F0               [24] 2406 	movx	@dptr,a
      006B0D E4               [12] 2407 	clr	a
      006B0E A3               [24] 2408 	inc	dptr
      006B0F F0               [24] 2409 	movx	@dptr,a
      006B10 80 6F            [24] 2410 	sjmp	00252$
      006B12                       2411 00232$:
                                   2412 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006B12 B8 00 69         [24] 2413 	cjne	r0,#0x00,00228$
      006B15 B9 03 66         [24] 2414 	cjne	r1,#0x03,00228$
      006B18 BB 01 63         [24] 2415 	cjne	r3,#0x01,00228$
      006B1B BC 00 60         [24] 2416 	cjne	r4,#0x00,00228$
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      006B1E 90 10 00         [24] 2418 	mov	dptr,#0x1000
      006B21 74 41            [12] 2419 	mov	a,#0x41
      006B23 F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      006B24 A3               [24] 2422 	inc	dptr
      006B25 74 4B            [12] 2423 	mov	a,#0x4b
      006B27 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      006B28 A3               [24] 2426 	inc	dptr
      006B29 74 42            [12] 2427 	mov	a,#0x42
      006B2B F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006B2C A3               [24] 2430 	inc	dptr
      006B2D 74 54            [12] 2431 	mov	a,#0x54
      006B2F F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      006B30 A3               [24] 2434 	inc	dptr
      006B31 74 01            [12] 2435 	mov	a,#0x01
      006B33 F0               [24] 2436 	movx	@dptr,a
                                   2437 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      006B34 90 07 ED         [24] 2438 	mov	dptr,#_ak820_boot_stage
      006B37 E0               [24] 2439 	movx	a,@dptr
      006B38 90 10 05         [24] 2440 	mov	dptr,#0x1005
      006B3B F0               [24] 2441 	movx	@dptr,a
                                   2442 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006B3C 90 07 EE         [24] 2443 	mov	dptr,#_ak820_main_heartbeat
      006B3F E0               [24] 2444 	movx	a,@dptr
      006B40 90 10 06         [24] 2445 	mov	dptr,#0x1006
      006B43 F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006B44 90 07 E8         [24] 2448 	mov	dptr,#_USB_EnumStatus
      006B47 E0               [24] 2449 	movx	a,@dptr
      006B48 60 02            [24] 2450 	jz	00322$
      006B4A 74 01            [12] 2451 	mov	a,#0x01
      006B4C                       2452 00322$:
      006B4C F9               [12] 2453 	mov	r1,a
      006B4D 90 07 E9         [24] 2454 	mov	dptr,#_USB_SleepStatus
      006B50 E0               [24] 2455 	movx	a,@dptr
      006B51 54 02            [12] 2456 	anl	a,#0x02
      006B53 F8               [12] 2457 	mov	r0,a
      006B54 E9               [12] 2458 	mov	a,r1
      006B55 42 00            [12] 2459 	orl	ar0,a
      006B57 90 10 07         [24] 2460 	mov	dptr,#0x1007
      006B5A E8               [12] 2461 	mov	a,r0
      006B5B F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      006B5C 90 08 50         [24] 2464 	mov	dptr,#_control_setup_length_10000_288
      006B5F E4               [12] 2465 	clr	a
      006B60 F0               [24] 2466 	movx	@dptr,a
      006B61 A3               [24] 2467 	inc	dptr
      006B62 F0               [24] 2468 	movx	@dptr,a
                                   2469 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006B63 90 07 E2         [24] 2470 	mov	dptr,#_D0SetupLen
      006B66 E0               [24] 2471 	movx	a,@dptr
      006B67 F8               [12] 2472 	mov	r0,a
      006B68 A3               [24] 2473 	inc	dptr
      006B69 E0               [24] 2474 	movx	a,@dptr
      006B6A F9               [12] 2475 	mov	r1,a
      006B6B C3               [12] 2476 	clr	c
      006B6C 74 08            [12] 2477 	mov	a,#0x08
      006B6E 98               [12] 2478 	subb	a,r0
      006B6F E4               [12] 2479 	clr	a
      006B70 99               [12] 2480 	subb	a,r1
      006B71 50 0E            [24] 2481 	jnc	00252$
                                   2482 ;	free result
      006B73 90 07 E2         [24] 2483 	mov	dptr,#_D0SetupLen
      006B76 74 08            [12] 2484 	mov	a,#0x08
      006B78 F0               [24] 2485 	movx	@dptr,a
      006B79 E4               [12] 2486 	clr	a
      006B7A A3               [24] 2487 	inc	dptr
      006B7B F0               [24] 2488 	movx	@dptr,a
      006B7C 80 03            [24] 2489 	sjmp	00252$
      006B7E                       2490 00228$:
                                   2491 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006B7E 02 62 E7         [24] 2492 	ljmp	_control_stall
      006B81                       2493 00252$:
                                   2494 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006B81 90 08 50         [24] 2495 	mov	dptr,#_control_setup_length_10000_288
      006B84 E0               [24] 2496 	movx	a,@dptr
      006B85 F5 19            [12] 2497 	mov	_control_setup_sloc4_1_0,a
      006B87 A3               [24] 2498 	inc	dptr
      006B88 E0               [24] 2499 	movx	a,@dptr
      006B89 F5 1A            [12] 2500 	mov	(_control_setup_sloc4_1_0 + 1),a
      006B8B E5 19            [12] 2501 	mov	a,_control_setup_sloc4_1_0
      006B8D 45 1A            [12] 2502 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006B8F 60 50            [24] 2503 	jz	00262$
                                   2504 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006B91 90 07 E2         [24] 2505 	mov	dptr,#_D0SetupLen
      006B94 E0               [24] 2506 	movx	a,@dptr
      006B95 F8               [12] 2507 	mov	r0,a
      006B96 A3               [24] 2508 	inc	dptr
      006B97 E0               [24] 2509 	movx	a,@dptr
      006B98 F9               [12] 2510 	mov	r1,a
      006B99 C3               [12] 2511 	clr	c
      006B9A E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006B9C 98               [12] 2513 	subb	a,r0
      006B9D E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006B9F 99               [12] 2515 	subb	a,r1
      006BA0 50 0A            [24] 2516 	jnc	00559$
                                   2517 ;	free result
      006BA2 90 07 E2         [24] 2518 	mov	dptr,#_D0SetupLen
      006BA5 E5 19            [12] 2519 	mov	a,_control_setup_sloc4_1_0
      006BA7 F0               [24] 2520 	movx	@dptr,a
      006BA8 E5 1A            [12] 2521 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006BAA A3               [24] 2522 	inc	dptr
      006BAB F0               [24] 2523 	movx	@dptr,a
                                   2524 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006BAC                       2525 00559$:
      006BAC 75 19 00         [24] 2526 	mov	_control_setup_sloc4_1_0,#0x00
      006BAF                       2527 00296$:
      006BAF 90 07 E2         [24] 2528 	mov	dptr,#_D0SetupLen
      006BB2 E0               [24] 2529 	movx	a,@dptr
      006BB3 F8               [12] 2530 	mov	r0,a
      006BB4 C3               [12] 2531 	clr	c
      006BB5 E5 19            [12] 2532 	mov	a,_control_setup_sloc4_1_0
      006BB7 98               [12] 2533 	subb	a,r0
      006BB8 50 46            [24] 2534 	jnc	00263$
      006BBA 85 19 17         [24] 2535 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006BBD 74 10            [12] 2536 	mov	a,#0x10
      006BBF 24 00            [12] 2537 	add	a, #0x00
      006BC1 F5 18            [12] 2538 	mov	(_control_setup_sloc3_1_0 + 1),a
      006BC3 90 08 52         [24] 2539 	mov	dptr,#_control_setup_offset_10000_288
      006BC6 E0               [24] 2540 	movx	a,@dptr
      006BC7 25 19            [12] 2541 	add	a, _control_setup_sloc4_1_0
      006BC9 24 12            [12] 2542 	add	a, #_input_snapshot
      006BCB F5 82            [12] 2543 	mov	dpl,a
      006BCD E4               [12] 2544 	clr	a
      006BCE 34 08            [12] 2545 	addc	a,#(_input_snapshot >> 8)
      006BD0 F5 83            [12] 2546 	mov	dph,a
      006BD2 E0               [24] 2547 	movx	a,@dptr
      006BD3 85 17 82         [24] 2548 	mov	dpl,_control_setup_sloc3_1_0
      006BD6 85 18 83         [24] 2549 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006BD9 F0               [24] 2550 	movx	@dptr,a
      006BDA E5 19            [12] 2551 	mov	a,_control_setup_sloc4_1_0
      006BDC 04               [12] 2552 	inc	a
      006BDD F5 19            [12] 2553 	mov	_control_setup_sloc4_1_0,a
      006BDF 80 CE            [24] 2554 	sjmp	00296$
      006BE1                       2555 00262$:
                                   2556 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006BE1 BB 01 1C         [24] 2557 	cjne	r3,#0x01,00263$
      006BE4 BC 00 19         [24] 2558 	cjne	r4,#0x00,00263$
      006BE7 90 07 E2         [24] 2559 	mov	dptr,#_D0SetupLen
      006BEA E0               [24] 2560 	movx	a,@dptr
      006BEB F8               [12] 2561 	mov	r0,a
      006BEC A3               [24] 2562 	inc	dptr
      006BED E0               [24] 2563 	movx	a,@dptr
      006BEE F9               [12] 2564 	mov	r1,a
      006BEF C3               [12] 2565 	clr	c
      006BF0 74 20            [12] 2566 	mov	a,#0x20
      006BF2 98               [12] 2567 	subb	a,r0
      006BF3 E4               [12] 2568 	clr	a
      006BF4 99               [12] 2569 	subb	a,r1
      006BF5 50 09            [24] 2570 	jnc	00263$
                                   2571 ;	free result
      006BF7 90 07 E2         [24] 2572 	mov	dptr,#_D0SetupLen
      006BFA 74 20            [12] 2573 	mov	a,#0x20
      006BFC F0               [24] 2574 	movx	@dptr,a
      006BFD E4               [12] 2575 	clr	a
      006BFE A3               [24] 2576 	inc	dptr
      006BFF F0               [24] 2577 	movx	@dptr,a
      006C00                       2578 00263$:
                                   2579 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006C00 90 07 E2         [24] 2580 	mov	dptr,#_D0SetupLen
      006C03 E0               [24] 2581 	movx	a,@dptr
      006C04 90 22 08         [24] 2582 	mov	dptr,#0x2208
      006C07 F0               [24] 2583 	movx	@dptr,a
                                   2584 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      006C08 90 08 46         [24] 2585 	mov	dptr,#_control_phase
      006C0B 74 02            [12] 2586 	mov	a,#0x02
      006C0D F0               [24] 2587 	movx	@dptr,a
      006C0E 02 6C 96         [24] 2588 	ljmp	00291$
      006C11                       2589 00273$:
                                   2590 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006C11 EB               [12] 2591 	mov	a,r3
      006C12 4C               [12] 2592 	orl	a,r4
      006C13 70 37            [24] 2593 	jnz	00265$
      006C15 90 07 E7         [24] 2594 	mov	dptr,#_D0UsbConfig
      006C18 E0               [24] 2595 	movx	a,@dptr
      006C19 60 31            [24] 2596 	jz	00265$
      006C1B EA               [12] 2597 	mov	a,r2
      006C1C 60 2E            [24] 2598 	jz	00265$
      006C1E 90 07 E1         [24] 2599 	mov	dptr,#_D0SetupReqCode
      006C21 E0               [24] 2600 	movx	a,@dptr
      006C22 FA               [12] 2601 	mov	r2,a
      006C23 BA 03 26         [24] 2602 	cjne	r2,#0x03,00265$
      006C26 30 1A 23         [24] 2603 	jnb	_control_setup_zero_value_10000_288,00265$
      006C29 90 07 E2         [24] 2604 	mov	dptr,#_D0SetupLen
      006C2C E0               [24] 2605 	movx	a,@dptr
      006C2D F9               [12] 2606 	mov	r1,a
      006C2E A3               [24] 2607 	inc	dptr
      006C2F E0               [24] 2608 	movx	a,@dptr
      006C30 FA               [12] 2609 	mov	r2,a
      006C31 B9 01 18         [24] 2610 	cjne	r1,#0x01,00265$
      006C34 BA 00 15         [24] 2611 	cjne	r2,#0x00,00265$
                                   2612 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006C37 90 0E 3B         [24] 2613 	mov	dptr,#_keyboard_protocol
      006C3A E0               [24] 2614 	movx	a,@dptr
      006C3B 90 10 00         [24] 2615 	mov	dptr,#0x1000
      006C3E F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      006C3F 90 22 08         [24] 2618 	mov	dptr,#0x2208
      006C42 74 01            [12] 2619 	mov	a,#0x01
      006C44 F0               [24] 2620 	movx	@dptr,a
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      006C45 90 08 46         [24] 2622 	mov	dptr,#_control_phase
      006C48 04               [12] 2623 	inc	a
      006C49 F0               [24] 2624 	movx	@dptr,a
      006C4A 80 4A            [24] 2625 	sjmp	00291$
      006C4C                       2626 00265$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006C4C 02 62 E7         [24] 2629 	ljmp	_control_stall
      006C4F                       2630 00282$:
                                   2631 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006C4F 30 18 3E         [24] 2632 	jnb	_control_setup_valid_interface_10000_288,00284$
      006C52 90 07 E7         [24] 2633 	mov	dptr,#_D0UsbConfig
      006C55 E0               [24] 2634 	movx	a,@dptr
      006C56 60 38            [24] 2635 	jz	00284$
      006C58 BF A1 35         [24] 2636 	cjne	r7,#0xa1,00284$
      006C5B 8E 05            [24] 2637 	mov	ar5,r6
      006C5D 7E 00            [12] 2638 	mov	r6,#0x00
      006C5F ED               [12] 2639 	mov	a,r5
      006C60 4E               [12] 2640 	orl	a,r6
      006C61 70 2D            [24] 2641 	jnz	00284$
      006C63 90 07 E2         [24] 2642 	mov	dptr,#_D0SetupLen
      006C66 E0               [24] 2643 	movx	a,@dptr
      006C67 FE               [12] 2644 	mov	r6,a
      006C68 A3               [24] 2645 	inc	dptr
      006C69 E0               [24] 2646 	movx	a,@dptr
      006C6A FF               [12] 2647 	mov	r7,a
      006C6B BE 01 22         [24] 2648 	cjne	r6,#0x01,00284$
      006C6E BF 00 1F         [24] 2649 	cjne	r7,#0x00,00284$
                                   2650 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006C71 EB               [12] 2651 	mov	a,r3
      006C72 4C               [12] 2652 	orl	a,r4
      006C73 70 07            [24] 2653 	jnz	00324$
      006C75 90 06 A9         [24] 2654 	mov	dptr,#_keyboard_idle
      006C78 E0               [24] 2655 	movx	a,@dptr
      006C79 FF               [12] 2656 	mov	r7,a
      006C7A 80 02            [24] 2657 	sjmp	00325$
      006C7C                       2658 00324$:
      006C7C 7F 00            [12] 2659 	mov	r7,#0x00
      006C7E                       2660 00325$:
      006C7E 90 10 00         [24] 2661 	mov	dptr,#0x1000
      006C81 EF               [12] 2662 	mov	a,r7
      006C82 F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006C83 90 22 08         [24] 2665 	mov	dptr,#0x2208
      006C86 74 01            [12] 2666 	mov	a,#0x01
      006C88 F0               [24] 2667 	movx	@dptr,a
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      006C89 90 08 46         [24] 2669 	mov	dptr,#_control_phase
      006C8C 04               [12] 2670 	inc	a
      006C8D F0               [24] 2671 	movx	@dptr,a
      006C8E 80 06            [24] 2672 	sjmp	00291$
      006C90                       2673 00284$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006C90 02 62 E7         [24] 2676 	ljmp	_control_stall
      006C93                       2677 00290$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006C93 02 62 E7         [24] 2679 	ljmp	_control_stall
      006C96                       2680 00291$:
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006C96 90 22 00         [24] 2682 	mov	dptr,#0x2200
      006C99 74 C0            [12] 2683 	mov	a,#0xc0
      006C9B F0               [24] 2684 	movx	@dptr,a
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      006C9C 22               [24] 2686 	ret
                                   2687 ;------------------------------------------------------------
                                   2688 ;Allocation info for local variables in function 'control_out'
                                   2689 ;------------------------------------------------------------
                                   2690 ;i             Allocated with name '_control_out_i_10000_372'
                                   2691 ;------------------------------------------------------------
                                   2692 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2693 ;	-----------------------------------------
                                   2694 ;	 function control_out
                                   2695 ;	-----------------------------------------
      006C9D                       2696 _control_out:
                                   2697 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006C9D 90 22 0F         [24] 2698 	mov	dptr,#0x220f
      006CA0 E0               [24] 2699 	movx	a,@dptr
      006CA1 20 E6 01         [24] 2700 	jb	acc.6,00102$
      006CA4 22               [24] 2701 	ret
      006CA5                       2702 00102$:
                                   2703 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006CA5 90 08 46         [24] 2704 	mov	dptr,#_control_phase
      006CA8 E0               [24] 2705 	movx	a,@dptr
      006CA9 FF               [12] 2706 	mov	r7,a
      006CAA BF 02 12         [24] 2707 	cjne	r7,#0x02,00104$
      006CAD 90 22 0E         [24] 2708 	mov	dptr,#0x220e
      006CB0 E0               [24] 2709 	movx	a,@dptr
      006CB1 70 0C            [24] 2710 	jnz	00104$
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006CB3 90 08 46         [24] 2712 	mov	dptr,#_control_phase
      006CB6 E4               [12] 2713 	clr	a
      006CB7 F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006CB8 90 22 00         [24] 2716 	mov	dptr,#0x2200
      006CBB 74 02            [12] 2717 	mov	a,#0x02
      006CBD F0               [24] 2718 	movx	@dptr,a
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006CBE 22               [24] 2720 	ret
      006CBF                       2721 00104$:
                                   2722 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006CBF BF 04 19         [24] 2723 	cjne	r7,#0x04,00106$
      006CC2 90 22 0E         [24] 2724 	mov	dptr,#0x220e
      006CC5 E0               [24] 2725 	movx	a,@dptr
      006CC6 FF               [12] 2726 	mov	r7,a
      006CC7 90 07 E2         [24] 2727 	mov	dptr,#_D0SetupLen
      006CCA E0               [24] 2728 	movx	a,@dptr
      006CCB FD               [12] 2729 	mov	r5,a
      006CCC A3               [24] 2730 	inc	dptr
      006CCD E0               [24] 2731 	movx	a,@dptr
      006CCE FE               [12] 2732 	mov	r6,a
      006CCF 7C 00            [12] 2733 	mov	r4,#0x00
      006CD1 EF               [12] 2734 	mov	a,r7
      006CD2 B5 05 06         [24] 2735 	cjne	a,ar5,00209$
      006CD5 EC               [12] 2736 	mov	a,r4
      006CD6 B5 06 02         [24] 2737 	cjne	a,ar6,00209$
      006CD9 80 03            [24] 2738 	sjmp	00107$
      006CDB                       2739 00209$:
      006CDB                       2740 00106$:
      006CDB 02 62 E7         [24] 2741 	ljmp	_control_stall
      006CDE                       2742 00107$:
                                   2743 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006CDE 90 08 47         [24] 2744 	mov	dptr,#_output_kind
      006CE1 E0               [24] 2745 	movx	a,@dptr
      006CE2 FF               [12] 2746 	mov	r7,a
      006CE3 BF 01 2E         [24] 2747 	cjne	r7,#0x01,00118$
      006CE6 90 07 EF         [24] 2748 	mov	dptr,#_raw_state
      006CE9 E0               [24] 2749 	movx	a,@dptr
      006CEA FE               [12] 2750 	mov	r6,a
      006CEB BE 01 26         [24] 2751 	cjne	r6,#0x01,00118$
                                   2752 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006CEE 7E 00            [12] 2753 	mov	r6,#0x00
      006CF0                       2754 00121$:
      006CF0 EE               [12] 2755 	mov	a,r6
      006CF1 24 F0            [12] 2756 	add	a, #_raw_buffer
      006CF3 FC               [12] 2757 	mov	r4,a
      006CF4 E4               [12] 2758 	clr	a
      006CF5 34 07            [12] 2759 	addc	a, #(_raw_buffer >> 8)
      006CF7 FD               [12] 2760 	mov	r5,a
      006CF8 8E 82            [24] 2761 	mov	dpl,r6
      006CFA 74 10            [12] 2762 	mov	a,#0x10
      006CFC 24 00            [12] 2763 	add	a, #0x00
      006CFE F5 83            [12] 2764 	mov	dph,a
      006D00 E0               [24] 2765 	movx	a,@dptr
      006D01 8C 82            [24] 2766 	mov	dpl,r4
      006D03 8D 83            [24] 2767 	mov	dph,r5
      006D05 F0               [24] 2768 	movx	@dptr,a
      006D06 0E               [12] 2769 	inc	r6
      006D07 BE 20 00         [24] 2770 	cjne	r6,#0x20,00214$
      006D0A                       2771 00214$:
      006D0A 40 E4            [24] 2772 	jc	00121$
                                   2773 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006D0C 90 07 EF         [24] 2774 	mov	dptr,#_raw_state
      006D0F 74 02            [12] 2775 	mov	a,#0x02
      006D11 F0               [24] 2776 	movx	@dptr,a
      006D12 80 2B            [24] 2777 	sjmp	00119$
      006D14                       2778 00118$:
                                   2779 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      006D14 BF 02 0A         [24] 2780 	cjne	r7,#0x02,00115$
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      006D17 90 10 00         [24] 2782 	mov	dptr,#0x1000
      006D1A E0               [24] 2783 	movx	a,@dptr
      006D1B 90 07 EC         [24] 2784 	mov	dptr,#_KB_USB_SetReport
      006D1E F0               [24] 2785 	movx	@dptr,a
      006D1F 80 1E            [24] 2786 	sjmp	00119$
      006D21                       2787 00115$:
                                   2788 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006D21 BF 03 18         [24] 2789 	cjne	r7,#0x03,00111$
      006D24 90 10 00         [24] 2790 	mov	dptr,#0x1000
      006D27 E0               [24] 2791 	movx	a,@dptr
      006D28 FF               [12] 2792 	mov	r7,a
      006D29 90 08 48         [24] 2793 	mov	dptr,#_output_report_id
      006D2C E0               [24] 2794 	movx	a,@dptr
      006D2D FE               [12] 2795 	mov	r6,a
      006D2E EF               [12] 2796 	mov	a,r7
      006D2F B5 06 0A         [24] 2797 	cjne	a,ar6,00111$
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006D32 90 10 01         [24] 2799 	mov	dptr,#0x1001
      006D35 E0               [24] 2800 	movx	a,@dptr
      006D36 90 07 EC         [24] 2801 	mov	dptr,#_KB_USB_SetReport
      006D39 F0               [24] 2802 	movx	@dptr,a
      006D3A 80 03            [24] 2803 	sjmp	00119$
      006D3C                       2804 00111$:
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006D3C 02 62 E7         [24] 2806 	ljmp	_control_stall
      006D3F                       2807 00119$:
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006D3F 90 08 47         [24] 2809 	mov	dptr,#_output_kind
      006D42 E4               [12] 2810 	clr	a
      006D43 F0               [24] 2811 	movx	@dptr,a
                                   2812 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006D44 90 07 E2         [24] 2813 	mov	dptr,#_D0SetupLen
      006D47 F0               [24] 2814 	movx	@dptr,a
      006D48 A3               [24] 2815 	inc	dptr
      006D49 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006D4A 90 08 46         [24] 2818 	mov	dptr,#_control_phase
      006D4D 74 03            [12] 2819 	mov	a,#0x03
      006D4F F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006D50 90 22 08         [24] 2822 	mov	dptr,#0x2208
      006D53 E4               [12] 2823 	clr	a
      006D54 F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006D55 F5 82            [12] 2826 	mov	dpl,a
      006D57 74 48            [12] 2827 	mov	a,#0x48
      006D59 F0               [24] 2828 	movx	@dptr,a
                                   2829 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006D5A 22               [24] 2830 	ret
                                   2831 ;------------------------------------------------------------
                                   2832 ;Allocation info for local variables in function 'control_in'
                                   2833 ;------------------------------------------------------------
                                   2834 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2835 ;	-----------------------------------------
                                   2836 ;	 function control_in
                                   2837 ;	-----------------------------------------
      006D5B                       2838 _control_in:
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006D5B 90 08 46         [24] 2840 	mov	dptr,#_control_phase
      006D5E E0               [24] 2841 	movx	a,@dptr
      006D5F FF               [12] 2842 	mov	r7,a
      006D60 BF 01 22         [24] 2843 	cjne	r7,#0x01,00109$
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006D63 90 07 E2         [24] 2845 	mov	dptr,#_D0SetupLen
      006D66 E0               [24] 2846 	movx	a,@dptr
      006D67 FD               [12] 2847 	mov	r5,a
      006D68 A3               [24] 2848 	inc	dptr
      006D69 E0               [24] 2849 	movx	a,@dptr
      006D6A 4D               [12] 2850 	orl	a,r5
      006D6B 70 06            [24] 2851 	jnz	00101$
      006D6D 90 08 49         [24] 2852 	mov	dptr,#_control_zlp
      006D70 E0               [24] 2853 	movx	a,@dptr
      006D71 60 0A            [24] 2854 	jz	00102$
      006D73                       2855 00101$:
                                   2856 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006D73 90 22 00         [24] 2857 	mov	dptr,#0x2200
      006D76 E0               [24] 2858 	movx	a,@dptr
      006D77 64 40            [12] 2859 	xrl	a,#0x40
      006D79 F0               [24] 2860 	movx	@dptr,a
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006D7A 02 63 09         [24] 2863 	ljmp	_control_next
      006D7D                       2864 00102$:
                                   2865 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006D7D 90 08 46         [24] 2866 	mov	dptr,#_control_phase
      006D80 74 02            [12] 2867 	mov	a,#0x02
      006D82 F0               [24] 2868 	movx	@dptr,a
      006D83 80 18            [24] 2869 	sjmp	00110$
      006D85                       2870 00109$:
                                   2871 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006D85 BF 03 15         [24] 2872 	cjne	r7,#0x03,00110$
                                   2873 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006D88 90 07 E1         [24] 2874 	mov	dptr,#_D0SetupReqCode
      006D8B E0               [24] 2875 	movx	a,@dptr
      006D8C FF               [12] 2876 	mov	r7,a
      006D8D BF 05 08         [24] 2877 	cjne	r7,#0x05,00105$
      006D90 90 07 E2         [24] 2878 	mov	dptr,#_D0SetupLen
      006D93 E0               [24] 2879 	movx	a,@dptr
      006D94 90 22 07         [24] 2880 	mov	dptr,#0x2207
      006D97 F0               [24] 2881 	movx	@dptr,a
      006D98                       2882 00105$:
                                   2883 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006D98 90 08 46         [24] 2884 	mov	dptr,#_control_phase
      006D9B E4               [12] 2885 	clr	a
      006D9C F0               [24] 2886 	movx	@dptr,a
      006D9D                       2887 00110$:
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006D9D 90 22 00         [24] 2889 	mov	dptr,#0x2200
      006DA0 74 82            [12] 2890 	mov	a,#0x82
      006DA2 F0               [24] 2891 	movx	@dptr,a
                                   2892 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006DA3 22               [24] 2893 	ret
                                   2894 ;------------------------------------------------------------
                                   2895 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2896 ;------------------------------------------------------------
                                   2897 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_396'
                                   2898 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_396'
                                   2899 ;------------------------------------------------------------
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2901 ;	-----------------------------------------
                                   2902 ;	 function USB_DeviceInterrupt
                                   2903 ;	-----------------------------------------
      006DA4                       2904 _USB_DeviceInterrupt:
                                   2905 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006DA4                       2906 00129$:
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006DA4 90 22 3D         [24] 2908 	mov	dptr,#0x223d
      006DA7 E0               [24] 2909 	movx	a,@dptr
      006DA8 30 E0 4B         [24] 2910 	jnb	acc.0,00127$
                                   2911 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      006DAB 12 62 8A         [24] 2912 	lcall	_endpoints_reset
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006DAE 90 22 07         [24] 2914 	mov	dptr,#0x2207
      006DB1 E4               [12] 2915 	clr	a
      006DB2 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006DB3 90 07 E9         [24] 2918 	mov	dptr,#_USB_SleepStatus
      006DB6 F0               [24] 2919 	movx	@dptr,a
      006DB7 90 07 E8         [24] 2920 	mov	dptr,#_USB_EnumStatus
      006DBA F0               [24] 2921 	movx	@dptr,a
      006DBB 90 07 E7         [24] 2922 	mov	dptr,#_D0UsbConfig
      006DBE F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006DBF 90 07 EC         [24] 2925 	mov	dptr,#_KB_USB_SetReport
      006DC2 F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006DC3 90 0E 3B         [24] 2928 	mov	dptr,#_keyboard_protocol
      006DC6 04               [12] 2929 	inc	a
      006DC7 F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      006DC8 90 06 A9         [24] 2932 	mov	dptr,#_keyboard_idle
      006DCB E4               [12] 2933 	clr	a
      006DCC F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006DCD 90 08 11         [24] 2936 	mov	dptr,#_keyboard_reset
      006DD0 04               [12] 2937 	inc	a
      006DD1 F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006DD2 90 07 E1         [24] 2940 	mov	dptr,#_D0SetupReqCode
      006DD5 74 FF            [12] 2941 	mov	a,#0xff
      006DD7 F0               [24] 2942 	movx	@dptr,a
                                   2943 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      006DD8 90 07 E2         [24] 2944 	mov	dptr,#_D0SetupLen
      006DDB E4               [12] 2945 	clr	a
      006DDC F0               [24] 2946 	movx	@dptr,a
      006DDD A3               [24] 2947 	inc	dptr
      006DDE F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006DDF 90 08 46         [24] 2950 	mov	dptr,#_control_phase
      006DE2 F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006DE3 90 22 00         [24] 2953 	mov	dptr,#0x2200
      006DE6 74 02            [12] 2954 	mov	a,#0x02
      006DE8 F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      006DE9 90 22 0F         [24] 2957 	mov	dptr,#0x220f
      006DEC E4               [12] 2958 	clr	a
      006DED F0               [24] 2959 	movx	@dptr,a
                                   2960 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006DEE 90 22 3D         [24] 2961 	mov	dptr,#0x223d
      006DF1 04               [12] 2962 	inc	a
      006DF2 F0               [24] 2963 	movx	@dptr,a
      006DF3 02 6E 89         [24] 2964 	ljmp	00130$
      006DF6                       2965 00127$:
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006DF6 90 22 3D         [24] 2967 	mov	dptr,#0x223d
      006DF9 E0               [24] 2968 	movx	a,@dptr
      006DFA 30 E5 60         [24] 2969 	jnb	acc.5,00124$
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006DFD 90 22 0F         [24] 2971 	mov	dptr,#0x220f
      006E00 E0               [24] 2972 	movx	a,@dptr
      006E01 FF               [12] 2973 	mov	r7,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006E02 74 07            [12] 2975 	mov	a,#0x07
      006E04 5F               [12] 2976 	anl	a,r7
      006E05 FE               [12] 2977 	mov	r6,a
                                   2978 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006E06 EF               [12] 2979 	mov	a,r7
      006E07 54 18            [12] 2980 	anl	a,#0x18
      006E09 70 08            [24] 2981 	jnz	00115$
      006E0B EE               [12] 2982 	mov	a,r6
      006E0C 70 05            [24] 2983 	jnz	00115$
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006E0E 12 6C 9D         [24] 2985 	lcall	_control_out
      006E11 80 43            [24] 2986 	sjmp	00116$
      006E13                       2987 00115$:
                                   2988 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006E13 8F 05            [24] 2989 	mov	ar5,r7
      006E15 74 18            [12] 2990 	mov	a,#0x18
      006E17 5D               [12] 2991 	anl	a,r5
      006E18 FC               [12] 2992 	mov	r4,a
      006E19 BC 10 2D         [24] 2993 	cjne	r4,#0x10,00112$
                                   2994 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006E1C EE               [12] 2995 	mov	a,r6
      006E1D 70 05            [24] 2996 	jnz	00106$
      006E1F 12 6D 5B         [24] 2997 	lcall	_control_in
      006E22 80 32            [24] 2998 	sjmp	00116$
      006E24                       2999 00106$:
                                   3000 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006E24 EE               [12] 3001 	mov	a,r6
      006E25 24 FC            [12] 3002 	add	a,#0xff - 0x03
      006E27 40 2D            [24] 3003 	jc	00116$
                                   3004 ;	free result
                                   3005 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006E29 8E 04            [24] 3006 	mov	ar4,r6
      006E2B 7B 00            [12] 3007 	mov	r3,#0x00
      006E2D 74 22            [12] 3008 	mov	a,#0x22
      006E2F 2B               [12] 3009 	add	a, r3
      006E30 FB               [12] 3010 	mov	r3,a
      006E31 8C 82            [24] 3011 	mov	dpl,r4
      006E33 8B 83            [24] 3012 	mov	dph,r3
      006E35 E0               [24] 3013 	movx	a,@dptr
      006E36 FA               [12] 3014 	mov	r2,a
      006E37 74 FC            [12] 3015 	mov	a,#0xfc
      006E39 5A               [12] 3016 	anl	a,r2
      006E3A 44 02            [12] 3017 	orl	a,#0x02
      006E3C 8C 82            [24] 3018 	mov	dpl,r4
      006E3E 8B 83            [24] 3019 	mov	dph,r3
      006E40 F0               [24] 3020 	movx	@dptr,a
                                   3021 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006E41 BE 03 12         [24] 3022 	cjne	r6,#0x03,00116$
      006E44 12 62 6D         [24] 3023 	lcall	_raw_complete
      006E47 80 0D            [24] 3024 	sjmp	00116$
      006E49                       3025 00112$:
                                   3026 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006E49 53 05 18         [24] 3027 	anl	ar5,#0x18
      006E4C BD 18 07         [24] 3028 	cjne	r5,#0x18,00116$
      006E4F EF               [12] 3029 	mov	a,r7
      006E50 30 E5 03         [24] 3030 	jnb	acc.5,00116$
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006E53 12 65 00         [24] 3032 	lcall	_control_setup
      006E56                       3033 00116$:
                                   3034 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006E56 90 22 0F         [24] 3035 	mov	dptr,#0x220f
      006E59 E4               [12] 3036 	clr	a
      006E5A F0               [24] 3037 	movx	@dptr,a
      006E5B 80 2C            [24] 3038 	sjmp	00130$
      006E5D                       3039 00124$:
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006E5D 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      006E60 E0               [24] 3042 	movx	a,@dptr
      006E61 30 E2 25         [24] 3043 	jnb	acc.2,00130$
                                   3044 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006E64 90 22 3D         [24] 3045 	mov	dptr,#0x223d
      006E67 E0               [24] 3046 	movx	a,@dptr
      006E68 30 E3 0A         [24] 3047 	jnb	acc.3,00119$
      006E6B 90 07 E9         [24] 3048 	mov	dptr,#_USB_SleepStatus
      006E6E E0               [24] 3049 	movx	a,@dptr
      006E6F 43 E0 02         [24] 3050 	orl	acc,#0x02
      006E72 F0               [24] 3051 	movx	@dptr,a
      006E73 80 0E            [24] 3052 	sjmp	00120$
      006E75                       3053 00119$:
                                   3054 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006E75 90 07 E9         [24] 3055 	mov	dptr,#_USB_SleepStatus
      006E78 E0               [24] 3056 	movx	a,@dptr
      006E79 53 E0 FD         [24] 3057 	anl	acc,#0xfd
      006E7C F0               [24] 3058 	movx	@dptr,a
                                   3059 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006E7D 90 08 11         [24] 3060 	mov	dptr,#_keyboard_reset
      006E80 74 01            [12] 3061 	mov	a,#0x01
      006E82 F0               [24] 3062 	movx	@dptr,a
      006E83                       3063 00120$:
                                   3064 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006E83 90 22 3D         [24] 3065 	mov	dptr,#0x223d
      006E86 74 04            [12] 3066 	mov	a,#0x04
      006E88 F0               [24] 3067 	movx	@dptr,a
      006E89                       3068 00130$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006E89 90 22 3D         [24] 3070 	mov	dptr,#0x223d
      006E8C E0               [24] 3071 	movx	a,@dptr
      006E8D 54 25            [12] 3072 	anl	a,#0x25
      006E8F 60 03            [24] 3073 	jz	00242$
      006E91 02 6D A4         [24] 3074 	ljmp	00129$
      006E94                       3075 00242$:
                                   3076 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006E94 22               [24] 3077 	ret
                                   3078 ;------------------------------------------------------------
                                   3079 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3080 ;------------------------------------------------------------
                                   3081 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3082 ;	-----------------------------------------
                                   3083 ;	 function USB_Device_Init
                                   3084 ;	-----------------------------------------
      006E95                       3085 _USB_Device_Init:
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3087 ;	assignBit
      006E95 C2 E9            [12] 3088 	clr	_IE_USB
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006E97 90 22 3C         [24] 3090 	mov	dptr,#0x223c
      006E9A E4               [12] 3091 	clr	a
      006E9B F0               [24] 3092 	movx	@dptr,a
                                   3093 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006E9C 90 07 EF         [24] 3094 	mov	dptr,#_raw_state
      006E9F F0               [24] 3095 	movx	@dptr,a
                                   3096 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006EA0 12 62 8A         [24] 3097 	lcall	_endpoints_reset
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006EA3 90 07 E9         [24] 3099 	mov	dptr,#_USB_SleepStatus
      006EA6 E4               [12] 3100 	clr	a
      006EA7 F0               [24] 3101 	movx	@dptr,a
      006EA8 90 07 E8         [24] 3102 	mov	dptr,#_USB_EnumStatus
      006EAB F0               [24] 3103 	movx	@dptr,a
      006EAC 90 07 E7         [24] 3104 	mov	dptr,#_D0UsbConfig
      006EAF F0               [24] 3105 	movx	@dptr,a
      006EB0 90 22 07         [24] 3106 	mov	dptr,#0x2207
      006EB3 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006EB4 90 07 EA         [24] 3109 	mov	dptr,#_MCU_Sleep_Operate
      006EB7 F0               [24] 3110 	movx	@dptr,a
      006EB8 90 07 EB         [24] 3111 	mov	dptr,#_KB_USB_UpStatus
      006EBB F0               [24] 3112 	movx	@dptr,a
      006EBC 90 07 EC         [24] 3113 	mov	dptr,#_KB_USB_SetReport
      006EBF F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006EC0 90 0E 3B         [24] 3116 	mov	dptr,#_keyboard_protocol
      006EC3 04               [12] 3117 	inc	a
      006EC4 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006EC5 90 06 A9         [24] 3120 	mov	dptr,#_keyboard_idle
      006EC8 E4               [12] 3121 	clr	a
      006EC9 F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006ECA 90 08 11         [24] 3124 	mov	dptr,#_keyboard_reset
      006ECD F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006ECE 90 08 46         [24] 3127 	mov	dptr,#_control_phase
      006ED1 F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006ED2 90 07 E1         [24] 3130 	mov	dptr,#_D0SetupReqCode
      006ED5 14               [12] 3131 	dec	a
      006ED6 F0               [24] 3132 	movx	@dptr,a
                                   3133 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006ED7 90 07 E2         [24] 3134 	mov	dptr,#_D0SetupLen
      006EDA E4               [12] 3135 	clr	a
      006EDB F0               [24] 3136 	movx	@dptr,a
      006EDC A3               [24] 3137 	inc	dptr
      006EDD F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006EDE 90 22 00         [24] 3140 	mov	dptr,#0x2200
      006EE1 74 02            [12] 3141 	mov	a,#0x02
      006EE3 F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006EE4 90 22 37         [24] 3144 	mov	dptr,#0x2237
      006EE7 74 7F            [12] 3145 	mov	a,#0x7f
      006EE9 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006EEA 90 22 3D         [24] 3148 	mov	dptr,#0x223d
      006EED 74 FF            [12] 3149 	mov	a,#0xff
      006EEF F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006EF0 90 22 3B         [24] 3152 	mov	dptr,#0x223b
      006EF3 74 07            [12] 3153 	mov	a,#0x07
      006EF5 F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006EF6 A3               [24] 3156 	inc	dptr
      006EF7 74 80            [12] 3157 	mov	a,#0x80
      006EF9 F0               [24] 3158 	movx	@dptr,a
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3160 ;	assignBit
      006EFA D2 E9            [12] 3161 	setb	_IE_USB
                                   3162 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006EFC 22               [24] 3163 	ret
                                   3164 ;------------------------------------------------------------
                                   3165 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3166 ;------------------------------------------------------------
                                   3167 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_419'
                                   3168 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_422'
                                   3169 ;------------------------------------------------------------
                                   3170 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3171 ;	-----------------------------------------
                                   3172 ;	 function USB_WakeUp_PC
                                   3173 ;	-----------------------------------------
      006EFD                       3174 _USB_WakeUp_PC:
                                   3175 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006EFD 90 07 E9         [24] 3176 	mov	dptr,#_USB_SleepStatus
      006F00 E0               [24] 3177 	movx	a,@dptr
      006F01 FF               [12] 3178 	mov	r7,a
      006F02 BF 03 22         [24] 3179 	cjne	r7,#0x03,00110$
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006F05 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      006F08 E0               [24] 3182 	movx	a,@dptr
      006F09 FF               [12] 3183 	mov	r7,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006F0A E0               [24] 3185 	movx	a,@dptr
      006F0B FE               [12] 3186 	mov	r6,a
      006F0C 63 06 C0         [24] 3187 	xrl	ar6,#0xc0
      006F0F 90 22 3C         [24] 3188 	mov	dptr,#0x223c
      006F12 EE               [12] 3189 	mov	a,r6
      006F13 F0               [24] 3190 	movx	@dptr,a
                                   3191 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006F14 7E 0A            [12] 3192 	mov	r6,#0x0a
      006F16                       3193 00108$:
      006F16 EE               [12] 3194 	mov	a,r6
      006F17 60 09            [24] 3195 	jz	00105$
      006F19 90 00 01         [24] 3196 	mov	dptr,#0x0001
      006F1C 12 60 B1         [24] 3197 	lcall	_mDelaymS
      006F1F 1E               [12] 3198 	dec	r6
      006F20 80 F4            [24] 3199 	sjmp	00108$
      006F22                       3200 00105$:
                                   3201 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006F22 90 22 3C         [24] 3202 	mov	dptr,#0x223c
      006F25 EF               [12] 3203 	mov	a,r7
      006F26 F0               [24] 3204 	movx	@dptr,a
      006F27                       3205 00110$:
                                   3206 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006F27 22               [24] 3207 	ret
                                   3208 ;------------------------------------------------------------
                                   3209 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3210 ;------------------------------------------------------------
                                   3211 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3212 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3213 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3214 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3215 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_424'
                                   3216 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_425'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_10000_425'
                                   3218 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_425'
                                   3219 ;offset        Allocated with name '_ak820_usb_send_offset_10000_425'
                                   3220 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_425'
                                   3221 ;i             Allocated with name '_ak820_usb_send_i_30000_437'
                                   3222 ;------------------------------------------------------------
                                   3223 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3224 ;	-----------------------------------------
                                   3225 ;	 function ak820_usb_send
                                   3226 ;	-----------------------------------------
      006F28                       3227 _ak820_usb_send:
      006F28 E5 82            [12] 3228 	mov	a,dpl
      006F2A 90 08 56         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      006F2D F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006F2E 90 08 57         [24] 3232 	mov	dptr,#_ak820_usb_send_offset_10000_425
      006F31 74 34            [12] 3233 	mov	a,#0x34
      006F33 F0               [24] 3234 	movx	@dptr,a
                                   3235 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006F34 90 08 56         [24] 3236 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      006F37 E0               [24] 3237 	movx	a,@dptr
      006F38 FF               [12] 3238 	mov	r7,a
      006F39 BF 01 00         [24] 3239 	cjne	r7,#0x01,00306$
      006F3C                       3240 00306$:
      006F3C 40 14            [24] 3241 	jc	00101$
      006F3E EF               [12] 3242 	mov	a,r7
      006F3F 24 FC            [12] 3243 	add	a,#0xff - 0x03
      006F41 40 0F            [24] 3244 	jc	00101$
                                   3245 ;	free result
      006F43 90 08 55         [24] 3246 	mov	dptr,#_ak820_usb_send_PARM_3
      006F46 E0               [24] 3247 	movx	a,@dptr
      006F47 FE               [12] 3248 	mov  r6,a
      006F48 24 BF            [12] 3249 	add	a,#0xff - 0x40
      006F4A 40 06            [24] 3250 	jc	00101$
                                   3251 ;	free result
      006F4C 90 07 E8         [24] 3252 	mov	dptr,#_USB_EnumStatus
      006F4F E0               [24] 3253 	movx	a,@dptr
      006F50 70 04            [24] 3254 	jnz	00102$
      006F52                       3255 00101$:
      006F52 75 82 00         [24] 3256 	mov	dpl, #0x00
      006F55 22               [24] 3257 	ret
      006F56                       3258 00102$:
                                   3259 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006F56 BF 01 10         [24] 3260 	cjne	r7,#0x01,00118$
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006F59 BE 08 02         [24] 3262 	cjne	r6,#0x08,00313$
      006F5C 80 04            [24] 3263 	sjmp	00107$
      006F5E                       3264 00313$:
      006F5E 75 82 00         [24] 3265 	mov	dpl, #0x00
      006F61 22               [24] 3266 	ret
      006F62                       3267 00107$:
                                   3268 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006F62 90 08 57         [24] 3269 	mov	dptr,#_ak820_usb_send_offset_10000_425
      006F65 E4               [12] 3270 	clr	a
      006F66 F0               [24] 3271 	movx	@dptr,a
      006F67 80 3C            [24] 3272 	sjmp	00119$
      006F69                       3273 00118$:
                                   3274 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006F69 BF 02 30         [24] 3275 	cjne	r7,#0x02,00115$
                                   3276 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006F6C 90 08 53         [24] 3277 	mov	dptr,#_ak820_usb_send_PARM_2
      006F6F E0               [24] 3278 	movx	a,@dptr
      006F70 FD               [12] 3279 	mov	r5,a
      006F71 A3               [24] 3280 	inc	dptr
      006F72 E0               [24] 3281 	movx	a,@dptr
      006F73 FF               [12] 3282 	mov	r7,a
      006F74 8D 82            [24] 3283 	mov	dpl,r5
      006F76 8F 83            [24] 3284 	mov	dph,r7
      006F78 E0               [24] 3285 	movx	a,@dptr
      006F79 FF               [12] 3286 	mov	r7,a
                                   3287 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006F7A BF 07 00         [24] 3288 	cjne	r7,#0x07,00316$
      006F7D                       3289 00316$:
      006F7D 50 0E            [24] 3290 	jnc	00108$
      006F7F EF               [12] 3291 	mov	a,r7
      006F80 90 C1 EC         [24] 3292 	mov	dptr,#_shared_lengths
      006F83 93               [24] 3293 	movc	a,@a+dptr
      006F84 FD               [12] 3294 	mov	r5,a
      006F85 60 06            [24] 3295 	jz	00108$
      006F87 EE               [12] 3296 	mov	a,r6
      006F88 B5 05 02         [24] 3297 	cjne	a,ar5,00319$
      006F8B 80 04            [24] 3298 	sjmp	00109$
      006F8D                       3299 00319$:
      006F8D                       3300 00108$:
      006F8D 75 82 00         [24] 3301 	mov	dpl, #0x00
      006F90 22               [24] 3302 	ret
      006F91                       3303 00109$:
                                   3304 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006F91 EF               [12] 3305 	mov	a,r7
      006F92 90 C1 E5         [24] 3306 	mov	dptr,#_shared_offsets
      006F95 93               [24] 3307 	movc	a,@a+dptr
      006F96 90 08 57         [24] 3308 	mov	dptr,#_ak820_usb_send_offset_10000_425
      006F99 F0               [24] 3309 	movx	@dptr,a
      006F9A 80 09            [24] 3310 	sjmp	00119$
      006F9C                       3311 00115$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006F9C BE 20 02         [24] 3313 	cjne	r6,#0x20,00320$
      006F9F 80 04            [24] 3314 	sjmp	00119$
      006FA1                       3315 00320$:
      006FA1 75 82 00         [24] 3316 	mov	dpl, #0x00
      006FA4 22               [24] 3317 	ret
      006FA5                       3318 00119$:
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006FA5 90 07 E9         [24] 3320 	mov	dptr,#_USB_SleepStatus
      006FA8 E0               [24] 3321 	movx	a,@dptr
      006FA9 30 E1 07         [24] 3322 	jnb	acc.1,00184$
      006FAC 12 6E FD         [24] 3323 	lcall	_USB_WakeUp_PC
      006FAF 75 82 00         [24] 3324 	mov	dpl, #0x00
      006FB2 22               [24] 3325 	ret
                                   3326 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006FB3                       3327 00184$:
      006FB3 7F FA            [12] 3328 	mov	r7,#0xfa
      006FB5                       3329 00127$:
      006FB5 90 08 56         [24] 3330 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      006FB8 E0               [24] 3331 	movx	a,@dptr
      006FB9 FC               [12] 3332 	mov	r4,a
      006FBA 7D 00            [12] 3333 	mov	r5,#0x00
      006FBC 8C 02            [24] 3334 	mov	ar2,r4
      006FBE 74 22            [12] 3335 	mov	a,#0x22
      006FC0 2D               [12] 3336 	add	a, r5
      006FC1 FB               [12] 3337 	mov	r3,a
      006FC2 8A 82            [24] 3338 	mov	dpl,r2
      006FC4 8B 83            [24] 3339 	mov	dph,r3
      006FC6 E0               [24] 3340 	movx	a,@dptr
      006FC7 54 03            [12] 3341 	anl	a,#0x03
      006FC9 70 20            [24] 3342 	jnz	00129$
      006FCB 8F 03            [24] 3343 	mov	ar3,r7
      006FCD 1F               [12] 3344 	dec	r7
      006FCE EB               [12] 3345 	mov	a,r3
      006FCF 60 1A            [24] 3346 	jz	00129$
      006FD1 7B 28            [12] 3347 	mov	r3,#0x28
      006FD3                       3348 00141$:
      006FD3 EB               [12] 3349 	mov	a,r3
      006FD4 60 DF            [24] 3350 	jz	00127$
      006FD6 90 00 01         [24] 3351 	mov	dptr,#0x0001
      006FD9 C0 07            [24] 3352 	push	ar7
      006FDB C0 06            [24] 3353 	push	ar6
      006FDD C0 03            [24] 3354 	push	ar3
      006FDF 12 60 75         [24] 3355 	lcall	_mDelayuS
      006FE2 D0 03            [24] 3356 	pop	ar3
      006FE4 D0 06            [24] 3357 	pop	ar6
      006FE6 D0 07            [24] 3358 	pop	ar7
      006FE8 1B               [12] 3359 	dec	r3
      006FE9 80 E8            [24] 3360 	sjmp	00141$
      006FEB                       3361 00129$:
                                   3362 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006FEB A2 AF            [12] 3363 	mov	c,_EA
      006FED E4               [12] 3364 	clr	a
      006FEE 33               [12] 3365 	rlc	a
      006FEF FF               [12] 3366 	mov	r7,a
                                   3367 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3368 ;	assignBit
      006FF0 C2 AF            [12] 3369 	clr	_EA
                                   3370 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006FF2 90 07 E8         [24] 3371 	mov	dptr,#_USB_EnumStatus
      006FF5 E0               [24] 3372 	movx	a,@dptr
      006FF6 60 25            [24] 3373 	jz	00130$
      006FF8 90 08 56         [24] 3374 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      006FFB E0               [24] 3375 	movx	a,@dptr
      006FFC FB               [12] 3376 	mov	r3,a
      006FFD F9               [12] 3377 	mov	r1,a
      006FFE 7A 00            [12] 3378 	mov	r2,#0x00
      007000 74 22            [12] 3379 	mov	a,#0x22
      007002 2A               [12] 3380 	add	a, r2
      007003 FA               [12] 3381 	mov	r2,a
      007004 89 82            [24] 3382 	mov	dpl,r1
      007006 8A 83            [24] 3383 	mov	dph,r2
      007008 E0               [24] 3384 	movx	a,@dptr
      007009 FA               [12] 3385 	mov	r2,a
      00700A 53 02 03         [24] 3386 	anl	ar2,#0x03
      00700D BA 02 0D         [24] 3387 	cjne	r2,#0x02,00130$
                                   3388 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      007010 BB 03 13         [24] 3389 	cjne	r3,#0x03,00192$
      007013 90 07 EF         [24] 3390 	mov	dptr,#_raw_state
      007016 E0               [24] 3391 	movx	a,@dptr
      007017 FB               [12] 3392 	mov	r3,a
      007018 BB 03 02         [24] 3393 	cjne	r3,#0x03,00331$
      00701B 80 09            [24] 3394 	sjmp	00192$
      00701D                       3395 00331$:
      00701D                       3396 00130$:
                                   3397 ;	assignBit
      00701D EF               [12] 3398 	mov	a,r7
      00701E 24 FF            [12] 3399 	add	a,#0xff
      007020 92 AF            [24] 3400 	mov	_EA,c
      007022 75 82 00         [24] 3401 	mov	dpl, #0x00
      007025 22               [24] 3402 	ret
                                   3403 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      007026                       3404 00192$:
      007026 7B 00            [12] 3405 	mov	r3,#0x00
      007028                       3406 00144$:
      007028 C3               [12] 3407 	clr	c
      007029 EB               [12] 3408 	mov	a,r3
      00702A 9E               [12] 3409 	subb	a,r6
      00702B 50 67            [24] 3410 	jnc	00137$
                                   3411 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      00702D C0 07            [24] 3412 	push	ar7
      00702F 90 08 56         [24] 3413 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      007032 E0               [24] 3414 	movx	a,@dptr
      007033 F9               [12] 3415 	mov	r1,a
      007034 E4               [12] 3416 	clr	a
      007035 C3               [12] 3417 	clr	c
      007036 C9               [12] 3418 	xch	a,r1
      007037 13               [12] 3419 	rrc	a
      007038 C9               [12] 3420 	xch	a,r1
      007039 13               [12] 3421 	rrc	a
      00703A A2 E0            [12] 3422 	mov	c,acc.0
      00703C C9               [12] 3423 	xch	a,r1
      00703D 13               [12] 3424 	rrc	a
      00703E C9               [12] 3425 	xch	a,r1
      00703F 13               [12] 3426 	rrc	a
      007040 C9               [12] 3427 	xch	a,r1
      007041 FA               [12] 3428 	mov	r2,a
      007042 8B 00            [24] 3429 	mov	ar0,r3
      007044 7F 00            [12] 3430 	mov	r7,#0x00
      007046 E8               [12] 3431 	mov	a,r0
      007047 29               [12] 3432 	add	a, r1
      007048 F9               [12] 3433 	mov	r1,a
      007049 EF               [12] 3434 	mov	a,r7
      00704A 3A               [12] 3435 	addc	a, r2
      00704B 24 10            [12] 3436 	add	a,#0x10
      00704D FA               [12] 3437 	mov	r2,a
      00704E 90 08 53         [24] 3438 	mov	dptr,#_ak820_usb_send_PARM_2
      007051 E0               [24] 3439 	movx	a,@dptr
      007052 F8               [12] 3440 	mov	r0,a
      007053 A3               [24] 3441 	inc	dptr
      007054 E0               [24] 3442 	movx	a,@dptr
      007055 FF               [12] 3443 	mov	r7,a
      007056 EB               [12] 3444 	mov	a,r3
      007057 28               [12] 3445 	add	a, r0
      007058 F5 1B            [12] 3446 	mov	_ak820_usb_send_sloc0_1_0,a
      00705A E4               [12] 3447 	clr	a
      00705B 3F               [12] 3448 	addc	a, r7
      00705C F5 1C            [12] 3449 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      00705E 85 1B 82         [24] 3450 	mov	dpl,_ak820_usb_send_sloc0_1_0
      007061 85 1C 83         [24] 3451 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      007064 E0               [24] 3452 	movx	a,@dptr
      007065 89 82            [24] 3453 	mov	dpl,r1
      007067 8A 83            [24] 3454 	mov	dph,r2
      007069 F0               [24] 3455 	movx	@dptr,a
                                   3456 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00706A 90 08 57         [24] 3457 	mov	dptr,#_ak820_usb_send_offset_10000_425
      00706D E0               [24] 3458 	movx	a,@dptr
      00706E F5 1D            [12] 3459 	mov	_ak820_usb_send_sloc1_1_0,a
      007070 74 34            [12] 3460 	mov	a,#0x34
      007072 B5 1D 04         [24] 3461 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      007075 D0 07            [24] 3462 	pop	ar7
      007077 80 18            [24] 3463 	sjmp	00145$
      007079                       3464 00333$:
      007079 D0 07            [24] 3465 	pop	ar7
      00707B EB               [12] 3466 	mov	a,r3
      00707C 25 1D            [12] 3467 	add	a, _ak820_usb_send_sloc1_1_0
      00707E 24 12            [12] 3468 	add	a, #_input_snapshot
      007080 F9               [12] 3469 	mov	r1,a
      007081 E4               [12] 3470 	clr	a
      007082 34 08            [12] 3471 	addc	a,#(_input_snapshot >> 8)
      007084 FA               [12] 3472 	mov	r2,a
      007085 85 1B 82         [24] 3473 	mov	dpl,_ak820_usb_send_sloc0_1_0
      007088 85 1C 83         [24] 3474 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      00708B E0               [24] 3475 	movx	a,@dptr
      00708C 89 82            [24] 3476 	mov	dpl,r1
      00708E 8A 83            [24] 3477 	mov	dph,r2
      007090 F0               [24] 3478 	movx	@dptr,a
      007091                       3479 00145$:
                                   3480 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      007091 0B               [12] 3481 	inc	r3
      007092 80 94            [24] 3482 	sjmp	00144$
      007094                       3483 00137$:
                                   3484 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      007094 90 08 56         [24] 3485 	mov	dptr,#_ak820_usb_send_endpoint_10000_424
      007097 E0               [24] 3486 	movx	a,@dptr
      007098 FB               [12] 3487 	mov	r3,a
      007099 F9               [12] 3488 	mov	r1,a
      00709A 7A 00            [12] 3489 	mov	r2,#0x00
      00709C 74 08            [12] 3490 	mov	a,#0x08
      00709E 29               [12] 3491 	add	a, r1
      00709F F9               [12] 3492 	mov	r1,a
      0070A0 74 22            [12] 3493 	mov	a,#0x22
      0070A2 3A               [12] 3494 	addc	a, r2
      0070A3 FA               [12] 3495 	mov	r2,a
      0070A4 89 82            [24] 3496 	mov	dpl,r1
      0070A6 8A 83            [24] 3497 	mov	dph,r2
      0070A8 EE               [12] 3498 	mov	a,r6
      0070A9 F0               [24] 3499 	movx	@dptr,a
                                   3500 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      0070AA BB 03 06         [24] 3501 	cjne	r3,#0x03,00139$
      0070AD 90 07 EF         [24] 3502 	mov	dptr,#_raw_state
      0070B0 74 04            [12] 3503 	mov	a,#0x04
      0070B2 F0               [24] 3504 	movx	@dptr,a
      0070B3                       3505 00139$:
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0070B3 74 22            [12] 3507 	mov	a,#0x22
      0070B5 2D               [12] 3508 	add	a, r5
      0070B6 FD               [12] 3509 	mov	r5,a
      0070B7 8C 82            [24] 3510 	mov	dpl,r4
      0070B9 8D 83            [24] 3511 	mov	dph,r5
      0070BB E0               [24] 3512 	movx	a,@dptr
      0070BC FE               [12] 3513 	mov	r6,a
      0070BD 53 06 FC         [24] 3514 	anl	ar6,#0xfc
      0070C0 8C 82            [24] 3515 	mov	dpl,r4
      0070C2 8D 83            [24] 3516 	mov	dph,r5
      0070C4 EE               [12] 3517 	mov	a,r6
      0070C5 F0               [24] 3518 	movx	@dptr,a
                                   3519 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3520 ;	assignBit
      0070C6 EF               [12] 3521 	mov	a,r7
      0070C7 24 FF            [12] 3522 	add	a,#0xff
      0070C9 92 AF            [24] 3523 	mov	_EA,c
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      0070CB 75 82 01         [24] 3525 	mov	dpl, #0x01
                                   3526 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      0070CE 22               [24] 3527 	ret
                                   3528 ;------------------------------------------------------------
                                   3529 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3530 ;------------------------------------------------------------
                                   3531 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3532 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3533 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_445'
                                   3534 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_446'
                                   3535 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_446'
                                   3536 ;------------------------------------------------------------
                                   3537 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3538 ;	-----------------------------------------
                                   3539 ;	 function ak820_usb_try_send
                                   3540 ;	-----------------------------------------
      0070CF                       3541 _ak820_usb_try_send:
      0070CF E5 82            [12] 3542 	mov	a,dpl
      0070D1 90 08 5B         [24] 3543 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_445
      0070D4 F0               [24] 3544 	movx	@dptr,a
                                   3545 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3546 ;	assignBit
      0070D5 A2 AF            [12] 3547 	mov	c,_EA
      0070D7 92 1E            [24] 3548 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3549 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      0070D9 90 08 5C         [24] 3550 	mov	dptr,#_ak820_usb_try_send_sent_10000_446
      0070DC E4               [12] 3551 	clr	a
      0070DD F0               [24] 3552 	movx	@dptr,a
                                   3553 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3554 ;	assignBit
      0070DE C2 AF            [12] 3555 	clr	_EA
                                   3556 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0070E0 90 08 5B         [24] 3557 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_445
      0070E3 E0               [24] 3558 	movx	a,@dptr
      0070E4 FF               [12] 3559 	mov	r7,a
      0070E5 BF 01 00         [24] 3560 	cjne	r7,#0x01,00152$
      0070E8                       3561 00152$:
      0070E8 40 4E            [24] 3562 	jc	00102$
      0070EA EF               [12] 3563 	mov	a,r7
      0070EB 24 FD            [12] 3564 	add	a,#0xff - 0x02
      0070ED 40 49            [24] 3565 	jc	00102$
                                   3566 ;	free result
      0070EF 90 07 E8         [24] 3567 	mov	dptr,#_USB_EnumStatus
      0070F2 E0               [24] 3568 	movx	a,@dptr
      0070F3 60 43            [24] 3569 	jz	00102$
                                   3570 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      0070F5 90 07 E9         [24] 3571 	mov	dptr,#_USB_SleepStatus
      0070F8 E0               [24] 3572 	movx	a,@dptr
      0070F9 20 E1 3C         [24] 3573 	jb	acc.1,00102$
      0070FC 90 08 11         [24] 3574 	mov	dptr,#_keyboard_reset
      0070FF E0               [24] 3575 	movx	a,@dptr
                                   3576 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      007100 70 36            [24] 3577 	jnz	00102$
      007102 8F 06            [24] 3578 	mov	ar6,r7
      007104 24 22            [12] 3579 	add	a,#0x22
      007106 FD               [12] 3580 	mov	r5,a
      007107 8E 82            [24] 3581 	mov	dpl,r6
      007109 8D 83            [24] 3582 	mov	dph,r5
      00710B E0               [24] 3583 	movx	a,@dptr
      00710C FE               [12] 3584 	mov	r6,a
      00710D 53 06 03         [24] 3585 	anl	ar6,#0x03
      007110 BE 02 25         [24] 3586 	cjne	r6,#0x02,00102$
                                   3587 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      007113 90 08 58         [24] 3588 	mov	dptr,#_ak820_usb_try_send_PARM_2
      007116 E0               [24] 3589 	movx	a,@dptr
      007117 FD               [12] 3590 	mov	r5,a
      007118 A3               [24] 3591 	inc	dptr
      007119 E0               [24] 3592 	movx	a,@dptr
      00711A FE               [12] 3593 	mov	r6,a
      00711B 90 08 5A         [24] 3594 	mov	dptr,#_ak820_usb_try_send_PARM_3
      00711E E0               [24] 3595 	movx	a,@dptr
      00711F FC               [12] 3596 	mov	r4,a
      007120 90 08 53         [24] 3597 	mov	dptr,#_ak820_usb_send_PARM_2
      007123 ED               [12] 3598 	mov	a,r5
      007124 F0               [24] 3599 	movx	@dptr,a
      007125 EE               [12] 3600 	mov	a,r6
      007126 A3               [24] 3601 	inc	dptr
      007127 F0               [24] 3602 	movx	@dptr,a
      007128 90 08 55         [24] 3603 	mov	dptr,#_ak820_usb_send_PARM_3
      00712B EC               [12] 3604 	mov	a,r4
      00712C F0               [24] 3605 	movx	@dptr,a
      00712D 8F 82            [24] 3606 	mov	dpl, r7
      00712F 12 6F 28         [24] 3607 	lcall	_ak820_usb_send
      007132 E5 82            [12] 3608 	mov	a, dpl
      007134 90 08 5C         [24] 3609 	mov	dptr,#_ak820_usb_try_send_sent_10000_446
      007137 F0               [24] 3610 	movx	@dptr,a
      007138                       3611 00102$:
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3613 ;	assignBit
      007138 A2 1E            [12] 3614 	mov	c,_ak820_usb_try_send_sloc0_1_0
      00713A 92 AF            [24] 3615 	mov	_EA,c
                                   3616 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      00713C 90 08 5C         [24] 3617 	mov	dptr,#_ak820_usb_try_send_sent_10000_446
      00713F E0               [24] 3618 	movx	a,@dptr
                                   3619 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      007140 F5 82            [12] 3620 	mov	dpl,a
      007142 22               [24] 3621 	ret
                                   3622 ;------------------------------------------------------------
                                   3623 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3624 ;------------------------------------------------------------
                                   3625 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3626 ;	-----------------------------------------
                                   3627 ;	 function raw_request_is_nonpersistent
                                   3628 ;	-----------------------------------------
      007143                       3629 _raw_request_is_nonpersistent:
                                   3630 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      007143 90 07 F0         [24] 3631 	mov	dptr,#_raw_buffer
      007146 E0               [24] 3632 	movx	a,@dptr
      007147 FF               [12] 3633 	mov	r7,a
      007148 BF 01 02         [24] 3634 	cjne	r7,#0x01,00302$
      00714B 80 35            [24] 3635 	sjmp	00108$
      00714D                       3636 00302$:
      00714D BF 02 02         [24] 3637 	cjne	r7,#0x02,00303$
      007150 80 34            [24] 3638 	sjmp	00109$
      007152                       3639 00303$:
      007152 BF 04 02         [24] 3640 	cjne	r7,#0x04,00304$
      007155 80 2B            [24] 3641 	sjmp	00108$
      007157                       3642 00304$:
      007157 BF 08 02         [24] 3643 	cjne	r7,#0x08,00305$
      00715A 80 47            [24] 3644 	sjmp	00116$
      00715C                       3645 00305$:
      00715C BF 0B 02         [24] 3646 	cjne	r7,#0x0b,00306$
      00715F 80 21            [24] 3647 	sjmp	00108$
      007161                       3648 00306$:
      007161 BF 0C 02         [24] 3649 	cjne	r7,#0x0c,00307$
      007164 80 1C            [24] 3650 	sjmp	00108$
      007166                       3651 00307$:
      007166 BF 0D 02         [24] 3652 	cjne	r7,#0x0d,00308$
      007169 80 17            [24] 3653 	sjmp	00108$
      00716B                       3654 00308$:
      00716B BF 0E 02         [24] 3655 	cjne	r7,#0x0e,00309$
      00716E 80 12            [24] 3656 	sjmp	00108$
      007170                       3657 00309$:
      007170 BF 11 02         [24] 3658 	cjne	r7,#0x11,00310$
      007173 80 0D            [24] 3659 	sjmp	00108$
      007175                       3660 00310$:
      007175 BF 12 02         [24] 3661 	cjne	r7,#0x12,00311$
      007178 80 08            [24] 3662 	sjmp	00108$
      00717A                       3663 00311$:
      00717A BF FE 02         [24] 3664 	cjne	r7,#0xfe,00312$
      00717D 80 46            [24] 3665 	sjmp	00124$
      00717F                       3666 00312$:
      00717F 02 72 1A         [24] 3667 	ljmp	00144$
                                   3668 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      007182                       3669 00108$:
                                   3670 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      007182 75 82 01         [24] 3671 	mov	dpl, #0x01
      007185 22               [24] 3672 	ret
                                   3673 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      007186                       3674 00109$:
                                   3675 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      007186 12 74 6E         [24] 3676 	lcall	_ak820_outline_0169
      007189 BF 01 02         [24] 3677 	cjne	r7,#0x01,00313$
      00718C 80 0D            [24] 3678 	sjmp	00113$
      00718E                       3679 00313$:
      00718E BF 02 02         [24] 3680 	cjne	r7,#0x02,00314$
      007191 80 08            [24] 3681 	sjmp	00113$
      007193                       3682 00314$:
      007193 BF 03 02         [24] 3683 	cjne	r7,#0x03,00315$
      007196 80 03            [24] 3684 	sjmp	00113$
      007198                       3685 00315$:
      007198 BF 04 04         [24] 3686 	cjne	r7,#0x04,00114$
                                   3687 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      00719B                       3688 00113$:
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      00719B 75 82 01         [24] 3690 	mov	dpl, #0x01
      00719E 22               [24] 3691 	ret
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      00719F                       3693 00114$:
      00719F 75 82 00         [24] 3694 	mov	dpl, #0x00
      0071A2 22               [24] 3695 	ret
                                   3696 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      0071A3                       3697 00116$:
                                   3698 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      0071A3 12 74 6E         [24] 3699 	lcall	_ak820_outline_0169
      0071A6 BF 40 02         [24] 3700 	cjne	r7,#0x40,00318$
      0071A9 80 12            [24] 3701 	sjmp	00121$
      0071AB                       3702 00318$:
      0071AB BF 41 02         [24] 3703 	cjne	r7,#0x41,00319$
      0071AE 80 0D            [24] 3704 	sjmp	00121$
      0071B0                       3705 00319$:
      0071B0 BF 42 02         [24] 3706 	cjne	r7,#0x42,00320$
      0071B3 80 08            [24] 3707 	sjmp	00121$
      0071B5                       3708 00320$:
      0071B5 BF 43 02         [24] 3709 	cjne	r7,#0x43,00321$
      0071B8 80 03            [24] 3710 	sjmp	00121$
      0071BA                       3711 00321$:
      0071BA BF 44 04         [24] 3712 	cjne	r7,#0x44,00122$
                                   3713 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      0071BD                       3714 00121$:
                                   3715 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      0071BD 75 82 01         [24] 3716 	mov	dpl, #0x01
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      0071C0 22               [24] 3718 	ret
      0071C1                       3719 00122$:
      0071C1 75 82 00         [24] 3720 	mov	dpl, #0x00
                                   3721 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      0071C4 22               [24] 3722 	ret
      0071C5                       3723 00124$:
                                   3724 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      0071C5 12 74 6E         [24] 3725 	lcall	_ak820_outline_0169
      0071C8 24 F2            [12] 3726 	add	a,#0xff - 0x0d
      0071CA 40 4A            [24] 3727 	jc	00142$
                                   3728 ;	free result
      0071CC EF               [12] 3729 	mov	a,r7
      0071CD 24 0A            [12] 3730 	add	a,#(00325$-3-.)
      0071CF 83               [24] 3731 	movc	a,@a+pc
      0071D0 F5 82            [12] 3732 	mov	dpl,a
      0071D2 EF               [12] 3733 	mov	a,r7
      0071D3 24 12            [12] 3734 	add	a,#(00326$-3-.)
      0071D5 83               [24] 3735 	movc	a,@a+pc
      0071D6 F5 83            [12] 3736 	mov	dph,a
      0071D8 E4               [12] 3737 	clr	a
      0071D9 73               [24] 3738 	jmp	@a+dptr
      0071DA                       3739 00325$:
      0071DA F6                    3740 	.db	00134$
      0071DB F6                    3741 	.db	00134$
      0071DC F6                    3742 	.db	00134$
      0071DD F6                    3743 	.db	00134$
      0071DE 16                    3744 	.db	00142$
      0071DF F6                    3745 	.db	00134$
      0071E0 F6                    3746 	.db	00134$
      0071E1 F6                    3747 	.db	00134$
      0071E2 F6                    3748 	.db	00134$
      0071E3 F6                    3749 	.db	00134$
      0071E4 F6                    3750 	.db	00134$
      0071E5 16                    3751 	.db	00142$
      0071E6 16                    3752 	.db	00142$
      0071E7 FA                    3753 	.db	00135$
      0071E8                       3754 00326$:
      0071E8 71                    3755 	.db	00134$>>8
      0071E9 71                    3756 	.db	00134$>>8
      0071EA 71                    3757 	.db	00134$>>8
      0071EB 71                    3758 	.db	00134$>>8
      0071EC 72                    3759 	.db	00142$>>8
      0071ED 71                    3760 	.db	00134$>>8
      0071EE 71                    3761 	.db	00134$>>8
      0071EF 71                    3762 	.db	00134$>>8
      0071F0 71                    3763 	.db	00134$>>8
      0071F1 71                    3764 	.db	00134$>>8
      0071F2 71                    3765 	.db	00134$>>8
      0071F3 72                    3766 	.db	00142$>>8
      0071F4 72                    3767 	.db	00142$>>8
      0071F5 71                    3768 	.db	00135$>>8
                                   3769 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      0071F6                       3770 00134$:
                                   3771 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      0071F6 75 82 01         [24] 3772 	mov	dpl, #0x01
                                   3773 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      0071F9 22               [24] 3774 	ret
      0071FA                       3775 00135$:
                                   3776 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      0071FA 90 07 F2         [24] 3777 	mov	dptr,#(_raw_buffer + 0x0002)
      0071FD E0               [24] 3778 	movx	a,@dptr
      0071FE FF               [12] 3779 	mov	r7,a
      0071FF 60 0D            [24] 3780 	jz	00139$
      007201 BF 01 02         [24] 3781 	cjne	r7,#0x01,00328$
      007204 80 08            [24] 3782 	sjmp	00139$
      007206                       3783 00328$:
      007206 BF 03 02         [24] 3784 	cjne	r7,#0x03,00329$
      007209 80 03            [24] 3785 	sjmp	00139$
      00720B                       3786 00329$:
      00720B BF 05 04         [24] 3787 	cjne	r7,#0x05,00140$
                                   3788 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      00720E                       3789 00139$:
                                   3790 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      00720E 75 82 01         [24] 3791 	mov	dpl, #0x01
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      007211 22               [24] 3793 	ret
      007212                       3794 00140$:
      007212 75 82 00         [24] 3795 	mov	dpl, #0x00
                                   3796 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      007215 22               [24] 3797 	ret
      007216                       3798 00142$:
      007216 75 82 00         [24] 3799 	mov	dpl, #0x00
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      007219 22               [24] 3801 	ret
      00721A                       3802 00144$:
      00721A 75 82 00         [24] 3803 	mov	dpl, #0x00
                                   3804 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3805 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      00721D 22               [24] 3806 	ret
                                   3807 ;------------------------------------------------------------
                                   3808 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3809 ;------------------------------------------------------------
                                   3810 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3811 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_461'
                                   3812 ;------------------------------------------------------------
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3814 ;	-----------------------------------------
                                   3815 ;	 function ak820_usb_raw_send
                                   3816 ;	-----------------------------------------
      00721E                       3817 _ak820_usb_raw_send:
      00721E 12 48 A0         [24] 3818 	lcall	_ak820_outline_0036
      007221 90 08 5E         [24] 3819 	mov	dptr,#_ak820_usb_raw_send_report_10000_461
      007224 12 3A 5F         [24] 3820 	lcall	_ak820_outline_0016
                                   3821 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      007227 90 08 5D         [24] 3822 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      00722A E0               [24] 3823 	movx	a,@dptr
      00722B FF               [12] 3824 	mov	r7,a
      00722C BF 20 2B         [24] 3825 	cjne	r7,#0x20,00106$
                                   3826 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      00722F C0 07            [24] 3827 	push	ar7
      007231 12 43 B6         [24] 3828 	lcall	_ak820_nvm_flush
      007234 D0 07            [24] 3829 	pop	ar7
                                   3830 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      007236 90 08 10         [24] 3831 	mov	dptr,#_raw_reply_without_nvm
      007239 E0               [24] 3832 	movx	a,@dptr
      00723A 70 07            [24] 3833 	jnz	00103$
      00723C 12 43 A7         [24] 3834 	lcall	_ak820_nvm_ok
      00723F E5 82            [12] 3835 	mov	a, dpl
      007241 60 17            [24] 3836 	jz	00106$
      007243                       3837 00103$:
      007243 90 08 5E         [24] 3838 	mov	dptr,#_ak820_usb_raw_send_report_10000_461
      007246 12 3A A4         [24] 3839 	lcall	_ak820_outline_0080
      007249 90 08 53         [24] 3840 	mov	dptr,#_ak820_usb_send_PARM_2
      00724C 12 49 0A         [24] 3841 	lcall	_ak820_outline_0167
      00724F 90 08 55         [24] 3842 	mov	dptr,#_ak820_usb_send_PARM_3
      007252 EF               [12] 3843 	mov	a,r7
      007253 F0               [24] 3844 	movx	@dptr,a
      007254 75 82 03         [24] 3845 	mov	dpl, #0x03
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      007257 02 6F 28         [24] 3847 	ljmp	_ak820_usb_send
      00725A                       3848 00106$:
      00725A 22               [24] 3849 	ret
                                   3850 ;------------------------------------------------------------
                                   3851 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3852 ;------------------------------------------------------------
                                   3853 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3854 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_466'
                                   3855 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_466'
                                   3856 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_466'
                                   3857 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_466'
                                   3858 ;------------------------------------------------------------
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3860 ;	-----------------------------------------
                                   3861 ;	 function ak820_usb_raw_task
                                   3862 ;	-----------------------------------------
      00725B                       3863 _ak820_usb_raw_task:
                                   3864 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      00725B A2 AF            [12] 3865 	mov	c,_EA
      00725D E4               [12] 3866 	clr	a
      00725E 33               [12] 3867 	rlc	a
      00725F FF               [12] 3868 	mov	r7,a
                                   3869 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3870 ;	assignBit
      007260 C2 AF            [12] 3871 	clr	_EA
                                   3872 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      007262 90 07 E8         [24] 3873 	mov	dptr,#_USB_EnumStatus
      007265 E0               [24] 3874 	movx	a,@dptr
      007266 60 0A            [24] 3875 	jz	00101$
      007268 90 07 EF         [24] 3876 	mov	dptr,#_raw_state
      00726B E0               [24] 3877 	movx	a,@dptr
      00726C FE               [12] 3878 	mov	r6,a
      00726D BE 02 02         [24] 3879 	cjne	r6,#0x02,00270$
      007270 80 06            [24] 3880 	sjmp	00102$
      007272                       3881 00270$:
      007272                       3882 00101$:
                                   3883 ;	assignBit
      007272 EF               [12] 3884 	mov	a,r7
      007273 24 FF            [12] 3885 	add	a,#0xff
      007275 92 AF            [24] 3886 	mov	_EA,c
      007277 22               [24] 3887 	ret
      007278                       3888 00102$:
                                   3889 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      007278 90 07 EF         [24] 3890 	mov	dptr,#_raw_state
      00727B 74 03            [12] 3891 	mov	a,#0x03
      00727D F0               [24] 3892 	movx	@dptr,a
                                   3893 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3894 ;	assignBit
      00727E EF               [12] 3895 	mov	a,r7
      00727F 24 FF            [12] 3896 	add	a,#0xff
      007281 92 AF            [24] 3897 	mov	_EA,c
                                   3898 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      007283 90 07 F0         [24] 3899 	mov	dptr,#_raw_buffer
      007286 E0               [24] 3900 	movx	a,@dptr
      007287 FF               [12] 3901 	mov	r7,a
      007288 E4               [12] 3902 	clr	a
      007289 BF FD 01         [24] 3903 	cjne	r7,#0xfd,00271$
      00728C 04               [12] 3904 	inc	a
      00728D                       3905 00271$:
      00728D FF               [12] 3906 	mov	r7,a
      00728E 70 03            [24] 3907 	jnz	00273$
      007290 02 73 30         [24] 3908 	ljmp	00118$
      007293                       3909 00273$:
      007293 90 07 F1         [24] 3910 	mov	dptr,#(_raw_buffer + 0x0001)
      007296 E0               [24] 3911 	movx	a,@dptr
      007297 60 03            [24] 3912 	jz	00274$
      007299 02 73 30         [24] 3913 	ljmp	00118$
      00729C                       3914 00274$:
                                   3915 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      00729C 90 07 F2         [24] 3916 	mov	dptr,#(_raw_buffer + 0x0002)
      00729F E0               [24] 3917 	movx	a,@dptr
      0072A0 FD               [12] 3918 	mov	r5,a
      0072A1 7E 00            [12] 3919 	mov	r6,#0x00
      0072A3 90 07 F3         [24] 3920 	mov	dptr,#(_raw_buffer + 0x0003)
      0072A6 E0               [24] 3921 	movx	a,@dptr
      0072A7 7B 00            [12] 3922 	mov	r3,#0x00
      0072A9 42 06            [12] 3923 	orl	ar6,a
      0072AB EB               [12] 3924 	mov	a,r3
      0072AC 42 05            [12] 3925 	orl	ar5,a
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      0072AE 90 07 F4         [24] 3927 	mov	dptr,#(_raw_buffer + 0x0004)
      0072B1 E0               [24] 3928 	movx	a,@dptr
      0072B2 FC               [12] 3929 	mov	r4,a
                                   3930 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0072B3 7B 05            [12] 3931 	mov	r3,#0x05
      0072B5                       3932 00128$:
      0072B5 EB               [12] 3933 	mov	a,r3
      0072B6 12 74 5C         [24] 3934 	lcall	_ak820_outline_0107
      0072B9 0B               [12] 3935 	inc	r3
      0072BA BB 20 00         [24] 3936 	cjne	r3,#0x20,00275$
      0072BD                       3937 00275$:
      0072BD 40 F6            [24] 3938 	jc	00128$
                                   3939 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      0072BF EC               [12] 3940 	mov	a,r4
      0072C0 24 E4            [12] 3941 	add	a,#0xff - 0x1b
      0072C2 40 1C            [24] 3942 	jc	00106$
                                   3943 ;	free result
      0072C4 EC               [12] 3944 	mov	a,r4
      0072C5 60 26            [24] 3945 	jz	00165$
      0072C7 8C 03            [24] 3946 	mov	ar3,r4
      0072C9 1B               [12] 3947 	dec	r3
      0072CA 7A 00            [12] 3948 	mov	r2,#0x00
      0072CC 74 FF            [12] 3949 	mov	a,#0xff
      0072CE C3               [12] 3950 	clr	c
      0072CF 9B               [12] 3951 	subb	a,r3
      0072D0 FB               [12] 3952 	mov	r3,a
      0072D1 74 FF            [12] 3953 	mov	a,#0xff
      0072D3 9A               [12] 3954 	subb	a,r2
      0072D4 FA               [12] 3955 	mov	r2,a
      0072D5 8E 00            [24] 3956 	mov	ar0,r6
      0072D7 8D 01            [24] 3957 	mov	ar1,r5
      0072D9 C3               [12] 3958 	clr	c
      0072DA EB               [12] 3959 	mov	a,r3
      0072DB 98               [12] 3960 	subb	a,r0
      0072DC EA               [12] 3961 	mov	a,r2
      0072DD 99               [12] 3962 	subb	a,r1
      0072DE 50 0D            [24] 3963 	jnc	00165$
                                   3964 ;	free result
      0072E0                       3965 00106$:
                                   3966 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      0072E0 90 07 F1         [24] 3967 	mov	dptr,#(_raw_buffer + 0x0001)
      0072E3 74 FF            [12] 3968 	mov	a,#0xff
      0072E5 F0               [24] 3969 	movx	@dptr,a
                                   3970 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      0072E6 90 07 F4         [24] 3971 	mov	dptr,#(_raw_buffer + 0x0004)
      0072E9 E4               [12] 3972 	clr	a
      0072EA F0               [24] 3973 	movx	@dptr,a
                                   3974 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      0072EB 80 3A            [24] 3975 	sjmp	00108$
      0072ED                       3976 00165$:
      0072ED 7B 00            [12] 3977 	mov	r3,#0x00
      0072EF                       3978 00131$:
      0072EF C3               [12] 3979 	clr	c
      0072F0 EB               [12] 3980 	mov	a,r3
      0072F1 9C               [12] 3981 	subb	a,r4
      0072F2 50 33            [24] 3982 	jnc	00108$
      0072F4 C0 04            [24] 3983 	push	ar4
      0072F6 8B 02            [24] 3984 	mov	ar2,r3
      0072F8 74 05            [12] 3985 	mov	a,#0x05
      0072FA 2A               [12] 3986 	add	a, r2
      0072FB F9               [12] 3987 	mov	r1,a
      0072FC 33               [12] 3988 	rlc	a
      0072FD 95 E0            [12] 3989 	subb	a,acc
      0072FF FA               [12] 3990 	mov	r2,a
      007300 E9               [12] 3991 	mov	a,r1
      007301 24 F0            [12] 3992 	add	a, #_raw_buffer
      007303 F9               [12] 3993 	mov	r1,a
      007304 EA               [12] 3994 	mov	a,r2
      007305 34 07            [12] 3995 	addc	a, #(_raw_buffer >> 8)
      007307 FA               [12] 3996 	mov	r2,a
      007308 8B 1E            [24] 3997 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      00730A 75 1F 00         [24] 3998 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      00730D 8E 00            [24] 3999 	mov	ar0,r6
      00730F 8D 04            [24] 4000 	mov	ar4,r5
      007311 E5 1E            [12] 4001 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      007313 28               [12] 4002 	add	a, r0
      007314 F8               [12] 4003 	mov	r0,a
      007315 E5 1F            [12] 4004 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      007317 3C               [12] 4005 	addc	a, r4
      007318 FC               [12] 4006 	mov	r4,a
      007319 88 82            [24] 4007 	mov	dpl,r0
      00731B 8C 83            [24] 4008 	mov	dph,r4
      00731D E4               [12] 4009 	clr	a
      00731E 93               [24] 4010 	movc	a,@a+dptr
      00731F 12 74 68         [24] 4011 	lcall	_ak820_outline_0141
      007322 0B               [12] 4012 	inc	r3
      007323 D0 04            [24] 4013 	pop	ar4
      007325 80 C8            [24] 4014 	sjmp	00131$
      007327                       4015 00108$:
                                   4016 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007327 12 74 48         [24] 4017 	lcall	_ak820_outline_0045
      00732A 12 6F 28         [24] 4018 	lcall	_ak820_usb_send
      00732D 02 73 D6         [24] 4019 	ljmp	00119$
      007330                       4020 00118$:
                                   4021 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      007330 EF               [12] 4022 	mov	a,r7
      007331 70 03            [24] 4023 	jnz	00281$
      007333 02 73 B3         [24] 4024 	ljmp	00114$
      007336                       4025 00281$:
      007336 12 74 6E         [24] 4026 	lcall	_ak820_outline_0169
      007339 BF 01 02         [24] 4027 	cjne	r7,#0x01,00282$
      00733C 80 03            [24] 4028 	sjmp	00283$
      00733E                       4029 00282$:
      00733E 02 73 B3         [24] 4030 	ljmp	00114$
      007341                       4031 00283$:
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      007341 7F 02            [12] 4033 	mov	r7,#0x02
      007343                       4034 00133$:
      007343 EF               [12] 4035 	mov	a,r7
      007344 12 74 5C         [24] 4036 	lcall	_ak820_outline_0107
      007347 0F               [12] 4037 	inc	r7
      007348 BF 20 00         [24] 4038 	cjne	r7,#0x20,00284$
      00734B                       4039 00284$:
      00734B 40 F6            [24] 4040 	jc	00133$
                                   4041 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      00734D 90 07 F2         [24] 4042 	mov	dptr,#(_raw_buffer + 0x0002)
      007350 74 01            [12] 4043 	mov	a,#0x01
      007352 F0               [24] 4044 	movx	@dptr,a
                                   4045 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      007353 90 07 F3         [24] 4046 	mov	dptr,#(_raw_buffer + 0x0003)
      007356 74 A8            [12] 4047 	mov	a,#0xa8
      007358 F0               [24] 4048 	movx	@dptr,a
                                   4049 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      007359 90 07 F4         [24] 4050 	mov	dptr,#(_raw_buffer + 0x0004)
      00735C 12 41 24         [24] 4051 	lcall	_ak820_nvm_diagnostic
                                   4052 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      00735F 7F 00            [12] 4053 	mov	r7,#0x00
      007361                       4054 00135$:
      007361 8F 06            [24] 4055 	mov	ar6,r7
      007363 74 0B            [12] 4056 	mov	a,#0x0b
      007365 2E               [12] 4057 	add	a, r6
      007366 24 F0            [12] 4058 	add	a,#_raw_buffer
      007368 FE               [12] 4059 	mov	r6,a
      007369 E4               [12] 4060 	clr	a
      00736A 34 07            [12] 4061 	addc	a, #(_raw_buffer >> 8)
      00736C FD               [12] 4062 	mov	r5,a
      00736D EF               [12] 4063 	mov	a,r7
      00736E 24 CA            [12] 4064 	add	a, #_ak820_flash_diagnostic
      007370 F5 82            [12] 4065 	mov	dpl,a
      007372 E4               [12] 4066 	clr	a
      007373 34 04            [12] 4067 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007375 F5 83            [12] 4068 	mov	dph,a
      007377 E0               [24] 4069 	movx	a,@dptr
      007378 8E 82            [24] 4070 	mov	dpl,r6
      00737A 8D 83            [24] 4071 	mov	dph,r5
      00737C F0               [24] 4072 	movx	@dptr,a
      00737D 0F               [12] 4073 	inc	r7
      00737E BF 06 00         [24] 4074 	cjne	r7,#0x06,00286$
      007381                       4075 00286$:
      007381 40 DE            [24] 4076 	jc	00135$
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      007383 90 0E A9         [24] 4078 	mov	dptr,#_vial_unlocked
      007386 E0               [24] 4079 	movx	a,@dptr
      007387 90 08 01         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0011)
      00738A F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      00738B 90 0E AA         [24] 4083 	mov	dptr,#_vial_unlock_in_progress
      00738E E0               [24] 4084 	movx	a,@dptr
      00738F 90 08 02         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0012)
      007392 F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      007393 90 07 E8         [24] 4088 	mov	dptr,#_USB_EnumStatus
      007396 E0               [24] 4089 	movx	a,@dptr
      007397 90 08 03         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0013)
      00739A F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      00739B 90 07 E9         [24] 4093 	mov	dptr,#_USB_SleepStatus
      00739E E0               [24] 4094 	movx	a,@dptr
      00739F 90 08 04         [24] 4095 	mov	dptr,#(_raw_buffer + 0x0014)
      0073A2 F0               [24] 4096 	movx	@dptr,a
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      0073A3 90 07 EF         [24] 4098 	mov	dptr,#_raw_state
      0073A6 E0               [24] 4099 	movx	a,@dptr
      0073A7 90 08 05         [24] 4100 	mov	dptr,#(_raw_buffer + 0x0015)
      0073AA F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0073AB 12 74 48         [24] 4103 	lcall	_ak820_outline_0045
      0073AE 12 6F 28         [24] 4104 	lcall	_ak820_usb_send
      0073B1 80 23            [24] 4105 	sjmp	00119$
      0073B3                       4106 00114$:
                                   4107 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      0073B3 12 71 43         [24] 4108 	lcall	_raw_request_is_nonpersistent
      0073B6 E5 82            [12] 4109 	mov	a, dpl
      0073B8 90 08 10         [24] 4110 	mov	dptr,#_raw_reply_without_nvm
      0073BB F0               [24] 4111 	movx	@dptr,a
                                   4112 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      0073BC 12 45 09         [24] 4113 	lcall	_ak820_nvm_begin
                                   4114 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      0073BF 90 0C DA         [24] 4115 	mov	dptr,#_raw_hid_receive_PARM_2
      0073C2 74 20            [12] 4116 	mov	a,#0x20
      0073C4 F0               [24] 4117 	movx	@dptr,a
      0073C5 90 07 F0         [24] 4118 	mov	dptr,#_raw_buffer
      0073C8 75 F0 00         [24] 4119 	mov	b, #0x00
      0073CB 12 AF 50         [24] 4120 	lcall	_raw_hid_receive
                                   4121 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      0073CE 12 45 1E         [24] 4122 	lcall	_ak820_nvm_end
                                   4123 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      0073D1 90 08 10         [24] 4124 	mov	dptr,#_raw_reply_without_nvm
      0073D4 E4               [12] 4125 	clr	a
      0073D5 F0               [24] 4126 	movx	@dptr,a
      0073D6                       4127 00119$:
                                   4128 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4129 ;	assignBit
      0073D6 A2 AF            [12] 4130 	mov	c,_EA
      0073D8 92 1F            [24] 4131 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4132 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4133 ;	assignBit
      0073DA C2 AF            [12] 4134 	clr	_EA
                                   4135 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0073DC 12 74 74         [24] 4136 	lcall	_ak820_outline_0171
      0073DF BF 04 08         [24] 4137 	cjne	r7,#0x04,00126$
      0073E2 90 07 EF         [24] 4138 	mov	dptr,#_raw_state
      0073E5 74 05            [12] 4139 	mov	a,#0x05
      0073E7 F0               [24] 4140 	movx	@dptr,a
      0073E8 80 1B            [24] 4141 	sjmp	00127$
      0073EA                       4142 00126$:
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      0073EA 12 74 74         [24] 4144 	lcall	_ak820_outline_0171
      0073ED BF 03 02         [24] 4145 	cjne	r7,#0x03,00290$
      0073F0 80 0E            [24] 4146 	sjmp	00121$
      0073F2                       4147 00290$:
      0073F2 12 74 74         [24] 4148 	lcall	_ak820_outline_0171
      0073F5 BF 06 02         [24] 4149 	cjne	r7,#0x06,00291$
      0073F8 80 06            [24] 4150 	sjmp	00121$
      0073FA                       4151 00291$:
      0073FA 12 74 74         [24] 4152 	lcall	_ak820_outline_0171
      0073FD BF 07 05         [24] 4153 	cjne	r7,#0x07,00127$
      007400                       4154 00121$:
      007400 90 07 EF         [24] 4155 	mov	dptr,#_raw_state
      007403 E4               [12] 4156 	clr	a
      007404 F0               [24] 4157 	movx	@dptr,a
      007405                       4158 00127$:
                                   4159 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4160 ;	assignBit
      007405 A2 1F            [12] 4161 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007407 92 AF            [24] 4162 	mov	_EA,c
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      007409 22               [24] 4164 	ret
                                   4165 ;------------------------------------------------------------
                                   4166 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4167 ;------------------------------------------------------------
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:665: bool ak820_usb_keyboard_blocked(void) {
                                   4169 ;	-----------------------------------------
                                   4170 ;	 function ak820_usb_keyboard_blocked
                                   4171 ;	-----------------------------------------
      00740A                       4172 _ak820_usb_keyboard_blocked:
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:666: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      00740A 90 07 E8         [24] 4174 	mov	dptr,#_USB_EnumStatus
      00740D E0               [24] 4175 	movx	a,@dptr
      00740E 60 13            [24] 4176 	jz	00104$
      007410 90 07 E9         [24] 4177 	mov	dptr,#_USB_SleepStatus
      007413 E0               [24] 4178 	movx	a,@dptr
      007414 03               [12] 4179 	rr	a
      007415 54 01            [12] 4180 	anl	a,#0x01
      007417 70 0A            [24] 4181 	jnz	00104$
      007419 90 08 11         [24] 4182 	mov	dptr,#_keyboard_reset
      00741C E0               [24] 4183 	movx	a,@dptr
      00741D 70 04            [24] 4184 	jnz	00104$
                                   4185 ;	assignBit
      00741F C2 20            [12] 4186 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      007421 80 02            [24] 4187 	sjmp	00105$
      007423                       4188 00104$:
                                   4189 ;	assignBit
      007423 D2 20            [12] 4190 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      007425                       4191 00105$:
      007425 A2 20            [12] 4192 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      007427 E4               [12] 4193 	clr	a
      007428 33               [12] 4194 	rlc	a
      007429 F5 82            [12] 4195 	mov	dpl, a
                                   4196 ;	tmk_core/protocol/ch555/usb_ak820.c:667: }
      00742B 22               [24] 4197 	ret
                                   4198 ;------------------------------------------------------------
                                   4199 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4200 ;------------------------------------------------------------
                                   4201 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_486'
                                   4202 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_486'
                                   4203 ;------------------------------------------------------------
                                   4204 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4205 ;	-----------------------------------------
                                   4206 ;	 function ak820_usb_take_keyboard_reset
                                   4207 ;	-----------------------------------------
      00742C                       4208 _ak820_usb_take_keyboard_reset:
                                   4209 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4210 ;	assignBit
      00742C A2 AF            [12] 4211 	mov	c,_EA
      00742E 92 21            [24] 4212 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4213 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4214 ;	assignBit
      007430 C2 AF            [12] 4215 	clr	_EA
                                   4216 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      007432 90 08 11         [24] 4217 	mov	dptr,#_keyboard_reset
      007435 E0               [24] 4218 	movx	a,@dptr
      007436 FF               [12] 4219 	mov	r7,a
                                   4220 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      007437 E4               [12] 4221 	clr	a
      007438 F0               [24] 4222 	movx	@dptr,a
                                   4223 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4224 ;	assignBit
      007439 A2 21            [12] 4225 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      00743B 92 AF            [24] 4226 	mov	_EA,c
                                   4227 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      00743D EF               [12] 4228 	mov	a,r7
      00743E B4 01 00         [24] 4229 	cjne	a,#0x01,00103$
      007441                       4230 00103$:
      007441 B3               [12] 4231 	cpl	c
      007442 92 21            [24] 4232 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007444 12 3A F6         [24] 4233 	lcall	_ak820_outline_0162
                                   4234 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      007447 22               [24] 4235 	ret
                                   4236 	.area CSEG    (CODE)
                                   4237 	.area CONST   (CODE)
                                   4238 	.area CONST   (CODE)
      00C1E5                       4239 _shared_offsets:
      00C1E5 00                    4240 	.db #0x00	; 0
      00C1E6 00                    4241 	.db #0x00	; 0
      00C1E7 28                    4242 	.db #0x28	; 40
      00C1E8 2E                    4243 	.db #0x2e	; 46
      00C1E9 31                    4244 	.db #0x31	; 49	'1'
      00C1EA 00                    4245 	.db #0x00	; 0
      00C1EB 08                    4246 	.db #0x08	; 8
                                   4247 	.area CSEG    (CODE)
                                   4248 	.area CONST   (CODE)
      00C1EC                       4249 _shared_lengths:
      00C1EC 00                    4250 	.db #0x00	; 0
      00C1ED 00                    4251 	.db #0x00	; 0
      00C1EE 06                    4252 	.db #0x06	; 6
      00C1EF 03                    4253 	.db #0x03	; 3
      00C1F0 03                    4254 	.db #0x03	; 3
      00C1F1 00                    4255 	.db #0x00	; 0
      00C1F2 20                    4256 	.db #0x20	; 32
                                   4257 	.area CSEG    (CODE)
                                   4258 	.area CONST   (CODE)
      00C1F3                       4259 _interface_descriptors:
      00C1F3 96 C7                 4260 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00C1F5 DF C8                 4261 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00C1F7 92 C8                 4262 	.byte _RawReport, (_RawReport >> 8)
      00C1F9 F8 C8                 4263 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00C1FB DB C7                 4264 	.byte _SharedReport, (_SharedReport >> 8)
      00C1FD 11 C9                 4265 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4266 	.area CSEG    (CODE)
                                   4267 	.area XINIT   (CODE)
                                   4268 	.area CABS    (ABS,CODE)
                                   4269 
                                   4270 ; Experimental exact instruction outlining.
                                   4271 	.globl _ak820_outline_0016
                                   4272 	.globl _ak820_outline_0036
                                   4273 	.globl _ak820_outline_0045
                                   4274 	.globl _ak820_outline_0080
                                   4275 	.globl _ak820_outline_0107
                                   4276 	.globl _ak820_outline_0141
                                   4277 	.globl _ak820_outline_0162
                                   4278 	.globl _ak820_outline_0167
                                   4279 	.globl _ak820_outline_0169
                                   4280 	.globl _ak820_outline_0171
                                   4281 
                                   4282 	.area CSEG (CODE)
                                   4283 ; function ak820_outline_0045
      007448                       4284 _ak820_outline_0045:
      007448 90 08 53         [24] 4285 	mov	dptr,#_ak820_usb_send_PARM_2
      00744B 74 F0            [12] 4286 	mov	a,#_raw_buffer
      00744D F0               [24] 4287 	movx	@dptr,a
      00744E 74 07            [12] 4288 	mov	a,#(_raw_buffer>>8)
      007450 A3               [24] 4289 	inc	dptr
      007451 F0               [24] 4290 	movx	@dptr,a
      007452 90 08 55         [24] 4291 	mov	dptr,#_ak820_usb_send_PARM_3
      007455 74 20            [12] 4292 	mov	a,#0x20
      007457 F0               [24] 4293 	movx	@dptr,a
      007458 75 82 03         [24] 4294 	mov	dpl,#0x03
      00745B 22               [24] 4295 	ret
                                   4296 
                                   4297 	.area CSEG (CODE)
                                   4298 ; function ak820_outline_0107
      00745C                       4299 _ak820_outline_0107:
      00745C 24 F0            [12] 4300 	add	a,#_raw_buffer
      00745E F5 82            [12] 4301 	mov	dpl,a
      007460 E4               [12] 4302 	clr	a
      007461 34 07            [12] 4303 	addc	a,#(_raw_buffer>>8)
      007463 F5 83            [12] 4304 	mov	dph,a
      007465 E4               [12] 4305 	clr	a
      007466 F0               [24] 4306 	movx	@dptr,a
      007467 22               [24] 4307 	ret
                                   4308 
                                   4309 	.area CSEG (CODE)
                                   4310 ; function ak820_outline_0141
      007468                       4311 _ak820_outline_0141:
      007468 89 82            [24] 4312 	mov	dpl,r1
      00746A 8A 83            [24] 4313 	mov	dph,r2
      00746C F0               [24] 4314 	movx	@dptr,a
      00746D 22               [24] 4315 	ret
                                   4316 
                                   4317 	.area CSEG (CODE)
                                   4318 ; function ak820_outline_0169
      00746E                       4319 _ak820_outline_0169:
      00746E 90 07 F1         [24] 4320 	mov	dptr,#(_raw_buffer+0x0001)
      007471 E0               [24] 4321 	movx	a,@dptr
      007472 FF               [12] 4322 	mov	r7,a
      007473 22               [24] 4323 	ret
                                   4324 
                                   4325 	.area CSEG (CODE)
                                   4326 ; function ak820_outline_0171
      007474                       4327 _ak820_outline_0171:
      007474 90 07 EF         [24] 4328 	mov	dptr,#_raw_state
      007477 E0               [24] 4329 	movx	a,@dptr
      007478 FF               [12] 4330 	mov	r7,a
      007479 22               [24] 4331 	ret
