                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000013                        595 _suspended:
      000013                        596 	.ds 1
      000014                        597 _dirty:
      000014                        598 	.ds 1
      000015                        599 _rendering:
      000015                        600 	.ds 1
      000016                        601 _rgb_matrix_task_sloc0_1_0:
      000016                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      000727                        611 _rgb_matrix_config::
      000727                        612 	.ds 8
      00072F                        613 _changed_at:
      00072F                        614 	.ds 2
      000731                        615 _frame_at:
      000731                        616 	.ds 2
      000733                        617 _phase:
      000733                        618 	.ds 2
      000735                        619 _led_index:
      000735                        620 	.ds 1
      000736                        621 _frame_mode:
      000736                        622 	.ds 1
      000737                        623 _frame_hue:
      000737                        624 	.ds 1
      000738                        625 _frame_sat:
      000738                        626 	.ds 1
      000739                        627 _frame_val:
      000739                        628 	.ds 1
      00073A                        629 _frame_flags:
      00073A                        630 	.ds 1
      00073B                        631 _frame_phase:
      00073B                        632 	.ds 1
      00073C                        633 _reactive_age:
      00073C                        634 	.ds 82
      00078E                        635 _reactive_at:
      00078E                        636 	.ds 2
      000790                        637 _add_sat_PARM_2:
      000790                        638 	.ds 1
      000791                        639 _add_sat_x_10000_266:
      000791                        640 	.ds 1
      000792                        641 _sub_sat_PARM_2:
      000792                        642 	.ds 1
      000793                        643 _sub_sat_x_10000_268:
      000793                        644 	.ds 1
      000794                        645 _rgb_matrix_set_color_PARM_2:
      000794                        646 	.ds 1
      000795                        647 _rgb_matrix_set_color_PARM_3:
      000795                        648 	.ds 1
      000796                        649 _rgb_matrix_set_color_PARM_4:
      000796                        650 	.ds 1
      000797                        651 _rgb_matrix_set_color_index_10000_284:
      000797                        652 	.ds 2
      000799                        653 _rgb_matrix_set_color_all_PARM_2:
      000799                        654 	.ds 1
      00079A                        655 _rgb_matrix_set_color_all_PARM_3:
      00079A                        656 	.ds 1
      00079B                        657 _rgb_matrix_set_color_all_r_10000_287:
      00079B                        658 	.ds 1
      00079C                        659 _sine8_theta_10000_289:
      00079C                        660 	.ds 1
      00079D                        661 _sine8_offset_10000_290:
      00079D                        662 	.ds 1
      00079E                        663 _sine8_fraction_10000_290:
      00079E                        664 	.ds 1
      00079F                        665 _breathing_cie_value_10000_293:
      00079F                        666 	.ds 1
      0007A0                        667 _rgb_matrix_task_end_10000_298:
      0007A0                        668 	.ds 1
      0007A1                        669 _rgb_matrix_task_hsv_10000_298:
      0007A1                        670 	.ds 3
      0007A4                        671 _rgb_matrix_task_rgb_10000_298:
      0007A4                        672 	.ds 3
      0007A7                        673 _process_rgb_matrix_PARM_2:
      0007A7                        674 	.ds 1
      0007A8                        675 _process_rgb_matrix_PARM_3:
      0007A8                        676 	.ds 1
      0007A9                        677 _process_rgb_matrix_row_10000_319:
      0007A9                        678 	.ds 1
      0007AA                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      0007AA                        680 	.ds 1
      0007AB                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      0007AB                        682 	.ds 1
      0007AC                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      0007AC                        684 	.ds 1
      0007AD                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      0007AD                        686 	.ds 1
      0007AE                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      0007AE                        688 	.ds 2
      0007B0                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      0007B0                        690 	.ds 1
      0007B1                        691 _rgb_matrix_mode_mode_10000_411:
      0007B1                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      00576B                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      00576B 12 5F 24         [24]  746 	lcall	_ak820_outline_0181
      00576E 74 52            [12]  747 	mov	a,#0x52
      005770 12 3A DC         [24]  748 	lcall	_ak820_outline_0136
      005773 90 07 3C         [24]  749 	mov	dptr,#_reactive_age
      005776 F5 F0            [12]  750 	mov	b,a
      005778 12 C0 F0         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      00577B 12 4E B5         [24]  753 	lcall	_timer_read
      00577E 12 3A E6         [24]  754 	lcall	_ak820_outline_0140
      005781 90 07 8E         [24]  755 	mov	dptr,#_reactive_at
      005784 12 5F 10         [24]  756 	lcall	_ak820_outline_0172
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      005787 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      005788                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      005788 90 07 8E         [24]  772 	mov	dptr,#_reactive_at
      00578B 12 3A 34         [24]  773 	lcall	_ak820_outline_0005
      00578E 12 4E B8         [24]  774 	lcall	_timer_elapsed
      005791 AE 82            [24]  775 	mov	r6, dpl
      005793 E5 83            [12]  776 	mov	a,dph
      005795 C4               [12]  777 	swap	a
      005796 CE               [12]  778 	xch	a,r6
      005797 C4               [12]  779 	swap	a
      005798 54 0F            [12]  780 	anl	a,#0x0f
      00579A 6E               [12]  781 	xrl	a,r6
      00579B CE               [12]  782 	xch	a,r6
      00579C 54 0F            [12]  783 	anl	a,#0x0f
      00579E CE               [12]  784 	xch	a,r6
      00579F 6E               [12]  785 	xrl	a,r6
      0057A0 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      0057A1 FF               [12]  788 	mov	r7,a
      0057A2 4E               [12]  789 	orl	a,r6
      0057A3 70 01            [24]  790 	jnz	00102$
      0057A5 22               [24]  791 	ret
      0057A6                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      0057A6 8E 04            [24]  794 	mov	ar4,r6
      0057A8 EF               [12]  795 	mov	a,r7
      0057A9 C4               [12]  796 	swap	a
      0057AA 54 F0            [12]  797 	anl	a,#0xf0
      0057AC CC               [12]  798 	xch	a,r4
      0057AD C4               [12]  799 	swap	a
      0057AE CC               [12]  800 	xch	a,r4
      0057AF 6C               [12]  801 	xrl	a,r4
      0057B0 CC               [12]  802 	xch	a,r4
      0057B1 54 F0            [12]  803 	anl	a,#0xf0
      0057B3 CC               [12]  804 	xch	a,r4
      0057B4 6C               [12]  805 	xrl	a,r4
      0057B5 FD               [12]  806 	mov	r5,a
      0057B6 90 07 8E         [24]  807 	mov	dptr,#_reactive_at
      0057B9 12 48 D7         [24]  808 	lcall	_ak820_outline_0106
      0057BC 90 07 8E         [24]  809 	mov	dptr,#_reactive_at
      0057BF EC               [12]  810 	mov	a,r4
      0057C0 2A               [12]  811 	add	a, r2
      0057C1 F0               [24]  812 	movx	@dptr,a
      0057C2 ED               [12]  813 	mov	a,r5
      0057C3 3B               [12]  814 	addc	a, r3
      0057C4 A3               [24]  815 	inc	dptr
      0057C5 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      0057C6 8E 04            [24]  818 	mov	ar4,r6
      0057C8 8F 05            [24]  819 	mov	ar5,r7
      0057CA C3               [12]  820 	clr	c
      0057CB 74 FF            [12]  821 	mov	a,#0xff
      0057CD 9C               [12]  822 	subb	a,r4
      0057CE E4               [12]  823 	clr	a
      0057CF 9D               [12]  824 	subb	a,r5
      0057D0 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      0057D2 7D FF            [12]  827 	mov	r5,#0xff
      0057D4 80 02            [24]  828 	sjmp	00109$
      0057D6                        829 00108$:
      0057D6 8E 05            [24]  830 	mov	ar5,r6
      0057D8                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0057D8 7F 00            [12]  833 	mov	r7,#0x00
      0057DA                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      0057DA EF               [12]  836 	mov	a,r7
      0057DB 24 3C            [12]  837 	add	a, #_reactive_age
      0057DD FC               [12]  838 	mov	r4,a
      0057DE E4               [12]  839 	clr	a
      0057DF 34 07            [12]  840 	addc	a, #(_reactive_age >> 8)
      0057E1 FE               [12]  841 	mov	r6,a
      0057E2 8C 82            [24]  842 	mov	dpl,r4
      0057E4 8E 83            [24]  843 	mov	dph,r6
      0057E6 E0               [24]  844 	movx	a,@dptr
      0057E7 FB               [12]  845 	mov	r3,a
      0057E8 C3               [12]  846 	clr	c
      0057E9 ED               [12]  847 	mov	a,r5
      0057EA 9B               [12]  848 	subb	a,r3
      0057EB 40 04            [24]  849 	jc	00110$
      0057ED 7B 00            [12]  850 	mov	r3,#0x00
      0057EF 80 08            [24]  851 	sjmp	00111$
      0057F1                        852 00110$:
      0057F1 8C 82            [24]  853 	mov	dpl,r4
      0057F3 8E 83            [24]  854 	mov	dph,r6
      0057F5 E0               [24]  855 	movx	a,@dptr
      0057F6 C3               [12]  856 	clr	c
      0057F7 9D               [12]  857 	subb	a,r5
      0057F8 FB               [12]  858 	mov	r3,a
      0057F9                        859 00111$:
      0057F9 8C 82            [24]  860 	mov	dpl,r4
      0057FB 8E 83            [24]  861 	mov	dph,r6
      0057FD EB               [12]  862 	mov	a,r3
      0057FE F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0057FF 0F               [12]  865 	inc	r7
      005800 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      005803                        867 00144$:
      005803 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      005805 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      005806                        881 _add_sat:
      005806 E5 82            [12]  882 	mov	a,dpl
      005808 90 07 91         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      00580B F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      00580C 90 07 90         [24]  886 	mov	dptr,#_add_sat_PARM_2
      00580F E0               [24]  887 	movx	a,@dptr
      005810 FF               [12]  888 	mov	r7,a
      005811 FE               [12]  889 	mov	r6,a
      005812 74 FF            [12]  890 	mov	a,#0xff
      005814 C3               [12]  891 	clr	c
      005815 9E               [12]  892 	subb	a,r6
      005816 FE               [12]  893 	mov	r6,a
      005817 90 07 91         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      00581A E0               [24]  895 	movx	a,@dptr
      00581B FD               [12]  896 	mov	r5,a
      00581C C3               [12]  897 	clr	c
      00581D EE               [12]  898 	mov	a,r6
      00581E 9D               [12]  899 	subb	a,r5
      00581F 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      005821 7E FF            [12]  902 	mov	r6,#0xff
      005823 80 03            [24]  903 	sjmp	00104$
      005825                        904 00103$:
      005825 EF               [12]  905 	mov	a,r7
      005826 2D               [12]  906 	add	a, r5
      005827 FE               [12]  907 	mov	r6,a
      005828                        908 00104$:
      005828 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      00582A 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      00582B                        922 _sub_sat:
      00582B E5 82            [12]  923 	mov	a,dpl
      00582D 90 07 93         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      005830 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      005831 E0               [24]  927 	movx	a,@dptr
      005832 FF               [12]  928 	mov	r7,a
      005833 90 07 92         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      005836 E0               [24]  930 	movx	a,@dptr
      005837 FE               [12]  931 	mov	r6,a
      005838 C3               [12]  932 	clr	c
      005839 EF               [12]  933 	mov	a,r7
      00583A 9E               [12]  934 	subb	a,r6
      00583B 50 04            [24]  935 	jnc	00103$
      00583D 7D 00            [12]  936 	mov	r5,#0x00
      00583F 80 04            [24]  937 	sjmp	00104$
      005841                        938 00103$:
      005841 EF               [12]  939 	mov	a,r7
      005842 C3               [12]  940 	clr	c
      005843 9E               [12]  941 	subb	a,r6
      005844 FD               [12]  942 	mov	r5,a
      005845                        943 00104$:
      005845 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      005847 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      005848                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      005848 D2 14            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      00584A 12 4E B5         [24]  959 	lcall	_timer_read
      00584D 12 3A E6         [24]  960 	lcall	_ak820_outline_0140
      005850 90 07 2F         [24]  961 	mov	dptr,#_changed_at
      005853 12 5F 10         [24]  962 	lcall	_ak820_outline_0172
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      005856 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      005857                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      005857 90 07 2E         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      00585A E4               [12]  978 	clr	a
      00585B F0               [24]  979 	movx	@dptr,a
      00585C 90 07 2D         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      00585F F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005860 90 05 FB         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005863 12 5E F3         [24]  984 	lcall	_ak820_outline_0088
      005866 90 05 FE         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      005869 12 5E DA         [24]  986 	lcall	_ak820_outline_0070
      00586C 12 47 AB         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      00586F C2 14            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005871 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005872                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005872 12 5F 24         [24] 1002 	lcall	_ak820_outline_0181
      005875 12 5E DA         [24] 1003 	lcall	_ak820_outline_0070
      005878 F5 F0            [12] 1004 	mov	b,a
      00587A 12 C0 F0         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      00587D 12 5F 03         [24] 1007 	lcall	_ak820_outline_0117
      005880 44 01            [12] 1008 	orl	a,#0x01
      005882 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005883 12 5E D3         [24] 1011 	lcall	_ak820_outline_0066
      005886 44 04            [12] 1012 	orl	a,#0x04
      005888 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      005889 90 07 28         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00588C E4               [12] 1016 	clr	a
      00588D F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      00588E 90 07 29         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005891 14               [12] 1020 	dec	a
      005892 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005893 90 07 2A         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005896 74 50            [12] 1024 	mov	a,#0x50
      005898 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      005899 90 07 2B         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00589C 74 60            [12] 1028 	mov	a,#0x60
      00589E F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      00589F 90 07 2C         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0058A2 74 FF            [12] 1032 	mov	a,#0xff
      0058A4 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      0058A5 01 57            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      0058A7                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0058A7 90 05 EB         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0058AA 12 5E F3         [24] 1047 	lcall	_ak820_outline_0088
      0058AD 90 05 EE         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0058B0 12 5E DA         [24] 1049 	lcall	_ak820_outline_0070
      0058B3 12 46 3C         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      0058B6 12 5F 03         [24] 1052 	lcall	_ak820_outline_0117
      0058B9 60 11            [24] 1053 	jz	00101$
      0058BB 12 5E B4         [24] 1054 	lcall	_ak820_outline_0019
      0058BE C3               [12] 1055 	clr	c
      0058BF 64 80            [12] 1056 	xrl	a,#0x80
      0058C1 94 87            [12] 1057 	subb	a,#0x87
      0058C3 50 07            [24] 1058 	jnc	00101$
      0058C5 12 5E D3         [24] 1059 	lcall	_ak820_outline_0066
      0058C8 24 FE            [12] 1060 	add	a,#0xff - 0x01
      0058CA 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      0058CC                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      0058CC 11 72            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      0058CE                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      0058CE 90 07 2A         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058D1 E0               [24] 1069 	movx	a,@dptr
      0058D2 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      0058D4 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      0058D6 90 07 2A         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058D9 74 A0            [12] 1075 	mov	a,#0xa0
      0058DB F0               [24] 1076 	movx	@dptr,a
      0058DC                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      0058DC C2 14            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      0058DE C2 15            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      0058E0 02 57 6B         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0058E3                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0058E3 11 A7            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0058E5 12 4E B5         [24] 1098 	lcall	_timer_read
      0058E8 12 48 E9         [24] 1099 	lcall	_ak820_outline_0127
      0058EB EE               [12] 1100 	mov	a,r6
      0058EC 24 F0            [12] 1101 	add	a,#0xf0
      0058EE FE               [12] 1102 	mov	r6,a
      0058EF EF               [12] 1103 	mov	a,r7
      0058F0 34 FF            [12] 1104 	addc	a,#0xff
      0058F2 FF               [12] 1105 	mov	r7,a
      0058F3 90 07 31         [24] 1106 	mov	dptr,#_frame_at
      0058F6 12 4E 09         [24] 1107 	lcall	_ak820_outline_0060
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0058F9 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0058FA                       1122 _rgb_matrix_set_color:
      0058FA 12 3A C2         [24] 1123 	lcall	_ak820_outline_0110
      0058FD 90 07 97         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005900 12 3A C7         [24] 1125 	lcall	_ak820_outline_0111
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      005903 90 07 97         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005906 12 3A 81         [24] 1128 	lcall	_ak820_outline_0053
      005909 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      00590C C3               [12] 1130 	clr	c
      00590D EE               [12] 1131 	mov	a,r6
      00590E 94 52            [12] 1132 	subb	a,#0x52
      005910 EF               [12] 1133 	mov	a,r7
      005911 64 80            [12] 1134 	xrl	a,#0x80
      005913 94 80            [12] 1135 	subb	a,#0x80
      005915 50 23            [24] 1136 	jnc	00104$
      005917 90 07 94         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      00591A E0               [24] 1138 	movx	a,@dptr
      00591B FF               [12] 1139 	mov	r7,a
      00591C 90 07 95         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00591F E0               [24] 1141 	movx	a,@dptr
      005920 FD               [12] 1142 	mov	r5,a
      005921 90 07 96         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005924 E0               [24] 1144 	movx	a,@dptr
      005925 FC               [12] 1145 	mov	r4,a
      005926 90 04 2A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005929 EF               [12] 1147 	mov	a,r7
      00592A F0               [24] 1148 	movx	@dptr,a
      00592B 90 04 2B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      00592E ED               [12] 1150 	mov	a,r5
      00592F F0               [24] 1151 	movx	@dptr,a
      005930 90 04 2C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      005933 EC               [12] 1153 	mov	a,r4
      005934 F0               [24] 1154 	movx	@dptr,a
      005935 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      005937 02 35 CD         [24] 1157 	ljmp	_ak820_rgb_set_color
      00593A                       1158 00104$:
      00593A 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      00593B                       1171 _rgb_matrix_set_color_all:
      00593B E5 82            [12] 1172 	mov	a,dpl
      00593D 90 07 9B         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      005940 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      005941 E0               [24] 1176 	movx	a,@dptr
      005942 FF               [12] 1177 	mov	r7,a
      005943 90 07 99         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005946 E0               [24] 1179 	movx	a,@dptr
      005947 FE               [12] 1180 	mov	r6,a
      005948 90 07 9A         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00594B E0               [24] 1182 	movx	a,@dptr
      00594C FD               [12] 1183 	mov	r5,a
      00594D 90 04 2E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      005950 EE               [12] 1185 	mov	a,r6
      005951 F0               [24] 1186 	movx	@dptr,a
      005952 90 04 2F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005955 ED               [12] 1188 	mov	a,r5
      005956 F0               [24] 1189 	movx	@dptr,a
      005957 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005959 02 36 04         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      00595C                       1206 _sine8:
      00595C E5 82            [12] 1207 	mov	a,dpl
      00595E 90 07 9C         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      005961 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005962 E0               [24] 1211 	movx	a,@dptr
      005963 FF               [12] 1212 	mov	r7,a
      005964 90 07 9D         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005967 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005968 EF               [12] 1216 	mov	a,r7
      005969 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      00596C 90 07 9D         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      00596F 74 FF            [12] 1219 	mov	a,#0xff
      005971 C3               [12] 1220 	clr	c
      005972 9F               [12] 1221 	subb	a,r7
      005973 F0               [24] 1222 	movx	@dptr,a
      005974                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005974 90 07 9D         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005977 E0               [24] 1226 	movx	a,@dptr
      005978 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      00597B F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00597C 90 07 9D         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      00597F E0               [24] 1231 	movx	a,@dptr
      005980 54 0F            [12] 1232 	anl	a,#0x0f
      005982 FF               [12] 1233 	mov	r7,a
      005983 90 07 9E         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005986 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005987 90 07 9C         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      00598A E0               [24] 1238 	movx	a,@dptr
      00598B 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      00598E 90 07 9E         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      005991 EF               [12] 1241 	mov	a,r7
      005992 04               [12] 1242 	inc	a
      005993 F0               [24] 1243 	movx	@dptr,a
      005994                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005994 90 07 9D         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005997 E0               [24] 1247 	movx	a,@dptr
      005998 C4               [12] 1248 	swap	a
      005999 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00599B 25 E0            [12] 1251 	add	a,acc
      00599D FF               [12] 1252 	mov	r7,a
      00599E 90 C1 D5         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      0059A1 93               [24] 1254 	movc	a,@a+dptr
      0059A2 FE               [12] 1255 	mov	r6,a
      0059A3 0F               [12] 1256 	inc	r7
      0059A4 EF               [12] 1257 	mov	a,r7
      0059A5 90 C1 D5         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      0059A8 93               [24] 1259 	movc	a,@a+dptr
      0059A9 FF               [12] 1260 	mov	r7,a
      0059AA 90 07 9E         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      0059AD E0               [24] 1262 	movx	a,@dptr
      0059AE 8F F0            [24] 1263 	mov	b,r7
      0059B0 A4               [48] 1264 	mul	ab
      0059B1 FF               [12] 1265 	mov	r7,a
      0059B2 E5 F0            [12] 1266 	mov	a,b
      0059B4 C4               [12] 1267 	swap	a
      0059B5 CF               [12] 1268 	xch	a,r7
      0059B6 C4               [12] 1269 	swap	a
      0059B7 54 0F            [12] 1270 	anl	a,#0x0f
      0059B9 6F               [12] 1271 	xrl	a,r7
      0059BA CF               [12] 1272 	xch	a,r7
      0059BB 54 0F            [12] 1273 	anl	a,#0x0f
      0059BD CF               [12] 1274 	xch	a,r7
      0059BE 6F               [12] 1275 	xrl	a,r7
      0059BF CF               [12] 1276 	xch	a,r7
      0059C0 EF               [12] 1277 	mov	a,r7
      0059C1 2E               [12] 1278 	add	a, r6
      0059C2 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      0059C3 90 07 9C         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      0059C6 E0               [24] 1282 	movx	a,@dptr
      0059C7 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      0059CA 8F 06            [24] 1284 	mov	ar6,r7
      0059CC 74 80            [12] 1285 	mov	a,#0x80
      0059CE C3               [12] 1286 	clr	c
      0059CF 9E               [12] 1287 	subb	a,r6
      0059D0 FE               [12] 1288 	mov	r6,a
      0059D1 80 04            [24] 1289 	sjmp	00108$
      0059D3                       1290 00107$:
      0059D3 74 80            [12] 1291 	mov	a,#0x80
      0059D5 2F               [12] 1292 	add	a, r7
      0059D6 FE               [12] 1293 	mov	r6,a
      0059D7                       1294 00108$:
      0059D7 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      0059D9 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      0059DA                       1312 _breathing_cie:
      0059DA E5 82            [12] 1313 	mov	a,dpl
      0059DC 90 07 9F         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      0059DF F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      0059E0 E0               [24] 1317 	movx	a,@dptr
      0059E1 FF               [12] 1318 	mov	r7,a
      0059E2 12 5F 32         [24] 1319 	lcall	_ak820_outline_0191
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0059E5 FE               [12] 1321 	mov	r6,a
      0059E6 90 C4 E1         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0059E9 93               [24] 1323 	movc	a,@a+dptr
      0059EA FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0059EB BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0059EE 8D 82            [24] 1327 	mov	dpl, r5
      0059F0 22               [24] 1328 	ret
      0059F1                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0059F1 EE               [12] 1331 	mov	a,r6
      0059F2 04               [12] 1332 	inc	a
      0059F3 90 C4 E1         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0059F6 93               [24] 1334 	movc	a,@a+dptr
      0059F7 C3               [12] 1335 	clr	c
      0059F8 9D               [12] 1336 	subb	a,r5
      0059F9 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0059FA 74 07            [12] 1339 	mov	a,#0x07
      0059FC 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0059FD F5 F0            [12] 1342 	mov	b,a
      0059FF EE               [12] 1343 	mov	a,r6
      005A00 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005A01 12 5F 32         [24] 1346 	lcall	_ak820_outline_0191
      005A04 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      005A05 F5 82            [12] 1349 	mov	dpl,a
      005A07 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      005A08                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      005A08 12 57 88         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005A0B 30 14 17         [24] 1369 	jnb	_dirty,00102$
      005A0E 90 07 2F         [24] 1370 	mov	dptr,#_changed_at
      005A11 12 3A 34         [24] 1371 	lcall	_ak820_outline_0005
      005A14 12 4E B8         [24] 1372 	lcall	_timer_elapsed
      005A17 12 48 E9         [24] 1373 	lcall	_ak820_outline_0127
      005A1A C3               [12] 1374 	clr	c
      005A1B EE               [12] 1375 	mov	a,r6
      005A1C 94 E8            [12] 1376 	subb	a,#0xe8
      005A1E EF               [12] 1377 	mov	a,r7
      005A1F 94 03            [12] 1378 	subb	a,#0x03
      005A21 40 02            [24] 1379 	jc	00102$
      005A23 11 57            [12] 1380 	acall	_eeconfig_update_rgb_matrix
      005A25                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      005A25 30 15 02         [24] 1383 	jnb	_rendering,00254$
      005A28 41 DD            [12] 1384 	ajmp	00109$
      005A2A                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005A2A 90 07 31         [24] 1387 	mov	dptr,#_frame_at
      005A2D 12 3A 34         [24] 1388 	lcall	_ak820_outline_0005
      005A30 12 4E B8         [24] 1389 	lcall	_timer_elapsed
      005A33 12 48 E9         [24] 1390 	lcall	_ak820_outline_0127
      005A36 C3               [12] 1391 	clr	c
      005A37 EE               [12] 1392 	mov	a,r6
      005A38 94 10            [12] 1393 	subb	a,#0x10
      005A3A EF               [12] 1394 	mov	a,r7
      005A3B 94 00            [12] 1395 	subb	a,#0x00
      005A3D 50 01            [24] 1396 	jnc	00105$
      005A3F 22               [24] 1397 	ret
      005A40                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      005A40 12 4E B5         [24] 1400 	lcall	_timer_read
      005A43 12 3A E6         [24] 1401 	lcall	_ak820_outline_0140
      005A46 90 07 31         [24] 1402 	mov	dptr,#_frame_at
      005A49 12 5F 10         [24] 1403 	lcall	_ak820_outline_0172
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      005A4C 90 07 2B         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005A4F E0               [24] 1406 	movx	a,@dptr
      005A50 FF               [12] 1407 	mov	r7,a
      005A51 7E 00            [12] 1408 	mov	r6,#0x00
      005A53 74 20            [12] 1409 	mov	a,#0x20
      005A55 2F               [12] 1410 	add	a, r7
      005A56 FF               [12] 1411 	mov	r7,a
      005A57 E4               [12] 1412 	clr	a
      005A58 3E               [12] 1413 	addc	a, r6
      005A59 FE               [12] 1414 	mov	r6,a
      005A5A 90 07 33         [24] 1415 	mov	dptr,#_phase
      005A5D 12 3A 98         [24] 1416 	lcall	_ak820_outline_0061
      005A60 EF               [12] 1417 	mov	a,r7
      005A61 2C               [12] 1418 	add	a, r4
      005A62 FF               [12] 1419 	mov	r7,a
      005A63 EE               [12] 1420 	mov	a,r6
      005A64 3D               [12] 1421 	addc	a, r5
      005A65 FE               [12] 1422 	mov	r6,a
      005A66 90 07 33         [24] 1423 	mov	dptr,#_phase
      005A69 EF               [12] 1424 	mov	a,r7
      005A6A F0               [24] 1425 	movx	@dptr,a
      005A6B EE               [12] 1426 	mov	a,r6
      005A6C A3               [24] 1427 	inc	dptr
      005A6D F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005A6E 90 07 33         [24] 1430 	mov	dptr,#_phase
      005A71 E0               [24] 1431 	movx	a,@dptr
      005A72 A3               [24] 1432 	inc	dptr
      005A73 E0               [24] 1433 	movx	a,@dptr
      005A74 FF               [12] 1434 	mov	r7,a
      005A75 90 07 3B         [24] 1435 	mov	dptr,#_frame_phase
      005A78 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005A79 20 13 05         [24] 1438 	jb	_suspended,00135$
      005A7C 12 5E D3         [24] 1439 	lcall	_ak820_outline_0066
      005A7F 70 04            [24] 1440 	jnz	00132$
      005A81                       1441 00135$:
      005A81 7E 00            [12] 1442 	mov	r6,#0x00
      005A83 80 04            [24] 1443 	sjmp	00133$
      005A85                       1444 00132$:
      005A85 12 5E B4         [24] 1445 	lcall	_ak820_outline_0019
      005A88 FE               [12] 1446 	mov	r6,a
      005A89                       1447 00133$:
      005A89 90 07 36         [24] 1448 	mov	dptr,#_frame_mode
      005A8C EE               [12] 1449 	mov	a,r6
      005A8D F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005A8E 90 07 28         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005A91 E0               [24] 1453 	movx	a,@dptr
      005A92 90 07 37         [24] 1454 	mov	dptr,#_frame_hue
      005A95 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005A96 90 07 29         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005A99 E0               [24] 1458 	movx	a,@dptr
      005A9A 90 07 38         [24] 1459 	mov	dptr,#_frame_sat
      005A9D F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005A9E 90 07 2A         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AA1 E0               [24] 1463 	movx	a,@dptr
      005AA2 FD               [12] 1464 	mov	r5,a
      005AA3 90 07 39         [24] 1465 	mov	dptr,#_frame_val
      005AA6 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005AA7 90 07 2C         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005AAA E0               [24] 1469 	movx	a,@dptr
      005AAB 90 07 3A         [24] 1470 	mov	dptr,#_frame_flags
      005AAE F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005AAF BE 02 24         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005AB2 EF               [12] 1475 	mov	a,r7
      005AB3 24 C0            [12] 1476 	add	a,#0xc0
      005AB5 F5 82            [12] 1477 	mov	dpl,a
      005AB7 C0 05            [24] 1478 	push	ar5
      005AB9 31 5C            [24] 1479 	acall	_sine8
      005ABB AF 82            [24] 1480 	mov	r7, dpl
      005ABD D0 05            [24] 1481 	pop	ar5
      005ABF 8D F0            [24] 1482 	mov	b,r5
      005AC1 EF               [12] 1483 	mov	a,r7
      005AC2 A4               [48] 1484 	mul	ab
      005AC3 AE F0            [24] 1485 	mov	r6,b
      005AC5 8E 05            [24] 1486 	mov	ar5,r6
      005AC7 90 07 39         [24] 1487 	mov	dptr,#_frame_val
      005ACA ED               [12] 1488 	mov	a,r5
      005ACB F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005ACC 8D 82            [24] 1491 	mov	dpl, r5
      005ACE 31 DA            [24] 1492 	acall	_breathing_cie
      005AD0 E5 82            [12] 1493 	mov	a, dpl
      005AD2 90 07 39         [24] 1494 	mov	dptr,#_frame_val
      005AD5 F0               [24] 1495 	movx	@dptr,a
      005AD6                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005AD6 90 07 35         [24] 1498 	mov	dptr,#_led_index
      005AD9 E4               [12] 1499 	clr	a
      005ADA F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005ADB D2 15            [12] 1503 	setb	_rendering
      005ADD                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005ADD 12 5F 2D         [24] 1506 	lcall	_ak820_outline_0189
      005AE0 24 08            [12] 1507 	add	a,#0x08
      005AE2 FF               [12] 1508 	mov	r7,a
      005AE3 90 07 A0         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005AE6 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005AE7 EF               [12] 1512 	mov	a,r7
      005AE8 24 AD            [12] 1513 	add	a,#0xff - 0x52
      005AEA 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      005AEC 90 07 A0         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005AEF 74 52            [12] 1517 	mov	a,#0x52
      005AF1 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005AF2                       1520 00125$:
      005AF2 12 5F 2D         [24] 1521 	lcall	_ak820_outline_0189
      005AF5 FF               [12] 1522 	mov	r7,a
      005AF6 90 07 A0         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005AF9 E0               [24] 1524 	movx	a,@dptr
      005AFA FE               [12] 1525 	mov	r6,a
      005AFB C3               [12] 1526 	clr	c
      005AFC EF               [12] 1527 	mov	a,r7
      005AFD 9E               [12] 1528 	subb	a,r6
      005AFE 40 02            [24] 1529 	jc	00261$
      005B00 81 5D            [12] 1530 	ajmp	00127$
      005B02                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      005B02 12 5F 0A         [24] 1533 	lcall	_ak820_outline_0142
      005B05 E0               [24] 1534 	movx	a,@dptr
      005B06 60 07            [24] 1535 	jz	00121$
      005B08 90 07 3A         [24] 1536 	mov	dptr,#_frame_flags
      005B0B E0               [24] 1537 	movx	a,@dptr
      005B0C 20 E2 19         [24] 1538 	jb	acc.2,00122$
      005B0F                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      005B0F 12 5F 2D         [24] 1541 	lcall	_ak820_outline_0189
      005B12 FC               [12] 1542 	mov	r4,a
      005B13 7D 00            [12] 1543 	mov	r5,#0x00
      005B15 90 07 94         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005B18 E4               [12] 1545 	clr	a
      005B19 F0               [24] 1546 	movx	@dptr,a
      005B1A 90 07 95         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005B1D F0               [24] 1548 	movx	@dptr,a
      005B1E 90 07 96         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005B21 12 3A B6         [24] 1550 	lcall	_ak820_outline_0104
      005B24 11 FA            [24] 1551 	acall	_rgb_matrix_set_color
      005B26 81 55            [12] 1552 	ajmp	00123$
      005B28                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005B28 BE 05 20         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      005B2B EF               [12] 1557 	mov	a,r7
      005B2C 75 F0 03         [24] 1558 	mov	b,#0x03
      005B2F A4               [48] 1559 	mul	ab
      005B30 24 14            [12] 1560 	add	a, #_g_direct_mode_colors
      005B32 FD               [12] 1561 	mov	r5,a
      005B33 74 0D            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      005B35 35 F0            [12] 1563 	addc	a, b
      005B37 FE               [12] 1564 	mov	r6,a
      005B38 90 0E 28         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      005B3B ED               [12] 1566 	mov	a,r5
      005B3C F0               [24] 1567 	movx	@dptr,a
      005B3D EE               [12] 1568 	mov	a,r6
      005B3E 12 5E E4         [24] 1569 	lcall	_ak820_outline_0073
      005B41 90 07 A1         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B44 F5 F0            [12] 1571 	mov	b,a
      005B46 12 C0 7A         [24] 1572 	lcall	___memcpy
      005B49 61 FA            [12] 1573 	ajmp	00120$
      005B4B                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005B4B 90 07 37         [24] 1576 	mov	dptr,#_frame_hue
      005B4E E0               [24] 1577 	movx	a,@dptr
      005B4F 90 07 A1         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B52 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005B53 90 07 38         [24] 1581 	mov	dptr,#_frame_sat
      005B56 E0               [24] 1582 	movx	a,@dptr
      005B57 90 07 A2         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005B5A F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005B5B 90 07 39         [24] 1586 	mov	dptr,#_frame_val
      005B5E E0               [24] 1587 	movx	a,@dptr
      005B5F 90 07 A3         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005B62 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005B63 12 5F 0A         [24] 1591 	lcall	_ak820_outline_0142
      005B66 BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      005B69 90 07 A1         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B6C E0               [24] 1594 	movx	a,@dptr
      005B6D FE               [12] 1595 	mov	r6,a
      005B6E 90 07 3B         [24] 1596 	mov	dptr,#_frame_phase
      005B71 E0               [24] 1597 	movx	a,@dptr
      005B72 2E               [12] 1598 	add	a, r6
      005B73 90 07 A1         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B76 F0               [24] 1600 	movx	@dptr,a
      005B77                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005B77 12 5F 0A         [24] 1603 	lcall	_ak820_outline_0142
      005B7A BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      005B7D 90 07 A1         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B80 E0               [24] 1606 	movx	a,@dptr
      005B81 FE               [12] 1607 	mov	r6,a
      005B82 12 5F 2D         [24] 1608 	lcall	_ak820_outline_0189
      005B85 75 F0 02         [24] 1609 	mov	b,#0x02
      005B88 A4               [48] 1610 	mul	ab
      005B89 24 3D            [12] 1611 	add	a, #_ak820_led_points
      005B8B F5 82            [12] 1612 	mov	dpl,a
      005B8D 74 C4            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      005B8F 12 5E FC         [24] 1614 	lcall	_ak820_outline_0112
      005B92 FD               [12] 1615 	mov	r5,a
      005B93 90 07 3B         [24] 1616 	mov	dptr,#_frame_phase
      005B96 E0               [24] 1617 	movx	a,@dptr
      005B97 FC               [12] 1618 	mov	r4,a
      005B98 ED               [12] 1619 	mov	a,r5
      005B99 C3               [12] 1620 	clr	c
      005B9A 9C               [12] 1621 	subb	a,r4
      005B9B 2E               [12] 1622 	add	a, r6
      005B9C 90 07 A1         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005B9F F0               [24] 1624 	movx	@dptr,a
      005BA0                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005BA0 12 5F 0A         [24] 1627 	lcall	_ak820_outline_0142
      005BA3 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005BA6 12 5F 1B         [24] 1630 	lcall	_ak820_outline_0176
      005BA9 FE               [12] 1631 	mov	r6,a
      005BAA 74 07            [12] 1632 	mov	a,#0x07
      005BAC C3               [12] 1633 	clr	c
      005BAD 9E               [12] 1634 	subb	a,r6
      005BAE FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      005BAF 8E F0            [24] 1637 	mov	b,r6
      005BB1 05 F0            [12] 1638 	inc	b
      005BB3 74 01            [12] 1639 	mov	a,#0x01
      005BB5 80 02            [24] 1640 	sjmp	00273$
      005BB7                       1641 00272$:
      005BB7 25 E0            [12] 1642 	add	a,acc
      005BB9                       1643 00273$:
      005BB9 D5 F0 FB         [24] 1644 	djnz	b,00272$
      005BBC FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      005BBD 12 5F 2D         [24] 1647 	lcall	_ak820_outline_0189
      005BC0 24 3C            [12] 1648 	add	a, #_reactive_age
      005BC2 F5 82            [12] 1649 	mov	dpl,a
      005BC4 E4               [12] 1650 	clr	a
      005BC5 34 07            [12] 1651 	addc	a, #(_reactive_age >> 8)
      005BC7 F5 83            [12] 1652 	mov	dph,a
      005BC9 E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005BCA FC               [12] 1655 	mov	r4,a
      005BCB C3               [12] 1656 	clr	c
      005BCC 9D               [12] 1657 	subb	a,r5
      005BCD 40 07            [24] 1658 	jc	00137$
      005BCF 90 07 39         [24] 1659 	mov	dptr,#_frame_val
      005BD2 E0               [24] 1660 	movx	a,@dptr
      005BD3 FB               [12] 1661 	mov	r3,a
      005BD4 80 1F            [24] 1662 	sjmp	00138$
      005BD6                       1663 00137$:
      005BD6 90 07 39         [24] 1664 	mov	dptr,#_frame_val
      005BD9 E0               [24] 1665 	movx	a,@dptr
      005BDA F5 F0            [12] 1666 	mov	b, a
      005BDC EC               [12] 1667 	mov	a,r4
      005BDD A4               [48] 1668 	mul	ab
      005BDE FC               [12] 1669 	mov	r4,a
      005BDF AA F0            [24] 1670 	mov	r2,b
      005BE1 8E F0            [24] 1671 	mov	b,r6
      005BE3 05 F0            [12] 1672 	inc	b
      005BE5 AB 04            [24] 1673 	mov	r3,ar4
      005BE7 AD 02            [24] 1674 	mov	r5,ar2
      005BE9 80 07            [24] 1675 	sjmp	00276$
      005BEB                       1676 00275$:
      005BEB C3               [12] 1677 	clr	c
      005BEC ED               [12] 1678 	mov	a,r5
      005BED 13               [12] 1679 	rrc	a
      005BEE FD               [12] 1680 	mov	r5,a
      005BEF EB               [12] 1681 	mov	a,r3
      005BF0 13               [12] 1682 	rrc	a
      005BF1 FB               [12] 1683 	mov	r3,a
      005BF2                       1684 00276$:
      005BF2 D5 F0 F6         [24] 1685 	djnz	b,00275$
      005BF5                       1686 00138$:
      005BF5 90 07 A3         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005BF8 EB               [12] 1688 	mov	a,r3
      005BF9 F0               [24] 1689 	movx	@dptr,a
      005BFA                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      005BFA 12 5F 0A         [24] 1692 	lcall	_ak820_outline_0142
      005BFD BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      005C00 D3               [12] 1694 	setb	c
      005C01 80 01            [24] 1695 	sjmp	00278$
      005C03                       1696 00277$:
      005C03 C3               [12] 1697 	clr	c
      005C04                       1698 00278$:
      005C04 B3               [12] 1699 	cpl	c
      005C05 92 16            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      005C07 90 0E 28         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      005C0A 74 A1            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      005C0C F0               [24] 1703 	movx	@dptr,a
      005C0D 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      005C0F 12 5E E4         [24] 1705 	lcall	_ak820_outline_0073
      005C12 90 0B 4B         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005C15 F5 F0            [12] 1707 	mov	b,a
      005C17 12 C0 7A         [24] 1708 	lcall	___memcpy
      005C1A 90 0B 4E         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      005C1D 74 A4            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      005C1F F0               [24] 1711 	movx	@dptr,a
      005C20 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005C22 A3               [24] 1713 	inc	dptr
      005C23 F0               [24] 1714 	movx	@dptr,a
      005C24 A2 16            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      005C26 12 3A F6         [24] 1716 	lcall	_ak820_outline_0162
      005C29 12 8A B8         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      005C2C 12 5F 2D         [24] 1719 	lcall	_ak820_outline_0189
      005C2F FD               [12] 1720 	mov	r5,a
      005C30 7E 00            [12] 1721 	mov	r6,#0x00
      005C32 90 07 A5         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005C35 E0               [24] 1723 	movx	a,@dptr
      005C36 FC               [12] 1724 	mov	r4,a
      005C37 90 07 A4         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      005C3A E0               [24] 1726 	movx	a,@dptr
      005C3B FB               [12] 1727 	mov	r3,a
      005C3C 90 07 A6         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005C3F E0               [24] 1729 	movx	a,@dptr
      005C40 FA               [12] 1730 	mov	r2,a
      005C41 90 07 94         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005C44 EC               [12] 1732 	mov	a,r4
      005C45 F0               [24] 1733 	movx	@dptr,a
      005C46 90 07 95         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005C49 EB               [12] 1735 	mov	a,r3
      005C4A F0               [24] 1736 	movx	@dptr,a
      005C4B 90 07 96         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005C4E EA               [12] 1738 	mov	a,r2
      005C4F F0               [24] 1739 	movx	@dptr,a
      005C50 12 3A E1         [24] 1740 	lcall	_ak820_outline_0137
      005C53 11 FA            [24] 1741 	acall	_rgb_matrix_set_color
      005C55                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005C55 12 5F 2D         [24] 1744 	lcall	_ak820_outline_0189
      005C58 24 01            [12] 1745 	add	a, #0x01
      005C5A F0               [24] 1746 	movx	@dptr,a
      005C5B 41 F2            [12] 1747 	ajmp	00125$
      005C5D                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005C5D BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      005C60 C2 15            [12] 1753 	clr	_rendering
      005C62                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005C62 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      005C63                       1770 _process_rgb_matrix:
      005C63 E5 82            [12] 1771 	mov	a,dpl
      005C65 90 07 A9         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005C68 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005C69 90 07 A8         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      005C6C E0               [24] 1776 	movx	a,@dptr
      005C6D 60 23            [24] 1777 	jz	00101$
      005C6F 20 13 20         [24] 1778 	jb	_suspended,00101$
      005C72 12 5E D3         [24] 1779 	lcall	_ak820_outline_0066
      005C75 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005C77 12 5E B4         [24] 1782 	lcall	_ak820_outline_0019
      005C7A FF               [12] 1783 	mov	r7,a
      005C7B BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      005C7E 90 07 A9         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005C81 E0               [24] 1786 	movx	a,@dptr
      005C82 FF               [12] 1787 	mov	r7,a
      005C83 BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      005C86                       1789 00169$:
      005C86 50 0A            [24] 1790 	jnc	00101$
      005C88 90 07 A7         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      005C8B E0               [24] 1792 	movx	a,@dptr
      005C8C FE               [12] 1793 	mov	r6,a
      005C8D BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      005C90                       1795 00171$:
      005C90 40 01            [24] 1796 	jc	00102$
      005C92                       1797 00101$:
      005C92 22               [24] 1798 	ret
      005C93                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005C93 C0 07            [24] 1801 	push	ar7
      005C95 C0 06            [24] 1802 	push	ar6
      005C97 12 57 88         [24] 1803 	lcall	_age_reactive
      005C9A D0 06            [24] 1804 	pop	ar6
      005C9C D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005C9E EF               [12] 1807 	mov	a,r7
      005C9F 12 3B 06         [24] 1808 	lcall	_ak820_outline_0193
      005CA2 2E               [12] 1809 	add	a,r6
      005CA3 FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005CA4 7E 00            [12] 1812 	mov	r6,#0x00
      005CA6                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005CA6 EE               [12] 1815 	mov	a,r6
      005CA7 90 C1 83         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      005CAA 93               [24] 1817 	movc	a,@a+dptr
      005CAB B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005CAE EE               [12] 1820 	mov	a,r6
      005CAF 24 3C            [12] 1821 	add	a, #_reactive_age
      005CB1 FC               [12] 1822 	mov	r4,a
      005CB2 E4               [12] 1823 	clr	a
      005CB3 34 07            [12] 1824 	addc	a, #(_reactive_age >> 8)
      005CB5 FD               [12] 1825 	mov	r5,a
      005CB6 12 5F 1B         [24] 1826 	lcall	_ak820_outline_0176
      005CB9 F5 F0            [12] 1827 	mov	b, a
      005CBB 05 F0            [12] 1828 	inc	b
      005CBD 7B 80            [12] 1829 	mov	r3,#0x80
      005CBF E4               [12] 1830 	clr	a
      005CC0 FA               [12] 1831 	mov	r2,a
      005CC1 33               [12] 1832 	rlc	a
      005CC2 92 D2            [24] 1833 	mov	ov,c
      005CC4 80 08            [24] 1834 	sjmp	00176$
      005CC6                       1835 00175$:
      005CC6 A2 D2            [12] 1836 	mov	c,ov
      005CC8 EA               [12] 1837 	mov	a,r2
      005CC9 13               [12] 1838 	rrc	a
      005CCA FA               [12] 1839 	mov	r2,a
      005CCB EB               [12] 1840 	mov	a,r3
      005CCC 13               [12] 1841 	rrc	a
      005CCD FB               [12] 1842 	mov	r3,a
      005CCE                       1843 00176$:
      005CCE D5 F0 F5         [24] 1844 	djnz	b,00175$
      005CD1 12 3A D7         [24] 1845 	lcall	_ak820_outline_0126
      005CD4 EB               [12] 1846 	mov	a,r3
      005CD5 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005CD6 22               [24] 1849 	ret
      005CD7                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005CD7 0E               [12] 1852 	inc	r6
      005CD8 BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      005CDB                       1854 00177$:
      005CDB 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      005CDD 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      005CDE                       1868 _rgb_matrix_set_suspend_state:
      005CDE E5 82            [12] 1869 	mov	a,dpl
      005CE0 90 07 AA         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005CE3 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005CE4 E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      005CE5 F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      005CE7 13               [12] 1876 	rrc	a
      005CE8 92 13            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      005CEA C2 15            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005CEC 12 57 6B         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005CEF E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005CF1 60 0E            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005CF3 90 07 99         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005CF6 E4               [12] 1888 	clr	a
      005CF7 F0               [24] 1889 	movx	@dptr,a
      005CF8 90 07 9A         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005CFB F0               [24] 1891 	movx	@dptr,a
      005CFC 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005CFF 21 3B            [24] 1894 	ajmp	_rgb_matrix_set_color_all
      005D01                       1895 00103$:
      005D01 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      005D02                       1904 _rgb_matrix_is_enabled:
      005D02 12 5E D3         [24] 1905 	lcall	_ak820_outline_0066
      005D05 F5 82            [12] 1906 	mov	dpl,a
      005D07 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      005D08                       1915 _rgb_matrix_get_mode:
      005D08 12 5E B4         [24] 1916 	lcall	_ak820_outline_0019
      005D0B F5 82            [12] 1917 	mov	dpl,a
      005D0D 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      005D0E                       1926 _rgb_matrix_get_hue:
      005D0E 90 07 28         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005D11 E0               [24] 1928 	movx	a,@dptr
      005D12 F5 82            [12] 1929 	mov	dpl,a
      005D14 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      005D15                       1938 _rgb_matrix_get_sat:
      005D15 90 07 29         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005D18 E0               [24] 1940 	movx	a,@dptr
      005D19 F5 82            [12] 1941 	mov	dpl,a
      005D1B 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      005D1C                       1950 _rgb_matrix_get_val:
      005D1C 90 07 2A         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005D1F E0               [24] 1952 	movx	a,@dptr
      005D20 F5 82            [12] 1953 	mov	dpl,a
      005D22 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      005D23                       1962 _rgb_matrix_get_speed:
      005D23 90 07 2B         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005D26 E0               [24] 1964 	movx	a,@dptr
      005D27 F5 82            [12] 1965 	mov	dpl,a
      005D29 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      005D2A                       1974 _rgb_matrix_toggle_noeeprom:
      005D2A 12 5E D3         [24] 1975 	lcall	_ak820_outline_0066
      005D2D FF               [12] 1976 	mov	r7,a
      005D2E 63 07 01         [24] 1977 	xrl	ar7,#0x01
      005D31 90 07 27         [24] 1978 	mov	dptr,#_rgb_matrix_config
      005D34 EF               [12] 1979 	mov	a,r7
      005D35 54 03            [12] 1980 	anl	a,#0x03
      005D37 F5 F0            [12] 1981 	mov	b,a
      005D39 E0               [24] 1982 	movx	a,@dptr
      005D3A 54 FC            [12] 1983 	anl	a,#0xfc
      005D3C 45 F0            [12] 1984 	orl	a,b
      005D3E F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      005D3F C2 15            [12] 1987 	clr	_rendering
      005D41 02 57 6B         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      005D44                       1996 _rgb_matrix_enable_noeeprom:
      005D44 12 5E D3         [24] 1997 	lcall	_ak820_outline_0066
      005D47 70 03            [24] 1998 	jnz	00102$
      005D49 12 57 6B         [24] 1999 	lcall	_clear_reactive
      005D4C                       2000 00102$:
      005D4C 12 5F 03         [24] 2001 	lcall	_ak820_outline_0117
      005D4F 44 01            [12] 2002 	orl	a,#0x01
      005D51 F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      005D52 C2 15            [12] 2005 	clr	_rendering
      005D54 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      005D55                       2014 _rgb_matrix_disable_noeeprom:
      005D55 12 5F 03         [24] 2015 	lcall	_ak820_outline_0117
      005D58 F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      005D59 C2 15            [12] 2018 	clr	_rendering
      005D5B 02 57 6B         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      005D5E                       2029 _rgb_matrix_mode_noeeprom:
      005D5E E5 82            [12] 2030 	mov	a,dpl
      005D60 90 07 AB         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005D63 F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005D64 E0               [24] 2034 	movx	a,@dptr
      005D65 FF               [12] 2035 	mov	r7,a
      005D66 60 05            [24] 2036 	jz	00101$
      005D68 BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      005D6B                       2038 00123$:
      005D6B 40 01            [24] 2039 	jc	00102$
      005D6D                       2040 00101$:
      005D6D 22               [24] 2041 	ret
      005D6E                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005D6E 12 5E B4         [24] 2044 	lcall	_ak820_outline_0019
      005D71 FE               [12] 2045 	mov	r6,a
      005D72 EF               [12] 2046 	mov	a,r7
      005D73 B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      005D76 80 03            [24] 2048 	sjmp	00105$
      005D78                       2049 00125$:
      005D78 12 57 6B         [24] 2050 	lcall	_clear_reactive
      005D7B                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005D7B 90 07 AB         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005D7E E0               [24] 2054 	movx	a,@dptr
      005D7F 90 07 27         [24] 2055 	mov	dptr,#_rgb_matrix_config
      005D82 25 E0            [12] 2056 	add	a,acc
      005D84 25 E0            [12] 2057 	add	a,acc
      005D86 54 FC            [12] 2058 	anl	a,#0xfc
      005D88 F5 F0            [12] 2059 	mov	b,a
      005D8A E0               [24] 2060 	movx	a,@dptr
      005D8B 54 03            [12] 2061 	anl	a,#0x03
      005D8D 45 F0            [12] 2062 	orl	a,b
      005D8F F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      005D90 C2 15            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005D92 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      005D93                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005D93 12 5E B4         [24] 2078 	lcall	_ak820_outline_0019
      005D96 FF               [12] 2079 	mov	r7,a
      005D97 0F               [12] 2080 	inc	r7
      005D98 BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      005D9B                       2082 00112$:
      005D9B 40 04            [24] 2083 	jc	00103$
      005D9D 7F 01            [12] 2084 	mov	r7,#0x01
      005D9F 80 07            [24] 2085 	sjmp	00104$
      005DA1                       2086 00103$:
      005DA1 12 5E B4         [24] 2087 	lcall	_ak820_outline_0019
      005DA4 FE               [12] 2088 	mov	r6,a
      005DA5 0E               [12] 2089 	inc	r6
      005DA6 8E 07            [24] 2090 	mov	ar7,r6
      005DA8                       2091 00104$:
      005DA8 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005DAA A1 5E            [12] 2094 	ajmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      005DAC                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005DAC 12 5E B4         [24] 2104 	lcall	_ak820_outline_0019
      005DAF 24 FE            [12] 2105 	add	a,#0xff - 0x01
      005DB1 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      005DB3 7F 06            [12] 2108 	mov	r7,#0x06
      005DB5 80 05            [24] 2109 	sjmp	00104$
      005DB7                       2110 00103$:
      005DB7 12 5E B4         [24] 2111 	lcall	_ak820_outline_0019
      005DBA 14               [12] 2112 	dec	a
      005DBB FF               [12] 2113 	mov	r7,a
      005DBC                       2114 00104$:
      005DBC 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005DBE A1 5E            [12] 2117 	ajmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      005DC0                       2129 _rgb_matrix_sethsv_noeeprom:
      005DC0 12 3A C2         [24] 2130 	lcall	_ak820_outline_0110
      005DC3 90 07 AE         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005DC6 12 3A C7         [24] 2132 	lcall	_ak820_outline_0111
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005DC9 90 07 AE         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005DCC E0               [24] 2135 	movx	a,@dptr
      005DCD 90 07 28         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005DD0 F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005DD1 90 07 AC         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005DD4 E0               [24] 2140 	movx	a,@dptr
      005DD5 FF               [12] 2141 	mov	r7,a
      005DD6 90 07 29         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005DD9 F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005DDA 90 07 AD         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005DDD E0               [24] 2146 	movx	a,@dptr
      005DDE FF               [12] 2147 	mov  r7,a
      005DDF 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      005DE1 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      005DE3 7E A0            [12] 2151 	mov	r6,#0xa0
      005DE5 80 02            [24] 2152 	sjmp	00104$
      005DE7                       2153 00103$:
      005DE7 8F 06            [24] 2154 	mov	ar6,r7
      005DE9                       2155 00104$:
      005DE9 90 07 2A         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005DEC EE               [12] 2157 	mov	a,r6
      005DED F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005DEE 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      005DEF                       2170 _rgb_matrix_set_speed_noeeprom:
      005DEF E5 82            [12] 2171 	mov	a,dpl
      005DF1 90 07 B0         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005DF4 F0               [24] 2173 	movx	@dptr,a
      005DF5 E0               [24] 2174 	movx	a,@dptr
      005DF6 90 07 2B         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005DF9 F0               [24] 2176 	movx	@dptr,a
      005DFA 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      005DFB                       2187 _rgb_matrix_increase_hue_noeeprom:
      005DFB 90 07 28         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005DFE E0               [24] 2189 	movx	a,@dptr
      005DFF 24 08            [12] 2190 	add	a,#0x08
      005E01 90 07 28         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005E04 F0               [24] 2192 	movx	@dptr,a
      005E05 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      005E06                       2201 _rgb_matrix_decrease_hue_noeeprom:
      005E06 90 07 28         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005E09 E0               [24] 2203 	movx	a,@dptr
      005E0A 24 F8            [12] 2204 	add	a,#0xf8
      005E0C 90 07 28         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005E0F F0               [24] 2206 	movx	@dptr,a
      005E10 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      005E11                       2215 _rgb_matrix_increase_sat_noeeprom:
      005E11 90 07 29         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005E14 12 5E BD         [24] 2217 	lcall	_ak820_outline_0048
      005E17 11 06            [12] 2218 	acall	_add_sat
      005E19 AF 82            [24] 2219 	mov	r7, dpl
      005E1B 90 07 29         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005E1E EF               [12] 2221 	mov	a,r7
      005E1F F0               [24] 2222 	movx	@dptr,a
      005E20 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      005E21                       2231 _rgb_matrix_decrease_sat_noeeprom:
      005E21 90 07 29         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005E24 12 5E C8         [24] 2233 	lcall	_ak820_outline_0049
      005E27 11 2B            [12] 2234 	acall	_sub_sat
      005E29 AF 82            [24] 2235 	mov	r7, dpl
      005E2B 90 07 29         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005E2E EF               [12] 2237 	mov	a,r7
      005E2F F0               [24] 2238 	movx	@dptr,a
      005E30 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      005E31                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005E31 90 07 2A         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005E34 12 5E BD         [24] 2252 	lcall	_ak820_outline_0048
      005E37 11 06            [12] 2253 	acall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005E39 E5 82            [12] 2255 	mov	a,dpl
      005E3B FF               [12] 2256 	mov	r7,a
      005E3C 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      005E3E 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      005E40 7E A0            [12] 2260 	mov	r6,#0xa0
      005E42 80 02            [24] 2261 	sjmp	00104$
      005E44                       2262 00103$:
      005E44 8F 06            [24] 2263 	mov	ar6,r7
      005E46                       2264 00104$:
      005E46 90 07 2A         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005E49 EE               [12] 2266 	mov	a,r6
      005E4A F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005E4B 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      005E4C                       2277 _rgb_matrix_decrease_val_noeeprom:
      005E4C 90 07 2A         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005E4F 12 5E C8         [24] 2279 	lcall	_ak820_outline_0049
      005E52 11 2B            [12] 2280 	acall	_sub_sat
      005E54 AF 82            [24] 2281 	mov	r7, dpl
      005E56 90 07 2A         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005E59 EF               [12] 2283 	mov	a,r7
      005E5A F0               [24] 2284 	movx	@dptr,a
      005E5B 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      005E5C                       2293 _rgb_matrix_increase_speed_noeeprom:
      005E5C 90 07 2B         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005E5F 12 5E BD         [24] 2295 	lcall	_ak820_outline_0048
      005E62 11 06            [12] 2296 	acall	_add_sat
      005E64 AF 82            [24] 2297 	mov	r7, dpl
      005E66 90 07 2B         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005E69 EF               [12] 2299 	mov	a,r7
      005E6A F0               [24] 2300 	movx	@dptr,a
      005E6B 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      005E6C                       2309 _rgb_matrix_decrease_speed_noeeprom:
      005E6C 90 07 2B         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005E6F 12 5E C8         [24] 2311 	lcall	_ak820_outline_0049
      005E72 11 2B            [12] 2312 	acall	_sub_sat
      005E74 AF 82            [24] 2313 	mov	r7, dpl
      005E76 90 07 2B         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005E79 EF               [12] 2315 	mov	a,r7
      005E7A F0               [24] 2316 	movx	@dptr,a
      005E7B 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      005E7C                       2325 _rgb_matrix_toggle:
      005E7C B1 2A            [12] 2326 	acall	_rgb_matrix_toggle_noeeprom
      005E7E 01 48            [12] 2327 	ajmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      005E80                       2335 _rgb_matrix_step:
      005E80 B1 93            [12] 2336 	acall	_rgb_matrix_step_noeeprom
      005E82 01 48            [12] 2337 	ajmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      005E84                       2345 _rgb_matrix_step_reverse:
      005E84 B1 AC            [12] 2346 	acall	_rgb_matrix_step_reverse_noeeprom
      005E86 01 48            [12] 2347 	ajmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      005E88                       2355 _rgb_matrix_increase_hue:
      005E88 B1 FB            [12] 2356 	acall	_rgb_matrix_increase_hue_noeeprom
      005E8A 01 48            [12] 2357 	ajmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      005E8C                       2365 _rgb_matrix_decrease_hue:
      005E8C D1 06            [12] 2366 	acall	_rgb_matrix_decrease_hue_noeeprom
      005E8E 01 48            [12] 2367 	ajmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      005E90                       2375 _rgb_matrix_increase_sat:
      005E90 D1 11            [12] 2376 	acall	_rgb_matrix_increase_sat_noeeprom
      005E92 01 48            [12] 2377 	ajmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      005E94                       2385 _rgb_matrix_decrease_sat:
      005E94 D1 21            [12] 2386 	acall	_rgb_matrix_decrease_sat_noeeprom
      005E96 01 48            [12] 2387 	ajmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      005E98                       2395 _rgb_matrix_increase_val:
      005E98 D1 31            [12] 2396 	acall	_rgb_matrix_increase_val_noeeprom
      005E9A 01 48            [12] 2397 	ajmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      005E9C                       2405 _rgb_matrix_decrease_val:
      005E9C D1 4C            [12] 2406 	acall	_rgb_matrix_decrease_val_noeeprom
      005E9E 01 48            [12] 2407 	ajmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      005EA0                       2415 _rgb_matrix_increase_speed:
      005EA0 D1 5C            [12] 2416 	acall	_rgb_matrix_increase_speed_noeeprom
      005EA2 01 48            [12] 2417 	ajmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      005EA4                       2425 _rgb_matrix_decrease_speed:
      005EA4 D1 6C            [12] 2426 	acall	_rgb_matrix_decrease_speed_noeeprom
      005EA6 01 48            [12] 2427 	ajmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      005EA8                       2437 _rgb_matrix_mode:
      005EA8 E5 82            [12] 2438 	mov	a,dpl
      005EAA 90 07 B1         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005EAD 12 5F 16         [24] 2440 	lcall	_ak820_outline_0173
      005EB0 B1 5E            [12] 2441 	acall	_rgb_matrix_mode_noeeprom
      005EB2 01 48            [12] 2442 	ajmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00C1D5                       2455 _sine8_coefficients_10000_290:
      00C1D5 00                    2456 	.db #0x00	; 0
      00C1D6 31                    2457 	.db #0x31	; 49	'1'
      00C1D7 31                    2458 	.db #0x31	; 49	'1'
      00C1D8 29                    2459 	.db #0x29	; 41
      00C1D9 5A                    2460 	.db #0x5a	; 90	'Z'
      00C1DA 1B                    2461 	.db #0x1b	; 27
      00C1DB 75                    2462 	.db #0x75	; 117	'u'
      00C1DC 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0053
                                   2474 	.globl _ak820_outline_0060
                                   2475 	.globl _ak820_outline_0061
                                   2476 	.globl _ak820_outline_0066
                                   2477 	.globl _ak820_outline_0070
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0088
                                   2480 	.globl _ak820_outline_0104
                                   2481 	.globl _ak820_outline_0106
                                   2482 	.globl _ak820_outline_0110
                                   2483 	.globl _ak820_outline_0111
                                   2484 	.globl _ak820_outline_0112
                                   2485 	.globl _ak820_outline_0117
                                   2486 	.globl _ak820_outline_0126
                                   2487 	.globl _ak820_outline_0127
                                   2488 	.globl _ak820_outline_0136
                                   2489 	.globl _ak820_outline_0137
                                   2490 	.globl _ak820_outline_0140
                                   2491 	.globl _ak820_outline_0142
                                   2492 	.globl _ak820_outline_0162
                                   2493 	.globl _ak820_outline_0172
                                   2494 	.globl _ak820_outline_0173
                                   2495 	.globl _ak820_outline_0176
                                   2496 	.globl _ak820_outline_0181
                                   2497 	.globl _ak820_outline_0189
                                   2498 	.globl _ak820_outline_0191
                                   2499 	.globl _ak820_outline_0193
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      005EB4                       2503 _ak820_outline_0019:
      005EB4 90 07 27         [24] 2504 	mov	dptr,#_rgb_matrix_config
      005EB7 E0               [24] 2505 	movx	a,@dptr
      005EB8 03               [12] 2506 	rr	a
      005EB9 03               [12] 2507 	rr	a
      005EBA 54 3F            [12] 2508 	anl	a,#0x3f
      005EBC 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      005EBD                       2513 _ak820_outline_0048:
      005EBD E0               [24] 2514 	movx	a,@dptr
      005EBE FF               [12] 2515 	mov	r7,a
      005EBF 90 07 90         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      005EC2 74 10            [12] 2517 	mov	a,#0x10
      005EC4 F0               [24] 2518 	movx	@dptr,a
      005EC5 8F 82            [24] 2519 	mov	dpl,r7
      005EC7 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      005EC8                       2524 _ak820_outline_0049:
      005EC8 E0               [24] 2525 	movx	a,@dptr
      005EC9 FF               [12] 2526 	mov	r7,a
      005ECA 90 07 92         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005ECD 74 10            [12] 2528 	mov	a,#0x10
      005ECF F0               [24] 2529 	movx	@dptr,a
      005ED0 8F 82            [24] 2530 	mov	dpl,r7
      005ED2 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0066
      005ED3                       2535 _ak820_outline_0066:
      005ED3 90 07 27         [24] 2536 	mov	dptr,#_rgb_matrix_config
      005ED6 E0               [24] 2537 	movx	a,@dptr
      005ED7 54 03            [12] 2538 	anl	a,#0x03
      005ED9 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0070
      005EDA                       2543 _ak820_outline_0070:
      005EDA 74 08            [12] 2544 	mov	a,#0x08
      005EDC F0               [24] 2545 	movx	@dptr,a
      005EDD E4               [12] 2546 	clr	a
      005EDE A3               [24] 2547 	inc	dptr
      005EDF F0               [24] 2548 	movx	@dptr,a
      005EE0 90 07 27         [24] 2549 	mov	dptr,#_rgb_matrix_config
      005EE3 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      005EE4                       2554 _ak820_outline_0073:
      005EE4 A3               [24] 2555 	inc	dptr
      005EE5 F0               [24] 2556 	movx	@dptr,a
      005EE6 E4               [12] 2557 	clr	a
      005EE7 A3               [24] 2558 	inc	dptr
      005EE8 F0               [24] 2559 	movx	@dptr,a
      005EE9 90 0E 2B         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      005EEC 74 03            [12] 2561 	mov	a,#0x03
      005EEE F0               [24] 2562 	movx	@dptr,a
      005EEF E4               [12] 2563 	clr	a
      005EF0 A3               [24] 2564 	inc	dptr
      005EF1 F0               [24] 2565 	movx	@dptr,a
      005EF2 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0088
      005EF3                       2570 _ak820_outline_0088:
      005EF3 74 18            [12] 2571 	mov	a,#0x18
      005EF5 F0               [24] 2572 	movx	@dptr,a
      005EF6 E4               [12] 2573 	clr	a
      005EF7 A3               [24] 2574 	inc	dptr
      005EF8 F0               [24] 2575 	movx	@dptr,a
      005EF9 A3               [24] 2576 	inc	dptr
      005EFA F0               [24] 2577 	movx	@dptr,a
      005EFB 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0112
      005EFC                       2582 _ak820_outline_0112:
      005EFC 35 F0            [12] 2583 	addc	a,b
      005EFE F5 83            [12] 2584 	mov	dph,a
      005F00 E4               [12] 2585 	clr	a
      005F01 93               [24] 2586 	movc	a,@a+dptr
      005F02 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0117
      005F03                       2591 _ak820_outline_0117:
      005F03 90 07 27         [24] 2592 	mov	dptr,#_rgb_matrix_config
      005F06 E0               [24] 2593 	movx	a,@dptr
      005F07 54 FC            [12] 2594 	anl	a,#0xfc
      005F09 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0142
      005F0A                       2599 _ak820_outline_0142:
      005F0A 90 07 36         [24] 2600 	mov	dptr,#_frame_mode
      005F0D E0               [24] 2601 	movx	a,@dptr
      005F0E FE               [12] 2602 	mov	r6,a
      005F0F 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0172
      005F10                       2607 _ak820_outline_0172:
      005F10 F0               [24] 2608 	movx	@dptr,a
      005F11 E5 F0            [12] 2609 	mov	a,b
      005F13 A3               [24] 2610 	inc	dptr
      005F14 F0               [24] 2611 	movx	@dptr,a
      005F15 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0173
      005F16                       2616 _ak820_outline_0173:
      005F16 F0               [24] 2617 	movx	@dptr,a
      005F17 E0               [24] 2618 	movx	a,@dptr
      005F18 F5 82            [12] 2619 	mov	dpl,a
      005F1A 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0176
      005F1B                       2624 _ak820_outline_0176:
      005F1B 90 07 2B         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005F1E E0               [24] 2626 	movx	a,@dptr
      005F1F 23               [12] 2627 	rl	a
      005F20 23               [12] 2628 	rl	a
      005F21 54 03            [12] 2629 	anl	a,#0x03
      005F23 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0181
      005F24                       2634 _ak820_outline_0181:
      005F24 90 0E 30         [24] 2635 	mov	dptr,#_memset_PARM_2
      005F27 E4               [12] 2636 	clr	a
      005F28 F0               [24] 2637 	movx	@dptr,a
      005F29 90 0E 31         [24] 2638 	mov	dptr,#_memset_PARM_3
      005F2C 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0189
      005F2D                       2643 _ak820_outline_0189:
      005F2D 90 07 35         [24] 2644 	mov	dptr,#_led_index
      005F30 E0               [24] 2645 	movx	a,@dptr
      005F31 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0191
      005F32                       2650 _ak820_outline_0191:
      005F32 C4               [12] 2651 	swap	a
      005F33 23               [12] 2652 	rl	a
      005F34 54 1F            [12] 2653 	anl	a,#0x1f
      005F36 22               [24] 2654 	ret
