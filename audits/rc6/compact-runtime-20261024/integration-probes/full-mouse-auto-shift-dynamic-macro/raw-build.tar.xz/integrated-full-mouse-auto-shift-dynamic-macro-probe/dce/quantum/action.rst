                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _ak820_dynamic_macro_cancel
                                     25 	.globl _ak820_dynamic_macro_task
                                     26 	.globl _ak820_dynamic_macro_observe
                                     27 	.globl _ak820_dynamic_macro_process
                                     28 	.globl _pre_process_record_quantum
                                     29 	.globl _get_record_keycode
                                     30 	.globl _get_repeat_key_count
                                     31 	.globl _repeat_key_cancel
                                     32 	.globl _clear_owned_usages
                                     33 	.globl _owned_usage_key
                                     34 	.globl _clear_owned_keys
                                     35 	.globl _del_owned_key
                                     36 	.globl _add_owned_key
                                     37 	.globl _clear_owned_mods
                                     38 	.globl _del_owned_weak_mods
                                     39 	.globl _add_owned_weak_mods
                                     40 	.globl _del_owned_mods
                                     41 	.globl _add_owned_mods
                                     42 	.globl _clear_weak_mods
                                     43 	.globl _clear_mods
                                     44 	.globl _send_keyboard_report
                                     45 	.globl _layer_hold_clear
                                     46 	.globl _layer_hold_off
                                     47 	.globl _layer_hold_on
                                     48 	.globl _ak820_resolve_key
                                     49 	.globl _layer_xor
                                     50 	.globl _layer_and
                                     51 	.globl _layer_or
                                     52 	.globl _layer_off
                                     53 	.globl _layer_on
                                     54 	.globl _layer_move
                                     55 	.globl _layer_clear
                                     56 	.globl _layer_state_set
                                     57 	.globl _default_layer_xor
                                     58 	.globl _default_layer_and
                                     59 	.globl _default_layer_or
                                     60 	.globl _default_layer_set
                                     61 	.globl _post_process_record_quantum
                                     62 	.globl _process_record_quantum
                                     63 	.globl _action_for_keycode
                                     64 	.globl _mousekey_send
                                     65 	.globl _mousekey_clear
                                     66 	.globl _mousekey_off
                                     67 	.globl _mousekey_on
                                     68 	.globl _mDelaymS
                                     69 	.globl _host_consumer_send
                                     70 	.globl _host_system_send
                                     71 	.globl _host_keyboard_leds
                                     72 	.globl _led_set
                                     73 	.globl _clear_keys_from_report
                                     74 	.globl ___memcpy
                                     75 	.globl _ADC_START
                                     76 	.globl _S0_R_FIFO
                                     77 	.globl _S0_T_FIFO
                                     78 	.globl _S0_FREE
                                     79 	.globl _S0_IF_BYTE
                                     80 	.globl _S0_IF_FIRST
                                     81 	.globl _S0_IF_OV
                                     82 	.globl _S0_FST_ACT
                                     83 	.globl _CP_RL2
                                     84 	.globl _C_T2
                                     85 	.globl _TR2
                                     86 	.globl _EXEN2
                                     87 	.globl _TCLK
                                     88 	.globl _RCLK
                                     89 	.globl _EXF2
                                     90 	.globl _CAP1F
                                     91 	.globl _TF2
                                     92 	.globl _RI
                                     93 	.globl _TI
                                     94 	.globl _RB8
                                     95 	.globl _TB8
                                     96 	.globl _REN
                                     97 	.globl _SM2
                                     98 	.globl _SM1
                                     99 	.globl _SM0
                                    100 	.globl _IT0
                                    101 	.globl _IE0
                                    102 	.globl _IT1
                                    103 	.globl _IE1
                                    104 	.globl _TR0
                                    105 	.globl _TF0
                                    106 	.globl _TR1
                                    107 	.globl _TF1
                                    108 	.globl _P4_0
                                    109 	.globl _P4_1
                                    110 	.globl _P4_2
                                    111 	.globl _P4_3
                                    112 	.globl _P4_4
                                    113 	.globl _P4_5
                                    114 	.globl _P4_6
                                    115 	.globl _RXD
                                    116 	.globl _TXD
                                    117 	.globl _INT0
                                    118 	.globl _INT1
                                    119 	.globl _T0
                                    120 	.globl _T1
                                    121 	.globl _MOSI1
                                    122 	.globl _MISO1
                                    123 	.globl _SCK1
                                    124 	.globl _P3_0
                                    125 	.globl _P3_1
                                    126 	.globl _P3_2
                                    127 	.globl _P3_3
                                    128 	.globl _P3_4
                                    129 	.globl _P3_5
                                    130 	.globl _P3_6
                                    131 	.globl _P3_7
                                    132 	.globl _CAP1_
                                    133 	.globl _T2_
                                    134 	.globl _CAP2_
                                    135 	.globl _T2EX_
                                    136 	.globl _RXD1
                                    137 	.globl _TXD1
                                    138 	.globl _P2_0
                                    139 	.globl _P2_1
                                    140 	.globl _P2_2
                                    141 	.globl _P2_3
                                    142 	.globl _P2_4
                                    143 	.globl _P2_5
                                    144 	.globl _P2_6
                                    145 	.globl _P2_7
                                    146 	.globl _AIN0
                                    147 	.globl _AIN1
                                    148 	.globl _AIN2
                                    149 	.globl _AIN3
                                    150 	.globl _AIN4
                                    151 	.globl _AIN5
                                    152 	.globl _AIN6
                                    153 	.globl _AIN7
                                    154 	.globl _CAP1
                                    155 	.globl _T2
                                    156 	.globl _CAP2
                                    157 	.globl _T2EX
                                    158 	.globl _INT0_
                                    159 	.globl _SCS
                                    160 	.globl _MOSI
                                    161 	.globl _MISO
                                    162 	.globl _SCK
                                    163 	.globl _RXD1_
                                    164 	.globl _TXD1_
                                    165 	.globl _P1_0
                                    166 	.globl _P1_1
                                    167 	.globl _P1_2
                                    168 	.globl _P1_3
                                    169 	.globl _P1_4
                                    170 	.globl _P1_5
                                    171 	.globl _P1_6
                                    172 	.globl _P1_7
                                    173 	.globl _AIN8
                                    174 	.globl _AIN9
                                    175 	.globl _AIN10
                                    176 	.globl _AIN11
                                    177 	.globl _AIN12
                                    178 	.globl _AIN13
                                    179 	.globl _RXD_
                                    180 	.globl _TXD_
                                    181 	.globl _SCL0
                                    182 	.globl _SDA0
                                    183 	.globl _P0_0
                                    184 	.globl _P0_1
                                    185 	.globl _P0_2
                                    186 	.globl _P0_3
                                    187 	.globl _P0_4
                                    188 	.globl _P0_5
                                    189 	.globl _P0_6
                                    190 	.globl _P0_7
                                    191 	.globl _IE_SPI0
                                    192 	.globl _IE_USB
                                    193 	.globl _IE_ADC
                                    194 	.globl _IE_UART1
                                    195 	.globl _IE_PWM_I2C
                                    196 	.globl _IE_GPIO
                                    197 	.globl _IE_WDOG
                                    198 	.globl _PX0
                                    199 	.globl _PT0
                                    200 	.globl _PX1
                                    201 	.globl _PT1
                                    202 	.globl _PS
                                    203 	.globl _PT2
                                    204 	.globl _PL_FLAG
                                    205 	.globl _PH_FLAG
                                    206 	.globl _EX0
                                    207 	.globl _ET0
                                    208 	.globl _EX1
                                    209 	.globl _ET1
                                    210 	.globl _ES
                                    211 	.globl _ET2
                                    212 	.globl _E_DIS
                                    213 	.globl _EA
                                    214 	.globl _P
                                    215 	.globl _F1
                                    216 	.globl _OV
                                    217 	.globl _RS0
                                    218 	.globl _RS1
                                    219 	.globl _F0
                                    220 	.globl _AC
                                    221 	.globl _CY
                                    222 	.globl _I2CS_INT_ST
                                    223 	.globl _I2CX_INT
                                    224 	.globl _LED_STATUS
                                    225 	.globl _LED_DMA_H
                                    226 	.globl _LED_DMA_L
                                    227 	.globl _LED_DMA
                                    228 	.globl _LED_PWM_OE
                                    229 	.globl _LED_COMMON
                                    230 	.globl _ADC_CHAN
                                    231 	.globl _ADC_DAT_H
                                    232 	.globl _ADC_DAT_L
                                    233 	.globl _ADC_DAT
                                    234 	.globl _ADC_CTRL
                                    235 	.globl _SPI1_CK_SE
                                    236 	.globl _SPI1_CTRL
                                    237 	.globl _SPI1_DATA
                                    238 	.globl _SPI1_STAT
                                    239 	.globl _SIF1
                                    240 	.globl _SBAUD1
                                    241 	.globl _SBUF1
                                    242 	.globl _SCON1
                                    243 	.globl _SPI0_SETUP
                                    244 	.globl _SPI0_CK_SE
                                    245 	.globl _SPI0_CTRL
                                    246 	.globl _SPI0_DATA
                                    247 	.globl _SPI0_STAT
                                    248 	.globl _T2CAP1H
                                    249 	.globl _T2CAP1L
                                    250 	.globl _T2CAP1
                                    251 	.globl _TH2
                                    252 	.globl _TL2
                                    253 	.globl _T2COUNT
                                    254 	.globl _RCAP2H
                                    255 	.globl _RCAP2L
                                    256 	.globl _RCAP2
                                    257 	.globl _T2MOD
                                    258 	.globl _T2CON
                                    259 	.globl _SBUF
                                    260 	.globl _SCON
                                    261 	.globl _TH1
                                    262 	.globl _TH0
                                    263 	.globl _TL1
                                    264 	.globl _TL0
                                    265 	.globl _TMOD
                                    266 	.globl _TCON
                                    267 	.globl _XBUS_AUX
                                    268 	.globl _P7
                                    269 	.globl _P6_DIR
                                    270 	.globl _P6_OUT_PU
                                    271 	.globl _P6_IN
                                    272 	.globl _P5_DIR
                                    273 	.globl _P5_OUT_PU
                                    274 	.globl _P5_IN
                                    275 	.globl _P4_LED_KEY
                                    276 	.globl _P4_DIR_PU
                                    277 	.globl _P4_MOD_OC
                                    278 	.globl _P4
                                    279 	.globl _P3_DIR_PU
                                    280 	.globl _P3_MOD_OC
                                    281 	.globl _P3
                                    282 	.globl _P2_DIR_PU
                                    283 	.globl _P2_MOD_OC
                                    284 	.globl _P2
                                    285 	.globl _P1_DIR_PU
                                    286 	.globl _P1_MOD_OC
                                    287 	.globl _P1
                                    288 	.globl _P0_DIR_PU
                                    289 	.globl _P0_MOD_OC
                                    290 	.globl _P0
                                    291 	.globl _ROM_CTRL
                                    292 	.globl _ROM_DATA_HH
                                    293 	.globl _ROM_DATA_HL
                                    294 	.globl _ROM_DATA_HI
                                    295 	.globl _ROM_ADDR_H
                                    296 	.globl _ROM_ADDR_L
                                    297 	.globl _ROM_ADDR
                                    298 	.globl _GPIO_IE
                                    299 	.globl _IP_EX
                                    300 	.globl _IE_EX
                                    301 	.globl _IP
                                    302 	.globl _IE
                                    303 	.globl _WDOG_COUNT
                                    304 	.globl _RESET_KEEP
                                    305 	.globl _WAKE_CTRL
                                    306 	.globl _CLOCK_CFG
                                    307 	.globl _POWER_CFG
                                    308 	.globl _PCON
                                    309 	.globl _GLOBAL_CFG
                                    310 	.globl _SAFE_MOD
                                    311 	.globl _DPH
                                    312 	.globl _DPL
                                    313 	.globl _SP
                                    314 	.globl _A_INV
                                    315 	.globl _B
                                    316 	.globl _ACC
                                    317 	.globl _PSW
                                    318 	.globl _disable_action_cache
                                    319 	.globl _tap_code_delay_PARM_2
                                    320 	.globl _process_action_PARM_2
                                    321 	.globl _register_mouse_PARM_2
                                    322 	.globl _action_exec_PARM_1
                                    323 	.globl _tp_buttons
                                    324 	.globl _action_exec
                                    325 	.globl _ak820_action_exec
                                    326 	.globl _process_record
                                    327 	.globl _process_record_handler
                                    328 	.globl _process_action
                                    329 	.globl _register_code
                                    330 	.globl _unregister_code
                                    331 	.globl _tap_code_delay
                                    332 	.globl _tap_code
                                    333 	.globl _register_mods
                                    334 	.globl _unregister_mods
                                    335 	.globl _register_weak_mods
                                    336 	.globl _unregister_weak_mods
                                    337 	.globl _clear_keyboard
                                    338 	.globl _clear_keyboard_but_mods
                                    339 	.globl _clear_keyboard_but_mods_and_keys
                                    340 ;--------------------------------------------------------
                                    341 ; special function registers
                                    342 ;--------------------------------------------------------
                                    343 	.area RSEG    (ABS,DATA)
      000000                        344 	.org 0x0000
                           0000D0   345 _PSW	=	0x00d0
                           0000E0   346 _ACC	=	0x00e0
                           0000F0   347 _B	=	0x00f0
                           0000FD   348 _A_INV	=	0x00fd
                           000081   349 _SP	=	0x0081
                           000082   350 _DPL	=	0x0082
                           000083   351 _DPH	=	0x0083
                           0000A1   352 _SAFE_MOD	=	0x00a1
                           0000B1   353 _GLOBAL_CFG	=	0x00b1
                           000087   354 _PCON	=	0x0087
                           0000BA   355 _POWER_CFG	=	0x00ba
                           0000B9   356 _CLOCK_CFG	=	0x00b9
                           0000A9   357 _WAKE_CTRL	=	0x00a9
                           0000FE   358 _RESET_KEEP	=	0x00fe
                           0000FF   359 _WDOG_COUNT	=	0x00ff
                           0000A8   360 _IE	=	0x00a8
                           0000B8   361 _IP	=	0x00b8
                           0000E8   362 _IE_EX	=	0x00e8
                           0000E9   363 _IP_EX	=	0x00e9
                           0000B2   364 _GPIO_IE	=	0x00b2
                           008584   365 _ROM_ADDR	=	0x8584
                           000084   366 _ROM_ADDR_L	=	0x0084
                           000085   367 _ROM_ADDR_H	=	0x0085
                           008F8E   368 _ROM_DATA_HI	=	0x8f8e
                           00008E   369 _ROM_DATA_HL	=	0x008e
                           00008F   370 _ROM_DATA_HH	=	0x008f
                           000086   371 _ROM_CTRL	=	0x0086
                           000080   372 _P0	=	0x0080
                           0000C4   373 _P0_MOD_OC	=	0x00c4
                           0000C5   374 _P0_DIR_PU	=	0x00c5
                           000090   375 _P1	=	0x0090
                           000092   376 _P1_MOD_OC	=	0x0092
                           000093   377 _P1_DIR_PU	=	0x0093
                           0000A0   378 _P2	=	0x00a0
                           000094   379 _P2_MOD_OC	=	0x0094
                           000095   380 _P2_DIR_PU	=	0x0095
                           0000B0   381 _P3	=	0x00b0
                           000096   382 _P3_MOD_OC	=	0x0096
                           000097   383 _P3_DIR_PU	=	0x0097
                           0000C0   384 _P4	=	0x00c0
                           0000C2   385 _P4_MOD_OC	=	0x00c2
                           0000C3   386 _P4_DIR_PU	=	0x00c3
                           0000C1   387 _P4_LED_KEY	=	0x00c1
                           0000AA   388 _P5_IN	=	0x00aa
                           0000AB   389 _P5_OUT_PU	=	0x00ab
                           0000AC   390 _P5_DIR	=	0x00ac
                           0000AD   391 _P6_IN	=	0x00ad
                           0000AE   392 _P6_OUT_PU	=	0x00ae
                           0000AF   393 _P6_DIR	=	0x00af
                           0000F1   394 _P7	=	0x00f1
                           0000A2   395 _XBUS_AUX	=	0x00a2
                           000088   396 _TCON	=	0x0088
                           000089   397 _TMOD	=	0x0089
                           00008A   398 _TL0	=	0x008a
                           00008B   399 _TL1	=	0x008b
                           00008C   400 _TH0	=	0x008c
                           00008D   401 _TH1	=	0x008d
                           000098   402 _SCON	=	0x0098
                           000099   403 _SBUF	=	0x0099
                           0000C8   404 _T2CON	=	0x00c8
                           0000C9   405 _T2MOD	=	0x00c9
                           00CBCA   406 _RCAP2	=	0xcbca
                           0000CA   407 _RCAP2L	=	0x00ca
                           0000CB   408 _RCAP2H	=	0x00cb
                           00CDCC   409 _T2COUNT	=	0xcdcc
                           0000CC   410 _TL2	=	0x00cc
                           0000CD   411 _TH2	=	0x00cd
                           00CFCE   412 _T2CAP1	=	0xcfce
                           0000CE   413 _T2CAP1L	=	0x00ce
                           0000CF   414 _T2CAP1H	=	0x00cf
                           0000F8   415 _SPI0_STAT	=	0x00f8
                           0000F9   416 _SPI0_DATA	=	0x00f9
                           0000FA   417 _SPI0_CTRL	=	0x00fa
                           0000FB   418 _SPI0_CK_SE	=	0x00fb
                           0000FC   419 _SPI0_SETUP	=	0x00fc
                           0000BC   420 _SCON1	=	0x00bc
                           0000BD   421 _SBUF1	=	0x00bd
                           0000BE   422 _SBAUD1	=	0x00be
                           0000BF   423 _SIF1	=	0x00bf
                           0000B4   424 _SPI1_STAT	=	0x00b4
                           0000B5   425 _SPI1_DATA	=	0x00b5
                           0000B6   426 _SPI1_CTRL	=	0x00b6
                           0000B7   427 _SPI1_CK_SE	=	0x00b7
                           0000F3   428 _ADC_CTRL	=	0x00f3
                           00F5F4   429 _ADC_DAT	=	0xf5f4
                           0000F4   430 _ADC_DAT_L	=	0x00f4
                           0000F5   431 _ADC_DAT_H	=	0x00f5
                           0000F6   432 _ADC_CHAN	=	0x00f6
                           0000A6   433 _LED_COMMON	=	0x00a6
                           0000A7   434 _LED_PWM_OE	=	0x00a7
                           00C7C6   435 _LED_DMA	=	0xc7c6
                           0000C6   436 _LED_DMA_L	=	0x00c6
                           0000C7   437 _LED_DMA_H	=	0x00c7
                           0000F7   438 _LED_STATUS	=	0x00f7
                           0000B3   439 _I2CX_INT	=	0x00b3
                           0000BB   440 _I2CS_INT_ST	=	0x00bb
                                    441 ;--------------------------------------------------------
                                    442 ; special function bits
                                    443 ;--------------------------------------------------------
                                    444 	.area RSEG    (ABS,DATA)
      000000                        445 	.org 0x0000
                           0000D7   446 _CY	=	0x00d7
                           0000D6   447 _AC	=	0x00d6
                           0000D5   448 _F0	=	0x00d5
                           0000D4   449 _RS1	=	0x00d4
                           0000D3   450 _RS0	=	0x00d3
                           0000D2   451 _OV	=	0x00d2
                           0000D1   452 _F1	=	0x00d1
                           0000D0   453 _P	=	0x00d0
                           0000AF   454 _EA	=	0x00af
                           0000AE   455 _E_DIS	=	0x00ae
                           0000AD   456 _ET2	=	0x00ad
                           0000AC   457 _ES	=	0x00ac
                           0000AB   458 _ET1	=	0x00ab
                           0000AA   459 _EX1	=	0x00aa
                           0000A9   460 _ET0	=	0x00a9
                           0000A8   461 _EX0	=	0x00a8
                           0000BF   462 _PH_FLAG	=	0x00bf
                           0000BE   463 _PL_FLAG	=	0x00be
                           0000BD   464 _PT2	=	0x00bd
                           0000BC   465 _PS	=	0x00bc
                           0000BB   466 _PT1	=	0x00bb
                           0000BA   467 _PX1	=	0x00ba
                           0000B9   468 _PT0	=	0x00b9
                           0000B8   469 _PX0	=	0x00b8
                           0000EF   470 _IE_WDOG	=	0x00ef
                           0000EE   471 _IE_GPIO	=	0x00ee
                           0000ED   472 _IE_PWM_I2C	=	0x00ed
                           0000EC   473 _IE_UART1	=	0x00ec
                           0000EB   474 _IE_ADC	=	0x00eb
                           0000E9   475 _IE_USB	=	0x00e9
                           0000E8   476 _IE_SPI0	=	0x00e8
                           000087   477 _P0_7	=	0x0087
                           000086   478 _P0_6	=	0x0086
                           000085   479 _P0_5	=	0x0085
                           000084   480 _P0_4	=	0x0084
                           000083   481 _P0_3	=	0x0083
                           000082   482 _P0_2	=	0x0082
                           000081   483 _P0_1	=	0x0081
                           000080   484 _P0_0	=	0x0080
                           000081   485 _SDA0	=	0x0081
                           000080   486 _SCL0	=	0x0080
                           000083   487 _TXD_	=	0x0083
                           000082   488 _RXD_	=	0x0082
                           000085   489 _AIN13	=	0x0085
                           000084   490 _AIN12	=	0x0084
                           000083   491 _AIN11	=	0x0083
                           000082   492 _AIN10	=	0x0082
                           000081   493 _AIN9	=	0x0081
                           000080   494 _AIN8	=	0x0080
                           000097   495 _P1_7	=	0x0097
                           000096   496 _P1_6	=	0x0096
                           000095   497 _P1_5	=	0x0095
                           000094   498 _P1_4	=	0x0094
                           000093   499 _P1_3	=	0x0093
                           000092   500 _P1_2	=	0x0092
                           000091   501 _P1_1	=	0x0091
                           000090   502 _P1_0	=	0x0090
                           000097   503 _TXD1_	=	0x0097
                           000096   504 _RXD1_	=	0x0096
                           000097   505 _SCK	=	0x0097
                           000096   506 _MISO	=	0x0096
                           000095   507 _MOSI	=	0x0095
                           000094   508 _SCS	=	0x0094
                           000092   509 _INT0_	=	0x0092
                           000091   510 _T2EX	=	0x0091
                           000091   511 _CAP2	=	0x0091
                           000090   512 _T2	=	0x0090
                           000090   513 _CAP1	=	0x0090
                           000097   514 _AIN7	=	0x0097
                           000096   515 _AIN6	=	0x0096
                           000095   516 _AIN5	=	0x0095
                           000094   517 _AIN4	=	0x0094
                           000093   518 _AIN3	=	0x0093
                           000092   519 _AIN2	=	0x0092
                           000091   520 _AIN1	=	0x0091
                           000090   521 _AIN0	=	0x0090
                           0000A7   522 _P2_7	=	0x00a7
                           0000A6   523 _P2_6	=	0x00a6
                           0000A5   524 _P2_5	=	0x00a5
                           0000A4   525 _P2_4	=	0x00a4
                           0000A3   526 _P2_3	=	0x00a3
                           0000A2   527 _P2_2	=	0x00a2
                           0000A1   528 _P2_1	=	0x00a1
                           0000A0   529 _P2_0	=	0x00a0
                           0000A7   530 _TXD1	=	0x00a7
                           0000A6   531 _RXD1	=	0x00a6
                           0000A5   532 _T2EX_	=	0x00a5
                           0000A5   533 _CAP2_	=	0x00a5
                           0000A4   534 _T2_	=	0x00a4
                           0000A4   535 _CAP1_	=	0x00a4
                           0000B7   536 _P3_7	=	0x00b7
                           0000B6   537 _P3_6	=	0x00b6
                           0000B5   538 _P3_5	=	0x00b5
                           0000B4   539 _P3_4	=	0x00b4
                           0000B3   540 _P3_3	=	0x00b3
                           0000B2   541 _P3_2	=	0x00b2
                           0000B1   542 _P3_1	=	0x00b1
                           0000B0   543 _P3_0	=	0x00b0
                           0000B7   544 _SCK1	=	0x00b7
                           0000B6   545 _MISO1	=	0x00b6
                           0000B5   546 _MOSI1	=	0x00b5
                           0000B5   547 _T1	=	0x00b5
                           0000B4   548 _T0	=	0x00b4
                           0000B3   549 _INT1	=	0x00b3
                           0000B2   550 _INT0	=	0x00b2
                           0000B1   551 _TXD	=	0x00b1
                           0000B0   552 _RXD	=	0x00b0
                           0000C6   553 _P4_6	=	0x00c6
                           0000C5   554 _P4_5	=	0x00c5
                           0000C4   555 _P4_4	=	0x00c4
                           0000C3   556 _P4_3	=	0x00c3
                           0000C2   557 _P4_2	=	0x00c2
                           0000C1   558 _P4_1	=	0x00c1
                           0000C0   559 _P4_0	=	0x00c0
                           00008F   560 _TF1	=	0x008f
                           00008E   561 _TR1	=	0x008e
                           00008D   562 _TF0	=	0x008d
                           00008C   563 _TR0	=	0x008c
                           00008B   564 _IE1	=	0x008b
                           00008A   565 _IT1	=	0x008a
                           000089   566 _IE0	=	0x0089
                           000088   567 _IT0	=	0x0088
                           00009F   568 _SM0	=	0x009f
                           00009E   569 _SM1	=	0x009e
                           00009D   570 _SM2	=	0x009d
                           00009C   571 _REN	=	0x009c
                           00009B   572 _TB8	=	0x009b
                           00009A   573 _RB8	=	0x009a
                           000099   574 _TI	=	0x0099
                           000098   575 _RI	=	0x0098
                           0000CF   576 _TF2	=	0x00cf
                           0000CF   577 _CAP1F	=	0x00cf
                           0000CE   578 _EXF2	=	0x00ce
                           0000CD   579 _RCLK	=	0x00cd
                           0000CC   580 _TCLK	=	0x00cc
                           0000CB   581 _EXEN2	=	0x00cb
                           0000CA   582 _TR2	=	0x00ca
                           0000C9   583 _C_T2	=	0x00c9
                           0000C8   584 _CP_RL2	=	0x00c8
                           0000FF   585 _S0_FST_ACT	=	0x00ff
                           0000FE   586 _S0_IF_OV	=	0x00fe
                           0000FD   587 _S0_IF_FIRST	=	0x00fd
                           0000FC   588 _S0_IF_BYTE	=	0x00fc
                           0000FB   589 _S0_FREE	=	0x00fb
                           0000FA   590 _S0_T_FIFO	=	0x00fa
                           0000F8   591 _S0_R_FIFO	=	0x00f8
                           0000F7   592 _ADC_START	=	0x00f7
                                    593 ;--------------------------------------------------------
                                    594 ; overlayable register banks
                                    595 ;--------------------------------------------------------
                                    596 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        597 	.ds 8
                                    598 ;--------------------------------------------------------
                                    599 ; internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area DSEG    (DATA)
      000027                        602 _process_record_sloc0_1_0:
      000027                        603 	.ds 1
      000028                        604 _process_action_sloc0_1_0:
      000028                        605 	.ds 1
                                    606 ;--------------------------------------------------------
                                    607 ; overlayable items in internal ram
                                    608 ;--------------------------------------------------------
                                    609 ;--------------------------------------------------------
                                    610 ; indirectly addressable internal ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area ISEG    (DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; absolute internal ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area IABS    (ABS,DATA)
                                    617 	.area IABS    (ABS,DATA)
                                    618 ;--------------------------------------------------------
                                    619 ; bit data
                                    620 ;--------------------------------------------------------
                                    621 	.area BSEG    (BIT)
      000022                        622 _process_action_sloc1_1_0:
      000022                        623 	.ds 1
                                    624 ;--------------------------------------------------------
                                    625 ; paged external ram data
                                    626 ;--------------------------------------------------------
                                    627 	.area PSEG    (PAG,XDATA)
                                    628 ;--------------------------------------------------------
                                    629 ; uninitialized external ram data
                                    630 ;--------------------------------------------------------
                                    631 	.area XSEG    (XDATA)
      000897                        632 _tp_buttons::
      000897                        633 	.ds 2
      000899                        634 _action_exec_PARM_1:
      000899                        635 	.ds 6
      00089F                        636 _action_exec_record_10001_634:
      00089F                        637 	.ds 9
      0008A8                        638 _ak820_action_exec_event_10000_639:
      0008A8                        639 	.ds 2
      0008AA                        640 _ak820_action_exec_snapshot_10000_640:
      0008AA                        641 	.ds 6
      0008B0                        642 _process_record_record_10000_643:
      0008B0                        643 	.ds 3
      0008B3                        644 _process_record_handler_record_argument_10000_652:
      0008B3                        645 	.ds 3
      0008B6                        646 _process_record_handler_action_10000_653:
      0008B6                        647 	.ds 2
      0008B8                        648 _register_mouse_PARM_2:
      0008B8                        649 	.ds 1
      0008B9                        650 _register_mouse_mouse_keycode_10000_661:
      0008B9                        651 	.ds 1
      0008BA                        652 _process_action_PARM_2:
      0008BA                        653 	.ds 2
      0008BC                        654 _process_action_record_argument_10000_668:
      0008BC                        655 	.ds 3
      0008BF                        656 _process_action_on_40000_691:
      0008BF                        657 	.ds 1
      0008C0                        658 _register_code_code_10000_725:
      0008C0                        659 	.ds 1
      0008C1                        660 _unregister_code_code_10000_739:
      0008C1                        661 	.ds 1
      0008C2                        662 _tap_code_delay_PARM_2:
      0008C2                        663 	.ds 2
      0008C4                        664 _tap_code_delay_code_10000_752:
      0008C4                        665 	.ds 1
      0008C5                        666 _tap_code_code_10000_759:
      0008C5                        667 	.ds 1
      0008C6                        668 _register_mods_mods_10000_761:
      0008C6                        669 	.ds 1
      0008C7                        670 _unregister_mods_mods_10000_765:
      0008C7                        671 	.ds 1
      0008C8                        672 _register_weak_mods_mods_10000_769:
      0008C8                        673 	.ds 1
      0008C9                        674 _unregister_weak_mods_mods_10000_773:
      0008C9                        675 	.ds 1
                                    676 ;--------------------------------------------------------
                                    677 ; absolute external ram data
                                    678 ;--------------------------------------------------------
                                    679 	.area XABS    (ABS,XDATA)
                                    680 ;--------------------------------------------------------
                                    681 ; initialized external ram data
                                    682 ;--------------------------------------------------------
                                    683 	.area XISEG   (XDATA)
      000E49                        684 _disable_action_cache::
      000E49                        685 	.ds 1
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function action_exec
                                    728 ;	-----------------------------------------
      007854                        729 _action_exec:
                                    730 ;	quantum/action.c:89: ak820_dynamic_macro_task(event.time);
      007854 90 08 9B         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007857 12 3A 34         [24]  732 	lcall	_ak820_outline_0005
      00785A 12 3D 66         [24]  733 	lcall	_ak820_dynamic_macro_task
                                    734 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      00785D 90 08 9B         [24]  735 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007860 12 3A 34         [24]  736 	lcall	_ak820_outline_0005
      007863 12 38 4B         [24]  737 	lcall	_ak820_combo_tick
                                    738 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      007866 90 08 99         [24]  739 	mov	dptr,#_action_exec_PARM_1
      007869 12 49 DF         [24]  740 	lcall	_ak820_tapping_before
      00786C E5 82            [12]  741 	mov	a, dpl
      00786E 70 01            [24]  742 	jnz	00102$
      007870 22               [24]  743 	ret
      007871                        744 00102$:
                                    745 ;	quantum/action.c:97: if (!ak820_autoshift_before(&event)) return;
      007871 90 08 99         [24]  746 	mov	dptr,#_action_exec_PARM_1
      007874 12 31 2D         [24]  747 	lcall	_ak820_autoshift_before
      007877 E5 82            [12]  748 	mov	a, dpl
      007879 70 01            [24]  749 	jnz	00104$
      00787B 22               [24]  750 	ret
      00787C                        751 00104$:
                                    752 ;	quantum/action.c:113: if (event.pressed) {
      00787C 90 08 9E         [24]  753 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00787F E0               [24]  754 	movx	a,@dptr
      007880 60 03            [24]  755 	jz	00106$
                                    756 ;	quantum/action.c:115: clear_weak_mods();
      007882 12 89 F0         [24]  757 	lcall	_clear_weak_mods
      007885                        758 00106$:
                                    759 ;	quantum/action.c:127: record.event = event;
      007885 90 0E 28         [24]  760 	mov	dptr,#___memcpy_PARM_2
      007888 74 99            [12]  761 	mov	a,#_action_exec_PARM_1
      00788A F0               [24]  762 	movx	@dptr,a
      00788B 74 08            [12]  763 	mov	a,#(_action_exec_PARM_1 >> 8)
      00788D 12 3A B0         [24]  764 	lcall	_ak820_outline_0095
      007890 12 80 74         [24]  765 	lcall	_ak820_outline_0071
      007893 90 08 9F         [24]  766 	mov	dptr,#_action_exec_record_10001_634
      007896 F5 F0            [12]  767 	mov	b,a
      007898 12 C0 97         [24]  768 	lcall	___memcpy
                                    769 ;	quantum/action.c:129: record.tap.count = 0;
      00789B 90 08 A5         [24]  770 	mov	dptr,#(_action_exec_record_10001_634 + 0x0006)
      00789E E0               [24]  771 	movx	a,@dptr
      00789F 54 0F            [12]  772 	anl	a,#0x0f
      0078A1 F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/action.c:134: record.keycode = 0;
      0078A2 90 08 A6         [24]  775 	mov	dptr,#(_action_exec_record_10001_634 + 0x0007)
      0078A5 12 55 02         [24]  776 	lcall	_ak820_outline_0184
                                    777 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0078A8 90 08 A3         [24]  778 	mov	dptr,#(_action_exec_record_10001_634 + 0x0004)
      0078AB E0               [24]  779 	movx	a,@dptr
      0078AC 60 0D            [24]  780 	jz	00111$
      0078AE 90 08 9F         [24]  781 	mov	dptr,#_action_exec_record_10001_634
      0078B1 75 F0 00         [24]  782 	mov	b, #0x00
      0078B4 12 A7 88         [24]  783 	lcall	_pre_process_record_quantum
      0078B7 E5 82            [12]  784 	mov	a, dpl
      0078B9 60 1E            [24]  785 	jz	00114$
      0078BB                        786 00111$:
                                    787 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      0078BB 90 08 9F         [24]  788 	mov	dptr,#_action_exec_record_10001_634
      0078BE 12 4A C4         [24]  789 	lcall	_ak820_tapping_process
      0078C1 E5 82            [12]  790 	mov	a, dpl
      0078C3 70 01            [24]  791 	jnz	00108$
      0078C5 22               [24]  792 	ret
      0078C6                        793 00108$:
                                    794 ;	quantum/action.c:169: if (!ak820_autoshift_process(&record)) return;
      0078C6 90 08 9F         [24]  795 	mov	dptr,#_action_exec_record_10001_634
      0078C9 12 32 35         [24]  796 	lcall	_ak820_autoshift_process
      0078CC E5 82            [12]  797 	mov	a, dpl
      0078CE 70 01            [24]  798 	jnz	00110$
      0078D0 22               [24]  799 	ret
      0078D1                        800 00110$:
                                    801 ;	quantum/action.c:172: process_record(&record);
      0078D1 90 08 9F         [24]  802 	mov	dptr,#_action_exec_record_10001_634
      0078D4 75 F0 00         [24]  803 	mov	b, #0x00
                                    804 ;	quantum/action.c:182: }
      0078D7 21 15            [12]  805 	ajmp	_process_record
      0078D9                        806 00114$:
      0078D9 22               [24]  807 	ret
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'ak820_action_exec'
                                    810 ;------------------------------------------------------------
                                    811 ;event         Allocated with name '_ak820_action_exec_event_10000_639'
                                    812 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_640'
                                    813 ;------------------------------------------------------------
                                    814 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    815 ;	-----------------------------------------
                                    816 ;	 function ak820_action_exec
                                    817 ;	-----------------------------------------
      0078DA                        818 _ak820_action_exec:
      0078DA 12 3A C2         [24]  819 	lcall	_ak820_outline_0110
      0078DD 90 08 A8         [24]  820 	mov	dptr,#_ak820_action_exec_event_10000_639
      0078E0 12 3A C7         [24]  821 	lcall	_ak820_outline_0111
                                    822 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      0078E3 90 08 A8         [24]  823 	mov	dptr,#_ak820_action_exec_event_10000_639
      0078E6 12 3A A4         [24]  824 	lcall	_ak820_outline_0080
      0078E9 7F 00            [12]  825 	mov	r7,#0x00
      0078EB 90 0E 28         [24]  826 	mov	dptr,#___memcpy_PARM_2
      0078EE ED               [12]  827 	mov	a,r5
      0078EF 12 3A 5F         [24]  828 	lcall	_ak820_outline_0016
      0078F2 12 80 74         [24]  829 	lcall	_ak820_outline_0071
      0078F5 90 08 AA         [24]  830 	mov	dptr,#_ak820_action_exec_snapshot_10000_640
      0078F8 F5 F0            [12]  831 	mov	b,a
      0078FA 12 C0 97         [24]  832 	lcall	___memcpy
                                    833 ;	quantum/action.c:189: action_exec(snapshot);
      0078FD 90 0E 28         [24]  834 	mov	dptr,#___memcpy_PARM_2
      007900 74 AA            [12]  835 	mov	a,#_ak820_action_exec_snapshot_10000_640
      007902 F0               [24]  836 	movx	@dptr,a
      007903 74 08            [12]  837 	mov	a,#(_ak820_action_exec_snapshot_10000_640 >> 8)
      007905 12 3A B0         [24]  838 	lcall	_ak820_outline_0095
      007908 12 80 74         [24]  839 	lcall	_ak820_outline_0071
      00790B 90 08 99         [24]  840 	mov	dptr,#_action_exec_PARM_1
      00790E F5 F0            [12]  841 	mov	b,a
      007910 12 C0 97         [24]  842 	lcall	___memcpy
                                    843 ;	quantum/action.c:190: }
      007913 01 54            [12]  844 	ajmp	_action_exec
                                    845 ;------------------------------------------------------------
                                    846 ;Allocation info for local variables in function 'process_record_nocache'
                                    847 ;------------------------------------------------------------
                                    848 ;record        Allocated with name '_process_record_nocache_record_10000_641'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function process_record
                                    853 ;	-----------------------------------------
      007915                        854 _process_record:
      007915 12 48 A0         [24]  855 	lcall	_ak820_outline_0036
      007918 90 08 B0         [24]  856 	mov	dptr,#_process_record_record_10000_643
      00791B 12 3A 5F         [24]  857 	lcall	_ak820_outline_0016
                                    858 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      00791E 90 08 B0         [24]  859 	mov	dptr,#_process_record_record_10000_643
      007921 12 54 AF         [24]  860 	lcall	_ak820_outline_0013
      007924 74 04            [12]  861 	mov	a,#0x04
      007926 12 80 30         [24]  862 	lcall	_ak820_outline_0006
      007929 12 C1 70         [24]  863 	lcall	__gptrget
      00792C 70 01            [24]  864 	jnz	00102$
                                    865 ;	quantum/action.c:330: return;
      00792E 22               [24]  866 	ret
      00792F                        867 00102$:
                                    868 ;	quantum/action.c:334: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      00792F 74 01            [12]  869 	mov	a,#0x01
      007931 12 80 30         [24]  870 	lcall	_ak820_outline_0006
      007934 12 C1 70         [24]  871 	lcall	__gptrget
      007937 FA               [12]  872 	mov	r2,a
      007938 BA 10 00         [24]  873 	cjne	r2,#0x10,00192$
      00793B                        874 00192$:
      00793B 50 49            [24]  875 	jnc	00104$
      00793D 8D 02            [24]  876 	mov	ar2,r5
      00793F 8E 03            [24]  877 	mov	ar3,r6
      007941 8F 04            [24]  878 	mov	ar4,r7
      007943 12 3A EC         [24]  879 	lcall	_ak820_outline_0147
      007946 8C F0            [24]  880 	mov	b,r4
      007948 12 C1 70         [24]  881 	lcall	__gptrget
      00794B FA               [12]  882 	mov	r2,a
      00794C BA 08 00         [24]  883 	cjne	r2,#0x08,00194$
      00794F                        884 00194$:
      00794F 50 35            [24]  885 	jnc	00104$
      007951 90 0A 0E         [24]  886 	mov	dptr,#_ak820_macro_primitive
      007954 E0               [24]  887 	movx	a,@dptr
      007955 70 2F            [24]  888 	jnz	00104$
                                    889 ;	quantum/action.c:335: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      007957 90 0C 7F         [24]  890 	mov	dptr,#_get_record_keycode_PARM_2
      00795A 74 01            [12]  891 	mov	a,#0x01
      00795C 12 54 B8         [24]  892 	lcall	_ak820_outline_0031
      00795F 12 A7 4A         [24]  893 	lcall	_get_record_keycode
      007962 12 48 E9         [24]  894 	lcall	_ak820_outline_0127
      007965 90 08 B0         [24]  895 	mov	dptr,#_process_record_record_10000_643
      007968 12 80 5B         [24]  896 	lcall	_ak820_outline_0024
      00796B 74 05            [12]  897 	mov	a,#0x05
      00796D 2B               [12]  898 	add	a, r3
      00796E FB               [12]  899 	mov	r3,a
      00796F E4               [12]  900 	clr	a
      007970 3C               [12]  901 	addc	a, r4
      007971 FC               [12]  902 	mov	r4,a
      007972 12 77 C5         [24]  903 	lcall	_ak820_outline_0097
      007975 12 C1 70         [24]  904 	lcall	__gptrget
      007978 90 04 BE         [24]  905 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      00797B 12 48 CB         [24]  906 	lcall	_ak820_outline_0076
      00797E 12 3B BD         [24]  907 	lcall	_ak820_dynamic_macro_process
      007981 E5 82            [12]  908 	mov	a, dpl
      007983 70 01            [24]  909 	jnz	00104$
      007985 22               [24]  910 	ret
      007986                        911 00104$:
                                    912 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007986 90 08 B0         [24]  913 	mov	dptr,#_process_record_record_10000_643
      007989 12 54 AF         [24]  914 	lcall	_ak820_outline_0013
      00798C 8D 02            [24]  915 	mov	ar2,r5
      00798E 8E 03            [24]  916 	mov	ar3,r6
      007990 8F 04            [24]  917 	mov	ar4,r7
      007992 90 0E 28         [24]  918 	mov	dptr,#___memcpy_PARM_2
      007995 EA               [12]  919 	mov	a,r2
      007996 12 80 CA         [24]  920 	lcall	_ak820_outline_0190
      007999 EC               [12]  921 	mov	a,r4
      00799A A3               [24]  922 	inc	dptr
      00799B F0               [24]  923 	movx	@dptr,a
      00799C 90 0E 2B         [24]  924 	mov	dptr,#___memcpy_PARM_3
      00799F 12 54 F4         [24]  925 	lcall	_ak820_outline_0113
      0079A2 90 06 8A         [24]  926 	mov	dptr,#_ak820_tapping_source_PARM_1
      0079A5 F5 F0            [12]  927 	mov	b,a
      0079A7 C0 07            [24]  928 	push	ar7
      0079A9 C0 06            [24]  929 	push	ar6
      0079AB C0 05            [24]  930 	push	ar5
      0079AD 12 C0 97         [24]  931 	lcall	___memcpy
      0079B0 12 49 1A         [24]  932 	lcall	_ak820_tapping_source
      0079B3 AC 82            [24]  933 	mov	r4, dpl
      0079B5 D0 05            [24]  934 	pop	ar5
      0079B7 D0 06            [24]  935 	pop	ar6
      0079B9 D0 07            [24]  936 	pop	ar7
                                    937 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      0079BB 74 05            [12]  938 	mov	a,#0x05
      0079BD 12 80 3E         [24]  939 	lcall	_ak820_outline_0014
      0079C0 12 C1 70         [24]  940 	lcall	__gptrget
      0079C3 FB               [12]  941 	mov	r3,a
                                    942 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      0079C4 74 07            [12]  943 	mov	a,#0x07
      0079C6 2D               [12]  944 	add	a, r5
      0079C7 F8               [12]  945 	mov	r0,a
      0079C8 E4               [12]  946 	clr	a
      0079C9 3E               [12]  947 	addc	a, r6
      0079CA F9               [12]  948 	mov	r1,a
      0079CB 8F 02            [24]  949 	mov	ar2,r7
      0079CD 90 0C 7F         [24]  950 	mov	dptr,#_get_record_keycode_PARM_2
      0079D0 74 01            [12]  951 	mov	a,#0x01
      0079D2 12 54 B8         [24]  952 	lcall	_ak820_outline_0031
      0079D5 C0 04            [24]  953 	push	ar4
      0079D7 C0 03            [24]  954 	push	ar3
      0079D9 C0 02            [24]  955 	push	ar2
      0079DB C0 01            [24]  956 	push	ar1
      0079DD C0 00            [24]  957 	push	ar0
      0079DF 12 A7 4A         [24]  958 	lcall	_get_record_keycode
      0079E2 12 48 E9         [24]  959 	lcall	_ak820_outline_0127
      0079E5 D0 00            [24]  960 	pop	ar0
      0079E7 D0 01            [24]  961 	pop	ar1
      0079E9 D0 02            [24]  962 	pop	ar2
      0079EB D0 03            [24]  963 	pop	ar3
      0079ED D0 04            [24]  964 	pop	ar4
      0079EF 12 3A F1         [24]  965 	lcall	_ak820_outline_0148
      0079F2 8A F0            [24]  966 	mov	b,r2
      0079F4 EE               [12]  967 	mov	a,r6
      0079F5 12 C1 35         [24]  968 	lcall	__gptrput
      0079F8 A3               [24]  969 	inc	dptr
      0079F9 EF               [12]  970 	mov	a,r7
      0079FA 12 C1 35         [24]  971 	lcall	__gptrput
                                    972 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0079FD 90 08 B0         [24]  973 	mov	dptr,#_process_record_record_10000_643
      007A00 12 54 AF         [24]  974 	lcall	_ak820_outline_0013
      007A03 74 07            [12]  975 	mov	a,#0x07
      007A05 12 80 85         [24]  976 	lcall	_ak820_outline_0082
      007A08 12 C1 70         [24]  977 	lcall	__gptrget
      007A0B F8               [12]  978 	mov	r0,a
      007A0C A3               [24]  979 	inc	dptr
      007A0D 12 C1 70         [24]  980 	lcall	__gptrget
      007A10 F9               [12]  981 	mov	r1,a
      007A11 90 06 9A         [24]  982 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007A14 EC               [12]  983 	mov	a,r4
      007A15 F0               [24]  984 	movx	@dptr,a
      007A16 90 06 9B         [24]  985 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007A19 EB               [12]  986 	mov	a,r3
      007A1A F0               [24]  987 	movx	@dptr,a
      007A1B 12 3A F1         [24]  988 	lcall	_ak820_outline_0148
      007A1E C0 07            [24]  989 	push	ar7
      007A20 C0 06            [24]  990 	push	ar6
      007A22 C0 05            [24]  991 	push	ar5
      007A24 C0 04            [24]  992 	push	ar4
      007A26 C0 03            [24]  993 	push	ar3
      007A28 12 4C 74         [24]  994 	lcall	_ak820_oneshot_process
      007A2B E5 82            [12]  995 	mov	a, dpl
      007A2D D0 03            [24]  996 	pop	ar3
      007A2F D0 04            [24]  997 	pop	ar4
      007A31 D0 05            [24]  998 	pop	ar5
      007A33 D0 06            [24]  999 	pop	ar6
      007A35 D0 07            [24] 1000 	pop	ar7
      007A37 70 01            [24] 1001 	jnz	00109$
      007A39 22               [24] 1002 	ret
      007A3A                       1003 00109$:
                                   1004 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      007A3A 12 75 9F         [24] 1005 	lcall	_ak820_outline_0050
      007A3D C0 04            [24] 1006 	push	ar4
      007A3F C0 03            [24] 1007 	push	ar3
      007A41 12 A8 0D         [24] 1008 	lcall	_process_record_quantum
      007A44 E5 82            [12] 1009 	mov	a, dpl
      007A46 D0 03            [24] 1010 	pop	ar3
      007A48 D0 04            [24] 1011 	pop	ar4
      007A4A 70 0A            [24] 1012 	jnz	00111$
                                   1013 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007A4C 90 06 02         [24] 1014 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007A4F EB               [12] 1015 	mov	a,r3
      007A50 F0               [24] 1016 	movx	@dptr,a
      007A51 8C 82            [24] 1017 	mov	dpl, r4
                                   1018 ;	quantum/action.c:352: return;
      007A53 02 2E BB         [24] 1019 	ljmp	_ak820_oneshot_post
      007A56                       1020 00111$:
                                   1021 ;	quantum/action.c:356: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      007A56 90 08 B0         [24] 1022 	mov	dptr,#_process_record_record_10000_643
      007A59 12 54 AF         [24] 1023 	lcall	_ak820_outline_0013
      007A5C 74 01            [12] 1024 	mov	a,#0x01
      007A5E 12 80 85         [24] 1025 	lcall	_ak820_outline_0082
      007A61 12 C1 70         [24] 1026 	lcall	__gptrget
      007A64 F8               [12] 1027 	mov	r0,a
      007A65 B8 10 00         [24] 1028 	cjne	r0,#0x10,00200$
      007A68                       1029 00200$:
      007A68 50 21            [24] 1030 	jnc	00114$
      007A6A 12 75 9F         [24] 1031 	lcall	_ak820_outline_0050
      007A6D 12 C1 70         [24] 1032 	lcall	__gptrget
      007A70 FD               [12] 1033 	mov	r5,a
      007A71 BD 08 00         [24] 1034 	cjne	r5,#0x08,00202$
      007A74                       1035 00202$:
      007A74 50 15            [24] 1036 	jnc	00114$
      007A76 C0 04            [24] 1037 	push	ar4
      007A78 C0 03            [24] 1038 	push	ar3
      007A7A 12 AA B6         [24] 1039 	lcall	_get_repeat_key_count
      007A7D E5 82            [12] 1040 	mov	a, dpl
      007A7F D0 03            [24] 1041 	pop	ar3
      007A81 D0 04            [24] 1042 	pop	ar4
      007A83 70 06            [24] 1043 	jnz	00114$
      007A85 90 0A 0E         [24] 1044 	mov	dptr,#_ak820_macro_primitive
      007A88 E0               [24] 1045 	movx	a,@dptr
      007A89 60 05            [24] 1046 	jz	00115$
      007A8B                       1047 00114$:
      007A8B 75 27 00         [24] 1048 	mov	_process_record_sloc0_1_0,#0x00
      007A8E 80 03            [24] 1049 	sjmp	00116$
      007A90                       1050 00115$:
      007A90 75 27 01         [24] 1051 	mov	_process_record_sloc0_1_0,#0x01
      007A93                       1052 00116$:
      007A93 90 04 BD         [24] 1053 	mov	dptr,#_ak820_dynamic_macro_source
      007A96 E5 27            [12] 1054 	mov	a,_process_record_sloc0_1_0
      007A98 F0               [24] 1055 	movx	@dptr,a
                                   1056 ;	quantum/action.c:358: process_record_handler(record);
      007A99 90 08 B0         [24] 1057 	mov	dptr,#_process_record_record_10000_643
      007A9C 12 54 89         [24] 1058 	lcall	_ak820_outline_0001
      007A9F C0 04            [24] 1059 	push	ar4
      007AA1 C0 03            [24] 1060 	push	ar3
      007AA3 51 C1            [24] 1061 	acall	_process_record_handler
                                   1062 ;	quantum/action.c:360: ak820_dynamic_macro_source = false;
      007AA5 90 04 BD         [24] 1063 	mov	dptr,#_ak820_dynamic_macro_source
      007AA8 E4               [12] 1064 	clr	a
      007AA9 F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	quantum/action.c:362: post_process_record_quantum(record);
      007AAA 90 08 B0         [24] 1067 	mov	dptr,#_process_record_record_10000_643
      007AAD 12 54 89         [24] 1068 	lcall	_ak820_outline_0001
      007AB0 12 A7 E3         [24] 1069 	lcall	_post_process_record_quantum
      007AB3 D0 03            [24] 1070 	pop	ar3
      007AB5 D0 04            [24] 1071 	pop	ar4
                                   1072 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007AB7 90 06 02         [24] 1073 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007ABA EB               [12] 1074 	mov	a,r3
      007ABB F0               [24] 1075 	movx	@dptr,a
      007ABC 8C 82            [24] 1076 	mov	dpl, r4
                                   1077 ;	quantum/action.c:366: }
      007ABE 02 2E BB         [24] 1078 	ljmp	_ak820_oneshot_post
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'process_record_handler'
                                   1081 ;------------------------------------------------------------
                                   1082 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_652'
                                   1083 ;record        Allocated with name '_process_record_handler_record_10000_653'
                                   1084 ;action        Allocated with name '_process_record_handler_action_10000_653'
                                   1085 ;------------------------------------------------------------
                                   1086 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                   1087 ;	-----------------------------------------
                                   1088 ;	 function process_record_handler
                                   1089 ;	-----------------------------------------
      007AC1                       1090 _process_record_handler:
      007AC1 12 48 A0         [24] 1091 	lcall	_ak820_outline_0036
      007AC4 90 08 B3         [24] 1092 	mov	dptr,#_process_record_handler_record_argument_10000_652
      007AC7 12 3A 5F         [24] 1093 	lcall	_ak820_outline_0016
                                   1094 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007ACA 90 08 B3         [24] 1095 	mov	dptr,#_process_record_handler_record_argument_10000_652
      007ACD 12 3A 3E         [24] 1096 	lcall	_ak820_outline_0008
                                   1097 ;	quantum/action.c:379: if (record->keycode) {
      007AD0 4C               [12] 1098 	orl	a,r4
      007AD1 60 19            [24] 1099 	jz	00102$
                                   1100 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      007AD3 12 3A D7         [24] 1101 	lcall	_ak820_outline_0126
      007AD6 C0 07            [24] 1102 	push	ar7
      007AD8 C0 06            [24] 1103 	push	ar6
      007ADA 12 9D A2         [24] 1104 	lcall	_action_for_keycode
      007ADD 12 48 FA         [24] 1105 	lcall	_ak820_outline_0154
      007AE0 D0 06            [24] 1106 	pop	ar6
      007AE2 D0 07            [24] 1107 	pop	ar7
      007AE4 90 08 B6         [24] 1108 	mov	dptr,#_process_record_handler_action_10000_653
      007AE7 12 3A 9E         [24] 1109 	lcall	_ak820_outline_0072
      007AEA 80 2B            [24] 1110 	sjmp	00104$
      007AEC                       1111 00102$:
                                   1112 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007AEC 12 80 4C         [24] 1113 	lcall	_ak820_outline_0021
      007AEF 7A 00            [12] 1114 	mov	r2,#0x00
      007AF1 12 48 F4         [24] 1115 	lcall	_ak820_outline_0146
      007AF4 12 48 8E         [24] 1116 	lcall	_ak820_outline_0012
      007AF7 E0               [24] 1117 	movx	a,@dptr
      007AF8 90 09 F4         [24] 1118 	mov	dptr,#_ak820_resolve_key_PARM_2
      007AFB F0               [24] 1119 	movx	@dptr,a
      007AFC 8D 82            [24] 1120 	mov	dpl, r5
      007AFE 8C 83            [24] 1121 	mov	dph, r4
      007B00 C0 07            [24] 1122 	push	ar7
      007B02 C0 06            [24] 1123 	push	ar6
      007B04 12 83 F2         [24] 1124 	lcall	_ak820_resolve_key
      007B07 12 9D A2         [24] 1125 	lcall	_action_for_keycode
      007B0A 12 48 FA         [24] 1126 	lcall	_ak820_outline_0154
      007B0D D0 06            [24] 1127 	pop	ar6
      007B0F D0 07            [24] 1128 	pop	ar7
      007B11 90 08 B6         [24] 1129 	mov	dptr,#_process_record_handler_action_10000_653
      007B14 12 3A 9E         [24] 1130 	lcall	_ak820_outline_0072
                                   1131 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      007B17                       1132 00104$:
                                   1133 ;	quantum/action.c:403: process_action(record, action);
      007B17 7D 00            [12] 1134 	mov	r5,#0x00
      007B19 90 0E 28         [24] 1135 	mov	dptr,#___memcpy_PARM_2
      007B1C 74 B6            [12] 1136 	mov	a,#_process_record_handler_action_10000_653
      007B1E F0               [24] 1137 	movx	@dptr,a
      007B1F 74 08            [12] 1138 	mov	a,#(_process_record_handler_action_10000_653 >> 8)
      007B21 12 3A B0         [24] 1139 	lcall	_ak820_outline_0095
      007B24 90 0E 2B         [24] 1140 	mov	dptr,#___memcpy_PARM_3
      007B27 12 54 F4         [24] 1141 	lcall	_ak820_outline_0113
      007B2A 90 08 BA         [24] 1142 	mov	dptr,#_process_action_PARM_2
      007B2D F5 F0            [12] 1143 	mov	b,a
      007B2F C0 07            [24] 1144 	push	ar7
      007B31 C0 06            [24] 1145 	push	ar6
      007B33 C0 05            [24] 1146 	push	ar5
      007B35 12 C0 97         [24] 1147 	lcall	___memcpy
      007B38 D0 05            [24] 1148 	pop	ar5
      007B3A D0 06            [24] 1149 	pop	ar6
      007B3C D0 07            [24] 1150 	pop	ar7
      007B3E 12 77 BE         [24] 1151 	lcall	_ak820_outline_0051
                                   1152 ;	quantum/action.c:404: }
      007B41 61 66            [12] 1153 	ajmp	_process_action
                                   1154 ;------------------------------------------------------------
                                   1155 ;Allocation info for local variables in function 'register_mouse'
                                   1156 ;------------------------------------------------------------
                                   1157 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1158 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_661'
                                   1159 ;------------------------------------------------------------
                                   1160 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1161 ;	-----------------------------------------
                                   1162 ;	 function register_mouse
                                   1163 ;	-----------------------------------------
      007B43                       1164 _register_mouse:
      007B43 E5 82            [12] 1165 	mov	a,dpl
      007B45 90 08 B9         [24] 1166 	mov	dptr,#_register_mouse_mouse_keycode_10000_661
      007B48 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action.c:419: if (pressed) {
      007B49 90 08 B8         [24] 1169 	mov	dptr,#_register_mouse_PARM_2
      007B4C E0               [24] 1170 	movx	a,@dptr
      007B4D 60 0B            [24] 1171 	jz	00102$
                                   1172 ;	quantum/action.c:420: mousekey_on(mouse_keycode);
      007B4F 90 08 B9         [24] 1173 	mov	dptr,#_register_mouse_mouse_keycode_10000_661
      007B52 E0               [24] 1174 	movx	a,@dptr
      007B53 F5 82            [12] 1175 	mov	dpl,a
      007B55 12 55 52         [24] 1176 	lcall	_mousekey_on
      007B58 80 09            [24] 1177 	sjmp	00103$
      007B5A                       1178 00102$:
                                   1179 ;	quantum/action.c:422: mousekey_off(mouse_keycode);
      007B5A 90 08 B9         [24] 1180 	mov	dptr,#_register_mouse_mouse_keycode_10000_661
      007B5D E0               [24] 1181 	movx	a,@dptr
      007B5E F5 82            [12] 1182 	mov	dpl,a
      007B60 12 55 C6         [24] 1183 	lcall	_mousekey_off
      007B63                       1184 00103$:
                                   1185 ;	quantum/action.c:443: mousekey_send();
                                   1186 ;	quantum/action.c:445: }
                                   1187 ;	quantum/action.c:461: }
      007B63 02 56 25         [24] 1188 	ljmp	_mousekey_send
                                   1189 ;------------------------------------------------------------
                                   1190 ;Allocation info for local variables in function 'process_action'
                                   1191 ;------------------------------------------------------------
                                   1192 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1193 ;action        Allocated with name '_process_action_PARM_2'
                                   1194 ;record_argument Allocated with name '_process_action_record_argument_10000_668'
                                   1195 ;record        Allocated with name '_process_action_record_10000_669'
                                   1196 ;pressed       Allocated with name '_process_action_pressed_10000_669'
                                   1197 ;mods          Allocated with name '_process_action_mods_10000_669'
                                   1198 ;on            Allocated with name '_process_action_on_40000_691'
                                   1199 ;shift         Allocated with name '_process_action_shift_60000_693'
                                   1200 ;bits          Allocated with name '_process_action_bits_60000_693'
                                   1201 ;mask          Allocated with name '_process_action_mask_60000_693'
                                   1202 ;i             Allocated with name '_process_action_i_110000_717'
                                   1203 ;i             Allocated with name '_process_action_i_110000_721'
                                   1204 ;------------------------------------------------------------
                                   1205 ;	quantum/action.c:467: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1206 ;	-----------------------------------------
                                   1207 ;	 function process_action
                                   1208 ;	-----------------------------------------
      007B66                       1209 _process_action:
      007B66 12 48 A0         [24] 1210 	lcall	_ak820_outline_0036
      007B69 90 08 BC         [24] 1211 	mov	dptr,#_process_action_record_argument_10000_668
      007B6C 12 3A 5F         [24] 1212 	lcall	_ak820_outline_0016
                                   1213 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007B6F 90 08 BC         [24] 1214 	mov	dptr,#_process_action_record_argument_10000_668
      007B72 12 3A 34         [24] 1215 	lcall	_ak820_outline_0005
                                   1216 ;	quantum/action.c:475: pressed = record->event.pressed;
      007B75 A3               [24] 1217 	inc	dptr
      007B76 A3               [24] 1218 	inc	dptr
      007B77 A3               [24] 1219 	inc	dptr
      007B78 A3               [24] 1220 	inc	dptr
      007B79 A3               [24] 1221 	inc	dptr
      007B7A E0               [24] 1222 	movx	a,@dptr
      007B7B F5 28            [12] 1223 	mov	_process_action_sloc0_1_0,a
                                   1224 ;	quantum/action.c:499: switch (action.kind.id) {
      007B7D 90 08 BB         [24] 1225 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B80 E0               [24] 1226 	movx	a,@dptr
      007B81 C4               [12] 1227 	swap	a
      007B82 54 0F            [12] 1228 	anl	a,#0x0f
      007B84 FD               [12] 1229 	mov  r5,a
      007B85 24 F4            [12] 1230 	add	a,#0xff - 0x0b
      007B87 50 03            [24] 1231 	jnc	00434$
      007B89 02 7E 19         [24] 1232 	ljmp	00181$
      007B8C                       1233 00434$:
                                   1234 ;	free result
      007B8C ED               [12] 1235 	mov	a,r5
      007B8D 24 0A            [12] 1236 	add	a,#(00435$-3-.)
      007B8F 83               [24] 1237 	movc	a,@a+pc
      007B90 F5 82            [12] 1238 	mov	dpl,a
      007B92 ED               [12] 1239 	mov	a,r5
      007B93 24 10            [12] 1240 	add	a,#(00436$-3-.)
      007B95 83               [24] 1241 	movc	a,@a+pc
      007B96 F5 83            [12] 1242 	mov	dph,a
      007B98 E4               [12] 1243 	clr	a
      007B99 73               [24] 1244 	jmp	@a+dptr
      007B9A                       1245 00435$:
      007B9A B2                    1246 	.db	00102$
      007B9B B2                    1247 	.db	00102$
      007B9C 19                    1248 	.db	00181$
      007B9D 19                    1249 	.db	00181$
      007B9E 3C                    1250 	.db	00123$
      007B9F 9C                    1251 	.db	00130$
      007BA0 19                    1252 	.db	00181$
      007BA1 19                    1253 	.db	00181$
      007BA2 AE                    1254 	.db	00131$
      007BA3 80                    1255 	.db	00147$
      007BA4 A6                    1256 	.db	00152$
      007BA5 A6                    1257 	.db	00152$
      007BA6                       1258 00436$:
      007BA6 7B                    1259 	.db	00102$>>8
      007BA7 7B                    1260 	.db	00102$>>8
      007BA8 7E                    1261 	.db	00181$>>8
      007BA9 7E                    1262 	.db	00181$>>8
      007BAA 7C                    1263 	.db	00123$>>8
      007BAB 7C                    1264 	.db	00130$>>8
      007BAC 7E                    1265 	.db	00181$>>8
      007BAD 7E                    1266 	.db	00181$>>8
      007BAE 7C                    1267 	.db	00131$>>8
      007BAF 7D                    1268 	.db	00147$>>8
      007BB0 7D                    1269 	.db	00152$>>8
      007BB1 7D                    1270 	.db	00152$>>8
                                   1271 ;	quantum/action.c:502: case ACT_RMODS: {
      007BB2                       1272 00102$:
                                   1273 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007BB2 90 08 BB         [24] 1274 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007BB5 E0               [24] 1275 	movx	a,@dptr
      007BB6 54 F0            [12] 1276 	anl	a,#0xf0
      007BB8 70 06            [24] 1277 	jnz	00194$
      007BBA 12 80 9C         [24] 1278 	lcall	_ak820_outline_0115
      007BBD FD               [12] 1279 	mov	r5,a
      007BBE 80 07            [24] 1280 	sjmp	00195$
      007BC0                       1281 00194$:
      007BC0 12 80 9C         [24] 1282 	lcall	_ak820_outline_0115
      007BC3 C4               [12] 1283 	swap	a
      007BC4 54 F0            [12] 1284 	anl	a,#0xf0
      007BC6 FD               [12] 1285 	mov	r5,a
      007BC7                       1286 00195$:
                                   1287 ;	quantum/action.c:505: if (pressed) {
      007BC7 E5 28            [12] 1288 	mov	a,_process_action_sloc0_1_0
      007BC9 60 35            [24] 1289 	jz	00119$
                                   1290 ;	quantum/action.c:506: if (mods) {
      007BCB ED               [12] 1291 	mov	a,r5
      007BCC 60 29            [24] 1292 	jz	00110$
                                   1293 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007BCE 12 80 BA         [24] 1294 	lcall	_ak820_outline_0153
      007BD1 FC               [12] 1295 	mov	r4,a
      007BD2 BC E0 00         [24] 1296 	cjne	r4,#0xe0,00440$
      007BD5                       1297 00440$:
      007BD5 40 07            [24] 1298 	jc	00108$
      007BD7 12 80 BA         [24] 1299 	lcall	_ak820_outline_0153
      007BDA 24 18            [12] 1300 	add	a,#0xff - 0xe7
      007BDC 50 0A            [24] 1301 	jnc	00104$
                                   1302 ;	free result
      007BDE                       1303 00108$:
      007BDE 7B BA            [12] 1304 	mov	r3,#_process_action_PARM_2
      007BE0 7C 08            [12] 1305 	mov	r4,#(_process_action_PARM_2 >> 8)
      007BE2 12 36 47         [24] 1306 	lcall	_ak820_outline_0125
      007BE5 E0               [24] 1307 	movx	a,@dptr
      007BE6 70 07            [24] 1308 	jnz	00105$
      007BE8                       1309 00104$:
                                   1310 ;	quantum/action.c:511: add_owned_mods(mods);
      007BE8 8D 82            [24] 1311 	mov	dpl, r5
      007BEA 12 86 08         [24] 1312 	lcall	_add_owned_mods
      007BED 80 05            [24] 1313 	sjmp	00106$
      007BEF                       1314 00105$:
                                   1315 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007BEF 8D 82            [24] 1316 	mov	dpl, r5
      007BF1 12 86 22         [24] 1317 	lcall	_add_owned_weak_mods
      007BF4                       1318 00106$:
                                   1319 ;	quantum/action.c:515: send_keyboard_report();
      007BF4 12 89 40         [24] 1320 	lcall	_send_keyboard_report
      007BF7                       1321 00110$:
                                   1322 ;	quantum/action.c:517: register_code(action.key.code);
      007BF7 12 80 7E         [24] 1323 	lcall	_ak820_outline_0079
      007BFA 12 7E 30         [24] 1324 	lcall	_register_code
      007BFD 02 7E 19         [24] 1325 	ljmp	00181$
      007C00                       1326 00119$:
                                   1327 ;	quantum/action.c:519: unregister_code(action.key.code);
      007C00 12 80 7E         [24] 1328 	lcall	_ak820_outline_0079
      007C03 C0 05            [24] 1329 	push	ar5
      007C05 12 7E BD         [24] 1330 	lcall	_unregister_code
      007C08 D0 05            [24] 1331 	pop	ar5
                                   1332 ;	quantum/action.c:520: if (mods) {
      007C0A ED               [12] 1333 	mov	a,r5
      007C0B 70 03            [24] 1334 	jnz	00444$
      007C0D 02 7E 19         [24] 1335 	ljmp	00181$
      007C10                       1336 00444$:
                                   1337 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007C10 12 80 BA         [24] 1338 	lcall	_ak820_outline_0153
      007C13 FC               [12] 1339 	mov	r4,a
      007C14 BC E0 00         [24] 1340 	cjne	r4,#0xe0,00445$
      007C17                       1341 00445$:
      007C17 40 07            [24] 1342 	jc	00115$
      007C19 12 80 BA         [24] 1343 	lcall	_ak820_outline_0153
      007C1C 24 18            [12] 1344 	add	a,#0xff - 0xe7
      007C1E 50 0A            [24] 1345 	jnc	00111$
                                   1346 ;	free result
      007C20                       1347 00115$:
      007C20 7B BA            [12] 1348 	mov	r3,#_process_action_PARM_2
      007C22 7C 08            [12] 1349 	mov	r4,#(_process_action_PARM_2 >> 8)
      007C24 12 36 47         [24] 1350 	lcall	_ak820_outline_0125
      007C27 E0               [24] 1351 	movx	a,@dptr
      007C28 70 07            [24] 1352 	jnz	00112$
      007C2A                       1353 00111$:
                                   1354 ;	quantum/action.c:522: del_owned_mods(mods);
      007C2A 8D 82            [24] 1355 	mov	dpl, r5
      007C2C 12 86 15         [24] 1356 	lcall	_del_owned_mods
      007C2F 80 05            [24] 1357 	sjmp	00113$
      007C31                       1358 00112$:
                                   1359 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007C31 8D 82            [24] 1360 	mov	dpl, r5
      007C33 12 86 31         [24] 1361 	lcall	_del_owned_weak_mods
      007C36                       1362 00113$:
                                   1363 ;	quantum/action.c:526: send_keyboard_report();
      007C36 12 89 40         [24] 1364 	lcall	_send_keyboard_report
                                   1365 ;	quantum/action.c:529: } break;
      007C39 02 7E 19         [24] 1366 	ljmp	00181$
                                   1367 ;	quantum/action.c:606: case ACT_USAGE:
      007C3C                       1368 00123$:
                                   1369 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007C3C 74 07            [12] 1370 	mov	a,#0x07
      007C3E 12 3A 71         [24] 1371 	lcall	_ak820_outline_0022
      007C41 12 4D AC         [24] 1372 	lcall	_ak820_outline_0009
      007C44 C3               [12] 1373 	clr	c
      007C45 EC               [12] 1374 	mov	a,r4
      007C46 94 A5            [12] 1375 	subb	a,#0xa5
      007C48 ED               [12] 1376 	mov	a,r5
      007C49 94 00            [12] 1377 	subb	a,#0x00
      007C4B 40 15            [24] 1378 	jc	00125$
      007C4D 74 C2            [12] 1379 	mov	a,#0xc2
      007C4F 9C               [12] 1380 	subb	a,r4
      007C50 E4               [12] 1381 	clr	a
      007C51 9D               [12] 1382 	subb	a,r5
      007C52 40 0E            [24] 1383 	jc	00125$
                                   1384 ;	free result
                                   1385 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007C54 90 0B 1B         [24] 1386 	mov	dptr,#_owned_usage_key_PARM_2
      007C57 E5 28            [12] 1387 	mov	a,_process_action_sloc0_1_0
      007C59 F0               [24] 1388 	movx	@dptr,a
      007C5A 8E 82            [24] 1389 	mov	dpl, r6
      007C5C 12 87 EC         [24] 1390 	lcall	_owned_usage_key
                                   1391 ;	quantum/action.c:614: break;
      007C5F 02 7E 19         [24] 1392 	ljmp	00181$
      007C62                       1393 00125$:
                                   1394 ;	quantum/action.c:617: switch (action.usage.page) {
      007C62 12 80 93         [24] 1395 	lcall	_ak820_outline_0091
      007C65 FF               [12] 1396 	mov	r7,a
      007C66 60 08            [24] 1397 	jz	00127$
      007C68 BF 01 02         [24] 1398 	cjne	r7,#0x01,00452$
      007C6B 80 19            [24] 1399 	sjmp	00128$
      007C6D                       1400 00452$:
      007C6D 02 7E 19         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007C70                       1403 00127$:
                                   1404 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007C70 E5 28            [12] 1405 	mov	a,_process_action_sloc0_1_0
      007C72 60 05            [24] 1406 	jz	00196$
      007C74 12 80 A3         [24] 1407 	lcall	_ak820_outline_0133
      007C77 80 04            [24] 1408 	sjmp	00197$
      007C79                       1409 00196$:
      007C79 7E 00            [12] 1410 	mov	r6,#0x00
      007C7B 7F 00            [12] 1411 	mov	r7,#0x00
      007C7D                       1412 00197$:
      007C7D 12 3A CC         [24] 1413 	lcall	_ak820_outline_0120
      007C80 12 75 2B         [24] 1414 	lcall	_host_system_send
                                   1415 ;	quantum/action.c:620: break;
      007C83 02 7E 19         [24] 1416 	ljmp	00181$
                                   1417 ;	quantum/action.c:621: case PAGE_CONSUMER:
      007C86                       1418 00128$:
                                   1419 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      007C86 E5 28            [12] 1420 	mov	a,_process_action_sloc0_1_0
      007C88 60 05            [24] 1421 	jz	00198$
      007C8A 12 80 A3         [24] 1422 	lcall	_ak820_outline_0133
      007C8D 80 04            [24] 1423 	sjmp	00199$
      007C8F                       1424 00198$:
      007C8F 7E 00            [12] 1425 	mov	r6,#0x00
      007C91 7F 00            [12] 1426 	mov	r7,#0x00
      007C93                       1427 00199$:
      007C93 12 3A CC         [24] 1428 	lcall	_ak820_outline_0120
      007C96 12 75 5A         [24] 1429 	lcall	_host_consumer_send
                                   1430 ;	quantum/action.c:625: break;
      007C99 02 7E 19         [24] 1431 	ljmp	00181$
                                   1432 ;	quantum/action.c:628: case ACT_MOUSEKEY:
      007C9C                       1433 00130$:
                                   1434 ;	quantum/action.c:629: register_mouse(action.key.code, pressed);
      007C9C 12 80 BA         [24] 1435 	lcall	_ak820_outline_0153
      007C9F FF               [12] 1436 	mov	r7,a
      007CA0 90 08 B8         [24] 1437 	mov	dptr,#_register_mouse_PARM_2
      007CA3 E5 28            [12] 1438 	mov	a,_process_action_sloc0_1_0
      007CA5 F0               [24] 1439 	movx	@dptr,a
      007CA6 8F 82            [24] 1440 	mov	dpl, r7
      007CA8 12 7B 43         [24] 1441 	lcall	_register_mouse
                                   1442 ;	quantum/action.c:630: break;
      007CAB 02 7E 19         [24] 1443 	ljmp	00181$
                                   1444 ;	quantum/action.c:632: case ACT_LAYER: {
      007CAE                       1445 00131$:
                                   1446 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      007CAE 90 08 BB         [24] 1447 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007CB1 E0               [24] 1448 	movx	a,@dptr
      007CB2 54 03            [12] 1449 	anl	a,#0x03
      007CB4 90 08 BF         [24] 1450 	mov	dptr,#_process_action_on_40000_691
      007CB7 F0               [24] 1451 	movx	@dptr,a
                                   1452 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007CB8 E0               [24] 1453 	movx	a,@dptr
      007CB9 FF               [12] 1454 	mov	r7,a
      007CBA 60 11            [24] 1455 	jz	00200$
      007CBC E5 28            [12] 1456 	mov	a,_process_action_sloc0_1_0
      007CBE 60 07            [24] 1457 	jz	00202$
      007CC0 8F 06            [24] 1458 	mov	ar6,r7
      007CC2 53 06 01         [24] 1459 	anl	ar6,#0x01
      007CC5 80 10            [24] 1460 	sjmp	00201$
      007CC7                       1461 00202$:
      007CC7 74 02            [12] 1462 	mov	a,#0x02
      007CC9 5F               [12] 1463 	anl	a,r7
      007CCA FE               [12] 1464 	mov	r6,a
      007CCB 80 0A            [24] 1465 	sjmp	00201$
      007CCD                       1466 00200$:
      007CCD E5 28            [12] 1467 	mov	a,_process_action_sloc0_1_0
      007CCF B4 01 00         [24] 1468 	cjne	a,#0x01,00457$
      007CD2                       1469 00457$:
      007CD2 92 22            [24] 1470 	mov  _process_action_sloc1_1_0,c
      007CD4 E4               [12] 1471 	clr	a
      007CD5 33               [12] 1472 	rlc	a
      007CD6 FE               [12] 1473 	mov	r6,a
      007CD7                       1474 00201$:
      007CD7 EE               [12] 1475 	mov	a,r6
      007CD8 70 03            [24] 1476 	jnz	00458$
      007CDA 02 7E 19         [24] 1477 	ljmp	00181$
      007CDD                       1478 00458$:
                                   1479 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007CDD 12 80 BA         [24] 1480 	lcall	_ak820_outline_0153
      007CE0 C4               [12] 1481 	swap	a
      007CE1 03               [12] 1482 	rr	a
      007CE2 54 07            [12] 1483 	anl	a,#0x07
      007CE4 25 E0            [12] 1484 	add	a,acc
      007CE6 25 E0            [12] 1485 	add	a,acc
      007CE8 FF               [12] 1486 	mov	r7,a
                                   1487 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007CE9 12 80 BA         [24] 1488 	lcall	_ak820_outline_0153
      007CEC 54 0F            [12] 1489 	anl	a,#0x0f
      007CEE FE               [12] 1490 	mov	r6,a
      007CEF 8F F0            [24] 1491 	mov	b,r7
      007CF1 05 F0            [12] 1492 	inc	b
      007CF3 EE               [12] 1493 	mov	a,r6
      007CF4 80 02            [24] 1494 	sjmp	00460$
      007CF6                       1495 00459$:
      007CF6 25 E0            [12] 1496 	add	a,acc
      007CF8                       1497 00460$:
      007CF8 D5 F0 FB         [24] 1498 	djnz	b,00459$
      007CFB FE               [12] 1499 	mov	r6,a
                                   1500 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007CFC 12 80 BA         [24] 1501 	lcall	_ak820_outline_0153
      007CFF 30 E4 11         [24] 1502 	jnb	acc.4,00204$
      007D02 8F F0            [24] 1503 	mov	b,r7
      007D04 05 F0            [12] 1504 	inc	b
      007D06 74 0F            [12] 1505 	mov	a,#0x0f
      007D08 80 02            [24] 1506 	sjmp	00463$
      007D0A                       1507 00462$:
      007D0A 25 E0            [12] 1508 	add	a,acc
      007D0C                       1509 00463$:
      007D0C D5 F0 FB         [24] 1510 	djnz	b,00462$
      007D0F F4               [12] 1511 	cpl	a
      007D10 FF               [12] 1512 	mov	r7,a
      007D11 80 02            [24] 1513 	sjmp	00205$
      007D13                       1514 00204$:
      007D13 7F 00            [12] 1515 	mov	r7,#0x00
      007D15                       1516 00205$:
                                   1517 ;	quantum/action.c:640: bits |= mask;
      007D15 EE               [12] 1518 	mov	a,r6
      007D16 42 07            [12] 1519 	orl	ar7,a
                                   1520 ;	quantum/action.c:641: if (!on) {
      007D18 90 08 BF         [24] 1521 	mov	dptr,#_process_action_on_40000_691
      007D1B E0               [24] 1522 	movx	a,@dptr
      007D1C 70 31            [24] 1523 	jnz	00143$
                                   1524 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007D1E 12 80 93         [24] 1525 	lcall	_ak820_outline_0091
      007D21 FE               [12] 1526 	mov	r6,a
      007D22 2E               [12] 1527 	add	a,r6
                                   1528 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007D23 90 7D 27         [24] 1529 	mov	dptr,#00465$
      007D26 73               [24] 1530 	jmp	@a+dptr
      007D27                       1531 00465$:
      007D27 80 06            [24] 1532 	sjmp	00132$
      007D29 80 0C            [24] 1533 	sjmp	00133$
      007D2B 80 12            [24] 1534 	sjmp	00134$
      007D2D 80 18            [24] 1535 	sjmp	00135$
      007D2F                       1536 00132$:
      007D2F 8F 82            [24] 1537 	mov	dpl, r7
      007D31 12 81 14         [24] 1538 	lcall	_default_layer_and
      007D34 02 7E 19         [24] 1539 	ljmp	00181$
                                   1540 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      007D37                       1541 00133$:
      007D37 8F 82            [24] 1542 	mov	dpl, r7
      007D39 12 81 04         [24] 1543 	lcall	_default_layer_or
      007D3C 02 7E 19         [24] 1544 	ljmp	00181$
                                   1545 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007D3F                       1546 00134$:
      007D3F 8F 82            [24] 1547 	mov	dpl, r7
      007D41 12 81 29         [24] 1548 	lcall	_default_layer_xor
      007D44 02 7E 19         [24] 1549 	ljmp	00181$
                                   1550 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      007D47                       1551 00135$:
      007D47 8F 82            [24] 1552 	mov	dpl, r7
      007D49 12 80 FA         [24] 1553 	lcall	_default_layer_set
                                   1554 ;	quantum/action.c:647: }
      007D4C 02 7E 19         [24] 1555 	ljmp	00181$
      007D4F                       1556 00143$:
                                   1557 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007D4F 12 80 93         [24] 1558 	lcall	_ak820_outline_0091
      007D52 FE               [12] 1559 	mov	r6,a
      007D53 2E               [12] 1560 	add	a,r6
                                   1561 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007D54 90 7D 58         [24] 1562 	mov	dptr,#00466$
      007D57 73               [24] 1563 	jmp	@a+dptr
      007D58                       1564 00466$:
      007D58 80 06            [24] 1565 	sjmp	00137$
      007D5A 80 0C            [24] 1566 	sjmp	00138$
      007D5C 80 12            [24] 1567 	sjmp	00139$
      007D5E 80 18            [24] 1568 	sjmp	00140$
      007D60                       1569 00137$:
      007D60 8F 82            [24] 1570 	mov	dpl, r7
      007D62 12 82 9F         [24] 1571 	lcall	_layer_and
      007D65 02 7E 19         [24] 1572 	ljmp	00181$
                                   1573 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      007D68                       1574 00138$:
      007D68 8F 82            [24] 1575 	mov	dpl, r7
      007D6A 12 82 8F         [24] 1576 	lcall	_layer_or
      007D6D 02 7E 19         [24] 1577 	ljmp	00181$
                                   1578 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007D70                       1579 00139$:
      007D70 8F 82            [24] 1580 	mov	dpl, r7
      007D72 12 82 B4         [24] 1581 	lcall	_layer_xor
      007D75 02 7E 19         [24] 1582 	ljmp	00181$
                                   1583 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007D78                       1584 00140$:
      007D78 8F 82            [24] 1585 	mov	dpl, r7
      007D7A 12 82 31         [24] 1586 	lcall	_layer_state_set
                                   1587 ;	quantum/action.c:657: break;
      007D7D 02 7E 19         [24] 1588 	ljmp	00181$
                                   1589 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007D80                       1590 00147$:
                                   1591 ;	quantum/action.c:660: if (pressed) {
      007D80 E5 28            [12] 1592 	mov	a,_process_action_sloc0_1_0
      007D82 60 11            [24] 1593 	jz	00149$
                                   1594 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007D84 12 80 9C         [24] 1595 	lcall	_ak820_outline_0115
      007D87 F5 82            [12] 1596 	mov	dpl,a
      007D89 12 81 97         [24] 1597 	lcall	_layer_hold_on
                                   1598 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      007D8C 12 80 7E         [24] 1599 	lcall	_ak820_outline_0079
      007D8F 12 7F 91         [24] 1600 	lcall	_register_mods
      007D92 02 7E 19         [24] 1601 	ljmp	00181$
      007D95                       1602 00149$:
                                   1603 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007D95 12 80 7E         [24] 1604 	lcall	_ak820_outline_0079
      007D98 12 7F A5         [24] 1605 	lcall	_unregister_mods
                                   1606 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      007D9B 12 80 9C         [24] 1607 	lcall	_ak820_outline_0115
      007D9E F5 82            [12] 1608 	mov	dpl,a
      007DA0 12 81 CD         [24] 1609 	lcall	_layer_hold_off
                                   1610 ;	quantum/action.c:667: break;
      007DA3 02 7E 19         [24] 1611 	ljmp	00181$
                                   1612 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007DA6                       1613 00152$:
                                   1614 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007DA6 12 80 BA         [24] 1615 	lcall	_ak820_outline_0153
      007DA9 FF               [12] 1616 	mov	r7,a
      007DAA BF F1 02         [24] 1617 	cjne	r7,#0xf1,00468$
      007DAD 80 0A            [24] 1618 	sjmp	00154$
      007DAF                       1619 00468$:
      007DAF BF F2 02         [24] 1620 	cjne	r7,#0xf2,00469$
      007DB2 80 19            [24] 1621 	sjmp	00155$
      007DB4                       1622 00469$:
                                   1623 ;	quantum/action.c:686: momentary_layer_action:
      007DB4 BF F3 3B         [24] 1624 	cjne	r7,#0xf3,00160$
      007DB7 80 28            [24] 1625 	sjmp	00156$
      007DB9                       1626 00154$:
                                   1627 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007DB9 E5 28            [12] 1628 	mov	a,_process_action_sloc0_1_0
      007DBB 60 08            [24] 1629 	jz	00206$
      007DBD 12 80 64         [24] 1630 	lcall	_ak820_outline_0042
      007DC0 12 81 97         [24] 1631 	lcall	_layer_hold_on
      007DC3 80 54            [24] 1632 	sjmp	00181$
      007DC5                       1633 00206$:
      007DC5 12 80 64         [24] 1634 	lcall	_ak820_outline_0042
      007DC8 12 81 CD         [24] 1635 	lcall	_layer_hold_off
                                   1636 ;	quantum/action.c:688: break;
                                   1637 ;	quantum/action.c:689: case OP_OFF_ON:
      007DCB 80 4C            [24] 1638 	sjmp	00181$
      007DCD                       1639 00155$:
                                   1640 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007DCD E5 28            [12] 1641 	mov	a,_process_action_sloc0_1_0
      007DCF 60 08            [24] 1642 	jz	00208$
      007DD1 12 80 64         [24] 1643 	lcall	_ak820_outline_0042
      007DD4 12 82 72         [24] 1644 	lcall	_layer_off
      007DD7 80 40            [24] 1645 	sjmp	00181$
      007DD9                       1646 00208$:
      007DD9 12 80 64         [24] 1647 	lcall	_ak820_outline_0042
      007DDC 12 82 58         [24] 1648 	lcall	_layer_on
                                   1649 ;	quantum/action.c:691: break;
                                   1650 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007DDF 80 38            [24] 1651 	sjmp	00181$
      007DE1                       1652 00156$:
                                   1653 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007DE1 E5 28            [12] 1654 	mov	a,_process_action_sloc0_1_0
      007DE3 60 08            [24] 1655 	jz	00210$
      007DE5 12 80 64         [24] 1656 	lcall	_ak820_outline_0042
      007DE8 12 82 43         [24] 1657 	lcall	_layer_move
      007DEB 80 2C            [24] 1658 	sjmp	00181$
      007DED                       1659 00210$:
      007DED 12 82 3E         [24] 1660 	lcall	_layer_clear
                                   1661 ;	quantum/action.c:694: break;
                                   1662 ;	quantum/action.c:740: default:
      007DF0 80 27            [24] 1663 	sjmp	00181$
      007DF2                       1664 00160$:
                                   1665 ;	quantum/action.c:747: if (pressed) {
      007DF2 E5 28            [12] 1666 	mov	a,_process_action_sloc0_1_0
      007DF4 60 08            [24] 1667 	jz	00163$
                                   1668 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      007DF6 12 80 7E         [24] 1669 	lcall	_ak820_outline_0079
      007DF9 12 7E 30         [24] 1670 	lcall	_register_code
                                   1671 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007DFC 80 1B            [24] 1672 	sjmp	00181$
      007DFE                       1673 00163$:
                                   1674 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007DFE 12 80 BA         [24] 1675 	lcall	_ak820_outline_0153
      007E01 FF               [12] 1676 	mov	r7,a
      007E02 BF 39 0E         [24] 1677 	cjne	r7,#0x39,00175$
                                   1678 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007E05 7F 50            [12] 1679 	mov	r7,#0x50
      007E07                       1680 00187$:
      007E07 EF               [12] 1681 	mov	a,r7
      007E08 60 09            [24] 1682 	jz	00175$
      007E0A 90 00 01         [24] 1683 	mov	dptr,#0x0001
      007E0D 12 60 B1         [24] 1684 	lcall	_mDelaymS
      007E10 1F               [12] 1685 	dec	r7
                                   1686 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007E11 80 F4            [24] 1687 	sjmp	00187$
      007E13                       1688 00175$:
                                   1689 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007E13 12 80 7E         [24] 1690 	lcall	_ak820_outline_0079
      007E16 12 7E BD         [24] 1691 	lcall	_unregister_code
                                   1692 ;	quantum/action.c:840: }
      007E19                       1693 00181$:
                                   1694 ;	quantum/action.c:861: switch (action.kind.id) {
      007E19 90 08 BB         [24] 1695 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007E1C E0               [24] 1696 	movx	a,@dptr
      007E1D C4               [12] 1697 	swap	a
      007E1E 54 0F            [12] 1698 	anl	a,#0x0f
      007E20 FF               [12] 1699 	mov	r7,a
      007E21 BF 08 02         [24] 1700 	cjne	r7,#0x08,00478$
      007E24 80 03            [24] 1701 	sjmp	00183$
      007E26                       1702 00478$:
      007E26 BF 09 06         [24] 1703 	cjne	r7,#0x09,00192$
                                   1704 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      007E29                       1705 00183$:
                                   1706 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      007E29 12 74 90         [24] 1707 	lcall	_host_keyboard_leds
                                   1708 ;	quantum/action.c:872: }
                                   1709 ;	quantum/action.c:925: }
      007E2C 02 A0 55         [24] 1710 	ljmp	_led_set
      007E2F                       1711 00192$:
      007E2F 22               [24] 1712 	ret
                                   1713 ;------------------------------------------------------------
                                   1714 ;Allocation info for local variables in function 'register_code'
                                   1715 ;------------------------------------------------------------
                                   1716 ;code          Allocated with name '_register_code_code_10000_725'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function register_code
                                   1721 ;	-----------------------------------------
      007E30                       1722 _register_code:
      007E30 E5 82            [12] 1723 	mov	a,dpl
      007E32 90 08 C0         [24] 1724 	mov	dptr,#_register_code_code_10000_725
      007E35 F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action.c:932: if (code == KC_NO) {
      007E36 E0               [24] 1727 	movx	a,@dptr
      007E37 FF               [12] 1728 	mov	r7,a
      007E38 70 01            [24] 1729 	jnz	00123$
                                   1730 ;	quantum/action.c:933: return;
      007E3A 22               [24] 1731 	ret
      007E3B                       1732 00123$:
                                   1733 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      007E3B BF 04 00         [24] 1734 	cjne	r7,#0x04,00198$
      007E3E                       1735 00198$:
      007E3E 40 1F            [24] 1736 	jc	00119$
      007E40 EF               [12] 1737 	mov	a,r7
      007E41 24 5B            [12] 1738 	add	a,#0xff - 0xa4
      007E43 40 1A            [24] 1739 	jc	00119$
                                   1740 ;	free result
                                   1741 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007E45 8F 82            [24] 1742 	mov	dpl, r7
      007E47 C0 07            [24] 1743 	push	ar7
      007E49 12 86 A5         [24] 1744 	lcall	_add_owned_key
      007E4C E5 82            [12] 1745 	mov	a, dpl
      007E4E D0 07            [24] 1746 	pop	ar7
      007E50 70 01            [24] 1747 	jnz	00104$
      007E52 22               [24] 1748 	ret
      007E53                       1749 00104$:
                                   1750 ;	quantum/action.c:975: ak820_dynamic_macro_observe(code, true);
      007E53 90 04 C1         [24] 1751 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007E56 12 80 BF         [24] 1752 	lcall	_ak820_outline_0166
      007E59 12 3C 7B         [24] 1753 	lcall	_ak820_dynamic_macro_observe
                                   1754 ;	quantum/action.c:987: send_keyboard_report();
      007E5C 02 89 40         [24] 1755 	ljmp	_send_keyboard_report
      007E5F                       1756 00119$:
                                   1757 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007E5F 12 80 AE         [24] 1758 	lcall	_ak820_outline_0143
      007E62 BF E0 00         [24] 1759 	cjne	r7,#0xe0,00202$
      007E65                       1760 00202$:
      007E65 40 1A            [24] 1761 	jc	00115$
      007E67 EF               [12] 1762 	mov	a,r7
      007E68 24 18            [12] 1763 	add	a,#0xff - 0xe7
      007E6A 40 15            [24] 1764 	jc	00115$
                                   1765 ;	free result
                                   1766 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007E6C 74 07            [12] 1767 	mov	a,#0x07
      007E6E 5F               [12] 1768 	anl	a,r7
      007E6F 12 80 6D         [24] 1769 	lcall	_ak820_outline_0063
      007E72 80 02            [24] 1770 	sjmp	00206$
      007E74                       1771 00205$:
      007E74 25 E0            [12] 1772 	add	a,acc
      007E76                       1773 00206$:
      007E76 D5 F0 FB         [24] 1774 	djnz	b,00205$
      007E79 F5 82            [12] 1775 	mov	dpl,a
      007E7B 12 86 08         [24] 1776 	lcall	_add_owned_mods
                                   1777 ;	quantum/action.c:990: send_keyboard_report();
      007E7E 02 89 40         [24] 1778 	ljmp	_send_keyboard_report
      007E81                       1779 00115$:
                                   1780 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007E81 12 80 AE         [24] 1781 	lcall	_ak820_outline_0143
      007E84 BF A5 00         [24] 1782 	cjne	r7,#0xa5,00207$
      007E87                       1783 00207$:
      007E87 40 05            [24] 1784 	jc	00113$
      007E89 EF               [12] 1785 	mov	a,r7
      007E8A 24 58            [12] 1786 	add	a,#0xff - 0xa7
      007E8C 50 0D            [24] 1787 	jnc	00108$
                                   1788 ;	free result
      007E8E                       1789 00113$:
      007E8E 12 80 AE         [24] 1790 	lcall	_ak820_outline_0143
      007E91 BF A8 00         [24] 1791 	cjne	r7,#0xa8,00210$
      007E94                       1792 00210$:
      007E94 40 11            [24] 1793 	jc	00109$
      007E96 EF               [12] 1794 	mov	a,r7
      007E97 24 3D            [12] 1795 	add	a,#0xff - 0xc2
      007E99 40 0C            [24] 1796 	jc	00109$
                                   1797 ;	free result
      007E9B                       1798 00108$:
                                   1799 ;	quantum/action.c:995: owned_usage_key(code, true);
      007E9B 12 80 AE         [24] 1800 	lcall	_ak820_outline_0143
      007E9E 90 0B 1B         [24] 1801 	mov	dptr,#_owned_usage_key_PARM_2
      007EA1 12 80 BF         [24] 1802 	lcall	_ak820_outline_0166
      007EA4 02 87 EC         [24] 1803 	ljmp	_owned_usage_key
      007EA7                       1804 00109$:
                                   1805 ;	quantum/action.c:1002: } else if (IS_MOUSE_KEYCODE(code)) {
      007EA7 12 80 AE         [24] 1806 	lcall	_ak820_outline_0143
      007EAA BF CD 00         [24] 1807 	cjne	r7,#0xcd,00213$
      007EAD                       1808 00213$:
      007EAD 40 0D            [24] 1809 	jc	00125$
      007EAF EF               [12] 1810 	mov	a,r7
      007EB0 24 20            [12] 1811 	add	a,#0xff - 0xdf
      007EB2 40 08            [24] 1812 	jc	00125$
                                   1813 ;	free result
                                   1814 ;	quantum/action.c:1003: register_mouse(code, true);
      007EB4 90 08 B8         [24] 1815 	mov	dptr,#_register_mouse_PARM_2
      007EB7 12 80 BF         [24] 1816 	lcall	_ak820_outline_0166
                                   1817 ;	quantum/action.c:1005: }
      007EBA 61 43            [24] 1818 	ajmp	_register_mouse
      007EBC                       1819 00125$:
      007EBC 22               [24] 1820 	ret
                                   1821 ;------------------------------------------------------------
                                   1822 ;Allocation info for local variables in function 'unregister_code'
                                   1823 ;------------------------------------------------------------
                                   1824 ;code          Allocated with name '_unregister_code_code_10000_739'
                                   1825 ;------------------------------------------------------------
                                   1826 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1827 ;	-----------------------------------------
                                   1828 ;	 function unregister_code
                                   1829 ;	-----------------------------------------
      007EBD                       1830 _unregister_code:
      007EBD E5 82            [12] 1831 	mov	a,dpl
      007EBF 90 08 C1         [24] 1832 	mov	dptr,#_unregister_code_code_10000_739
      007EC2 F0               [24] 1833 	movx	@dptr,a
                                   1834 ;	quantum/action.c:1012: if (code == KC_NO) {
      007EC3 E0               [24] 1835 	movx	a,@dptr
      007EC4 FF               [12] 1836 	mov	r7,a
      007EC5 70 01            [24] 1837 	jnz	00121$
                                   1838 ;	quantum/action.c:1013: return;
      007EC7 22               [24] 1839 	ret
      007EC8                       1840 00121$:
                                   1841 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      007EC8 BF 04 00         [24] 1842 	cjne	r7,#0x04,00196$
      007ECB                       1843 00196$:
      007ECB 40 1F            [24] 1844 	jc	00117$
      007ECD EF               [12] 1845 	mov	a,r7
      007ECE 24 5B            [12] 1846 	add	a,#0xff - 0xa4
      007ED0 40 1A            [24] 1847 	jc	00117$
                                   1848 ;	free result
                                   1849 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007ED2 8F 82            [24] 1850 	mov	dpl, r7
      007ED4 C0 07            [24] 1851 	push	ar7
      007ED6 12 87 21         [24] 1852 	lcall	_del_owned_key
      007ED9 E5 82            [12] 1853 	mov	a, dpl
      007EDB D0 07            [24] 1854 	pop	ar7
      007EDD 70 01            [24] 1855 	jnz	00102$
      007EDF 22               [24] 1856 	ret
      007EE0                       1857 00102$:
                                   1858 ;	quantum/action.c:1049: ak820_dynamic_macro_observe(code, false);
      007EE0 90 04 C1         [24] 1859 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007EE3 12 80 C5         [24] 1860 	lcall	_ak820_outline_0185
      007EE6 12 3C 7B         [24] 1861 	lcall	_ak820_dynamic_macro_observe
                                   1862 ;	quantum/action.c:1054: send_keyboard_report();
      007EE9 02 89 40         [24] 1863 	ljmp	_send_keyboard_report
      007EEC                       1864 00117$:
                                   1865 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007EEC 12 80 B4         [24] 1866 	lcall	_ak820_outline_0144
      007EEF BF E0 00         [24] 1867 	cjne	r7,#0xe0,00200$
      007EF2                       1868 00200$:
      007EF2 40 1A            [24] 1869 	jc	00113$
      007EF4 EF               [12] 1870 	mov	a,r7
      007EF5 24 18            [12] 1871 	add	a,#0xff - 0xe7
      007EF7 40 15            [24] 1872 	jc	00113$
                                   1873 ;	free result
                                   1874 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007EF9 74 07            [12] 1875 	mov	a,#0x07
      007EFB 5F               [12] 1876 	anl	a,r7
      007EFC 12 80 6D         [24] 1877 	lcall	_ak820_outline_0063
      007EFF 80 02            [24] 1878 	sjmp	00204$
      007F01                       1879 00203$:
      007F01 25 E0            [12] 1880 	add	a,acc
      007F03                       1881 00204$:
      007F03 D5 F0 FB         [24] 1882 	djnz	b,00203$
      007F06 F5 82            [12] 1883 	mov	dpl,a
      007F08 12 86 15         [24] 1884 	lcall	_del_owned_mods
                                   1885 ;	quantum/action.c:1057: send_keyboard_report();
      007F0B 02 89 40         [24] 1886 	ljmp	_send_keyboard_report
      007F0E                       1887 00113$:
                                   1888 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007F0E 12 80 B4         [24] 1889 	lcall	_ak820_outline_0144
      007F11 BF A5 00         [24] 1890 	cjne	r7,#0xa5,00205$
      007F14                       1891 00205$:
      007F14 40 05            [24] 1892 	jc	00111$
      007F16 EF               [12] 1893 	mov	a,r7
      007F17 24 58            [12] 1894 	add	a,#0xff - 0xa7
      007F19 50 0D            [24] 1895 	jnc	00106$
                                   1896 ;	free result
      007F1B                       1897 00111$:
      007F1B 12 80 B4         [24] 1898 	lcall	_ak820_outline_0144
      007F1E BF A8 00         [24] 1899 	cjne	r7,#0xa8,00208$
      007F21                       1900 00208$:
      007F21 40 11            [24] 1901 	jc	00107$
      007F23 EF               [12] 1902 	mov	a,r7
      007F24 24 3D            [12] 1903 	add	a,#0xff - 0xc2
      007F26 40 0C            [24] 1904 	jc	00107$
                                   1905 ;	free result
      007F28                       1906 00106$:
                                   1907 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007F28 12 80 B4         [24] 1908 	lcall	_ak820_outline_0144
      007F2B 90 0B 1B         [24] 1909 	mov	dptr,#_owned_usage_key_PARM_2
      007F2E 12 80 C5         [24] 1910 	lcall	_ak820_outline_0185
      007F31 02 87 EC         [24] 1911 	ljmp	_owned_usage_key
      007F34                       1912 00107$:
                                   1913 ;	quantum/action.c:1069: } else if (IS_MOUSE_KEYCODE(code)) {
      007F34 12 80 B4         [24] 1914 	lcall	_ak820_outline_0144
      007F37 BF CD 00         [24] 1915 	cjne	r7,#0xcd,00211$
      007F3A                       1916 00211$:
      007F3A 40 0D            [24] 1917 	jc	00123$
      007F3C EF               [12] 1918 	mov	a,r7
      007F3D 24 20            [12] 1919 	add	a,#0xff - 0xdf
      007F3F 40 08            [24] 1920 	jc	00123$
                                   1921 ;	free result
                                   1922 ;	quantum/action.c:1070: register_mouse(code, false);
      007F41 90 08 B8         [24] 1923 	mov	dptr,#_register_mouse_PARM_2
      007F44 12 80 C5         [24] 1924 	lcall	_ak820_outline_0185
                                   1925 ;	quantum/action.c:1072: }
      007F47 61 43            [24] 1926 	ajmp	_register_mouse
      007F49                       1927 00123$:
      007F49 22               [24] 1928 	ret
                                   1929 ;------------------------------------------------------------
                                   1930 ;Allocation info for local variables in function 'tap_code_delay'
                                   1931 ;------------------------------------------------------------
                                   1932 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1933 ;code          Allocated with name '_tap_code_delay_code_10000_752'
                                   1934 ;i             Allocated with name '_tap_code_delay_i_20000_754'
                                   1935 ;i             Allocated with name '_tap_code_delay_i_50000_757'
                                   1936 ;------------------------------------------------------------
                                   1937 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1938 ;	-----------------------------------------
                                   1939 ;	 function tap_code_delay
                                   1940 ;	-----------------------------------------
      007F4A                       1941 _tap_code_delay:
      007F4A E5 82            [12] 1942 	mov	a,dpl
      007F4C 90 08 C4         [24] 1943 	mov	dptr,#_tap_code_delay_code_10000_752
      007F4F F0               [24] 1944 	movx	@dptr,a
                                   1945 ;	quantum/action.c:1080: register_code(code);
      007F50 E0               [24] 1946 	movx	a,@dptr
      007F51 FF               [12] 1947 	mov	r7,a
      007F52 F5 82            [12] 1948 	mov	dpl,a
      007F54 C0 07            [24] 1949 	push	ar7
      007F56 D1 30            [12] 1950 	acall	_register_code
      007F58 D0 07            [24] 1951 	pop	ar7
                                   1952 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007F5A 90 08 C2         [24] 1953 	mov	dptr,#_tap_code_delay_PARM_2
      007F5D 12 3A A4         [24] 1954 	lcall	_ak820_outline_0080
      007F60                       1955 00110$:
      007F60 ED               [12] 1956 	mov	a,r5
      007F61 4E               [12] 1957 	orl	a,r6
      007F62 60 0D            [24] 1958 	jz	00105$
                                   1959 ;	quantum/action.c:1082: wait_ms(1);
      007F64 90 00 01         [24] 1960 	mov	dptr,#0x0001
      007F67 12 60 B1         [24] 1961 	lcall	_mDelaymS
                                   1962 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007F6A 1D               [12] 1963 	dec	r5
      007F6B BD FF 01         [24] 1964 	cjne	r5,#0xff,00141$
      007F6E 1E               [12] 1965 	dec	r6
      007F6F                       1966 00141$:
      007F6F 80 EF            [24] 1967 	sjmp	00110$
      007F71                       1968 00105$:
                                   1969 ;	quantum/action.c:1084: unregister_code(code);
      007F71 8F 82            [24] 1970 	mov	dpl, r7
                                   1971 ;	quantum/action.c:1085: }
      007F73 C1 BD            [12] 1972 	ajmp	_unregister_code
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'tap_code'
                                   1975 ;------------------------------------------------------------
                                   1976 ;code          Allocated with name '_tap_code_code_10000_759'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1979 ;	-----------------------------------------
                                   1980 ;	 function tap_code
                                   1981 ;	-----------------------------------------
      007F75                       1982 _tap_code:
      007F75 E5 82            [12] 1983 	mov	a,dpl
      007F77 90 08 C5         [24] 1984 	mov	dptr,#_tap_code_code_10000_759
      007F7A F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007F7B E0               [24] 1987 	movx	a,@dptr
      007F7C FF               [12] 1988 	mov	r7,a
      007F7D BF 39 04         [24] 1989 	cjne	r7,#0x39,00103$
      007F80 7E 50            [12] 1990 	mov	r6,#0x50
      007F82 80 02            [24] 1991 	sjmp	00104$
      007F84                       1992 00103$:
      007F84 7E 00            [12] 1993 	mov	r6,#0x00
      007F86                       1994 00104$:
      007F86 90 08 C2         [24] 1995 	mov	dptr,#_tap_code_delay_PARM_2
      007F89 EE               [12] 1996 	mov	a,r6
      007F8A 12 3A DC         [24] 1997 	lcall	_ak820_outline_0136
      007F8D 8F 82            [24] 1998 	mov	dpl, r7
                                   1999 ;	quantum/action.c:1093: }
      007F8F E1 4A            [12] 2000 	ajmp	_tap_code_delay
                                   2001 ;------------------------------------------------------------
                                   2002 ;Allocation info for local variables in function 'register_mods'
                                   2003 ;------------------------------------------------------------
                                   2004 ;mods          Allocated with name '_register_mods_mods_10000_761'
                                   2005 ;------------------------------------------------------------
                                   2006 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   2007 ;	-----------------------------------------
                                   2008 ;	 function register_mods
                                   2009 ;	-----------------------------------------
      007F91                       2010 _register_mods:
      007F91 E5 82            [12] 2011 	mov	a,dpl
      007F93 90 08 C6         [24] 2012 	mov	dptr,#_register_mods_mods_10000_761
      007F96 F0               [24] 2013 	movx	@dptr,a
                                   2014 ;	quantum/action.c:1100: if (mods) {
      007F97 E0               [24] 2015 	movx	a,@dptr
      007F98 FF               [12] 2016 	mov	r7,a
      007F99 E0               [24] 2017 	movx	a,@dptr
      007F9A 60 08            [24] 2018 	jz	00103$
                                   2019 ;	quantum/action.c:1101: add_owned_mods(mods);
      007F9C 8F 82            [24] 2020 	mov	dpl, r7
      007F9E 12 86 08         [24] 2021 	lcall	_add_owned_mods
                                   2022 ;	quantum/action.c:1102: send_keyboard_report();
                                   2023 ;	quantum/action.c:1104: }
      007FA1 02 89 40         [24] 2024 	ljmp	_send_keyboard_report
      007FA4                       2025 00103$:
      007FA4 22               [24] 2026 	ret
                                   2027 ;------------------------------------------------------------
                                   2028 ;Allocation info for local variables in function 'unregister_mods'
                                   2029 ;------------------------------------------------------------
                                   2030 ;mods          Allocated with name '_unregister_mods_mods_10000_765'
                                   2031 ;------------------------------------------------------------
                                   2032 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   2033 ;	-----------------------------------------
                                   2034 ;	 function unregister_mods
                                   2035 ;	-----------------------------------------
      007FA5                       2036 _unregister_mods:
      007FA5 E5 82            [12] 2037 	mov	a,dpl
      007FA7 90 08 C7         [24] 2038 	mov	dptr,#_unregister_mods_mods_10000_765
      007FAA F0               [24] 2039 	movx	@dptr,a
                                   2040 ;	quantum/action.c:1111: if (mods) {
      007FAB E0               [24] 2041 	movx	a,@dptr
      007FAC FF               [12] 2042 	mov	r7,a
      007FAD E0               [24] 2043 	movx	a,@dptr
      007FAE 60 08            [24] 2044 	jz	00103$
                                   2045 ;	quantum/action.c:1112: del_owned_mods(mods);
      007FB0 8F 82            [24] 2046 	mov	dpl, r7
      007FB2 12 86 15         [24] 2047 	lcall	_del_owned_mods
                                   2048 ;	quantum/action.c:1113: send_keyboard_report();
                                   2049 ;	quantum/action.c:1115: }
      007FB5 02 89 40         [24] 2050 	ljmp	_send_keyboard_report
      007FB8                       2051 00103$:
      007FB8 22               [24] 2052 	ret
                                   2053 ;------------------------------------------------------------
                                   2054 ;Allocation info for local variables in function 'register_weak_mods'
                                   2055 ;------------------------------------------------------------
                                   2056 ;mods          Allocated with name '_register_weak_mods_mods_10000_769'
                                   2057 ;------------------------------------------------------------
                                   2058 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   2059 ;	-----------------------------------------
                                   2060 ;	 function register_weak_mods
                                   2061 ;	-----------------------------------------
      007FB9                       2062 _register_weak_mods:
      007FB9 E5 82            [12] 2063 	mov	a,dpl
      007FBB 90 08 C8         [24] 2064 	mov	dptr,#_register_weak_mods_mods_10000_769
      007FBE F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	quantum/action.c:1122: if (mods) {
      007FBF E0               [24] 2067 	movx	a,@dptr
      007FC0 FF               [12] 2068 	mov	r7,a
      007FC1 E0               [24] 2069 	movx	a,@dptr
      007FC2 60 08            [24] 2070 	jz	00103$
                                   2071 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007FC4 8F 82            [24] 2072 	mov	dpl, r7
      007FC6 12 86 22         [24] 2073 	lcall	_add_owned_weak_mods
                                   2074 ;	quantum/action.c:1124: send_keyboard_report();
                                   2075 ;	quantum/action.c:1126: }
      007FC9 02 89 40         [24] 2076 	ljmp	_send_keyboard_report
      007FCC                       2077 00103$:
      007FCC 22               [24] 2078 	ret
                                   2079 ;------------------------------------------------------------
                                   2080 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   2081 ;------------------------------------------------------------
                                   2082 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_773'
                                   2083 ;------------------------------------------------------------
                                   2084 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   2085 ;	-----------------------------------------
                                   2086 ;	 function unregister_weak_mods
                                   2087 ;	-----------------------------------------
      007FCD                       2088 _unregister_weak_mods:
      007FCD E5 82            [12] 2089 	mov	a,dpl
      007FCF 90 08 C9         [24] 2090 	mov	dptr,#_unregister_weak_mods_mods_10000_773
      007FD2 F0               [24] 2091 	movx	@dptr,a
                                   2092 ;	quantum/action.c:1133: if (mods) {
      007FD3 E0               [24] 2093 	movx	a,@dptr
      007FD4 FF               [12] 2094 	mov	r7,a
      007FD5 E0               [24] 2095 	movx	a,@dptr
      007FD6 60 08            [24] 2096 	jz	00103$
                                   2097 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007FD8 8F 82            [24] 2098 	mov	dpl, r7
      007FDA 12 86 31         [24] 2099 	lcall	_del_owned_weak_mods
                                   2100 ;	quantum/action.c:1135: send_keyboard_report();
                                   2101 ;	quantum/action.c:1137: }
      007FDD 02 89 40         [24] 2102 	ljmp	_send_keyboard_report
      007FE0                       2103 00103$:
      007FE0 22               [24] 2104 	ret
                                   2105 ;------------------------------------------------------------
                                   2106 ;Allocation info for local variables in function 'clear_keyboard'
                                   2107 ;------------------------------------------------------------
                                   2108 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   2109 ;	-----------------------------------------
                                   2110 ;	 function clear_keyboard
                                   2111 ;	-----------------------------------------
      007FE1                       2112 _clear_keyboard:
                                   2113 ;	quantum/action.c:1144: clear_mods();
      007FE1 12 89 BB         [24] 2114 	lcall	_clear_mods
                                   2115 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   2116 ;	quantum/action.c:1146: }
      007FE4 E1 E6            [12] 2117 	ajmp	_clear_keyboard_but_mods
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2120 ;------------------------------------------------------------
                                   2121 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   2122 ;	-----------------------------------------
                                   2123 ;	 function clear_keyboard_but_mods
                                   2124 ;	-----------------------------------------
      007FE6                       2125 _clear_keyboard_but_mods:
                                   2126 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007FE6 90 0E 4E         [24] 2127 	mov	dptr,#_actual_keyboard_report
      007FE9 75 F0 00         [24] 2128 	mov	b, #0x00
      007FEC 12 77 5F         [24] 2129 	lcall	_clear_keys_from_report
                                   2130 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   2131 ;	quantum/action.c:1155: }
      007FEF E1 F1            [12] 2132 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function clear_keyboard_but_mods_and_keys
                                   2139 ;	-----------------------------------------
      007FF1                       2140 _clear_keyboard_but_mods_and_keys:
                                   2141 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007FF1 12 4C 53         [24] 2142 	lcall	_ak820_tapping_cancel
                                   2143 ;	quantum/action.c:1165: ak820_dynamic_macro_cancel();
      007FF4 12 3B AC         [24] 2144 	lcall	_ak820_dynamic_macro_cancel
                                   2145 ;	quantum/action.c:1168: ak820_autoshift_cancel();
      007FF7 12 33 4A         [24] 2146 	lcall	_ak820_autoshift_cancel
                                   2147 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007FFA 12 2E F0         [24] 2148 	lcall	_ak820_oneshot_cancel
                                   2149 ;	quantum/action.c:1174: ak820_combo_cancel();
      007FFD 12 37 B7         [24] 2150 	lcall	_ak820_combo_cancel
                                   2151 ;	quantum/action.c:1177: repeat_key_cancel();
      008000 12 AA 22         [24] 2152 	lcall	_repeat_key_cancel
                                   2153 ;	quantum/action.c:1179: clear_owned_mods();
      008003 D1 40            [12] 2154 	acall	_clear_owned_mods
                                   2155 ;	quantum/action.c:1180: clear_owned_keys();
      008005 D1 78            [12] 2156 	acall	_clear_owned_keys
                                   2157 ;	quantum/action.c:1181: clear_owned_usages();
      008007 12 87 B4         [24] 2158 	lcall	_clear_owned_usages
                                   2159 ;	quantum/action.c:1182: layer_hold_clear();
      00800A 51 04            [12] 2160 	acall	_layer_hold_clear
                                   2161 ;	quantum/action.c:1184: clear_macro_tri_layer();
      00800C 12 A4 F6         [24] 2162 	lcall	_clear_macro_tri_layer
                                   2163 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00800F 90 0E 4E         [24] 2164 	mov	dptr,#_actual_keyboard_report
      008012 75 F0 00         [24] 2165 	mov	b, #0x00
      008015 12 77 5F         [24] 2166 	lcall	_clear_keys_from_report
                                   2167 ;	quantum/action.c:1189: host_system_send(0);
      008018 90 00 00         [24] 2168 	mov	dptr,#0x0000
      00801B 12 75 2B         [24] 2169 	lcall	_host_system_send
                                   2170 ;	quantum/action.c:1190: host_consumer_send(0);
      00801E 90 00 00         [24] 2171 	mov	dptr,#0x0000
      008021 12 75 5A         [24] 2172 	lcall	_host_consumer_send
                                   2173 ;	quantum/action.c:1192: clear_weak_mods();
      008024 12 89 F0         [24] 2174 	lcall	_clear_weak_mods
                                   2175 ;	quantum/action.c:1193: send_keyboard_report();
      008027 12 89 40         [24] 2176 	lcall	_send_keyboard_report
                                   2177 ;	quantum/action.c:1195: mousekey_clear();
      00802A 12 57 5D         [24] 2178 	lcall	_mousekey_clear
                                   2179 ;	quantum/action.c:1196: mousekey_send();
                                   2180 ;	quantum/action.c:1201: }
      00802D 02 56 25         [24] 2181 	ljmp	_mousekey_send
                                   2182 ;------------------------------------------------------------
                                   2183 ;Allocation info for local variables in function 'is_tap_record'
                                   2184 ;------------------------------------------------------------
                                   2185 ;record        Allocated with name '_is_tap_record_record_10000_789'
                                   2186 ;action        Allocated with name '_is_tap_record_action_10001_793'
                                   2187 ;------------------------------------------------------------
                                   2188 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   2189 ;	-----------------------------------------
                                   2190 	.area CSEG    (CODE)
                                   2191 	.area CONST   (CODE)
                                   2192 	.area XINIT   (CODE)
      00C9B9                       2193 __xinit__disable_action_cache:
      00C9B9 00                    2194 	.db #0x00	;  0
                                   2195 	.area CABS    (ABS,CODE)
                                   2196 
                                   2197 ; Experimental exact instruction outlining.
                                   2198 	.globl _ak820_outline_0001
                                   2199 	.globl _ak820_outline_0005
                                   2200 	.globl _ak820_outline_0006
                                   2201 	.globl _ak820_outline_0008
                                   2202 	.globl _ak820_outline_0009
                                   2203 	.globl _ak820_outline_0012
                                   2204 	.globl _ak820_outline_0013
                                   2205 	.globl _ak820_outline_0014
                                   2206 	.globl _ak820_outline_0016
                                   2207 	.globl _ak820_outline_0021
                                   2208 	.globl _ak820_outline_0022
                                   2209 	.globl _ak820_outline_0024
                                   2210 	.globl _ak820_outline_0031
                                   2211 	.globl _ak820_outline_0036
                                   2212 	.globl _ak820_outline_0042
                                   2213 	.globl _ak820_outline_0050
                                   2214 	.globl _ak820_outline_0051
                                   2215 	.globl _ak820_outline_0063
                                   2216 	.globl _ak820_outline_0071
                                   2217 	.globl _ak820_outline_0072
                                   2218 	.globl _ak820_outline_0076
                                   2219 	.globl _ak820_outline_0079
                                   2220 	.globl _ak820_outline_0080
                                   2221 	.globl _ak820_outline_0082
                                   2222 	.globl _ak820_outline_0091
                                   2223 	.globl _ak820_outline_0095
                                   2224 	.globl _ak820_outline_0097
                                   2225 	.globl _ak820_outline_0110
                                   2226 	.globl _ak820_outline_0111
                                   2227 	.globl _ak820_outline_0113
                                   2228 	.globl _ak820_outline_0115
                                   2229 	.globl _ak820_outline_0120
                                   2230 	.globl _ak820_outline_0125
                                   2231 	.globl _ak820_outline_0126
                                   2232 	.globl _ak820_outline_0127
                                   2233 	.globl _ak820_outline_0133
                                   2234 	.globl _ak820_outline_0136
                                   2235 	.globl _ak820_outline_0143
                                   2236 	.globl _ak820_outline_0144
                                   2237 	.globl _ak820_outline_0146
                                   2238 	.globl _ak820_outline_0147
                                   2239 	.globl _ak820_outline_0148
                                   2240 	.globl _ak820_outline_0153
                                   2241 	.globl _ak820_outline_0154
                                   2242 	.globl _ak820_outline_0166
                                   2243 	.globl _ak820_outline_0184
                                   2244 	.globl _ak820_outline_0185
                                   2245 	.globl _ak820_outline_0190
                                   2246 
                                   2247 	.area CSEG (CODE)
                                   2248 ; function ak820_outline_0006
      008030                       2249 _ak820_outline_0006:
      008030 2D               [12] 2250 	add	a,r5
      008031 FA               [12] 2251 	mov	r2,a
      008032 E4               [12] 2252 	clr	a
      008033 3E               [12] 2253 	addc	a,r6
      008034 FB               [12] 2254 	mov	r3,a
      008035 8F 04            [24] 2255 	mov	ar4,r7
      008037 8A 82            [24] 2256 	mov	dpl,r2
      008039 8B 83            [24] 2257 	mov	dph,r3
      00803B 8C F0            [24] 2258 	mov	b,r4
      00803D 22               [24] 2259 	ret
                                   2260 
                                   2261 	.area CSEG (CODE)
                                   2262 ; function ak820_outline_0014
      00803E                       2263 _ak820_outline_0014:
      00803E 2D               [12] 2264 	add	a,r5
      00803F F9               [12] 2265 	mov	r1,a
      008040 E4               [12] 2266 	clr	a
      008041 3E               [12] 2267 	addc	a,r6
      008042 FA               [12] 2268 	mov	r2,a
      008043 8F 03            [24] 2269 	mov	ar3,r7
      008045 89 82            [24] 2270 	mov	dpl,r1
      008047 8A 83            [24] 2271 	mov	dph,r2
      008049 8B F0            [24] 2272 	mov	b,r3
      00804B 22               [24] 2273 	ret
                                   2274 
                                   2275 	.area CSEG (CODE)
                                   2276 ; function ak820_outline_0021
      00804C                       2277 _ak820_outline_0021:
      00804C 8E 82            [24] 2278 	mov	dpl,r6
      00804E 8F 83            [24] 2279 	mov	dph,r7
      008050 A3               [24] 2280 	inc	dptr
      008051 E0               [24] 2281 	movx	a,@dptr
      008052 FC               [12] 2282 	mov	r4,a
      008053 7D 00            [12] 2283 	mov	r5,#0x00
      008055 8E 82            [24] 2284 	mov	dpl,r6
      008057 8F 83            [24] 2285 	mov	dph,r7
      008059 E0               [24] 2286 	movx	a,@dptr
      00805A 22               [24] 2287 	ret
                                   2288 
                                   2289 	.area CSEG (CODE)
                                   2290 ; function ak820_outline_0024
      00805B                       2291 _ak820_outline_0024:
      00805B E0               [24] 2292 	movx	a,@dptr
      00805C FB               [12] 2293 	mov	r3,a
      00805D A3               [24] 2294 	inc	dptr
      00805E E0               [24] 2295 	movx	a,@dptr
      00805F FC               [12] 2296 	mov	r4,a
      008060 A3               [24] 2297 	inc	dptr
      008061 E0               [24] 2298 	movx	a,@dptr
      008062 FD               [12] 2299 	mov	r5,a
      008063 22               [24] 2300 	ret
                                   2301 
                                   2302 	.area CSEG (CODE)
                                   2303 ; function ak820_outline_0042
      008064                       2304 _ak820_outline_0042:
      008064 90 08 BB         [24] 2305 	mov	dptr,#(_process_action_PARM_2+0x0001)
      008067 E0               [24] 2306 	movx	a,@dptr
      008068 54 1F            [12] 2307 	anl	a,#0x1f
      00806A F5 82            [12] 2308 	mov	dpl,a
      00806C 22               [24] 2309 	ret
                                   2310 
                                   2311 	.area CSEG (CODE)
                                   2312 ; function ak820_outline_0063
      00806D                       2313 _ak820_outline_0063:
      00806D F5 F0            [12] 2314 	mov	b,a
      00806F 05 F0            [12] 2315 	inc	b
      008071 74 01            [12] 2316 	mov	a,#0x01
      008073 22               [24] 2317 	ret
                                   2318 
                                   2319 	.area CSEG (CODE)
                                   2320 ; function ak820_outline_0071
      008074                       2321 _ak820_outline_0071:
      008074 90 0E 2B         [24] 2322 	mov	dptr,#___memcpy_PARM_3
      008077 74 06            [12] 2323 	mov	a,#0x06
      008079 F0               [24] 2324 	movx	@dptr,a
      00807A E4               [12] 2325 	clr	a
      00807B A3               [24] 2326 	inc	dptr
      00807C F0               [24] 2327 	movx	@dptr,a
      00807D 22               [24] 2328 	ret
                                   2329 
                                   2330 	.area CSEG (CODE)
                                   2331 ; function ak820_outline_0079
      00807E                       2332 _ak820_outline_0079:
      00807E 90 08 BA         [24] 2333 	mov	dptr,#_process_action_PARM_2
      008081 E0               [24] 2334 	movx	a,@dptr
      008082 F5 82            [12] 2335 	mov	dpl,a
      008084 22               [24] 2336 	ret
                                   2337 
                                   2338 	.area CSEG (CODE)
                                   2339 ; function ak820_outline_0082
      008085                       2340 _ak820_outline_0082:
      008085 2D               [12] 2341 	add	a,r5
      008086 F8               [12] 2342 	mov	r0,a
      008087 E4               [12] 2343 	clr	a
      008088 3E               [12] 2344 	addc	a,r6
      008089 F9               [12] 2345 	mov	r1,a
      00808A 8F 02            [24] 2346 	mov	ar2,r7
      00808C 88 82            [24] 2347 	mov	dpl,r0
      00808E 89 83            [24] 2348 	mov	dph,r1
      008090 8A F0            [24] 2349 	mov	b,r2
      008092 22               [24] 2350 	ret
                                   2351 
                                   2352 	.area CSEG (CODE)
                                   2353 ; function ak820_outline_0091
      008093                       2354 _ak820_outline_0091:
      008093 90 08 BB         [24] 2355 	mov	dptr,#(_process_action_PARM_2+0x0001)
      008096 E0               [24] 2356 	movx	a,@dptr
      008097 03               [12] 2357 	rr	a
      008098 03               [12] 2358 	rr	a
      008099 54 03            [12] 2359 	anl	a,#0x03
      00809B 22               [24] 2360 	ret
                                   2361 
                                   2362 	.area CSEG (CODE)
                                   2363 ; function ak820_outline_0115
      00809C                       2364 _ak820_outline_0115:
      00809C 90 08 BB         [24] 2365 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00809F E0               [24] 2366 	movx	a,@dptr
      0080A0 54 0F            [12] 2367 	anl	a,#0x0f
      0080A2 22               [24] 2368 	ret
                                   2369 
                                   2370 	.area CSEG (CODE)
                                   2371 ; function ak820_outline_0133
      0080A3                       2372 _ak820_outline_0133:
      0080A3 90 08 BA         [24] 2373 	mov	dptr,#_process_action_PARM_2
      0080A6 E0               [24] 2374 	movx	a,@dptr
      0080A7 FE               [12] 2375 	mov	r6,a
      0080A8 A3               [24] 2376 	inc	dptr
      0080A9 E0               [24] 2377 	movx	a,@dptr
      0080AA 54 03            [12] 2378 	anl	a,#0x03
      0080AC FF               [12] 2379 	mov	r7,a
      0080AD 22               [24] 2380 	ret
                                   2381 
                                   2382 	.area CSEG (CODE)
                                   2383 ; function ak820_outline_0143
      0080AE                       2384 _ak820_outline_0143:
      0080AE 90 08 C0         [24] 2385 	mov	dptr,#_register_code_code_10000_725
      0080B1 E0               [24] 2386 	movx	a,@dptr
      0080B2 FF               [12] 2387 	mov	r7,a
      0080B3 22               [24] 2388 	ret
                                   2389 
                                   2390 	.area CSEG (CODE)
                                   2391 ; function ak820_outline_0144
      0080B4                       2392 _ak820_outline_0144:
      0080B4 90 08 C1         [24] 2393 	mov	dptr,#_unregister_code_code_10000_739
      0080B7 E0               [24] 2394 	movx	a,@dptr
      0080B8 FF               [12] 2395 	mov	r7,a
      0080B9 22               [24] 2396 	ret
                                   2397 
                                   2398 	.area CSEG (CODE)
                                   2399 ; function ak820_outline_0153
      0080BA                       2400 _ak820_outline_0153:
      0080BA 90 08 BA         [24] 2401 	mov	dptr,#_process_action_PARM_2
      0080BD E0               [24] 2402 	movx	a,@dptr
      0080BE 22               [24] 2403 	ret
                                   2404 
                                   2405 	.area CSEG (CODE)
                                   2406 ; function ak820_outline_0166
      0080BF                       2407 _ak820_outline_0166:
      0080BF 74 01            [12] 2408 	mov	a,#0x01
      0080C1 F0               [24] 2409 	movx	@dptr,a
      0080C2 8F 82            [24] 2410 	mov	dpl,r7
      0080C4 22               [24] 2411 	ret
                                   2412 
                                   2413 	.area CSEG (CODE)
                                   2414 ; function ak820_outline_0185
      0080C5                       2415 _ak820_outline_0185:
      0080C5 E4               [12] 2416 	clr	a
      0080C6 F0               [24] 2417 	movx	@dptr,a
      0080C7 8F 82            [24] 2418 	mov	dpl,r7
      0080C9 22               [24] 2419 	ret
                                   2420 
                                   2421 	.area CSEG (CODE)
                                   2422 ; function ak820_outline_0190
      0080CA                       2423 _ak820_outline_0190:
      0080CA F0               [24] 2424 	movx	@dptr,a
      0080CB EB               [12] 2425 	mov	a,r3
      0080CC A3               [24] 2426 	inc	dptr
      0080CD F0               [24] 2427 	movx	@dptr,a
      0080CE 22               [24] 2428 	ret
