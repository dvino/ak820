                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006E8                         85 _eeprom_read_word_addr_10000_91:
      0006E8                         86 	.ds 3
      0006EB                         87 _eeprom_read_word_ret_10000_92:
      0006EB                         88 	.ds 2
      0006ED                         89 _eeprom_read_dword_addr_10000_93:
      0006ED                         90 	.ds 3
      0006F0                         91 _eeprom_read_dword_ret_10000_94:
      0006F0                         92 	.ds 4
      0006F4                         93 _eeprom_write_byte_PARM_2:
      0006F4                         94 	.ds 1
      0006F5                         95 _eeprom_write_byte_addr_10000_95:
      0006F5                         96 	.ds 3
      0006F8                         97 _eeprom_write_word_PARM_2:
      0006F8                         98 	.ds 2
      0006FA                         99 _eeprom_write_word_addr_10000_97:
      0006FA                        100 	.ds 3
      0006FD                        101 _eeprom_write_dword_PARM_2:
      0006FD                        102 	.ds 4
      000701                        103 _eeprom_write_dword_addr_10000_99:
      000701                        104 	.ds 3
      000704                        105 _eeprom_update_byte_PARM_2:
      000704                        106 	.ds 1
      000705                        107 _eeprom_update_byte_addr_10000_107:
      000705                        108 	.ds 3
      000708                        109 _eeprom_update_word_PARM_2:
      000708                        110 	.ds 2
      00070A                        111 _eeprom_update_word_addr_10000_111:
      00070A                        112 	.ds 3
      00070D                        113 _eeprom_update_dword_PARM_2:
      00070D                        114 	.ds 4
      000711                        115 _eeprom_update_dword_addr_10000_115:
      000711                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0052F7                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0052F7 12 48 A0         [24]  170 	lcall	_ak820_outline_0036
      0052FA 90 06 E8         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052FD 12 3A 5F         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005300 90 06 EB         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005303 12 55 02         [24]  175 	lcall	_ak820_outline_0184
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      005306 90 06 E8         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005309 12 54 AF         [24]  178 	lcall	_ak820_outline_0013
      00530C 90 05 EB         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00530F ED               [12]  180 	mov	a,r5
      005310 12 3A 5F         [24]  181 	lcall	_ak820_outline_0016
      005313 90 05 EE         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005316 12 54 F4         [24]  183 	lcall	_ak820_outline_0113
      005319 90 06 EB         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00531C 12 46 3C         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      00531F 90 06 EB         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005322 12 54 EB         [24]  188 	lcall	_ak820_outline_0094
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005325 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005326                        201 _eeprom_read_dword:
      005326 12 48 A0         [24]  202 	lcall	_ak820_outline_0036
      005329 90 06 ED         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00532C 12 3A 5F         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      00532F 90 06 F0         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005332 12 54 C0         [24]  207 	lcall	_ak820_outline_0052
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      005335 90 06 ED         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005338 12 54 AF         [24]  210 	lcall	_ak820_outline_0013
      00533B 90 05 EB         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00533E ED               [12]  212 	mov	a,r5
      00533F 12 3A 5F         [24]  213 	lcall	_ak820_outline_0016
      005342 90 05 EE         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005345 74 04            [12]  215 	mov	a,#0x04
      005347 12 3A DC         [24]  216 	lcall	_ak820_outline_0136
      00534A 90 06 F0         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00534D 12 46 3C         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005350 90 06 F0         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005353 12 54 C9         [24]  221 	lcall	_ak820_outline_0056
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005356 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      005357                        234 _eeprom_write_byte:
      005357 12 48 A0         [24]  235 	lcall	_ak820_outline_0036
      00535A 90 06 F5         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      00535D 12 3A 5F         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005360 90 06 F5         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005363 12 54 98         [24]  240 	lcall	_ak820_outline_0004
      005366 74 01            [12]  241 	mov	a,#0x01
      005368 12 3A DC         [24]  242 	lcall	_ak820_outline_0136
      00536B 90 06 F4         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      00536E 02 46 C8         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005371                        256 _eeprom_write_word:
      005371 12 48 A0         [24]  257 	lcall	_ak820_outline_0036
      005374 90 06 FA         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005377 12 3A 5F         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00537A 90 06 FA         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00537D 12 54 98         [24]  262 	lcall	_ak820_outline_0004
      005380 12 54 F4         [24]  263 	lcall	_ak820_outline_0113
      005383 90 06 F8         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005386 02 46 C8         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005389                        277 _eeprom_write_dword:
      005389 12 48 A0         [24]  278 	lcall	_ak820_outline_0036
      00538C 90 07 01         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00538F 12 3A 5F         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005392 90 07 01         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005395 12 54 98         [24]  283 	lcall	_ak820_outline_0004
      005398 74 04            [12]  284 	mov	a,#0x04
      00539A 12 3A DC         [24]  285 	lcall	_ak820_outline_0136
      00539D 90 06 FD         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      0053A0 02 46 C8         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      0053A3                        307 _eeprom_update_byte:
      0053A3 C0 07            [24]  308 	push	ar7
      0053A5 C0 06            [24]  309 	push	ar6
      0053A7 C0 05            [24]  310 	push	ar5
      0053A9 C0 04            [24]  311 	push	ar4
      0053AB 12 48 A0         [24]  312 	lcall	_ak820_outline_0036
      0053AE 90 07 05         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053B1 12 3A 5F         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      0053B4 90 07 05         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053B7 12 54 89         [24]  317 	lcall	_ak820_outline_0001
      0053BA 12 46 01         [24]  318 	lcall	_eeprom_read_byte
      0053BD AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      0053BF 90 07 04         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      0053C2 E0               [24]  322 	movx	a,@dptr
      0053C3 FE               [12]  323 	mov	r6,a
      0053C4 EF               [12]  324 	mov	a,r7
      0053C5 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      0053C8 80 35            [24]  326 	sjmp	00103$
      0053CA                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      0053CA 90 07 05         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053CD 12 3A 98         [24]  330 	lcall	_ak820_outline_0061
      0053D0 A3               [24]  331 	inc	dptr
      0053D1 E0               [24]  332 	movx	a,@dptr
      0053D2 FF               [12]  333 	mov	r7,a
      0053D3 90 06 F4         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0053D6 EE               [12]  335 	mov	a,r6
      0053D7 12 3A B6         [24]  336 	lcall	_ak820_outline_0104
      0053DA 8F F0            [24]  337 	mov	b, r7
      0053DC C0 07            [24]  338 	push	ar7
      0053DE C0 06            [24]  339 	push	ar6
      0053E0 C0 05            [24]  340 	push	ar5
      0053E2 C0 04            [24]  341 	push	ar4
      0053E4 C0 03            [24]  342 	push	ar3
      0053E6 C0 02            [24]  343 	push	ar2
      0053E8 C0 01            [24]  344 	push	ar1
      0053EA C0 00            [24]  345 	push	ar0
      0053EC 12 53 57         [24]  346 	lcall	_eeprom_write_byte
      0053EF D0 00            [24]  347 	pop	ar0
      0053F1 D0 01            [24]  348 	pop	ar1
      0053F3 D0 02            [24]  349 	pop	ar2
      0053F5 D0 03            [24]  350 	pop	ar3
      0053F7 D0 04            [24]  351 	pop	ar4
      0053F9 D0 05            [24]  352 	pop	ar5
      0053FB D0 06            [24]  353 	pop	ar6
      0053FD D0 07            [24]  354 	pop	ar7
      0053FF                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0053FF D0 04            [24]  357 	pop	ar4
      005401 D0 05            [24]  358 	pop	ar5
      005403 D0 06            [24]  359 	pop	ar6
      005405 D0 07            [24]  360 	pop	ar7
      005407 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      005408                        373 _eeprom_update_word:
      005408 12 48 A0         [24]  374 	lcall	_ak820_outline_0036
      00540B 90 07 0A         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00540E 12 3A 5F         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005411 90 07 0A         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005414 12 54 89         [24]  379 	lcall	_ak820_outline_0001
      005417 12 52 F7         [24]  380 	lcall	_eeprom_read_word
      00541A 12 48 E9         [24]  381 	lcall	_ak820_outline_0127
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      00541D 90 07 08         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      005420 12 3A 98         [24]  384 	lcall	_ak820_outline_0061
      005423 EE               [12]  385 	mov	a,r6
      005424 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      005427 EF               [12]  387 	mov	a,r7
      005428 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      00542B 22               [24]  389 	ret
      00542C                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00542C 90 07 0A         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00542F E0               [24]  393 	movx	a,@dptr
      005430 FB               [12]  394 	mov	r3,a
      005431 A3               [24]  395 	inc	dptr
      005432 12 3A 81         [24]  396 	lcall	_ak820_outline_0053
      005435 90 06 F8         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      005438 12 3A 9E         [24]  398 	lcall	_ak820_outline_0072
      00543B 8B 82            [24]  399 	mov	dpl, r3
      00543D 8E 83            [24]  400 	mov	dph, r6
      00543F 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      005441 02 53 71         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      005444                        415 _eeprom_update_dword:
      005444 12 48 A0         [24]  416 	lcall	_ak820_outline_0036
      005447 90 07 11         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00544A 12 3A 5F         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      00544D 90 07 11         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005450 12 54 89         [24]  421 	lcall	_ak820_outline_0001
      005453 12 53 26         [24]  422 	lcall	_eeprom_read_dword
      005456 12 54 DA         [24]  423 	lcall	_ak820_outline_0058
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      005459 90 07 0D         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      00545C E0               [24]  426 	movx	a,@dptr
      00545D F8               [12]  427 	mov	r0,a
      00545E A3               [24]  428 	inc	dptr
      00545F 12 54 E2         [24]  429 	lcall	_ak820_outline_0093
      005462 EC               [12]  430 	mov	a,r4
      005463 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      005466 ED               [12]  432 	mov	a,r5
      005467 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      00546A EE               [12]  434 	mov	a,r6
      00546B B5 02 05         [24]  435 	cjne	a,ar2,00112$
      00546E EF               [12]  436 	mov	a,r7
      00546F B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005472 22               [24]  438 	ret
      005473                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005473 90 07 11         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005476 12 54 AF         [24]  442 	lcall	_ak820_outline_0013
      005479 90 06 FD         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      00547C E8               [12]  444 	mov	a,r0
      00547D F0               [24]  445 	movx	@dptr,a
      00547E E9               [12]  446 	mov	a,r1
      00547F A3               [24]  447 	inc	dptr
      005480 12 54 FB         [24]  448 	lcall	_ak820_outline_0161
      005483 12 54 B8         [24]  449 	lcall	_ak820_outline_0031
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      005486 02 53 89         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0013
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0031
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0052
                                    465 	.globl _ak820_outline_0053
                                    466 	.globl _ak820_outline_0056
                                    467 	.globl _ak820_outline_0058
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0093
                                    471 	.globl _ak820_outline_0094
                                    472 	.globl _ak820_outline_0104
                                    473 	.globl _ak820_outline_0113
                                    474 	.globl _ak820_outline_0127
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0161
                                    477 	.globl _ak820_outline_0184
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      005489                        481 _ak820_outline_0001:
      005489 E0               [24]  482 	movx	a,@dptr
      00548A FD               [12]  483 	mov	r5,a
      00548B A3               [24]  484 	inc	dptr
      00548C E0               [24]  485 	movx	a,@dptr
      00548D FE               [12]  486 	mov	r6,a
      00548E A3               [24]  487 	inc	dptr
      00548F E0               [24]  488 	movx	a,@dptr
      005490 FF               [12]  489 	mov	r7,a
      005491 8D 82            [24]  490 	mov	dpl,r5
      005493 8E 83            [24]  491 	mov	dph,r6
      005495 8F F0            [24]  492 	mov	b,r7
      005497 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      005498                        497 _ak820_outline_0004:
      005498 E0               [24]  498 	movx	a,@dptr
      005499 FD               [12]  499 	mov	r5,a
      00549A A3               [24]  500 	inc	dptr
      00549B E0               [24]  501 	movx	a,@dptr
      00549C FE               [12]  502 	mov	r6,a
      00549D A3               [24]  503 	inc	dptr
      00549E E0               [24]  504 	movx	a,@dptr
      00549F FF               [12]  505 	mov	r7,a
      0054A0 90 05 F4         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0054A3 ED               [12]  507 	mov	a,r5
      0054A4 F0               [24]  508 	movx	@dptr,a
      0054A5 EE               [12]  509 	mov	a,r6
      0054A6 A3               [24]  510 	inc	dptr
      0054A7 F0               [24]  511 	movx	@dptr,a
      0054A8 EF               [12]  512 	mov	a,r7
      0054A9 A3               [24]  513 	inc	dptr
      0054AA F0               [24]  514 	movx	@dptr,a
      0054AB 90 05 F7         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0054AE 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0013
      0054AF                        520 _ak820_outline_0013:
      0054AF E0               [24]  521 	movx	a,@dptr
      0054B0 FD               [12]  522 	mov	r5,a
      0054B1 A3               [24]  523 	inc	dptr
      0054B2 E0               [24]  524 	movx	a,@dptr
      0054B3 FE               [12]  525 	mov	r6,a
      0054B4 A3               [24]  526 	inc	dptr
      0054B5 E0               [24]  527 	movx	a,@dptr
      0054B6 FF               [12]  528 	mov	r7,a
      0054B7 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0031
      0054B8                        533 _ak820_outline_0031:
      0054B8 F0               [24]  534 	movx	@dptr,a
      0054B9 8D 82            [24]  535 	mov	dpl,r5
      0054BB 8E 83            [24]  536 	mov	dph,r6
      0054BD 8F F0            [24]  537 	mov	b,r7
      0054BF 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0052
      0054C0                        542 _ak820_outline_0052:
      0054C0 E4               [12]  543 	clr	a
      0054C1 F0               [24]  544 	movx	@dptr,a
      0054C2 A3               [24]  545 	inc	dptr
      0054C3 F0               [24]  546 	movx	@dptr,a
      0054C4 A3               [24]  547 	inc	dptr
      0054C5 F0               [24]  548 	movx	@dptr,a
      0054C6 A3               [24]  549 	inc	dptr
      0054C7 F0               [24]  550 	movx	@dptr,a
      0054C8 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0056
      0054C9                        555 _ak820_outline_0056:
      0054C9 E0               [24]  556 	movx	a,@dptr
      0054CA FC               [12]  557 	mov	r4,a
      0054CB A3               [24]  558 	inc	dptr
      0054CC E0               [24]  559 	movx	a,@dptr
      0054CD FD               [12]  560 	mov	r5,a
      0054CE A3               [24]  561 	inc	dptr
      0054CF E0               [24]  562 	movx	a,@dptr
      0054D0 FE               [12]  563 	mov	r6,a
      0054D1 A3               [24]  564 	inc	dptr
      0054D2 E0               [24]  565 	movx	a,@dptr
      0054D3 8C 82            [24]  566 	mov	dpl,r4
      0054D5 8D 83            [24]  567 	mov	dph,r5
      0054D7 8E F0            [24]  568 	mov	b,r6
      0054D9 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0058
      0054DA                        573 _ak820_outline_0058:
      0054DA AC 82            [24]  574 	mov	r4,dpl
      0054DC AD 83            [24]  575 	mov	r5,dph
      0054DE AE F0            [24]  576 	mov	r6,b
      0054E0 FF               [12]  577 	mov	r7,a
      0054E1 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0093
      0054E2                        582 _ak820_outline_0093:
      0054E2 E0               [24]  583 	movx	a,@dptr
      0054E3 F9               [12]  584 	mov	r1,a
      0054E4 A3               [24]  585 	inc	dptr
      0054E5 E0               [24]  586 	movx	a,@dptr
      0054E6 FA               [12]  587 	mov	r2,a
      0054E7 A3               [24]  588 	inc	dptr
      0054E8 E0               [24]  589 	movx	a,@dptr
      0054E9 FB               [12]  590 	mov	r3,a
      0054EA 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0094
      0054EB                        595 _ak820_outline_0094:
      0054EB E0               [24]  596 	movx	a,@dptr
      0054EC FE               [12]  597 	mov	r6,a
      0054ED A3               [24]  598 	inc	dptr
      0054EE E0               [24]  599 	movx	a,@dptr
      0054EF 8E 82            [24]  600 	mov	dpl,r6
      0054F1 F5 83            [12]  601 	mov	dph,a
      0054F3 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0113
      0054F4                        606 _ak820_outline_0113:
      0054F4 74 02            [12]  607 	mov	a,#0x02
      0054F6 F0               [24]  608 	movx	@dptr,a
      0054F7 E4               [12]  609 	clr	a
      0054F8 A3               [24]  610 	inc	dptr
      0054F9 F0               [24]  611 	movx	@dptr,a
      0054FA 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0161
      0054FB                        616 _ak820_outline_0161:
      0054FB F0               [24]  617 	movx	@dptr,a
      0054FC EA               [12]  618 	mov	a,r2
      0054FD A3               [24]  619 	inc	dptr
      0054FE F0               [24]  620 	movx	@dptr,a
      0054FF EB               [12]  621 	mov	a,r3
      005500 A3               [24]  622 	inc	dptr
      005501 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0184
      005502                        627 _ak820_outline_0184:
      005502 E4               [12]  628 	clr	a
      005503 F0               [24]  629 	movx	@dptr,a
      005504 A3               [24]  630 	inc	dptr
      005505 F0               [24]  631 	movx	@dptr,a
      005506 22               [24]  632 	ret
