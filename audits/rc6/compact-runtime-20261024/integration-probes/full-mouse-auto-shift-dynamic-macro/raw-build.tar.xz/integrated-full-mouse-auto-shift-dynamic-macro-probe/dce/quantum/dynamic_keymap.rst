                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      00002A                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      00002A                        588 	.ds 2
      00002C                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002C                        590 	.ds 1
      00002D                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002D                        592 	.ds 1
      00002E                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002E                        594 	.ds 2
      000030                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000030                        596 	.ds 2
      000032                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000032                        598 	.ds 1
      000033                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000033                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000027                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B60                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B60                        628 	.ds 1
      000B61                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B61                        630 	.ds 1
      000B62                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000B62                        632 	.ds 1
      000B63                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B63                        634 	.ds 1
      000B64                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B64                        636 	.ds 1
      000B65                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000B65                        638 	.ds 1
      000B66                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B66                        640 	.ds 1
      000B67                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B67                        642 	.ds 1
      000B68                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B68                        644 	.ds 2
      000B6A                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000B6A                        646 	.ds 1
      000B6B                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B6B                        648 	.ds 1
      000B6C                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000B6C                        650 	.ds 1
      000B6D                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B6D                        652 	.ds 1
      000B6E                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B6E                        654 	.ds 1
      000B6F                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000B6F                        656 	.ds 1
      000B70                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B70                        658 	.ds 1
      000B71                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B71                        660 	.ds 1
      000B72                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B72                        662 	.ds 2
      000B74                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000B74                        664 	.ds 1
      000B75                        665 _dynamic_keymap_get_combo_PARM_2:
      000B75                        666 	.ds 3
      000B78                        667 _dynamic_keymap_get_combo_index_10000_385:
      000B78                        668 	.ds 1
      000B79                        669 _dynamic_keymap_set_combo_PARM_2:
      000B79                        670 	.ds 3
      000B7C                        671 _dynamic_keymap_set_combo_index_10000_391:
      000B7C                        672 	.ds 1
      000B7D                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000B7D                        674 	.ds 10
      000B87                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B87                        676 	.ds 1
      000B88                        677 _dynamic_keymap_reset_combo_10001_408:
      000B88                        678 	.ds 10
      000B92                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B92                        680 	.ds 2
      000B94                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B94                        682 	.ds 2
      000B96                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B96                        684 	.ds 2
      000B98                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B98                        686 	.ds 3
      000B9B                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B9B                        688 	.ds 2
      000B9D                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B9D                        690 	.ds 1
      000B9E                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B9E                        692 	.ds 2
      000BA0                        693 _dynamic_keymap_get_buffer_PARM_3:
      000BA0                        694 	.ds 3
      000BA3                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000BA3                        696 	.ds 2
      000BA5                        697 _dynamic_keymap_set_buffer_PARM_2:
      000BA5                        698 	.ds 2
      000BA7                        699 _dynamic_keymap_set_buffer_PARM_3:
      000BA7                        700 	.ds 3
      000BAA                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000BAA                        702 	.ds 2
      000BAC                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000BAC                        704 	.ds 1
      000BAD                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000BAD                        706 	.ds 1
      000BAE                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000BAE                        708 	.ds 1
      000BAF                        709 _keycode_at_keymap_location_PARM_2:
      000BAF                        710 	.ds 1
      000BB0                        711 _keycode_at_keymap_location_PARM_3:
      000BB0                        712 	.ds 1
      000BB1                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000BB1                        714 	.ds 1
      000BB2                        715 _keycode_at_encodermap_location_PARM_2:
      000BB2                        716 	.ds 1
      000BB3                        717 _keycode_at_encodermap_location_PARM_3:
      000BB3                        718 	.ds 1
      000BB4                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000BB4                        720 	.ds 1
      000BB5                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BB5                        722 	.ds 2
      000BB7                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000BB7                        724 	.ds 3
      000BBA                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000BBA                        726 	.ds 2
      000BBC                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000BBC                        728 	.ds 2
      000BBE                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000BBE                        730 	.ds 3
      000BC1                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000BC1                        732 	.ds 2
      000BC3                        733 _decode_keycode_kc_10000_455:
      000BC3                        734 	.ds 2
      000BC5                        735 _dynamic_keymap_macro_send_id_10000_458:
      000BC5                        736 	.ds 1
      000BC6                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000BC6                        738 	.ds 1
      000BC7                        739 _dynamic_keymap_macro_send_p_10001_464:
      000BC7                        740 	.ds 2
      000BC9                        741 _dynamic_keymap_macro_send_data_10003_471:
      000BC9                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008CE2                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008CE2 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008CE5 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008CE6                        810 _dynamic_keymap_key_to_eeprom_address:
      008CE6 E5 82            [12]  811 	mov	a,dpl
      008CE8 90 0B 62         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      008CEB F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008CEC E0               [24]  815 	movx	a,@dptr
      008CED FF               [12]  816 	mov	r7,a
      008CEE 7E 00            [12]  817 	mov	r6,#0x00
      008CF0 74 40            [12]  818 	mov	a,#0x40
      008CF2 12 48 EE         [24]  819 	lcall	_ak820_outline_0139
      008CF5 7D 00            [12]  820 	mov	r5,#0x00
      008CF7 90 0B 60         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008CFA E0               [24]  822 	movx	a,@dptr
      008CFB 75 F0 10         [24]  823 	mov	b,#0x10
      008CFE A4               [48]  824 	mul	ab
      008CFF 2E               [12]  825 	add	a, r6
      008D00 FE               [12]  826 	mov	r6,a
      008D01 EF               [12]  827 	mov	a,r7
      008D02 35 F0            [12]  828 	addc	a, b
      008D04 FF               [12]  829 	mov	r7,a
      008D05 90 0B 61         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008D08 E0               [24]  831 	movx	a,@dptr
      008D09 7C 00            [12]  832 	mov	r4,#0x00
      008D0B 25 E0            [12]  833 	add	a,acc
      008D0D FB               [12]  834 	mov	r3,a
      008D0E EC               [12]  835 	mov	a,r4
      008D0F 33               [12]  836 	rlc	a
      008D10 FC               [12]  837 	mov	r4,a
      008D11 EB               [12]  838 	mov	a,r3
      008D12 2E               [12]  839 	add	a, r6
      008D13 FE               [12]  840 	mov	r6,a
      008D14 EC               [12]  841 	mov	a,r4
      008D15 3F               [12]  842 	addc	a, r7
      008D16 FF               [12]  843 	mov	r7,a
      008D17 12 77 BE         [24]  844 	lcall	_ak820_outline_0051
                                    845 ;	quantum/dynamic_keymap.c:184: }
      008D1A 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      008D1B                        860 _dynamic_keymap_get_keycode:
      008D1B E5 82            [12]  861 	mov	a,dpl
      008D1D 90 0B 65         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      008D20 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008D21 E0               [24]  865 	movx	a,@dptr
      008D22 FF               [12]  866 	mov	r7,a
      008D23 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      008D26                        868 00121$:
      008D26 50 14            [24]  869 	jnc	00101$
      008D28 90 0B 63         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008D2B E0               [24]  871 	movx	a,@dptr
      008D2C FE               [12]  872 	mov	r6,a
      008D2D BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      008D30                        874 00123$:
      008D30 50 0A            [24]  875 	jnc	00101$
      008D32 90 0B 64         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008D35 E0               [24]  877 	movx	a,@dptr
      008D36 FD               [12]  878 	mov	r5,a
      008D37 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      008D3A                        880 00125$:
      008D3A 40 04            [24]  881 	jc	00102$
      008D3C                        882 00101$:
      008D3C 90 00 00         [24]  883 	mov	dptr,#0x0000
      008D3F 22               [24]  884 	ret
      008D40                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008D40 12 97 5D         [24]  887 	lcall	_ak820_outline_0102
      008D43 91 E6            [12]  888 	acall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008D45 12 97 71         [24]  890 	lcall	_ak820_outline_0118
      008D48 12 46 01         [24]  891 	lcall	_eeprom_read_byte
      008D4B AB 82            [24]  892 	mov	r3,dpl
      008D4D 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008D4F 0D               [12]  895 	inc	r5
      008D50 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      008D53 0E               [12]  897 	inc	r6
      008D54                        898 00127$:
      008D54 12 75 9F         [24]  899 	lcall	_ak820_outline_0050
      008D57 12 46 01         [24]  900 	lcall	_eeprom_read_byte
      008D5A AF 82            [24]  901 	mov	r7, dpl
      008D5C 7E 00            [12]  902 	mov	r6,#0x00
      008D5E EF               [12]  903 	mov	a,r7
      008D5F 42 04            [12]  904 	orl	ar4,a
      008D61 EE               [12]  905 	mov	a,r6
      008D62 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      008D64 12 49 15         [24]  908 	lcall	_ak820_outline_0187
                                    909 ;	quantum/dynamic_keymap.c:193: }
      008D67 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      008D68                        924 _dynamic_keymap_set_keycode:
      008D68 E5 82            [12]  925 	mov	a,dpl
      008D6A 90 0B 6A         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008D6D F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008D6E E0               [24]  929 	movx	a,@dptr
      008D6F FF               [12]  930 	mov	r7,a
      008D70 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008D73                        932 00121$:
      008D73 50 14            [24]  933 	jnc	00101$
      008D75 90 0B 66         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008D78 E0               [24]  935 	movx	a,@dptr
      008D79 FE               [12]  936 	mov	r6,a
      008D7A BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      008D7D                        938 00123$:
      008D7D 50 0A            [24]  939 	jnc	00101$
      008D7F 90 0B 67         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008D82 E0               [24]  941 	movx	a,@dptr
      008D83 FD               [12]  942 	mov	r5,a
      008D84 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      008D87                        944 00125$:
      008D87 40 01            [24]  945 	jc	00102$
      008D89                        946 00101$:
      008D89 22               [24]  947 	ret
      008D8A                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008D8A 12 97 5D         [24]  950 	lcall	_ak820_outline_0102
      008D8D 91 E6            [12]  951 	acall	_dynamic_keymap_key_to_eeprom_address
      008D8F 12 97 71         [24]  952 	lcall	_ak820_outline_0118
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008D92 90 0B 68         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008D95 E0               [24]  955 	movx	a,@dptr
      008D96 FB               [12]  956 	mov	r3,a
      008D97 A3               [24]  957 	inc	dptr
      008D98 E0               [24]  958 	movx	a,@dptr
      008D99 90 07 04         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      008D9C 12 54 B8         [24]  960 	lcall	_ak820_outline_0031
      008D9F 12 53 A3         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008DA2 0D               [12]  963 	inc	r5
      008DA3 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      008DA6 0E               [12]  965 	inc	r6
      008DA7                        966 00127$:
      008DA7 90 07 04         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      008DAA EB               [12]  968 	mov	a,r3
      008DAB 12 54 B8         [24]  969 	lcall	_ak820_outline_0031
                                    970 ;	quantum/dynamic_keymap.c:201: }
      008DAE 02 53 A3         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      008DB1                        982 _dynamic_keymap_encoder_to_eeprom_address:
      008DB1 E5 82            [12]  983 	mov	a,dpl
      008DB3 90 0B 6C         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      008DB6 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008DB7 E0               [24]  987 	movx	a,@dptr
      008DB8 75 F0 04         [24]  988 	mov	b,#0x04
      008DBB A4               [48]  989 	mul	ab
      008DBC 24 40            [12]  990 	add	a, #0x40
      008DBE FD               [12]  991 	mov	r5,a
      008DBF 74 06            [12]  992 	mov	a,#0x06
      008DC1 35 F0            [12]  993 	addc	a, b
      008DC3 FE               [12]  994 	mov	r6,a
      008DC4 7F 00            [12]  995 	mov	r7,#0x00
      008DC6 90 0B 6B         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008DC9 E0               [24]  997 	movx	a,@dptr
      008DCA 75 F0 04         [24]  998 	mov	b,#0x04
      008DCD A4               [48]  999 	mul	ab
      008DCE 2D               [12] 1000 	add	a, r5
      008DCF FD               [12] 1001 	mov	r5,a
      008DD0 EE               [12] 1002 	mov	a,r6
      008DD1 35 F0            [12] 1003 	addc	a, b
      008DD3 FE               [12] 1004 	mov	r6,a
      008DD4 12 75 9F         [24] 1005 	lcall	_ak820_outline_0050
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      008DD7 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      008DD8                       1021 _dynamic_keymap_get_encoder:
      008DD8 E5 82            [12] 1022 	mov	a,dpl
      008DDA 90 0B 6F         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008DDD F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008DDE E0               [24] 1026 	movx	a,@dptr
      008DDF FF               [12] 1027 	mov	r7,a
      008DE0 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008DE3                       1029 00131$:
      008DE3 50 0A            [24] 1030 	jnc	00101$
      008DE5 90 0B 6D         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008DE8 E0               [24] 1032 	movx	a,@dptr
      008DE9 FE               [12] 1033 	mov	r6,a
      008DEA BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      008DED                       1035 00133$:
      008DED 40 04            [24] 1036 	jc	00102$
      008DEF                       1037 00101$:
      008DEF 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008DF2 22               [24] 1039 	ret
      008DF3                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008DF3 90 0B 6B         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008DF6 12 80 C5         [24] 1043 	lcall	_ak820_outline_0185
      008DF9 B1 B1            [12] 1044 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008DFB 12 97 71         [24] 1045 	lcall	_ak820_outline_0118
                                   1046 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008DFE 90 0B 6E         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008E01 E0               [24] 1048 	movx	a,@dptr
      008E02 FC               [12] 1049 	mov	r4,a
      008E03 E0               [24] 1050 	movx	a,@dptr
      008E04 60 04            [24] 1051 	jz	00106$
      008E06 7B 00            [12] 1052 	mov	r3,#0x00
      008E08 80 02            [24] 1053 	sjmp	00107$
      008E0A                       1054 00106$:
      008E0A 7B 02            [12] 1055 	mov	r3,#0x02
      008E0C                       1056 00107$:
      008E0C EB               [12] 1057 	mov	a,r3
      008E0D 12 80 3E         [24] 1058 	lcall	_ak820_outline_0014
      008E10 12 46 01         [24] 1059 	lcall	_eeprom_read_byte
      008E13 AA 82            [24] 1060 	mov	r2,dpl
      008E15 7B 00            [12] 1061 	mov	r3,#0x00
                                   1062 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008E17 EC               [12] 1063 	mov	a,r4
      008E18 60 04            [24] 1064 	jz	00108$
      008E1A 7C 00            [12] 1065 	mov	r4,#0x00
      008E1C 80 02            [24] 1066 	sjmp	00109$
      008E1E                       1067 00108$:
      008E1E 7C 02            [12] 1068 	mov	r4,#0x02
      008E20                       1069 00109$:
      008E20 EC               [12] 1070 	mov	a,r4
      008E21 12 3A FB         [24] 1071 	lcall	_ak820_outline_0164
      008E24 0D               [12] 1072 	inc	r5
      008E25 BD 00 01         [24] 1073 	cjne	r5,#0x00,00137$
      008E28 0E               [12] 1074 	inc	r6
      008E29                       1075 00137$:
      008E29 12 75 9F         [24] 1076 	lcall	_ak820_outline_0050
      008E2C 12 46 01         [24] 1077 	lcall	_eeprom_read_byte
      008E2F AF 82            [24] 1078 	mov	r7, dpl
      008E31 7E 00            [12] 1079 	mov	r6,#0x00
      008E33 EF               [12] 1080 	mov	a,r7
      008E34 42 03            [12] 1081 	orl	ar3,a
      008E36 EE               [12] 1082 	mov	a,r6
      008E37 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/dynamic_keymap.c:214: return keycode;
      008E39 8B 82            [24] 1085 	mov	dpl, r3
      008E3B 8A 83            [24] 1086 	mov	dph, r2
                                   1087 ;	quantum/dynamic_keymap.c:215: }
      008E3D 22               [24] 1088 	ret
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1091 ;------------------------------------------------------------
                                   1092 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1093 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1094 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1095 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1096 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1097 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function dynamic_keymap_set_encoder
                                   1102 ;	-----------------------------------------
      008E3E                       1103 _dynamic_keymap_set_encoder:
      008E3E E5 82            [12] 1104 	mov	a,dpl
      008E40 90 0B 74         [24] 1105 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      008E43 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008E44 E0               [24] 1108 	movx	a,@dptr
      008E45 FF               [12] 1109 	mov	r7,a
      008E46 BF 06 00         [24] 1110 	cjne	r7,#0x06,00131$
      008E49                       1111 00131$:
      008E49 50 0A            [24] 1112 	jnc	00101$
      008E4B 90 0B 70         [24] 1113 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008E4E E0               [24] 1114 	movx	a,@dptr
      008E4F FE               [12] 1115 	mov	r6,a
      008E50 BE 01 00         [24] 1116 	cjne	r6,#0x01,00133$
      008E53                       1117 00133$:
      008E53 40 01            [24] 1118 	jc	00102$
      008E55                       1119 00101$:
      008E55 22               [24] 1120 	ret
      008E56                       1121 00102$:
                                   1122 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008E56 90 0B 6B         [24] 1123 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008E59 12 80 C5         [24] 1124 	lcall	_ak820_outline_0185
      008E5C B1 B1            [12] 1125 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008E5E 12 97 71         [24] 1126 	lcall	_ak820_outline_0118
                                   1127 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008E61 90 0B 71         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008E64 E0               [24] 1129 	movx	a,@dptr
      008E65 FC               [12] 1130 	mov	r4,a
      008E66 E0               [24] 1131 	movx	a,@dptr
      008E67 60 04            [24] 1132 	jz	00106$
      008E69 7B 00            [12] 1133 	mov	r3,#0x00
      008E6B 80 02            [24] 1134 	sjmp	00107$
      008E6D                       1135 00106$:
      008E6D 7B 02            [12] 1136 	mov	r3,#0x02
      008E6F                       1137 00107$:
      008E6F EB               [12] 1138 	mov	a,r3
      008E70 12 97 83         [24] 1139 	lcall	_ak820_outline_0138
      008E73 8F 03            [24] 1140 	mov	ar3,r7
      008E75 90 0B 72         [24] 1141 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008E78 E0               [24] 1142 	movx	a,@dptr
      008E79 F5 2A            [12] 1143 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008E7B A3               [24] 1144 	inc	dptr
      008E7C E0               [24] 1145 	movx	a,@dptr
      008E7D F5 2B            [12] 1146 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008E7F 90 07 04         [24] 1147 	mov	dptr,#_eeprom_update_byte_PARM_2
      008E82 F0               [24] 1148 	movx	@dptr,a
      008E83 12 49 10         [24] 1149 	lcall	_ak820_outline_0186
      008E86 8B F0            [24] 1150 	mov	b, r3
      008E88 12 53 A3         [24] 1151 	lcall	_eeprom_update_byte
                                   1152 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008E8B EC               [12] 1153 	mov	a,r4
      008E8C 60 04            [24] 1154 	jz	00108$
      008E8E 7C 00            [12] 1155 	mov	r4,#0x00
      008E90 80 02            [24] 1156 	sjmp	00109$
      008E92                       1157 00108$:
      008E92 7C 02            [12] 1158 	mov	r4,#0x02
      008E94                       1159 00109$:
      008E94 EC               [12] 1160 	mov	a,r4
      008E95 12 3A FB         [24] 1161 	lcall	_ak820_outline_0164
      008E98 0D               [12] 1162 	inc	r5
      008E99 BD 00 01         [24] 1163 	cjne	r5,#0x00,00137$
      008E9C 0E               [12] 1164 	inc	r6
      008E9D                       1165 00137$:
      008E9D 90 07 04         [24] 1166 	mov	dptr,#_eeprom_update_byte_PARM_2
      008EA0 E5 2A            [12] 1167 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008EA2 12 54 B8         [24] 1168 	lcall	_ak820_outline_0031
                                   1169 ;	quantum/dynamic_keymap.c:223: }
      008EA5 02 53 A3         [24] 1170 	ljmp	_eeprom_update_byte
                                   1171 ;------------------------------------------------------------
                                   1172 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1173 ;------------------------------------------------------------
                                   1174 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1175 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1176 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1177 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1178 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1179 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function dynamic_keymap_get_combo
                                   1184 ;	-----------------------------------------
      008EA8                       1185 _dynamic_keymap_get_combo:
      008EA8 E5 82            [12] 1186 	mov	a,dpl
      008EAA 90 0B 78         [24] 1187 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008EAD F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008EAE 90 0B 75         [24] 1190 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008EB1 12 3A 81         [24] 1191 	lcall	_ak820_outline_0053
                                   1192 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008EB4 90 0B 78         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008EB7 E0               [24] 1194 	movx	a,@dptr
      008EB8 FD               [12] 1195 	mov	r5,a
      008EB9 BD 08 00         [24] 1196 	cjne	r5,#0x08,00132$
      008EBC                       1197 00132$:
      008EBC 40 04            [24] 1198 	jc	00102$
                                   1199 ;	quantum/dynamic_keymap.c:275: return -1;
      008EBE 90 FF FF         [24] 1200 	mov	dptr,#0xffff
      008EC1 22               [24] 1201 	ret
      008EC2                       1202 00102$:
                                   1203 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008EC2 12 97 49         [24] 1204 	lcall	_ak820_outline_0083
                                   1205 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008EC5 8E 02            [24] 1206 	mov	ar2,r6
      008EC7 8F 03            [24] 1207 	mov	ar3,r7
      008EC9 90 05 EB         [24] 1208 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008ECC 12 3A 9E         [24] 1209 	lcall	_ak820_outline_0072
      008ECF E4               [12] 1210 	clr	a
      008ED0 A3               [24] 1211 	inc	dptr
      008ED1 F0               [24] 1212 	movx	@dptr,a
      008ED2 90 05 EE         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008ED5 12 97 6A         [24] 1214 	lcall	_ak820_outline_0114
      008ED8 12 3A EC         [24] 1215 	lcall	_ak820_outline_0147
      008EDB C0 07            [24] 1216 	push	ar7
      008EDD C0 06            [24] 1217 	push	ar6
      008EDF 12 46 3C         [24] 1218 	lcall	_ak820_eeprom_read_block_xdata
      008EE2 D0 06            [24] 1219 	pop	ar6
      008EE4 D0 07            [24] 1220 	pop	ar7
                                   1221 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008EE6 74 04            [12] 1222 	mov	a,#0x04
      008EE8 12 4D F6         [24] 1223 	lcall	_ak820_outline_0034
      008EEB FA               [12] 1224 	mov	r2,a
      008EEC A3               [24] 1225 	inc	dptr
      008EED E0               [24] 1226 	movx	a,@dptr
      008EEE FB               [12] 1227 	mov	r3,a
      008EEF BA 20 13         [24] 1228 	cjne	r2,#0x20,00108$
      008EF2 BB 08 10         [24] 1229 	cjne	r3,#0x08,00108$
      008EF5 74 06            [12] 1230 	mov	a,#0x06
      008EF7 12 3A 71         [24] 1231 	lcall	_ak820_outline_0022
      008EFA 12 48 D7         [24] 1232 	lcall	_ak820_outline_0106
      008EFD BA 01 05         [24] 1233 	cjne	r2,#0x01,00136$
      008F00 BB 00 02         [24] 1234 	cjne	r3,#0x00,00136$
      008F03 80 05            [24] 1235 	sjmp	00109$
      008F05                       1236 00136$:
      008F05                       1237 00108$:
      008F05 75 2C 00         [24] 1238 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008F08 80 03            [24] 1239 	sjmp	00110$
      008F0A                       1240 00109$:
      008F0A 75 2C 01         [24] 1241 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008F0D                       1242 00110$:
                                   1243 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008F0D 74 06            [12] 1244 	mov	a,#0x06
      008F0F 12 3A 71         [24] 1245 	lcall	_ak820_outline_0022
      008F12 E4               [12] 1246 	clr	a
      008F13 F0               [24] 1247 	movx	@dptr,a
      008F14 A3               [24] 1248 	inc	dptr
      008F15 12 3A B6         [24] 1249 	lcall	_ak820_outline_0104
      008F18 F0               [24] 1250 	movx	@dptr,a
      008F19 A3               [24] 1251 	inc	dptr
      008F1A F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008F1B E5 2C            [12] 1254 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008F1D 60 12            [24] 1255 	jz	00103$
      008F1F 12 3A CC         [24] 1256 	lcall	_ak820_outline_0120
      008F22 C0 07            [24] 1257 	push	ar7
      008F24 C0 06            [24] 1258 	push	ar6
      008F26 12 37 1B         [24] 1259 	lcall	_ak820_combo_valid
      008F29 E5 82            [12] 1260 	mov	a, dpl
      008F2B D0 06            [24] 1261 	pop	ar6
      008F2D D0 07            [24] 1262 	pop	ar7
      008F2F 70 13            [24] 1263 	jnz	00104$
      008F31                       1264 00103$:
      008F31 7D 00            [12] 1265 	mov	r5,#0x00
      008F33 90 0E 30         [24] 1266 	mov	dptr,#_memset_PARM_2
      008F36 E4               [12] 1267 	clr	a
      008F37 F0               [24] 1268 	movx	@dptr,a
      008F38 90 0E 31         [24] 1269 	mov	dptr,#_memset_PARM_3
      008F3B 12 97 6A         [24] 1270 	lcall	_ak820_outline_0114
      008F3E 12 77 BE         [24] 1271 	lcall	_ak820_outline_0051
      008F41 12 C1 0D         [24] 1272 	lcall	_memset
      008F44                       1273 00104$:
                                   1274 ;	quantum/dynamic_keymap.c:289: return 0;
      008F44 90 00 00         [24] 1275 	mov	dptr,#0x0000
                                   1276 ;	quantum/dynamic_keymap.c:290: }
      008F47 22               [24] 1277 	ret
                                   1278 ;------------------------------------------------------------
                                   1279 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1280 ;------------------------------------------------------------
                                   1281 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1282 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1283 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1284 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1285 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1286 ;------------------------------------------------------------
                                   1287 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1288 ;	-----------------------------------------
                                   1289 ;	 function dynamic_keymap_set_combo
                                   1290 ;	-----------------------------------------
      008F48                       1291 _dynamic_keymap_set_combo:
      008F48 E5 82            [12] 1292 	mov	a,dpl
      008F4A 90 0B 7C         [24] 1293 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008F4D F0               [24] 1294 	movx	@dptr,a
                                   1295 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008F4E 90 0B 79         [24] 1296 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008F51 12 3A 34         [24] 1297 	lcall	_ak820_outline_0005
                                   1298 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008F54 C0 07            [24] 1299 	push	ar7
      008F56 C0 06            [24] 1300 	push	ar6
      008F58 12 37 1B         [24] 1301 	lcall	_ak820_combo_valid
      008F5B E5 82            [12] 1302 	mov	a, dpl
      008F5D D0 06            [24] 1303 	pop	ar6
      008F5F D0 07            [24] 1304 	pop	ar7
      008F61 60 07            [24] 1305 	jz	00101$
      008F63 12 43 A7         [24] 1306 	lcall	_ak820_nvm_ok
      008F66 E5 82            [12] 1307 	mov	a, dpl
      008F68 70 04            [24] 1308 	jnz	00102$
      008F6A                       1309 00101$:
      008F6A 90 FF FF         [24] 1310 	mov	dptr,#0xffff
      008F6D 22               [24] 1311 	ret
      008F6E                       1312 00102$:
                                   1313 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008F6E 90 0B 7C         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008F71 E0               [24] 1315 	movx	a,@dptr
      008F72 FD               [12] 1316 	mov	r5,a
      008F73 BD 08 00         [24] 1317 	cjne	r5,#0x08,00133$
      008F76                       1318 00133$:
      008F76 40 04            [24] 1319 	jc	00105$
                                   1320 ;	quantum/dynamic_keymap.c:302: return -1;
      008F78 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008F7B 22               [24] 1322 	ret
      008F7C                       1323 00105$:
                                   1324 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008F7C 12 97 49         [24] 1325 	lcall	_ak820_outline_0083
                                   1326 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008F7F C0 07            [24] 1327 	push	ar7
      008F81 C0 06            [24] 1328 	push	ar6
      008F83 C0 05            [24] 1329 	push	ar5
      008F85 C0 04            [24] 1330 	push	ar4
      008F87 12 7F E1         [24] 1331 	lcall	_clear_keyboard
      008F8A D0 04            [24] 1332 	pop	ar4
      008F8C D0 05            [24] 1333 	pop	ar5
      008F8E D0 06            [24] 1334 	pop	ar6
      008F90 D0 07            [24] 1335 	pop	ar7
                                   1336 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008F92 90 0E 28         [24] 1337 	mov	dptr,#___memcpy_PARM_2
      008F95 12 4E 09         [24] 1338 	lcall	_ak820_outline_0060
      008F98 E4               [12] 1339 	clr	a
      008F99 A3               [24] 1340 	inc	dptr
      008F9A F0               [24] 1341 	movx	@dptr,a
      008F9B 90 0E 2B         [24] 1342 	mov	dptr,#___memcpy_PARM_3
      008F9E 12 97 6A         [24] 1343 	lcall	_ak820_outline_0114
      008FA1 90 0B 7D         [24] 1344 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008FA4 F5 F0            [12] 1345 	mov	b,a
      008FA6 C0 05            [24] 1346 	push	ar5
      008FA8 C0 04            [24] 1347 	push	ar4
      008FAA 12 C0 97         [24] 1348 	lcall	___memcpy
      008FAD D0 04            [24] 1349 	pop	ar4
      008FAF D0 05            [24] 1350 	pop	ar5
                                   1351 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008FB1 90 0B 81         [24] 1352 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008FB4 74 20            [12] 1353 	mov	a,#0x20
      008FB6 F0               [24] 1354 	movx	@dptr,a
      008FB7 74 08            [12] 1355 	mov	a,#0x08
      008FB9 A3               [24] 1356 	inc	dptr
      008FBA F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008FBB 90 0B 83         [24] 1359 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008FBE 74 01            [12] 1360 	mov	a,#0x01
      008FC0 12 3A DC         [24] 1361 	lcall	_ak820_outline_0136
                                   1362 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008FC3 90 05 F4         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008FC6 12 3A 9E         [24] 1364 	lcall	_ak820_outline_0072
      008FC9 E4               [12] 1365 	clr	a
      008FCA A3               [24] 1366 	inc	dptr
      008FCB F0               [24] 1367 	movx	@dptr,a
      008FCC 90 05 F7         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008FCF 12 97 6A         [24] 1369 	lcall	_ak820_outline_0114
      008FD2 90 0B 7D         [24] 1370 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008FD5 12 46 C8         [24] 1371 	lcall	_ak820_eeprom_write_block_xdata
                                   1372 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008FD8 12 43 B6         [24] 1373 	lcall	_ak820_nvm_flush
                                   1374 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008FDB 12 43 A7         [24] 1375 	lcall	_ak820_nvm_ok
      008FDE E5 82            [12] 1376 	mov	a, dpl
      008FE0 70 04            [24] 1377 	jnz	00107$
      008FE2 90 FF FF         [24] 1378 	mov	dptr,#0xffff
      008FE5 22               [24] 1379 	ret
      008FE6                       1380 00107$:
                                   1381 ;	quantum/dynamic_keymap.c:320: return 0;
      008FE6 90 00 00         [24] 1382 	mov	dptr,#0x0000
                                   1383 ;	quantum/dynamic_keymap.c:321: }
      008FE9 22               [24] 1384 	ret
                                   1385 ;------------------------------------------------------------
                                   1386 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1387 ;------------------------------------------------------------
                                   1388 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1389 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1390 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1391 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1392 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1393 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1394 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1395 ;------------------------------------------------------------
                                   1396 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1397 ;	-----------------------------------------
                                   1398 ;	 function dynamic_keymap_reset
                                   1399 ;	-----------------------------------------
      008FEA                       1400 _dynamic_keymap_reset:
                                   1401 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008FEA 90 0E A9         [24] 1402 	mov	dptr,#_vial_unlocked
      008FED E0               [24] 1403 	movx	a,@dptr
      008FEE 90 0B 87         [24] 1404 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008FF1 F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008FF2 90 0E A9         [24] 1407 	mov	dptr,#_vial_unlocked
      008FF5 74 01            [12] 1408 	mov	a,#0x01
      008FF7 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008FF8 7F 00            [12] 1411 	mov	r7,#0x00
      008FFA                       1412 00116$:
      008FFA BF 06 00         [24] 1413 	cjne	r7,#0x06,00198$
      008FFD                       1414 00198$:
      008FFD 40 03            [24] 1415 	jc	00199$
      008FFF 02 90 AD         [24] 1416 	ljmp	00104$
      009002                       1417 00199$:
                                   1418 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      009002 7E 00            [12] 1419 	mov	r6,#0x00
      009004                       1420 00110$:
      009004 BE 10 00         [24] 1421 	cjne	r6,#0x10,00200$
      009007                       1422 00200$:
      009007 50 4D            [24] 1423 	jnc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      009009 7D 00            [12] 1425 	mov	r5,#0x00
      00900B                       1426 00107$:
      00900B BD 08 00         [24] 1427 	cjne	r5,#0x08,00202$
      00900E                       1428 00202$:
      00900E 50 43            [24] 1429 	jnc	00111$
                                   1430 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      009010 90 0C 23         [24] 1431 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      009013 EE               [12] 1432 	mov	a,r6
      009014 F0               [24] 1433 	movx	@dptr,a
      009015 90 0C 24         [24] 1434 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      009018 ED               [12] 1435 	mov	a,r5
      009019 F0               [24] 1436 	movx	@dptr,a
      00901A 8F 82            [24] 1437 	mov	dpl, r7
      00901C C0 07            [24] 1438 	push	ar7
      00901E C0 06            [24] 1439 	push	ar6
      009020 C0 05            [24] 1440 	push	ar5
      009022 12 9F 85         [24] 1441 	lcall	_keycode_at_keymap_location_raw
      009025 AB 82            [24] 1442 	mov	r3, dpl
      009027 AC 83            [24] 1443 	mov	r4, dph
      009029 D0 05            [24] 1444 	pop	ar5
      00902B D0 06            [24] 1445 	pop	ar6
      00902D D0 07            [24] 1446 	pop	ar7
      00902F 90 0B 66         [24] 1447 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      009032 EE               [12] 1448 	mov	a,r6
      009033 F0               [24] 1449 	movx	@dptr,a
      009034 90 0B 67         [24] 1450 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      009037 ED               [12] 1451 	mov	a,r5
      009038 F0               [24] 1452 	movx	@dptr,a
      009039 90 0B 68         [24] 1453 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00903C 12 3A AA         [24] 1454 	lcall	_ak820_outline_0087
      00903F 8F 82            [24] 1455 	mov	dpl, r7
      009041 C0 07            [24] 1456 	push	ar7
      009043 C0 06            [24] 1457 	push	ar6
      009045 C0 05            [24] 1458 	push	ar5
      009047 12 8D 68         [24] 1459 	lcall	_dynamic_keymap_set_keycode
      00904A D0 05            [24] 1460 	pop	ar5
      00904C D0 06            [24] 1461 	pop	ar6
      00904E D0 07            [24] 1462 	pop	ar7
                                   1463 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      009050 0D               [12] 1464 	inc	r5
      009051 80 B8            [24] 1465 	sjmp	00107$
      009053                       1466 00111$:
                                   1467 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      009053 0E               [12] 1468 	inc	r6
      009054 80 AE            [24] 1469 	sjmp	00110$
      009056                       1470 00102$:
                                   1471 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      009056 7E 00            [12] 1472 	mov	r6,#0x00
      009058                       1473 00113$:
      009058 BE 01 00         [24] 1474 	cjne	r6,#0x01,00204$
      00905B                       1475 00204$:
      00905B 50 4C            [24] 1476 	jnc	00117$
                                   1477 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00905D 12 97 9F         [24] 1478 	lcall	_ak820_outline_0180
      009060 04               [12] 1479 	inc	a
      009061 F0               [24] 1480 	movx	@dptr,a
      009062 8F 82            [24] 1481 	mov	dpl, r7
      009064 C0 07            [24] 1482 	push	ar7
      009066 12 9F CA         [24] 1483 	lcall	_keycode_at_encodermap_location_raw
      009069 12 48 FA         [24] 1484 	lcall	_ak820_outline_0154
      00906C D0 07            [24] 1485 	pop	ar7
      00906E 12 97 96         [24] 1486 	lcall	_ak820_outline_0179
      009071 04               [12] 1487 	inc	a
      009072 F0               [24] 1488 	movx	@dptr,a
      009073 90 0B 72         [24] 1489 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      009076 12 3A 9E         [24] 1490 	lcall	_ak820_outline_0072
      009079 8F 82            [24] 1491 	mov	dpl, r7
      00907B C0 07            [24] 1492 	push	ar7
      00907D 12 8E 3E         [24] 1493 	lcall	_dynamic_keymap_set_encoder
      009080 D0 07            [24] 1494 	pop	ar7
                                   1495 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      009082 12 97 9F         [24] 1496 	lcall	_ak820_outline_0180
      009085 F0               [24] 1497 	movx	@dptr,a
      009086 8F 82            [24] 1498 	mov	dpl, r7
      009088 C0 07            [24] 1499 	push	ar7
      00908A 12 9F CA         [24] 1500 	lcall	_keycode_at_encodermap_location_raw
      00908D 12 48 FA         [24] 1501 	lcall	_ak820_outline_0154
      009090 D0 07            [24] 1502 	pop	ar7
      009092 12 97 96         [24] 1503 	lcall	_ak820_outline_0179
      009095 F0               [24] 1504 	movx	@dptr,a
      009096 90 0B 72         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      009099 12 3A 9E         [24] 1506 	lcall	_ak820_outline_0072
      00909C 8F 82            [24] 1507 	mov	dpl, r7
      00909E C0 07            [24] 1508 	push	ar7
      0090A0 12 8E 3E         [24] 1509 	lcall	_dynamic_keymap_set_encoder
      0090A3 D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0090A5 7E 01            [12] 1512 	mov	r6,#0x01
      0090A7 80 AF            [24] 1513 	sjmp	00113$
      0090A9                       1514 00117$:
                                   1515 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0090A9 0F               [12] 1516 	inc	r7
      0090AA 02 8F FA         [24] 1517 	ljmp	00116$
      0090AD                       1518 00104$:
                                   1519 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      0090AD 90 0B 88         [24] 1520 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      0090B0 12 55 02         [24] 1521 	lcall	_ak820_outline_0184
      0090B3 90 0B 8A         [24] 1522 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      0090B6 F0               [24] 1523 	movx	@dptr,a
      0090B7 A3               [24] 1524 	inc	dptr
      0090B8 F0               [24] 1525 	movx	@dptr,a
      0090B9 90 0B 8C         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      0090BC F0               [24] 1527 	movx	@dptr,a
      0090BD A3               [24] 1528 	inc	dptr
      0090BE F0               [24] 1529 	movx	@dptr,a
      0090BF 90 0B 8E         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      0090C2 F0               [24] 1531 	movx	@dptr,a
      0090C3 A3               [24] 1532 	inc	dptr
      0090C4 F0               [24] 1533 	movx	@dptr,a
      0090C5 90 0B 90         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      0090C8 F0               [24] 1535 	movx	@dptr,a
      0090C9 A3               [24] 1536 	inc	dptr
      0090CA F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0090CB FF               [12] 1539 	mov	r7,a
      0090CC                       1540 00119$:
      0090CC BF 08 00         [24] 1541 	cjne	r7,#0x08,00206$
      0090CF                       1542 00206$:
      0090CF 50 19            [24] 1543 	jnc	00105$
                                   1544 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      0090D1 8F 06            [24] 1545 	mov	ar6,r7
      0090D3 90 0B 79         [24] 1546 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0090D6 74 88            [12] 1547 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      0090D8 F0               [24] 1548 	movx	@dptr,a
      0090D9 74 0B            [12] 1549 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      0090DB 12 3A B0         [24] 1550 	lcall	_ak820_outline_0095
      0090DE 8E 82            [24] 1551 	mov	dpl, r6
      0090E0 C0 07            [24] 1552 	push	ar7
      0090E2 12 8F 48         [24] 1553 	lcall	_dynamic_keymap_set_combo
      0090E5 D0 07            [24] 1554 	pop	ar7
                                   1555 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0090E7 0F               [12] 1556 	inc	r7
      0090E8 80 E2            [24] 1557 	sjmp	00119$
      0090EA                       1558 00105$:
                                   1559 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      0090EA 90 0B 87         [24] 1560 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      0090ED E0               [24] 1561 	movx	a,@dptr
      0090EE 90 0E A9         [24] 1562 	mov	dptr,#_vial_unlocked
      0090F1 F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/dynamic_keymap.c:405: }
      0090F2 22               [24] 1565 	ret
                                   1566 ;------------------------------------------------------------
                                   1567 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1568 ;------------------------------------------------------------
                                   1569 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1570 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1571 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1572 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1573 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1574 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1575 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1576 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1577 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1578 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function ak820_dynamic_read_buffer
                                   1583 ;	-----------------------------------------
      0090F3                       1584 _ak820_dynamic_read_buffer:
      0090F3 12 3A C2         [24] 1585 	lcall	_ak820_outline_0110
      0090F6 90 0B 9B         [24] 1586 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0090F9 12 3A C7         [24] 1587 	lcall	_ak820_outline_0111
                                   1588 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0090FC 90 0B 98         [24] 1589 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0090FF 12 3A 81         [24] 1590 	lcall	_ak820_outline_0053
                                   1591 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      009102 90 0B 9D         [24] 1592 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      009105 E4               [12] 1593 	clr	a
      009106 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      009107 90 0B 96         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00910A 12 3A 98         [24] 1597 	lcall	_ak820_outline_0061
      00910D 8C 02            [24] 1598 	mov	ar2,r4
      00910F 8D 03            [24] 1599 	mov	ar3,r5
      009111 C3               [12] 1600 	clr	c
      009112 74 1C            [12] 1601 	mov	a,#0x1c
      009114 9A               [12] 1602 	subb	a,r2
      009115 E4               [12] 1603 	clr	a
      009116 9B               [12] 1604 	subb	a,r3
      009117 50 01            [24] 1605 	jnc	00102$
                                   1606 ;	free result
      009119 22               [24] 1607 	ret
      00911A                       1608 00102$:
                                   1609 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      00911A 90 0B 94         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00911D 12 48 D7         [24] 1611 	lcall	_ak820_outline_0106
      009120 90 0B 92         [24] 1612 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009123 12 3A BC         [24] 1613 	lcall	_ak820_outline_0105
      009126 C3               [12] 1614 	clr	c
      009127 EA               [12] 1615 	mov	a,r2
      009128 98               [12] 1616 	subb	a,r0
      009129 EB               [12] 1617 	mov	a,r3
      00912A 99               [12] 1618 	subb	a,r1
      00912B 50 17            [24] 1619 	jnc	00104$
                                   1620 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      00912D E8               [12] 1621 	mov	a,r0
      00912E C3               [12] 1622 	clr	c
      00912F 9A               [12] 1623 	subb	a,r2
      009130 F8               [12] 1624 	mov	r0,a
      009131 E9               [12] 1625 	mov	a,r1
      009132 9B               [12] 1626 	subb	a,r3
      009133 F9               [12] 1627 	mov	r1,a
                                   1628 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      009134 C3               [12] 1629 	clr	c
      009135 E8               [12] 1630 	mov	a,r0
      009136 9C               [12] 1631 	subb	a,r4
      009137 E9               [12] 1632 	mov	a,r1
      009138 9D               [12] 1633 	subb	a,r5
      009139 40 04            [24] 1634 	jc	00114$
      00913B 8C 00            [24] 1635 	mov	ar0,r4
      00913D 8D 01            [24] 1636 	mov	ar1,r5
      00913F                       1637 00114$:
      00913F 90 0B 9D         [24] 1638 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      009142 E8               [12] 1639 	mov	a,r0
      009143 F0               [24] 1640 	movx	@dptr,a
      009144                       1641 00104$:
                                   1642 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      009144 90 0B 9D         [24] 1643 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      009147 E0               [24] 1644 	movx	a,@dptr
      009148 F5 2D            [12] 1645 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      00914A E0               [24] 1646 	movx	a,@dptr
      00914B 60 42            [24] 1647 	jz	00106$
      00914D C0 04            [24] 1648 	push	ar4
      00914F C0 05            [24] 1649 	push	ar5
      009151 8E 00            [24] 1650 	mov	ar0,r6
      009153 8F 05            [24] 1651 	mov	ar5,r7
      009155 90 0B 9B         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      009158 E0               [24] 1653 	movx	a,@dptr
      009159 F9               [12] 1654 	mov	r1,a
      00915A A3               [24] 1655 	inc	dptr
      00915B E0               [24] 1656 	movx	a,@dptr
      00915C FC               [12] 1657 	mov	r4,a
      00915D EA               [12] 1658 	mov	a,r2
      00915E 29               [12] 1659 	add	a, r1
      00915F FA               [12] 1660 	mov	r2,a
      009160 EB               [12] 1661 	mov	a,r3
      009161 3C               [12] 1662 	addc	a, r4
      009162 FB               [12] 1663 	mov	r3,a
      009163 90 05 EB         [24] 1664 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      009166 EA               [12] 1665 	mov	a,r2
      009167 F0               [24] 1666 	movx	@dptr,a
      009168 EB               [12] 1667 	mov	a,r3
      009169 12 3A B0         [24] 1668 	lcall	_ak820_outline_0095
      00916C 90 05 EE         [24] 1669 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00916F E5 2D            [12] 1670 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      009171 12 3A DC         [24] 1671 	lcall	_ak820_outline_0136
      009174 88 82            [24] 1672 	mov	dpl, r0
      009176 8D 83            [24] 1673 	mov	dph, r5
      009178 C0 07            [24] 1674 	push	ar7
      00917A C0 06            [24] 1675 	push	ar6
      00917C C0 05            [24] 1676 	push	ar5
      00917E C0 04            [24] 1677 	push	ar4
      009180 12 46 3C         [24] 1678 	lcall	_ak820_eeprom_read_block_xdata
      009183 D0 04            [24] 1679 	pop	ar4
      009185 D0 05            [24] 1680 	pop	ar5
      009187 D0 06            [24] 1681 	pop	ar6
      009189 D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00918B D0 05            [24] 1684 	pop	ar5
      00918D D0 04            [24] 1685 	pop	ar4
                                   1686 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      00918F                       1687 00106$:
                                   1688 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      00918F 90 0B 9D         [24] 1689 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      009192 E0               [24] 1690 	movx	a,@dptr
      009193 FB               [12] 1691 	mov	r3,a
      009194                       1692 00109$:
      009194 8B 01            [24] 1693 	mov	ar1,r3
      009196 7A 00            [12] 1694 	mov	r2,#0x00
      009198 C3               [12] 1695 	clr	c
      009199 E9               [12] 1696 	mov	a,r1
      00919A 9C               [12] 1697 	subb	a,r4
      00919B EA               [12] 1698 	mov	a,r2
      00919C 9D               [12] 1699 	subb	a,r5
      00919D 50 09            [24] 1700 	jnc	00111$
      00919F EB               [12] 1701 	mov	a,r3
      0091A0 12 3A 71         [24] 1702 	lcall	_ak820_outline_0022
      0091A3 E4               [12] 1703 	clr	a
      0091A4 F0               [24] 1704 	movx	@dptr,a
      0091A5 0B               [12] 1705 	inc	r3
      0091A6 80 EC            [24] 1706 	sjmp	00109$
      0091A8                       1707 00111$:
                                   1708 ;	quantum/dynamic_keymap.c:420: }
      0091A8 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1712 ;------------------------------------------------------------
                                   1713 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1714 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1715 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function dynamic_keymap_get_buffer
                                   1720 ;	-----------------------------------------
      0091A9                       1721 _dynamic_keymap_get_buffer:
      0091A9 12 3A C2         [24] 1722 	lcall	_ak820_outline_0110
      0091AC 90 0B A3         [24] 1723 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      0091AF 12 3A C7         [24] 1724 	lcall	_ak820_outline_0111
                                   1725 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      0091B2 90 0B A3         [24] 1726 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      0091B5 12 3A 81         [24] 1727 	lcall	_ak820_outline_0053
      0091B8 90 0B 9E         [24] 1728 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      0091BB 12 3A 98         [24] 1729 	lcall	_ak820_outline_0061
      0091BE 90 0B A0         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      0091C1 12 54 E2         [24] 1731 	lcall	_ak820_outline_0093
      0091C4 90 0B 92         [24] 1732 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0091C7 E4               [12] 1733 	clr	a
      0091C8 F0               [24] 1734 	movx	@dptr,a
      0091C9 74 06            [12] 1735 	mov	a,#0x06
      0091CB A3               [24] 1736 	inc	dptr
      0091CC F0               [24] 1737 	movx	@dptr,a
      0091CD 90 0B 94         [24] 1738 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0091D0 12 4E 09         [24] 1739 	lcall	_ak820_outline_0060
      0091D3 90 0B 96         [24] 1740 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0091D6 12 3A 9E         [24] 1741 	lcall	_ak820_outline_0072
      0091D9 90 0B 98         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0091DC E9               [12] 1743 	mov	a,r1
      0091DD 12 54 FB         [24] 1744 	lcall	_ak820_outline_0161
      0091E0 F0               [24] 1745 	movx	@dptr,a
      0091E1 90 00 40         [24] 1746 	mov	dptr,#0x0040
                                   1747 ;	quantum/dynamic_keymap.c:448: }
      0091E4 01 F3            [12] 1748 	ajmp	_ak820_dynamic_read_buffer
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1751 ;------------------------------------------------------------
                                   1752 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1753 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1754 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1755 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1756 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1757 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1758 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1759 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1760 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1761 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1762 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1763 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1764 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1766 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1767 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function dynamic_keymap_set_buffer
                                   1772 ;	-----------------------------------------
      0091E6                       1773 _dynamic_keymap_set_buffer:
      0091E6 12 3A C2         [24] 1774 	lcall	_ak820_outline_0110
      0091E9 90 0B AA         [24] 1775 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      0091EC 12 3A C7         [24] 1776 	lcall	_ak820_outline_0111
                                   1777 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      0091EF 90 0B AA         [24] 1778 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      0091F2 12 4D AC         [24] 1779 	lcall	_ak820_outline_0009
      0091F5 74 40            [12] 1780 	mov	a,#0x40
      0091F7 2C               [12] 1781 	add	a, r4
      0091F8 FA               [12] 1782 	mov	r2,a
      0091F9 E4               [12] 1783 	clr	a
      0091FA 3D               [12] 1784 	addc	a, r5
      0091FB FB               [12] 1785 	mov	r3,a
                                   1786 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0091FC 90 0B A7         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      0091FF 12 3A BC         [24] 1788 	lcall	_ak820_outline_0105
                                   1789 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      009202 90 0B A5         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      009205 E0               [24] 1791 	movx	a,@dptr
      009206 F5 2E            [12] 1792 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      009208 A3               [24] 1793 	inc	dptr
      009209 E0               [24] 1794 	movx	a,@dptr
      00920A F5 2F            [12] 1795 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      00920C E5 2E            [12] 1796 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00920E 45 2F            [12] 1797 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009210 70 01            [24] 1798 	jnz	00102$
      009212 22               [24] 1799 	ret
      009213                       1800 00102$:
                                   1801 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      009213 85 2E 30         [24] 1802 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      009216 85 2F 31         [24] 1803 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009219 C3               [12] 1804 	clr	c
      00921A 74 1C            [12] 1805 	mov	a,#0x1c
      00921C 95 30            [12] 1806 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      00921E E4               [12] 1807 	clr	a
      00921F 95 31            [12] 1808 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      009221 50 01            [24] 1809 	jnc	00104$
                                   1810 ;	free result
      009223 22               [24] 1811 	ret
      009224                       1812 00104$:
                                   1813 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      009224 85 2E 32         [24] 1814 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1815 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      009227 74 FA            [12] 1816 	mov	a,#0x100 - 0x06
      009229 2F               [12] 1817 	add	a,r7
      00922A 40 11            [24] 1818 	jc	00105$
      00922C E4               [12] 1819 	clr	a
      00922D C3               [12] 1820 	clr	c
      00922E 9E               [12] 1821 	subb	a,r6
      00922F FE               [12] 1822 	mov	r6,a
      009230 74 06            [12] 1823 	mov	a,#0x06
      009232 9F               [12] 1824 	subb	a,r7
      009233 FF               [12] 1825 	mov	r7,a
      009234 C3               [12] 1826 	clr	c
      009235 EE               [12] 1827 	mov	a,r6
      009236 95 2E            [12] 1828 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      009238 EF               [12] 1829 	mov	a,r7
      009239 95 2F            [12] 1830 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00923B 50 01            [24] 1831 	jnc	00106$
      00923D                       1832 00105$:
                                   1833 ;	quantum/dynamic_keymap.c:466: return;
      00923D 22               [24] 1834 	ret
      00923E                       1835 00106$:
                                   1836 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      00923E 90 0E A9         [24] 1837 	mov	dptr,#_vial_unlocked
      009241 E0               [24] 1838 	movx	a,@dptr
      009242 60 02            [24] 1839 	jz	00207$
      009244 61 50            [12] 1840 	ajmp	00120$
      009246                       1841 00207$:
                                   1842 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      009246 90 0B AC         [24] 1843 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      009249 E4               [12] 1844 	clr	a
      00924A F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      00924B 90 0B AD         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      00924E E5 32            [12] 1848 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      009250 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      009251 EC               [12] 1851 	mov	a,r4
      009252 30 E0 31         [24] 1852 	jnb	acc.0,00111$
                                   1853 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      009255 EA               [12] 1854 	mov	a,r2
      009256 24 FF            [12] 1855 	add	a,#0xff
      009258 FE               [12] 1856 	mov	r6,a
      009259 EB               [12] 1857 	mov	a,r3
      00925A 34 FF            [12] 1858 	addc	a,#0xff
      00925C FF               [12] 1859 	mov	r7,a
      00925D 7D 00            [12] 1860 	mov	r5,#0x00
      00925F 12 77 BE         [24] 1861 	lcall	_ak820_outline_0051
      009262 12 46 01         [24] 1862 	lcall	_eeprom_read_byte
      009265 AE 82            [24] 1863 	mov	r6,dpl
      009267 7F 00            [12] 1864 	mov	r7,#0x00
      009269 12 3A F1         [24] 1865 	lcall	_ak820_outline_0148
      00926C E0               [24] 1866 	movx	a,@dptr
      00926D 7C 00            [12] 1867 	mov	r4,#0x00
      00926F 42 07            [12] 1868 	orl	ar7,a
      009271 EC               [12] 1869 	mov	a,r4
      009272 42 06            [12] 1870 	orl	ar6,a
                                   1871 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      009274 BF 00 09         [24] 1872 	cjne	r7,#0x00,00109$
      009277 BE 7C 06         [24] 1873 	cjne	r6,#0x7c,00109$
                                   1874 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      00927A 12 3A F1         [24] 1875 	lcall	_ak820_outline_0148
      00927D 74 FF            [12] 1876 	mov	a,#0xff
      00927F F0               [24] 1877 	movx	@dptr,a
      009280                       1878 00109$:
                                   1879 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      009280 90 0B AC         [24] 1880 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      009283 74 01            [12] 1881 	mov	a,#0x01
      009285 F0               [24] 1882 	movx	@dptr,a
      009286                       1883 00111$:
                                   1884 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      009286 90 0B AA         [24] 1885 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      009289 12 3A 81         [24] 1886 	lcall	_ak820_outline_0053
      00928C E5 2E            [12] 1887 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00928E 2E               [12] 1888 	add	a, r6
      00928F FE               [12] 1889 	mov	r6,a
      009290 E5 2F            [12] 1890 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009292 3F               [12] 1891 	addc	a, r7
      009293 EE               [12] 1892 	mov	a,r6
      009294 30 E0 5A         [24] 1893 	jnb	acc.0,00115$
                                   1894 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      009297 AE 32            [24] 1895 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      009299 7F 00            [12] 1896 	mov	r7,#0x00
      00929B EE               [12] 1897 	mov	a,r6
      00929C 24 FF            [12] 1898 	add	a,#0xff
      00929E FC               [12] 1899 	mov	r4,a
      00929F EF               [12] 1900 	mov	a,r7
      0092A0 34 FF            [12] 1901 	addc	a,#0xff
      0092A2 FD               [12] 1902 	mov	r5,a
      0092A3 EC               [12] 1903 	mov	a,r4
      0092A4 28               [12] 1904 	add	a, r0
      0092A5 F5 82            [12] 1905 	mov	dpl,a
      0092A7 ED               [12] 1906 	mov	a,r5
      0092A8 39               [12] 1907 	addc	a, r1
      0092A9 F5 83            [12] 1908 	mov	dph,a
      0092AB E0               [24] 1909 	movx	a,@dptr
      0092AC FC               [12] 1910 	mov	r4,a
      0092AD 7D 00            [12] 1911 	mov	r5,#0x00
      0092AF E5 32            [12] 1912 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0092B1 2A               [12] 1913 	add	a, r2
      0092B2 FA               [12] 1914 	mov	r2,a
      0092B3 E4               [12] 1915 	clr	a
      0092B4 3B               [12] 1916 	addc	a, r3
      0092B5 FB               [12] 1917 	mov	r3,a
      0092B6 C0 00            [24] 1918 	push	ar0
      0092B8 C0 01            [24] 1919 	push	ar1
      0092BA 8B 01            [24] 1920 	mov	ar1,r3
      0092BC 7B 00            [12] 1921 	mov	r3,#0x00
      0092BE 8A 82            [24] 1922 	mov	dpl, r2
      0092C0 89 83            [24] 1923 	mov	dph, r1
      0092C2 8B F0            [24] 1924 	mov	b, r3
      0092C4 12 46 01         [24] 1925 	lcall	_eeprom_read_byte
      0092C7 AB 82            [24] 1926 	mov	r3, dpl
      0092C9 7A 00            [12] 1927 	mov	r2,#0x00
      0092CB EB               [12] 1928 	mov	a,r3
      0092CC 12 48 F4         [24] 1929 	lcall	_ak820_outline_0146
                                   1930 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      0092CF BD 00 05         [24] 1931 	cjne	r5,#0x00,00212$
      0092D2 BC 7C 02         [24] 1932 	cjne	r4,#0x7c,00212$
      0092D5 80 06            [24] 1933 	sjmp	00213$
      0092D7                       1934 00212$:
      0092D7 D0 01            [24] 1935 	pop	ar1
      0092D9 D0 00            [24] 1936 	pop	ar0
      0092DB 80 0D            [24] 1937 	sjmp	00113$
      0092DD                       1938 00213$:
      0092DD D0 01            [24] 1939 	pop	ar1
      0092DF D0 00            [24] 1940 	pop	ar0
                                   1941 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      0092E1 1E               [12] 1942 	dec	r6
      0092E2 BE FF 01         [24] 1943 	cjne	r6,#0xff,00214$
      0092E5 1F               [12] 1944 	dec	r7
      0092E6                       1945 00214$:
      0092E6 EE               [12] 1946 	mov	a,r6
      0092E7 12 97 78         [24] 1947 	lcall	_ak820_outline_0131
      0092EA                       1948 00113$:
                                   1949 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      0092EA E5 32            [12] 1950 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0092EC 14               [12] 1951 	dec	a
      0092ED 90 0B AD         [24] 1952 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      0092F0 F0               [24] 1953 	movx	@dptr,a
      0092F1                       1954 00115$:
                                   1955 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0092F1 90 0B AC         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      0092F4 E0               [24] 1957 	movx	a,@dptr
      0092F5 90 0B AE         [24] 1958 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      0092F8 F0               [24] 1959 	movx	@dptr,a
      0092F9                       1960 00122$:
      0092F9 90 0B AE         [24] 1961 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      0092FC E0               [24] 1962 	movx	a,@dptr
      0092FD FF               [12] 1963 	mov	r7,a
      0092FE 90 0B AD         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      009301 E0               [24] 1965 	movx	a,@dptr
      009302 FE               [12] 1966 	mov	r6,a
      009303 C3               [12] 1967 	clr	c
      009304 EF               [12] 1968 	mov	a,r7
      009305 9E               [12] 1969 	subb	a,r6
      009306 50 48            [24] 1970 	jnc	00120$
                                   1971 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      009308 EF               [12] 1972 	mov	a,r7
      009309 28               [12] 1973 	add	a, r0
      00930A FD               [12] 1974 	mov	r5,a
      00930B E4               [12] 1975 	clr	a
      00930C 39               [12] 1976 	addc	a, r1
      00930D FE               [12] 1977 	mov	r6,a
      00930E 12 4E 16         [24] 1978 	lcall	_ak820_outline_0078
      009311 7B 00            [12] 1979 	mov	r3,#0x00
      009313 8C 2F            [24] 1980 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      009315 8B 2E            [24] 1981 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      009317 8F 02            [24] 1982 	mov	ar2,r7
      009319 7F 00            [12] 1983 	mov	r7,#0x00
      00931B 74 01            [12] 1984 	mov	a,#0x01
      00931D 2A               [12] 1985 	add	a, r2
      00931E FB               [12] 1986 	mov	r3,a
      00931F E4               [12] 1987 	clr	a
      009320 3F               [12] 1988 	addc	a, r7
      009321 FC               [12] 1989 	mov	r4,a
      009322 EB               [12] 1990 	mov	a,r3
      009323 28               [12] 1991 	add	a, r0
      009324 F5 82            [12] 1992 	mov	dpl,a
      009326 EC               [12] 1993 	mov	a,r4
      009327 39               [12] 1994 	addc	a, r1
      009328 F5 83            [12] 1995 	mov	dph,a
      00932A E0               [24] 1996 	movx	a,@dptr
      00932B FC               [12] 1997 	mov	r4,a
      00932C 7B 00            [12] 1998 	mov	r3,#0x00
      00932E E5 2F            [12] 1999 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009330 42 03            [12] 2000 	orl	ar3,a
                                   2001 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      009332 BC 00 12         [24] 2002 	cjne	r4,#0x00,00123$
      009335 BB 7C 0F         [24] 2003 	cjne	r3,#0x7c,00123$
                                   2004 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      009338 12 3A E1         [24] 2005 	lcall	_ak820_outline_0137
      00933B 74 FF            [12] 2006 	mov	a,#0xff
      00933D F0               [24] 2007 	movx	@dptr,a
                                   2008 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      00933E 0A               [12] 2009 	inc	r2
      00933F BA 00 01         [24] 2010 	cjne	r2,#0x00,00218$
      009342 0F               [12] 2011 	inc	r7
      009343                       2012 00218$:
      009343 EA               [12] 2013 	mov	a,r2
      009344 12 97 78         [24] 2014 	lcall	_ak820_outline_0131
      009347                       2015 00123$:
                                   2016 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009347 90 0B AE         [24] 2017 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      00934A E0               [24] 2018 	movx	a,@dptr
      00934B 24 02            [12] 2019 	add	a,#0x02
      00934D F0               [24] 2020 	movx	@dptr,a
      00934E 80 A9            [24] 2021 	sjmp	00122$
      009350                       2022 00120$:
                                   2023 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      009350 90 0B AA         [24] 2024 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      009353 12 3A 81         [24] 2025 	lcall	_ak820_outline_0053
      009356 74 40            [12] 2026 	mov	a,#0x40
      009358 12 48 EE         [24] 2027 	lcall	_ak820_outline_0139
      00935B 90 05 F4         [24] 2028 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00935E 12 4E 09         [24] 2029 	lcall	_ak820_outline_0060
      009361 E4               [12] 2030 	clr	a
      009362 A3               [24] 2031 	inc	dptr
      009363 F0               [24] 2032 	movx	@dptr,a
      009364 90 05 F7         [24] 2033 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      009367 E5 30            [12] 2034 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      009369 F0               [24] 2035 	movx	@dptr,a
      00936A E5 31            [12] 2036 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      00936C A3               [24] 2037 	inc	dptr
      00936D F0               [24] 2038 	movx	@dptr,a
      00936E 12 3A F1         [24] 2039 	lcall	_ak820_outline_0148
                                   2040 ;	quantum/dynamic_keymap.c:521: }
      009371 02 46 C8         [24] 2041 	ljmp	_ak820_eeprom_write_block_xdata
                                   2042 ;------------------------------------------------------------
                                   2043 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2044 ;------------------------------------------------------------
                                   2045 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2046 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2047 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function keycode_at_keymap_location
                                   2052 ;	-----------------------------------------
      009374                       2053 _keycode_at_keymap_location:
      009374 E5 82            [12] 2054 	mov	a,dpl
      009376 90 0B B1         [24] 2055 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      009379 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      00937A E0               [24] 2058 	movx	a,@dptr
      00937B FF               [12] 2059 	mov	r7,a
      00937C BF 06 00         [24] 2060 	cjne	r7,#0x06,00128$
      00937F                       2061 00128$:
      00937F 50 23            [24] 2062 	jnc	00102$
      009381 90 0B AF         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      009384 E0               [24] 2064 	movx	a,@dptr
      009385 FE               [12] 2065 	mov	r6,a
      009386 BE 10 00         [24] 2066 	cjne	r6,#0x10,00130$
      009389                       2067 00130$:
      009389 50 19            [24] 2068 	jnc	00102$
      00938B 90 0B B0         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      00938E E0               [24] 2070 	movx	a,@dptr
      00938F FD               [12] 2071 	mov	r5,a
      009390 BD 08 00         [24] 2072 	cjne	r5,#0x08,00132$
      009393                       2073 00132$:
      009393 50 0F            [24] 2074 	jnc	00102$
                                   2075 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      009395 90 0B 63         [24] 2076 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      009398 EE               [12] 2077 	mov	a,r6
      009399 F0               [24] 2078 	movx	@dptr,a
      00939A 90 0B 64         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00939D ED               [12] 2080 	mov	a,r5
      00939E F0               [24] 2081 	movx	@dptr,a
      00939F 8F 82            [24] 2082 	mov	dpl, r7
      0093A1 02 8D 1B         [24] 2083 	ljmp	_dynamic_keymap_get_keycode
      0093A4                       2084 00102$:
                                   2085 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      0093A4 90 00 00         [24] 2086 	mov	dptr,#0x0000
                                   2087 ;	quantum/dynamic_keymap.c:528: }
      0093A7 22               [24] 2088 	ret
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2091 ;------------------------------------------------------------
                                   2092 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2093 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2094 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2095 ;------------------------------------------------------------
                                   2096 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2097 ;	-----------------------------------------
                                   2098 ;	 function keycode_at_encodermap_location
                                   2099 ;	-----------------------------------------
      0093A8                       2100 _keycode_at_encodermap_location:
      0093A8 E5 82            [12] 2101 	mov	a,dpl
      0093AA 90 0B B4         [24] 2102 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      0093AD F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0093AE E0               [24] 2105 	movx	a,@dptr
      0093AF FF               [12] 2106 	mov	r7,a
      0093B0 BF 06 00         [24] 2107 	cjne	r7,#0x06,00120$
      0093B3                       2108 00120$:
      0093B3 50 1E            [24] 2109 	jnc	00102$
      0093B5 90 0B B2         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0093B8 E0               [24] 2111 	movx	a,@dptr
      0093B9 FE               [12] 2112 	mov	r6,a
      0093BA BE 01 00         [24] 2113 	cjne	r6,#0x01,00122$
      0093BD                       2114 00122$:
      0093BD 50 14            [24] 2115 	jnc	00102$
                                   2116 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      0093BF 90 0B B3         [24] 2117 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      0093C2 E0               [24] 2118 	movx	a,@dptr
      0093C3 FE               [12] 2119 	mov	r6,a
      0093C4 90 0B 6D         [24] 2120 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0093C7 E4               [12] 2121 	clr	a
      0093C8 F0               [24] 2122 	movx	@dptr,a
      0093C9 90 0B 6E         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0093CC EE               [12] 2124 	mov	a,r6
      0093CD F0               [24] 2125 	movx	@dptr,a
      0093CE 8F 82            [24] 2126 	mov	dpl, r7
      0093D0 02 8D D8         [24] 2127 	ljmp	_dynamic_keymap_get_encoder
      0093D3                       2128 00102$:
                                   2129 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      0093D3 90 00 00         [24] 2130 	mov	dptr,#0x0000
                                   2131 ;	quantum/dynamic_keymap.c:536: }
      0093D6 22               [24] 2132 	ret
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function dynamic_keymap_macro_get_count
                                   2139 ;	-----------------------------------------
      0093D7                       2140 _dynamic_keymap_macro_get_count:
                                   2141 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      0093D7 75 82 10         [24] 2142 	mov	dpl, #0x10
                                   2143 ;	quantum/dynamic_keymap.c:541: }
      0093DA 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2151 ;	-----------------------------------------
      0093DB                       2152 _dynamic_keymap_macro_get_buffer_size:
                                   2153 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      0093DB 90 20 00         [24] 2154 	mov	dptr,#0x2000
                                   2155 ;	quantum/dynamic_keymap.c:545: }
      0093DE 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2159 ;------------------------------------------------------------
                                   2160 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2161 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2162 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2163 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer
                                   2168 ;	-----------------------------------------
      0093DF                       2169 _dynamic_keymap_macro_get_buffer:
      0093DF 12 3A C2         [24] 2170 	lcall	_ak820_outline_0110
      0093E2 90 0B BA         [24] 2171 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      0093E5 12 3A C7         [24] 2172 	lcall	_ak820_outline_0111
                                   2173 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      0093E8 12 2B 2B         [24] 2174 	lcall	_ak820_macro_length
      0093EB 12 48 E9         [24] 2175 	lcall	_ak820_outline_0127
      0093EE 90 0B BA         [24] 2176 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      0093F1 12 3A 98         [24] 2177 	lcall	_ak820_outline_0061
      0093F4 90 0B B5         [24] 2178 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      0093F7 E0               [24] 2179 	movx	a,@dptr
      0093F8 F5 33            [12] 2180 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      0093FA A3               [24] 2181 	inc	dptr
      0093FB E0               [24] 2182 	movx	a,@dptr
      0093FC F5 34            [12] 2183 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      0093FE 90 0B B7         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009401 12 3A BC         [24] 2185 	lcall	_ak820_outline_0105
      009404 A3               [24] 2186 	inc	dptr
      009405 E0               [24] 2187 	movx	a,@dptr
      009406 FB               [12] 2188 	mov	r3,a
      009407 90 0B 92         [24] 2189 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00940A 12 4E 09         [24] 2190 	lcall	_ak820_outline_0060
      00940D 90 0B 94         [24] 2191 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009410 12 3A 9E         [24] 2192 	lcall	_ak820_outline_0072
      009413 90 0B 96         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009416 E5 33            [12] 2194 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      009418 F0               [24] 2195 	movx	@dptr,a
      009419 E5 34            [12] 2196 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00941B A3               [24] 2197 	inc	dptr
      00941C F0               [24] 2198 	movx	@dptr,a
      00941D 90 0B 98         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009420 E8               [12] 2200 	mov	a,r0
      009421 F0               [24] 2201 	movx	@dptr,a
      009422 E9               [12] 2202 	mov	a,r1
      009423 A3               [24] 2203 	inc	dptr
      009424 12 80 CA         [24] 2204 	lcall	_ak820_outline_0190
      009427 90 08 00         [24] 2205 	mov	dptr,#0x0800
                                   2206 ;	quantum/dynamic_keymap.c:572: }
      00942A 01 F3            [12] 2207 	ajmp	_ak820_dynamic_read_buffer
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2210 ;------------------------------------------------------------
                                   2211 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2212 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2213 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2214 ;------------------------------------------------------------
                                   2215 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2216 ;	-----------------------------------------
                                   2217 ;	 function dynamic_keymap_macro_set_buffer
                                   2218 ;	-----------------------------------------
      00942C                       2219 _dynamic_keymap_macro_set_buffer:
      00942C 12 3A C2         [24] 2220 	lcall	_ak820_outline_0110
      00942F 90 0B C1         [24] 2221 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      009432 12 3A C7         [24] 2222 	lcall	_ak820_outline_0111
                                   2223 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      009435 90 0B C1         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      009438 12 3A 81         [24] 2225 	lcall	_ak820_outline_0053
      00943B 90 0B BC         [24] 2226 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00943E 12 3A 98         [24] 2227 	lcall	_ak820_outline_0061
      009441 90 0B BE         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009444 12 54 E2         [24] 2229 	lcall	_ak820_outline_0093
      009447 90 05 7A         [24] 2230 	mov	dptr,#_ak820_macro_write_PARM_2
      00944A 12 3A 9E         [24] 2231 	lcall	_ak820_outline_0072
      00944D 90 05 7C         [24] 2232 	mov	dptr,#_ak820_macro_write_PARM_3
      009450 E9               [12] 2233 	mov	a,r1
      009451 12 54 FB         [24] 2234 	lcall	_ak820_outline_0161
      009454 12 48 CB         [24] 2235 	lcall	_ak820_outline_0076
                                   2236 ;	quantum/dynamic_keymap.c:577: }
      009457 02 2B 45         [24] 2237 	ljmp	_ak820_macro_write
                                   2238 ;------------------------------------------------------------
                                   2239 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2240 ;------------------------------------------------------------
                                   2241 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2242 ;	-----------------------------------------
                                   2243 ;	 function dynamic_keymap_macro_reset
                                   2244 ;	-----------------------------------------
      00945A                       2245 _dynamic_keymap_macro_reset:
                                   2246 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2247 ;	quantum/dynamic_keymap.c:603: }
      00945A 02 2E 64         [24] 2248 	ljmp	_ak820_macro_reset
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'decode_keycode'
                                   2251 ;------------------------------------------------------------
                                   2252 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function decode_keycode
                                   2257 ;	-----------------------------------------
      00945D                       2258 _decode_keycode:
      00945D 12 3A C2         [24] 2259 	lcall	_ak820_outline_0110
      009460 90 0B C3         [24] 2260 	mov	dptr,#_decode_keycode_kc_10000_455
      009463 12 3A C7         [24] 2261 	lcall	_ak820_outline_0111
                                   2262 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      009466 90 0B C3         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_455
      009469 12 4D AC         [24] 2264 	lcall	_ak820_outline_0009
      00946C C3               [12] 2265 	clr	c
      00946D E4               [12] 2266 	clr	a
      00946E 9C               [12] 2267 	subb	a,r4
      00946F 74 FF            [12] 2268 	mov	a,#0xff
      009471 9D               [12] 2269 	subb	a,r5
      009472 50 08            [24] 2270 	jnc	00102$
                                   2271 ;	free result
                                   2272 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      009474 8C 05            [24] 2273 	mov	ar5,r4
      009476 7C 00            [12] 2274 	mov	r4,#0x00
      009478 12 3A D7         [24] 2275 	lcall	_ak820_outline_0126
      00947B 22               [24] 2276 	ret
      00947C                       2277 00102$:
                                   2278 ;	quantum/dynamic_keymap.c:609: return kc;
      00947C 12 3A CC         [24] 2279 	lcall	_ak820_outline_0120
                                   2280 ;	quantum/dynamic_keymap.c:610: }
      00947F 22               [24] 2281 	ret
                                   2282 ;------------------------------------------------------------
                                   2283 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2284 ;------------------------------------------------------------
                                   2285 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2286 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2287 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2288 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2289 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2290 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2291 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2292 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2293 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2294 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2295 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2296 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function dynamic_keymap_macro_send
                                   2301 ;	-----------------------------------------
      009480                       2302 _dynamic_keymap_macro_send:
      009480 E5 82            [12] 2303 	mov	a,dpl
      009482 90 0B C5         [24] 2304 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      009485 F0               [24] 2305 	movx	@dptr,a
                                   2306 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      009486 90 0B C6         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      009489 E0               [24] 2308 	movx	a,@dptr
      00948A 60 01            [24] 2309 	jz	00102$
      00948C 22               [24] 2310 	ret
      00948D                       2311 00102$:
                                   2312 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00948D 90 0B C5         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      009490 E0               [24] 2314 	movx	a,@dptr
      009491 FF               [12] 2315 	mov	r7,a
      009492 BF 10 00         [24] 2316 	cjne	r7,#0x10,00422$
      009495                       2317 00422$:
      009495 40 01            [24] 2318 	jc	00104$
                                   2319 ;	quantum/dynamic_keymap.c:620: return;
      009497 22               [24] 2320 	ret
      009498                       2321 00104$:
                                   2322 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      009498 C0 07            [24] 2323 	push	ar7
      00949A 12 2A F2         [24] 2324 	lcall	_ak820_macro_ready
      00949D E5 82            [12] 2325 	mov	a, dpl
      00949F D0 07            [24] 2326 	pop	ar7
      0094A1 70 01            [24] 2327 	jnz	00106$
      0094A3 22               [24] 2328 	ret
      0094A4                       2329 00106$:
                                   2330 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0094A4 90 0B C7         [24] 2331 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0094A7 E4               [12] 2332 	clr	a
      0094A8 F0               [24] 2333 	movx	@dptr,a
      0094A9 74 08            [12] 2334 	mov	a,#0x08
      0094AB A3               [24] 2335 	inc	dptr
      0094AC F0               [24] 2336 	movx	@dptr,a
                                   2337 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0094AD C0 07            [24] 2338 	push	ar7
      0094AF 12 2B 2B         [24] 2339 	lcall	_ak820_macro_length
      0094B2 AD 82            [24] 2340 	mov	r5, dpl
      0094B4 AE 83            [24] 2341 	mov	r6, dph
      0094B6 D0 07            [24] 2342 	pop	ar7
      0094B8 74 08            [12] 2343 	mov	a,#0x08
      0094BA 2E               [12] 2344 	add	a, r6
      0094BB FE               [12] 2345 	mov	r6,a
                                   2346 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      0094BC 7B 00            [12] 2347 	mov	r3,#0x00
      0094BE 7C 08            [12] 2348 	mov	r4,#0x08
      0094C0                       2349 00111$:
      0094C0 EF               [12] 2350 	mov	a,r7
      0094C1 60 31            [24] 2351 	jz	00113$
                                   2352 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      0094C3 EB               [12] 2353 	mov	a,r3
      0094C4 B5 05 05         [24] 2354 	cjne	a,ar5,00108$
      0094C7 EC               [12] 2355 	mov	a,r4
      0094C8 B5 06 01         [24] 2356 	cjne	a,ar6,00108$
                                   2357 ;	quantum/dynamic_keymap.c:654: return;
      0094CB 22               [24] 2358 	ret
      0094CC                       2359 00108$:
                                   2360 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0094CC 8B 01            [24] 2361 	mov	ar1,r3
      0094CE 8C 02            [24] 2362 	mov	ar2,r4
      0094D0 8A 00            [24] 2363 	mov	ar0,r2
      0094D2 7A 00            [12] 2364 	mov	r2,#0x00
      0094D4 89 82            [24] 2365 	mov	dpl, r1
      0094D6 88 83            [24] 2366 	mov	dph, r0
      0094D8 8A F0            [24] 2367 	mov	b, r2
      0094DA 12 46 01         [24] 2368 	lcall	_eeprom_read_byte
      0094DD E5 82            [12] 2369 	mov	a, dpl
      0094DF 70 06            [24] 2370 	jnz	00110$
                                   2371 ;	quantum/dynamic_keymap.c:657: --id;
      0094E1 1F               [12] 2372 	dec	r7
      0094E2 90 0B C5         [24] 2373 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      0094E5 EF               [12] 2374 	mov	a,r7
      0094E6 F0               [24] 2375 	movx	@dptr,a
      0094E7                       2376 00110$:
                                   2377 ;	quantum/dynamic_keymap.c:659: ++p;
      0094E7 0B               [12] 2378 	inc	r3
      0094E8 BB 00 01         [24] 2379 	cjne	r3,#0x00,00429$
      0094EB 0C               [12] 2380 	inc	r4
      0094EC                       2381 00429$:
      0094EC 90 0B C7         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0094EF 12 3A AA         [24] 2383 	lcall	_ak820_outline_0087
      0094F2 80 CC            [24] 2384 	sjmp	00111$
      0094F4                       2385 00113$:
                                   2386 ;	quantum/dynamic_keymap.c:665: sending = true;
      0094F4 90 0B C6         [24] 2387 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      0094F7 74 01            [12] 2388 	mov	a,#0x01
      0094F9 F0               [24] 2389 	movx	@dptr,a
                                   2390 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      0094FA 12 97 90         [24] 2391 	lcall	_ak820_outline_0170
      0094FD 90 0A 0F         [24] 2392 	mov	dptr,#_ak820_macro_cancelled
      009500 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      009501 90 0B C9         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009504 F0               [24] 2396 	movx	@dptr,a
      009505 90 0B CA         [24] 2397 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009508 F0               [24] 2398 	movx	@dptr,a
      009509 90 0B CB         [24] 2399 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      00950C F0               [24] 2400 	movx	@dptr,a
      00950D 90 0B CC         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      009510 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:675: while (p < end
      009511                       2404 00167$:
                                   2405 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      009511 90 0B C7         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009514 E0               [24] 2407 	movx	a,@dptr
      009515 FC               [12] 2408 	mov	r4,a
      009516 A3               [24] 2409 	inc	dptr
      009517 E0               [24] 2410 	movx	a,@dptr
      009518 FF               [12] 2411 	mov	r7,a
      009519 C3               [12] 2412 	clr	c
      00951A EC               [12] 2413 	mov	a,r4
      00951B 9D               [12] 2414 	subb	a,r5
      00951C EF               [12] 2415 	mov	a,r7
      00951D 9E               [12] 2416 	subb	a,r6
      00951E 40 02            [24] 2417 	jc	00430$
      009520 E1 25            [12] 2418 	ajmp	00169$
      009522                       2419 00430$:
      009522 90 0A 0F         [24] 2420 	mov	dptr,#_ak820_macro_cancelled
      009525 E0               [24] 2421 	movx	a,@dptr
      009526 60 02            [24] 2422 	jz	00431$
      009528 E1 25            [12] 2423 	ajmp	00169$
      00952A                       2424 00431$:
                                   2425 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00952A 8C 02            [24] 2426 	mov	ar2,r4
      00952C 8F 03            [24] 2427 	mov	ar3,r7
      00952E 90 0B C7         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009531 74 01            [12] 2429 	mov	a,#0x01
      009533 2C               [12] 2430 	add	a, r4
      009534 F0               [24] 2431 	movx	@dptr,a
      009535 E4               [12] 2432 	clr	a
      009536 3F               [12] 2433 	addc	a, r7
      009537 A3               [24] 2434 	inc	dptr
      009538 F0               [24] 2435 	movx	@dptr,a
      009539 7F 00            [12] 2436 	mov	r7,#0x00
      00953B 12 3A EC         [24] 2437 	lcall	_ak820_outline_0147
      00953E 8F F0            [24] 2438 	mov	b, r7
      009540 12 46 01         [24] 2439 	lcall	_eeprom_read_byte
      009543 AF 82            [24] 2440 	mov	r7, dpl
      009545 90 0B C9         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009548 EF               [12] 2442 	mov	a,r7
      009549 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      00954A 90 0B CA         [24] 2445 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00954D E4               [12] 2446 	clr	a
      00954E F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      00954F 90 0B C9         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009552 E0               [24] 2450 	movx	a,@dptr
      009553 70 02            [24] 2451 	jnz	00432$
      009555 E1 25            [12] 2452 	ajmp	00169$
      009557                       2453 00432$:
                                   2454 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      009557 90 0B C9         [24] 2455 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00955A E0               [24] 2456 	movx	a,@dptr
      00955B FF               [12] 2457 	mov	r7,a
      00955C BF 01 02         [24] 2458 	cjne	r7,#0x01,00433$
      00955F 80 02            [24] 2459 	sjmp	00434$
      009561                       2460 00433$:
      009561 E1 08            [12] 2461 	ajmp	00164$
      009563                       2462 00434$:
                                   2463 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009563 12 97 2D         [24] 2464 	lcall	_ak820_outline_0000
      009566 12 46 01         [24] 2465 	lcall	_eeprom_read_byte
      009569 AF 82            [24] 2466 	mov	r7, dpl
      00956B 90 0B CA         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00956E EF               [12] 2468 	mov	a,r7
      00956F F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      009570 EF               [12] 2471 	mov	a,r7
      009571 70 02            [24] 2472 	jnz	00435$
      009573 E1 25            [12] 2473 	ajmp	00169$
      009575                       2474 00435$:
                                   2475 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009575 12 97 57         [24] 2476 	lcall	_ak820_outline_0096
      009578 BF 01 02         [24] 2477 	cjne	r7,#0x01,00436$
      00957B 80 12            [24] 2478 	sjmp	00151$
      00957D                       2479 00436$:
      00957D 12 97 57         [24] 2480 	lcall	_ak820_outline_0096
      009580 BF 02 02         [24] 2481 	cjne	r7,#0x02,00437$
      009583 80 0A            [24] 2482 	sjmp	00151$
      009585                       2483 00437$:
      009585 12 97 57         [24] 2484 	lcall	_ak820_outline_0096
      009588 BF 03 02         [24] 2485 	cjne	r7,#0x03,00438$
      00958B 80 02            [24] 2486 	sjmp	00439$
      00958D                       2487 00438$:
      00958D A1 EE            [12] 2488 	ajmp	00152$
      00958F                       2489 00439$:
      00958F                       2490 00151$:
                                   2491 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00958F 12 97 2D         [24] 2492 	lcall	_ak820_outline_0000
      009592 12 46 01         [24] 2493 	lcall	_eeprom_read_byte
      009595 12 97 A8         [24] 2494 	lcall	_ak820_outline_0183
                                   2495 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      009598 70 02            [24] 2496 	jnz	00440$
      00959A A1 11            [12] 2497 	ajmp	00167$
      00959C                       2498 00440$:
                                   2499 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      00959C 12 97 57         [24] 2500 	lcall	_ak820_outline_0096
      00959F BF 01 03         [24] 2501 	cjne	r7,#0x01,00441$
      0095A2 D3               [12] 2502 	setb	c
      0095A3 80 01            [24] 2503 	sjmp	00442$
      0095A5                       2504 00441$:
      0095A5 C3               [12] 2505 	clr	c
      0095A6                       2506 00442$:
      0095A6 92 27            [24] 2507 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0095A8 90 0A 0E         [24] 2508 	mov	dptr,#_ak820_macro_primitive
      0095AB B3               [12] 2509 	cpl	c
      0095AC E4               [12] 2510 	clr	a
      0095AD 33               [12] 2511 	rlc	a
      0095AE F0               [24] 2512 	movx	@dptr,a
                                   2513 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0095AF 12 97 57         [24] 2514 	lcall	_ak820_outline_0096
      0095B2 BF 01 10         [24] 2515 	cjne	r7,#0x01,00122$
      0095B5 12 97 89         [24] 2516 	lcall	_ak820_outline_0157
      0095B8 C0 06            [24] 2517 	push	ar6
      0095BA C0 05            [24] 2518 	push	ar5
      0095BC 12 7F 75         [24] 2519 	lcall	_tap_code
      0095BF D0 05            [24] 2520 	pop	ar5
      0095C1 D0 06            [24] 2521 	pop	ar6
      0095C3 80 24            [24] 2522 	sjmp	00123$
      0095C5                       2523 00122$:
                                   2524 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0095C5 12 97 57         [24] 2525 	lcall	_ak820_outline_0096
      0095C8 BF 02 10         [24] 2526 	cjne	r7,#0x02,00119$
      0095CB 12 97 89         [24] 2527 	lcall	_ak820_outline_0157
      0095CE C0 06            [24] 2528 	push	ar6
      0095D0 C0 05            [24] 2529 	push	ar5
      0095D2 12 7E 30         [24] 2530 	lcall	_register_code
      0095D5 D0 05            [24] 2531 	pop	ar5
      0095D7 D0 06            [24] 2532 	pop	ar6
      0095D9 80 0E            [24] 2533 	sjmp	00123$
      0095DB                       2534 00119$:
                                   2535 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      0095DB 12 97 89         [24] 2536 	lcall	_ak820_outline_0157
      0095DE C0 06            [24] 2537 	push	ar6
      0095E0 C0 05            [24] 2538 	push	ar5
      0095E2 12 7E BD         [24] 2539 	lcall	_unregister_code
      0095E5 D0 05            [24] 2540 	pop	ar5
      0095E7 D0 06            [24] 2541 	pop	ar6
      0095E9                       2542 00123$:
                                   2543 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      0095E9 12 97 90         [24] 2544 	lcall	_ak820_outline_0170
      0095EC A1 11            [12] 2545 	ajmp	00167$
      0095EE                       2546 00152$:
                                   2547 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0095EE 12 97 57         [24] 2548 	lcall	_ak820_outline_0096
      0095F1 BF 05 02         [24] 2549 	cjne	r7,#0x05,00447$
      0095F4 80 12            [24] 2550 	sjmp	00146$
      0095F6                       2551 00447$:
      0095F6 12 97 57         [24] 2552 	lcall	_ak820_outline_0096
      0095F9 BF 06 02         [24] 2553 	cjne	r7,#0x06,00448$
      0095FC 80 0A            [24] 2554 	sjmp	00146$
      0095FE                       2555 00448$:
      0095FE 12 97 57         [24] 2556 	lcall	_ak820_outline_0096
      009601 BF 07 02         [24] 2557 	cjne	r7,#0x07,00449$
      009604 80 02            [24] 2558 	sjmp	00450$
      009606                       2559 00449$:
      009606 C1 AA            [12] 2560 	ajmp	00147$
      009608                       2561 00450$:
      009608                       2562 00146$:
                                   2563 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009608 12 97 2D         [24] 2564 	lcall	_ak820_outline_0000
      00960B 12 46 01         [24] 2565 	lcall	_eeprom_read_byte
      00960E 12 97 A8         [24] 2566 	lcall	_ak820_outline_0183
                                   2567 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      009611 70 02            [24] 2568 	jnz	00451$
      009613 A1 11            [12] 2569 	ajmp	00167$
      009615                       2570 00451$:
                                   2571 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009615 12 97 2D         [24] 2572 	lcall	_ak820_outline_0000
      009618 12 46 01         [24] 2573 	lcall	_eeprom_read_byte
      00961B AF 82            [24] 2574 	mov	r7, dpl
      00961D 90 0B CC         [24] 2575 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      009620 EF               [12] 2576 	mov	a,r7
      009621 F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      009622 EF               [12] 2579 	mov	a,r7
      009623 70 02            [24] 2580 	jnz	00452$
      009625 A1 11            [12] 2581 	ajmp	00167$
      009627                       2582 00452$:
                                   2583 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009627 90 0B CB         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      00962A E0               [24] 2585 	movx	a,@dptr
      00962B FF               [12] 2586 	mov	r7,a
      00962C 90 0B CC         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      00962F E0               [24] 2588 	movx	a,@dptr
      009630 FB               [12] 2589 	mov	r3,a
      009631 E4               [12] 2590 	clr	a
      009632 FC               [12] 2591 	mov	r4,a
      009633 FA               [12] 2592 	mov	r2,a
      009634 EF               [12] 2593 	mov	a,r7
      009635 42 04            [12] 2594 	orl	ar4,a
      009637 EA               [12] 2595 	mov	a,r2
      009638 42 03            [12] 2596 	orl	ar3,a
                                   2597 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      00963A 12 49 15         [24] 2598 	lcall	_ak820_outline_0187
      00963D C0 06            [24] 2599 	push	ar6
      00963F C0 05            [24] 2600 	push	ar5
      009641 91 5D            [12] 2601 	acall	_decode_keycode
      009643 AC 82            [24] 2602 	mov	r4, dpl
      009645 AF 83            [24] 2603 	mov	r7, dph
      009647 D0 05            [24] 2604 	pop	ar5
      009649 D0 06            [24] 2605 	pop	ar6
                                   2606 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00964B 90 0B CA         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      00964E E0               [24] 2608 	movx	a,@dptr
      00964F FB               [12] 2609 	mov	r3,a
      009650 BB 05 03         [24] 2610 	cjne	r3,#0x05,00453$
      009653 D3               [12] 2611 	setb	c
      009654 80 01            [24] 2612 	sjmp	00454$
      009656                       2613 00453$:
      009656 C3               [12] 2614 	clr	c
      009657                       2615 00454$:
      009657 92 27            [24] 2616 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009659 90 0A 0E         [24] 2617 	mov	dptr,#_ak820_macro_primitive
      00965C B3               [12] 2618 	cpl	c
      00965D E4               [12] 2619 	clr	a
      00965E 33               [12] 2620 	rlc	a
      00965F F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      009660 90 0B CA         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009663 E0               [24] 2624 	movx	a,@dptr
      009664 FB               [12] 2625 	mov	r3,a
      009665 BB 05 02         [24] 2626 	cjne	r3,#0x05,00455$
      009668 80 0A            [24] 2627 	sjmp	00126$
      00966A                       2628 00455$:
      00966A BB 06 02         [24] 2629 	cjne	r3,#0x06,00456$
      00966D 80 16            [24] 2630 	sjmp	00127$
      00966F                       2631 00456$:
                                   2632 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      00966F BB 07 33         [24] 2633 	cjne	r3,#0x07,00129$
      009672 80 22            [24] 2634 	sjmp	00128$
      009674                       2635 00126$:
                                   2636 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      009674 8C 82            [24] 2637 	mov	dpl, r4
      009676 8F 83            [24] 2638 	mov	dph, r7
      009678 C0 06            [24] 2639 	push	ar6
      00967A C0 05            [24] 2640 	push	ar5
      00967C 12 BA 9A         [24] 2641 	lcall	_vial_keycode_tap
      00967F D0 05            [24] 2642 	pop	ar5
      009681 D0 06            [24] 2643 	pop	ar6
                                   2644 ;	quantum/dynamic_keymap.c:732: break;
                                   2645 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      009683 80 20            [24] 2646 	sjmp	00129$
      009685                       2647 00127$:
                                   2648 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      009685 8C 82            [24] 2649 	mov	dpl, r4
      009687 8F 83            [24] 2650 	mov	dph, r7
      009689 C0 06            [24] 2651 	push	ar6
      00968B C0 05            [24] 2652 	push	ar5
      00968D 12 B9 CF         [24] 2653 	lcall	_vial_keycode_down
      009690 D0 05            [24] 2654 	pop	ar5
      009692 D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:735: break;
                                   2657 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      009694 80 0F            [24] 2658 	sjmp	00129$
      009696                       2659 00128$:
                                   2660 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      009696 8C 82            [24] 2661 	mov	dpl, r4
      009698 8F 83            [24] 2662 	mov	dph, r7
      00969A C0 06            [24] 2663 	push	ar6
      00969C C0 05            [24] 2664 	push	ar5
      00969E 12 BA 35         [24] 2665 	lcall	_vial_keycode_up
      0096A1 D0 05            [24] 2666 	pop	ar5
      0096A3 D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:739: }
      0096A5                       2669 00129$:
                                   2670 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      0096A5 12 97 90         [24] 2671 	lcall	_ak820_outline_0170
      0096A8 A1 11            [12] 2672 	ajmp	00167$
      0096AA                       2673 00147$:
                                   2674 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      0096AA 12 97 57         [24] 2675 	lcall	_ak820_outline_0096
      0096AD BF 04 02         [24] 2676 	cjne	r7,#0x04,00458$
      0096B0 80 02            [24] 2677 	sjmp	00459$
      0096B2                       2678 00458$:
      0096B2 A1 11            [12] 2679 	ajmp	00167$
      0096B4                       2680 00459$:
                                   2681 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0096B4 12 97 2D         [24] 2682 	lcall	_ak820_outline_0000
      0096B7 12 46 01         [24] 2683 	lcall	_eeprom_read_byte
      0096BA AF 82            [24] 2684 	mov	r7, dpl
                                   2685 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0096BC 90 0B C7         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0096BF 12 3A D1         [24] 2687 	lcall	_ak820_outline_0124
      0096C2 90 0B C7         [24] 2688 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0096C5 74 01            [12] 2689 	mov	a,#0x01
      0096C7 2B               [12] 2690 	add	a, r3
      0096C8 F0               [24] 2691 	movx	@dptr,a
      0096C9 E4               [12] 2692 	clr	a
      0096CA 3C               [12] 2693 	addc	a, r4
      0096CB A3               [24] 2694 	inc	dptr
      0096CC F0               [24] 2695 	movx	@dptr,a
      0096CD 7A 00            [12] 2696 	mov	r2,#0x00
      0096CF 12 36 47         [24] 2697 	lcall	_ak820_outline_0125
      0096D2 8A F0            [24] 2698 	mov	b, r2
      0096D4 12 46 01         [24] 2699 	lcall	_eeprom_read_byte
      0096D7 AC 82            [24] 2700 	mov	r4, dpl
                                   2701 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      0096D9 EF               [12] 2702 	mov	a,r7
      0096DA 60 49            [24] 2703 	jz	00169$
      0096DC EC               [12] 2704 	mov	a,r4
      0096DD 60 46            [24] 2705 	jz	00169$
                                   2706 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0096DF 1F               [12] 2707 	dec	r7
      0096E0 1C               [12] 2708 	dec	r4
      0096E1 EC               [12] 2709 	mov	a,r4
      0096E2 75 F0 FF         [24] 2710 	mov	b,#0xff
      0096E5 A4               [48] 2711 	mul	ab
      0096E6 FC               [12] 2712 	mov	r4,a
      0096E7 AB F0            [24] 2713 	mov	r3,b
      0096E9 7A 00            [12] 2714 	mov	r2,#0x00
      0096EB EC               [12] 2715 	mov	a,r4
      0096EC 2F               [12] 2716 	add	a, r7
      0096ED FC               [12] 2717 	mov	r4,a
      0096EE EB               [12] 2718 	mov	a,r3
      0096EF 3A               [12] 2719 	addc	a, r2
      0096F0 FB               [12] 2720 	mov	r3,a
                                   2721 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      0096F1                       2722 00141$:
      0096F1 8C 02            [24] 2723 	mov	ar2,r4
      0096F3 8B 07            [24] 2724 	mov	ar7,r3
      0096F5 1C               [12] 2725 	dec	r4
      0096F6 BC FF 01         [24] 2726 	cjne	r4,#0xff,00462$
      0096F9 1B               [12] 2727 	dec	r3
      0096FA                       2728 00462$:
      0096FA EA               [12] 2729 	mov	a,r2
      0096FB 4F               [12] 2730 	orl	a,r7
      0096FC 70 02            [24] 2731 	jnz	00463$
      0096FE A1 11            [12] 2732 	ajmp	00167$
      009700                       2733 00463$:
      009700 90 00 01         [24] 2734 	mov	dptr,#0x0001
      009703 12 60 B1         [24] 2735 	lcall	_mDelaymS
      009706 80 E9            [24] 2736 	sjmp	00141$
      009708                       2737 00164$:
                                   2738 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      009708 90 0B C9         [24] 2739 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00970B E0               [24] 2740 	movx	a,@dptr
      00970C FF               [12] 2741 	mov	r7,a
      00970D BF 80 00         [24] 2742 	cjne	r7,#0x80,00464$
      009710                       2743 00464$:
      009710 50 13            [24] 2744 	jnc	00169$
                                   2745 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      009712 90 0B C9         [24] 2746 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009715 E0               [24] 2747 	movx	a,@dptr
      009716 F5 82            [12] 2748 	mov	dpl,a
      009718 C0 06            [24] 2749 	push	ar6
      00971A C0 05            [24] 2750 	push	ar5
      00971C 12 AD 67         [24] 2751 	lcall	_send_char
      00971F D0 05            [24] 2752 	pop	ar5
      009721 D0 06            [24] 2753 	pop	ar6
                                   2754 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009723 A1 11            [12] 2755 	ajmp	00167$
      009725                       2756 00169$:
                                   2757 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      009725 12 97 90         [24] 2758 	lcall	_ak820_outline_0170
                                   2759 ;	quantum/dynamic_keymap.c:774: sending = false;
      009728 90 0B C6         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      00972B F0               [24] 2761 	movx	@dptr,a
                                   2762 ;	quantum/dynamic_keymap.c:776: }
      00972C 22               [24] 2763 	ret
                                   2764 	.area CSEG    (CODE)
                                   2765 	.area CONST   (CODE)
                                   2766 	.area XINIT   (CODE)
                                   2767 	.area CABS    (ABS,CODE)
                                   2768 
                                   2769 ; Experimental exact instruction outlining.
                                   2770 	.globl _ak820_outline_0000
                                   2771 	.globl _ak820_outline_0005
                                   2772 	.globl _ak820_outline_0009
                                   2773 	.globl _ak820_outline_0014
                                   2774 	.globl _ak820_outline_0022
                                   2775 	.globl _ak820_outline_0031
                                   2776 	.globl _ak820_outline_0034
                                   2777 	.globl _ak820_outline_0050
                                   2778 	.globl _ak820_outline_0051
                                   2779 	.globl _ak820_outline_0053
                                   2780 	.globl _ak820_outline_0060
                                   2781 	.globl _ak820_outline_0061
                                   2782 	.globl _ak820_outline_0072
                                   2783 	.globl _ak820_outline_0076
                                   2784 	.globl _ak820_outline_0078
                                   2785 	.globl _ak820_outline_0083
                                   2786 	.globl _ak820_outline_0087
                                   2787 	.globl _ak820_outline_0093
                                   2788 	.globl _ak820_outline_0095
                                   2789 	.globl _ak820_outline_0096
                                   2790 	.globl _ak820_outline_0102
                                   2791 	.globl _ak820_outline_0104
                                   2792 	.globl _ak820_outline_0105
                                   2793 	.globl _ak820_outline_0106
                                   2794 	.globl _ak820_outline_0110
                                   2795 	.globl _ak820_outline_0111
                                   2796 	.globl _ak820_outline_0114
                                   2797 	.globl _ak820_outline_0118
                                   2798 	.globl _ak820_outline_0120
                                   2799 	.globl _ak820_outline_0124
                                   2800 	.globl _ak820_outline_0125
                                   2801 	.globl _ak820_outline_0126
                                   2802 	.globl _ak820_outline_0127
                                   2803 	.globl _ak820_outline_0131
                                   2804 	.globl _ak820_outline_0136
                                   2805 	.globl _ak820_outline_0137
                                   2806 	.globl _ak820_outline_0138
                                   2807 	.globl _ak820_outline_0139
                                   2808 	.globl _ak820_outline_0146
                                   2809 	.globl _ak820_outline_0147
                                   2810 	.globl _ak820_outline_0148
                                   2811 	.globl _ak820_outline_0154
                                   2812 	.globl _ak820_outline_0157
                                   2813 	.globl _ak820_outline_0161
                                   2814 	.globl _ak820_outline_0164
                                   2815 	.globl _ak820_outline_0170
                                   2816 	.globl _ak820_outline_0179
                                   2817 	.globl _ak820_outline_0180
                                   2818 	.globl _ak820_outline_0183
                                   2819 	.globl _ak820_outline_0184
                                   2820 	.globl _ak820_outline_0185
                                   2821 	.globl _ak820_outline_0186
                                   2822 	.globl _ak820_outline_0187
                                   2823 	.globl _ak820_outline_0190
                                   2824 
                                   2825 	.area CSEG (CODE)
                                   2826 ; function ak820_outline_0000
      00972D                       2827 _ak820_outline_0000:
      00972D 90 0B C7         [24] 2828 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009730 E0               [24] 2829 	movx	a,@dptr
      009731 FC               [12] 2830 	mov	r4,a
      009732 A3               [24] 2831 	inc	dptr
      009733 E0               [24] 2832 	movx	a,@dptr
      009734 FF               [12] 2833 	mov	r7,a
      009735 90 0B C7         [24] 2834 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009738 74 01            [12] 2835 	mov	a,#0x01
      00973A 2C               [12] 2836 	add	a,r4
      00973B F0               [24] 2837 	movx	@dptr,a
      00973C E4               [12] 2838 	clr	a
      00973D 3F               [12] 2839 	addc	a,r7
      00973E A3               [24] 2840 	inc	dptr
      00973F F0               [24] 2841 	movx	@dptr,a
      009740 7B 00            [12] 2842 	mov	r3,#0x00
      009742 8C 82            [24] 2843 	mov	dpl,r4
      009744 8F 83            [24] 2844 	mov	dph,r7
      009746 8B F0            [24] 2845 	mov	b,r3
      009748 22               [24] 2846 	ret
                                   2847 
                                   2848 	.area CSEG (CODE)
                                   2849 ; function ak820_outline_0083
      009749                       2850 _ak820_outline_0083:
      009749 ED               [12] 2851 	mov	a,r5
      00974A 75 F0 0A         [24] 2852 	mov	b,#0x0a
      00974D A4               [48] 2853 	mul	ab
      00974E 24 58            [12] 2854 	add	a,#0x58
      009750 FC               [12] 2855 	mov	r4,a
      009751 74 06            [12] 2856 	mov	a,#0x06
      009753 35 F0            [12] 2857 	addc	a,b
      009755 FD               [12] 2858 	mov	r5,a
      009756 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0096
      009757                       2863 _ak820_outline_0096:
      009757 90 0B CA         [24] 2864 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      00975A E0               [24] 2865 	movx	a,@dptr
      00975B FF               [12] 2866 	mov	r7,a
      00975C 22               [24] 2867 	ret
                                   2868 
                                   2869 	.area CSEG (CODE)
                                   2870 ; function ak820_outline_0102
      00975D                       2871 _ak820_outline_0102:
      00975D 90 0B 60         [24] 2872 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009760 EE               [12] 2873 	mov	a,r6
      009761 F0               [24] 2874 	movx	@dptr,a
      009762 90 0B 61         [24] 2875 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009765 ED               [12] 2876 	mov	a,r5
      009766 F0               [24] 2877 	movx	@dptr,a
      009767 8F 82            [24] 2878 	mov	dpl,r7
      009769 22               [24] 2879 	ret
                                   2880 
                                   2881 	.area CSEG (CODE)
                                   2882 ; function ak820_outline_0114
      00976A                       2883 _ak820_outline_0114:
      00976A 74 0A            [12] 2884 	mov	a,#0x0a
      00976C F0               [24] 2885 	movx	@dptr,a
      00976D E4               [12] 2886 	clr	a
      00976E A3               [24] 2887 	inc	dptr
      00976F F0               [24] 2888 	movx	@dptr,a
      009770 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0118
      009771                       2893 _ak820_outline_0118:
      009771 AD 82            [24] 2894 	mov	r5,dpl
      009773 AE 83            [24] 2895 	mov	r6,dph
      009775 AF F0            [24] 2896 	mov	r7,b
      009777 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0131
      009778                       2901 _ak820_outline_0131:
      009778 28               [12] 2902 	add	a,r0
      009779 F5 82            [12] 2903 	mov	dpl,a
      00977B EF               [12] 2904 	mov	a,r7
      00977C 39               [12] 2905 	addc	a,r1
      00977D F5 83            [12] 2906 	mov	dph,a
      00977F 74 FF            [12] 2907 	mov	a,#0xff
      009781 F0               [24] 2908 	movx	@dptr,a
      009782 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0138
      009783                       2913 _ak820_outline_0138:
      009783 2D               [12] 2914 	add	a,r5
      009784 F9               [12] 2915 	mov	r1,a
      009785 E4               [12] 2916 	clr	a
      009786 3E               [12] 2917 	addc	a,r6
      009787 FA               [12] 2918 	mov	r2,a
      009788 22               [24] 2919 	ret
                                   2920 
                                   2921 	.area CSEG (CODE)
                                   2922 ; function ak820_outline_0157
      009789                       2923 _ak820_outline_0157:
      009789 90 0B CB         [24] 2924 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00978C E0               [24] 2925 	movx	a,@dptr
      00978D F5 82            [12] 2926 	mov	dpl,a
      00978F 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0170
      009790                       2931 _ak820_outline_0170:
      009790 90 0A 0E         [24] 2932 	mov	dptr,#_ak820_macro_primitive
      009793 E4               [12] 2933 	clr	a
      009794 F0               [24] 2934 	movx	@dptr,a
      009795 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0179
      009796                       2939 _ak820_outline_0179:
      009796 90 0B 70         [24] 2940 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009799 E4               [12] 2941 	clr	a
      00979A F0               [24] 2942 	movx	@dptr,a
      00979B 90 0B 71         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00979E 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0180
      00979F                       2948 _ak820_outline_0180:
      00979F 90 0C 26         [24] 2949 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0097A2 E4               [12] 2950 	clr	a
      0097A3 F0               [24] 2951 	movx	@dptr,a
      0097A4 90 0C 27         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0097A7 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0183
      0097A8                       2957 _ak820_outline_0183:
      0097A8 AF 82            [24] 2958 	mov	r7,dpl
      0097AA 90 0B CB         [24] 2959 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      0097AD EF               [12] 2960 	mov	a,r7
      0097AE F0               [24] 2961 	movx	@dptr,a
      0097AF EF               [12] 2962 	mov	a,r7
      0097B0 22               [24] 2963 	ret
