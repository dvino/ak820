                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004D                        535 _fast_set_leds_sloc0_1_0:
      00004D                        536 	.ds 2
      00004F                        537 _fast_set_leds_sloc1_1_0:
      00004F                        538 	.ds 2
      000051                        539 _vialrgb_get_value_sloc0_1_0:
      000051                        540 	.ds 2
      000053                        541 _vialrgb_get_value_sloc1_1_0:
      000053                        542 	.ds 2
      000055                        543 _vialrgb_set_value_sloc0_1_0:
      000055                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CBF                        569 _g_direct_mode_colors::
      000CBF                        570 	.ds 246
      000DB5                        571 _get_supported_PARM_2:
      000DB5                        572 	.ds 1
      000DB6                        573 _get_supported_args_10000_255:
      000DB6                        574 	.ds 2
      000DB8                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DB8                        576 	.ds 2
      000DBA                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DBA                        578 	.ds 2
      000DBC                        579 _set_mode_mode_10000_275:
      000DBC                        580 	.ds 2
      000DBE                        581 _get_matrix_pos_for_led_PARM_2:
      000DBE                        582 	.ds 2
      000DC0                        583 _get_matrix_pos_for_led_led_10000_280:
      000DC0                        584 	.ds 2
      000DC2                        585 _fast_set_leds_PARM_2:
      000DC2                        586 	.ds 1
      000DC3                        587 _fast_set_leds_args_10000_282:
      000DC3                        588 	.ds 2
      000DC5                        589 _fast_set_leds_first_index_10001_285:
      000DC5                        590 	.ds 2
      000DC7                        591 _fast_set_leds_num_leds_10001_285:
      000DC7                        592 	.ds 1
      000DC8                        593 _vialrgb_get_value_PARM_2:
      000DC8                        594 	.ds 1
      000DC9                        595 _vialrgb_get_value_data_10000_291:
      000DC9                        596 	.ds 3
      000DCC                        597 _vialrgb_set_value_PARM_2:
      000DCC                        598 	.ds 1
      000DCD                        599 _vialrgb_set_value_data_10000_302:
      000DCD                        600 	.ds 3
      000DD0                        601 _vialrgb_save_PARM_2:
      000DD0                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B6C7                        654 _get_supported:
      00B6C7 12 3A F0         [24]  655 	lcall	_ak820_outline_0107
      00B6CA 90 0D B6         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B6CD 12 3A F5         [24]  657 	lcall	_ak820_outline_0108
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B6D0 90 0D B6         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B6D3 12 3A 62         [24]  660 	lcall	_ak820_outline_0005
      00B6D6 E0               [24]  661 	movx	a,@dptr
      00B6D7 FD               [12]  662 	mov	r5,a
      00B6D8 7C 00            [12]  663 	mov	r4,#0x00
      00B6DA 12 3A FA         [24]  664 	lcall	_ak820_outline_0118
      00B6DD A3               [24]  665 	inc	dptr
      00B6DE E0               [24]  666 	movx	a,@dptr
      00B6DF FA               [12]  667 	mov	r2,a
      00B6E0 E4               [12]  668 	clr	a
      00B6E1 12 45 CF         [24]  669 	lcall	_ak820_outline_0143
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B6E4 90 0D B5         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B6E7 E0               [24]  672 	movx	a,@dptr
      00B6E8 FB               [12]  673 	mov	r3,a
      00B6E9 7A 00            [12]  674 	mov	r2,#0x00
      00B6EB                        675 00107$:
      00B6EB C3               [12]  676 	clr	c
      00B6EC EA               [12]  677 	mov	a,r2
      00B6ED 9B               [12]  678 	subb	a,r3
      00B6EE 50 0A            [24]  679 	jnc	00101$
      00B6F0 EA               [12]  680 	mov	a,r2
      00B6F1 12 3A 9F         [24]  681 	lcall	_ak820_outline_0022
      00B6F4 74 FF            [12]  682 	mov	a,#0xff
      00B6F6 F0               [24]  683 	movx	@dptr,a
      00B6F7 0A               [12]  684 	inc	r2
      00B6F8 80 F1            [24]  685 	sjmp	00107$
      00B6FA                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B6FA 8D 06            [24]  688 	mov	ar6,r5
      00B6FC 8C 07            [24]  689 	mov	ar7,r4
      00B6FE 8B 05            [24]  690 	mov	ar5,r3
      00B700 90 0D B6         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B703 12 3B 14         [24]  692 	lcall	_ak820_outline_0141
      00B706 7A 00            [12]  693 	mov	r2,#0x00
      00B708                        694 00110$:
      00B708 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B70B                        696 00159$:
      00B70B 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B70D EA               [12]  699 	mov	a,r2
      00B70E 75 F0 02         [24]  700 	mov	b,#0x02
      00B711 A4               [48]  701 	mul	ab
      00B712 24 6C            [12]  702 	add	a, #_supported_modes
      00B714 F5 82            [12]  703 	mov	dpl,a
      00B716 74 C3            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B718 12 5B D6         [24]  705 	lcall	_ak820_outline_0109
      00B71B F8               [12]  706 	mov	r0,a
      00B71C 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B71E C3               [12]  709 	clr	c
      00B71F EE               [12]  710 	mov	a,r6
      00B720 98               [12]  711 	subb	a,r0
      00B721 EF               [12]  712 	mov	a,r7
      00B722 99               [12]  713 	subb	a,r1
      00B723 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B725 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B728                        717 00162$:
      00B728 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B72A C0 06            [24]  720 	push	ar6
      00B72C C0 07            [24]  721 	push	ar7
      00B72E 88 07            [24]  722 	mov	ar7,r0
      00B730 12 36 75         [24]  723 	lcall	_ak820_outline_0122
      00B733 EF               [12]  724 	mov	a,r7
      00B734 12 74 7F         [24]  725 	lcall	_ak820_outline_0103
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B737 A3               [24]  727 	inc	dptr
      00B738 89 00            [24]  728 	mov	ar0,r1
      00B73A E8               [12]  729 	mov	a,r0
      00B73B F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B73C 1D               [12]  732 	dec	r5
      00B73D 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B73E 74 02            [12]  735 	mov	a,#0x02
      00B740 2B               [12]  736 	add	a, r3
      00B741 FB               [12]  737 	mov	r3,a
      00B742 E4               [12]  738 	clr	a
      00B743 3C               [12]  739 	addc	a, r4
      00B744 FC               [12]  740 	mov	r4,a
      00B745 90 0D B6         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B748 12 3A DE         [24]  742 	lcall	_ak820_outline_0093
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B74B D0 07            [24]  744 	pop	ar7
      00B74D D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B74F                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B74F 0A               [12]  749 	inc	r2
      00B750 80 B6            [24]  750 	sjmp	00110$
      00B752                        751 00127$:
      00B752 90 0D B6         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B755 12 3A DE         [24]  753 	lcall	_ak820_outline_0093
                                    754 ;	quantum/vialrgb.c:55: }
      00B758 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B759                        767 _qmk_id_to_vialrgb_id:
      00B759 12 3A F0         [24]  768 	lcall	_ak820_outline_0107
      00B75C 90 0D B8         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B75F 12 3A F5         [24]  770 	lcall	_ak820_outline_0108
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B762 90 0D B8         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B765 12 3A AF         [24]  773 	lcall	_ak820_outline_0052
      00B768 7D 00            [12]  774 	mov	r5,#0x00
      00B76A                        775 00105$:
      00B76A BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B76D                        777 00130$:
      00B76D 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B76F 12 BB 83         [24]  780 	lcall	_ak820_outline_0047
      00B772 A3               [24]  781 	inc	dptr
      00B773 E4               [12]  782 	clr	a
      00B774 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B775 7A 00            [12]  785 	mov	r2,#0x00
      00B777 B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B77A EA               [12]  787 	mov	a,r2
      00B77B B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B77E 12 36 75         [24]  790 	lcall	_ak820_outline_0122
      00B781 12 BB AF         [24]  791 	lcall	_ak820_outline_0145
      00B784 22               [24]  792 	ret
      00B785                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B785 0D               [12]  795 	inc	r5
      00B786 80 E2            [24]  796 	sjmp	00105$
      00B788                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B788 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B78B 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B78C                        813 _vialrgb_id_to_qmk_id:
      00B78C 12 3A F0         [24]  814 	lcall	_ak820_outline_0107
      00B78F 90 0D BA         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B792 12 3A F5         [24]  816 	lcall	_ak820_outline_0108
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B795 90 0D BA         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B798 12 3A AF         [24]  819 	lcall	_ak820_outline_0052
      00B79B 7D 00            [12]  820 	mov	r5,#0x00
      00B79D                        821 00105$:
      00B79D BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B7A0                        823 00130$:
      00B7A0 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7A2 12 BB 83         [24]  826 	lcall	_ak820_outline_0047
      00B7A5 E4               [12]  827 	clr	a
      00B7A6 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B7A7 7A 00            [12]  830 	mov	r2,#0x00
      00B7A9 B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B7AC EA               [12]  832 	mov	a,r2
      00B7AD B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B7B0 12 36 75         [24]  835 	lcall	_ak820_outline_0122
      00B7B3 A3               [24]  836 	inc	dptr
      00B7B4 12 BB AF         [24]  837 	lcall	_ak820_outline_0145
      00B7B7 22               [24]  838 	ret
      00B7B8                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7B8 0D               [12]  841 	inc	r5
      00B7B9 80 E2            [24]  842 	sjmp	00105$
      00B7BB                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B7BB 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B7BE 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B7BF                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B7BF 12 59 D9         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B7C2 E5 82            [12]  858 	mov	a, dpl
      00B7C4 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B7C6 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B7C9 22               [24]  862 	ret
      00B7CA                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B7CA 12 59 DF         [24]  865 	lcall	_rgb_matrix_get_mode
      00B7CD 7E 00            [12]  866 	mov	r6,#0x00
      00B7CF 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B7D1 E1 59            [12]  869 	ajmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B7D3                        879 _set_mode:
      00B7D3 12 3A F0         [24]  880 	lcall	_ak820_outline_0107
      00B7D6 90 0D BC         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B7D9 12 3A F5         [24]  882 	lcall	_ak820_outline_0108
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B7DC 90 0D BC         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B7DF 12 3A AF         [24]  885 	lcall	_ak820_outline_0052
      00B7E2 90 0D BC         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B7E5 12 72 4F         [24]  887 	lcall	_ak820_outline_0040
      00B7E8 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B7EA 02 5A 2C         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B7ED                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B7ED C0 07            [24]  893 	push	ar7
      00B7EF C0 06            [24]  894 	push	ar6
      00B7F1 12 5A 1B         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B7F4 D0 06            [24]  896 	pop	ar6
      00B7F6 D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B7F8 12 3A FA         [24]  899 	lcall	_ak820_outline_0118
      00B7FB F1 8C            [12]  900 	acall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B7FD 02 5A 35         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B800                        914 _get_matrix_pos_for_led:
      00B800 12 3A F0         [24]  915 	lcall	_ak820_outline_0107
      00B803 90 0D C0         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B806 12 3A F5         [24]  917 	lcall	_ak820_outline_0108
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B809 90 0D C0         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B80C 12 3A AF         [24]  920 	lcall	_ak820_outline_0052
      00B80F EE               [12]  921 	mov	a,r6
      00B810 24 6B            [12]  922 	add	a, #_ak820_rgb_slots
      00B812 F5 82            [12]  923 	mov	dpl,a
      00B814 EF               [12]  924 	mov	a,r7
      00B815 34 BD            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B817 F5 83            [12]  926 	mov	dph,a
      00B819 E4               [12]  927 	clr	a
      00B81A 93               [24]  928 	movc	a,@a+dptr
      00B81B FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B81C 90 0D BE         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B81F 12 3A D8         [24]  932 	lcall	_ak820_outline_0080
      00B822 EF               [12]  933 	mov	a,r7
      00B823 12 5C 0C         [24]  934 	lcall	_ak820_outline_0186
      00B826 12 86 15         [24]  935 	lcall	_ak820_outline_0121
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B829 12 3B 09         [24]  937 	lcall	_ak820_outline_0133
      00B82C A3               [24]  938 	inc	dptr
      00B82D 53 07 07         [24]  939 	anl	ar7,#0x07
      00B830 EF               [12]  940 	mov	a,r7
      00B831 F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B832 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B833                        961 _fast_set_leds:
      00B833 12 3A F0         [24]  962 	lcall	_ak820_outline_0107
      00B836 90 0D C3         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B839 12 3A F5         [24]  964 	lcall	_ak820_outline_0108
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B83C 90 0D C2         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B83F E0               [24]  967 	movx	a,@dptr
      00B840 FF               [12]  968 	mov	r7,a
      00B841 BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B844                        970 00159$:
      00B844 50 01            [24]  971 	jnc	00102$
      00B846 22               [24]  972 	ret
      00B847                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B847 90 0D C3         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B84A 12 3A D8         [24]  976 	lcall	_ak820_outline_0080
      00B84D 12 4A F7         [24]  977 	lcall	_ak820_outline_0077
      00B850 7B 00            [12]  978 	mov	r3,#0x00
      00B852 12 3B 09         [24]  979 	lcall	_ak820_outline_0133
      00B855 A3               [24]  980 	inc	dptr
      00B856 E0               [24]  981 	movx	a,@dptr
      00B857 FA               [12]  982 	mov	r2,a
      00B858 79 00            [12]  983 	mov	r1,#0x00
      00B85A 90 0D C5         [24]  984 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B85D E9               [12]  985 	mov	a,r1
      00B85E 4C               [12]  986 	orl	a,r4
      00B85F F0               [24]  987 	movx	@dptr,a
      00B860 EA               [12]  988 	mov	a,r2
      00B861 4B               [12]  989 	orl	a,r3
      00B862 A3               [24]  990 	inc	dptr
      00B863 F0               [24]  991 	movx	@dptr,a
                                    992 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B864 12 3B 09         [24]  993 	lcall	_ak820_outline_0133
      00B867 A3               [24]  994 	inc	dptr
      00B868 A3               [24]  995 	inc	dptr
      00B869 E0               [24]  996 	movx	a,@dptr
      00B86A 90 0D C7         [24]  997 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B86D F0               [24]  998 	movx	@dptr,a
                                    999 ;	quantum/vialrgb.c:119: length -= 3;
      00B86E EF               [12] 1000 	mov	a,r7
      00B86F 24 FD            [12] 1001 	add	a,#0xfd
      00B871 90 0D C2         [24] 1002 	mov	dptr,#_fast_set_leds_PARM_2
      00B874 F0               [24] 1003 	movx	@dptr,a
                                   1004 ;	quantum/vialrgb.c:120: args += 3;
      00B875 90 0D C3         [24] 1005 	mov	dptr,#_fast_set_leds_args_10000_282
      00B878 74 03            [12] 1006 	mov	a,#0x03
      00B87A 2D               [12] 1007 	add	a, r5
      00B87B F0               [24] 1008 	movx	@dptr,a
      00B87C E4               [12] 1009 	clr	a
      00B87D 3E               [12] 1010 	addc	a, r6
      00B87E A3               [24] 1011 	inc	dptr
      00B87F F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B880 90 0D C7         [24] 1014 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B883 E0               [24] 1015 	movx	a,@dptr
      00B884 FF               [12] 1016 	mov	r7,a
      00B885 75 F0 03         [24] 1017 	mov	b,#0x03
      00B888 A4               [48] 1018 	mul	ab
      00B889 FE               [12] 1019 	mov	r6,a
      00B88A AD F0            [24] 1020 	mov	r5,b
      00B88C 90 0D C2         [24] 1021 	mov	dptr,#_fast_set_leds_PARM_2
      00B88F E0               [24] 1022 	movx	a,@dptr
      00B890 FB               [12] 1023 	mov	r3,a
      00B891 7C 00            [12] 1024 	mov	r4,#0x00
      00B893 C3               [12] 1025 	clr	c
      00B894 EB               [12] 1026 	mov	a,r3
      00B895 9E               [12] 1027 	subb	a,r6
      00B896 EC               [12] 1028 	mov	a,r4
      00B897 9D               [12] 1029 	subb	a,r5
      00B898 40 13            [24] 1030 	jc	00103$
                                   1031 ;	free result
      00B89A 90 0D C5         [24] 1032 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B89D 12 3A D8         [24] 1033 	lcall	_ak820_outline_0080
      00B8A0 8D 03            [24] 1034 	mov	ar3,r5
      00B8A2 8E 04            [24] 1035 	mov	ar4,r6
      00B8A4 C3               [12] 1036 	clr	c
      00B8A5 EB               [12] 1037 	mov	a,r3
      00B8A6 94 52            [12] 1038 	subb	a,#0x52
      00B8A8 EC               [12] 1039 	mov	a,r4
      00B8A9 94 00            [12] 1040 	subb	a,#0x00
      00B8AB 40 01            [24] 1041 	jc	00104$
      00B8AD                       1042 00103$:
      00B8AD 22               [24] 1043 	ret
      00B8AE                       1044 00104$:
                                   1045 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B8AE 74 52            [12] 1046 	mov	a,#0x52
      00B8B0 C3               [12] 1047 	clr	c
      00B8B1 9D               [12] 1048 	subb	a,r5
      00B8B2 FB               [12] 1049 	mov	r3,a
      00B8B3 E4               [12] 1050 	clr	a
      00B8B4 9E               [12] 1051 	subb	a,r6
      00B8B5 FC               [12] 1052 	mov	r4,a
      00B8B6 7A 00            [12] 1053 	mov	r2,#0x00
      00B8B8 C3               [12] 1054 	clr	c
      00B8B9 EB               [12] 1055 	mov	a,r3
      00B8BA 9F               [12] 1056 	subb	a,r7
      00B8BB EC               [12] 1057 	mov	a,r4
      00B8BC 9A               [12] 1058 	subb	a,r2
      00B8BD 50 08            [24] 1059 	jnc	00127$
                                   1060 ;	free result
      00B8BF 90 0D C7         [24] 1061 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8C2 74 52            [12] 1062 	mov	a,#0x52
      00B8C4 C3               [12] 1063 	clr	c
      00B8C5 9D               [12] 1064 	subb	a,r5
      00B8C6 F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B8C7                       1067 00127$:
      00B8C7 90 0D C7         [24] 1068 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8CA E0               [24] 1069 	movx	a,@dptr
      00B8CB FF               [12] 1070 	mov	r7,a
      00B8CC 90 0D C5         [24] 1071 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8CF 12 3A D8         [24] 1072 	lcall	_ak820_outline_0080
      00B8D2 7C 00            [12] 1073 	mov	r4,#0x00
      00B8D4                       1074 00110$:
      00B8D4 C3               [12] 1075 	clr	c
      00B8D5 EC               [12] 1076 	mov	a,r4
      00B8D6 9F               [12] 1077 	subb	a,r7
      00B8D7 40 01            [24] 1078 	jc	00164$
      00B8D9 22               [24] 1079 	ret
      00B8DA                       1080 00164$:
                                   1081 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B8DA C0 07            [24] 1082 	push	ar7
      00B8DC 90 0D DF         [24] 1083 	mov	dptr,#__mulint_PARM_2
      00B8DF 12 45 EC         [24] 1084 	lcall	_ak820_outline_0165
      00B8E2 90 00 03         [24] 1085 	mov	dptr,#0x0003
      00B8E5 C0 07            [24] 1086 	push	ar7
      00B8E7 C0 06            [24] 1087 	push	ar6
      00B8E9 C0 05            [24] 1088 	push	ar5
      00B8EB C0 04            [24] 1089 	push	ar4
      00B8ED B1 1B            [12] 1090 	acall	__mulint
      00B8EF AA 82            [24] 1091 	mov	r2, dpl
      00B8F1 AB 83            [24] 1092 	mov	r3, dph
      00B8F3 D0 04            [24] 1093 	pop	ar4
      00B8F5 D0 05            [24] 1094 	pop	ar5
      00B8F7 D0 06            [24] 1095 	pop	ar6
      00B8F9 D0 07            [24] 1096 	pop	ar7
      00B8FB 0D               [12] 1097 	inc	r5
      00B8FC BD 00 01         [24] 1098 	cjne	r5,#0x00,00165$
      00B8FF 0E               [12] 1099 	inc	r6
      00B900                       1100 00165$:
      00B900 EA               [12] 1101 	mov	a,r2
      00B901 24 BF            [12] 1102 	add	a, #_g_direct_mode_colors
      00B903 FA               [12] 1103 	mov	r2,a
      00B904 EB               [12] 1104 	mov	a,r3
      00B905 34 0C            [12] 1105 	addc	a, #(_g_direct_mode_colors >> 8)
      00B907 FB               [12] 1106 	mov	r3,a
                                   1107 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B908 8A 4D            [24] 1108 	mov	_fast_set_leds_sloc0_1_0,r2
      00B90A 8B 4E            [24] 1109 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B90C 12 BB 95         [24] 1110 	lcall	_ak820_outline_0085
      00B90F F8               [12] 1111 	mov	r0,a
      00B910 12 BB A3         [24] 1112 	lcall	_ak820_outline_0106
      00B913 85 4D 82         [24] 1113 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B916 85 4E 83         [24] 1114 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B919 E8               [12] 1115 	mov	a,r0
      00B91A F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B91B 74 01            [12] 1118 	mov	a,#0x01
      00B91D 2A               [12] 1119 	add	a, r2
      00B91E F5 4D            [12] 1120 	mov	_fast_set_leds_sloc0_1_0,a
      00B920 E4               [12] 1121 	clr	a
      00B921 3B               [12] 1122 	addc	a, r3
      00B922 F5 4E            [12] 1123 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B924 90 0D C3         [24] 1124 	mov	dptr,#_fast_set_leds_args_10000_282
      00B927 E0               [24] 1125 	movx	a,@dptr
      00B928 F8               [12] 1126 	mov	r0,a
      00B929 A3               [24] 1127 	inc	dptr
      00B92A E0               [24] 1128 	movx	a,@dptr
      00B92B FF               [12] 1129 	mov	r7,a
      00B92C 88 82            [24] 1130 	mov	dpl,r0
      00B92E 8F 83            [24] 1131 	mov	dph,r7
      00B930 E0               [24] 1132 	movx	a,@dptr
      00B931 F9               [12] 1133 	mov	r1,a
      00B932 90 0D C3         [24] 1134 	mov	dptr,#_fast_set_leds_args_10000_282
      00B935 74 01            [12] 1135 	mov	a,#0x01
      00B937 28               [12] 1136 	add	a, r0
      00B938 F0               [24] 1137 	movx	@dptr,a
      00B939 E4               [12] 1138 	clr	a
      00B93A 3F               [12] 1139 	addc	a, r7
      00B93B A3               [24] 1140 	inc	dptr
      00B93C F0               [24] 1141 	movx	@dptr,a
      00B93D 85 4D 82         [24] 1142 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B940 85 4E 83         [24] 1143 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B943 E9               [12] 1144 	mov	a,r1
      00B944 F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B945 12 BB 95         [24] 1147 	lcall	_ak820_outline_0085
      00B948 F5 4D            [12] 1148 	mov	_fast_set_leds_sloc0_1_0,a
      00B94A 12 BB A3         [24] 1149 	lcall	_ak820_outline_0106
                                   1150 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B94D 74 02            [12] 1151 	mov	a,#0x02
      00B94F 2A               [12] 1152 	add	a, r2
      00B950 F5 4F            [12] 1153 	mov	_fast_set_leds_sloc1_1_0,a
      00B952 E4               [12] 1154 	clr	a
      00B953 3B               [12] 1155 	addc	a, r3
      00B954 F5 50            [12] 1156 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B956 C3               [12] 1157 	clr	c
      00B957 74 A0            [12] 1158 	mov	a,#0xa0
      00B959 95 4D            [12] 1159 	subb	a,_fast_set_leds_sloc0_1_0
      00B95B D0 07            [24] 1160 	pop	ar7
      00B95D 50 04            [24] 1161 	jnc	00114$
                                   1162 ;	free result
      00B95F 7B A0            [12] 1163 	mov	r3,#0xa0
      00B961 80 04            [24] 1164 	sjmp	00115$
      00B963                       1165 00114$:
      00B963 AA 4D            [24] 1166 	mov	r2,_fast_set_leds_sloc0_1_0
      00B965 8A 03            [24] 1167 	mov	ar3,r2
      00B967                       1168 00115$:
      00B967 85 4F 82         [24] 1169 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B96A 85 50 83         [24] 1170 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B96D EB               [12] 1171 	mov	a,r3
      00B96E F0               [24] 1172 	movx	@dptr,a
                                   1173 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B96F 0C               [12] 1174 	inc	r4
                                   1175 ;	quantum/vialrgb.c:133: }
      00B970 01 D4            [24] 1176 	ajmp	00110$
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1179 ;------------------------------------------------------------
                                   1180 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1181 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1182 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1183 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1184 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1185 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1186 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1187 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function vialrgb_get_value
                                   1192 ;	-----------------------------------------
      00B972                       1193 _vialrgb_get_value:
      00B972 12 45 7B         [24] 1194 	lcall	_ak820_outline_0036
      00B975 90 0D C9         [24] 1195 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B978 12 3A 8D         [24] 1196 	lcall	_ak820_outline_0016
                                   1197 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B97B 90 0D C8         [24] 1198 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B97E E0               [24] 1199 	movx	a,@dptr
      00B97F FF               [12] 1200 	mov	r7,a
      00B980 BF 20 02         [24] 1201 	cjne	r7,#0x20,00162$
      00B983 80 01            [24] 1202 	sjmp	00102$
      00B985                       1203 00162$:
      00B985 22               [24] 1204 	ret
      00B986                       1205 00102$:
                                   1206 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B986 90 0D C9         [24] 1207 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B989 12 BB 6F         [24] 1208 	lcall	_ak820_outline_0046
                                   1209 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1210 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B98C BA 40 02         [24] 1211 	cjne	r2,#0x40,00163$
      00B98F 80 15            [24] 1212 	sjmp	00103$
      00B991                       1213 00163$:
      00B991 BA 41 02         [24] 1214 	cjne	r2,#0x41,00164$
      00B994 80 23            [24] 1215 	sjmp	00104$
      00B996                       1216 00164$:
      00B996 BA 42 02         [24] 1217 	cjne	r2,#0x42,00165$
      00B999 41 4A            [12] 1218 	ajmp	00105$
      00B99B                       1219 00165$:
      00B99B BA 43 02         [24] 1220 	cjne	r2,#0x43,00166$
      00B99E 41 56            [12] 1221 	ajmp	00106$
      00B9A0                       1222 00166$:
      00B9A0 BA 44 02         [24] 1223 	cjne	r2,#0x44,00167$
      00B9A3 41 62            [12] 1224 	ajmp	00107$
      00B9A5                       1225 00167$:
      00B9A5 22               [24] 1226 	ret
                                   1227 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B9A6                       1228 00103$:
                                   1229 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B9A6 12 36 75         [24] 1230 	lcall	_ak820_outline_0122
      00B9A9 74 01            [12] 1231 	mov	a,#0x01
      00B9AB F0               [24] 1232 	movx	@dptr,a
                                   1233 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B9AC 12 BB 67         [24] 1234 	lcall	_ak820_outline_0039
      00B9AF E4               [12] 1235 	clr	a
      00B9B0 F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B9B1 12 BB 67         [24] 1238 	lcall	_ak820_outline_0039
      00B9B4 A3               [24] 1239 	inc	dptr
      00B9B5 74 A0            [12] 1240 	mov	a,#0xa0
      00B9B7 F0               [24] 1241 	movx	@dptr,a
                                   1242 ;	quantum/vialrgb.c:147: break;
      00B9B8 22               [24] 1243 	ret
                                   1244 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B9B9                       1245 00104$:
                                   1246 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B9B9 C0 06            [24] 1247 	push	ar6
      00B9BB C0 05            [24] 1248 	push	ar5
      00B9BD C0 04            [24] 1249 	push	ar4
      00B9BF C0 03            [24] 1250 	push	ar3
?ASlink-Warning-2K Page relocation error
      00B9C1 F1 BF            [12] 1251 	acall	_get_mode
      00B9C3 A9 82            [24] 1252 	mov	r1, dpl
      00B9C5 AA 83            [24] 1253 	mov	r2, dph
      00B9C7 D0 03            [24] 1254 	pop	ar3
      00B9C9 D0 04            [24] 1255 	pop	ar4
      00B9CB D0 05            [24] 1256 	pop	ar5
      00B9CD D0 06            [24] 1257 	pop	ar6
                                   1258 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B9CF 89 00            [24] 1259 	mov	ar0,r1
      00B9D1 12 36 75         [24] 1260 	lcall	_ak820_outline_0122
      00B9D4 E8               [12] 1261 	mov	a,r0
      00B9D5 F0               [24] 1262 	movx	@dptr,a
                                   1263 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B9D6 12 BB 67         [24] 1264 	lcall	_ak820_outline_0039
      00B9D9 8A 01            [24] 1265 	mov	ar1,r2
      00B9DB E9               [12] 1266 	mov	a,r1
      00B9DC F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B9DD 74 04            [12] 1269 	mov	a,#0x04
      00B9DF 12 93 49         [24] 1270 	lcall	_ak820_outline_0134
      00B9E2 C0 06            [24] 1271 	push	ar6
      00B9E4 C0 05            [24] 1272 	push	ar5
      00B9E6 C0 02            [24] 1273 	push	ar2
      00B9E8 C0 01            [24] 1274 	push	ar1
      00B9EA 12 59 FA         [24] 1275 	lcall	_rgb_matrix_get_speed
      00B9ED A8 82            [24] 1276 	mov	r0, dpl
      00B9EF D0 01            [24] 1277 	pop	ar1
      00B9F1 D0 02            [24] 1278 	pop	ar2
      00B9F3 D0 05            [24] 1279 	pop	ar5
      00B9F5 D0 06            [24] 1280 	pop	ar6
      00B9F7 12 85 EE         [24] 1281 	lcall	_ak820_outline_0064
                                   1282 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B9FA 74 05            [12] 1283 	mov	a,#0x05
      00B9FC 12 93 49         [24] 1284 	lcall	_ak820_outline_0134
      00B9FF C0 06            [24] 1285 	push	ar6
      00BA01 C0 05            [24] 1286 	push	ar5
      00BA03 C0 02            [24] 1287 	push	ar2
      00BA05 C0 01            [24] 1288 	push	ar1
      00BA07 12 59 E5         [24] 1289 	lcall	_rgb_matrix_get_hue
      00BA0A A8 82            [24] 1290 	mov	r0, dpl
      00BA0C D0 01            [24] 1291 	pop	ar1
      00BA0E D0 02            [24] 1292 	pop	ar2
      00BA10 D0 05            [24] 1293 	pop	ar5
      00BA12 D0 06            [24] 1294 	pop	ar6
      00BA14 12 85 EE         [24] 1295 	lcall	_ak820_outline_0064
                                   1296 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BA17 74 06            [12] 1297 	mov	a,#0x06
      00BA19 12 93 49         [24] 1298 	lcall	_ak820_outline_0134
      00BA1C C0 06            [24] 1299 	push	ar6
      00BA1E C0 05            [24] 1300 	push	ar5
      00BA20 C0 02            [24] 1301 	push	ar2
      00BA22 C0 01            [24] 1302 	push	ar1
      00BA24 12 59 EC         [24] 1303 	lcall	_rgb_matrix_get_sat
      00BA27 A8 82            [24] 1304 	mov	r0, dpl
      00BA29 D0 01            [24] 1305 	pop	ar1
      00BA2B D0 02            [24] 1306 	pop	ar2
      00BA2D D0 05            [24] 1307 	pop	ar5
      00BA2F D0 06            [24] 1308 	pop	ar6
      00BA31 12 85 EE         [24] 1309 	lcall	_ak820_outline_0064
                                   1310 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BA34 74 07            [12] 1311 	mov	a,#0x07
      00BA36 12 93 49         [24] 1312 	lcall	_ak820_outline_0134
      00BA39 C0 02            [24] 1313 	push	ar2
      00BA3B C0 01            [24] 1314 	push	ar1
      00BA3D 12 59 F3         [24] 1315 	lcall	_rgb_matrix_get_val
      00BA40 A8 82            [24] 1316 	mov	r0, dpl
      00BA42 D0 01            [24] 1317 	pop	ar1
      00BA44 D0 02            [24] 1318 	pop	ar2
      00BA46 12 85 EE         [24] 1319 	lcall	_ak820_outline_0064
                                   1320 ;	quantum/vialrgb.c:156: break;
      00BA49 22               [24] 1321 	ret
                                   1322 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BA4A                       1323 00105$:
                                   1324 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BA4A EF               [12] 1325 	mov	a,r7
      00BA4B 24 FE            [12] 1326 	add	a,#0xfe
      00BA4D 90 0D B5         [24] 1327 	mov	dptr,#_get_supported_PARM_2
      00BA50 12 74 7F         [24] 1328 	lcall	_ak820_outline_0103
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BA53 02 B6 C7         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BA56                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BA56 12 36 75         [24] 1334 	lcall	_ak820_outline_0122
      00BA59 74 52            [12] 1335 	mov	a,#0x52
      00BA5B F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BA5C 12 BB 67         [24] 1338 	lcall	_ak820_outline_0039
      00BA5F E4               [12] 1339 	clr	a
      00BA60 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BA61 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BA62                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BA62 12 36 75         [24] 1346 	lcall	_ak820_outline_0122
      00BA65 E0               [24] 1347 	movx	a,@dptr
      00BA66 FF               [12] 1348 	mov	r7,a
      00BA67 7A 00            [12] 1349 	mov	r2,#0x00
      00BA69 74 03            [12] 1350 	mov	a,#0x03
      00BA6B 2D               [12] 1351 	add	a, r5
      00BA6C F8               [12] 1352 	mov	r0,a
      00BA6D E4               [12] 1353 	clr	a
      00BA6E 3E               [12] 1354 	addc	a, r6
      00BA6F F9               [12] 1355 	mov	r1,a
      00BA70 C0 03            [24] 1356 	push	ar3
      00BA72 C0 04            [24] 1357 	push	ar4
      00BA74 12 3B 24         [24] 1358 	lcall	_ak820_outline_0161
      00BA77 E0               [24] 1359 	movx	a,@dptr
      00BA78 FB               [12] 1360 	mov	r3,a
      00BA79 E4               [12] 1361 	clr	a
      00BA7A 4F               [12] 1362 	orl	a,r7
      00BA7B F5 51            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BA7D EB               [12] 1364 	mov	a,r3
      00BA7E 4A               [12] 1365 	orl	a,r2
      00BA7F F5 52            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BA81 AC 51            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BA83 AF 52            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BA85 C3               [12] 1370 	clr	c
      00BA86 EC               [12] 1371 	mov	a,r4
      00BA87 94 52            [12] 1372 	subb	a,#0x52
      00BA89 EF               [12] 1373 	mov	a,r7
      00BA8A 94 00            [12] 1374 	subb	a,#0x00
      00BA8C D0 04            [24] 1375 	pop	ar4
      00BA8E D0 03            [24] 1376 	pop	ar3
      00BA90 40 01            [24] 1377 	jc	00109$
      00BA92 22               [24] 1378 	ret
      00BA93                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BA93 E5 51            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BA95 25 51            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BA97 FA               [12] 1383 	mov	r2,a
      00BA98 E5 52            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BA9A 33               [12] 1385 	rlc	a
      00BA9B FF               [12] 1386 	mov	r7,a
      00BA9C EA               [12] 1387 	mov	a,r2
      00BA9D 24 25            [12] 1388 	add	a, #_ak820_led_points
      00BA9F F5 53            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BAA1 EF               [12] 1390 	mov	a,r7
      00BAA2 34 C0            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BAA4 F5 54            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BAA6 85 53 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BAA9 85 54 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BAAC E4               [12] 1395 	clr	a
      00BAAD 93               [24] 1396 	movc	a,@a+dptr
      00BAAE 12 36 75         [24] 1397 	lcall	_ak820_outline_0122
      00BAB1 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BAB2 85 53 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BAB5 85 54 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BAB8 A3               [24] 1402 	inc	dptr
      00BAB9 E4               [12] 1403 	clr	a
      00BABA 93               [24] 1404 	movc	a,@a+dptr
      00BABB 12 3B 24         [24] 1405 	lcall	_ak820_outline_0161
      00BABE F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BABF 12 BB 67         [24] 1408 	lcall	_ak820_outline_0039
      00BAC2 A3               [24] 1409 	inc	dptr
      00BAC3 74 04            [12] 1410 	mov	a,#0x04
      00BAC5 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BAC6 90 0D BE         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BAC9 04               [12] 1414 	inc	a
      00BACA 2D               [12] 1415 	add	a, r5
      00BACB F0               [24] 1416 	movx	@dptr,a
      00BACC E4               [12] 1417 	clr	a
      00BACD 3E               [12] 1418 	addc	a, r6
      00BACE A3               [24] 1419 	inc	dptr
      00BACF F0               [24] 1420 	movx	@dptr,a
      00BAD0 85 51 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BAD3 85 52 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BAD6 01 00            [24] 1425 	ajmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BAD8                       1440 _vialrgb_set_value:
      00BAD8 12 45 7B         [24] 1441 	lcall	_ak820_outline_0036
      00BADB 90 0D CD         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BADE 12 3A 8D         [24] 1443 	lcall	_ak820_outline_0016
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BAE1 90 0D CC         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BAE4 E0               [24] 1446 	movx	a,@dptr
      00BAE5 FF               [12] 1447 	mov	r7,a
      00BAE6 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BAE9 80 01            [24] 1449 	sjmp	00102$
      00BAEB                       1450 00129$:
      00BAEB 22               [24] 1451 	ret
      00BAEC                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BAEC 90 0D CD         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BAEF 12 BB 6F         [24] 1455 	lcall	_ak820_outline_0046
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BAF2 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BAF5 80 06            [24] 1459 	sjmp	00103$
      00BAF7                       1460 00130$:
      00BAF7 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BAFA 80 5D            [24] 1462 	sjmp	00104$
      00BAFC                       1463 00131$:
      00BAFC 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BAFD                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BAFD 12 36 75         [24] 1468 	lcall	_ak820_outline_0122
      00BB00 E0               [24] 1469 	movx	a,@dptr
      00BB01 FA               [12] 1470 	mov	r2,a
      00BB02 12 BB 67         [24] 1471 	lcall	_ak820_outline_0039
      00BB05 E0               [24] 1472 	movx	a,@dptr
      00BB06 F8               [12] 1473 	mov	r0,a
      00BB07 79 00            [12] 1474 	mov	r1,#0x00
      00BB09 88 56            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BB0B 89 55            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BB0D 8A 01            [24] 1477 	mov	ar1,r2
      00BB0F 7A 00            [12] 1478 	mov	r2,#0x00
      00BB11 E5 56            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BB13 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BB15 12 45 F2         [24] 1482 	lcall	_ak820_outline_0188
      00BB18 C0 06            [24] 1483 	push	ar6
      00BB1A C0 05            [24] 1484 	push	ar5
?ASlink-Warning-2K Page relocation error
      00BB1C F1 D3            [24] 1485 	acall	_set_mode
      00BB1E D0 05            [24] 1486 	pop	ar5
      00BB20 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BB22 12 BB 67         [24] 1489 	lcall	_ak820_outline_0039
      00BB25 A3               [24] 1490 	inc	dptr
      00BB26 E0               [24] 1491 	movx	a,@dptr
      00BB27 F5 82            [12] 1492 	mov	dpl,a
      00BB29 C0 06            [24] 1493 	push	ar6
      00BB2B C0 05            [24] 1494 	push	ar5
      00BB2D 12 5A C6         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BB30 D0 05            [24] 1496 	pop	ar5
      00BB32 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BB34 12 BB 67         [24] 1499 	lcall	_ak820_outline_0039
      00BB37 A3               [24] 1500 	inc	dptr
      00BB38 A3               [24] 1501 	inc	dptr
      00BB39 E0               [24] 1502 	movx	a,@dptr
      00BB3A F9               [12] 1503 	mov	r1,a
      00BB3B 7A 00            [12] 1504 	mov	r2,#0x00
      00BB3D 74 06            [12] 1505 	mov	a,#0x06
      00BB3F 12 BB B9         [24] 1506 	lcall	_ak820_outline_0172
      00BB42 F8               [12] 1507 	mov	r0,a
      00BB43 74 07            [12] 1508 	mov	a,#0x07
      00BB45 12 BB B9         [24] 1509 	lcall	_ak820_outline_0172
      00BB48 FE               [12] 1510 	mov	r6,a
      00BB49 90 07 56         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BB4C E8               [12] 1512 	mov	a,r0
      00BB4D F0               [24] 1513 	movx	@dptr,a
      00BB4E 90 07 57         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BB51 EE               [12] 1515 	mov	a,r6
      00BB52 F0               [24] 1516 	movx	@dptr,a
      00BB53 12 45 F2         [24] 1517 	lcall	_ak820_outline_0188
                                   1518 ;	quantum/vialrgb.c:202: break;
                                   1519 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BB56 02 5A 97         [24] 1520 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BB59                       1521 00104$:
                                   1522 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BB59 EF               [12] 1523 	mov	a,r7
      00BB5A 24 FE            [12] 1524 	add	a,#0xfe
      00BB5C 90 0D C2         [24] 1525 	mov	dptr,#_fast_set_leds_PARM_2
      00BB5F 12 74 7F         [24] 1526 	lcall	_ak820_outline_0103
                                   1527 ;	quantum/vialrgb.c:210: }
                                   1528 ;	quantum/vialrgb.c:211: }
      00BB62 01 33            [24] 1529 	ajmp	_fast_set_leds
                                   1530 ;------------------------------------------------------------
                                   1531 ;Allocation info for local variables in function 'vialrgb_save'
                                   1532 ;------------------------------------------------------------
                                   1533 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1534 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1535 ;------------------------------------------------------------
                                   1536 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1537 ;	-----------------------------------------
                                   1538 ;	 function vialrgb_save
                                   1539 ;	-----------------------------------------
      00BB64                       1540 _vialrgb_save:
                                   1541 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1542 ;	quantum/vialrgb.c:218: }
      00BB64 02 55 1B         [24] 1543 	ljmp	_eeconfig_update_rgb_matrix
                                   1544 	.area CSEG    (CODE)
                                   1545 	.area CONST   (CODE)
                                   1546 	.area CONST   (CODE)
      00C36C                       1547 _supported_modes:
      00C36C 00                    1548 	.db #0x00	; 0
      00C36D 00                    1549 	.db #0x00	; 0
      00C36E 01                    1550 	.db #0x01	; 1
      00C36F 05                    1551 	.db #0x05	; 5
      00C370 02                    1552 	.db #0x02	; 2
      00C371 01                    1553 	.db #0x01	; 1
      00C372 06                    1554 	.db #0x06	; 6
      00C373 02                    1555 	.db #0x02	; 2
      00C374 0D                    1556 	.db #0x0d	; 13
      00C375 03                    1557 	.db #0x03	; 3
      00C376 0E                    1558 	.db #0x0e	; 14
      00C377 04                    1559 	.db #0x04	; 4
      00C378 1F                    1560 	.db #0x1f	; 31
      00C379 06                    1561 	.db #0x06	; 6
                                   1562 	.area CSEG    (CODE)
                                   1563 	.area XINIT   (CODE)
                                   1564 	.area CABS    (ABS,CODE)
                                   1565 
                                   1566 ; Experimental exact instruction outlining.
                                   1567 	.globl _ak820_outline_0005
                                   1568 	.globl _ak820_outline_0016
                                   1569 	.globl _ak820_outline_0022
                                   1570 	.globl _ak820_outline_0036
                                   1571 	.globl _ak820_outline_0039
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0046
                                   1574 	.globl _ak820_outline_0047
                                   1575 	.globl _ak820_outline_0052
                                   1576 	.globl _ak820_outline_0064
                                   1577 	.globl _ak820_outline_0077
                                   1578 	.globl _ak820_outline_0080
                                   1579 	.globl _ak820_outline_0085
                                   1580 	.globl _ak820_outline_0093
                                   1581 	.globl _ak820_outline_0103
                                   1582 	.globl _ak820_outline_0106
                                   1583 	.globl _ak820_outline_0107
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0109
                                   1586 	.globl _ak820_outline_0118
                                   1587 	.globl _ak820_outline_0121
                                   1588 	.globl _ak820_outline_0122
                                   1589 	.globl _ak820_outline_0133
                                   1590 	.globl _ak820_outline_0134
                                   1591 	.globl _ak820_outline_0141
                                   1592 	.globl _ak820_outline_0143
                                   1593 	.globl _ak820_outline_0145
                                   1594 	.globl _ak820_outline_0161
                                   1595 	.globl _ak820_outline_0165
                                   1596 	.globl _ak820_outline_0172
                                   1597 	.globl _ak820_outline_0186
                                   1598 	.globl _ak820_outline_0188
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0039
      00BB67                       1602 _ak820_outline_0039:
      00BB67 8D 82            [24] 1603 	mov	dpl,r5
      00BB69 8E 83            [24] 1604 	mov	dph,r6
      00BB6B A3               [24] 1605 	inc	dptr
      00BB6C A3               [24] 1606 	inc	dptr
      00BB6D A3               [24] 1607 	inc	dptr
      00BB6E 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0046
      00BB6F                       1612 _ak820_outline_0046:
      00BB6F E0               [24] 1613 	movx	a,@dptr
      00BB70 FD               [12] 1614 	mov	r5,a
      00BB71 A3               [24] 1615 	inc	dptr
      00BB72 E0               [24] 1616 	movx	a,@dptr
      00BB73 FE               [12] 1617 	mov	r6,a
      00BB74 74 02            [12] 1618 	mov	a,#0x02
      00BB76 2D               [12] 1619 	add	a,r5
      00BB77 FB               [12] 1620 	mov	r3,a
      00BB78 E4               [12] 1621 	clr	a
      00BB79 3E               [12] 1622 	addc	a,r6
      00BB7A FC               [12] 1623 	mov	r4,a
      00BB7B 8D 82            [24] 1624 	mov	dpl,r5
      00BB7D 8E 83            [24] 1625 	mov	dph,r6
      00BB7F A3               [24] 1626 	inc	dptr
      00BB80 E0               [24] 1627 	movx	a,@dptr
      00BB81 FA               [12] 1628 	mov	r2,a
      00BB82 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0047
      00BB83                       1633 _ak820_outline_0047:
      00BB83 ED               [12] 1634 	mov	a,r5
      00BB84 75 F0 02         [24] 1635 	mov	b,#0x02
      00BB87 A4               [48] 1636 	mul	ab
      00BB88 24 6C            [12] 1637 	add	a,#_supported_modes
      00BB8A FB               [12] 1638 	mov	r3,a
      00BB8B 74 C3            [12] 1639 	mov	a,#(_supported_modes>>8)
      00BB8D 35 F0            [12] 1640 	addc	a,b
      00BB8F FC               [12] 1641 	mov	r4,a
      00BB90 8B 82            [24] 1642 	mov	dpl,r3
      00BB92 8C 83            [24] 1643 	mov	dph,r4
      00BB94 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0085
      00BB95                       1648 _ak820_outline_0085:
      00BB95 90 0D C3         [24] 1649 	mov	dptr,#_fast_set_leds_args_10000_282
      00BB98 E0               [24] 1650 	movx	a,@dptr
      00BB99 F9               [12] 1651 	mov	r1,a
      00BB9A A3               [24] 1652 	inc	dptr
      00BB9B E0               [24] 1653 	movx	a,@dptr
      00BB9C FF               [12] 1654 	mov	r7,a
      00BB9D 89 82            [24] 1655 	mov	dpl,r1
      00BB9F 8F 83            [24] 1656 	mov	dph,r7
      00BBA1 E0               [24] 1657 	movx	a,@dptr
      00BBA2 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0106
      00BBA3                       1662 _ak820_outline_0106:
      00BBA3 90 0D C3         [24] 1663 	mov	dptr,#_fast_set_leds_args_10000_282
      00BBA6 74 01            [12] 1664 	mov	a,#0x01
      00BBA8 29               [12] 1665 	add	a,r1
      00BBA9 F0               [24] 1666 	movx	@dptr,a
      00BBAA E4               [12] 1667 	clr	a
      00BBAB 3F               [12] 1668 	addc	a,r7
      00BBAC A3               [24] 1669 	inc	dptr
      00BBAD F0               [24] 1670 	movx	@dptr,a
      00BBAE 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0145
      00BBAF                       1675 _ak820_outline_0145:
      00BBAF E4               [12] 1676 	clr	a
      00BBB0 93               [24] 1677 	movc	a,@a+dptr
      00BBB1 FC               [12] 1678 	mov	r4,a
      00BBB2 7B 00            [12] 1679 	mov	r3,#0x00
      00BBB4 8C 82            [24] 1680 	mov	dpl,r4
      00BBB6 8B 83            [24] 1681 	mov	dph,r3
      00BBB8 22               [24] 1682 	ret
                                   1683 
                                   1684 	.area CSEG (CODE)
                                   1685 ; function ak820_outline_0172
      00BBB9                       1686 _ak820_outline_0172:
      00BBB9 2D               [12] 1687 	add	a,r5
      00BBBA F5 82            [12] 1688 	mov	dpl,a
      00BBBC E4               [12] 1689 	clr	a
      00BBBD 3E               [12] 1690 	addc	a,r6
      00BBBE F5 83            [12] 1691 	mov	dph,a
      00BBC0 E0               [24] 1692 	movx	a,@dptr
      00BBC1 22               [24] 1693 	ret
