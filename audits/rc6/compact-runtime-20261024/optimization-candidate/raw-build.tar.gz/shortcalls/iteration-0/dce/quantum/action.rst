                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _repeat_key_cancel
                                     27 	.globl _clear_owned_usages
                                     28 	.globl _owned_usage_key
                                     29 	.globl _clear_owned_keys
                                     30 	.globl _del_owned_key
                                     31 	.globl _add_owned_key
                                     32 	.globl _clear_owned_mods
                                     33 	.globl _del_owned_weak_mods
                                     34 	.globl _add_owned_weak_mods
                                     35 	.globl _del_owned_mods
                                     36 	.globl _add_owned_mods
                                     37 	.globl _clear_weak_mods
                                     38 	.globl _clear_mods
                                     39 	.globl _send_keyboard_report
                                     40 	.globl _layer_hold_clear
                                     41 	.globl _layer_hold_off
                                     42 	.globl _layer_hold_on
                                     43 	.globl _ak820_resolve_key
                                     44 	.globl _layer_xor
                                     45 	.globl _layer_and
                                     46 	.globl _layer_or
                                     47 	.globl _layer_off
                                     48 	.globl _layer_on
                                     49 	.globl _layer_move
                                     50 	.globl _layer_clear
                                     51 	.globl _layer_state_set
                                     52 	.globl _default_layer_xor
                                     53 	.globl _default_layer_and
                                     54 	.globl _default_layer_or
                                     55 	.globl _default_layer_set
                                     56 	.globl _post_process_record_quantum
                                     57 	.globl _process_record_quantum
                                     58 	.globl _action_for_keycode
                                     59 	.globl _mousekey_send
                                     60 	.globl _mousekey_clear
                                     61 	.globl _mousekey_off
                                     62 	.globl _mousekey_on
                                     63 	.globl _mDelaymS
                                     64 	.globl _host_consumer_send
                                     65 	.globl _host_system_send
                                     66 	.globl _host_keyboard_leds
                                     67 	.globl _led_set
                                     68 	.globl _clear_keys_from_report
                                     69 	.globl ___memcpy
                                     70 	.globl _ADC_START
                                     71 	.globl _S0_R_FIFO
                                     72 	.globl _S0_T_FIFO
                                     73 	.globl _S0_FREE
                                     74 	.globl _S0_IF_BYTE
                                     75 	.globl _S0_IF_FIRST
                                     76 	.globl _S0_IF_OV
                                     77 	.globl _S0_FST_ACT
                                     78 	.globl _CP_RL2
                                     79 	.globl _C_T2
                                     80 	.globl _TR2
                                     81 	.globl _EXEN2
                                     82 	.globl _TCLK
                                     83 	.globl _RCLK
                                     84 	.globl _EXF2
                                     85 	.globl _CAP1F
                                     86 	.globl _TF2
                                     87 	.globl _RI
                                     88 	.globl _TI
                                     89 	.globl _RB8
                                     90 	.globl _TB8
                                     91 	.globl _REN
                                     92 	.globl _SM2
                                     93 	.globl _SM1
                                     94 	.globl _SM0
                                     95 	.globl _IT0
                                     96 	.globl _IE0
                                     97 	.globl _IT1
                                     98 	.globl _IE1
                                     99 	.globl _TR0
                                    100 	.globl _TF0
                                    101 	.globl _TR1
                                    102 	.globl _TF1
                                    103 	.globl _P4_0
                                    104 	.globl _P4_1
                                    105 	.globl _P4_2
                                    106 	.globl _P4_3
                                    107 	.globl _P4_4
                                    108 	.globl _P4_5
                                    109 	.globl _P4_6
                                    110 	.globl _RXD
                                    111 	.globl _TXD
                                    112 	.globl _INT0
                                    113 	.globl _INT1
                                    114 	.globl _T0
                                    115 	.globl _T1
                                    116 	.globl _MOSI1
                                    117 	.globl _MISO1
                                    118 	.globl _SCK1
                                    119 	.globl _P3_0
                                    120 	.globl _P3_1
                                    121 	.globl _P3_2
                                    122 	.globl _P3_3
                                    123 	.globl _P3_4
                                    124 	.globl _P3_5
                                    125 	.globl _P3_6
                                    126 	.globl _P3_7
                                    127 	.globl _CAP1_
                                    128 	.globl _T2_
                                    129 	.globl _CAP2_
                                    130 	.globl _T2EX_
                                    131 	.globl _RXD1
                                    132 	.globl _TXD1
                                    133 	.globl _P2_0
                                    134 	.globl _P2_1
                                    135 	.globl _P2_2
                                    136 	.globl _P2_3
                                    137 	.globl _P2_4
                                    138 	.globl _P2_5
                                    139 	.globl _P2_6
                                    140 	.globl _P2_7
                                    141 	.globl _AIN0
                                    142 	.globl _AIN1
                                    143 	.globl _AIN2
                                    144 	.globl _AIN3
                                    145 	.globl _AIN4
                                    146 	.globl _AIN5
                                    147 	.globl _AIN6
                                    148 	.globl _AIN7
                                    149 	.globl _CAP1
                                    150 	.globl _T2
                                    151 	.globl _CAP2
                                    152 	.globl _T2EX
                                    153 	.globl _INT0_
                                    154 	.globl _SCS
                                    155 	.globl _MOSI
                                    156 	.globl _MISO
                                    157 	.globl _SCK
                                    158 	.globl _RXD1_
                                    159 	.globl _TXD1_
                                    160 	.globl _P1_0
                                    161 	.globl _P1_1
                                    162 	.globl _P1_2
                                    163 	.globl _P1_3
                                    164 	.globl _P1_4
                                    165 	.globl _P1_5
                                    166 	.globl _P1_6
                                    167 	.globl _P1_7
                                    168 	.globl _AIN8
                                    169 	.globl _AIN9
                                    170 	.globl _AIN10
                                    171 	.globl _AIN11
                                    172 	.globl _AIN12
                                    173 	.globl _AIN13
                                    174 	.globl _RXD_
                                    175 	.globl _TXD_
                                    176 	.globl _SCL0
                                    177 	.globl _SDA0
                                    178 	.globl _P0_0
                                    179 	.globl _P0_1
                                    180 	.globl _P0_2
                                    181 	.globl _P0_3
                                    182 	.globl _P0_4
                                    183 	.globl _P0_5
                                    184 	.globl _P0_6
                                    185 	.globl _P0_7
                                    186 	.globl _IE_SPI0
                                    187 	.globl _IE_USB
                                    188 	.globl _IE_ADC
                                    189 	.globl _IE_UART1
                                    190 	.globl _IE_PWM_I2C
                                    191 	.globl _IE_GPIO
                                    192 	.globl _IE_WDOG
                                    193 	.globl _PX0
                                    194 	.globl _PT0
                                    195 	.globl _PX1
                                    196 	.globl _PT1
                                    197 	.globl _PS
                                    198 	.globl _PT2
                                    199 	.globl _PL_FLAG
                                    200 	.globl _PH_FLAG
                                    201 	.globl _EX0
                                    202 	.globl _ET0
                                    203 	.globl _EX1
                                    204 	.globl _ET1
                                    205 	.globl _ES
                                    206 	.globl _ET2
                                    207 	.globl _E_DIS
                                    208 	.globl _EA
                                    209 	.globl _P
                                    210 	.globl _F1
                                    211 	.globl _OV
                                    212 	.globl _RS0
                                    213 	.globl _RS1
                                    214 	.globl _F0
                                    215 	.globl _AC
                                    216 	.globl _CY
                                    217 	.globl _I2CS_INT_ST
                                    218 	.globl _I2CX_INT
                                    219 	.globl _LED_STATUS
                                    220 	.globl _LED_DMA_H
                                    221 	.globl _LED_DMA_L
                                    222 	.globl _LED_DMA
                                    223 	.globl _LED_PWM_OE
                                    224 	.globl _LED_COMMON
                                    225 	.globl _ADC_CHAN
                                    226 	.globl _ADC_DAT_H
                                    227 	.globl _ADC_DAT_L
                                    228 	.globl _ADC_DAT
                                    229 	.globl _ADC_CTRL
                                    230 	.globl _SPI1_CK_SE
                                    231 	.globl _SPI1_CTRL
                                    232 	.globl _SPI1_DATA
                                    233 	.globl _SPI1_STAT
                                    234 	.globl _SIF1
                                    235 	.globl _SBAUD1
                                    236 	.globl _SBUF1
                                    237 	.globl _SCON1
                                    238 	.globl _SPI0_SETUP
                                    239 	.globl _SPI0_CK_SE
                                    240 	.globl _SPI0_CTRL
                                    241 	.globl _SPI0_DATA
                                    242 	.globl _SPI0_STAT
                                    243 	.globl _T2CAP1H
                                    244 	.globl _T2CAP1L
                                    245 	.globl _T2CAP1
                                    246 	.globl _TH2
                                    247 	.globl _TL2
                                    248 	.globl _T2COUNT
                                    249 	.globl _RCAP2H
                                    250 	.globl _RCAP2L
                                    251 	.globl _RCAP2
                                    252 	.globl _T2MOD
                                    253 	.globl _T2CON
                                    254 	.globl _SBUF
                                    255 	.globl _SCON
                                    256 	.globl _TH1
                                    257 	.globl _TH0
                                    258 	.globl _TL1
                                    259 	.globl _TL0
                                    260 	.globl _TMOD
                                    261 	.globl _TCON
                                    262 	.globl _XBUS_AUX
                                    263 	.globl _P7
                                    264 	.globl _P6_DIR
                                    265 	.globl _P6_OUT_PU
                                    266 	.globl _P6_IN
                                    267 	.globl _P5_DIR
                                    268 	.globl _P5_OUT_PU
                                    269 	.globl _P5_IN
                                    270 	.globl _P4_LED_KEY
                                    271 	.globl _P4_DIR_PU
                                    272 	.globl _P4_MOD_OC
                                    273 	.globl _P4
                                    274 	.globl _P3_DIR_PU
                                    275 	.globl _P3_MOD_OC
                                    276 	.globl _P3
                                    277 	.globl _P2_DIR_PU
                                    278 	.globl _P2_MOD_OC
                                    279 	.globl _P2
                                    280 	.globl _P1_DIR_PU
                                    281 	.globl _P1_MOD_OC
                                    282 	.globl _P1
                                    283 	.globl _P0_DIR_PU
                                    284 	.globl _P0_MOD_OC
                                    285 	.globl _P0
                                    286 	.globl _ROM_CTRL
                                    287 	.globl _ROM_DATA_HH
                                    288 	.globl _ROM_DATA_HL
                                    289 	.globl _ROM_DATA_HI
                                    290 	.globl _ROM_ADDR_H
                                    291 	.globl _ROM_ADDR_L
                                    292 	.globl _ROM_ADDR
                                    293 	.globl _GPIO_IE
                                    294 	.globl _IP_EX
                                    295 	.globl _IE_EX
                                    296 	.globl _IP
                                    297 	.globl _IE
                                    298 	.globl _WDOG_COUNT
                                    299 	.globl _RESET_KEEP
                                    300 	.globl _WAKE_CTRL
                                    301 	.globl _CLOCK_CFG
                                    302 	.globl _POWER_CFG
                                    303 	.globl _PCON
                                    304 	.globl _GLOBAL_CFG
                                    305 	.globl _SAFE_MOD
                                    306 	.globl _DPH
                                    307 	.globl _DPL
                                    308 	.globl _SP
                                    309 	.globl _A_INV
                                    310 	.globl _B
                                    311 	.globl _ACC
                                    312 	.globl _PSW
                                    313 	.globl _disable_action_cache
                                    314 	.globl _tap_code_delay_PARM_2
                                    315 	.globl _process_action_PARM_2
                                    316 	.globl _register_mouse_PARM_2
                                    317 	.globl _action_exec_PARM_1
                                    318 	.globl _tp_buttons
                                    319 	.globl _action_exec
                                    320 	.globl _ak820_action_exec
                                    321 	.globl _process_record
                                    322 	.globl _process_record_handler
                                    323 	.globl _process_action
                                    324 	.globl _register_code
                                    325 	.globl _unregister_code
                                    326 	.globl _tap_code_delay
                                    327 	.globl _tap_code
                                    328 	.globl _register_mods
                                    329 	.globl _unregister_mods
                                    330 	.globl _register_weak_mods
                                    331 	.globl _unregister_weak_mods
                                    332 	.globl _clear_keyboard
                                    333 	.globl _clear_keyboard_but_mods
                                    334 	.globl _clear_keyboard_but_mods_and_keys
                                    335 ;--------------------------------------------------------
                                    336 ; special function registers
                                    337 ;--------------------------------------------------------
                                    338 	.area RSEG    (ABS,DATA)
      000000                        339 	.org 0x0000
                           0000D0   340 _PSW	=	0x00d0
                           0000E0   341 _ACC	=	0x00e0
                           0000F0   342 _B	=	0x00f0
                           0000FD   343 _A_INV	=	0x00fd
                           000081   344 _SP	=	0x0081
                           000082   345 _DPL	=	0x0082
                           000083   346 _DPH	=	0x0083
                           0000A1   347 _SAFE_MOD	=	0x00a1
                           0000B1   348 _GLOBAL_CFG	=	0x00b1
                           000087   349 _PCON	=	0x0087
                           0000BA   350 _POWER_CFG	=	0x00ba
                           0000B9   351 _CLOCK_CFG	=	0x00b9
                           0000A9   352 _WAKE_CTRL	=	0x00a9
                           0000FE   353 _RESET_KEEP	=	0x00fe
                           0000FF   354 _WDOG_COUNT	=	0x00ff
                           0000A8   355 _IE	=	0x00a8
                           0000B8   356 _IP	=	0x00b8
                           0000E8   357 _IE_EX	=	0x00e8
                           0000E9   358 _IP_EX	=	0x00e9
                           0000B2   359 _GPIO_IE	=	0x00b2
                           008584   360 _ROM_ADDR	=	0x8584
                           000084   361 _ROM_ADDR_L	=	0x0084
                           000085   362 _ROM_ADDR_H	=	0x0085
                           008F8E   363 _ROM_DATA_HI	=	0x8f8e
                           00008E   364 _ROM_DATA_HL	=	0x008e
                           00008F   365 _ROM_DATA_HH	=	0x008f
                           000086   366 _ROM_CTRL	=	0x0086
                           000080   367 _P0	=	0x0080
                           0000C4   368 _P0_MOD_OC	=	0x00c4
                           0000C5   369 _P0_DIR_PU	=	0x00c5
                           000090   370 _P1	=	0x0090
                           000092   371 _P1_MOD_OC	=	0x0092
                           000093   372 _P1_DIR_PU	=	0x0093
                           0000A0   373 _P2	=	0x00a0
                           000094   374 _P2_MOD_OC	=	0x0094
                           000095   375 _P2_DIR_PU	=	0x0095
                           0000B0   376 _P3	=	0x00b0
                           000096   377 _P3_MOD_OC	=	0x0096
                           000097   378 _P3_DIR_PU	=	0x0097
                           0000C0   379 _P4	=	0x00c0
                           0000C2   380 _P4_MOD_OC	=	0x00c2
                           0000C3   381 _P4_DIR_PU	=	0x00c3
                           0000C1   382 _P4_LED_KEY	=	0x00c1
                           0000AA   383 _P5_IN	=	0x00aa
                           0000AB   384 _P5_OUT_PU	=	0x00ab
                           0000AC   385 _P5_DIR	=	0x00ac
                           0000AD   386 _P6_IN	=	0x00ad
                           0000AE   387 _P6_OUT_PU	=	0x00ae
                           0000AF   388 _P6_DIR	=	0x00af
                           0000F1   389 _P7	=	0x00f1
                           0000A2   390 _XBUS_AUX	=	0x00a2
                           000088   391 _TCON	=	0x0088
                           000089   392 _TMOD	=	0x0089
                           00008A   393 _TL0	=	0x008a
                           00008B   394 _TL1	=	0x008b
                           00008C   395 _TH0	=	0x008c
                           00008D   396 _TH1	=	0x008d
                           000098   397 _SCON	=	0x0098
                           000099   398 _SBUF	=	0x0099
                           0000C8   399 _T2CON	=	0x00c8
                           0000C9   400 _T2MOD	=	0x00c9
                           00CBCA   401 _RCAP2	=	0xcbca
                           0000CA   402 _RCAP2L	=	0x00ca
                           0000CB   403 _RCAP2H	=	0x00cb
                           00CDCC   404 _T2COUNT	=	0xcdcc
                           0000CC   405 _TL2	=	0x00cc
                           0000CD   406 _TH2	=	0x00cd
                           00CFCE   407 _T2CAP1	=	0xcfce
                           0000CE   408 _T2CAP1L	=	0x00ce
                           0000CF   409 _T2CAP1H	=	0x00cf
                           0000F8   410 _SPI0_STAT	=	0x00f8
                           0000F9   411 _SPI0_DATA	=	0x00f9
                           0000FA   412 _SPI0_CTRL	=	0x00fa
                           0000FB   413 _SPI0_CK_SE	=	0x00fb
                           0000FC   414 _SPI0_SETUP	=	0x00fc
                           0000BC   415 _SCON1	=	0x00bc
                           0000BD   416 _SBUF1	=	0x00bd
                           0000BE   417 _SBAUD1	=	0x00be
                           0000BF   418 _SIF1	=	0x00bf
                           0000B4   419 _SPI1_STAT	=	0x00b4
                           0000B5   420 _SPI1_DATA	=	0x00b5
                           0000B6   421 _SPI1_CTRL	=	0x00b6
                           0000B7   422 _SPI1_CK_SE	=	0x00b7
                           0000F3   423 _ADC_CTRL	=	0x00f3
                           00F5F4   424 _ADC_DAT	=	0xf5f4
                           0000F4   425 _ADC_DAT_L	=	0x00f4
                           0000F5   426 _ADC_DAT_H	=	0x00f5
                           0000F6   427 _ADC_CHAN	=	0x00f6
                           0000A6   428 _LED_COMMON	=	0x00a6
                           0000A7   429 _LED_PWM_OE	=	0x00a7
                           00C7C6   430 _LED_DMA	=	0xc7c6
                           0000C6   431 _LED_DMA_L	=	0x00c6
                           0000C7   432 _LED_DMA_H	=	0x00c7
                           0000F7   433 _LED_STATUS	=	0x00f7
                           0000B3   434 _I2CX_INT	=	0x00b3
                           0000BB   435 _I2CS_INT_ST	=	0x00bb
                                    436 ;--------------------------------------------------------
                                    437 ; special function bits
                                    438 ;--------------------------------------------------------
                                    439 	.area RSEG    (ABS,DATA)
      000000                        440 	.org 0x0000
                           0000D7   441 _CY	=	0x00d7
                           0000D6   442 _AC	=	0x00d6
                           0000D5   443 _F0	=	0x00d5
                           0000D4   444 _RS1	=	0x00d4
                           0000D3   445 _RS0	=	0x00d3
                           0000D2   446 _OV	=	0x00d2
                           0000D1   447 _F1	=	0x00d1
                           0000D0   448 _P	=	0x00d0
                           0000AF   449 _EA	=	0x00af
                           0000AE   450 _E_DIS	=	0x00ae
                           0000AD   451 _ET2	=	0x00ad
                           0000AC   452 _ES	=	0x00ac
                           0000AB   453 _ET1	=	0x00ab
                           0000AA   454 _EX1	=	0x00aa
                           0000A9   455 _ET0	=	0x00a9
                           0000A8   456 _EX0	=	0x00a8
                           0000BF   457 _PH_FLAG	=	0x00bf
                           0000BE   458 _PL_FLAG	=	0x00be
                           0000BD   459 _PT2	=	0x00bd
                           0000BC   460 _PS	=	0x00bc
                           0000BB   461 _PT1	=	0x00bb
                           0000BA   462 _PX1	=	0x00ba
                           0000B9   463 _PT0	=	0x00b9
                           0000B8   464 _PX0	=	0x00b8
                           0000EF   465 _IE_WDOG	=	0x00ef
                           0000EE   466 _IE_GPIO	=	0x00ee
                           0000ED   467 _IE_PWM_I2C	=	0x00ed
                           0000EC   468 _IE_UART1	=	0x00ec
                           0000EB   469 _IE_ADC	=	0x00eb
                           0000E9   470 _IE_USB	=	0x00e9
                           0000E8   471 _IE_SPI0	=	0x00e8
                           000087   472 _P0_7	=	0x0087
                           000086   473 _P0_6	=	0x0086
                           000085   474 _P0_5	=	0x0085
                           000084   475 _P0_4	=	0x0084
                           000083   476 _P0_3	=	0x0083
                           000082   477 _P0_2	=	0x0082
                           000081   478 _P0_1	=	0x0081
                           000080   479 _P0_0	=	0x0080
                           000081   480 _SDA0	=	0x0081
                           000080   481 _SCL0	=	0x0080
                           000083   482 _TXD_	=	0x0083
                           000082   483 _RXD_	=	0x0082
                           000085   484 _AIN13	=	0x0085
                           000084   485 _AIN12	=	0x0084
                           000083   486 _AIN11	=	0x0083
                           000082   487 _AIN10	=	0x0082
                           000081   488 _AIN9	=	0x0081
                           000080   489 _AIN8	=	0x0080
                           000097   490 _P1_7	=	0x0097
                           000096   491 _P1_6	=	0x0096
                           000095   492 _P1_5	=	0x0095
                           000094   493 _P1_4	=	0x0094
                           000093   494 _P1_3	=	0x0093
                           000092   495 _P1_2	=	0x0092
                           000091   496 _P1_1	=	0x0091
                           000090   497 _P1_0	=	0x0090
                           000097   498 _TXD1_	=	0x0097
                           000096   499 _RXD1_	=	0x0096
                           000097   500 _SCK	=	0x0097
                           000096   501 _MISO	=	0x0096
                           000095   502 _MOSI	=	0x0095
                           000094   503 _SCS	=	0x0094
                           000092   504 _INT0_	=	0x0092
                           000091   505 _T2EX	=	0x0091
                           000091   506 _CAP2	=	0x0091
                           000090   507 _T2	=	0x0090
                           000090   508 _CAP1	=	0x0090
                           000097   509 _AIN7	=	0x0097
                           000096   510 _AIN6	=	0x0096
                           000095   511 _AIN5	=	0x0095
                           000094   512 _AIN4	=	0x0094
                           000093   513 _AIN3	=	0x0093
                           000092   514 _AIN2	=	0x0092
                           000091   515 _AIN1	=	0x0091
                           000090   516 _AIN0	=	0x0090
                           0000A7   517 _P2_7	=	0x00a7
                           0000A6   518 _P2_6	=	0x00a6
                           0000A5   519 _P2_5	=	0x00a5
                           0000A4   520 _P2_4	=	0x00a4
                           0000A3   521 _P2_3	=	0x00a3
                           0000A2   522 _P2_2	=	0x00a2
                           0000A1   523 _P2_1	=	0x00a1
                           0000A0   524 _P2_0	=	0x00a0
                           0000A7   525 _TXD1	=	0x00a7
                           0000A6   526 _RXD1	=	0x00a6
                           0000A5   527 _T2EX_	=	0x00a5
                           0000A5   528 _CAP2_	=	0x00a5
                           0000A4   529 _T2_	=	0x00a4
                           0000A4   530 _CAP1_	=	0x00a4
                           0000B7   531 _P3_7	=	0x00b7
                           0000B6   532 _P3_6	=	0x00b6
                           0000B5   533 _P3_5	=	0x00b5
                           0000B4   534 _P3_4	=	0x00b4
                           0000B3   535 _P3_3	=	0x00b3
                           0000B2   536 _P3_2	=	0x00b2
                           0000B1   537 _P3_1	=	0x00b1
                           0000B0   538 _P3_0	=	0x00b0
                           0000B7   539 _SCK1	=	0x00b7
                           0000B6   540 _MISO1	=	0x00b6
                           0000B5   541 _MOSI1	=	0x00b5
                           0000B5   542 _T1	=	0x00b5
                           0000B4   543 _T0	=	0x00b4
                           0000B3   544 _INT1	=	0x00b3
                           0000B2   545 _INT0	=	0x00b2
                           0000B1   546 _TXD	=	0x00b1
                           0000B0   547 _RXD	=	0x00b0
                           0000C6   548 _P4_6	=	0x00c6
                           0000C5   549 _P4_5	=	0x00c5
                           0000C4   550 _P4_4	=	0x00c4
                           0000C3   551 _P4_3	=	0x00c3
                           0000C2   552 _P4_2	=	0x00c2
                           0000C1   553 _P4_1	=	0x00c1
                           0000C0   554 _P4_0	=	0x00c0
                           00008F   555 _TF1	=	0x008f
                           00008E   556 _TR1	=	0x008e
                           00008D   557 _TF0	=	0x008d
                           00008C   558 _TR0	=	0x008c
                           00008B   559 _IE1	=	0x008b
                           00008A   560 _IT1	=	0x008a
                           000089   561 _IE0	=	0x0089
                           000088   562 _IT0	=	0x0088
                           00009F   563 _SM0	=	0x009f
                           00009E   564 _SM1	=	0x009e
                           00009D   565 _SM2	=	0x009d
                           00009C   566 _REN	=	0x009c
                           00009B   567 _TB8	=	0x009b
                           00009A   568 _RB8	=	0x009a
                           000099   569 _TI	=	0x0099
                           000098   570 _RI	=	0x0098
                           0000CF   571 _TF2	=	0x00cf
                           0000CF   572 _CAP1F	=	0x00cf
                           0000CE   573 _EXF2	=	0x00ce
                           0000CD   574 _RCLK	=	0x00cd
                           0000CC   575 _TCLK	=	0x00cc
                           0000CB   576 _EXEN2	=	0x00cb
                           0000CA   577 _TR2	=	0x00ca
                           0000C9   578 _C_T2	=	0x00c9
                           0000C8   579 _CP_RL2	=	0x00c8
                           0000FF   580 _S0_FST_ACT	=	0x00ff
                           0000FE   581 _S0_IF_OV	=	0x00fe
                           0000FD   582 _S0_IF_FIRST	=	0x00fd
                           0000FC   583 _S0_IF_BYTE	=	0x00fc
                           0000FB   584 _S0_FREE	=	0x00fb
                           0000FA   585 _S0_T_FIFO	=	0x00fa
                           0000F8   586 _S0_R_FIFO	=	0x00f8
                           0000F7   587 _ADC_START	=	0x00f7
                                    588 ;--------------------------------------------------------
                                    589 ; overlayable register banks
                                    590 ;--------------------------------------------------------
                                    591 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        592 	.ds 8
                                    593 ;--------------------------------------------------------
                                    594 ; internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area DSEG    (DATA)
      000027                        597 _process_action_sloc0_1_0:
      000027                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; overlayable items in internal ram
                                    601 ;--------------------------------------------------------
                                    602 ;--------------------------------------------------------
                                    603 ; indirectly addressable internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area ISEG    (DATA)
                                    606 ;--------------------------------------------------------
                                    607 ; absolute internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area IABS    (ABS,DATA)
                                    610 	.area IABS    (ABS,DATA)
                                    611 ;--------------------------------------------------------
                                    612 ; bit data
                                    613 ;--------------------------------------------------------
                                    614 	.area BSEG    (BIT)
      000020                        615 _process_action_sloc1_1_0:
      000020                        616 	.ds 1
                                    617 ;--------------------------------------------------------
                                    618 ; paged external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area PSEG    (PAG,XDATA)
                                    621 ;--------------------------------------------------------
                                    622 ; uninitialized external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area XSEG    (XDATA)
      000841                        625 _tp_buttons::
      000841                        626 	.ds 2
      000843                        627 _action_exec_PARM_1:
      000843                        628 	.ds 6
      000849                        629 _action_exec_record_10001_629:
      000849                        630 	.ds 9
      000852                        631 _ak820_action_exec_event_10000_634:
      000852                        632 	.ds 2
      000854                        633 _ak820_action_exec_snapshot_10000_635:
      000854                        634 	.ds 6
      00085A                        635 _process_record_record_10000_638:
      00085A                        636 	.ds 3
      00085D                        637 _process_record_handler_record_argument_10000_646:
      00085D                        638 	.ds 3
      000860                        639 _process_record_handler_action_10000_647:
      000860                        640 	.ds 2
      000862                        641 _register_mouse_PARM_2:
      000862                        642 	.ds 1
      000863                        643 _register_mouse_mouse_keycode_10000_655:
      000863                        644 	.ds 1
      000864                        645 _process_action_PARM_2:
      000864                        646 	.ds 2
      000866                        647 _process_action_record_argument_10000_662:
      000866                        648 	.ds 3
      000869                        649 _process_action_on_40000_685:
      000869                        650 	.ds 1
      00086A                        651 _register_code_code_10000_719:
      00086A                        652 	.ds 1
      00086B                        653 _unregister_code_code_10000_733:
      00086B                        654 	.ds 1
      00086C                        655 _tap_code_delay_PARM_2:
      00086C                        656 	.ds 2
      00086E                        657 _tap_code_delay_code_10000_746:
      00086E                        658 	.ds 1
      00086F                        659 _tap_code_code_10000_753:
      00086F                        660 	.ds 1
      000870                        661 _register_mods_mods_10000_755:
      000870                        662 	.ds 1
      000871                        663 _unregister_mods_mods_10000_759:
      000871                        664 	.ds 1
      000872                        665 _register_weak_mods_mods_10000_763:
      000872                        666 	.ds 1
      000873                        667 _unregister_weak_mods_mods_10000_767:
      000873                        668 	.ds 1
                                    669 ;--------------------------------------------------------
                                    670 ; absolute external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XABS    (ABS,XDATA)
                                    673 ;--------------------------------------------------------
                                    674 ; initialized external ram data
                                    675 ;--------------------------------------------------------
                                    676 	.area XISEG   (XDATA)
      000DF4                        677 _disable_action_cache::
      000DF4                        678 	.ds 1
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT0 (CODE)
                                    681 	.area GSINIT1 (CODE)
                                    682 	.area GSINIT2 (CODE)
                                    683 	.area GSINIT3 (CODE)
                                    684 	.area GSINIT4 (CODE)
                                    685 	.area GSINIT5 (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 	.area GSFINAL (CODE)
                                    688 	.area CSEG    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; global & static initialisations
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area GSINIT  (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    707 ;------------------------------------------------------------
                                    708 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    709 ;------------------------------------------------------------
                                    710 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function action_exec
                                    721 ;	-----------------------------------------
      00750D                        722 _action_exec:
                                    723 ;	quantum/action.c:86: ak820_combo_tick(event.time);
      00750D 90 08 45         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007510 12 3A 62         [24]  725 	lcall	_ak820_outline_0005
      007513 12 38 79         [24]  726 	lcall	_ak820_combo_tick
                                    727 ;	quantum/action.c:89: if (!ak820_tapping_before(&event)) return;
      007516 90 08 43         [24]  728 	mov	dptr,#_action_exec_PARM_1
      007519 12 46 C1         [24]  729 	lcall	_ak820_tapping_before
      00751C E5 82            [12]  730 	mov	a, dpl
      00751E 70 01            [24]  731 	jnz	00102$
      007520 22               [24]  732 	ret
      007521                        733 00102$:
                                    734 ;	quantum/action.c:91: if (!ak820_autoshift_before(&event)) return;
      007521 90 08 43         [24]  735 	mov	dptr,#_action_exec_PARM_1
      007524 12 31 5B         [24]  736 	lcall	_ak820_autoshift_before
      007527 E5 82            [12]  737 	mov	a, dpl
      007529 70 01            [24]  738 	jnz	00104$
      00752B 22               [24]  739 	ret
      00752C                        740 00104$:
                                    741 ;	quantum/action.c:107: if (event.pressed) {
      00752C 90 08 48         [24]  742 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00752F E0               [24]  743 	movx	a,@dptr
      007530 60 03            [24]  744 	jz	00106$
                                    745 ;	quantum/action.c:109: clear_weak_mods();
      007532 12 85 D2         [24]  746 	lcall	_clear_weak_mods
      007535                        747 00106$:
                                    748 ;	quantum/action.c:121: record.event = event;
      007535 90 0D D3         [24]  749 	mov	dptr,#___memcpy_PARM_2
      007538 74 43            [12]  750 	mov	a,#_action_exec_PARM_1
      00753A F0               [24]  751 	movx	@dptr,a
      00753B 74 08            [12]  752 	mov	a,#(_action_exec_PARM_1 >> 8)
      00753D 12 3A CC         [24]  753 	lcall	_ak820_outline_0072
      007540 12 7C 5A         [24]  754 	lcall	_ak820_outline_0071
      007543 90 08 49         [24]  755 	mov	dptr,#_action_exec_record_10001_629
      007546 F5 F0            [12]  756 	mov	b,a
      007548 12 BC 62         [24]  757 	lcall	___memcpy
                                    758 ;	quantum/action.c:123: record.tap.count = 0;
      00754B 90 08 4F         [24]  759 	mov	dptr,#(_action_exec_record_10001_629 + 0x0006)
      00754E E0               [24]  760 	movx	a,@dptr
      00754F 54 0F            [12]  761 	anl	a,#0x0f
      007551 F0               [24]  762 	movx	@dptr,a
                                    763 ;	quantum/action.c:128: record.keycode = 0;
      007552 90 08 50         [24]  764 	mov	dptr,#(_action_exec_record_10001_629 + 0x0007)
      007555 12 51 C6         [24]  765 	lcall	_ak820_outline_0182
                                    766 ;	quantum/action.c:159: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007558 90 08 4D         [24]  767 	mov	dptr,#(_action_exec_record_10001_629 + 0x0004)
      00755B E0               [24]  768 	movx	a,@dptr
      00755C 60 0D            [24]  769 	jz	00111$
      00755E 90 08 49         [24]  770 	mov	dptr,#_action_exec_record_10001_629
      007561 75 F0 00         [24]  771 	mov	b, #0x00
      007564 12 A3 5C         [24]  772 	lcall	_pre_process_record_quantum
      007567 E5 82            [12]  773 	mov	a, dpl
      007569 60 1E            [24]  774 	jz	00114$
      00756B                        775 00111$:
                                    776 ;	quantum/action.c:161: if (!ak820_tapping_process(&record)) return;
      00756B 90 08 49         [24]  777 	mov	dptr,#_action_exec_record_10001_629
      00756E 12 47 A6         [24]  778 	lcall	_ak820_tapping_process
      007571 E5 82            [12]  779 	mov	a, dpl
      007573 70 01            [24]  780 	jnz	00108$
      007575 22               [24]  781 	ret
      007576                        782 00108$:
                                    783 ;	quantum/action.c:163: if (!ak820_autoshift_process(&record)) return;
      007576 90 08 49         [24]  784 	mov	dptr,#_action_exec_record_10001_629
      007579 12 32 63         [24]  785 	lcall	_ak820_autoshift_process
      00757C E5 82            [12]  786 	mov	a, dpl
      00757E 70 01            [24]  787 	jnz	00110$
      007580 22               [24]  788 	ret
      007581                        789 00110$:
                                    790 ;	quantum/action.c:166: process_record(&record);
      007581 90 08 49         [24]  791 	mov	dptr,#_action_exec_record_10001_629
      007584 75 F0 00         [24]  792 	mov	b, #0x00
                                    793 ;	quantum/action.c:176: }
      007587 A1 C5            [12]  794 	ajmp	_process_record
      007589                        795 00114$:
      007589 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'ak820_action_exec'
                                    799 ;------------------------------------------------------------
                                    800 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    801 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    802 ;------------------------------------------------------------
                                    803 ;	quantum/action.c:179: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function ak820_action_exec
                                    806 ;	-----------------------------------------
      00758A                        807 _ak820_action_exec:
      00758A 12 3A F0         [24]  808 	lcall	_ak820_outline_0107
      00758D 90 08 52         [24]  809 	mov	dptr,#_ak820_action_exec_event_10000_634
      007590 12 3A F5         [24]  810 	lcall	_ak820_outline_0108
                                    811 ;	quantum/action.c:182: keyevent_t snapshot = *event;
      007593 90 08 52         [24]  812 	mov	dptr,#_ak820_action_exec_event_10000_634
      007596 12 3A D8         [24]  813 	lcall	_ak820_outline_0080
      007599 7F 00            [12]  814 	mov	r7,#0x00
      00759B 90 0D D3         [24]  815 	mov	dptr,#___memcpy_PARM_2
      00759E ED               [12]  816 	mov	a,r5
      00759F 12 3A 8D         [24]  817 	lcall	_ak820_outline_0016
      0075A2 12 7C 5A         [24]  818 	lcall	_ak820_outline_0071
      0075A5 90 08 54         [24]  819 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      0075A8 F5 F0            [12]  820 	mov	b,a
      0075AA 12 BC 62         [24]  821 	lcall	___memcpy
                                    822 ;	quantum/action.c:183: action_exec(snapshot);
      0075AD 90 0D D3         [24]  823 	mov	dptr,#___memcpy_PARM_2
      0075B0 74 54            [12]  824 	mov	a,#_ak820_action_exec_snapshot_10000_635
      0075B2 F0               [24]  825 	movx	@dptr,a
      0075B3 74 08            [12]  826 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      0075B5 12 3A CC         [24]  827 	lcall	_ak820_outline_0072
      0075B8 12 7C 5A         [24]  828 	lcall	_ak820_outline_0071
      0075BB 90 08 43         [24]  829 	mov	dptr,#_action_exec_PARM_1
      0075BE F5 F0            [12]  830 	mov	b,a
      0075C0 12 BC 62         [24]  831 	lcall	___memcpy
                                    832 ;	quantum/action.c:184: }
      0075C3 A1 0D            [12]  833 	ajmp	_action_exec
                                    834 ;------------------------------------------------------------
                                    835 ;Allocation info for local variables in function 'process_record_nocache'
                                    836 ;------------------------------------------------------------
                                    837 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    838 ;------------------------------------------------------------
                                    839 ;	quantum/action.c:269: void process_record_nocache(keyrecord_t *record) {
                                    840 ;	-----------------------------------------
                                    841 ;	 function process_record
                                    842 ;	-----------------------------------------
      0075C5                        843 _process_record:
      0075C5 12 45 7B         [24]  844 	lcall	_ak820_outline_0036
      0075C8 90 08 5A         [24]  845 	mov	dptr,#_process_record_record_10000_638
      0075CB 12 3A 8D         [24]  846 	lcall	_ak820_outline_0016
                                    847 ;	quantum/action.c:323: if (IS_NOEVENT(record->event)) {
      0075CE 90 08 5A         [24]  848 	mov	dptr,#_process_record_record_10000_638
      0075D1 12 51 7C         [24]  849 	lcall	_ak820_outline_0012
      0075D4 74 04            [12]  850 	mov	a,#0x04
      0075D6 12 7C 2D         [24]  851 	lcall	_ak820_outline_0014
      0075D9 12 BD 3B         [24]  852 	lcall	__gptrget
      0075DC 70 01            [24]  853 	jnz	00102$
                                    854 ;	quantum/action.c:324: return;
      0075DE 22               [24]  855 	ret
      0075DF                        856 00102$:
                                    857 ;	quantum/action.c:328: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0075DF 8D 02            [24]  858 	mov	ar2,r5
      0075E1 8E 03            [24]  859 	mov	ar3,r6
      0075E3 8F 04            [24]  860 	mov	ar4,r7
      0075E5 90 0D D3         [24]  861 	mov	dptr,#___memcpy_PARM_2
      0075E8 EA               [12]  862 	mov	a,r2
      0075E9 12 7C A1         [24]  863 	lcall	_ak820_outline_0185
      0075EC EC               [12]  864 	mov	a,r4
      0075ED A3               [24]  865 	inc	dptr
      0075EE F0               [24]  866 	movx	@dptr,a
      0075EF 90 0D D6         [24]  867 	mov	dptr,#___memcpy_PARM_3
      0075F2 12 51 B8         [24]  868 	lcall	_ak820_outline_0110
      0075F5 90 06 34         [24]  869 	mov	dptr,#_ak820_tapping_source_PARM_1
      0075F8 F5 F0            [12]  870 	mov	b,a
      0075FA C0 07            [24]  871 	push	ar7
      0075FC C0 06            [24]  872 	push	ar6
      0075FE C0 05            [24]  873 	push	ar5
      007600 12 BC 62         [24]  874 	lcall	___memcpy
      007603 12 45 FC         [24]  875 	lcall	_ak820_tapping_source
      007606 AC 82            [24]  876 	mov	r4, dpl
      007608 D0 05            [24]  877 	pop	ar5
      00760A D0 06            [24]  878 	pop	ar6
      00760C D0 07            [24]  879 	pop	ar7
                                    880 ;	quantum/action.c:329: bool oneshot_pressed = record->event.pressed;
      00760E 74 05            [12]  881 	mov	a,#0x05
      007610 12 7C 1F         [24]  882 	lcall	_ak820_outline_0013
      007613 12 BD 3B         [24]  883 	lcall	__gptrget
      007616 FB               [12]  884 	mov	r3,a
                                    885 ;	quantum/action.c:330: record->keycode = get_record_keycode(record, true);
      007617 12 7C 92         [24]  886 	lcall	_ak820_outline_0147
      00761A 90 0C 2A         [24]  887 	mov	dptr,#_get_record_keycode_PARM_2
      00761D 74 01            [12]  888 	mov	a,#0x01
      00761F 12 51 85         [24]  889 	lcall	_ak820_outline_0034
      007622 C0 04            [24]  890 	push	ar4
      007624 C0 03            [24]  891 	push	ar3
      007626 C0 02            [24]  892 	push	ar2
      007628 C0 01            [24]  893 	push	ar1
      00762A C0 00            [24]  894 	push	ar0
      00762C 12 A3 1E         [24]  895 	lcall	_get_record_keycode
      00762F 12 45 C4         [24]  896 	lcall	_ak820_outline_0125
      007632 D0 00            [24]  897 	pop	ar0
      007634 D0 01            [24]  898 	pop	ar1
      007636 D0 02            [24]  899 	pop	ar2
      007638 D0 03            [24]  900 	pop	ar3
      00763A D0 04            [24]  901 	pop	ar4
      00763C 12 4B 19         [24]  902 	lcall	_ak820_outline_0111
      00763F EE               [12]  903 	mov	a,r6
      007640 12 BD 00         [24]  904 	lcall	__gptrput
      007643 A3               [24]  905 	inc	dptr
      007644 EF               [12]  906 	mov	a,r7
      007645 12 BD 00         [24]  907 	lcall	__gptrput
                                    908 ;	quantum/action.c:331: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007648 90 08 5A         [24]  909 	mov	dptr,#_process_record_record_10000_638
      00764B 12 51 7C         [24]  910 	lcall	_ak820_outline_0012
      00764E 12 7C 92         [24]  911 	lcall	_ak820_outline_0147
      007651 12 4B 19         [24]  912 	lcall	_ak820_outline_0111
      007654 12 BD 3B         [24]  913 	lcall	__gptrget
      007657 F8               [12]  914 	mov	r0,a
      007658 A3               [24]  915 	inc	dptr
      007659 12 BD 3B         [24]  916 	lcall	__gptrget
      00765C F9               [12]  917 	mov	r1,a
      00765D 90 06 44         [24]  918 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007660 EC               [12]  919 	mov	a,r4
      007661 F0               [24]  920 	movx	@dptr,a
      007662 90 06 45         [24]  921 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007665 EB               [12]  922 	mov	a,r3
      007666 F0               [24]  923 	movx	@dptr,a
      007667 12 3B 24         [24]  924 	lcall	_ak820_outline_0161
      00766A C0 07            [24]  925 	push	ar7
      00766C C0 06            [24]  926 	push	ar6
      00766E C0 05            [24]  927 	push	ar5
      007670 C0 04            [24]  928 	push	ar4
      007672 C0 03            [24]  929 	push	ar3
      007674 12 49 55         [24]  930 	lcall	_ak820_oneshot_process
      007677 E5 82            [12]  931 	mov	a, dpl
      007679 D0 03            [24]  932 	pop	ar3
      00767B D0 04            [24]  933 	pop	ar4
      00767D D0 05            [24]  934 	pop	ar5
      00767F D0 06            [24]  935 	pop	ar6
      007681 D0 07            [24]  936 	pop	ar7
      007683 70 01            [24]  937 	jnz	00104$
      007685 22               [24]  938 	ret
      007686                        939 00104$:
                                    940 ;	quantum/action.c:333: if (!process_record_quantum(record)) {
      007686 12 72 57         [24]  941 	lcall	_ak820_outline_0059
      007689 C0 04            [24]  942 	push	ar4
      00768B C0 03            [24]  943 	push	ar3
      00768D 12 A3 E0         [24]  944 	lcall	_process_record_quantum
      007690 E5 82            [12]  945 	mov	a, dpl
      007692 D0 03            [24]  946 	pop	ar3
      007694 D0 04            [24]  947 	pop	ar4
      007696 70 0A            [24]  948 	jnz	00106$
                                    949 ;	quantum/action.c:335: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007698 90 05 AC         [24]  950 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00769B EB               [12]  951 	mov	a,r3
      00769C F0               [24]  952 	movx	@dptr,a
      00769D 8C 82            [24]  953 	mov	dpl, r4
                                    954 ;	quantum/action.c:342: return;
      00769F 02 2E BB         [24]  955 	ljmp	_ak820_oneshot_post
      0076A2                        956 00106$:
                                    957 ;	quantum/action.c:345: process_record_handler(record);
      0076A2 90 08 5A         [24]  958 	mov	dptr,#_process_record_record_10000_638
      0076A5 12 51 56         [24]  959 	lcall	_ak820_outline_0001
      0076A8 C0 04            [24]  960 	push	ar4
      0076AA C0 03            [24]  961 	push	ar3
      0076AC D1 C5            [24]  962 	acall	_process_record_handler
                                    963 ;	quantum/action.c:346: post_process_record_quantum(record);
      0076AE 90 08 5A         [24]  964 	mov	dptr,#_process_record_record_10000_638
      0076B1 12 51 56         [24]  965 	lcall	_ak820_outline_0001
      0076B4 12 A3 B7         [24]  966 	lcall	_post_process_record_quantum
      0076B7 D0 03            [24]  967 	pop	ar3
      0076B9 D0 04            [24]  968 	pop	ar4
                                    969 ;	quantum/action.c:348: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0076BB 90 05 AC         [24]  970 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0076BE EB               [12]  971 	mov	a,r3
      0076BF F0               [24]  972 	movx	@dptr,a
      0076C0 8C 82            [24]  973 	mov	dpl, r4
                                    974 ;	quantum/action.c:350: }
      0076C2 02 2E BB         [24]  975 	ljmp	_ak820_oneshot_post
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'process_record_handler'
                                    978 ;------------------------------------------------------------
                                    979 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_646'
                                    980 ;record        Allocated with name '_process_record_handler_record_10000_647'
                                    981 ;action        Allocated with name '_process_record_handler_action_10000_647'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/action.c:352: void process_record_handler(keyrecord_t *record_argument) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function process_record_handler
                                    986 ;	-----------------------------------------
      0076C5                        987 _process_record_handler:
      0076C5 12 45 7B         [24]  988 	lcall	_ak820_outline_0036
      0076C8 90 08 5D         [24]  989 	mov	dptr,#_process_record_handler_record_argument_10000_646
      0076CB 12 3A 8D         [24]  990 	lcall	_ak820_outline_0016
                                    991 ;	quantum/action.c:356: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0076CE 90 08 5D         [24]  992 	mov	dptr,#_process_record_handler_record_argument_10000_646
      0076D1 12 3A 6C         [24]  993 	lcall	_ak820_outline_0007
                                    994 ;	quantum/action.c:363: if (record->keycode) {
      0076D4 4C               [12]  995 	orl	a,r4
      0076D5 60 19            [24]  996 	jz	00102$
                                    997 ;	quantum/action.c:364: action.code = action_for_keycode(record->keycode);
      0076D7 12 3A FF         [24]  998 	lcall	_ak820_outline_0123
      0076DA C0 07            [24]  999 	push	ar7
      0076DC C0 06            [24] 1000 	push	ar6
      0076DE 12 99 72         [24] 1001 	lcall	_action_for_keycode
      0076E1 12 45 D5         [24] 1002 	lcall	_ak820_outline_0151
      0076E4 D0 06            [24] 1003 	pop	ar6
      0076E6 D0 07            [24] 1004 	pop	ar7
      0076E8 90 08 60         [24] 1005 	mov	dptr,#_process_record_handler_action_10000_647
      0076EB 12 3A D2         [24] 1006 	lcall	_ak820_outline_0074
      0076EE 80 2B            [24] 1007 	sjmp	00104$
      0076F0                       1008 00102$:
                                   1009 ;	quantum/action.c:367: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0076F0 12 7C 3B         [24] 1010 	lcall	_ak820_outline_0021
      0076F3 7A 00            [12] 1011 	mov	r2,#0x00
      0076F5 12 45 CF         [24] 1012 	lcall	_ak820_outline_0143
      0076F8 12 45 69         [24] 1013 	lcall	_ak820_outline_0011
      0076FB E0               [24] 1014 	movx	a,@dptr
      0076FC 90 09 9E         [24] 1015 	mov	dptr,#_ak820_resolve_key_PARM_2
      0076FF F0               [24] 1016 	movx	@dptr,a
      007700 8D 82            [24] 1017 	mov	dpl, r5
      007702 8C 83            [24] 1018 	mov	dph, r4
      007704 C0 07            [24] 1019 	push	ar7
      007706 C0 06            [24] 1020 	push	ar6
      007708 12 7F D1         [24] 1021 	lcall	_ak820_resolve_key
      00770B 12 99 72         [24] 1022 	lcall	_action_for_keycode
      00770E 12 45 D5         [24] 1023 	lcall	_ak820_outline_0151
      007711 D0 06            [24] 1024 	pop	ar6
      007713 D0 07            [24] 1025 	pop	ar7
      007715 90 08 60         [24] 1026 	mov	dptr,#_process_record_handler_action_10000_647
      007718 12 3A D2         [24] 1027 	lcall	_ak820_outline_0074
                                   1028 ;	quantum/action.c:376: ac_dprintf("ACTION: ");
      00771B                       1029 00104$:
                                   1030 ;	quantum/action.c:387: process_action(record, action);
      00771B 7D 00            [12] 1031 	mov	r5,#0x00
      00771D 90 0D D3         [24] 1032 	mov	dptr,#___memcpy_PARM_2
      007720 74 60            [12] 1033 	mov	a,#_process_record_handler_action_10000_647
      007722 F0               [24] 1034 	movx	@dptr,a
      007723 74 08            [12] 1035 	mov	a,#(_process_record_handler_action_10000_647 >> 8)
      007725 12 3A CC         [24] 1036 	lcall	_ak820_outline_0072
      007728 90 0D D6         [24] 1037 	mov	dptr,#___memcpy_PARM_3
      00772B 12 51 B8         [24] 1038 	lcall	_ak820_outline_0110
      00772E 90 08 64         [24] 1039 	mov	dptr,#_process_action_PARM_2
      007731 F5 F0            [12] 1040 	mov	b,a
      007733 C0 07            [24] 1041 	push	ar7
      007735 C0 06            [24] 1042 	push	ar6
      007737 C0 05            [24] 1043 	push	ar5
      007739 12 BC 62         [24] 1044 	lcall	___memcpy
      00773C D0 05            [24] 1045 	pop	ar5
      00773E D0 06            [24] 1046 	pop	ar6
      007740 D0 07            [24] 1047 	pop	ar7
      007742 12 74 78         [24] 1048 	lcall	_ak820_outline_0050
                                   1049 ;	quantum/action.c:388: }
      007745 E1 6A            [24] 1050 	ajmp	_process_action
                                   1051 ;------------------------------------------------------------
                                   1052 ;Allocation info for local variables in function 'register_mouse'
                                   1053 ;------------------------------------------------------------
                                   1054 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1055 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_655'
                                   1056 ;------------------------------------------------------------
                                   1057 ;	quantum/action.c:400: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1058 ;	-----------------------------------------
                                   1059 ;	 function register_mouse
                                   1060 ;	-----------------------------------------
      007747                       1061 _register_mouse:
      007747 E5 82            [12] 1062 	mov	a,dpl
      007749 90 08 63         [24] 1063 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      00774C F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/action.c:403: if (pressed) {
      00774D 90 08 62         [24] 1066 	mov	dptr,#_register_mouse_PARM_2
      007750 E0               [24] 1067 	movx	a,@dptr
      007751 60 0B            [24] 1068 	jz	00102$
                                   1069 ;	quantum/action.c:404: mousekey_on(mouse_keycode);
      007753 90 08 63         [24] 1070 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      007756 E0               [24] 1071 	movx	a,@dptr
      007757 F5 82            [12] 1072 	mov	dpl,a
      007759 12 52 16         [24] 1073 	lcall	_mousekey_on
      00775C 80 09            [24] 1074 	sjmp	00103$
      00775E                       1075 00102$:
                                   1076 ;	quantum/action.c:406: mousekey_off(mouse_keycode);
      00775E 90 08 63         [24] 1077 	mov	dptr,#_register_mouse_mouse_keycode_10000_655
      007761 E0               [24] 1078 	movx	a,@dptr
      007762 F5 82            [12] 1079 	mov	dpl,a
      007764 12 52 8A         [24] 1080 	lcall	_mousekey_off
      007767                       1081 00103$:
                                   1082 ;	quantum/action.c:427: mousekey_send();
                                   1083 ;	quantum/action.c:429: }
                                   1084 ;	quantum/action.c:445: }
      007767 02 52 E9         [24] 1085 	ljmp	_mousekey_send
                                   1086 ;------------------------------------------------------------
                                   1087 ;Allocation info for local variables in function 'process_action'
                                   1088 ;------------------------------------------------------------
                                   1089 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1090 ;action        Allocated with name '_process_action_PARM_2'
                                   1091 ;record_argument Allocated with name '_process_action_record_argument_10000_662'
                                   1092 ;record        Allocated with name '_process_action_record_10000_663'
                                   1093 ;pressed       Allocated with name '_process_action_pressed_10000_663'
                                   1094 ;mods          Allocated with name '_process_action_mods_10000_663'
                                   1095 ;on            Allocated with name '_process_action_on_40000_685'
                                   1096 ;shift         Allocated with name '_process_action_shift_60000_687'
                                   1097 ;bits          Allocated with name '_process_action_bits_60000_687'
                                   1098 ;mask          Allocated with name '_process_action_mask_60000_687'
                                   1099 ;i             Allocated with name '_process_action_i_110000_711'
                                   1100 ;i             Allocated with name '_process_action_i_110000_715'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/action.c:451: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function process_action
                                   1105 ;	-----------------------------------------
      00776A                       1106 _process_action:
      00776A 12 45 7B         [24] 1107 	lcall	_ak820_outline_0036
      00776D 90 08 66         [24] 1108 	mov	dptr,#_process_action_record_argument_10000_662
      007770 12 3A 8D         [24] 1109 	lcall	_ak820_outline_0016
                                   1110 ;	quantum/action.c:453: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007773 90 08 66         [24] 1111 	mov	dptr,#_process_action_record_argument_10000_662
      007776 12 3A 62         [24] 1112 	lcall	_ak820_outline_0005
                                   1113 ;	quantum/action.c:459: pressed = record->event.pressed;
      007779 A3               [24] 1114 	inc	dptr
      00777A A3               [24] 1115 	inc	dptr
      00777B A3               [24] 1116 	inc	dptr
      00777C A3               [24] 1117 	inc	dptr
      00777D A3               [24] 1118 	inc	dptr
      00777E E0               [24] 1119 	movx	a,@dptr
      00777F F5 27            [12] 1120 	mov	_process_action_sloc0_1_0,a
                                   1121 ;	quantum/action.c:483: switch (action.kind.id) {
      007781 90 08 65         [24] 1122 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007784 E0               [24] 1123 	movx	a,@dptr
      007785 C4               [12] 1124 	swap	a
      007786 54 0F            [12] 1125 	anl	a,#0x0f
      007788 FD               [12] 1126 	mov  r5,a
      007789 24 F4            [12] 1127 	add	a,#0xff - 0x0b
      00778B 50 03            [24] 1128 	jnc	00434$
      00778D 02 7A 1D         [24] 1129 	ljmp	00181$
      007790                       1130 00434$:
                                   1131 ;	free result
      007790 ED               [12] 1132 	mov	a,r5
      007791 24 0A            [12] 1133 	add	a,#(00435$-3-.)
      007793 83               [24] 1134 	movc	a,@a+pc
      007794 F5 82            [12] 1135 	mov	dpl,a
      007796 ED               [12] 1136 	mov	a,r5
      007797 24 10            [12] 1137 	add	a,#(00436$-3-.)
      007799 83               [24] 1138 	movc	a,@a+pc
      00779A F5 83            [12] 1139 	mov	dph,a
      00779C E4               [12] 1140 	clr	a
      00779D 73               [24] 1141 	jmp	@a+dptr
      00779E                       1142 00435$:
      00779E B6                    1143 	.db	00102$
      00779F B6                    1144 	.db	00102$
      0077A0 1D                    1145 	.db	00181$
      0077A1 1D                    1146 	.db	00181$
      0077A2 40                    1147 	.db	00123$
      0077A3 A0                    1148 	.db	00130$
      0077A4 1D                    1149 	.db	00181$
      0077A5 1D                    1150 	.db	00181$
      0077A6 B2                    1151 	.db	00131$
      0077A7 84                    1152 	.db	00147$
      0077A8 AA                    1153 	.db	00152$
      0077A9 AA                    1154 	.db	00152$
      0077AA                       1155 00436$:
      0077AA 77                    1156 	.db	00102$>>8
      0077AB 77                    1157 	.db	00102$>>8
      0077AC 7A                    1158 	.db	00181$>>8
      0077AD 7A                    1159 	.db	00181$>>8
      0077AE 78                    1160 	.db	00123$>>8
      0077AF 78                    1161 	.db	00130$>>8
      0077B0 7A                    1162 	.db	00181$>>8
      0077B1 7A                    1163 	.db	00181$>>8
      0077B2 78                    1164 	.db	00131$>>8
      0077B3 79                    1165 	.db	00147$>>8
      0077B4 79                    1166 	.db	00152$>>8
      0077B5 79                    1167 	.db	00152$>>8
                                   1168 ;	quantum/action.c:486: case ACT_RMODS: {
      0077B6                       1169 00102$:
                                   1170 ;	quantum/action.c:487: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0077B6 90 08 65         [24] 1171 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077B9 E0               [24] 1172 	movx	a,@dptr
      0077BA 54 F0            [12] 1173 	anl	a,#0xf0
      0077BC 70 06            [24] 1174 	jnz	00194$
      0077BE 12 7C 74         [24] 1175 	lcall	_ak820_outline_0112
      0077C1 FD               [12] 1176 	mov	r5,a
      0077C2 80 07            [24] 1177 	sjmp	00195$
      0077C4                       1178 00194$:
      0077C4 12 7C 74         [24] 1179 	lcall	_ak820_outline_0112
      0077C7 C4               [12] 1180 	swap	a
      0077C8 54 F0            [12] 1181 	anl	a,#0xf0
      0077CA FD               [12] 1182 	mov	r5,a
      0077CB                       1183 00195$:
                                   1184 ;	quantum/action.c:489: if (pressed) {
      0077CB E5 27            [12] 1185 	mov	a,_process_action_sloc0_1_0
      0077CD 60 35            [24] 1186 	jz	00119$
                                   1187 ;	quantum/action.c:490: if (mods) {
      0077CF ED               [12] 1188 	mov	a,r5
      0077D0 60 29            [24] 1189 	jz	00110$
                                   1190 ;	quantum/action.c:491: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0077D2 12 7C 9C         [24] 1191 	lcall	_ak820_outline_0150
      0077D5 FC               [12] 1192 	mov	r4,a
      0077D6 BC E0 00         [24] 1193 	cjne	r4,#0xe0,00440$
      0077D9                       1194 00440$:
      0077D9 40 07            [24] 1195 	jc	00108$
      0077DB 12 7C 9C         [24] 1196 	lcall	_ak820_outline_0150
      0077DE 24 18            [12] 1197 	add	a,#0xff - 0xe7
      0077E0 50 0A            [24] 1198 	jnc	00104$
                                   1199 ;	free result
      0077E2                       1200 00108$:
      0077E2 7B 64            [12] 1201 	mov	r3,#_process_action_PARM_2
      0077E4 7C 08            [12] 1202 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077E6 12 36 75         [24] 1203 	lcall	_ak820_outline_0122
      0077E9 E0               [24] 1204 	movx	a,@dptr
      0077EA 70 07            [24] 1205 	jnz	00105$
      0077EC                       1206 00104$:
                                   1207 ;	quantum/action.c:495: add_owned_mods(mods);
      0077EC 8D 82            [24] 1208 	mov	dpl, r5
      0077EE 12 81 E9         [24] 1209 	lcall	_add_owned_mods
      0077F1 80 05            [24] 1210 	sjmp	00106$
      0077F3                       1211 00105$:
                                   1212 ;	quantum/action.c:497: add_owned_weak_mods(mods);
      0077F3 8D 82            [24] 1213 	mov	dpl, r5
      0077F5 12 82 05         [24] 1214 	lcall	_add_owned_weak_mods
      0077F8                       1215 00106$:
                                   1216 ;	quantum/action.c:499: send_keyboard_report();
      0077F8 12 85 22         [24] 1217 	lcall	_send_keyboard_report
      0077FB                       1218 00110$:
                                   1219 ;	quantum/action.c:501: register_code(action.key.code);
      0077FB 12 7C 64         [24] 1220 	lcall	_ak820_outline_0078
      0077FE 12 7A 34         [24] 1221 	lcall	_register_code
      007801 02 7A 1D         [24] 1222 	ljmp	00181$
      007804                       1223 00119$:
                                   1224 ;	quantum/action.c:503: unregister_code(action.key.code);
      007804 12 7C 64         [24] 1225 	lcall	_ak820_outline_0078
      007807 C0 05            [24] 1226 	push	ar5
      007809 12 7A B9         [24] 1227 	lcall	_unregister_code
      00780C D0 05            [24] 1228 	pop	ar5
                                   1229 ;	quantum/action.c:504: if (mods) {
      00780E ED               [12] 1230 	mov	a,r5
      00780F 70 03            [24] 1231 	jnz	00444$
      007811 02 7A 1D         [24] 1232 	ljmp	00181$
      007814                       1233 00444$:
                                   1234 ;	quantum/action.c:505: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007814 12 7C 9C         [24] 1235 	lcall	_ak820_outline_0150
      007817 FC               [12] 1236 	mov	r4,a
      007818 BC E0 00         [24] 1237 	cjne	r4,#0xe0,00445$
      00781B                       1238 00445$:
      00781B 40 07            [24] 1239 	jc	00115$
      00781D 12 7C 9C         [24] 1240 	lcall	_ak820_outline_0150
      007820 24 18            [12] 1241 	add	a,#0xff - 0xe7
      007822 50 0A            [24] 1242 	jnc	00111$
                                   1243 ;	free result
      007824                       1244 00115$:
      007824 7B 64            [12] 1245 	mov	r3,#_process_action_PARM_2
      007826 7C 08            [12] 1246 	mov	r4,#(_process_action_PARM_2 >> 8)
      007828 12 36 75         [24] 1247 	lcall	_ak820_outline_0122
      00782B E0               [24] 1248 	movx	a,@dptr
      00782C 70 07            [24] 1249 	jnz	00112$
      00782E                       1250 00111$:
                                   1251 ;	quantum/action.c:506: del_owned_mods(mods);
      00782E 8D 82            [24] 1252 	mov	dpl, r5
      007830 12 81 F8         [24] 1253 	lcall	_del_owned_mods
      007833 80 05            [24] 1254 	sjmp	00113$
      007835                       1255 00112$:
                                   1256 ;	quantum/action.c:508: del_owned_weak_mods(mods);
      007835 8D 82            [24] 1257 	mov	dpl, r5
      007837 12 82 14         [24] 1258 	lcall	_del_owned_weak_mods
      00783A                       1259 00113$:
                                   1260 ;	quantum/action.c:510: send_keyboard_report();
      00783A 12 85 22         [24] 1261 	lcall	_send_keyboard_report
                                   1262 ;	quantum/action.c:513: } break;
      00783D 02 7A 1D         [24] 1263 	ljmp	00181$
                                   1264 ;	quantum/action.c:590: case ACT_USAGE:
      007840                       1265 00123$:
                                   1266 ;	quantum/action.c:596: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007840 74 07            [12] 1267 	mov	a,#0x07
      007842 12 3A 9F         [24] 1268 	lcall	_ak820_outline_0022
      007845 12 4A 8D         [24] 1269 	lcall	_ak820_outline_0008
      007848 C3               [12] 1270 	clr	c
      007849 EC               [12] 1271 	mov	a,r4
      00784A 94 A5            [12] 1272 	subb	a,#0xa5
      00784C ED               [12] 1273 	mov	a,r5
      00784D 94 00            [12] 1274 	subb	a,#0x00
      00784F 40 15            [24] 1275 	jc	00125$
      007851 74 C2            [12] 1276 	mov	a,#0xc2
      007853 9C               [12] 1277 	subb	a,r4
      007854 E4               [12] 1278 	clr	a
      007855 9D               [12] 1279 	subb	a,r5
      007856 40 0E            [24] 1280 	jc	00125$
                                   1281 ;	free result
                                   1282 ;	quantum/action.c:597: owned_usage_key((uint8_t)record->keycode, pressed);
      007858 90 0A C5         [24] 1283 	mov	dptr,#_owned_usage_key_PARM_2
      00785B E5 27            [12] 1284 	mov	a,_process_action_sloc0_1_0
      00785D F0               [24] 1285 	movx	@dptr,a
      00785E 8E 82            [24] 1286 	mov	dpl, r6
      007860 12 83 CF         [24] 1287 	lcall	_owned_usage_key
                                   1288 ;	quantum/action.c:598: break;
      007863 02 7A 1D         [24] 1289 	ljmp	00181$
      007866                       1290 00125$:
                                   1291 ;	quantum/action.c:601: switch (action.usage.page) {
      007866 12 7C 6B         [24] 1292 	lcall	_ak820_outline_0090
      007869 FF               [12] 1293 	mov	r7,a
      00786A 60 08            [24] 1294 	jz	00127$
      00786C BF 01 02         [24] 1295 	cjne	r7,#0x01,00452$
      00786F 80 19            [24] 1296 	sjmp	00128$
      007871                       1297 00452$:
      007871 02 7A 1D         [24] 1298 	ljmp	00181$
                                   1299 ;	quantum/action.c:602: case PAGE_SYSTEM:
      007874                       1300 00127$:
                                   1301 ;	quantum/action.c:603: host_system_send(pressed ? action.usage.code : 0);
      007874 E5 27            [12] 1302 	mov	a,_process_action_sloc0_1_0
      007876 60 05            [24] 1303 	jz	00196$
      007878 12 7C 7B         [24] 1304 	lcall	_ak820_outline_0131
      00787B 80 04            [24] 1305 	sjmp	00197$
      00787D                       1306 00196$:
      00787D 7E 00            [12] 1307 	mov	r6,#0x00
      00787F 7F 00            [12] 1308 	mov	r7,#0x00
      007881                       1309 00197$:
      007881 12 3A FA         [24] 1310 	lcall	_ak820_outline_0118
      007884 12 71 E3         [24] 1311 	lcall	_host_system_send
                                   1312 ;	quantum/action.c:604: break;
      007887 02 7A 1D         [24] 1313 	ljmp	00181$
                                   1314 ;	quantum/action.c:605: case PAGE_CONSUMER:
      00788A                       1315 00128$:
                                   1316 ;	quantum/action.c:606: host_consumer_send(pressed ? action.usage.code : 0);
      00788A E5 27            [12] 1317 	mov	a,_process_action_sloc0_1_0
      00788C 60 05            [24] 1318 	jz	00198$
      00788E 12 7C 7B         [24] 1319 	lcall	_ak820_outline_0131
      007891 80 04            [24] 1320 	sjmp	00199$
      007893                       1321 00198$:
      007893 7E 00            [12] 1322 	mov	r6,#0x00
      007895 7F 00            [12] 1323 	mov	r7,#0x00
      007897                       1324 00199$:
      007897 12 3A FA         [24] 1325 	lcall	_ak820_outline_0118
      00789A 12 72 12         [24] 1326 	lcall	_host_consumer_send
                                   1327 ;	quantum/action.c:609: break;
      00789D 02 7A 1D         [24] 1328 	ljmp	00181$
                                   1329 ;	quantum/action.c:612: case ACT_MOUSEKEY:
      0078A0                       1330 00130$:
                                   1331 ;	quantum/action.c:613: register_mouse(action.key.code, pressed);
      0078A0 12 7C 9C         [24] 1332 	lcall	_ak820_outline_0150
      0078A3 FF               [12] 1333 	mov	r7,a
      0078A4 90 08 62         [24] 1334 	mov	dptr,#_register_mouse_PARM_2
      0078A7 E5 27            [12] 1335 	mov	a,_process_action_sloc0_1_0
      0078A9 F0               [24] 1336 	movx	@dptr,a
      0078AA 8F 82            [24] 1337 	mov	dpl, r7
      0078AC 12 77 47         [24] 1338 	lcall	_register_mouse
                                   1339 ;	quantum/action.c:614: break;
      0078AF 02 7A 1D         [24] 1340 	ljmp	00181$
                                   1341 ;	quantum/action.c:616: case ACT_LAYER: {
      0078B2                       1342 00131$:
                                   1343 ;	quantum/action.c:617: uint8_t on = action.layer_bitop.on;
      0078B2 90 08 65         [24] 1344 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078B5 E0               [24] 1345 	movx	a,@dptr
      0078B6 54 03            [12] 1346 	anl	a,#0x03
      0078B8 90 08 69         [24] 1347 	mov	dptr,#_process_action_on_40000_685
      0078BB F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/action.c:620: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0078BC E0               [24] 1350 	movx	a,@dptr
      0078BD FF               [12] 1351 	mov	r7,a
      0078BE 60 11            [24] 1352 	jz	00200$
      0078C0 E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      0078C2 60 07            [24] 1354 	jz	00202$
      0078C4 8F 06            [24] 1355 	mov	ar6,r7
      0078C6 53 06 01         [24] 1356 	anl	ar6,#0x01
      0078C9 80 10            [24] 1357 	sjmp	00201$
      0078CB                       1358 00202$:
      0078CB 74 02            [12] 1359 	mov	a,#0x02
      0078CD 5F               [12] 1360 	anl	a,r7
      0078CE FE               [12] 1361 	mov	r6,a
      0078CF 80 0A            [24] 1362 	sjmp	00201$
      0078D1                       1363 00200$:
      0078D1 E5 27            [12] 1364 	mov	a,_process_action_sloc0_1_0
      0078D3 B4 01 00         [24] 1365 	cjne	a,#0x01,00457$
      0078D6                       1366 00457$:
      0078D6 92 20            [24] 1367 	mov  _process_action_sloc1_1_0,c
      0078D8 E4               [12] 1368 	clr	a
      0078D9 33               [12] 1369 	rlc	a
      0078DA FE               [12] 1370 	mov	r6,a
      0078DB                       1371 00201$:
      0078DB EE               [12] 1372 	mov	a,r6
      0078DC 70 03            [24] 1373 	jnz	00458$
      0078DE 02 7A 1D         [24] 1374 	ljmp	00181$
      0078E1                       1375 00458$:
                                   1376 ;	quantum/action.c:621: uint8_t shift = action.layer_bitop.part * 4;
      0078E1 12 7C 9C         [24] 1377 	lcall	_ak820_outline_0150
      0078E4 C4               [12] 1378 	swap	a
      0078E5 03               [12] 1379 	rr	a
      0078E6 54 07            [12] 1380 	anl	a,#0x07
      0078E8 25 E0            [12] 1381 	add	a,acc
      0078EA 25 E0            [12] 1382 	add	a,acc
      0078EC FF               [12] 1383 	mov	r7,a
                                   1384 ;	quantum/action.c:622: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0078ED 12 7C 9C         [24] 1385 	lcall	_ak820_outline_0150
      0078F0 54 0F            [12] 1386 	anl	a,#0x0f
      0078F2 FE               [12] 1387 	mov	r6,a
      0078F3 8F F0            [24] 1388 	mov	b,r7
      0078F5 05 F0            [12] 1389 	inc	b
      0078F7 EE               [12] 1390 	mov	a,r6
      0078F8 80 02            [24] 1391 	sjmp	00460$
      0078FA                       1392 00459$:
      0078FA 25 E0            [12] 1393 	add	a,acc
      0078FC                       1394 00460$:
      0078FC D5 F0 FB         [24] 1395 	djnz	b,00459$
      0078FF FE               [12] 1396 	mov	r6,a
                                   1397 ;	quantum/action.c:623: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007900 12 7C 9C         [24] 1398 	lcall	_ak820_outline_0150
      007903 30 E4 11         [24] 1399 	jnb	acc.4,00204$
      007906 8F F0            [24] 1400 	mov	b,r7
      007908 05 F0            [12] 1401 	inc	b
      00790A 74 0F            [12] 1402 	mov	a,#0x0f
      00790C 80 02            [24] 1403 	sjmp	00463$
      00790E                       1404 00462$:
      00790E 25 E0            [12] 1405 	add	a,acc
      007910                       1406 00463$:
      007910 D5 F0 FB         [24] 1407 	djnz	b,00462$
      007913 F4               [12] 1408 	cpl	a
      007914 FF               [12] 1409 	mov	r7,a
      007915 80 02            [24] 1410 	sjmp	00205$
      007917                       1411 00204$:
      007917 7F 00            [12] 1412 	mov	r7,#0x00
      007919                       1413 00205$:
                                   1414 ;	quantum/action.c:624: bits |= mask;
      007919 EE               [12] 1415 	mov	a,r6
      00791A 42 07            [12] 1416 	orl	ar7,a
                                   1417 ;	quantum/action.c:625: if (!on) {
      00791C 90 08 69         [24] 1418 	mov	dptr,#_process_action_on_40000_685
      00791F E0               [24] 1419 	movx	a,@dptr
      007920 70 31            [24] 1420 	jnz	00143$
                                   1421 ;	quantum/action.c:626: switch (action.layer_bitop.op) {
      007922 12 7C 6B         [24] 1422 	lcall	_ak820_outline_0090
      007925 FE               [12] 1423 	mov	r6,a
      007926 2E               [12] 1424 	add	a,r6
                                   1425 ;	quantum/action.c:627: case OP_BIT_AND: default_layer_and(bits); break;
      007927 90 79 2B         [24] 1426 	mov	dptr,#00465$
      00792A 73               [24] 1427 	jmp	@a+dptr
      00792B                       1428 00465$:
      00792B 80 06            [24] 1429 	sjmp	00132$
      00792D 80 0C            [24] 1430 	sjmp	00133$
      00792F 80 12            [24] 1431 	sjmp	00134$
      007931 80 18            [24] 1432 	sjmp	00135$
      007933                       1433 00132$:
      007933 8F 82            [24] 1434 	mov	dpl, r7
      007935 12 7C F0         [24] 1435 	lcall	_default_layer_and
      007938 02 7A 1D         [24] 1436 	ljmp	00181$
                                   1437 ;	quantum/action.c:628: case OP_BIT_OR: default_layer_or(bits); break;
      00793B                       1438 00133$:
      00793B 8F 82            [24] 1439 	mov	dpl, r7
      00793D 12 7C E0         [24] 1440 	lcall	_default_layer_or
      007940 02 7A 1D         [24] 1441 	ljmp	00181$
                                   1442 ;	quantum/action.c:629: case OP_BIT_XOR: default_layer_xor(bits); break;
      007943                       1443 00134$:
      007943 8F 82            [24] 1444 	mov	dpl, r7
      007945 12 7D 05         [24] 1445 	lcall	_default_layer_xor
      007948 02 7A 1D         [24] 1446 	ljmp	00181$
                                   1447 ;	quantum/action.c:630: case OP_BIT_SET: default_layer_set(bits); break;
      00794B                       1448 00135$:
      00794B 8F 82            [24] 1449 	mov	dpl, r7
      00794D 12 7C D6         [24] 1450 	lcall	_default_layer_set
                                   1451 ;	quantum/action.c:631: }
      007950 02 7A 1D         [24] 1452 	ljmp	00181$
      007953                       1453 00143$:
                                   1454 ;	quantum/action.c:633: switch (action.layer_bitop.op) {
      007953 12 7C 6B         [24] 1455 	lcall	_ak820_outline_0090
      007956 FE               [12] 1456 	mov	r6,a
      007957 2E               [12] 1457 	add	a,r6
                                   1458 ;	quantum/action.c:634: case OP_BIT_AND: layer_and(bits); break;
      007958 90 79 5C         [24] 1459 	mov	dptr,#00466$
      00795B 73               [24] 1460 	jmp	@a+dptr
      00795C                       1461 00466$:
      00795C 80 06            [24] 1462 	sjmp	00137$
      00795E 80 0C            [24] 1463 	sjmp	00138$
      007960 80 12            [24] 1464 	sjmp	00139$
      007962 80 18            [24] 1465 	sjmp	00140$
      007964                       1466 00137$:
      007964 8F 82            [24] 1467 	mov	dpl, r7
      007966 12 7E 7D         [24] 1468 	lcall	_layer_and
      007969 02 7A 1D         [24] 1469 	ljmp	00181$
                                   1470 ;	quantum/action.c:635: case OP_BIT_OR: layer_or(bits); break;
      00796C                       1471 00138$:
      00796C 8F 82            [24] 1472 	mov	dpl, r7
      00796E 12 7E 6D         [24] 1473 	lcall	_layer_or
      007971 02 7A 1D         [24] 1474 	ljmp	00181$
                                   1475 ;	quantum/action.c:636: case OP_BIT_XOR: layer_xor(bits); break;
      007974                       1476 00139$:
      007974 8F 82            [24] 1477 	mov	dpl, r7
      007976 12 7E 92         [24] 1478 	lcall	_layer_xor
      007979 02 7A 1D         [24] 1479 	ljmp	00181$
                                   1480 ;	quantum/action.c:637: case OP_BIT_SET: layer_state_set(bits); break;
      00797C                       1481 00140$:
      00797C 8F 82            [24] 1482 	mov	dpl, r7
      00797E 12 7E 0F         [24] 1483 	lcall	_layer_state_set
                                   1484 ;	quantum/action.c:641: break;
      007981 02 7A 1D         [24] 1485 	ljmp	00181$
                                   1486 ;	quantum/action.c:643: case ACT_LAYER_MODS:
      007984                       1487 00147$:
                                   1488 ;	quantum/action.c:644: if (pressed) {
      007984 E5 27            [12] 1489 	mov	a,_process_action_sloc0_1_0
      007986 60 11            [24] 1490 	jz	00149$
                                   1491 ;	quantum/action.c:645: layer_hold_on(action.layer_mods.layer);
      007988 12 7C 74         [24] 1492 	lcall	_ak820_outline_0112
      00798B F5 82            [12] 1493 	mov	dpl,a
      00798D 12 7D 73         [24] 1494 	lcall	_layer_hold_on
                                   1495 ;	quantum/action.c:646: register_mods(action.layer_mods.mods);
      007990 12 7C 64         [24] 1496 	lcall	_ak820_outline_0078
      007993 12 7B 81         [24] 1497 	lcall	_register_mods
      007996 02 7A 1D         [24] 1498 	ljmp	00181$
      007999                       1499 00149$:
                                   1500 ;	quantum/action.c:648: unregister_mods(action.layer_mods.mods);
      007999 12 7C 64         [24] 1501 	lcall	_ak820_outline_0078
      00799C 12 7B 95         [24] 1502 	lcall	_unregister_mods
                                   1503 ;	quantum/action.c:649: layer_hold_off(action.layer_mods.layer);
      00799F 12 7C 74         [24] 1504 	lcall	_ak820_outline_0112
      0079A2 F5 82            [12] 1505 	mov	dpl,a
      0079A4 12 7D AA         [24] 1506 	lcall	_layer_hold_off
                                   1507 ;	quantum/action.c:651: break;
      0079A7 02 7A 1D         [24] 1508 	ljmp	00181$
                                   1509 ;	quantum/action.c:653: case ACT_LAYER_TAP_EXT:
      0079AA                       1510 00152$:
                                   1511 ;	quantum/action.c:654: switch (action.layer_tap.code) {
      0079AA 12 7C 9C         [24] 1512 	lcall	_ak820_outline_0150
      0079AD FF               [12] 1513 	mov	r7,a
      0079AE BF F1 02         [24] 1514 	cjne	r7,#0xf1,00468$
      0079B1 80 0A            [24] 1515 	sjmp	00154$
      0079B3                       1516 00468$:
      0079B3 BF F2 02         [24] 1517 	cjne	r7,#0xf2,00469$
      0079B6 80 19            [24] 1518 	sjmp	00155$
      0079B8                       1519 00469$:
                                   1520 ;	quantum/action.c:670: momentary_layer_action:
      0079B8 BF F3 3B         [24] 1521 	cjne	r7,#0xf3,00160$
      0079BB 80 28            [24] 1522 	sjmp	00156$
      0079BD                       1523 00154$:
                                   1524 ;	quantum/action.c:671: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0079BD E5 27            [12] 1525 	mov	a,_process_action_sloc0_1_0
      0079BF 60 08            [24] 1526 	jz	00206$
      0079C1 12 7C 4A         [24] 1527 	lcall	_ak820_outline_0042
      0079C4 12 7D 73         [24] 1528 	lcall	_layer_hold_on
      0079C7 80 54            [24] 1529 	sjmp	00181$
      0079C9                       1530 00206$:
      0079C9 12 7C 4A         [24] 1531 	lcall	_ak820_outline_0042
      0079CC 12 7D AA         [24] 1532 	lcall	_layer_hold_off
                                   1533 ;	quantum/action.c:672: break;
                                   1534 ;	quantum/action.c:673: case OP_OFF_ON:
      0079CF 80 4C            [24] 1535 	sjmp	00181$
      0079D1                       1536 00155$:
                                   1537 ;	quantum/action.c:674: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0079D1 E5 27            [12] 1538 	mov	a,_process_action_sloc0_1_0
      0079D3 60 08            [24] 1539 	jz	00208$
      0079D5 12 7C 4A         [24] 1540 	lcall	_ak820_outline_0042
      0079D8 12 7E 50         [24] 1541 	lcall	_layer_off
      0079DB 80 40            [24] 1542 	sjmp	00181$
      0079DD                       1543 00208$:
      0079DD 12 7C 4A         [24] 1544 	lcall	_ak820_outline_0042
      0079E0 12 7E 36         [24] 1545 	lcall	_layer_on
                                   1546 ;	quantum/action.c:675: break;
                                   1547 ;	quantum/action.c:676: case OP_SET_CLEAR:
      0079E3 80 38            [24] 1548 	sjmp	00181$
      0079E5                       1549 00156$:
                                   1550 ;	quantum/action.c:677: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0079E5 E5 27            [12] 1551 	mov	a,_process_action_sloc0_1_0
      0079E7 60 08            [24] 1552 	jz	00210$
      0079E9 12 7C 4A         [24] 1553 	lcall	_ak820_outline_0042
      0079EC 12 7E 21         [24] 1554 	lcall	_layer_move
      0079EF 80 2C            [24] 1555 	sjmp	00181$
      0079F1                       1556 00210$:
      0079F1 12 7E 1C         [24] 1557 	lcall	_layer_clear
                                   1558 ;	quantum/action.c:678: break;
                                   1559 ;	quantum/action.c:724: default:
      0079F4 80 27            [24] 1560 	sjmp	00181$
      0079F6                       1561 00160$:
                                   1562 ;	quantum/action.c:731: if (pressed) {
      0079F6 E5 27            [12] 1563 	mov	a,_process_action_sloc0_1_0
      0079F8 60 08            [24] 1564 	jz	00163$
                                   1565 ;	quantum/action.c:733: register_code(action.layer_tap.code);
      0079FA 12 7C 64         [24] 1566 	lcall	_ak820_outline_0078
      0079FD 12 7A 34         [24] 1567 	lcall	_register_code
                                   1568 ;	quantum/action.c:735: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007A00 80 1B            [24] 1569 	sjmp	00181$
      007A02                       1570 00163$:
                                   1571 ;	quantum/action.c:736: if (action.layer_tap.code == KC_CAPS) {
      007A02 12 7C 9C         [24] 1572 	lcall	_ak820_outline_0150
      007A05 FF               [12] 1573 	mov	r7,a
      007A06 BF 39 0E         [24] 1574 	cjne	r7,#0x39,00175$
                                   1575 ;	quantum/action.c:737: wait_ms(TAP_HOLD_CAPS_DELAY);
      007A09 7F 50            [12] 1576 	mov	r7,#0x50
      007A0B                       1577 00187$:
      007A0B EF               [12] 1578 	mov	a,r7
      007A0C 60 09            [24] 1579 	jz	00175$
      007A0E 90 00 01         [24] 1580 	mov	dptr,#0x0001
      007A11 12 5D 8B         [24] 1581 	lcall	_mDelaymS
      007A14 1F               [12] 1582 	dec	r7
                                   1583 ;	quantum/action.c:739: wait_ms(TAP_CODE_DELAY);
      007A15 80 F4            [24] 1584 	sjmp	00187$
      007A17                       1585 00175$:
                                   1586 ;	quantum/action.c:741: unregister_code(action.layer_tap.code);
      007A17 12 7C 64         [24] 1587 	lcall	_ak820_outline_0078
      007A1A 12 7A B9         [24] 1588 	lcall	_unregister_code
                                   1589 ;	quantum/action.c:824: }
      007A1D                       1590 00181$:
                                   1591 ;	quantum/action.c:845: switch (action.kind.id) {
      007A1D 90 08 65         [24] 1592 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007A20 E0               [24] 1593 	movx	a,@dptr
      007A21 C4               [12] 1594 	swap	a
      007A22 54 0F            [12] 1595 	anl	a,#0x0f
      007A24 FF               [12] 1596 	mov	r7,a
      007A25 BF 08 02         [24] 1597 	cjne	r7,#0x08,00478$
      007A28 80 03            [24] 1598 	sjmp	00183$
      007A2A                       1599 00478$:
      007A2A BF 09 06         [24] 1600 	cjne	r7,#0x09,00192$
                                   1601 ;	quantum/action.c:847: case ACT_LAYER_MODS:
      007A2D                       1602 00183$:
                                   1603 ;	quantum/action.c:852: led_set(host_keyboard_leds());
      007A2D 12 71 48         [24] 1604 	lcall	_host_keyboard_leds
                                   1605 ;	quantum/action.c:856: }
                                   1606 ;	quantum/action.c:909: }
      007A30 02 9C 25         [24] 1607 	ljmp	_led_set
      007A33                       1608 00192$:
      007A33 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'register_code'
                                   1612 ;------------------------------------------------------------
                                   1613 ;code          Allocated with name '_register_code_code_10000_719'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:915: __attribute__((weak)) void register_code(uint8_t code) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function register_code
                                   1618 ;	-----------------------------------------
      007A34                       1619 _register_code:
      007A34 E5 82            [12] 1620 	mov	a,dpl
      007A36 90 08 6A         [24] 1621 	mov	dptr,#_register_code_code_10000_719
      007A39 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:916: if (code == KC_NO) {
      007A3A E0               [24] 1624 	movx	a,@dptr
      007A3B FF               [12] 1625 	mov	r7,a
      007A3C 70 01            [24] 1626 	jnz	00123$
                                   1627 ;	quantum/action.c:917: return;
      007A3E 22               [24] 1628 	ret
      007A3F                       1629 00123$:
                                   1630 ;	quantum/action.c:952: } else if (IS_BASIC_KEYCODE(code)) {
      007A3F BF 04 00         [24] 1631 	cjne	r7,#0x04,00198$
      007A42                       1632 00198$:
      007A42 40 12            [24] 1633 	jc	00119$
      007A44 EF               [12] 1634 	mov	a,r7
      007A45 24 5B            [12] 1635 	add	a,#0xff - 0xa4
      007A47 40 0D            [24] 1636 	jc	00119$
                                   1637 ;	free result
                                   1638 ;	quantum/action.c:957: if (!add_owned_key(code)) return;
      007A49 8F 82            [24] 1639 	mov	dpl, r7
      007A4B 12 82 88         [24] 1640 	lcall	_add_owned_key
      007A4E E5 82            [12] 1641 	mov	a, dpl
      007A50 70 01            [24] 1642 	jnz	00104$
      007A52 22               [24] 1643 	ret
      007A53                       1644 00104$:
                                   1645 ;	quantum/action.c:968: send_keyboard_report();
      007A53 02 85 22         [24] 1646 	ljmp	_send_keyboard_report
      007A56                       1647 00119$:
                                   1648 ;	quantum/action.c:969: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A56 12 7C 86         [24] 1649 	lcall	_ak820_outline_0139
      007A59 BF E0 00         [24] 1650 	cjne	r7,#0xe0,00202$
      007A5C                       1651 00202$:
      007A5C 40 1A            [24] 1652 	jc	00115$
      007A5E EF               [12] 1653 	mov	a,r7
      007A5F 24 18            [12] 1654 	add	a,#0xff - 0xe7
      007A61 40 15            [24] 1655 	jc	00115$
                                   1656 ;	free result
                                   1657 ;	quantum/action.c:970: add_owned_mods(MOD_BIT(code));
      007A63 74 07            [12] 1658 	mov	a,#0x07
      007A65 5F               [12] 1659 	anl	a,r7
      007A66 12 7C 53         [24] 1660 	lcall	_ak820_outline_0063
      007A69 80 02            [24] 1661 	sjmp	00206$
      007A6B                       1662 00205$:
      007A6B 25 E0            [12] 1663 	add	a,acc
      007A6D                       1664 00206$:
      007A6D D5 F0 FB         [24] 1665 	djnz	b,00205$
      007A70 F5 82            [12] 1666 	mov	dpl,a
      007A72 12 81 E9         [24] 1667 	lcall	_add_owned_mods
                                   1668 ;	quantum/action.c:971: send_keyboard_report();
      007A75 02 85 22         [24] 1669 	ljmp	_send_keyboard_report
      007A78                       1670 00115$:
                                   1671 ;	quantum/action.c:974: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A78 12 7C 86         [24] 1672 	lcall	_ak820_outline_0139
      007A7B BF A5 00         [24] 1673 	cjne	r7,#0xa5,00207$
      007A7E                       1674 00207$:
      007A7E 40 05            [24] 1675 	jc	00113$
      007A80 EF               [12] 1676 	mov	a,r7
      007A81 24 58            [12] 1677 	add	a,#0xff - 0xa7
      007A83 50 0D            [24] 1678 	jnc	00108$
                                   1679 ;	free result
      007A85                       1680 00113$:
      007A85 12 7C 86         [24] 1681 	lcall	_ak820_outline_0139
      007A88 BF A8 00         [24] 1682 	cjne	r7,#0xa8,00210$
      007A8B                       1683 00210$:
      007A8B 40 13            [24] 1684 	jc	00109$
      007A8D EF               [12] 1685 	mov	a,r7
      007A8E 24 3D            [12] 1686 	add	a,#0xff - 0xc2
      007A90 40 0E            [24] 1687 	jc	00109$
                                   1688 ;	free result
      007A92                       1689 00108$:
                                   1690 ;	quantum/action.c:976: owned_usage_key(code, true);
      007A92 12 7C 86         [24] 1691 	lcall	_ak820_outline_0139
      007A95 90 0A C5         [24] 1692 	mov	dptr,#_owned_usage_key_PARM_2
      007A98 74 01            [12] 1693 	mov	a,#0x01
      007A9A F0               [24] 1694 	movx	@dptr,a
      007A9B 8F 82            [24] 1695 	mov	dpl, r7
      007A9D 02 83 CF         [24] 1696 	ljmp	_owned_usage_key
      007AA0                       1697 00109$:
                                   1698 ;	quantum/action.c:983: } else if (IS_MOUSE_KEYCODE(code)) {
      007AA0 12 7C 86         [24] 1699 	lcall	_ak820_outline_0139
      007AA3 BF CD 00         [24] 1700 	cjne	r7,#0xcd,00213$
      007AA6                       1701 00213$:
      007AA6 40 10            [24] 1702 	jc	00125$
      007AA8 EF               [12] 1703 	mov	a,r7
      007AA9 24 20            [12] 1704 	add	a,#0xff - 0xdf
      007AAB 40 0B            [24] 1705 	jc	00125$
                                   1706 ;	free result
                                   1707 ;	quantum/action.c:984: register_mouse(code, true);
      007AAD 90 08 62         [24] 1708 	mov	dptr,#_register_mouse_PARM_2
      007AB0 74 01            [12] 1709 	mov	a,#0x01
      007AB2 F0               [24] 1710 	movx	@dptr,a
      007AB3 8F 82            [24] 1711 	mov	dpl, r7
                                   1712 ;	quantum/action.c:986: }
      007AB5 02 77 47         [24] 1713 	ljmp	_register_mouse
      007AB8                       1714 00125$:
      007AB8 22               [24] 1715 	ret
                                   1716 ;------------------------------------------------------------
                                   1717 ;Allocation info for local variables in function 'unregister_code'
                                   1718 ;------------------------------------------------------------
                                   1719 ;code          Allocated with name '_unregister_code_code_10000_733'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/action.c:992: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function unregister_code
                                   1724 ;	-----------------------------------------
      007AB9                       1725 _unregister_code:
      007AB9 E5 82            [12] 1726 	mov	a,dpl
      007ABB 90 08 6B         [24] 1727 	mov	dptr,#_unregister_code_code_10000_733
      007ABE F0               [24] 1728 	movx	@dptr,a
                                   1729 ;	quantum/action.c:993: if (code == KC_NO) {
      007ABF E0               [24] 1730 	movx	a,@dptr
      007AC0 FF               [12] 1731 	mov	r7,a
      007AC1 70 01            [24] 1732 	jnz	00121$
                                   1733 ;	quantum/action.c:994: return;
      007AC3 22               [24] 1734 	ret
      007AC4                       1735 00121$:
                                   1736 ;	quantum/action.c:1026: } else if (IS_BASIC_KEYCODE(code)) {
      007AC4 BF 04 00         [24] 1737 	cjne	r7,#0x04,00196$
      007AC7                       1738 00196$:
      007AC7 40 12            [24] 1739 	jc	00117$
      007AC9 EF               [12] 1740 	mov	a,r7
      007ACA 24 5B            [12] 1741 	add	a,#0xff - 0xa4
      007ACC 40 0D            [24] 1742 	jc	00117$
                                   1743 ;	free result
                                   1744 ;	quantum/action.c:1028: if (!del_owned_key(code)) return;
      007ACE 8F 82            [24] 1745 	mov	dpl, r7
      007AD0 12 83 04         [24] 1746 	lcall	_del_owned_key
      007AD3 E5 82            [12] 1747 	mov	a, dpl
      007AD5 70 01            [24] 1748 	jnz	00102$
      007AD7 22               [24] 1749 	ret
      007AD8                       1750 00102$:
                                   1751 ;	quantum/action.c:1032: send_keyboard_report();
      007AD8 02 85 22         [24] 1752 	ljmp	_send_keyboard_report
      007ADB                       1753 00117$:
                                   1754 ;	quantum/action.c:1033: } else if (IS_MODIFIER_KEYCODE(code)) {
      007ADB 12 7C 8C         [24] 1755 	lcall	_ak820_outline_0140
      007ADE BF E0 00         [24] 1756 	cjne	r7,#0xe0,00200$
      007AE1                       1757 00200$:
      007AE1 40 1A            [24] 1758 	jc	00113$
      007AE3 EF               [12] 1759 	mov	a,r7
      007AE4 24 18            [12] 1760 	add	a,#0xff - 0xe7
      007AE6 40 15            [24] 1761 	jc	00113$
                                   1762 ;	free result
                                   1763 ;	quantum/action.c:1034: del_owned_mods(MOD_BIT(code));
      007AE8 74 07            [12] 1764 	mov	a,#0x07
      007AEA 5F               [12] 1765 	anl	a,r7
      007AEB 12 7C 53         [24] 1766 	lcall	_ak820_outline_0063
      007AEE 80 02            [24] 1767 	sjmp	00204$
      007AF0                       1768 00203$:
      007AF0 25 E0            [12] 1769 	add	a,acc
      007AF2                       1770 00204$:
      007AF2 D5 F0 FB         [24] 1771 	djnz	b,00203$
      007AF5 F5 82            [12] 1772 	mov	dpl,a
      007AF7 12 81 F8         [24] 1773 	lcall	_del_owned_mods
                                   1774 ;	quantum/action.c:1035: send_keyboard_report();
      007AFA 02 85 22         [24] 1775 	ljmp	_send_keyboard_report
      007AFD                       1776 00113$:
                                   1777 ;	quantum/action.c:1038: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007AFD 12 7C 8C         [24] 1778 	lcall	_ak820_outline_0140
      007B00 BF A5 00         [24] 1779 	cjne	r7,#0xa5,00205$
      007B03                       1780 00205$:
      007B03 40 05            [24] 1781 	jc	00111$
      007B05 EF               [12] 1782 	mov	a,r7
      007B06 24 58            [12] 1783 	add	a,#0xff - 0xa7
      007B08 50 0D            [24] 1784 	jnc	00106$
                                   1785 ;	free result
      007B0A                       1786 00111$:
      007B0A 12 7C 8C         [24] 1787 	lcall	_ak820_outline_0140
      007B0D BF A8 00         [24] 1788 	cjne	r7,#0xa8,00208$
      007B10                       1789 00208$:
      007B10 40 11            [24] 1790 	jc	00107$
      007B12 EF               [12] 1791 	mov	a,r7
      007B13 24 3D            [12] 1792 	add	a,#0xff - 0xc2
      007B15 40 0C            [24] 1793 	jc	00107$
                                   1794 ;	free result
      007B17                       1795 00106$:
                                   1796 ;	quantum/action.c:1040: owned_usage_key(code, false);
      007B17 12 7C 8C         [24] 1797 	lcall	_ak820_outline_0140
      007B1A 90 0A C5         [24] 1798 	mov	dptr,#_owned_usage_key_PARM_2
      007B1D 12 7C A6         [24] 1799 	lcall	_ak820_outline_0187
      007B20 02 83 CF         [24] 1800 	ljmp	_owned_usage_key
      007B23                       1801 00107$:
                                   1802 ;	quantum/action.c:1047: } else if (IS_MOUSE_KEYCODE(code)) {
      007B23 12 7C 8C         [24] 1803 	lcall	_ak820_outline_0140
      007B26 BF CD 00         [24] 1804 	cjne	r7,#0xcd,00211$
      007B29                       1805 00211$:
      007B29 40 0E            [24] 1806 	jc	00123$
      007B2B EF               [12] 1807 	mov	a,r7
      007B2C 24 20            [12] 1808 	add	a,#0xff - 0xdf
      007B2E 40 09            [24] 1809 	jc	00123$
                                   1810 ;	free result
                                   1811 ;	quantum/action.c:1048: register_mouse(code, false);
      007B30 90 08 62         [24] 1812 	mov	dptr,#_register_mouse_PARM_2
      007B33 12 7C A6         [24] 1813 	lcall	_ak820_outline_0187
                                   1814 ;	quantum/action.c:1050: }
      007B36 02 77 47         [24] 1815 	ljmp	_register_mouse
      007B39                       1816 00123$:
      007B39 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'tap_code_delay'
                                   1820 ;------------------------------------------------------------
                                   1821 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1822 ;code          Allocated with name '_tap_code_delay_code_10000_746'
                                   1823 ;i             Allocated with name '_tap_code_delay_i_20000_748'
                                   1824 ;i             Allocated with name '_tap_code_delay_i_50000_751'
                                   1825 ;------------------------------------------------------------
                                   1826 ;	quantum/action.c:1057: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1827 ;	-----------------------------------------
                                   1828 ;	 function tap_code_delay
                                   1829 ;	-----------------------------------------
      007B3A                       1830 _tap_code_delay:
      007B3A E5 82            [12] 1831 	mov	a,dpl
      007B3C 90 08 6E         [24] 1832 	mov	dptr,#_tap_code_delay_code_10000_746
      007B3F F0               [24] 1833 	movx	@dptr,a
                                   1834 ;	quantum/action.c:1058: register_code(code);
      007B40 E0               [24] 1835 	movx	a,@dptr
      007B41 FF               [12] 1836 	mov	r7,a
      007B42 F5 82            [12] 1837 	mov	dpl,a
      007B44 C0 07            [24] 1838 	push	ar7
      007B46 51 34            [12] 1839 	acall	_register_code
      007B48 D0 07            [24] 1840 	pop	ar7
                                   1841 ;	quantum/action.c:1059: for (uint16_t i = delay; i > 0; i--) {
      007B4A 90 08 6C         [24] 1842 	mov	dptr,#_tap_code_delay_PARM_2
      007B4D 12 3A D8         [24] 1843 	lcall	_ak820_outline_0080
      007B50                       1844 00110$:
      007B50 ED               [12] 1845 	mov	a,r5
      007B51 4E               [12] 1846 	orl	a,r6
      007B52 60 0D            [24] 1847 	jz	00105$
                                   1848 ;	quantum/action.c:1060: wait_ms(1);
      007B54 90 00 01         [24] 1849 	mov	dptr,#0x0001
      007B57 12 5D 8B         [24] 1850 	lcall	_mDelaymS
                                   1851 ;	quantum/action.c:1059: for (uint16_t i = delay; i > 0; i--) {
      007B5A 1D               [12] 1852 	dec	r5
      007B5B BD FF 01         [24] 1853 	cjne	r5,#0xff,00141$
      007B5E 1E               [12] 1854 	dec	r6
      007B5F                       1855 00141$:
      007B5F 80 EF            [24] 1856 	sjmp	00110$
      007B61                       1857 00105$:
                                   1858 ;	quantum/action.c:1062: unregister_code(code);
      007B61 8F 82            [24] 1859 	mov	dpl, r7
                                   1860 ;	quantum/action.c:1063: }
      007B63 41 B9            [12] 1861 	ajmp	_unregister_code
                                   1862 ;------------------------------------------------------------
                                   1863 ;Allocation info for local variables in function 'tap_code'
                                   1864 ;------------------------------------------------------------
                                   1865 ;code          Allocated with name '_tap_code_code_10000_753'
                                   1866 ;------------------------------------------------------------
                                   1867 ;	quantum/action.c:1069: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1868 ;	-----------------------------------------
                                   1869 ;	 function tap_code
                                   1870 ;	-----------------------------------------
      007B65                       1871 _tap_code:
      007B65 E5 82            [12] 1872 	mov	a,dpl
      007B67 90 08 6F         [24] 1873 	mov	dptr,#_tap_code_code_10000_753
      007B6A F0               [24] 1874 	movx	@dptr,a
                                   1875 ;	quantum/action.c:1070: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B6B E0               [24] 1876 	movx	a,@dptr
      007B6C FF               [12] 1877 	mov	r7,a
      007B6D BF 39 04         [24] 1878 	cjne	r7,#0x39,00103$
      007B70 7E 50            [12] 1879 	mov	r6,#0x50
      007B72 80 02            [24] 1880 	sjmp	00104$
      007B74                       1881 00103$:
      007B74 7E 00            [12] 1882 	mov	r6,#0x00
      007B76                       1883 00104$:
      007B76 90 08 6C         [24] 1884 	mov	dptr,#_tap_code_delay_PARM_2
      007B79 EE               [12] 1885 	mov	a,r6
      007B7A 12 3B 04         [24] 1886 	lcall	_ak820_outline_0124
      007B7D 8F 82            [24] 1887 	mov	dpl, r7
                                   1888 ;	quantum/action.c:1071: }
      007B7F 61 3A            [12] 1889 	ajmp	_tap_code_delay
                                   1890 ;------------------------------------------------------------
                                   1891 ;Allocation info for local variables in function 'register_mods'
                                   1892 ;------------------------------------------------------------
                                   1893 ;mods          Allocated with name '_register_mods_mods_10000_755'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1077: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function register_mods
                                   1898 ;	-----------------------------------------
      007B81                       1899 _register_mods:
      007B81 E5 82            [12] 1900 	mov	a,dpl
      007B83 90 08 70         [24] 1901 	mov	dptr,#_register_mods_mods_10000_755
      007B86 F0               [24] 1902 	movx	@dptr,a
                                   1903 ;	quantum/action.c:1078: if (mods) {
      007B87 E0               [24] 1904 	movx	a,@dptr
      007B88 FF               [12] 1905 	mov	r7,a
      007B89 E0               [24] 1906 	movx	a,@dptr
      007B8A 60 08            [24] 1907 	jz	00103$
                                   1908 ;	quantum/action.c:1079: add_owned_mods(mods);
      007B8C 8F 82            [24] 1909 	mov	dpl, r7
      007B8E 12 81 E9         [24] 1910 	lcall	_add_owned_mods
                                   1911 ;	quantum/action.c:1080: send_keyboard_report();
                                   1912 ;	quantum/action.c:1082: }
      007B91 02 85 22         [24] 1913 	ljmp	_send_keyboard_report
      007B94                       1914 00103$:
      007B94 22               [24] 1915 	ret
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'unregister_mods'
                                   1918 ;------------------------------------------------------------
                                   1919 ;mods          Allocated with name '_unregister_mods_mods_10000_759'
                                   1920 ;------------------------------------------------------------
                                   1921 ;	quantum/action.c:1088: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1922 ;	-----------------------------------------
                                   1923 ;	 function unregister_mods
                                   1924 ;	-----------------------------------------
      007B95                       1925 _unregister_mods:
      007B95 E5 82            [12] 1926 	mov	a,dpl
      007B97 90 08 71         [24] 1927 	mov	dptr,#_unregister_mods_mods_10000_759
      007B9A F0               [24] 1928 	movx	@dptr,a
                                   1929 ;	quantum/action.c:1089: if (mods) {
      007B9B E0               [24] 1930 	movx	a,@dptr
      007B9C FF               [12] 1931 	mov	r7,a
      007B9D E0               [24] 1932 	movx	a,@dptr
      007B9E 60 08            [24] 1933 	jz	00103$
                                   1934 ;	quantum/action.c:1090: del_owned_mods(mods);
      007BA0 8F 82            [24] 1935 	mov	dpl, r7
      007BA2 12 81 F8         [24] 1936 	lcall	_del_owned_mods
                                   1937 ;	quantum/action.c:1091: send_keyboard_report();
                                   1938 ;	quantum/action.c:1093: }
      007BA5 02 85 22         [24] 1939 	ljmp	_send_keyboard_report
      007BA8                       1940 00103$:
      007BA8 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'register_weak_mods'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_register_weak_mods_mods_10000_763'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action.c:1099: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function register_weak_mods
                                   1950 ;	-----------------------------------------
      007BA9                       1951 _register_weak_mods:
      007BA9 E5 82            [12] 1952 	mov	a,dpl
      007BAB 90 08 72         [24] 1953 	mov	dptr,#_register_weak_mods_mods_10000_763
      007BAE F0               [24] 1954 	movx	@dptr,a
                                   1955 ;	quantum/action.c:1100: if (mods) {
      007BAF E0               [24] 1956 	movx	a,@dptr
      007BB0 FF               [12] 1957 	mov	r7,a
      007BB1 E0               [24] 1958 	movx	a,@dptr
      007BB2 60 08            [24] 1959 	jz	00103$
                                   1960 ;	quantum/action.c:1101: add_owned_weak_mods(mods);
      007BB4 8F 82            [24] 1961 	mov	dpl, r7
      007BB6 12 82 05         [24] 1962 	lcall	_add_owned_weak_mods
                                   1963 ;	quantum/action.c:1102: send_keyboard_report();
                                   1964 ;	quantum/action.c:1104: }
      007BB9 02 85 22         [24] 1965 	ljmp	_send_keyboard_report
      007BBC                       1966 00103$:
      007BBC 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1970 ;------------------------------------------------------------
                                   1971 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_767'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function unregister_weak_mods
                                   1976 ;	-----------------------------------------
      007BBD                       1977 _unregister_weak_mods:
      007BBD E5 82            [12] 1978 	mov	a,dpl
      007BBF 90 08 73         [24] 1979 	mov	dptr,#_unregister_weak_mods_mods_10000_767
      007BC2 F0               [24] 1980 	movx	@dptr,a
                                   1981 ;	quantum/action.c:1111: if (mods) {
      007BC3 E0               [24] 1982 	movx	a,@dptr
      007BC4 FF               [12] 1983 	mov	r7,a
      007BC5 E0               [24] 1984 	movx	a,@dptr
      007BC6 60 08            [24] 1985 	jz	00103$
                                   1986 ;	quantum/action.c:1112: del_owned_weak_mods(mods);
      007BC8 8F 82            [24] 1987 	mov	dpl, r7
      007BCA 12 82 14         [24] 1988 	lcall	_del_owned_weak_mods
                                   1989 ;	quantum/action.c:1113: send_keyboard_report();
                                   1990 ;	quantum/action.c:1115: }
      007BCD 02 85 22         [24] 1991 	ljmp	_send_keyboard_report
      007BD0                       1992 00103$:
      007BD0 22               [24] 1993 	ret
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'clear_keyboard'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	quantum/action.c:1121: void clear_keyboard(void) {
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function clear_keyboard
                                   2000 ;	-----------------------------------------
      007BD1                       2001 _clear_keyboard:
                                   2002 ;	quantum/action.c:1122: clear_mods();
      007BD1 12 85 9D         [24] 2003 	lcall	_clear_mods
                                   2004 ;	quantum/action.c:1123: clear_keyboard_but_mods();
                                   2005 ;	quantum/action.c:1124: }
      007BD4 61 D6            [12] 2006 	ajmp	_clear_keyboard_but_mods
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	quantum/action.c:1130: void clear_keyboard_but_mods(void) {
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function clear_keyboard_but_mods
                                   2013 ;	-----------------------------------------
      007BD6                       2014 _clear_keyboard_but_mods:
                                   2015 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007BD6 90 0D F9         [24] 2016 	mov	dptr,#_actual_keyboard_report
      007BD9 75 F0 00         [24] 2017 	mov	b, #0x00
      007BDC 12 74 19         [24] 2018 	lcall	_clear_keys_from_report
                                   2019 ;	quantum/action.c:1132: clear_keyboard_but_mods_and_keys();
                                   2020 ;	quantum/action.c:1133: }
      007BDF 61 E1            [12] 2021 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2022 ;------------------------------------------------------------
                                   2023 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	quantum/action.c:1139: void clear_keyboard_but_mods_and_keys(void) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function clear_keyboard_but_mods_and_keys
                                   2028 ;	-----------------------------------------
      007BE1                       2029 _clear_keyboard_but_mods_and_keys:
                                   2030 ;	quantum/action.c:1141: ak820_tapping_cancel();
      007BE1 12 49 34         [24] 2031 	lcall	_ak820_tapping_cancel
                                   2032 ;	quantum/action.c:1143: ak820_autoshift_cancel();
      007BE4 12 33 78         [24] 2033 	lcall	_ak820_autoshift_cancel
                                   2034 ;	quantum/action.c:1146: ak820_oneshot_cancel();
      007BE7 12 2E F0         [24] 2035 	lcall	_ak820_oneshot_cancel
                                   2036 ;	quantum/action.c:1149: ak820_combo_cancel();
      007BEA 12 37 E5         [24] 2037 	lcall	_ak820_combo_cancel
                                   2038 ;	quantum/action.c:1152: repeat_key_cancel();
      007BED 12 A5 ED         [24] 2039 	lcall	_repeat_key_cancel
                                   2040 ;	quantum/action.c:1154: clear_owned_mods();
      007BF0 12 82 23         [24] 2041 	lcall	_clear_owned_mods
                                   2042 ;	quantum/action.c:1155: clear_owned_keys();
      007BF3 12 82 5B         [24] 2043 	lcall	_clear_owned_keys
                                   2044 ;	quantum/action.c:1156: clear_owned_usages();
      007BF6 12 83 97         [24] 2045 	lcall	_clear_owned_usages
                                   2046 ;	quantum/action.c:1157: layer_hold_clear();
      007BF9 B1 E2            [12] 2047 	acall	_layer_hold_clear
                                   2048 ;	quantum/action.c:1159: clear_macro_tri_layer();
      007BFB 12 A0 CE         [24] 2049 	lcall	_clear_macro_tri_layer
                                   2050 ;	quantum/action_util.h:47: clear_keys_from_report(keyboard_report);
      007BFE 90 0D F9         [24] 2051 	mov	dptr,#_actual_keyboard_report
      007C01 75 F0 00         [24] 2052 	mov	b, #0x00
      007C04 12 74 19         [24] 2053 	lcall	_clear_keys_from_report
                                   2054 ;	quantum/action.c:1164: host_system_send(0);
      007C07 90 00 00         [24] 2055 	mov	dptr,#0x0000
      007C0A 12 71 E3         [24] 2056 	lcall	_host_system_send
                                   2057 ;	quantum/action.c:1165: host_consumer_send(0);
      007C0D 90 00 00         [24] 2058 	mov	dptr,#0x0000
      007C10 12 72 12         [24] 2059 	lcall	_host_consumer_send
                                   2060 ;	quantum/action.c:1167: clear_weak_mods();
      007C13 12 85 D2         [24] 2061 	lcall	_clear_weak_mods
                                   2062 ;	quantum/action.c:1168: send_keyboard_report();
      007C16 12 85 22         [24] 2063 	lcall	_send_keyboard_report
                                   2064 ;	quantum/action.c:1170: mousekey_clear();
      007C19 12 54 21         [24] 2065 	lcall	_mousekey_clear
                                   2066 ;	quantum/action.c:1171: mousekey_send();
                                   2067 ;	quantum/action.c:1176: }
      007C1C 02 52 E9         [24] 2068 	ljmp	_mousekey_send
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'is_tap_record'
                                   2071 ;------------------------------------------------------------
                                   2072 ;record        Allocated with name '_is_tap_record_record_10000_783'
                                   2073 ;action        Allocated with name '_is_tap_record_action_10001_787'
                                   2074 ;------------------------------------------------------------
                                   2075 ;	quantum/action.c:1182: bool is_tap_record(keyrecord_t *record) {
                                   2076 ;	-----------------------------------------
                                   2077 	.area CSEG    (CODE)
                                   2078 	.area CONST   (CODE)
                                   2079 	.area XINIT   (CODE)
      00C584                       2080 __xinit__disable_action_cache:
      00C584 00                    2081 	.db #0x00	;  0
                                   2082 	.area CABS    (ABS,CODE)
                                   2083 
                                   2084 ; Experimental exact instruction outlining.
                                   2085 	.globl _ak820_outline_0001
                                   2086 	.globl _ak820_outline_0005
                                   2087 	.globl _ak820_outline_0007
                                   2088 	.globl _ak820_outline_0008
                                   2089 	.globl _ak820_outline_0011
                                   2090 	.globl _ak820_outline_0012
                                   2091 	.globl _ak820_outline_0013
                                   2092 	.globl _ak820_outline_0014
                                   2093 	.globl _ak820_outline_0016
                                   2094 	.globl _ak820_outline_0021
                                   2095 	.globl _ak820_outline_0022
                                   2096 	.globl _ak820_outline_0034
                                   2097 	.globl _ak820_outline_0036
                                   2098 	.globl _ak820_outline_0042
                                   2099 	.globl _ak820_outline_0050
                                   2100 	.globl _ak820_outline_0059
                                   2101 	.globl _ak820_outline_0063
                                   2102 	.globl _ak820_outline_0071
                                   2103 	.globl _ak820_outline_0072
                                   2104 	.globl _ak820_outline_0074
                                   2105 	.globl _ak820_outline_0078
                                   2106 	.globl _ak820_outline_0080
                                   2107 	.globl _ak820_outline_0090
                                   2108 	.globl _ak820_outline_0107
                                   2109 	.globl _ak820_outline_0108
                                   2110 	.globl _ak820_outline_0110
                                   2111 	.globl _ak820_outline_0111
                                   2112 	.globl _ak820_outline_0112
                                   2113 	.globl _ak820_outline_0118
                                   2114 	.globl _ak820_outline_0122
                                   2115 	.globl _ak820_outline_0123
                                   2116 	.globl _ak820_outline_0124
                                   2117 	.globl _ak820_outline_0125
                                   2118 	.globl _ak820_outline_0131
                                   2119 	.globl _ak820_outline_0139
                                   2120 	.globl _ak820_outline_0140
                                   2121 	.globl _ak820_outline_0143
                                   2122 	.globl _ak820_outline_0147
                                   2123 	.globl _ak820_outline_0150
                                   2124 	.globl _ak820_outline_0151
                                   2125 	.globl _ak820_outline_0161
                                   2126 	.globl _ak820_outline_0182
                                   2127 	.globl _ak820_outline_0185
                                   2128 	.globl _ak820_outline_0187
                                   2129 
                                   2130 	.area CSEG (CODE)
                                   2131 ; function ak820_outline_0013
      007C1F                       2132 _ak820_outline_0013:
      007C1F 2D               [12] 2133 	add	a,r5
      007C20 F9               [12] 2134 	mov	r1,a
      007C21 E4               [12] 2135 	clr	a
      007C22 3E               [12] 2136 	addc	a,r6
      007C23 FA               [12] 2137 	mov	r2,a
      007C24 8F 03            [24] 2138 	mov	ar3,r7
      007C26 89 82            [24] 2139 	mov	dpl,r1
      007C28 8A 83            [24] 2140 	mov	dph,r2
      007C2A 8B F0            [24] 2141 	mov	b,r3
      007C2C 22               [24] 2142 	ret
                                   2143 
                                   2144 	.area CSEG (CODE)
                                   2145 ; function ak820_outline_0014
      007C2D                       2146 _ak820_outline_0014:
      007C2D 2D               [12] 2147 	add	a,r5
      007C2E FA               [12] 2148 	mov	r2,a
      007C2F E4               [12] 2149 	clr	a
      007C30 3E               [12] 2150 	addc	a,r6
      007C31 FB               [12] 2151 	mov	r3,a
      007C32 8F 04            [24] 2152 	mov	ar4,r7
      007C34 8A 82            [24] 2153 	mov	dpl,r2
      007C36 8B 83            [24] 2154 	mov	dph,r3
      007C38 8C F0            [24] 2155 	mov	b,r4
      007C3A 22               [24] 2156 	ret
                                   2157 
                                   2158 	.area CSEG (CODE)
                                   2159 ; function ak820_outline_0021
      007C3B                       2160 _ak820_outline_0021:
      007C3B 8E 82            [24] 2161 	mov	dpl,r6
      007C3D 8F 83            [24] 2162 	mov	dph,r7
      007C3F A3               [24] 2163 	inc	dptr
      007C40 E0               [24] 2164 	movx	a,@dptr
      007C41 FC               [12] 2165 	mov	r4,a
      007C42 7D 00            [12] 2166 	mov	r5,#0x00
      007C44 8E 82            [24] 2167 	mov	dpl,r6
      007C46 8F 83            [24] 2168 	mov	dph,r7
      007C48 E0               [24] 2169 	movx	a,@dptr
      007C49 22               [24] 2170 	ret
                                   2171 
                                   2172 	.area CSEG (CODE)
                                   2173 ; function ak820_outline_0042
      007C4A                       2174 _ak820_outline_0042:
      007C4A 90 08 65         [24] 2175 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C4D E0               [24] 2176 	movx	a,@dptr
      007C4E 54 1F            [12] 2177 	anl	a,#0x1f
      007C50 F5 82            [12] 2178 	mov	dpl,a
      007C52 22               [24] 2179 	ret
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0063
      007C53                       2183 _ak820_outline_0063:
      007C53 F5 F0            [12] 2184 	mov	b,a
      007C55 05 F0            [12] 2185 	inc	b
      007C57 74 01            [12] 2186 	mov	a,#0x01
      007C59 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0071
      007C5A                       2191 _ak820_outline_0071:
      007C5A 90 0D D6         [24] 2192 	mov	dptr,#___memcpy_PARM_3
      007C5D 74 06            [12] 2193 	mov	a,#0x06
      007C5F F0               [24] 2194 	movx	@dptr,a
      007C60 E4               [12] 2195 	clr	a
      007C61 A3               [24] 2196 	inc	dptr
      007C62 F0               [24] 2197 	movx	@dptr,a
      007C63 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0078
      007C64                       2202 _ak820_outline_0078:
      007C64 90 08 64         [24] 2203 	mov	dptr,#_process_action_PARM_2
      007C67 E0               [24] 2204 	movx	a,@dptr
      007C68 F5 82            [12] 2205 	mov	dpl,a
      007C6A 22               [24] 2206 	ret
                                   2207 
                                   2208 	.area CSEG (CODE)
                                   2209 ; function ak820_outline_0090
      007C6B                       2210 _ak820_outline_0090:
      007C6B 90 08 65         [24] 2211 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C6E E0               [24] 2212 	movx	a,@dptr
      007C6F 03               [12] 2213 	rr	a
      007C70 03               [12] 2214 	rr	a
      007C71 54 03            [12] 2215 	anl	a,#0x03
      007C73 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0112
      007C74                       2220 _ak820_outline_0112:
      007C74 90 08 65         [24] 2221 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C77 E0               [24] 2222 	movx	a,@dptr
      007C78 54 0F            [12] 2223 	anl	a,#0x0f
      007C7A 22               [24] 2224 	ret
                                   2225 
                                   2226 	.area CSEG (CODE)
                                   2227 ; function ak820_outline_0131
      007C7B                       2228 _ak820_outline_0131:
      007C7B 90 08 64         [24] 2229 	mov	dptr,#_process_action_PARM_2
      007C7E E0               [24] 2230 	movx	a,@dptr
      007C7F FE               [12] 2231 	mov	r6,a
      007C80 A3               [24] 2232 	inc	dptr
      007C81 E0               [24] 2233 	movx	a,@dptr
      007C82 54 03            [12] 2234 	anl	a,#0x03
      007C84 FF               [12] 2235 	mov	r7,a
      007C85 22               [24] 2236 	ret
                                   2237 
                                   2238 	.area CSEG (CODE)
                                   2239 ; function ak820_outline_0139
      007C86                       2240 _ak820_outline_0139:
      007C86 90 08 6A         [24] 2241 	mov	dptr,#_register_code_code_10000_719
      007C89 E0               [24] 2242 	movx	a,@dptr
      007C8A FF               [12] 2243 	mov	r7,a
      007C8B 22               [24] 2244 	ret
                                   2245 
                                   2246 	.area CSEG (CODE)
                                   2247 ; function ak820_outline_0140
      007C8C                       2248 _ak820_outline_0140:
      007C8C 90 08 6B         [24] 2249 	mov	dptr,#_unregister_code_code_10000_733
      007C8F E0               [24] 2250 	movx	a,@dptr
      007C90 FF               [12] 2251 	mov	r7,a
      007C91 22               [24] 2252 	ret
                                   2253 
                                   2254 	.area CSEG (CODE)
                                   2255 ; function ak820_outline_0147
      007C92                       2256 _ak820_outline_0147:
      007C92 74 07            [12] 2257 	mov	a,#0x07
      007C94 2D               [12] 2258 	add	a,r5
      007C95 F8               [12] 2259 	mov	r0,a
      007C96 E4               [12] 2260 	clr	a
      007C97 3E               [12] 2261 	addc	a,r6
      007C98 F9               [12] 2262 	mov	r1,a
      007C99 8F 02            [24] 2263 	mov	ar2,r7
      007C9B 22               [24] 2264 	ret
                                   2265 
                                   2266 	.area CSEG (CODE)
                                   2267 ; function ak820_outline_0150
      007C9C                       2268 _ak820_outline_0150:
      007C9C 90 08 64         [24] 2269 	mov	dptr,#_process_action_PARM_2
      007C9F E0               [24] 2270 	movx	a,@dptr
      007CA0 22               [24] 2271 	ret
                                   2272 
                                   2273 	.area CSEG (CODE)
                                   2274 ; function ak820_outline_0185
      007CA1                       2275 _ak820_outline_0185:
      007CA1 F0               [24] 2276 	movx	@dptr,a
      007CA2 EB               [12] 2277 	mov	a,r3
      007CA3 A3               [24] 2278 	inc	dptr
      007CA4 F0               [24] 2279 	movx	@dptr,a
      007CA5 22               [24] 2280 	ret
                                   2281 
                                   2282 	.area CSEG (CODE)
                                   2283 ; function ak820_outline_0187
      007CA6                       2284 _ak820_outline_0187:
      007CA6 E4               [12] 2285 	clr	a
      007CA7 F0               [24] 2286 	movx	@dptr,a
      007CA8 8F 82            [24] 2287 	mov	dpl,r7
      007CAA 22               [24] 2288 	ret
