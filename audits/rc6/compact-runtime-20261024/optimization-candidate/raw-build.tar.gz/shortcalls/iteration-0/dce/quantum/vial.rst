                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000045                        541 _vial_handle_cmd_sloc0_1_0:
      000045                        542 	.ds 2
      000047                        543 _vial_handle_cmd_sloc1_1_0:
      000047                        544 	.ds 2
      000049                        545 _vial_handle_cmd_sloc2_1_0:
      000049                        546 	.ds 2
      00004B                        547 _vial_handle_cmd_sloc3_1_0:
      00004B                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C89                        573 _vial_unlock_timer:
      000C89                        574 	.ds 4
      000C8D                        575 _vial_unlock_holding:
      000C8D                        576 	.ds 1
      000C8E                        577 _vial_keycode_firewall_in_10000_610:
      000C8E                        578 	.ds 2
      000C90                        579 _vial_fill_packet_PARM_2:
      000C90                        580 	.ds 1
      000C91                        581 _vial_fill_packet_msg_10000_613:
      000C91                        582 	.ds 2
      000C93                        583 _vial_handle_cmd_PARM_2:
      000C93                        584 	.ds 1
      000C94                        585 _vial_handle_cmd_data_10000_618:
      000C94                        586 	.ds 3
      000C97                        587 _vial_handle_cmd_entry_70000_646:
      000C97                        588 	.ds 10
      000CA1                        589 _vial_handle_cmd_entry_70000_647:
      000CA1                        590 	.ds 10
      000CAB                        591 _g_vial_magic_keycode_override::
      000CAB                        592 	.ds 2
      000CAD                        593 _vial_keycode_down_keycode_10000_649:
      000CAD                        594 	.ds 2
      000CAF                        595 _vial_keycode_down_dummy_event_30000_656:
      000CAF                        596 	.ds 6
      000CB5                        597 _vial_keycode_up_keycode_10000_657:
      000CB5                        598 	.ds 2
      000CB7                        599 _vial_keycode_up_dummy_event_30000_664:
      000CB7                        600 	.ds 6
      000CBD                        601 _vial_keycode_tap_keycode_10000_665:
      000CBD                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E54                        611 _vial_unlocked::
      000E54                        612 	.ds 1
      000E55                        613 _vial_unlock_in_progress::
      000E55                        614 	.ds 1
      000E56                        615 _vial_unlock_counter:
      000E56                        616 	.ds 1
      000E57                        617 _vial_unlock_combo_rows:
      000E57                        618 	.ds 2
      000E59                        619 _vial_unlock_combo_cols:
      000E59                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00B0FC                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B0FC 90 0E 55         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00B0FF E0               [24]  667 	movx	a,@dptr
      00B100 70 01            [24]  668 	jnz	00131$
      00B102 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B103                        671 00131$:
      00B103 7F 00            [12]  672 	mov	r7,#0x00
      00B105                        673 00115$:
      00B105 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00B108                        675 00184$:
      00B108 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B10A EF               [12]  678 	mov	a,r7
      00B10B 12 B6 BC         [24]  679 	lcall	_ak820_outline_0128
      00B10E FE               [12]  680 	mov	r6,a
      00B10F EF               [12]  681 	mov	a,r7
      00B110 12 B6 B1         [24]  682 	lcall	_ak820_outline_0127
      00B113 90 07 85         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00B116 F0               [24]  684 	movx	@dptr,a
      00B117 8E 82            [24]  685 	mov	dpl, r6
      00B119 C0 07            [24]  686 	push	ar7
      00B11B 12 5E 1D         [24]  687 	lcall	_matrix_is_on
      00B11E E5 82            [12]  688 	mov	a, dpl
      00B120 D0 07            [24]  689 	pop	ar7
      00B122 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B124 90 0C 8D         [24]  692 	mov	dptr,#_vial_unlock_holding
      00B127 E4               [12]  693 	clr	a
      00B128 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B129 90 0E 56         [24]  696 	mov	dptr,#_vial_unlock_counter
      00B12C 74 1E            [12]  697 	mov	a,#0x1e
      00B12E F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00B12F 22               [24]  700 	ret
      00B130                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B130 0F               [12]  703 	inc	r7
      00B131 80 D2            [24]  704 	sjmp	00115$
      00B133                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B133 90 0C 8D         [24]  707 	mov	dptr,#_vial_unlock_holding
      00B136 E0               [24]  708 	movx	a,@dptr
      00B137 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B139 90 0C 8D         [24]  711 	mov	dptr,#_vial_unlock_holding
      00B13C 74 01            [12]  712 	mov	a,#0x01
      00B13E F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B13F 12 4B 6C         [24]  715 	lcall	_timer_read32
      00B142 12 51 A7         [24]  716 	lcall	_ak820_outline_0057
      00B145 90 0C 89         [24]  717 	mov	dptr,#_vial_unlock_timer
      00B148 12 94 F3         [24]  718 	lcall	_ak820_outline_0006
      00B14B                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B14B 90 0C 89         [24]  721 	mov	dptr,#_vial_unlock_timer
      00B14E 12 51 96         [24]  722 	lcall	_ak820_outline_0055
      00B151 12 4B C5         [24]  723 	lcall	_timer_elapsed32
      00B154 12 51 A7         [24]  724 	lcall	_ak820_outline_0057
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B157 7B 1E            [12]  726 	mov	r3,#0x1e
      00B159                        727 00109$:
      00B159 EB               [12]  728 	mov	a,r3
      00B15A 60 22            [24]  729 	jz	00111$
      00B15C C3               [12]  730 	clr	c
      00B15D EC               [12]  731 	mov	a,r4
      00B15E 94 64            [12]  732 	subb	a,#0x64
      00B160 ED               [12]  733 	mov	a,r5
      00B161 94 00            [12]  734 	subb	a,#0x00
      00B163 EE               [12]  735 	mov	a,r6
      00B164 94 00            [12]  736 	subb	a,#0x00
      00B166 EF               [12]  737 	mov	a,r7
      00B167 94 00            [12]  738 	subb	a,#0x00
      00B169 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B16B EC               [12]  741 	mov	a,r4
      00B16C 24 9C            [12]  742 	add	a,#0x9c
      00B16E FC               [12]  743 	mov	r4,a
      00B16F ED               [12]  744 	mov	a,r5
      00B170 34 FF            [12]  745 	addc	a,#0xff
      00B172 FD               [12]  746 	mov	r5,a
      00B173 EE               [12]  747 	mov	a,r6
      00B174 34 FF            [12]  748 	addc	a,#0xff
      00B176 FE               [12]  749 	mov	r6,a
      00B177 EF               [12]  750 	mov	a,r7
      00B178 34 FF            [12]  751 	addc	a,#0xff
      00B17A FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00B17B 1B               [12]  754 	dec	r3
      00B17C 80 DB            [24]  755 	sjmp	00109$
      00B17E                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B17E 90 0E 56         [24]  758 	mov	dptr,#_vial_unlock_counter
      00B181 EB               [12]  759 	mov	a,r3
      00B182 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00B183 EB               [12]  762 	mov	a,r3
      00B184 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B186 90 0E 55         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00B189 E4               [12]  766 	clr	a
      00B18A F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B18B 90 0E 54         [24]  769 	mov	dptr,#_vial_unlocked
      00B18E 04               [12]  770 	inc	a
      00B18F F0               [24]  771 	movx	@dptr,a
      00B190                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00B190 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:108: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00B191                        782 _vial_init:
                                    783 ;	quantum/vial.c:113: reload_combo();
                                    784 ;	quantum/vial.c:118: }
      00B191 02 37 F5         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00B194                        795 _vial_keycode_firewall:
      00B194 12 3A F0         [24]  796 	lcall	_ak820_outline_0107
      00B197 90 0C 8E         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00B19A 12 3A F5         [24]  798 	lcall	_ak820_outline_0108
                                    799 ;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
      00B19D 90 0C 8E         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00B1A0 12 4A 8D         [24]  801 	lcall	_ak820_outline_0008
      00B1A3 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00B1A6 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00B1A9 90 0E 54         [24]  804 	mov	dptr,#_vial_unlocked
      00B1AC E0               [24]  805 	movx	a,@dptr
      00B1AD 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:122: return 0;
      00B1AF 90 00 00         [24]  808 	mov	dptr,#0x0000
      00B1B2 22               [24]  809 	ret
      00B1B3                        810 00102$:
                                    811 ;	quantum/vial.c:123: return in;
      00B1B3 12 3A FA         [24]  812 	lcall	_ak820_outline_0118
                                    813 ;	quantum/vial.c:124: }
      00B1B6 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00B1B7                        826 _vial_fill_packet:
      00B1B7 12 3A F0         [24]  827 	lcall	_ak820_outline_0107
      00B1BA 90 0C 91         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00B1BD 12 3A F5         [24]  829 	lcall	_ak820_outline_0108
                                    830 ;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B1C0 90 0C 91         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00B1C3 12 3A AF         [24]  832 	lcall	_ak820_outline_0052
      00B1C6 90 0C 90         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1C9 E0               [24]  834 	movx	a,@dptr
      00B1CA FD               [12]  835 	mov	r5,a
      00B1CB 7C 00            [12]  836 	mov	r4,#0x00
      00B1CD                        837 00103$:
      00B1CD BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00B1D0                        839 00122$:
      00B1D0 50 09            [24]  840 	jnc	00105$
      00B1D2 EC               [12]  841 	mov	a,r4
      00B1D3 12 3A 9F         [24]  842 	lcall	_ak820_outline_0022
      00B1D6 ED               [12]  843 	mov	a,r5
      00B1D7 F0               [24]  844 	movx	@dptr,a
      00B1D8 0C               [12]  845 	inc	r4
      00B1D9 80 F2            [24]  846 	sjmp	00103$
      00B1DB                        847 00105$:
                                    848 ;	quantum/vial.c:129: }
      00B1DB 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:140: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00B1DC                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:162: repeat_key_cancel();
      00B1DC 12 A5 ED         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:164: clear_keyboard();
                                    861 ;	quantum/vial.c:165: }
      00B1DF 02 7B D1         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00B1E2                        893 _vial_handle_cmd:
      00B1E2 12 45 7B         [24]  894 	lcall	_ak820_outline_0036
      00B1E5 90 0C 94         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00B1E8 12 3A 8D         [24]  896 	lcall	_ak820_outline_0016
                                    897 ;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B1EB 90 0C 94         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00B1EE 12 3A AF         [24]  899 	lcall	_ak820_outline_0052
                                    900 ;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
      00B1F1 90 0C 93         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B1F4 E0               [24]  902 	movx	a,@dptr
      00B1F5 FD               [12]  903 	mov	r5,a
      00B1F6 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00B1F9 80 01            [24]  905 	sjmp	00102$
      00B1FB                        906 00258$:
                                    907 ;	quantum/vial.c:178: return;
      00B1FB 22               [24]  908 	ret
      00B1FC                        909 00102$:
                                    910 ;	quantum/vial.c:181: switch (msg[1]) {
      00B1FC 74 01            [12]  911 	mov	a,#0x01
      00B1FE 12 4A D7         [24]  912 	lcall	_ak820_outline_0033
      00B201 FB               [12]  913 	mov  r3,a
      00B202 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00B204 50 01            [24]  915 	jnc	00259$
      00B206 22               [24]  916 	ret
      00B207                        917 00259$:
                                    918 ;	free result
      00B207 EB               [12]  919 	mov	a,r3
      00B208 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00B20A 83               [24]  921 	movc	a,@a+pc
      00B20B F5 82            [12]  922 	mov	dpl,a
      00B20D EB               [12]  923 	mov	a,r3
      00B20E 24 12            [12]  924 	add	a,#(00261$-3-.)
      00B210 83               [24]  925 	movc	a,@a+pc
      00B211 F5 83            [12]  926 	mov	dph,a
      00B213 E4               [12]  927 	clr	a
      00B214 73               [24]  928 	jmp	@a+dptr
      00B215                        929 00260$:
      00B215 31                     930 	.db	00103$
      00B216 79                     931 	.db	00105$
      00B217 8D                     932 	.db	00106$
      00B218 19                     933 	.db	00112$
      00B219 9F                     934 	.db	00113$
      00B21A EA                     935 	.db	00114$
      00B21B 59                     936 	.db	00116$
      00B21C 74                     937 	.db	00119$
      00B21D 94                     938 	.db	00120$
      00B21E A2                     939 	.db	00121$
      00B21F AE                     940 	.db	00139$
      00B220 AE                     941 	.db	00139$
      00B221 AE                     942 	.db	00139$
      00B222 AD                     943 	.db	00122$
      00B223                        944 00261$:
      00B223 B2                     945 	.db	00103$>>8
      00B224 B2                     946 	.db	00105$>>8
      00B225 B2                     947 	.db	00106$>>8
      00B226 B3                     948 	.db	00112$>>8
      00B227 B3                     949 	.db	00113$>>8
      00B228 B3                     950 	.db	00114$>>8
      00B229 B4                     951 	.db	00116$>>8
      00B22A B4                     952 	.db	00119$>>8
      00B22B B4                     953 	.db	00120$>>8
      00B22C B4                     954 	.db	00121$>>8
      00B22D B5                     955 	.db	00139$>>8
      00B22E B5                     956 	.db	00139$>>8
      00B22F B5                     957 	.db	00139$>>8
      00B230 B4                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:183: case vial_get_keyboard_id: {
      00B231                        960 00103$:
                                    961 ;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
      00B231 90 0C 90         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00B234 E4               [12]  963 	clr	a
      00B235 12 45 A6         [24]  964 	lcall	_ak820_outline_0079
      00B238 C0 07            [24]  965 	push	ar7
      00B23A C0 06            [24]  966 	push	ar6
      00B23C 12 B1 B7         [24]  967 	lcall	_vial_fill_packet
      00B23F D0 06            [24]  968 	pop	ar6
      00B241 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B243 12 3A FA         [24]  971 	lcall	_ak820_outline_0118
      00B246 74 06            [12]  972 	mov	a,#0x06
      00B248 12 45 A6         [24]  973 	lcall	_ak820_outline_0079
                                    974 ;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B24B A3               [24]  975 	inc	dptr
      00B24C E4               [12]  976 	clr	a
      00B24D 12 45 73         [24]  977 	lcall	_ak820_outline_0031
                                    978 ;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B250 12 45 73         [24]  979 	lcall	_ak820_outline_0031
                                    980 ;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B253 A3               [24]  981 	inc	dptr
      00B254 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B255 FB               [12]  984 	mov	r3,a
      00B256                        985 00131$:
      00B256 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00B259                        987 00262$:
      00B259 50 15            [24]  988 	jnc	00104$
      00B25B 8B 02            [24]  989 	mov	ar2,r3
      00B25D 74 04            [12]  990 	mov	a,#0x04
      00B25F 2A               [12]  991 	add	a, r2
      00B260 2E               [12]  992 	add	a, r6
      00B261 F9               [12]  993 	mov	r1,a
      00B262 E4               [12]  994 	clr	a
      00B263 3F               [12]  995 	addc	a,r7
      00B264 FA               [12]  996 	mov	r2,a
      00B265 EB               [12]  997 	mov	a,r3
      00B266 90 C3 64         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00B269 93               [24]  999 	movc	a,@a+dptr
      00B26A 12 71 20         [24] 1000 	lcall	_ak820_outline_0137
      00B26D 0B               [12] 1001 	inc	r3
      00B26E 80 E6            [24] 1002 	sjmp	00131$
      00B270                       1003 00104$:
                                   1004 ;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B270 74 0C            [12] 1005 	mov	a,#0x0c
      00B272 12 3A 9F         [24] 1006 	lcall	_ak820_outline_0022
      00B275 74 01            [12] 1007 	mov	a,#0x01
      00B277 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:195: break;
      00B278 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:198: case vial_get_size: {
      00B279                       1012 00105$:
                                   1013 ;	quantum/vial.c:200: msg[0] = sz & 0xFF;
      00B279 12 3A FA         [24] 1014 	lcall	_ak820_outline_0118
      00B27C 74 7C            [12] 1015 	mov	a,#0x7c
      00B27E 12 3A E4         [24] 1016 	lcall	_ak820_outline_0096
                                   1017 ;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
      00B281 74 01            [12] 1018 	mov	a,#0x01
      00B283 12 45 73         [24] 1019 	lcall	_ak820_outline_0031
                                   1020 ;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
      00B286 E4               [12] 1021 	clr	a
      00B287 12 45 73         [24] 1022 	lcall	_ak820_outline_0031
                                   1023 ;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
      00B28A A3               [24] 1024 	inc	dptr
      00B28B F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:204: break;
      00B28C 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:207: case vial_get_def: {
      00B28D                       1029 00106$:
                                   1030 ;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
      00B28D 12 B0 C7         [24] 1031 	lcall	_ak820_outline_0023
      00B290 E0               [24] 1032 	movx	a,@dptr
      00B291 FB               [12] 1033 	mov	r3,a
      00B292 12 45 69         [24] 1034 	lcall	_ak820_outline_0011
      00B295 E0               [24] 1035 	movx	a,@dptr
      00B296 4B               [12] 1036 	orl	a,r3
      00B297 60 01            [24] 1037 	jz	00108$
      00B299 22               [24] 1038 	ret
      00B29A                       1039 00108$:
                                   1040 ;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B29A 12 3A A7         [24] 1041 	lcall	_ak820_outline_0037
      00B29D FB               [12] 1042 	mov	r3,a
      00B29E 7A 00            [12] 1043 	mov	r2,#0x00
      00B2A0 12 B0 BE         [24] 1044 	lcall	_ak820_outline_0018
      00B2A3 F9               [12] 1045 	mov	r1,a
      00B2A4 E4               [12] 1046 	clr	a
      00B2A5 42 03            [12] 1047 	orl	ar3,a
      00B2A7 E9               [12] 1048 	mov	a,r1
      00B2A8 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B2AA C3               [12] 1051 	clr	c
      00B2AB EB               [12] 1052 	mov	a,r3
      00B2AC 94 0C            [12] 1053 	subb	a,#0x0c
      00B2AE EA               [12] 1054 	mov	a,r2
      00B2AF 94 00            [12] 1055 	subb	a,#0x00
      00B2B1 40 01            [24] 1056 	jc	00110$
      00B2B3 22               [24] 1057 	ret
      00B2B4                       1058 00110$:
                                   1059 ;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B2B4 EA               [12] 1060 	mov	a,r2
      00B2B5 C4               [12] 1061 	swap	a
      00B2B6 23               [12] 1062 	rl	a
      00B2B7 54 E0            [12] 1063 	anl	a,#0xe0
      00B2B9 CB               [12] 1064 	xch	a,r3
      00B2BA C4               [12] 1065 	swap	a
      00B2BB 23               [12] 1066 	rl	a
      00B2BC CB               [12] 1067 	xch	a,r3
      00B2BD 6B               [12] 1068 	xrl	a,r3
      00B2BE CB               [12] 1069 	xch	a,r3
      00B2BF 54 E0            [12] 1070 	anl	a,#0xe0
      00B2C1 CB               [12] 1071 	xch	a,r3
      00B2C2 6B               [12] 1072 	xrl	a,r3
      00B2C3 FA               [12] 1073 	mov	r2,a
      00B2C4 8B 45            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B2C6 8A 46            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B2C8 74 7C            [12] 1077 	mov	a,#0x7c
      00B2CA C3               [12] 1078 	clr	c
      00B2CB 95 45            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B2CD F8               [12] 1080 	mov	r0,a
      00B2CE 74 01            [12] 1081 	mov	a,#0x01
      00B2D0 95 46            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B2D2 F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B2D3 C3               [12] 1085 	clr	c
      00B2D4 E8               [12] 1086 	mov	a,r0
      00B2D5 94 20            [12] 1087 	subb	a,#0x20
      00B2D7 E9               [12] 1088 	mov	a,r1
      00B2D8 94 00            [12] 1089 	subb	a,#0x00
      00B2DA 40 02            [24] 1090 	jc	00142$
      00B2DC 78 20            [12] 1091 	mov	r0,#0x20
      00B2DE                       1092 00142$:
                                   1093 ;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B2DE 79 00            [12] 1094 	mov	r1,#0x00
      00B2E0                       1095 00134$:
      00B2E0 C3               [12] 1096 	clr	c
      00B2E1 E9               [12] 1097 	mov	a,r1
      00B2E2 98               [12] 1098 	subb	a,r0
      00B2E3 40 01            [24] 1099 	jc	00267$
      00B2E5 22               [24] 1100 	ret
      00B2E6                       1101 00267$:
      00B2E6 C0 00            [24] 1102 	push	ar0
      00B2E8 E9               [12] 1103 	mov	a,r1
      00B2E9 2E               [12] 1104 	add	a, r6
      00B2EA F5 47            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B2EC E4               [12] 1106 	clr	a
      00B2ED 3F               [12] 1107 	addc	a, r7
      00B2EE F5 48            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B2F0 89 49            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B2F2 75 4A 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B2F5 A8 45            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B2F7 AB 46            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B2F9 E5 49            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B2FB 28               [12] 1114 	add	a, r0
      00B2FC F8               [12] 1115 	mov	r0,a
      00B2FD E5 4A            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B2FF 3B               [12] 1117 	addc	a, r3
      00B300 FB               [12] 1118 	mov	r3,a
      00B301 E8               [12] 1119 	mov	a,r0
      00B302 24 E8            [12] 1120 	add	a, #_keyboard_definition
      00B304 F5 82            [12] 1121 	mov	dpl,a
      00B306 EB               [12] 1122 	mov	a,r3
      00B307 34 C1            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00B309 F5 83            [12] 1124 	mov	dph,a
      00B30B E4               [12] 1125 	clr	a
      00B30C 93               [24] 1126 	movc	a,@a+dptr
      00B30D 85 47 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B310 85 48 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B313 F0               [24] 1129 	movx	@dptr,a
      00B314 09               [12] 1130 	inc	r1
      00B315 D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:234: case vial_get_encoder: {
      00B317 80 C7            [24] 1133 	sjmp	00134$
      00B319                       1134 00112$:
                                   1135 ;	quantum/vial.c:235: uint8_t layer = msg[2];
      00B319 74 02            [12] 1136 	mov	a,#0x02
      00B31B 12 4A CC         [24] 1137 	lcall	_ak820_outline_0032
      00B31E F5 49            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:236: uint8_t idx = msg[3];
      00B320 74 03            [12] 1140 	mov	a,#0x03
      00B322 2E               [12] 1141 	add	a, r6
      00B323 F5 47            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B325 E4               [12] 1143 	clr	a
      00B326 3F               [12] 1144 	addc	a, r7
      00B327 F5 48            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B329 85 47 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B32C 85 48 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B32F E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B330 F5 45            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B332 90 0B 17         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B335 F0               [24] 1152 	movx	@dptr,a
      00B336 90 0B 18         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B339 E4               [12] 1154 	clr	a
      00B33A F0               [24] 1155 	movx	@dptr,a
      00B33B 85 49 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B33E C0 07            [24] 1157 	push	ar7
      00B340 C0 06            [24] 1158 	push	ar6
      00B342 C0 05            [24] 1159 	push	ar5
      00B344 C0 04            [24] 1160 	push	ar4
      00B346 C0 03            [24] 1161 	push	ar3
      00B348 C0 02            [24] 1162 	push	ar2
      00B34A 12 89 BA         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00B34D 85 82 4B         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B350 85 83 4C         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B353 D0 02            [24] 1166 	pop	ar2
      00B355 D0 03            [24] 1167 	pop	ar3
      00B357 D0 04            [24] 1168 	pop	ar4
      00B359 D0 05            [24] 1169 	pop	ar5
      00B35B D0 06            [24] 1170 	pop	ar6
      00B35D D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:238: msg[0]  = keycode >> 8;
      00B35F A9 4C            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B361 12 3A FA         [24] 1174 	lcall	_ak820_outline_0118
      00B364 E9               [12] 1175 	mov	a,r1
      00B365 F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
      00B366 A8 4B            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B368 12 3A FF         [24] 1179 	lcall	_ak820_outline_0123
      00B36B E8               [12] 1180 	mov	a,r0
      00B36C F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B36D 90 0B 17         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B370 E5 45            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B372 F0               [24] 1185 	movx	@dptr,a
      00B373 90 0B 18         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B376 74 01            [12] 1187 	mov	a,#0x01
      00B378 F0               [24] 1188 	movx	@dptr,a
      00B379 85 49 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B37C C0 03            [24] 1190 	push	ar3
      00B37E C0 02            [24] 1191 	push	ar2
      00B380 12 89 BA         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00B383 85 82 4B         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B386 85 83 4C         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B389 D0 02            [24] 1195 	pop	ar2
      00B38B D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:241: msg[2] = keycode >> 8;
      00B38D A9 4C            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B38F 12 3B 1A         [24] 1199 	lcall	_ak820_outline_0144
      00B392 E9               [12] 1200 	mov	a,r1
      00B393 F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
      00B394 A8 4B            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B396 85 47 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B399 85 48 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B39C E8               [12] 1206 	mov	a,r0
      00B39D F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:243: break;
      00B39E 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:245: case vial_set_encoder: {
      00B39F                       1211 00113$:
                                   1212 ;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B39F 12 3A A7         [24] 1213 	lcall	_ak820_outline_0037
      00B3A2 F5 47            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3A4 12 B0 BE         [24] 1215 	lcall	_ak820_outline_0018
      00B3A7 F5 49            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B3A9 12 B0 C7         [24] 1217 	lcall	_ak820_outline_0023
      00B3AC E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00B3AD 24 FF            [12] 1220 	add	a,#0xff
      00B3AF E4               [12] 1221 	clr	a
      00B3B0 33               [12] 1222 	rlc	a
      00B3B1 F5 4B            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B3B3 12 45 69         [24] 1224 	lcall	_ak820_outline_0011
      00B3B6 E0               [24] 1225 	movx	a,@dptr
      00B3B7 F9               [12] 1226 	mov	r1,a
      00B3B8 78 00            [12] 1227 	mov	r0,#0x00
      00B3BA 74 06            [12] 1228 	mov	a,#0x06
      00B3BC 12 3A 9F         [24] 1229 	lcall	_ak820_outline_0022
      00B3BF E0               [24] 1230 	movx	a,@dptr
      00B3C0 7B 00            [12] 1231 	mov	r3,#0x00
      00B3C2 42 00            [12] 1232 	orl	ar0,a
      00B3C4 EB               [12] 1233 	mov	a,r3
      00B3C5 42 01            [12] 1234 	orl	ar1,a
      00B3C7 12 3B 24         [24] 1235 	lcall	_ak820_outline_0161
      00B3CA 12 B1 94         [24] 1236 	lcall	_vial_keycode_firewall
      00B3CD AA 82            [24] 1237 	mov	r2, dpl
      00B3CF AB 83            [24] 1238 	mov	r3, dph
      00B3D1 90 0B 1A         [24] 1239 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B3D4 E5 49            [12] 1240 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B3D6 F0               [24] 1241 	movx	@dptr,a
      00B3D7 90 0B 1B         [24] 1242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B3DA E5 4B            [12] 1243 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B3DC F0               [24] 1244 	movx	@dptr,a
      00B3DD 90 0B 1C         [24] 1245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B3E0 EA               [12] 1246 	mov	a,r2
      00B3E1 12 7C A1         [24] 1247 	lcall	_ak820_outline_0185
      00B3E4 85 47 82         [24] 1248 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1249 ;	quantum/vial.c:247: break;
      00B3E7 02 8A 20         [24] 1250 	ljmp	_dynamic_keymap_set_encoder
                                   1251 ;	quantum/vial.c:250: case vial_get_unlock_status: {
      00B3EA                       1252 00114$:
                                   1253 ;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B3EA 90 0C 90         [24] 1254 	mov	dptr,#_vial_fill_packet_PARM_2
      00B3ED 74 FF            [12] 1255 	mov	a,#0xff
      00B3EF 12 45 A6         [24] 1256 	lcall	_ak820_outline_0079
      00B3F2 C0 07            [24] 1257 	push	ar7
      00B3F4 C0 06            [24] 1258 	push	ar6
      00B3F6 12 B1 B7         [24] 1259 	lcall	_vial_fill_packet
      00B3F9 D0 06            [24] 1260 	pop	ar6
      00B3FB D0 07            [24] 1261 	pop	ar7
                                   1262 ;	quantum/vial.c:254: msg[0] = vial_unlocked;
      00B3FD 90 0E 54         [24] 1263 	mov	dptr,#_vial_unlocked
      00B400 E0               [24] 1264 	movx	a,@dptr
      00B401 12 3A FA         [24] 1265 	lcall	_ak820_outline_0118
      00B404 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
      00B405 74 01            [12] 1268 	mov	a,#0x01
      00B407 2E               [12] 1269 	add	a, r6
      00B408 FA               [12] 1270 	mov	r2,a
      00B409 E4               [12] 1271 	clr	a
      00B40A 3F               [12] 1272 	addc	a, r7
      00B40B FB               [12] 1273 	mov	r3,a
      00B40C 90 0E 55         [24] 1274 	mov	dptr,#_vial_unlock_in_progress
      00B40F E0               [24] 1275 	movx	a,@dptr
      00B410 12 3B 1A         [24] 1276 	lcall	_ak820_outline_0144
      00B413 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B414 7B 00            [12] 1279 	mov	r3,#0x00
      00B416                       1280 00137$:
      00B416 BB 02 00         [24] 1281 	cjne	r3,#0x02,00268$
      00B419                       1282 00268$:
      00B419 40 01            [24] 1283 	jc	00269$
      00B41B 22               [24] 1284 	ret
      00B41C                       1285 00269$:
                                   1286 ;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B41C 8B 01            [24] 1287 	mov	ar1,r3
      00B41E 7A 00            [12] 1288 	mov	r2,#0x00
      00B420 E9               [12] 1289 	mov	a,r1
      00B421 29               [12] 1290 	add	a,r1
      00B422 F5 4B            [12] 1291 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B424 EA               [12] 1292 	mov	a,r2
      00B425 33               [12] 1293 	rlc	a
      00B426 F5 4C            [12] 1294 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B428 74 02            [12] 1295 	mov	a,#0x02
      00B42A 25 4B            [12] 1296 	add	a, _vial_handle_cmd_sloc3_1_0
      00B42C F8               [12] 1297 	mov	r0,a
      00B42D E4               [12] 1298 	clr	a
      00B42E 35 4C            [12] 1299 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B430 FA               [12] 1300 	mov	r2,a
      00B431 E8               [12] 1301 	mov	a,r0
      00B432 2E               [12] 1302 	add	a, r6
      00B433 F8               [12] 1303 	mov	r0,a
      00B434 EA               [12] 1304 	mov	a,r2
      00B435 3F               [12] 1305 	addc	a, r7
      00B436 FA               [12] 1306 	mov	r2,a
      00B437 EB               [12] 1307 	mov	a,r3
      00B438 12 B6 BC         [24] 1308 	lcall	_ak820_outline_0128
      00B43B 88 82            [24] 1309 	mov	dpl,r0
      00B43D 8A 83            [24] 1310 	mov	dph,r2
      00B43F F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B440 74 03            [12] 1313 	mov	a,#0x03
      00B442 25 4B            [12] 1314 	add	a, _vial_handle_cmd_sloc3_1_0
      00B444 F9               [12] 1315 	mov	r1,a
      00B445 E4               [12] 1316 	clr	a
      00B446 35 4C            [12] 1317 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B448 FA               [12] 1318 	mov	r2,a
      00B449 E9               [12] 1319 	mov	a,r1
      00B44A 2E               [12] 1320 	add	a, r6
      00B44B F9               [12] 1321 	mov	r1,a
      00B44C EA               [12] 1322 	mov	a,r2
      00B44D 3F               [12] 1323 	addc	a, r7
      00B44E FA               [12] 1324 	mov	r2,a
      00B44F EB               [12] 1325 	mov	a,r3
      00B450 12 B6 B1         [24] 1326 	lcall	_ak820_outline_0127
      00B453 12 71 20         [24] 1327 	lcall	_ak820_outline_0137
                                   1328 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B456 0B               [12] 1329 	inc	r3
                                   1330 ;	quantum/vial.c:266: case vial_unlock_start: {
      00B457 80 BD            [24] 1331 	sjmp	00137$
      00B459                       1332 00116$:
                                   1333 ;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
      00B459 90 0E 55         [24] 1334 	mov	dptr,#_vial_unlock_in_progress
      00B45C E0               [24] 1335 	movx	a,@dptr
      00B45D 70 03            [24] 1336 	jnz	00118$
      00B45F 12 B1 DC         [24] 1337 	lcall	_vial_release_held_state
      00B462                       1338 00118$:
                                   1339 ;	quantum/vial.c:270: vial_unlock_in_progress = 1;
      00B462 90 0E 55         [24] 1340 	mov	dptr,#_vial_unlock_in_progress
      00B465 74 01            [12] 1341 	mov	a,#0x01
      00B467 F0               [24] 1342 	movx	@dptr,a
                                   1343 ;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B468 90 0E 56         [24] 1344 	mov	dptr,#_vial_unlock_counter
      00B46B 74 1E            [12] 1345 	mov	a,#0x1e
      00B46D F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/vial.c:273: vial_unlock_holding = false;
      00B46E 90 0C 8D         [24] 1348 	mov	dptr,#_vial_unlock_holding
      00B471 E4               [12] 1349 	clr	a
      00B472 F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/vial.c:275: break;
      00B473 22               [24] 1352 	ret
                                   1353 ;	quantum/vial.c:277: case vial_unlock_poll: {
      00B474                       1354 00119$:
                                   1355 ;	quantum/vial.c:278: msg[0] = vial_unlocked;
      00B474 90 0E 54         [24] 1356 	mov	dptr,#_vial_unlocked
      00B477 E0               [24] 1357 	movx	a,@dptr
      00B478 12 3A FA         [24] 1358 	lcall	_ak820_outline_0118
      00B47B F0               [24] 1359 	movx	@dptr,a
                                   1360 ;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
      00B47C 90 0E 55         [24] 1361 	mov	dptr,#_vial_unlock_in_progress
      00B47F E0               [24] 1362 	movx	a,@dptr
      00B480 12 3A FF         [24] 1363 	lcall	_ak820_outline_0123
      00B483 F0               [24] 1364 	movx	@dptr,a
                                   1365 ;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
      00B484 74 02            [12] 1366 	mov	a,#0x02
      00B486 2E               [12] 1367 	add	a, r6
      00B487 FA               [12] 1368 	mov	r2,a
      00B488 E4               [12] 1369 	clr	a
      00B489 3F               [12] 1370 	addc	a, r7
      00B48A FB               [12] 1371 	mov	r3,a
      00B48B 90 0E 56         [24] 1372 	mov	dptr,#_vial_unlock_counter
      00B48E E0               [24] 1373 	movx	a,@dptr
      00B48F 12 3B 1A         [24] 1374 	lcall	_ak820_outline_0144
      00B492 F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/vial.c:281: break;
      00B493 22               [24] 1377 	ret
                                   1378 ;	quantum/vial.c:283: case vial_lock: {
      00B494                       1379 00120$:
                                   1380 ;	quantum/vial.c:285: vial_unlocked = 0;
      00B494 90 0E 54         [24] 1381 	mov	dptr,#_vial_unlocked
      00B497 E4               [12] 1382 	clr	a
      00B498 F0               [24] 1383 	movx	@dptr,a
                                   1384 ;	quantum/vial.c:286: vial_unlock_in_progress = 0;
      00B499 90 0E 55         [24] 1385 	mov	dptr,#_vial_unlock_in_progress
      00B49C F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:287: vial_unlock_holding = false;
      00B49D 90 0C 8D         [24] 1388 	mov	dptr,#_vial_unlock_holding
      00B4A0 F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:289: break;
      00B4A1 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:291: case vial_qmk_settings_query: {
      00B4A2                       1393 00121$:
                                   1394 ;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B4A2 90 0C 90         [24] 1395 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4A5 74 FF            [12] 1396 	mov	a,#0xff
      00B4A7 12 45 A6         [24] 1397 	lcall	_ak820_outline_0079
                                   1398 ;	quantum/vial.c:298: break;
      00B4AA 02 B1 B7         [24] 1399 	ljmp	_vial_fill_packet
                                   1400 ;	quantum/vial.c:318: case vial_dynamic_entry_op: {
      00B4AD                       1401 00122$:
                                   1402 ;	quantum/vial.c:319: switch (msg[2]) {
      00B4AD 12 3A A7         [24] 1403 	lcall	_ak820_outline_0037
      00B4B0 FB               [12] 1404 	mov	r3,a
      00B4B1 60 0C            [24] 1405 	jz	00123$
      00B4B3 BB 03 02         [24] 1406 	cjne	r3,#0x03,00272$
      00B4B6 80 31            [24] 1407 	sjmp	00124$
      00B4B8                       1408 00272$:
      00B4B8 BB 04 03         [24] 1409 	cjne	r3,#0x04,00273$
      00B4BB 02 B5 4D         [24] 1410 	ljmp	00125$
      00B4BE                       1411 00273$:
      00B4BE 22               [24] 1412 	ret
                                   1413 ;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
      00B4BF                       1414 00123$:
                                   1415 ;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
      00B4BF 90 0C 90         [24] 1416 	mov	dptr,#_vial_fill_packet_PARM_2
      00B4C2 E4               [12] 1417 	clr	a
      00B4C3 12 45 A6         [24] 1418 	lcall	_ak820_outline_0079
      00B4C6 C0 07            [24] 1419 	push	ar7
      00B4C8 C0 06            [24] 1420 	push	ar6
      00B4CA 12 B1 B7         [24] 1421 	lcall	_vial_fill_packet
      00B4CD D0 06            [24] 1422 	pop	ar6
      00B4CF D0 07            [24] 1423 	pop	ar7
                                   1424 ;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B4D1 12 3A FA         [24] 1425 	lcall	_ak820_outline_0118
      00B4D4 E4               [12] 1426 	clr	a
      00B4D5 12 45 A6         [24] 1427 	lcall	_ak820_outline_0079
                                   1428 ;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
      00B4D8 A3               [24] 1429 	inc	dptr
      00B4D9 74 08            [12] 1430 	mov	a,#0x08
      00B4DB 12 45 73         [24] 1431 	lcall	_ak820_outline_0031
                                   1432 ;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B4DE E4               [12] 1433 	clr	a
      00B4DF F0               [24] 1434 	movx	@dptr,a
                                   1435 ;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B4E0 74 1F            [12] 1436 	mov	a,#0x1f
      00B4E2 12 3A 9F         [24] 1437 	lcall	_ak820_outline_0022
      00B4E5 74 01            [12] 1438 	mov	a,#0x01
      00B4E7 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/vial.c:328: break;
      00B4E8 22               [24] 1441 	ret
                                   1442 ;	quantum/vial.c:352: case dynamic_vial_combo_get: {
      00B4E9                       1443 00124$:
                                   1444 ;	quantum/vial.c:353: uint8_t idx = msg[3];
      00B4E9 12 B0 BE         [24] 1445 	lcall	_ak820_outline_0018
      00B4EC FB               [12] 1446 	mov	r3,a
                                   1447 ;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
      00B4ED 90 0C 97         [24] 1448 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B4F0 12 51 C6         [24] 1449 	lcall	_ak820_outline_0182
      00B4F3 90 0C 99         [24] 1450 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00B4F6 F0               [24] 1451 	movx	@dptr,a
      00B4F7 A3               [24] 1452 	inc	dptr
      00B4F8 F0               [24] 1453 	movx	@dptr,a
      00B4F9 90 0C 9B         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00B4FC F0               [24] 1455 	movx	@dptr,a
      00B4FD A3               [24] 1456 	inc	dptr
      00B4FE F0               [24] 1457 	movx	@dptr,a
      00B4FF 90 0C 9D         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00B502 F0               [24] 1459 	movx	@dptr,a
      00B503 A3               [24] 1460 	inc	dptr
      00B504 F0               [24] 1461 	movx	@dptr,a
      00B505 90 0C 9F         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B508 F0               [24] 1463 	movx	@dptr,a
      00B509 A3               [24] 1464 	inc	dptr
      00B50A F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B50B 90 0B 1F         [24] 1467 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B50E 74 97            [12] 1468 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B510 F0               [24] 1469 	movx	@dptr,a
      00B511 74 0C            [12] 1470 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B513 12 3A CC         [24] 1471 	lcall	_ak820_outline_0072
      00B516 8B 82            [24] 1472 	mov	dpl, r3
      00B518 C0 07            [24] 1473 	push	ar7
      00B51A C0 06            [24] 1474 	push	ar6
      00B51C C0 05            [24] 1475 	push	ar5
      00B51E C0 04            [24] 1476 	push	ar4
      00B520 12 8A 88         [24] 1477 	lcall	_dynamic_keymap_get_combo
      00B523 AA 82            [24] 1478 	mov	r2, dpl
      00B525 D0 04            [24] 1479 	pop	ar4
      00B527 D0 05            [24] 1480 	pop	ar5
      00B529 D0 06            [24] 1481 	pop	ar6
      00B52B D0 07            [24] 1482 	pop	ar7
      00B52D 12 3A FA         [24] 1483 	lcall	_ak820_outline_0118
      00B530 EA               [12] 1484 	mov	a,r2
      00B531 F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
      00B532 7B 00            [12] 1487 	mov	r3,#0x00
      00B534 90 0D D3         [24] 1488 	mov	dptr,#___memcpy_PARM_2
      00B537 74 97            [12] 1489 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B539 F0               [24] 1490 	movx	@dptr,a
      00B53A 74 0C            [12] 1491 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B53C 12 3A CC         [24] 1492 	lcall	_ak820_outline_0072
      00B53F 90 0D D6         [24] 1493 	mov	dptr,#___memcpy_PARM_3
      00B542 12 93 0F         [24] 1494 	lcall	_ak820_outline_0075
      00B545 12 3A FF         [24] 1495 	lcall	_ak820_outline_0123
      00B548 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:357: break;
      00B54A 02 BC 62         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:359: case dynamic_vial_combo_set: {
      00B54D                       1500 00125$:
                                   1501 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B54D 12 B0 BE         [24] 1502 	lcall	_ak820_outline_0018
      00B550 FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
      00B551 74 04            [12] 1505 	mov	a,#0x04
      00B553 2E               [12] 1506 	add	a, r6
      00B554 FB               [12] 1507 	mov	r3,a
      00B555 E4               [12] 1508 	clr	a
      00B556 3F               [12] 1509 	addc	a, r7
      00B557 FC               [12] 1510 	mov	r4,a
      00B558 90 0D D3         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00B55B EB               [12] 1512 	mov	a,r3
      00B55C F0               [24] 1513 	movx	@dptr,a
      00B55D EC               [12] 1514 	mov	a,r4
      00B55E 12 3A CC         [24] 1515 	lcall	_ak820_outline_0072
      00B561 90 0D D6         [24] 1516 	mov	dptr,#___memcpy_PARM_3
      00B564 12 93 0F         [24] 1517 	lcall	_ak820_outline_0075
      00B567 90 0C A1         [24] 1518 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B56A F5 F0            [12] 1519 	mov	b,a
      00B56C C0 07            [24] 1520 	push	ar7
      00B56E C0 06            [24] 1521 	push	ar6
      00B570 C0 05            [24] 1522 	push	ar5
      00B572 12 BC 62         [24] 1523 	lcall	___memcpy
                                   1524 ;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
      00B575 90 0C A9         [24] 1525 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B578 12 3B 14         [24] 1526 	lcall	_ak820_outline_0141
      00B57B 12 36 75         [24] 1527 	lcall	_ak820_outline_0122
      00B57E 12 B1 94         [24] 1528 	lcall	_vial_keycode_firewall
      00B581 AB 82            [24] 1529 	mov	r3, dpl
      00B583 AC 83            [24] 1530 	mov	r4, dph
      00B585 D0 05            [24] 1531 	pop	ar5
      00B587 90 0C A9         [24] 1532 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B58A 12 3A DE         [24] 1533 	lcall	_ak820_outline_0093
                                   1534 ;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B58D 90 0B 23         [24] 1535 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B590 74 A1            [12] 1536 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B592 F0               [24] 1537 	movx	@dptr,a
      00B593 74 0C            [12] 1538 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B595 12 3A CC         [24] 1539 	lcall	_ak820_outline_0072
      00B598 8D 82            [24] 1540 	mov	dpl, r5
      00B59A 12 8B 28         [24] 1541 	lcall	_dynamic_keymap_set_combo
      00B59D AC 82            [24] 1542 	mov	r4, dpl
      00B59F D0 06            [24] 1543 	pop	ar6
      00B5A1 D0 07            [24] 1544 	pop	ar7
      00B5A3 12 3A FA         [24] 1545 	lcall	_ak820_outline_0118
      00B5A6 EC               [12] 1546 	mov	a,r4
      00B5A7 F0               [24] 1547 	movx	@dptr,a
                                   1548 ;	quantum/vial.c:365: if (!msg[0]) reload_combo();
      00B5A8 EC               [12] 1549 	mov	a,r4
      00B5A9 70 03            [24] 1550 	jnz	00139$
                                   1551 ;	quantum/vial.c:391: }
                                   1552 ;	quantum/vial.c:392: }
      00B5AB 02 37 F5         [24] 1553 	ljmp	_ak820_combo_reload
      00B5AE                       1554 00139$:
      00B5AE 22               [24] 1555 	ret
                                   1556 ;------------------------------------------------------------
                                   1557 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1558 ;------------------------------------------------------------
                                   1559 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1560 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1561 ;------------------------------------------------------------
                                   1562 ;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
                                   1563 ;	-----------------------------------------
                                   1564 ;	 function vial_keycode_down
                                   1565 ;	-----------------------------------------
      00B5AF                       1566 _vial_keycode_down:
      00B5AF 12 3A F0         [24] 1567 	lcall	_ak820_outline_0107
      00B5B2 90 0C AD         [24] 1568 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B5B5 12 3A F5         [24] 1569 	lcall	_ak820_outline_0108
                                   1570 ;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B5B8 90 0C AD         [24] 1571 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B5BB 12 4A 8D         [24] 1572 	lcall	_ak820_outline_0008
      00B5BE 74 E0            [12] 1573 	mov	a,#0x100 - 0x20
      00B5C0 2D               [12] 1574 	add	a,r5
      00B5C1 50 19            [24] 1575 	jnc	00104$
      00B5C3 C3               [12] 1576 	clr	c
      00B5C4 74 FF            [12] 1577 	mov	a,#0xff
      00B5C6 9C               [12] 1578 	subb	a,r4
      00B5C7 74 4F            [12] 1579 	mov	a,#0x4f
      00B5C9 9D               [12] 1580 	subb	a,r5
      00B5CA 40 10            [24] 1581 	jc	00104$
                                   1582 ;	free result
                                   1583 ;	quantum/vial.c:401: keycode = (uint8_t)keycode;
      00B5CC 90 0C AD         [24] 1584 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B5CF EE               [12] 1585 	mov	a,r6
      00B5D0 12 3B 04         [24] 1586 	lcall	_ak820_outline_0124
                                   1587 ;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
      00B5D3 90 0C AD         [24] 1588 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B5D6 E0               [24] 1589 	movx	a,@dptr
      00B5D7 24 FE            [12] 1590 	add	a,#0xff - 0x01
      00B5D9 40 01            [24] 1591 	jc	00104$
                                   1592 ;	free result
      00B5DB 22               [24] 1593 	ret
      00B5DC                       1594 00104$:
                                   1595 ;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
      00B5DC 90 0C AD         [24] 1596 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B5DF 12 B6 98         [24] 1597 	lcall	_ak820_outline_0025
                                   1598 ;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
      00B5E2 40 06            [24] 1599 	jc	00107$
                                   1600 ;	free result
                                   1601 ;	quantum/vial.c:408: register_code16(keycode);
      00B5E4 12 3A FA         [24] 1602 	lcall	_ak820_outline_0118
      00B5E7 02 A2 10         [24] 1603 	ljmp	_register_code16
      00B5EA                       1604 00107$:
                                   1605 ;	quantum/vial.c:410: keyevent_t dummy_event = {
      00B5EA 90 0C B3         [24] 1606 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00B5ED 74 01            [12] 1607 	mov	a,#0x01
      00B5EF F0               [24] 1608 	movx	@dptr,a
      00B5F0 90 0C B0         [24] 1609 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00B5F3 74 F0            [12] 1610 	mov	a,#0xf0
      00B5F5 F0               [24] 1611 	movx	@dptr,a
      00B5F6 90 0C AF         [24] 1612 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00B5F9 F0               [24] 1613 	movx	@dptr,a
      00B5FA 90 0C B4         [24] 1614 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00B5FD 74 01            [12] 1615 	mov	a,#0x01
      00B5FF F0               [24] 1616 	movx	@dptr,a
      00B600 12 4B 9D         [24] 1617 	lcall	_timer_read
      00B603 12 45 C4         [24] 1618 	lcall	_ak820_outline_0125
      00B606 43 06 01         [24] 1619 	orl	ar6,#0x01
      00B609 90 0C B1         [24] 1620 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00B60C 12 4A EA         [24] 1621 	lcall	_ak820_outline_0060
                                   1622 ;	quantum/vial.c:414: AK820_ACTION_EXEC(dummy_event);
      00B60F 90 0C AF         [24] 1623 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1624 ;	quantum/vial.c:416: }
      00B612 02 75 8A         [24] 1625 	ljmp	_ak820_action_exec
                                   1626 ;------------------------------------------------------------
                                   1627 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1628 ;------------------------------------------------------------
                                   1629 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1630 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1631 ;------------------------------------------------------------
                                   1632 ;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
                                   1633 ;	-----------------------------------------
                                   1634 ;	 function vial_keycode_up
                                   1635 ;	-----------------------------------------
      00B615                       1636 _vial_keycode_up:
      00B615 12 3A F0         [24] 1637 	lcall	_ak820_outline_0107
      00B618 90 0C B5         [24] 1638 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B61B 12 3A F5         [24] 1639 	lcall	_ak820_outline_0108
                                   1640 ;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B61E 90 0C B5         [24] 1641 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B621 12 4A 8D         [24] 1642 	lcall	_ak820_outline_0008
      00B624 74 E0            [12] 1643 	mov	a,#0x100 - 0x20
      00B626 2D               [12] 1644 	add	a,r5
      00B627 50 19            [24] 1645 	jnc	00104$
      00B629 C3               [12] 1646 	clr	c
      00B62A 74 FF            [12] 1647 	mov	a,#0xff
      00B62C 9C               [12] 1648 	subb	a,r4
      00B62D 74 4F            [12] 1649 	mov	a,#0x4f
      00B62F 9D               [12] 1650 	subb	a,r5
      00B630 40 10            [24] 1651 	jc	00104$
                                   1652 ;	free result
                                   1653 ;	quantum/vial.c:423: keycode = (uint8_t)keycode;
      00B632 90 0C B5         [24] 1654 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B635 EE               [12] 1655 	mov	a,r6
      00B636 12 3B 04         [24] 1656 	lcall	_ak820_outline_0124
                                   1657 ;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
      00B639 90 0C B5         [24] 1658 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B63C E0               [24] 1659 	movx	a,@dptr
      00B63D 24 FE            [12] 1660 	add	a,#0xff - 0x01
      00B63F 40 01            [24] 1661 	jc	00104$
                                   1662 ;	free result
      00B641 22               [24] 1663 	ret
      00B642                       1664 00104$:
                                   1665 ;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
      00B642 90 0C B5         [24] 1666 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B645 12 B6 98         [24] 1667 	lcall	_ak820_outline_0025
                                   1668 ;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
      00B648 40 06            [24] 1669 	jc	00107$
                                   1670 ;	free result
                                   1671 ;	quantum/vial.c:430: unregister_code16(keycode);
      00B64A 12 3A FA         [24] 1672 	lcall	_ak820_outline_0118
      00B64D 02 A2 54         [24] 1673 	ljmp	_unregister_code16
      00B650                       1674 00107$:
                                   1675 ;	quantum/vial.c:432: keyevent_t dummy_event = {
      00B650 90 0C BB         [24] 1676 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B653 74 01            [12] 1677 	mov	a,#0x01
      00B655 F0               [24] 1678 	movx	@dptr,a
      00B656 90 0C B8         [24] 1679 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B659 74 F0            [12] 1680 	mov	a,#0xf0
      00B65B F0               [24] 1681 	movx	@dptr,a
      00B65C 90 0C B7         [24] 1682 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B65F F0               [24] 1683 	movx	@dptr,a
      00B660 90 0C BC         [24] 1684 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B663 E4               [12] 1685 	clr	a
      00B664 F0               [24] 1686 	movx	@dptr,a
      00B665 12 4B 9D         [24] 1687 	lcall	_timer_read
      00B668 12 45 C4         [24] 1688 	lcall	_ak820_outline_0125
      00B66B 43 06 01         [24] 1689 	orl	ar6,#0x01
      00B66E 90 0C B9         [24] 1690 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B671 12 4A EA         [24] 1691 	lcall	_ak820_outline_0060
                                   1692 ;	quantum/vial.c:436: AK820_ACTION_EXEC(dummy_event);
      00B674 90 0C B7         [24] 1693 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1694 ;	quantum/vial.c:438: }
      00B677 02 75 8A         [24] 1695 	ljmp	_ak820_action_exec
                                   1696 ;------------------------------------------------------------
                                   1697 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1698 ;------------------------------------------------------------
                                   1699 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1700 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1701 ;------------------------------------------------------------
                                   1702 ;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
                                   1703 ;	-----------------------------------------
                                   1704 ;	 function vial_keycode_tap
                                   1705 ;	-----------------------------------------
      00B67A                       1706 _vial_keycode_tap:
      00B67A 12 3A F0         [24] 1707 	lcall	_ak820_outline_0107
      00B67D 90 0C BD         [24] 1708 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B680 12 3A F5         [24] 1709 	lcall	_ak820_outline_0108
                                   1710 ;	quantum/vial.c:441: vial_keycode_down(keycode);
      00B683 90 0C BD         [24] 1711 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B686 12 3A 62         [24] 1712 	lcall	_ak820_outline_0005
      00B689 C0 07            [24] 1713 	push	ar7
      00B68B C0 06            [24] 1714 	push	ar6
      00B68D B1 AF            [12] 1715 	acall	_vial_keycode_down
      00B68F D0 06            [24] 1716 	pop	ar6
      00B691 D0 07            [24] 1717 	pop	ar7
                                   1718 ;	quantum/vial.c:443: vial_keycode_up(keycode);
      00B693 12 3A FA         [24] 1719 	lcall	_ak820_outline_0118
                                   1720 ;	quantum/vial.c:444: }
      00B696 C1 15            [12] 1721 	ajmp	_vial_keycode_up
                                   1722 ;------------------------------------------------------------
                                   1723 ;Allocation info for local variables in function 'process_record_vial'
                                   1724 ;------------------------------------------------------------
                                   1725 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1726 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1727 ;------------------------------------------------------------
                                   1728 ;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1729 ;	-----------------------------------------
                                   1730 	.area CSEG    (CODE)
                                   1731 	.area CONST   (CODE)
                                   1732 	.area CONST   (CODE)
      00C1E8                       1733 _keyboard_definition:
      00C1E8 FD                    1734 	.db #0xfd	; 253
      00C1E9 37                    1735 	.db #0x37	; 55	'7'
      00C1EA 7A                    1736 	.db #0x7a	; 122	'z'
      00C1EB 58                    1737 	.db #0x58	; 88	'X'
      00C1EC 5A                    1738 	.db #0x5a	; 90	'Z'
      00C1ED 00                    1739 	.db #0x00	; 0
      00C1EE 00                    1740 	.db #0x00	; 0
      00C1EF 04                    1741 	.db #0x04	; 4
      00C1F0 E6                    1742 	.db #0xe6	; 230
      00C1F1 D6                    1743 	.db #0xd6	; 214
      00C1F2 B4                    1744 	.db #0xb4	; 180
      00C1F3 46                    1745 	.db #0x46	; 70	'F'
      00C1F4 02                    1746 	.db #0x02	; 2
      00C1F5 00                    1747 	.db #0x00	; 0
      00C1F6 21                    1748 	.db #0x21	; 33
      00C1F7 01                    1749 	.db #0x01	; 1
      00C1F8 00                    1750 	.db #0x00	; 0
      00C1F9 00                    1751 	.db #0x00	; 0
      00C1FA 00                    1752 	.db #0x00	; 0
      00C1FB 00                    1753 	.db #0x00	; 0
      00C1FC 37                    1754 	.db #0x37	; 55	'7'
      00C1FD 27                    1755 	.db #0x27	; 39
      00C1FE 97                    1756 	.db #0x97	; 151
      00C1FF D6                    1757 	.db #0xd6	; 214
      00C200 E0                    1758 	.db #0xe0	; 224
      00C201 03                    1759 	.db #0x03	; 3
      00C202 CB                    1760 	.db #0xcb	; 203
      00C203 01                    1761 	.db #0x01	; 1
      00C204 3C                    1762 	.db #0x3c	; 60
      00C205 00                    1763 	.db #0x00	; 0
      00C206 00                    1764 	.db #0x00	; 0
      00C207 3D                    1765 	.db #0x3d	; 61
      00C208 88                    1766 	.db #0x88	; 136
      00C209 CD                    1767 	.db #0xcd	; 205
      00C20A A5                    1768 	.db #0xa5	; 165
      00C20B AA                    1769 	.db #0xaa	; 170
      00C20C E5                    1770 	.db #0xe5	; 229
      00C20D A8                    1771 	.db #0xa8	; 168
      00C20E 76                    1772 	.db #0x76	; 118	'v'
      00C20F F6                    1773 	.db #0xf6	; 246
      00C210 43                    1774 	.db #0x43	; 67	'C'
      00C211 0E                    1775 	.db #0x0e	; 14
      00C212 D2                    1776 	.db #0xd2	; 210
      00C213 90                    1777 	.db #0x90	; 144
      00C214 7D                    1778 	.db #0x7d	; 125
      00C215 94                    1779 	.db #0x94	; 148
      00C216 79                    1780 	.db #0x79	; 121	'y'
      00C217 78                    1781 	.db #0x78	; 120	'x'
      00C218 EF                    1782 	.db #0xef	; 239
      00C219 49                    1783 	.db #0x49	; 73	'I'
      00C21A 3E                    1784 	.db #0x3e	; 62
      00C21B EF                    1785 	.db #0xef	; 239
      00C21C FD                    1786 	.db #0xfd	; 253
      00C21D 8F                    1787 	.db #0x8f	; 143
      00C21E EF                    1788 	.db #0xef	; 239
      00C21F 00                    1789 	.db #0x00	; 0
      00C220 C6                    1790 	.db #0xc6	; 198
      00C221 D1                    1791 	.db #0xd1	; 209
      00C222 DB                    1792 	.db #0xdb	; 219
      00C223 FB                    1793 	.db #0xfb	; 251
      00C224 EB                    1794 	.db #0xeb	; 235
      00C225 DE                    1795 	.db #0xde	; 222
      00C226 66                    1796 	.db #0x66	; 102	'f'
      00C227 63                    1797 	.db #0x63	; 99	'c'
      00C228 0C                    1798 	.db #0x0c	; 12
      00C229 92                    1799 	.db #0x92	; 146
      00C22A 7B                    1800 	.db #0x7b	; 123
      00C22B F9                    1801 	.db #0xf9	; 249
      00C22C D4                    1802 	.db #0xd4	; 212
      00C22D 7A                    1803 	.db #0x7a	; 122	'z'
      00C22E 4F                    1804 	.db #0x4f	; 79	'O'
      00C22F 83                    1805 	.db #0x83	; 131
      00C230 4B                    1806 	.db #0x4b	; 75	'K'
      00C231 86                    1807 	.db #0x86	; 134
      00C232 0E                    1808 	.db #0x0e	; 14
      00C233 6A                    1809 	.db #0x6a	; 106	'j'
      00C234 F2                    1810 	.db #0xf2	; 242
      00C235 22                    1811 	.db #0x22	; 34
      00C236 22                    1812 	.db #0x22	; 34
      00C237 0B                    1813 	.db #0x0b	; 11
      00C238 03                    1814 	.db #0x03	; 3
      00C239 BA                    1815 	.db #0xba	; 186
      00C23A 67                    1816 	.db #0x67	; 103	'g'
      00C23B 9B                    1817 	.db #0x9b	; 155
      00C23C 7A                    1818 	.db #0x7a	; 122	'z'
      00C23D E1                    1819 	.db #0xe1	; 225
      00C23E BC                    1820 	.db #0xbc	; 188
      00C23F 37                    1821 	.db #0x37	; 55	'7'
      00C240 26                    1822 	.db #0x26	; 38
      00C241 46                    1823 	.db #0x46	; 70	'F'
      00C242 78                    1824 	.db #0x78	; 120	'x'
      00C243 05                    1825 	.db #0x05	; 5
      00C244 0D                    1826 	.db #0x0d	; 13
      00C245 95                    1827 	.db #0x95	; 149
      00C246 02                    1828 	.db #0x02	; 2
      00C247 E4                    1829 	.db #0xe4	; 228
      00C248 18                    1830 	.db #0x18	; 24
      00C249 CA                    1831 	.db #0xca	; 202
      00C24A 33                    1832 	.db #0x33	; 51	'3'
      00C24B EA                    1833 	.db #0xea	; 234
      00C24C 24                    1834 	.db #0x24	; 36
      00C24D C8                    1835 	.db #0xc8	; 200
      00C24E 81                    1836 	.db #0x81	; 129
      00C24F 4E                    1837 	.db #0x4e	; 78	'N'
      00C250 47                    1838 	.db #0x47	; 71	'G'
      00C251 A8                    1839 	.db #0xa8	; 168
      00C252 44                    1840 	.db #0x44	; 68	'D'
      00C253 DD                    1841 	.db #0xdd	; 221
      00C254 91                    1842 	.db #0x91	; 145
      00C255 6D                    1843 	.db #0x6d	; 109	'm'
      00C256 69                    1844 	.db #0x69	; 105	'i'
      00C257 DB                    1845 	.db #0xdb	; 219
      00C258 4F                    1846 	.db #0x4f	; 79	'O'
      00C259 3A                    1847 	.db #0x3a	; 58
      00C25A 43                    1848 	.db #0x43	; 67	'C'
      00C25B 9D                    1849 	.db #0x9d	; 157
      00C25C 26                    1850 	.db #0x26	; 38
      00C25D 49                    1851 	.db #0x49	; 73	'I'
      00C25E 4C                    1852 	.db #0x4c	; 76	'L'
      00C25F EF                    1853 	.db #0xef	; 239
      00C260 2B                    1854 	.db #0x2b	; 43
      00C261 D8                    1855 	.db #0xd8	; 216
      00C262 55                    1856 	.db #0x55	; 85	'U'
      00C263 95                    1857 	.db #0x95	; 149
      00C264 70                    1858 	.db #0x70	; 112	'p'
      00C265 B1                    1859 	.db #0xb1	; 177
      00C266 CC                    1860 	.db #0xcc	; 204
      00C267 CF                    1861 	.db #0xcf	; 207
      00C268 13                    1862 	.db #0x13	; 19
      00C269 32                    1863 	.db #0x32	; 50	'2'
      00C26A 6A                    1864 	.db #0x6a	; 106	'j'
      00C26B A1                    1865 	.db #0xa1	; 161
      00C26C FF                    1866 	.db #0xff	; 255
      00C26D 99                    1867 	.db #0x99	; 153
      00C26E 61                    1868 	.db #0x61	; 97	'a'
      00C26F 95                    1869 	.db #0x95	; 149
      00C270 B1                    1870 	.db #0xb1	; 177
      00C271 89                    1871 	.db #0x89	; 137
      00C272 9B                    1872 	.db #0x9b	; 155
      00C273 11                    1873 	.db #0x11	; 17
      00C274 D9                    1874 	.db #0xd9	; 217
      00C275 35                    1875 	.db #0x35	; 53	'5'
      00C276 78                    1876 	.db #0x78	; 120	'x'
      00C277 ED                    1877 	.db #0xed	; 237
      00C278 CD                    1878 	.db #0xcd	; 205
      00C279 94                    1879 	.db #0x94	; 148
      00C27A 6E                    1880 	.db #0x6e	; 110	'n'
      00C27B 60                    1881 	.db #0x60	; 96
      00C27C 8E                    1882 	.db #0x8e	; 142
      00C27D 63                    1883 	.db #0x63	; 99	'c'
      00C27E 8B                    1884 	.db #0x8b	; 139
      00C27F FF                    1885 	.db #0xff	; 255
      00C280 4E                    1886 	.db #0x4e	; 78	'N'
      00C281 20                    1887 	.db #0x20	; 32
      00C282 7A                    1888 	.db #0x7a	; 122	'z'
      00C283 B5                    1889 	.db #0xb5	; 181
      00C284 87                    1890 	.db #0x87	; 135
      00C285 C2                    1891 	.db #0xc2	; 194
      00C286 35                    1892 	.db #0x35	; 53	'5'
      00C287 A4                    1893 	.db #0xa4	; 164
      00C288 6D                    1894 	.db #0x6d	; 109	'm'
      00C289 18                    1895 	.db #0x18	; 24
      00C28A C1                    1896 	.db #0xc1	; 193
      00C28B A3                    1897 	.db #0xa3	; 163
      00C28C DB                    1898 	.db #0xdb	; 219
      00C28D 53                    1899 	.db #0x53	; 83	'S'
      00C28E 1D                    1900 	.db #0x1d	; 29
      00C28F EC                    1901 	.db #0xec	; 236
      00C290 F0                    1902 	.db #0xf0	; 240
      00C291 BF                    1903 	.db #0xbf	; 191
      00C292 4A                    1904 	.db #0x4a	; 74	'J'
      00C293 4C                    1905 	.db #0x4c	; 76	'L'
      00C294 4A                    1906 	.db #0x4a	; 74	'J'
      00C295 C4                    1907 	.db #0xc4	; 196
      00C296 AA                    1908 	.db #0xaa	; 170
      00C297 37                    1909 	.db #0x37	; 55	'7'
      00C298 19                    1910 	.db #0x19	; 25
      00C299 34                    1911 	.db #0x34	; 52	'4'
      00C29A 3F                    1912 	.db #0x3f	; 63
      00C29B A1                    1913 	.db #0xa1	; 161
      00C29C D3                    1914 	.db #0xd3	; 211
      00C29D 1A                    1915 	.db #0x1a	; 26
      00C29E 5C                    1916 	.db #0x5c	; 92
      00C29F 03                    1917 	.db #0x03	; 3
      00C2A0 4D                    1918 	.db #0x4d	; 77	'M'
      00C2A1 BC                    1919 	.db #0xbc	; 188
      00C2A2 10                    1920 	.db #0x10	; 16
      00C2A3 2E                    1921 	.db #0x2e	; 46
      00C2A4 80                    1922 	.db #0x80	; 128
      00C2A5 F7                    1923 	.db #0xf7	; 247
      00C2A6 D6                    1924 	.db #0xd6	; 214
      00C2A7 82                    1925 	.db #0x82	; 130
      00C2A8 24                    1926 	.db #0x24	; 36
      00C2A9 4C                    1927 	.db #0x4c	; 76	'L'
      00C2AA 87                    1928 	.db #0x87	; 135
      00C2AB B9                    1929 	.db #0xb9	; 185
      00C2AC F8                    1930 	.db #0xf8	; 248
      00C2AD BE                    1931 	.db #0xbe	; 190
      00C2AE 67                    1932 	.db #0x67	; 103	'g'
      00C2AF 96                    1933 	.db #0x96	; 150
      00C2B0 89                    1934 	.db #0x89	; 137
      00C2B1 30                    1935 	.db #0x30	; 48	'0'
      00C2B2 C8                    1936 	.db #0xc8	; 200
      00C2B3 8D                    1937 	.db #0x8d	; 141
      00C2B4 2C                    1938 	.db #0x2c	; 44
      00C2B5 F5                    1939 	.db #0xf5	; 245
      00C2B6 06                    1940 	.db #0x06	; 6
      00C2B7 05                    1941 	.db #0x05	; 5
      00C2B8 7C                    1942 	.db #0x7c	; 124
      00C2B9 48                    1943 	.db #0x48	; 72	'H'
      00C2BA 1B                    1944 	.db #0x1b	; 27
      00C2BB 76                    1945 	.db #0x76	; 118	'v'
      00C2BC AA                    1946 	.db #0xaa	; 170
      00C2BD 3D                    1947 	.db #0x3d	; 61
      00C2BE 28                    1948 	.db #0x28	; 40
      00C2BF FC                    1949 	.db #0xfc	; 252
      00C2C0 80                    1950 	.db #0x80	; 128
      00C2C1 75                    1951 	.db #0x75	; 117	'u'
      00C2C2 EB                    1952 	.db #0xeb	; 235
      00C2C3 78                    1953 	.db #0x78	; 120	'x'
      00C2C4 D0                    1954 	.db #0xd0	; 208
      00C2C5 8A                    1955 	.db #0x8a	; 138
      00C2C6 8F                    1956 	.db #0x8f	; 143
      00C2C7 27                    1957 	.db #0x27	; 39
      00C2C8 F7                    1958 	.db #0xf7	; 247
      00C2C9 F2                    1959 	.db #0xf2	; 242
      00C2CA EB                    1960 	.db #0xeb	; 235
      00C2CB 58                    1961 	.db #0x58	; 88	'X'
      00C2CC 37                    1962 	.db #0x37	; 55	'7'
      00C2CD 3C                    1963 	.db #0x3c	; 60
      00C2CE 2B                    1964 	.db #0x2b	; 43
      00C2CF 6F                    1965 	.db #0x6f	; 111	'o'
      00C2D0 0E                    1966 	.db #0x0e	; 14
      00C2D1 C7                    1967 	.db #0xc7	; 199
      00C2D2 E2                    1968 	.db #0xe2	; 226
      00C2D3 A0                    1969 	.db #0xa0	; 160
      00C2D4 97                    1970 	.db #0x97	; 151
      00C2D5 EE                    1971 	.db #0xee	; 238
      00C2D6 FD                    1972 	.db #0xfd	; 253
      00C2D7 9F                    1973 	.db #0x9f	; 159
      00C2D8 45                    1974 	.db #0x45	; 69	'E'
      00C2D9 17                    1975 	.db #0x17	; 23
      00C2DA 94                    1976 	.db #0x94	; 148
      00C2DB E6                    1977 	.db #0xe6	; 230
      00C2DC E7                    1978 	.db #0xe7	; 231
      00C2DD FA                    1979 	.db #0xfa	; 250
      00C2DE 4C                    1980 	.db #0x4c	; 76	'L'
      00C2DF 7A                    1981 	.db #0x7a	; 122	'z'
      00C2E0 D6                    1982 	.db #0xd6	; 214
      00C2E1 7A                    1983 	.db #0x7a	; 122	'z'
      00C2E2 7B                    1984 	.db #0x7b	; 123
      00C2E3 ED                    1985 	.db #0xed	; 237
      00C2E4 10                    1986 	.db #0x10	; 16
      00C2E5 C5                    1987 	.db #0xc5	; 197
      00C2E6 BC                    1988 	.db #0xbc	; 188
      00C2E7 E3                    1989 	.db #0xe3	; 227
      00C2E8 A9                    1990 	.db #0xa9	; 169
      00C2E9 1F                    1991 	.db #0x1f	; 31
      00C2EA CF                    1992 	.db #0xcf	; 207
      00C2EB C4                    1993 	.db #0xc4	; 196
      00C2EC 9D                    1994 	.db #0x9d	; 157
      00C2ED DC                    1995 	.db #0xdc	; 220
      00C2EE 45                    1996 	.db #0x45	; 69	'E'
      00C2EF 2A                    1997 	.db #0x2a	; 42
      00C2F0 69                    1998 	.db #0x69	; 105	'i'
      00C2F1 57                    1999 	.db #0x57	; 87	'W'
      00C2F2 8F                    2000 	.db #0x8f	; 143
      00C2F3 EC                    2001 	.db #0xec	; 236
      00C2F4 85                    2002 	.db #0x85	; 133
      00C2F5 6C                    2003 	.db #0x6c	; 108	'l'
      00C2F6 43                    2004 	.db #0x43	; 67	'C'
      00C2F7 1C                    2005 	.db #0x1c	; 28
      00C2F8 BA                    2006 	.db #0xba	; 186
      00C2F9 89                    2007 	.db #0x89	; 137
      00C2FA 68                    2008 	.db #0x68	; 104	'h'
      00C2FB 4A                    2009 	.db #0x4a	; 74	'J'
      00C2FC 1C                    2010 	.db #0x1c	; 28
      00C2FD 91                    2011 	.db #0x91	; 145
      00C2FE 3F                    2012 	.db #0x3f	; 63
      00C2FF D1                    2013 	.db #0xd1	; 209
      00C300 B3                    2014 	.db #0xb3	; 179
      00C301 96                    2015 	.db #0x96	; 150
      00C302 1D                    2016 	.db #0x1d	; 29
      00C303 7C                    2017 	.db #0x7c	; 124
      00C304 14                    2018 	.db #0x14	; 20
      00C305 77                    2019 	.db #0x77	; 119	'w'
      00C306 9C                    2020 	.db #0x9c	; 156
      00C307 74                    2021 	.db #0x74	; 116	't'
      00C308 36                    2022 	.db #0x36	; 54	'6'
      00C309 FF                    2023 	.db #0xff	; 255
      00C30A 2C                    2024 	.db #0x2c	; 44
      00C30B 66                    2025 	.db #0x66	; 102	'f'
      00C30C AF                    2026 	.db #0xaf	; 175
      00C30D 0F                    2027 	.db #0x0f	; 15
      00C30E 3C                    2028 	.db #0x3c	; 60
      00C30F A2                    2029 	.db #0xa2	; 162
      00C310 23                    2030 	.db #0x23	; 35
      00C311 85                    2031 	.db #0x85	; 133
      00C312 05                    2032 	.db #0x05	; 5
      00C313 87                    2033 	.db #0x87	; 135
      00C314 DA                    2034 	.db #0xda	; 218
      00C315 61                    2035 	.db #0x61	; 97	'a'
      00C316 5E                    2036 	.db #0x5e	; 94
      00C317 42                    2037 	.db #0x42	; 66	'B'
      00C318 54                    2038 	.db #0x54	; 84	'T'
      00C319 60                    2039 	.db #0x60	; 96
      00C31A 23                    2040 	.db #0x23	; 35
      00C31B CA                    2041 	.db #0xca	; 202
      00C31C BC                    2042 	.db #0xbc	; 188
      00C31D B3                    2043 	.db #0xb3	; 179
      00C31E 18                    2044 	.db #0x18	; 24
      00C31F 1D                    2045 	.db #0x1d	; 29
      00C320 F8                    2046 	.db #0xf8	; 248
      00C321 0A                    2047 	.db #0x0a	; 10
      00C322 55                    2048 	.db #0x55	; 85	'U'
      00C323 CD                    2049 	.db #0xcd	; 205
      00C324 A3                    2050 	.db #0xa3	; 163
      00C325 DE                    2051 	.db #0xde	; 222
      00C326 FF                    2052 	.db #0xff	; 255
      00C327 B2                    2053 	.db #0xb2	; 178
      00C328 2A                    2054 	.db #0x2a	; 42
      00C329 35                    2055 	.db #0x35	; 53	'5'
      00C32A 00                    2056 	.db #0x00	; 0
      00C32B D6                    2057 	.db #0xd6	; 214
      00C32C 7B                    2058 	.db #0x7b	; 123
      00C32D E8                    2059 	.db #0xe8	; 232
      00C32E F2                    2060 	.db #0xf2	; 242
      00C32F 1A                    2061 	.db #0x1a	; 26
      00C330 BC                    2062 	.db #0xbc	; 188
      00C331 F5                    2063 	.db #0xf5	; 245
      00C332 7E                    2064 	.db #0x7e	; 126
      00C333 48                    2065 	.db #0x48	; 72	'H'
      00C334 72                    2066 	.db #0x72	; 114	'r'
      00C335 E0                    2067 	.db #0xe0	; 224
      00C336 E4                    2068 	.db #0xe4	; 228
      00C337 E0                    2069 	.db #0xe0	; 224
      00C338 27                    2070 	.db #0x27	; 39
      00C339 87                    2071 	.db #0x87	; 135
      00C33A 9A                    2072 	.db #0x9a	; 154
      00C33B 51                    2073 	.db #0x51	; 81	'Q'
      00C33C D4                    2074 	.db #0xd4	; 212
      00C33D DD                    2075 	.db #0xdd	; 221
      00C33E C3                    2076 	.db #0xc3	; 195
      00C33F AA                    2077 	.db #0xaa	; 170
      00C340 49                    2078 	.db #0x49	; 73	'I'
      00C341 5A                    2079 	.db #0x5a	; 90	'Z'
      00C342 2A                    2080 	.db #0x2a	; 42
      00C343 00                    2081 	.db #0x00	; 0
      00C344 A0                    2082 	.db #0xa0	; 160
      00C345 8C                    2083 	.db #0x8c	; 140
      00C346 FF                    2084 	.db #0xff	; 255
      00C347 74                    2085 	.db #0x74	; 116	't'
      00C348 BF                    2086 	.db #0xbf	; 191
      00C349 EC                    2087 	.db #0xec	; 236
      00C34A 1D                    2088 	.db #0x1d	; 29
      00C34B F1                    2089 	.db #0xf1	; 241
      00C34C 00                    2090 	.db #0x00	; 0
      00C34D 01                    2091 	.db #0x01	; 1
      00C34E D8                    2092 	.db #0xd8	; 216
      00C34F 02                    2093 	.db #0x02	; 2
      00C350 CC                    2094 	.db #0xcc	; 204
      00C351 07                    2095 	.db #0x07	; 7
      00C352 00                    2096 	.db #0x00	; 0
      00C353 00                    2097 	.db #0x00	; 0
      00C354 C4                    2098 	.db #0xc4	; 196
      00C355 5E                    2099 	.db #0x5e	; 94
      00C356 2C                    2100 	.db #0x2c	; 44
      00C357 7E                    2101 	.db #0x7e	; 126
      00C358 B1                    2102 	.db #0xb1	; 177
      00C359 C4                    2103 	.db #0xc4	; 196
      00C35A 67                    2104 	.db #0x67	; 103	'g'
      00C35B FB                    2105 	.db #0xfb	; 251
      00C35C 02                    2106 	.db #0x02	; 2
      00C35D 00                    2107 	.db #0x00	; 0
      00C35E 00                    2108 	.db #0x00	; 0
      00C35F 00                    2109 	.db #0x00	; 0
      00C360 00                    2110 	.db #0x00	; 0
      00C361 04                    2111 	.db #0x04	; 4
      00C362 59                    2112 	.db #0x59	; 89	'Y'
      00C363 5A                    2113 	.db #0x5a	; 90	'Z'
                                   2114 	.area CSEG    (CODE)
                                   2115 	.area CONST   (CODE)
      00C364                       2116 _vial_handle_cmd_keyboard_uid_40000_623:
      00C364 04                    2117 	.db #0x04	; 4
      00C365 70                    2118 	.db #0x70	; 112	'p'
      00C366 FF                    2119 	.db #0xff	; 255
      00C367 90                    2120 	.db #0x90	; 144
      00C368 01                    2121 	.db #0x01	; 1
      00C369 B9                    2122 	.db #0xb9	; 185
      00C36A 15                    2123 	.db #0x15	; 21
      00C36B D3                    2124 	.db #0xd3	; 211
                                   2125 	.area CSEG    (CODE)
                                   2126 	.area XINIT   (CODE)
      00C5E4                       2127 __xinit__vial_unlocked:
      00C5E4 00                    2128 	.db #0x00	;  0
      00C5E5                       2129 __xinit__vial_unlock_in_progress:
      00C5E5 00                    2130 	.db #0x00	;  0
      00C5E6                       2131 __xinit__vial_unlock_counter:
      00C5E6 00                    2132 	.db #0x00	; 0
      00C5E7                       2133 __xinit__vial_unlock_combo_rows:
      00C5E7 00                    2134 	.db #0x00	; 0
      00C5E8 00                    2135 	.db #0x00	; 0
      00C5E9                       2136 __xinit__vial_unlock_combo_cols:
      00C5E9 00                    2137 	.db #0x00	; 0
      00C5EA 05                    2138 	.db #0x05	; 5
                                   2139 	.area CABS    (ABS,CODE)
                                   2140 
                                   2141 ; Experimental exact instruction outlining.
                                   2142 	.globl _ak820_outline_0005
                                   2143 	.globl _ak820_outline_0006
                                   2144 	.globl _ak820_outline_0008
                                   2145 	.globl _ak820_outline_0011
                                   2146 	.globl _ak820_outline_0016
                                   2147 	.globl _ak820_outline_0018
                                   2148 	.globl _ak820_outline_0022
                                   2149 	.globl _ak820_outline_0023
                                   2150 	.globl _ak820_outline_0025
                                   2151 	.globl _ak820_outline_0031
                                   2152 	.globl _ak820_outline_0032
                                   2153 	.globl _ak820_outline_0033
                                   2154 	.globl _ak820_outline_0036
                                   2155 	.globl _ak820_outline_0037
                                   2156 	.globl _ak820_outline_0052
                                   2157 	.globl _ak820_outline_0055
                                   2158 	.globl _ak820_outline_0057
                                   2159 	.globl _ak820_outline_0060
                                   2160 	.globl _ak820_outline_0072
                                   2161 	.globl _ak820_outline_0075
                                   2162 	.globl _ak820_outline_0079
                                   2163 	.globl _ak820_outline_0093
                                   2164 	.globl _ak820_outline_0096
                                   2165 	.globl _ak820_outline_0107
                                   2166 	.globl _ak820_outline_0108
                                   2167 	.globl _ak820_outline_0118
                                   2168 	.globl _ak820_outline_0122
                                   2169 	.globl _ak820_outline_0123
                                   2170 	.globl _ak820_outline_0124
                                   2171 	.globl _ak820_outline_0125
                                   2172 	.globl _ak820_outline_0127
                                   2173 	.globl _ak820_outline_0128
                                   2174 	.globl _ak820_outline_0137
                                   2175 	.globl _ak820_outline_0141
                                   2176 	.globl _ak820_outline_0144
                                   2177 	.globl _ak820_outline_0161
                                   2178 	.globl _ak820_outline_0182
                                   2179 	.globl _ak820_outline_0185
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0025
      00B698                       2183 _ak820_outline_0025:
      00B698 E0               [24] 2184 	movx	a,@dptr
      00B699 FE               [12] 2185 	mov	r6,a
      00B69A A3               [24] 2186 	inc	dptr
      00B69B E0               [24] 2187 	movx	a,@dptr
      00B69C FF               [12] 2188 	mov	r7,a
      00B69D 90 0C AB         [24] 2189 	mov	dptr,#_g_vial_magic_keycode_override
      00B6A0 EE               [12] 2190 	mov	a,r6
      00B6A1 F0               [24] 2191 	movx	@dptr,a
      00B6A2 EF               [12] 2192 	mov	a,r7
      00B6A3 A3               [24] 2193 	inc	dptr
      00B6A4 F0               [24] 2194 	movx	@dptr,a
      00B6A5 8E 04            [24] 2195 	mov	ar4,r6
      00B6A7 8F 05            [24] 2196 	mov	ar5,r7
      00B6A9 C3               [12] 2197 	clr	c
      00B6AA 74 FF            [12] 2198 	mov	a,#0xff
      00B6AC 9C               [12] 2199 	subb	a,r4
      00B6AD 74 1F            [12] 2200 	mov	a,#0x1f
      00B6AF 9D               [12] 2201 	subb	a,r5
      00B6B0 22               [24] 2202 	ret
                                   2203 
                                   2204 	.area CSEG (CODE)
                                   2205 ; function ak820_outline_0127
      00B6B1                       2206 _ak820_outline_0127:
      00B6B1 24 59            [12] 2207 	add	a,#_vial_unlock_combo_cols
      00B6B3 F5 82            [12] 2208 	mov	dpl,a
      00B6B5 E4               [12] 2209 	clr	a
      00B6B6 34 0E            [12] 2210 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B6B8 F5 83            [12] 2211 	mov	dph,a
      00B6BA E0               [24] 2212 	movx	a,@dptr
      00B6BB 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0128
      00B6BC                       2217 _ak820_outline_0128:
      00B6BC 24 57            [12] 2218 	add	a,#_vial_unlock_combo_rows
      00B6BE F5 82            [12] 2219 	mov	dpl,a
      00B6C0 E4               [12] 2220 	clr	a
      00B6C1 34 0E            [12] 2221 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B6C3 F5 83            [12] 2222 	mov	dph,a
      00B6C5 E0               [24] 2223 	movx	a,@dptr
      00B6C6 22               [24] 2224 	ret
