                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000001                        539 _input_sloc0_1_0:
      000001                        540 	.ds 1
      000002                        541 _output_sloc0_1_0:
      000002                        542 	.ds 1
      000003                        543 _ak820_combo_valid_sloc0_1_0:
      000003                        544 	.ds 1
      000004                        545 _ak820_combo_process_sloc0_1_0:
      000004                        546 	.ds 1
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000432                        555 _input_code_10000_593:
      000432                        556 	.ds 2
      000434                        557 _output_code_10000_595:
      000434                        558 	.ds 2
      000436                        559 _combos:
      000436                        560 	.ds 32
      000456                        561 _saved:
      000456                        562 	.ds 9
      00045F                        563 _active:
      00045F                        564 	.ds 1
      000460                        565 _ak820_combo_valid_entry_10000_597:
      000460                        566 	.ds 2
      000462                        567 _ak820_combo_reload_entry_30000_609:
      000462                        568 	.ds 10
      00046C                        569 _ak820_combo_tick_now_10000_614:
      00046C                        570 	.ds 2
      00046E                        571 _ak820_combo_process_record_10000_617:
      00046E                        572 	.ds 2
      000470                        573 _ak820_combo_process_eligible_10001_632:
      000470                        574 	.ds 1
      000471                        575 _ak820_combo_process_i_40001_635:
      000471                        576 	.ds 1
      000472                        577 _ak820_combo_process_a_50001_636:
      000472                        578 	.ds 1
      000473                        579 _ak820_combo_process_b_50001_636:
      000473                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
      000DE2                        589 _first:
      000DE2                        590 	.ds 1
      000DE3                        591 _second:
      000DE3                        592 	.ds 1
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    621 ;------------------------------------------------------------
                                    622 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    623 ;------------------------------------------------------------
                                    624 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function input
                                    635 ;	-----------------------------------------
      0036E1                        636 _input:
      0036E1 12 3A F0         [24]  637 	lcall	_ak820_outline_0107
      0036E4 90 04 32         [24]  638 	mov	dptr,#_input_code_10000_593
      0036E7 12 3A F5         [24]  639 	lcall	_ak820_outline_0108
      0036EA 90 04 32         [24]  640 	mov	dptr,#_input_code_10000_593
      0036ED 12 3A AF         [24]  641 	lcall	_ak820_outline_0052
      0036F0 C3               [12]  642 	clr	c
      0036F1 EE               [12]  643 	mov	a,r6
      0036F2 94 04            [12]  644 	subb	a,#0x04
      0036F4 EF               [12]  645 	mov	a,r7
      0036F5 94 00            [12]  646 	subb	a,#0x00
      0036F7 40 07            [24]  647 	jc	00103$
      0036F9 74 A4            [12]  648 	mov	a,#0xa4
      0036FB 9E               [12]  649 	subb	a,r6
      0036FC E4               [12]  650 	clr	a
      0036FD 9F               [12]  651 	subb	a,r7
      0036FE 50 04            [24]  652 	jnc	00104$
                                    653 ;	free result
      003700                        654 00103$:
                                    655 ;	assignBit
      003700 C2 01            [12]  656 	clr	_input_sloc0_1_0
      003702 80 02            [24]  657 	sjmp	00105$
      003704                        658 00104$:
                                    659 ;	assignBit
      003704 D2 01            [12]  660 	setb	_input_sloc0_1_0
      003706                        661 00105$:
      003706 A2 01            [12]  662 	mov	c,_input_sloc0_1_0
      003708 12 3B 1F         [24]  663 	lcall	_ak820_outline_0160
      00370B 22               [24]  664 	ret
                                    665 ;------------------------------------------------------------
                                    666 ;Allocation info for local variables in function 'output'
                                    667 ;------------------------------------------------------------
                                    668 ;code          Allocated with name '_output_code_10000_595'
                                    669 ;basic         Allocated with name '_output_basic_10000_596'
                                    670 ;------------------------------------------------------------
                                    671 ;	keyboards/ajazz/ak820/ak820_combo.c:10: static bool output(uint16_t code) {
                                    672 ;	-----------------------------------------
                                    673 ;	 function output
                                    674 ;	-----------------------------------------
      00370C                        675 _output:
      00370C 12 3A F0         [24]  676 	lcall	_ak820_outline_0107
      00370F 90 04 34         [24]  677 	mov	dptr,#_output_code_10000_595
      003712 12 3A F5         [24]  678 	lcall	_ak820_outline_0108
                                    679 ;	keyboards/ajazz/ak820/ak820_combo.c:11: uint8_t basic = code;
      003715 90 04 34         [24]  680 	mov	dptr,#_output_code_10000_595
      003718 12 3A AF         [24]  681 	lcall	_ak820_outline_0052
      00371B 8E 05            [24]  682 	mov	ar5,r6
                                    683 ;	keyboards/ajazz/ak820/ak820_combo.c:12: return code < QK_MOD_TAP && (input(basic) || (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI));
      00371D 74 E0            [12]  684 	mov	a,#0x100 - 0x20
      00371F 2F               [12]  685 	add	a,r7
      003720 40 1B            [24]  686 	jc	00103$
      003722 8D 06            [24]  687 	mov	ar6,r5
      003724 7F 00            [12]  688 	mov	r7,#0x00
      003726 12 3A FA         [24]  689 	lcall	_ak820_outline_0118
      003729 C0 05            [24]  690 	push	ar5
      00372B D1 E1            [12]  691 	acall	_input
      00372D E5 82            [12]  692 	mov	a, dpl
      00372F D0 05            [24]  693 	pop	ar5
      003731 70 0E            [24]  694 	jnz	00104$
      003733 BD E0 00         [24]  695 	cjne	r5,#0xe0,00135$
      003736                        696 00135$:
      003736 40 05            [24]  697 	jc	00103$
      003738 ED               [12]  698 	mov	a,r5
      003739 24 18            [12]  699 	add	a,#0xff - 0xe7
      00373B 50 04            [24]  700 	jnc	00104$
                                    701 ;	free result
      00373D                        702 00103$:
                                    703 ;	assignBit
      00373D C2 02            [12]  704 	clr	_output_sloc0_1_0
      00373F 80 02            [24]  705 	sjmp	00105$
      003741                        706 00104$:
                                    707 ;	assignBit
      003741 D2 02            [12]  708 	setb	_output_sloc0_1_0
      003743                        709 00105$:
      003743 A2 02            [12]  710 	mov	c,_output_sloc0_1_0
      003745 12 3B 1F         [24]  711 	lcall	_ak820_outline_0160
                                    712 ;	keyboards/ajazz/ak820/ak820_combo.c:13: }
      003748 22               [24]  713 	ret
                                    714 ;------------------------------------------------------------
                                    715 ;Allocation info for local variables in function 'ak820_combo_valid'
                                    716 ;------------------------------------------------------------
                                    717 ;entry         Allocated with name '_ak820_combo_valid_entry_10000_597'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_combo.c:19: bool ak820_combo_valid(const vial_combo_entry_t AK820_STATE_MEM *entry) {
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_combo_valid
                                    722 ;	-----------------------------------------
      003749                        723 _ak820_combo_valid:
      003749 12 3A F0         [24]  724 	lcall	_ak820_outline_0107
      00374C 90 04 60         [24]  725 	mov	dptr,#_ak820_combo_valid_entry_10000_597
      00374F 12 3A F5         [24]  726 	lcall	_ak820_outline_0108
                                    727 ;	keyboards/ajazz/ak820/ak820_combo.c:20: if (entry->input[2] || entry->input[3]) return false;
      003752 90 04 60         [24]  728 	mov	dptr,#_ak820_combo_valid_entry_10000_597
      003755 12 3A 62         [24]  729 	lcall	_ak820_outline_0005
      003758 A3               [24]  730 	inc	dptr
      003759 A3               [24]  731 	inc	dptr
      00375A A3               [24]  732 	inc	dptr
      00375B A3               [24]  733 	inc	dptr
      00375C E0               [24]  734 	movx	a,@dptr
      00375D FC               [12]  735 	mov	r4,a
      00375E A3               [24]  736 	inc	dptr
      00375F E0               [24]  737 	movx	a,@dptr
      003760 4C               [12]  738 	orl	a,r4
      003761 70 0C            [24]  739 	jnz	00101$
      003763 74 06            [12]  740 	mov	a,#0x06
      003765 12 3A 9F         [24]  741 	lcall	_ak820_outline_0022
      003768 E0               [24]  742 	movx	a,@dptr
      003769 FC               [12]  743 	mov	r4,a
      00376A A3               [24]  744 	inc	dptr
      00376B E0               [24]  745 	movx	a,@dptr
      00376C 4C               [12]  746 	orl	a,r4
      00376D 60 04            [24]  747 	jz	00102$
      00376F                        748 00101$:
      00376F 75 82 00         [24]  749 	mov	dpl, #0x00
      003772 22               [24]  750 	ret
      003773                        751 00102$:
                                    752 ;	keyboards/ajazz/ak820/ak820_combo.c:21: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      003773 8E 04            [24]  753 	mov	ar4,r6
      003775 8F 05            [24]  754 	mov	ar5,r7
      003777 12 3A A7         [24]  755 	lcall	_ak820_outline_0037
      00377A FA               [12]  756 	mov	r2,a
      00377B A3               [24]  757 	inc	dptr
      00377C E0               [24]  758 	movx	a,@dptr
      00377D FB               [12]  759 	mov	r3,a
      00377E 12 3A FF         [24]  760 	lcall	_ak820_outline_0123
      003781 12 3A C6         [24]  761 	lcall	_ak820_outline_0061
      003784 EA               [12]  762 	mov	a,r2
      003785 4C               [12]  763 	orl	a,r4
      003786 F8               [12]  764 	mov	r0,a
      003787 EB               [12]  765 	mov	a,r3
      003788 4D               [12]  766 	orl	a,r5
      003789 48               [12]  767 	orl	a,r0
      00378A 70 13            [24]  768 	jnz	00105$
      00378C 74 08            [12]  769 	mov	a,#0x08
      00378E 12 3A 9F         [24]  770 	lcall	_ak820_outline_0022
      003791 E0               [24]  771 	movx	a,@dptr
      003792 F8               [12]  772 	mov	r0,a
      003793 A3               [24]  773 	inc	dptr
      003794 E0               [24]  774 	movx	a,@dptr
      003795 48               [12]  775 	orl	a,r0
      003796 B4 01 00         [24]  776 	cjne	a,#0x01,00152$
      003799                        777 00152$:
      003799 92 03            [24]  778 	mov  _ak820_combo_valid_sloc0_1_0,c
      00379B 12 3B 1F         [24]  779 	lcall	_ak820_outline_0160
      00379E 22               [24]  780 	ret
      00379F                        781 00105$:
                                    782 ;	keyboards/ajazz/ak820/ak820_combo.c:22: if (entry->input[0] == entry->input[1]) return false;
      00379F EC               [12]  783 	mov	a,r4
      0037A0 B5 02 08         [24]  784 	cjne	a,ar2,00107$
      0037A3 ED               [12]  785 	mov	a,r5
      0037A4 B5 03 04         [24]  786 	cjne	a,ar3,00107$
      0037A7 75 82 00         [24]  787 	mov	dpl, #0x00
      0037AA 22               [24]  788 	ret
      0037AB                        789 00107$:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:23: if (!input(entry->input[0])) return false;
      0037AB 12 3A FF         [24]  791 	lcall	_ak820_outline_0123
      0037AE C0 07            [24]  792 	push	ar7
      0037B0 C0 06            [24]  793 	push	ar6
      0037B2 C0 03            [24]  794 	push	ar3
      0037B4 C0 02            [24]  795 	push	ar2
      0037B6 D1 E1            [12]  796 	acall	_input
      0037B8 E5 82            [12]  797 	mov	a, dpl
      0037BA D0 02            [24]  798 	pop	ar2
      0037BC D0 03            [24]  799 	pop	ar3
      0037BE D0 06            [24]  800 	pop	ar6
      0037C0 D0 07            [24]  801 	pop	ar7
      0037C2 70 03            [24]  802 	jnz	00109$
      0037C4 F5 82            [12]  803 	mov	dpl,a
      0037C6 22               [24]  804 	ret
      0037C7                        805 00109$:
                                    806 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (!input(entry->input[1])) return false;
      0037C7 12 3B 1A         [24]  807 	lcall	_ak820_outline_0144
      0037CA C0 07            [24]  808 	push	ar7
      0037CC C0 06            [24]  809 	push	ar6
      0037CE D1 E1            [12]  810 	acall	_input
      0037D0 E5 82            [12]  811 	mov	a, dpl
      0037D2 D0 06            [24]  812 	pop	ar6
      0037D4 D0 07            [24]  813 	pop	ar7
      0037D6 70 03            [24]  814 	jnz	00111$
      0037D8 F5 82            [12]  815 	mov	dpl,a
      0037DA 22               [24]  816 	ret
      0037DB                        817 00111$:
                                    818 ;	keyboards/ajazz/ak820/ak820_combo.c:25: return output(entry->output);
      0037DB 74 08            [12]  819 	mov	a,#0x08
      0037DD 12 3A 9F         [24]  820 	lcall	_ak820_outline_0022
      0037E0 12 3A 62         [24]  821 	lcall	_ak820_outline_0005
                                    822 ;	keyboards/ajazz/ak820/ak820_combo.c:26: }
      0037E3 E1 0C            [12]  823 	ajmp	_output
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    826 ;------------------------------------------------------------
                                    827 ;	keyboards/ajazz/ak820/ak820_combo.c:29: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    828 ;	-----------------------------------------
                                    829 ;	 function ak820_combo_cancel
                                    830 ;	-----------------------------------------
      0037E5                        831 _ak820_combo_cancel:
      0037E5 90 0D E3         [24]  832 	mov	dptr,#_second
      0037E8 74 FF            [12]  833 	mov	a,#0xff
      0037EA F0               [24]  834 	movx	@dptr,a
      0037EB 90 0D E2         [24]  835 	mov	dptr,#_first
      0037EE F0               [24]  836 	movx	@dptr,a
      0037EF 90 04 5F         [24]  837 	mov	dptr,#_active
      0037F2 E4               [12]  838 	clr	a
      0037F3 F0               [24]  839 	movx	@dptr,a
      0037F4 22               [24]  840 	ret
                                    841 ;------------------------------------------------------------
                                    842 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    843 ;------------------------------------------------------------
                                    844 ;i             Allocated with name '_ak820_combo_reload_i_20000_608'
                                    845 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_609'
                                    846 ;------------------------------------------------------------
                                    847 ;	keyboards/ajazz/ak820/ak820_combo.c:30: void ak820_combo_reload(void) {
                                    848 ;	-----------------------------------------
                                    849 ;	 function ak820_combo_reload
                                    850 ;	-----------------------------------------
      0037F5                        851 _ak820_combo_reload:
                                    852 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0037F5 7F 00            [12]  853 	mov	r7,#0x00
      0037F7                        854 00105$:
      0037F7 BF 08 00         [24]  855 	cjne	r7,#0x08,00131$
      0037FA                        856 00131$:
      0037FA 40 01            [24]  857 	jc	00132$
      0037FC 22               [24]  858 	ret
      0037FD                        859 00132$:
                                    860 ;	keyboards/ajazz/ak820/ak820_combo.c:33: combos[i].a = 0;
      0037FD EF               [12]  861 	mov	a,r7
      0037FE 75 F0 04         [24]  862 	mov	b,#0x04
      003801 A4               [48]  863 	mul	ab
      003802 24 36            [12]  864 	add	a, #_combos
      003804 FD               [12]  865 	mov	r5,a
      003805 74 04            [12]  866 	mov	a,#(_combos >> 8)
      003807 35 F0            [12]  867 	addc	a, b
      003809 FE               [12]  868 	mov	r6,a
      00380A 8D 03            [24]  869 	mov	ar3,r5
      00380C 8E 04            [24]  870 	mov	ar4,r6
      00380E 12 36 75         [24]  871 	lcall	_ak820_outline_0122
      003811 E4               [12]  872 	clr	a
      003812 F0               [24]  873 	movx	@dptr,a
                                    874 ;	keyboards/ajazz/ak820/ak820_combo.c:34: if (!dynamic_keymap_get_combo(i, &entry)) {
      003813 90 0B 1F         [24]  875 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003816 74 62            [12]  876 	mov	a,#_ak820_combo_reload_entry_30000_609
      003818 F0               [24]  877 	movx	@dptr,a
      003819 74 04            [12]  878 	mov	a,#(_ak820_combo_reload_entry_30000_609 >> 8)
      00381B 12 3A CC         [24]  879 	lcall	_ak820_outline_0072
      00381E 8F 82            [24]  880 	mov	dpl, r7
      003820 C0 07            [24]  881 	push	ar7
      003822 C0 06            [24]  882 	push	ar6
      003824 C0 05            [24]  883 	push	ar5
      003826 C0 04            [24]  884 	push	ar4
      003828 C0 03            [24]  885 	push	ar3
      00382A 12 8A 88         [24]  886 	lcall	_dynamic_keymap_get_combo
      00382D 12 3B 0E         [24]  887 	lcall	_ak820_outline_0136
      003830 D0 03            [24]  888 	pop	ar3
      003832 D0 04            [24]  889 	pop	ar4
      003834 D0 05            [24]  890 	pop	ar5
      003836 D0 06            [24]  891 	pop	ar6
      003838 D0 07            [24]  892 	pop	ar7
      00383A 45 F0            [12]  893 	orl	a,b
      00383C 70 28            [24]  894 	jnz	00106$
                                    895 ;	keyboards/ajazz/ak820/ak820_combo.c:35: combos[i].a = entry.input[0];
      00383E 90 04 62         [24]  896 	mov	dptr,#_ak820_combo_reload_entry_30000_609
      003841 E0               [24]  897 	movx	a,@dptr
      003842 12 36 75         [24]  898 	lcall	_ak820_outline_0122
      003845 F0               [24]  899 	movx	@dptr,a
                                    900 ;	keyboards/ajazz/ak820/ak820_combo.c:36: combos[i].b = entry.input[1];
      003846 74 01            [12]  901 	mov	a,#0x01
      003848 2D               [12]  902 	add	a, r5
      003849 FB               [12]  903 	mov	r3,a
      00384A E4               [12]  904 	clr	a
      00384B 3E               [12]  905 	addc	a, r6
      00384C FC               [12]  906 	mov	r4,a
      00384D 90 04 64         [24]  907 	mov	dptr,#(_ak820_combo_reload_entry_30000_609 + 0x0002)
      003850 E0               [24]  908 	movx	a,@dptr
      003851 12 36 75         [24]  909 	lcall	_ak820_outline_0122
      003854 F0               [24]  910 	movx	@dptr,a
                                    911 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].output = entry.output;
      003855 74 02            [12]  912 	mov	a,#0x02
      003857 12 3B 29         [24]  913 	lcall	_ak820_outline_0163
      00385A 90 04 6A         [24]  914 	mov	dptr,#(_ak820_combo_reload_entry_30000_609 + 0x0008)
      00385D 12 3B 14         [24]  915 	lcall	_ak820_outline_0141
      003860 12 3B 09         [24]  916 	lcall	_ak820_outline_0133
      003863 12 3A DE         [24]  917 	lcall	_ak820_outline_0093
      003866                        918 00106$:
                                    919 ;	keyboards/ajazz/ak820/ak820_combo.c:31: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003866 0F               [12]  920 	inc	r7
                                    921 ;	keyboards/ajazz/ak820/ak820_combo.c:40: }
      003867 02 37 F7         [24]  922 	ljmp	00105$
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'flush'
                                    925 ;------------------------------------------------------------
                                    926 ;	keyboards/ajazz/ak820/ak820_combo.c:41: static void flush(void) {
                                    927 ;	-----------------------------------------
                                    928 ;	 function flush
                                    929 ;	-----------------------------------------
      00386A                        930 _flush:
                                    931 ;	keyboards/ajazz/ak820/ak820_combo.c:42: first = NONE;
      00386A 90 0D E2         [24]  932 	mov	dptr,#_first
      00386D 74 FF            [12]  933 	mov	a,#0xff
      00386F F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_combo.c:43: process_record(&saved);
      003870 90 04 56         [24]  936 	mov	dptr,#_saved
      003873 75 F0 00         [24]  937 	mov	b, #0x00
                                    938 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      003876 02 75 C5         [24]  939 	ljmp	_process_record
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    942 ;------------------------------------------------------------
                                    943 ;now           Allocated with name '_ak820_combo_tick_now_10000_614'
                                    944 ;------------------------------------------------------------
                                    945 ;	keyboards/ajazz/ak820/ak820_combo.c:45: void ak820_combo_tick(uint16_t now) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function ak820_combo_tick
                                    948 ;	-----------------------------------------
      003879                        949 _ak820_combo_tick:
      003879 12 3A F0         [24]  950 	lcall	_ak820_outline_0107
      00387C 90 04 6C         [24]  951 	mov	dptr,#_ak820_combo_tick_now_10000_614
      00387F 12 3A F5         [24]  952 	lcall	_ak820_outline_0108
                                    953 ;	keyboards/ajazz/ak820/ak820_combo.c:46: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= 40) flush();
      003882 12 3B 2F         [24]  954 	lcall	_ak820_outline_0183
      003885 FF               [12]  955 	mov	r7,a
      003886 BF FF 01         [24]  956 	cjne	r7,#0xff,00128$
      003889 22               [24]  957 	ret
      00388A                        958 00128$:
      00388A 90 04 5F         [24]  959 	mov	dptr,#_active
      00388D E0               [24]  960 	movx	a,@dptr
      00388E 70 1E            [24]  961 	jnz	00105$
      003890 90 04 58         [24]  962 	mov	dptr,#(_saved + 0x0002)
      003893 12 3A AF         [24]  963 	lcall	_ak820_outline_0052
      003896 90 04 6C         [24]  964 	mov	dptr,#_ak820_combo_tick_now_10000_614
      003899 12 3A C6         [24]  965 	lcall	_ak820_outline_0061
      00389C EC               [12]  966 	mov	a,r4
      00389D C3               [12]  967 	clr	c
      00389E 9E               [12]  968 	subb	a,r6
      00389F FE               [12]  969 	mov	r6,a
      0038A0 ED               [12]  970 	mov	a,r5
      0038A1 9F               [12]  971 	subb	a,r7
      0038A2 FF               [12]  972 	mov	r7,a
      0038A3 C3               [12]  973 	clr	c
      0038A4 EE               [12]  974 	mov	a,r6
      0038A5 94 28            [12]  975 	subb	a,#0x28
      0038A7 EF               [12]  976 	mov	a,r7
      0038A8 94 00            [12]  977 	subb	a,#0x00
      0038AA 40 02            [24]  978 	jc	00105$
                                    979 ;	keyboards/ajazz/ak820/ak820_combo.c:47: }
      0038AC 01 6A            [24]  980 	ajmp	_flush
      0038AE                        981 00105$:
      0038AE 22               [24]  982 	ret
                                    983 ;------------------------------------------------------------
                                    984 ;Allocation info for local variables in function 'ak820_combo_process'
                                    985 ;------------------------------------------------------------
                                    986 ;record        Allocated with name '_ak820_combo_process_record_10000_617'
                                    987 ;id            Allocated with name '_ak820_combo_process_id_10000_618'
                                    988 ;code          Allocated with name '_ak820_combo_process_code_10000_618'
                                    989 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_632'
                                    990 ;previous      Allocated with name '_ak820_combo_process_previous_30001_634'
                                    991 ;i             Allocated with name '_ak820_combo_process_i_40001_635'
                                    992 ;a             Allocated with name '_ak820_combo_process_a_50001_636'
                                    993 ;b             Allocated with name '_ak820_combo_process_b_50001_636'
                                    994 ;------------------------------------------------------------
                                    995 ;	keyboards/ajazz/ak820/ak820_combo.c:48: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function ak820_combo_process
                                    998 ;	-----------------------------------------
      0038AF                        999 _ak820_combo_process:
      0038AF 12 3A F0         [24] 1000 	lcall	_ak820_outline_0107
      0038B2 90 04 6E         [24] 1001 	mov	dptr,#_ak820_combo_process_record_10000_617
      0038B5 12 3A F5         [24] 1002 	lcall	_ak820_outline_0108
                                   1003 ;	keyboards/ajazz/ak820/ak820_combo.c:49: uint8_t id, code = record->keycode;
      0038B8 90 04 6E         [24] 1004 	mov	dptr,#_ak820_combo_process_record_10000_617
      0038BB 12 3A 6C         [24] 1005 	lcall	_ak820_outline_0007
      0038BE 8C 03            [24] 1006 	mov	ar3,r4
                                   1007 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (IS_NOEVENT(record->event)) return true;
      0038C0 74 04            [12] 1008 	mov	a,#0x04
      0038C2 2E               [12] 1009 	add	a, r6
      0038C3 12 3A 95         [24] 1010 	lcall	_ak820_outline_0017
      0038C6 70 04            [24] 1011 	jnz	00102$
      0038C8 75 82 01         [24] 1012 	mov	dpl, #0x01
      0038CB 22               [24] 1013 	ret
      0038CC                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_combo.c:52: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      0038CC 12 3A FA         [24] 1016 	lcall	_ak820_outline_0118
      0038CF A3               [24] 1017 	inc	dptr
      0038D0 E0               [24] 1018 	movx	a,@dptr
      0038D1 FA               [12] 1019 	mov	r2,a
      0038D2 BA 10 00         [24] 1020 	cjne	r2,#0x10,00300$
      0038D5                       1021 00300$:
      0038D5 50 0A            [24] 1022 	jnc	00106$
      0038D7 12 3A FA         [24] 1023 	lcall	_ak820_outline_0118
      0038DA E0               [24] 1024 	movx	a,@dptr
      0038DB F9               [12] 1025 	mov	r1,a
      0038DC B9 08 00         [24] 1026 	cjne	r1,#0x08,00302$
      0038DF                       1027 00302$:
      0038DF 40 15            [24] 1028 	jc	00107$
      0038E1                       1029 00106$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_combo.c:53: if (first != NONE && !active) flush();
      0038E1 12 3B 2F         [24] 1031 	lcall	_ak820_outline_0183
      0038E4 F8               [12] 1032 	mov	r0,a
      0038E5 B8 FF 02         [24] 1033 	cjne	r0,#0xff,00304$
      0038E8 80 08            [24] 1034 	sjmp	00104$
      0038EA                       1035 00304$:
      0038EA 90 04 5F         [24] 1036 	mov	dptr,#_active
      0038ED E0               [24] 1037 	movx	a,@dptr
      0038EE 70 02            [24] 1038 	jnz	00104$
      0038F0 11 6A            [24] 1039 	acall	_flush
      0038F2                       1040 00104$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_combo.c:54: return true;
      0038F2 75 82 01         [24] 1042 	mov	dpl, #0x01
      0038F5 22               [24] 1043 	ret
      0038F6                       1044 00107$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_combo.c:56: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      0038F6 EA               [12] 1046 	mov	a,r2
      0038F7 12 3B 34         [24] 1047 	lcall	_ak820_outline_0191
      0038FA 29               [12] 1048 	add	a,r1
      0038FB FA               [12] 1049 	mov	r2,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (active) {
      0038FC 90 04 5F         [24] 1051 	mov	dptr,#_active
      0038FF E0               [24] 1052 	movx	a,@dptr
      003900 60 71            [24] 1053 	jz	00123$
                                   1054 ;	keyboards/ajazz/ak820/ak820_combo.c:58: if (id != first && id != second) return true;
      003902 12 3B 2F         [24] 1055 	lcall	_ak820_outline_0183
      003905 F9               [12] 1056 	mov	r1,a
      003906 EA               [12] 1057 	mov	a,r2
      003907 B5 01 02         [24] 1058 	cjne	a,ar1,00307$
      00390A 80 0F            [24] 1059 	sjmp	00110$
      00390C                       1060 00307$:
      00390C 90 0D E3         [24] 1061 	mov	dptr,#_second
      00390F E0               [24] 1062 	movx	a,@dptr
      003910 F9               [12] 1063 	mov	r1,a
      003911 EA               [12] 1064 	mov	a,r2
      003912 B5 01 02         [24] 1065 	cjne	a,ar1,00308$
      003915 80 04            [24] 1066 	sjmp	00110$
      003917                       1067 00308$:
      003917 75 82 01         [24] 1068 	mov	dpl, #0x01
      00391A 22               [24] 1069 	ret
      00391B                       1070 00110$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_combo.c:59: if (!record->event.pressed) {
      00391B 90 04 6E         [24] 1072 	mov	dptr,#_ak820_combo_process_record_10000_617
      00391E 12 3A EA         [24] 1073 	lcall	_ak820_outline_0101
      003921 74 05            [12] 1074 	mov	a,#0x05
      003923 28               [12] 1075 	add	a, r0
      003924 F8               [12] 1076 	mov	r0,a
      003925 E4               [12] 1077 	clr	a
      003926 39               [12] 1078 	addc	a, r1
      003927 F9               [12] 1079 	mov	r1,a
      003928 12 3B 24         [24] 1080 	lcall	_ak820_outline_0161
      00392B E0               [24] 1081 	movx	a,@dptr
      00392C 70 41            [24] 1082 	jnz	00121$
                                   1083 ;	keyboards/ajazz/ak820/ak820_combo.c:60: if (saved.event.pressed) {
      00392E 90 04 5B         [24] 1084 	mov	dptr,#(_saved + 0x0005)
      003931 E0               [24] 1085 	movx	a,@dptr
      003932 60 11            [24] 1086 	jz	00113$
                                   1087 ;	keyboards/ajazz/ak820/ak820_combo.c:61: saved.event.pressed = false;
      003934 90 04 5B         [24] 1088 	mov	dptr,#(_saved + 0x0005)
      003937 E4               [12] 1089 	clr	a
      003938 F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:62: process_record(&saved);
      003939 90 04 56         [24] 1092 	mov	dptr,#_saved
      00393C F5 F0            [12] 1093 	mov	b,a
      00393E C0 02            [24] 1094 	push	ar2
      003940 12 75 C5         [24] 1095 	lcall	_process_record
      003943 D0 02            [24] 1096 	pop	ar2
      003945                       1097 00113$:
                                   1098 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (id == first) first = NONE;
      003945 12 3B 2F         [24] 1099 	lcall	_ak820_outline_0183
      003948 F9               [12] 1100 	mov	r1,a
      003949 EA               [12] 1101 	mov	a,r2
      00394A B5 01 08         [24] 1102 	cjne	a,ar1,00115$
      00394D 90 0D E2         [24] 1103 	mov	dptr,#_first
      003950 74 FF            [12] 1104 	mov	a,#0xff
      003952 F0               [24] 1105 	movx	@dptr,a
      003953 80 06            [24] 1106 	sjmp	00116$
      003955                       1107 00115$:
                                   1108 ;	keyboards/ajazz/ak820/ak820_combo.c:65: else second = NONE;
      003955 90 0D E3         [24] 1109 	mov	dptr,#_second
      003958 74 FF            [12] 1110 	mov	a,#0xff
      00395A F0               [24] 1111 	movx	@dptr,a
      00395B                       1112 00116$:
                                   1113 ;	keyboards/ajazz/ak820/ak820_combo.c:66: if (first == NONE && second == NONE) active = false;
      00395B 12 3B 2F         [24] 1114 	lcall	_ak820_outline_0183
      00395E F9               [12] 1115 	mov	r1,a
      00395F B9 FF 0D         [24] 1116 	cjne	r1,#0xff,00121$
      003962 90 0D E3         [24] 1117 	mov	dptr,#_second
      003965 E0               [24] 1118 	movx	a,@dptr
      003966 F9               [12] 1119 	mov	r1,a
      003967 B9 FF 05         [24] 1120 	cjne	r1,#0xff,00121$
      00396A 90 04 5F         [24] 1121 	mov	dptr,#_active
      00396D E4               [12] 1122 	clr	a
      00396E F0               [24] 1123 	movx	@dptr,a
      00396F                       1124 00121$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_combo.c:68: return false;
      00396F 75 82 00         [24] 1126 	mov	dpl, #0x00
      003972 22               [24] 1127 	ret
      003973                       1128 00123$:
                                   1129 ;	keyboards/ajazz/ak820/ak820_combo.c:70: bool eligible = false;
      003973 90 04 70         [24] 1130 	mov	dptr,#_ak820_combo_process_eligible_10001_632
      003976 E4               [12] 1131 	clr	a
      003977 F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_combo.c:71: if (record->event.pressed && input(record->keycode)) {
      003978 12 3A 80         [24] 1134 	lcall	_ak820_outline_0009
      00397B 70 02            [24] 1135 	jnz	00317$
      00397D 41 21            [12] 1136 	ajmp	00134$
      00397F                       1137 00317$:
      00397F 12 3A FF         [24] 1138 	lcall	_ak820_outline_0123
      003982 C0 03            [24] 1139 	push	ar3
      003984 C0 02            [24] 1140 	push	ar2
      003986 12 36 E1         [24] 1141 	lcall	_input
      003989 E5 82            [12] 1142 	mov	a, dpl
      00398B D0 02            [24] 1143 	pop	ar2
      00398D D0 03            [24] 1144 	pop	ar3
      00398F 70 02            [24] 1145 	jnz	00318$
      003991 41 21            [12] 1146 	ajmp	00134$
      003993                       1147 00318$:
                                   1148 ;	keyboards/ajazz/ak820/ak820_combo.c:72: uint8_t previous = saved.keycode;
      003993 90 04 5D         [24] 1149 	mov	dptr,#(_saved + 0x0007)
      003996 E0               [24] 1150 	movx	a,@dptr
      003997 FF               [12] 1151 	mov	r7,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003998 90 04 71         [24] 1153 	mov	dptr,#_ak820_combo_process_i_40001_635
      00399B E4               [12] 1154 	clr	a
      00399C F0               [24] 1155 	movx	@dptr,a
      00399D EB               [12] 1156 	mov	a,r3
      00399E B5 07 03         [24] 1157 	cjne	a,ar7,00319$
      0039A1 D3               [12] 1158 	setb	c
      0039A2 80 01            [24] 1159 	sjmp	00320$
      0039A4                       1160 00319$:
      0039A4 C3               [12] 1161 	clr	c
      0039A5                       1162 00320$:
      0039A5 92 04            [24] 1163 	mov	_ak820_combo_process_sloc0_1_0,c
      0039A7 7E 00            [12] 1164 	mov	r6,#0x00
      0039A9                       1165 00141$:
      0039A9 BE 08 00         [24] 1166 	cjne	r6,#0x08,00321$
      0039AC                       1167 00321$:
      0039AC 40 02            [24] 1168 	jc	00322$
      0039AE 41 21            [12] 1169 	ajmp	00134$
      0039B0                       1170 00322$:
                                   1171 ;	keyboards/ajazz/ak820/ak820_combo.c:74: uint8_t a = combos[i].a, b = combos[i].b;
      0039B0 EE               [12] 1172 	mov	a,r6
      0039B1 12 3A B5         [24] 1173 	lcall	_ak820_outline_0054
      0039B4 E0               [24] 1174 	movx	a,@dptr
      0039B5 F9               [12] 1175 	mov	r1,a
      0039B6 90 04 72         [24] 1176 	mov	dptr,#_ak820_combo_process_a_50001_636
      0039B9 12 3A E4         [24] 1177 	lcall	_ak820_outline_0096
      0039BC A3               [24] 1178 	inc	dptr
      0039BD E0               [24] 1179 	movx	a,@dptr
      0039BE FD               [12] 1180 	mov	r5,a
      0039BF 90 04 73         [24] 1181 	mov	dptr,#_ak820_combo_process_b_50001_636
      0039C2 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (a == code || b == code) {
      0039C3 E9               [12] 1184 	mov	a,r1
      0039C4 B5 03 02         [24] 1185 	cjne	a,ar3,00323$
      0039C7 80 04            [24] 1186 	sjmp	00129$
      0039C9                       1187 00323$:
      0039C9 ED               [12] 1188 	mov	a,r5
      0039CA B5 03 4C         [24] 1189 	cjne	a,ar3,00142$
      0039CD                       1190 00129$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_combo.c:76: eligible = true;
      0039CD 90 04 70         [24] 1192 	mov	dptr,#_ak820_combo_process_eligible_10001_632
      0039D0 74 01            [12] 1193 	mov	a,#0x01
      0039D2 F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	keyboards/ajazz/ak820/ak820_combo.c:77: if (first != NONE && code != previous && (a == previous || b == previous)) {
      0039D3 12 3B 2F         [24] 1196 	lcall	_ak820_outline_0183
      0039D6 FD               [12] 1197 	mov	r5,a
      0039D7 BD FF 02         [24] 1198 	cjne	r5,#0xff,00326$
      0039DA 80 3D            [24] 1199 	sjmp	00142$
      0039DC                       1200 00326$:
      0039DC 20 04 3A         [24] 1201 	jb	_ak820_combo_process_sloc0_1_0,00142$
      0039DF 90 04 72         [24] 1202 	mov	dptr,#_ak820_combo_process_a_50001_636
      0039E2 E0               [24] 1203 	movx	a,@dptr
      0039E3 B5 07 02         [24] 1204 	cjne	a,ar7,00328$
      0039E6 80 07            [24] 1205 	sjmp	00124$
      0039E8                       1206 00328$:
      0039E8 90 04 73         [24] 1207 	mov	dptr,#_ak820_combo_process_b_50001_636
      0039EB E0               [24] 1208 	movx	a,@dptr
      0039EC B5 07 2A         [24] 1209 	cjne	a,ar7,00142$
      0039EF                       1210 00124$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_combo.c:78: second = id;
      0039EF 90 0D E3         [24] 1212 	mov	dptr,#_second
      0039F2 EA               [12] 1213 	mov	a,r2
      0039F3 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_combo.c:79: active = true;
      0039F4 90 04 5F         [24] 1216 	mov	dptr,#_active
      0039F7 74 01            [12] 1217 	mov	a,#0x01
      0039F9 F0               [24] 1218 	movx	@dptr,a
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:80: saved.keycode = combos[i].output;
      0039FA 90 04 71         [24] 1220 	mov	dptr,#_ak820_combo_process_i_40001_635
      0039FD E0               [24] 1221 	movx	a,@dptr
      0039FE 12 3A B5         [24] 1222 	lcall	_ak820_outline_0054
      003A01 A3               [24] 1223 	inc	dptr
      003A02 A3               [24] 1224 	inc	dptr
      003A03 12 3A C6         [24] 1225 	lcall	_ak820_outline_0061
      003A06 90 04 5D         [24] 1226 	mov	dptr,#(_saved + 0x0007)
      003A09 12 3A D2         [24] 1227 	lcall	_ak820_outline_0074
                                   1228 ;	keyboards/ajazz/ak820/ak820_combo.c:81: process_record(&saved);
      003A0C 90 04 56         [24] 1229 	mov	dptr,#_saved
      003A0F 75 F0 00         [24] 1230 	mov	b, #0x00
      003A12 12 75 C5         [24] 1231 	lcall	_process_record
                                   1232 ;	keyboards/ajazz/ak820/ak820_combo.c:82: return false;
      003A15 75 82 00         [24] 1233 	mov	dpl, #0x00
      003A18 22               [24] 1234 	ret
      003A19                       1235 00142$:
                                   1236 ;	keyboards/ajazz/ak820/ak820_combo.c:73: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003A19 0E               [12] 1237 	inc	r6
      003A1A 90 04 71         [24] 1238 	mov	dptr,#_ak820_combo_process_i_40001_635
      003A1D EE               [12] 1239 	mov	a,r6
      003A1E F0               [24] 1240 	movx	@dptr,a
      003A1F 21 A9            [24] 1241 	ajmp	00141$
      003A21                       1242 00134$:
                                   1243 ;	keyboards/ajazz/ak820/ak820_combo.c:87: if (first != NONE) flush();
      003A21 12 3B 2F         [24] 1244 	lcall	_ak820_outline_0183
      003A24 FF               [12] 1245 	mov	r7,a
      003A25 BF FF 02         [24] 1246 	cjne	r7,#0xff,00331$
      003A28 80 06            [24] 1247 	sjmp	00137$
      003A2A                       1248 00331$:
      003A2A C0 02            [24] 1249 	push	ar2
      003A2C 11 6A            [24] 1250 	acall	_flush
      003A2E D0 02            [24] 1251 	pop	ar2
      003A30                       1252 00137$:
                                   1253 ;	keyboards/ajazz/ak820/ak820_combo.c:88: if (eligible) {
      003A30 90 04 70         [24] 1254 	mov	dptr,#_ak820_combo_process_eligible_10001_632
      003A33 E0               [24] 1255 	movx	a,@dptr
      003A34 60 28            [24] 1256 	jz	00139$
                                   1257 ;	keyboards/ajazz/ak820/ak820_combo.c:89: first = id;
      003A36 90 0D E2         [24] 1258 	mov	dptr,#_first
      003A39 EA               [12] 1259 	mov	a,r2
      003A3A F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	keyboards/ajazz/ak820/ak820_combo.c:90: saved = *record;
      003A3B 90 04 6E         [24] 1262 	mov	dptr,#_ak820_combo_process_record_10000_617
      003A3E 12 3A D8         [24] 1263 	lcall	_ak820_outline_0080
      003A41 7F 00            [12] 1264 	mov	r7,#0x00
      003A43 90 0D D3         [24] 1265 	mov	dptr,#___memcpy_PARM_2
      003A46 ED               [12] 1266 	mov	a,r5
      003A47 12 3A 8D         [24] 1267 	lcall	_ak820_outline_0016
      003A4A 90 0D D6         [24] 1268 	mov	dptr,#___memcpy_PARM_3
      003A4D 74 09            [12] 1269 	mov	a,#0x09
      003A4F 12 3B 04         [24] 1270 	lcall	_ak820_outline_0124
      003A52 90 04 56         [24] 1271 	mov	dptr,#_saved
      003A55 F5 F0            [12] 1272 	mov	b,a
      003A57 12 BC 62         [24] 1273 	lcall	___memcpy
                                   1274 ;	keyboards/ajazz/ak820/ak820_combo.c:91: return false;
      003A5A 75 82 00         [24] 1275 	mov	dpl, #0x00
      003A5D 22               [24] 1276 	ret
      003A5E                       1277 00139$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_combo.c:93: return true;
      003A5E 75 82 01         [24] 1279 	mov	dpl, #0x01
                                   1280 ;	keyboards/ajazz/ak820/ak820_combo.c:94: }
      003A61 22               [24] 1281 	ret
                                   1282 	.area CSEG    (CODE)
                                   1283 	.area CONST   (CODE)
                                   1284 	.area XINIT   (CODE)
      00C572                       1285 __xinit__first:
      00C572 FF                    1286 	.db #0xff	; 255
      00C573                       1287 __xinit__second:
      00C573 FF                    1288 	.db #0xff	; 255
                                   1289 	.area CABS    (ABS,CODE)
                                   1290 
                                   1291 ; Experimental exact instruction outlining.
                                   1292 	.globl _ak820_outline_0005
                                   1293 	.globl _ak820_outline_0007
                                   1294 	.globl _ak820_outline_0009
                                   1295 	.globl _ak820_outline_0016
                                   1296 	.globl _ak820_outline_0017
                                   1297 	.globl _ak820_outline_0022
                                   1298 	.globl _ak820_outline_0037
                                   1299 	.globl _ak820_outline_0052
                                   1300 	.globl _ak820_outline_0054
                                   1301 	.globl _ak820_outline_0061
                                   1302 	.globl _ak820_outline_0072
                                   1303 	.globl _ak820_outline_0074
                                   1304 	.globl _ak820_outline_0080
                                   1305 	.globl _ak820_outline_0093
                                   1306 	.globl _ak820_outline_0096
                                   1307 	.globl _ak820_outline_0101
                                   1308 	.globl _ak820_outline_0107
                                   1309 	.globl _ak820_outline_0108
                                   1310 	.globl _ak820_outline_0118
                                   1311 	.globl _ak820_outline_0122
                                   1312 	.globl _ak820_outline_0123
                                   1313 	.globl _ak820_outline_0124
                                   1314 	.globl _ak820_outline_0133
                                   1315 	.globl _ak820_outline_0136
                                   1316 	.globl _ak820_outline_0141
                                   1317 	.globl _ak820_outline_0144
                                   1318 	.globl _ak820_outline_0160
                                   1319 	.globl _ak820_outline_0161
                                   1320 	.globl _ak820_outline_0163
                                   1321 	.globl _ak820_outline_0183
                                   1322 	.globl _ak820_outline_0191
                                   1323 
                                   1324 	.area CSEG (CODE)
                                   1325 ; function ak820_outline_0005
      003A62                       1326 _ak820_outline_0005:
      003A62 E0               [24] 1327 	movx	a,@dptr
      003A63 FE               [12] 1328 	mov	r6,a
      003A64 A3               [24] 1329 	inc	dptr
      003A65 E0               [24] 1330 	movx	a,@dptr
      003A66 FF               [12] 1331 	mov	r7,a
      003A67 8E 82            [24] 1332 	mov	dpl,r6
      003A69 8F 83            [24] 1333 	mov	dph,r7
      003A6B 22               [24] 1334 	ret
                                   1335 
                                   1336 	.area CSEG (CODE)
                                   1337 ; function ak820_outline_0007
      003A6C                       1338 _ak820_outline_0007:
      003A6C E0               [24] 1339 	movx	a,@dptr
      003A6D FE               [12] 1340 	mov	r6,a
      003A6E A3               [24] 1341 	inc	dptr
      003A6F E0               [24] 1342 	movx	a,@dptr
      003A70 FF               [12] 1343 	mov	r7,a
      003A71 74 07            [12] 1344 	mov	a,#0x07
      003A73 2E               [12] 1345 	add	a,r6
      003A74 F5 82            [12] 1346 	mov	dpl,a
      003A76 E4               [12] 1347 	clr	a
      003A77 3F               [12] 1348 	addc	a,r7
      003A78 F5 83            [12] 1349 	mov	dph,a
      003A7A E0               [24] 1350 	movx	a,@dptr
      003A7B FC               [12] 1351 	mov	r4,a
      003A7C A3               [24] 1352 	inc	dptr
      003A7D E0               [24] 1353 	movx	a,@dptr
      003A7E FD               [12] 1354 	mov	r5,a
      003A7F 22               [24] 1355 	ret
                                   1356 
                                   1357 	.area CSEG (CODE)
                                   1358 ; function ak820_outline_0009
      003A80                       1359 _ak820_outline_0009:
      003A80 74 05            [12] 1360 	mov	a,#0x05
      003A82 2E               [12] 1361 	add	a,r6
      003A83 FE               [12] 1362 	mov	r6,a
      003A84 E4               [12] 1363 	clr	a
      003A85 3F               [12] 1364 	addc	a,r7
      003A86 FF               [12] 1365 	mov	r7,a
      003A87 8E 82            [24] 1366 	mov	dpl,r6
      003A89 8F 83            [24] 1367 	mov	dph,r7
      003A8B E0               [24] 1368 	movx	a,@dptr
      003A8C 22               [24] 1369 	ret
                                   1370 
                                   1371 	.area CSEG (CODE)
                                   1372 ; function ak820_outline_0016
      003A8D                       1373 _ak820_outline_0016:
      003A8D F0               [24] 1374 	movx	@dptr,a
      003A8E EE               [12] 1375 	mov	a,r6
      003A8F A3               [24] 1376 	inc	dptr
      003A90 F0               [24] 1377 	movx	@dptr,a
      003A91 EF               [12] 1378 	mov	a,r7
      003A92 A3               [24] 1379 	inc	dptr
      003A93 F0               [24] 1380 	movx	@dptr,a
      003A94 22               [24] 1381 	ret
                                   1382 
                                   1383 	.area CSEG (CODE)
                                   1384 ; function ak820_outline_0017
      003A95                       1385 _ak820_outline_0017:
      003A95 F9               [12] 1386 	mov	r1,a
      003A96 E4               [12] 1387 	clr	a
      003A97 3F               [12] 1388 	addc	a,r7
      003A98 FA               [12] 1389 	mov	r2,a
      003A99 89 82            [24] 1390 	mov	dpl,r1
      003A9B 8A 83            [24] 1391 	mov	dph,r2
      003A9D E0               [24] 1392 	movx	a,@dptr
      003A9E 22               [24] 1393 	ret
                                   1394 
                                   1395 	.area CSEG (CODE)
                                   1396 ; function ak820_outline_0022
      003A9F                       1397 _ak820_outline_0022:
      003A9F 2E               [12] 1398 	add	a,r6
      003AA0 F5 82            [12] 1399 	mov	dpl,a
      003AA2 E4               [12] 1400 	clr	a
      003AA3 3F               [12] 1401 	addc	a,r7
      003AA4 F5 83            [12] 1402 	mov	dph,a
      003AA6 22               [24] 1403 	ret
                                   1404 
                                   1405 	.area CSEG (CODE)
                                   1406 ; function ak820_outline_0037
      003AA7                       1407 _ak820_outline_0037:
      003AA7 8E 82            [24] 1408 	mov	dpl,r6
      003AA9 8F 83            [24] 1409 	mov	dph,r7
      003AAB A3               [24] 1410 	inc	dptr
      003AAC A3               [24] 1411 	inc	dptr
      003AAD E0               [24] 1412 	movx	a,@dptr
      003AAE 22               [24] 1413 	ret
                                   1414 
                                   1415 	.area CSEG (CODE)
                                   1416 ; function ak820_outline_0052
      003AAF                       1417 _ak820_outline_0052:
      003AAF E0               [24] 1418 	movx	a,@dptr
      003AB0 FE               [12] 1419 	mov	r6,a
      003AB1 A3               [24] 1420 	inc	dptr
      003AB2 E0               [24] 1421 	movx	a,@dptr
      003AB3 FF               [12] 1422 	mov	r7,a
      003AB4 22               [24] 1423 	ret
                                   1424 
                                   1425 	.area CSEG (CODE)
                                   1426 ; function ak820_outline_0054
      003AB5                       1427 _ak820_outline_0054:
      003AB5 75 F0 04         [24] 1428 	mov	b,#0x04
      003AB8 A4               [48] 1429 	mul	ab
      003AB9 24 36            [12] 1430 	add	a,#_combos
      003ABB FC               [12] 1431 	mov	r4,a
      003ABC 74 04            [12] 1432 	mov	a,#(_combos>>8)
      003ABE 35 F0            [12] 1433 	addc	a,b
      003AC0 FD               [12] 1434 	mov	r5,a
      003AC1 8C 82            [24] 1435 	mov	dpl,r4
      003AC3 8D 83            [24] 1436 	mov	dph,r5
      003AC5 22               [24] 1437 	ret
                                   1438 
                                   1439 	.area CSEG (CODE)
                                   1440 ; function ak820_outline_0061
      003AC6                       1441 _ak820_outline_0061:
      003AC6 E0               [24] 1442 	movx	a,@dptr
      003AC7 FC               [12] 1443 	mov	r4,a
      003AC8 A3               [24] 1444 	inc	dptr
      003AC9 E0               [24] 1445 	movx	a,@dptr
      003ACA FD               [12] 1446 	mov	r5,a
      003ACB 22               [24] 1447 	ret
                                   1448 
                                   1449 	.area CSEG (CODE)
                                   1450 ; function ak820_outline_0072
      003ACC                       1451 _ak820_outline_0072:
      003ACC A3               [24] 1452 	inc	dptr
      003ACD F0               [24] 1453 	movx	@dptr,a
      003ACE E4               [12] 1454 	clr	a
      003ACF A3               [24] 1455 	inc	dptr
      003AD0 F0               [24] 1456 	movx	@dptr,a
      003AD1 22               [24] 1457 	ret
                                   1458 
                                   1459 	.area CSEG (CODE)
                                   1460 ; function ak820_outline_0074
      003AD2                       1461 _ak820_outline_0074:
      003AD2 EC               [12] 1462 	mov	a,r4
      003AD3 F0               [24] 1463 	movx	@dptr,a
      003AD4 ED               [12] 1464 	mov	a,r5
      003AD5 A3               [24] 1465 	inc	dptr
      003AD6 F0               [24] 1466 	movx	@dptr,a
      003AD7 22               [24] 1467 	ret
                                   1468 
                                   1469 	.area CSEG (CODE)
                                   1470 ; function ak820_outline_0080
      003AD8                       1471 _ak820_outline_0080:
      003AD8 E0               [24] 1472 	movx	a,@dptr
      003AD9 FD               [12] 1473 	mov	r5,a
      003ADA A3               [24] 1474 	inc	dptr
      003ADB E0               [24] 1475 	movx	a,@dptr
      003ADC FE               [12] 1476 	mov	r6,a
      003ADD 22               [24] 1477 	ret
                                   1478 
                                   1479 	.area CSEG (CODE)
                                   1480 ; function ak820_outline_0093
      003ADE                       1481 _ak820_outline_0093:
      003ADE EB               [12] 1482 	mov	a,r3
      003ADF F0               [24] 1483 	movx	@dptr,a
      003AE0 EC               [12] 1484 	mov	a,r4
      003AE1 A3               [24] 1485 	inc	dptr
      003AE2 F0               [24] 1486 	movx	@dptr,a
      003AE3 22               [24] 1487 	ret
                                   1488 
                                   1489 	.area CSEG (CODE)
                                   1490 ; function ak820_outline_0096
      003AE4                       1491 _ak820_outline_0096:
      003AE4 F0               [24] 1492 	movx	@dptr,a
      003AE5 8C 82            [24] 1493 	mov	dpl,r4
      003AE7 8D 83            [24] 1494 	mov	dph,r5
      003AE9 22               [24] 1495 	ret
                                   1496 
                                   1497 	.area CSEG (CODE)
                                   1498 ; function ak820_outline_0101
      003AEA                       1499 _ak820_outline_0101:
      003AEA E0               [24] 1500 	movx	a,@dptr
      003AEB F8               [12] 1501 	mov	r0,a
      003AEC A3               [24] 1502 	inc	dptr
      003AED E0               [24] 1503 	movx	a,@dptr
      003AEE F9               [12] 1504 	mov	r1,a
      003AEF 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0107
      003AF0                       1509 _ak820_outline_0107:
      003AF0 AF 83            [24] 1510 	mov	r7,dph
      003AF2 E5 82            [12] 1511 	mov	a,dpl
      003AF4 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0108
      003AF5                       1516 _ak820_outline_0108:
      003AF5 F0               [24] 1517 	movx	@dptr,a
      003AF6 EF               [12] 1518 	mov	a,r7
      003AF7 A3               [24] 1519 	inc	dptr
      003AF8 F0               [24] 1520 	movx	@dptr,a
      003AF9 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0118
      003AFA                       1525 _ak820_outline_0118:
      003AFA 8E 82            [24] 1526 	mov	dpl,r6
      003AFC 8F 83            [24] 1527 	mov	dph,r7
      003AFE 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0123
      003AFF                       1532 _ak820_outline_0123:
      003AFF 8C 82            [24] 1533 	mov	dpl,r4
      003B01 8D 83            [24] 1534 	mov	dph,r5
      003B03 22               [24] 1535 	ret
                                   1536 
                                   1537 	.area CSEG (CODE)
                                   1538 ; function ak820_outline_0124
      003B04                       1539 _ak820_outline_0124:
      003B04 F0               [24] 1540 	movx	@dptr,a
      003B05 E4               [12] 1541 	clr	a
      003B06 A3               [24] 1542 	inc	dptr
      003B07 F0               [24] 1543 	movx	@dptr,a
      003B08 22               [24] 1544 	ret
                                   1545 
                                   1546 	.area CSEG (CODE)
                                   1547 ; function ak820_outline_0133
      003B09                       1548 _ak820_outline_0133:
      003B09 8D 82            [24] 1549 	mov	dpl,r5
      003B0B 8E 83            [24] 1550 	mov	dph,r6
      003B0D 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0136
      003B0E                       1555 _ak820_outline_0136:
      003B0E E5 82            [12] 1556 	mov	a,dpl
      003B10 85 83 F0         [24] 1557 	mov	b,dph
      003B13 22               [24] 1558 	ret
                                   1559 
                                   1560 	.area CSEG (CODE)
                                   1561 ; function ak820_outline_0141
      003B14                       1562 _ak820_outline_0141:
      003B14 E0               [24] 1563 	movx	a,@dptr
      003B15 FB               [12] 1564 	mov	r3,a
      003B16 A3               [24] 1565 	inc	dptr
      003B17 E0               [24] 1566 	movx	a,@dptr
      003B18 FC               [12] 1567 	mov	r4,a
      003B19 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0144
      003B1A                       1572 _ak820_outline_0144:
      003B1A 8A 82            [24] 1573 	mov	dpl,r2
      003B1C 8B 83            [24] 1574 	mov	dph,r3
      003B1E 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0160
      003B1F                       1579 _ak820_outline_0160:
      003B1F E4               [12] 1580 	clr	a
      003B20 33               [12] 1581 	rlc	a
      003B21 F5 82            [12] 1582 	mov	dpl,a
      003B23 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0161
      003B24                       1587 _ak820_outline_0161:
      003B24 88 82            [24] 1588 	mov	dpl,r0
      003B26 89 83            [24] 1589 	mov	dph,r1
      003B28 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0163
      003B29                       1594 _ak820_outline_0163:
      003B29 2D               [12] 1595 	add	a,r5
      003B2A FD               [12] 1596 	mov	r5,a
      003B2B E4               [12] 1597 	clr	a
      003B2C 3E               [12] 1598 	addc	a,r6
      003B2D FE               [12] 1599 	mov	r6,a
      003B2E 22               [24] 1600 	ret
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0183
      003B2F                       1604 _ak820_outline_0183:
      003B2F 90 0D E2         [24] 1605 	mov	dptr,#_first
      003B32 E0               [24] 1606 	movx	a,@dptr
      003B33 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0191
      003B34                       1611 _ak820_outline_0191:
      003B34 C4               [12] 1612 	swap	a
      003B35 03               [12] 1613 	rr	a
      003B36 54 F8            [12] 1614 	anl	a,#0xf8
      003B38 22               [24] 1615 	ret
