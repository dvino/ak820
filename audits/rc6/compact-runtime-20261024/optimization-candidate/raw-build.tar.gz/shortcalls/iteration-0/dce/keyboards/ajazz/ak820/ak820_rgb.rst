                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000012                        595 _suspended:
      000012                        596 	.ds 1
      000013                        597 _dirty:
      000013                        598 	.ds 1
      000014                        599 _rendering:
      000014                        600 	.ds 1
      000015                        601 _rgb_matrix_task_sloc0_1_0:
      000015                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006D1                        611 _rgb_matrix_config::
      0006D1                        612 	.ds 8
      0006D9                        613 _changed_at:
      0006D9                        614 	.ds 2
      0006DB                        615 _frame_at:
      0006DB                        616 	.ds 2
      0006DD                        617 _phase:
      0006DD                        618 	.ds 2
      0006DF                        619 _led_index:
      0006DF                        620 	.ds 1
      0006E0                        621 _frame_mode:
      0006E0                        622 	.ds 1
      0006E1                        623 _frame_hue:
      0006E1                        624 	.ds 1
      0006E2                        625 _frame_sat:
      0006E2                        626 	.ds 1
      0006E3                        627 _frame_val:
      0006E3                        628 	.ds 1
      0006E4                        629 _frame_flags:
      0006E4                        630 	.ds 1
      0006E5                        631 _frame_phase:
      0006E5                        632 	.ds 1
      0006E6                        633 _reactive_age:
      0006E6                        634 	.ds 82
      000738                        635 _reactive_at:
      000738                        636 	.ds 2
      00073A                        637 _add_sat_PARM_2:
      00073A                        638 	.ds 1
      00073B                        639 _add_sat_x_10000_266:
      00073B                        640 	.ds 1
      00073C                        641 _sub_sat_PARM_2:
      00073C                        642 	.ds 1
      00073D                        643 _sub_sat_x_10000_268:
      00073D                        644 	.ds 1
      00073E                        645 _rgb_matrix_set_color_PARM_2:
      00073E                        646 	.ds 1
      00073F                        647 _rgb_matrix_set_color_PARM_3:
      00073F                        648 	.ds 1
      000740                        649 _rgb_matrix_set_color_PARM_4:
      000740                        650 	.ds 1
      000741                        651 _rgb_matrix_set_color_index_10000_284:
      000741                        652 	.ds 2
      000743                        653 _rgb_matrix_set_color_all_PARM_2:
      000743                        654 	.ds 1
      000744                        655 _rgb_matrix_set_color_all_PARM_3:
      000744                        656 	.ds 1
      000745                        657 _rgb_matrix_set_color_all_r_10000_287:
      000745                        658 	.ds 1
      000746                        659 _sine8_theta_10000_289:
      000746                        660 	.ds 1
      000747                        661 _sine8_offset_10000_290:
      000747                        662 	.ds 1
      000748                        663 _sine8_fraction_10000_290:
      000748                        664 	.ds 1
      000749                        665 _breathing_cie_value_10000_293:
      000749                        666 	.ds 1
      00074A                        667 _rgb_matrix_task_end_10000_298:
      00074A                        668 	.ds 1
      00074B                        669 _rgb_matrix_task_hsv_10000_298:
      00074B                        670 	.ds 3
      00074E                        671 _rgb_matrix_task_rgb_10000_298:
      00074E                        672 	.ds 3
      000751                        673 _process_rgb_matrix_PARM_2:
      000751                        674 	.ds 1
      000752                        675 _process_rgb_matrix_PARM_3:
      000752                        676 	.ds 1
      000753                        677 _process_rgb_matrix_row_10000_319:
      000753                        678 	.ds 1
      000754                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000754                        680 	.ds 1
      000755                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000755                        682 	.ds 1
      000756                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000756                        684 	.ds 1
      000757                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000757                        686 	.ds 1
      000758                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000758                        688 	.ds 2
      00075A                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00075A                        690 	.ds 1
      00075B                        691 _rgb_matrix_mode_mode_10000_411:
      00075B                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      00542F                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      00542F 12 5B FE         [24]  746 	lcall	_ak820_outline_0179
      005432 74 52            [12]  747 	mov	a,#0x52
      005434 12 3B 04         [24]  748 	lcall	_ak820_outline_0124
      005437 90 06 E6         [24]  749 	mov	dptr,#_reactive_age
      00543A F5 F0            [12]  750 	mov	b,a
      00543C 12 BC D8         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      00543F 12 4B 9D         [24]  753 	lcall	_timer_read
      005442 12 3B 0E         [24]  754 	lcall	_ak820_outline_0136
      005445 90 07 38         [24]  755 	mov	dptr,#_reactive_at
      005448 12 5B EA         [24]  756 	lcall	_ak820_outline_0170
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      00544B 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      00544C                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      00544C 90 07 38         [24]  772 	mov	dptr,#_reactive_at
      00544F 12 3A 62         [24]  773 	lcall	_ak820_outline_0005
      005452 12 4B A0         [24]  774 	lcall	_timer_elapsed
      005455 AE 82            [24]  775 	mov	r6, dpl
      005457 E5 83            [12]  776 	mov	a,dph
      005459 C4               [12]  777 	swap	a
      00545A CE               [12]  778 	xch	a,r6
      00545B C4               [12]  779 	swap	a
      00545C 54 0F            [12]  780 	anl	a,#0x0f
      00545E 6E               [12]  781 	xrl	a,r6
      00545F CE               [12]  782 	xch	a,r6
      005460 54 0F            [12]  783 	anl	a,#0x0f
      005462 CE               [12]  784 	xch	a,r6
      005463 6E               [12]  785 	xrl	a,r6
      005464 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005465 FF               [12]  788 	mov	r7,a
      005466 4E               [12]  789 	orl	a,r6
      005467 70 01            [24]  790 	jnz	00102$
      005469 22               [24]  791 	ret
      00546A                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      00546A 8E 04            [24]  794 	mov	ar4,r6
      00546C EF               [12]  795 	mov	a,r7
      00546D C4               [12]  796 	swap	a
      00546E 54 F0            [12]  797 	anl	a,#0xf0
      005470 CC               [12]  798 	xch	a,r4
      005471 C4               [12]  799 	swap	a
      005472 CC               [12]  800 	xch	a,r4
      005473 6C               [12]  801 	xrl	a,r4
      005474 CC               [12]  802 	xch	a,r4
      005475 54 F0            [12]  803 	anl	a,#0xf0
      005477 CC               [12]  804 	xch	a,r4
      005478 6C               [12]  805 	xrl	a,r4
      005479 FD               [12]  806 	mov	r5,a
      00547A 90 07 38         [24]  807 	mov	dptr,#_reactive_at
      00547D 12 45 AC         [24]  808 	lcall	_ak820_outline_0086
      005480 90 07 38         [24]  809 	mov	dptr,#_reactive_at
      005483 EC               [12]  810 	mov	a,r4
      005484 2A               [12]  811 	add	a, r2
      005485 F0               [24]  812 	movx	@dptr,a
      005486 ED               [12]  813 	mov	a,r5
      005487 3B               [12]  814 	addc	a, r3
      005488 A3               [24]  815 	inc	dptr
      005489 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      00548A 8E 04            [24]  818 	mov	ar4,r6
      00548C 8F 05            [24]  819 	mov	ar5,r7
      00548E C3               [12]  820 	clr	c
      00548F 74 FF            [12]  821 	mov	a,#0xff
      005491 9C               [12]  822 	subb	a,r4
      005492 E4               [12]  823 	clr	a
      005493 9D               [12]  824 	subb	a,r5
      005494 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005496 7D FF            [12]  827 	mov	r5,#0xff
      005498 80 02            [24]  828 	sjmp	00109$
      00549A                        829 00108$:
      00549A 8E 05            [24]  830 	mov	ar5,r6
      00549C                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00549C 7F 00            [12]  833 	mov	r7,#0x00
      00549E                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      00549E EF               [12]  836 	mov	a,r7
      00549F 24 E6            [12]  837 	add	a, #_reactive_age
      0054A1 FC               [12]  838 	mov	r4,a
      0054A2 E4               [12]  839 	clr	a
      0054A3 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      0054A5 FE               [12]  841 	mov	r6,a
      0054A6 8C 82            [24]  842 	mov	dpl,r4
      0054A8 8E 83            [24]  843 	mov	dph,r6
      0054AA E0               [24]  844 	movx	a,@dptr
      0054AB FB               [12]  845 	mov	r3,a
      0054AC C3               [12]  846 	clr	c
      0054AD ED               [12]  847 	mov	a,r5
      0054AE 9B               [12]  848 	subb	a,r3
      0054AF 40 04            [24]  849 	jc	00110$
      0054B1 7B 00            [12]  850 	mov	r3,#0x00
      0054B3 80 08            [24]  851 	sjmp	00111$
      0054B5                        852 00110$:
      0054B5 8C 82            [24]  853 	mov	dpl,r4
      0054B7 8E 83            [24]  854 	mov	dph,r6
      0054B9 E0               [24]  855 	movx	a,@dptr
      0054BA C3               [12]  856 	clr	c
      0054BB 9D               [12]  857 	subb	a,r5
      0054BC FB               [12]  858 	mov	r3,a
      0054BD                        859 00111$:
      0054BD 8C 82            [24]  860 	mov	dpl,r4
      0054BF 8E 83            [24]  861 	mov	dph,r6
      0054C1 EB               [12]  862 	mov	a,r3
      0054C2 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054C3 0F               [12]  865 	inc	r7
      0054C4 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      0054C7                        867 00144$:
      0054C7 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      0054C9 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      0054CA                        881 _add_sat:
      0054CA E5 82            [12]  882 	mov	a,dpl
      0054CC 90 07 3B         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      0054CF F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      0054D0 90 07 3A         [24]  886 	mov	dptr,#_add_sat_PARM_2
      0054D3 E0               [24]  887 	movx	a,@dptr
      0054D4 FF               [12]  888 	mov	r7,a
      0054D5 FE               [12]  889 	mov	r6,a
      0054D6 74 FF            [12]  890 	mov	a,#0xff
      0054D8 C3               [12]  891 	clr	c
      0054D9 9E               [12]  892 	subb	a,r6
      0054DA FE               [12]  893 	mov	r6,a
      0054DB 90 07 3B         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      0054DE E0               [24]  895 	movx	a,@dptr
      0054DF FD               [12]  896 	mov	r5,a
      0054E0 C3               [12]  897 	clr	c
      0054E1 EE               [12]  898 	mov	a,r6
      0054E2 9D               [12]  899 	subb	a,r5
      0054E3 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      0054E5 7E FF            [12]  902 	mov	r6,#0xff
      0054E7 80 03            [24]  903 	sjmp	00104$
      0054E9                        904 00103$:
      0054E9 EF               [12]  905 	mov	a,r7
      0054EA 2D               [12]  906 	add	a, r5
      0054EB FE               [12]  907 	mov	r6,a
      0054EC                        908 00104$:
      0054EC 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      0054EE 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      0054EF                        922 _sub_sat:
      0054EF E5 82            [12]  923 	mov	a,dpl
      0054F1 90 07 3D         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      0054F4 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      0054F5 E0               [24]  927 	movx	a,@dptr
      0054F6 FF               [12]  928 	mov	r7,a
      0054F7 90 07 3C         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      0054FA E0               [24]  930 	movx	a,@dptr
      0054FB FE               [12]  931 	mov	r6,a
      0054FC C3               [12]  932 	clr	c
      0054FD EF               [12]  933 	mov	a,r7
      0054FE 9E               [12]  934 	subb	a,r6
      0054FF 50 04            [24]  935 	jnc	00103$
      005501 7D 00            [12]  936 	mov	r5,#0x00
      005503 80 04            [24]  937 	sjmp	00104$
      005505                        938 00103$:
      005505 EF               [12]  939 	mov	a,r7
      005506 C3               [12]  940 	clr	c
      005507 9E               [12]  941 	subb	a,r6
      005508 FD               [12]  942 	mov	r5,a
      005509                        943 00104$:
      005509 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      00550B 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      00550C                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      00550C D2 13            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      00550E 12 4B 9D         [24]  959 	lcall	_timer_read
      005511 12 3B 0E         [24]  960 	lcall	_ak820_outline_0136
      005514 90 06 D9         [24]  961 	mov	dptr,#_changed_at
      005517 12 5B EA         [24]  962 	lcall	_ak820_outline_0170
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      00551A 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      00551B                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      00551B 90 06 D8         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      00551E E4               [12]  978 	clr	a
      00551F F0               [24]  979 	movx	@dptr,a
      005520 90 06 D7         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      005523 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005524 90 05 A5         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005527 12 5B CD         [24]  984 	lcall	_ak820_outline_0087
      00552A 90 05 A8         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00552D 12 5B C3         [24]  986 	lcall	_ak820_outline_0070
      005530 12 44 86         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005533 C2 13            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005535 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005536                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005536 12 5B FE         [24] 1002 	lcall	_ak820_outline_0179
      005539 12 5B C3         [24] 1003 	lcall	_ak820_outline_0070
      00553C F5 F0            [12] 1004 	mov	b,a
      00553E 12 BC D8         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005541 12 5B DD         [24] 1007 	lcall	_ak820_outline_0114
      005544 44 01            [12] 1008 	orl	a,#0x01
      005546 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005547 12 5B BC         [24] 1011 	lcall	_ak820_outline_0066
      00554A 44 04            [12] 1012 	orl	a,#0x04
      00554C F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00554D 90 06 D2         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005550 E4               [12] 1016 	clr	a
      005551 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005552 90 06 D3         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005555 14               [12] 1020 	dec	a
      005556 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005557 90 06 D4         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00555A 74 50            [12] 1024 	mov	a,#0x50
      00555C F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00555D 90 06 D5         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005560 74 60            [12] 1028 	mov	a,#0x60
      005562 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005563 90 06 D6         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005566 74 FF            [12] 1032 	mov	a,#0xff
      005568 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005569 A1 1B            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00556B                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00556B 90 05 95         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00556E 12 5B CD         [24] 1047 	lcall	_ak820_outline_0087
      005571 90 05 98         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005574 12 5B C3         [24] 1049 	lcall	_ak820_outline_0070
      005577 12 43 1D         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00557A 12 5B DD         [24] 1052 	lcall	_ak820_outline_0114
      00557D 60 11            [24] 1053 	jz	00101$
      00557F 12 5B 9D         [24] 1054 	lcall	_ak820_outline_0019
      005582 C3               [12] 1055 	clr	c
      005583 64 80            [12] 1056 	xrl	a,#0x80
      005585 94 87            [12] 1057 	subb	a,#0x87
      005587 50 07            [24] 1058 	jnc	00101$
      005589 12 5B BC         [24] 1059 	lcall	_ak820_outline_0066
      00558C 24 FE            [12] 1060 	add	a,#0xff - 0x01
      00558E 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005590                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005590 B1 36            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      005592                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005592 90 06 D4         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005595 E0               [24] 1069 	movx	a,@dptr
      005596 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      005598 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00559A 90 06 D4         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00559D 74 A0            [12] 1075 	mov	a,#0xa0
      00559F F0               [24] 1076 	movx	@dptr,a
      0055A0                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      0055A0 C2 13            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      0055A2 C2 14            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      0055A4 81 2F            [12] 1086 	ajmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0055A6                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0055A6 B1 6B            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0055A8 12 4B 9D         [24] 1098 	lcall	_timer_read
      0055AB 12 45 C4         [24] 1099 	lcall	_ak820_outline_0125
      0055AE EE               [12] 1100 	mov	a,r6
      0055AF 24 F0            [12] 1101 	add	a,#0xf0
      0055B1 FE               [12] 1102 	mov	r6,a
      0055B2 EF               [12] 1103 	mov	a,r7
      0055B3 34 FF            [12] 1104 	addc	a,#0xff
      0055B5 FF               [12] 1105 	mov	r7,a
      0055B6 90 06 DB         [24] 1106 	mov	dptr,#_frame_at
      0055B9 12 4A EA         [24] 1107 	lcall	_ak820_outline_0060
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0055BC 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0055BD                       1122 _rgb_matrix_set_color:
      0055BD 12 3A F0         [24] 1123 	lcall	_ak820_outline_0107
      0055C0 90 07 41         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0055C3 12 3A F5         [24] 1125 	lcall	_ak820_outline_0108
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0055C6 90 07 41         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0055C9 12 3A AF         [24] 1128 	lcall	_ak820_outline_0052
      0055CC 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0055CF C3               [12] 1130 	clr	c
      0055D0 EE               [12] 1131 	mov	a,r6
      0055D1 94 52            [12] 1132 	subb	a,#0x52
      0055D3 EF               [12] 1133 	mov	a,r7
      0055D4 64 80            [12] 1134 	xrl	a,#0x80
      0055D6 94 80            [12] 1135 	subb	a,#0x80
      0055D8 50 23            [24] 1136 	jnc	00104$
      0055DA 90 07 3E         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0055DD E0               [24] 1138 	movx	a,@dptr
      0055DE FF               [12] 1139 	mov	r7,a
      0055DF 90 07 3F         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0055E2 E0               [24] 1141 	movx	a,@dptr
      0055E3 FD               [12] 1142 	mov	r5,a
      0055E4 90 07 40         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0055E7 E0               [24] 1144 	movx	a,@dptr
      0055E8 FC               [12] 1145 	mov	r4,a
      0055E9 90 04 2A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0055EC EF               [12] 1147 	mov	a,r7
      0055ED F0               [24] 1148 	movx	@dptr,a
      0055EE 90 04 2B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0055F1 ED               [12] 1150 	mov	a,r5
      0055F2 F0               [24] 1151 	movx	@dptr,a
      0055F3 90 04 2C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0055F6 EC               [12] 1153 	mov	a,r4
      0055F7 F0               [24] 1154 	movx	@dptr,a
      0055F8 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0055FA 02 35 FB         [24] 1157 	ljmp	_ak820_rgb_set_color
      0055FD                       1158 00104$:
      0055FD 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0055FE                       1171 _rgb_matrix_set_color_all:
      0055FE E5 82            [12] 1172 	mov	a,dpl
      005600 90 07 45         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      005603 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      005604 E0               [24] 1176 	movx	a,@dptr
      005605 FF               [12] 1177 	mov	r7,a
      005606 90 07 43         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005609 E0               [24] 1179 	movx	a,@dptr
      00560A FE               [12] 1180 	mov	r6,a
      00560B 90 07 44         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00560E E0               [24] 1182 	movx	a,@dptr
      00560F FD               [12] 1183 	mov	r5,a
      005610 90 04 2E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      005613 EE               [12] 1185 	mov	a,r6
      005614 F0               [24] 1186 	movx	@dptr,a
      005615 90 04 2F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005618 ED               [12] 1188 	mov	a,r5
      005619 F0               [24] 1189 	movx	@dptr,a
      00561A 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      00561C 02 36 32         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      00561F                       1206 _sine8:
      00561F E5 82            [12] 1207 	mov	a,dpl
      005621 90 07 46         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      005624 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005625 E0               [24] 1211 	movx	a,@dptr
      005626 FF               [12] 1212 	mov	r7,a
      005627 90 07 47         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      00562A F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      00562B EF               [12] 1216 	mov	a,r7
      00562C 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      00562F 90 07 47         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      005632 74 FF            [12] 1219 	mov	a,#0xff
      005634 C3               [12] 1220 	clr	c
      005635 9F               [12] 1221 	subb	a,r7
      005636 F0               [24] 1222 	movx	@dptr,a
      005637                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005637 90 07 47         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      00563A E0               [24] 1226 	movx	a,@dptr
      00563B 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      00563E F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00563F 90 07 47         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      005642 E0               [24] 1231 	movx	a,@dptr
      005643 54 0F            [12] 1232 	anl	a,#0x0f
      005645 FF               [12] 1233 	mov	r7,a
      005646 90 07 48         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005649 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      00564A 90 07 46         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      00564D E0               [24] 1238 	movx	a,@dptr
      00564E 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      005651 90 07 48         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      005654 EF               [12] 1241 	mov	a,r7
      005655 04               [12] 1242 	inc	a
      005656 F0               [24] 1243 	movx	@dptr,a
      005657                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005657 90 07 47         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      00565A E0               [24] 1247 	movx	a,@dptr
      00565B C4               [12] 1248 	swap	a
      00565C 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      00565E 25 E0            [12] 1251 	add	a,acc
      005660 FF               [12] 1252 	mov	r7,a
      005661 90 BD BD         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      005664 93               [24] 1254 	movc	a,@a+dptr
      005665 FE               [12] 1255 	mov	r6,a
      005666 0F               [12] 1256 	inc	r7
      005667 EF               [12] 1257 	mov	a,r7
      005668 90 BD BD         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      00566B 93               [24] 1259 	movc	a,@a+dptr
      00566C FF               [12] 1260 	mov	r7,a
      00566D 90 07 48         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005670 E0               [24] 1262 	movx	a,@dptr
      005671 8F F0            [24] 1263 	mov	b,r7
      005673 A4               [48] 1264 	mul	ab
      005674 FF               [12] 1265 	mov	r7,a
      005675 E5 F0            [12] 1266 	mov	a,b
      005677 C4               [12] 1267 	swap	a
      005678 CF               [12] 1268 	xch	a,r7
      005679 C4               [12] 1269 	swap	a
      00567A 54 0F            [12] 1270 	anl	a,#0x0f
      00567C 6F               [12] 1271 	xrl	a,r7
      00567D CF               [12] 1272 	xch	a,r7
      00567E 54 0F            [12] 1273 	anl	a,#0x0f
      005680 CF               [12] 1274 	xch	a,r7
      005681 6F               [12] 1275 	xrl	a,r7
      005682 CF               [12] 1276 	xch	a,r7
      005683 EF               [12] 1277 	mov	a,r7
      005684 2E               [12] 1278 	add	a, r6
      005685 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      005686 90 07 46         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      005689 E0               [24] 1282 	movx	a,@dptr
      00568A 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      00568D 8F 06            [24] 1284 	mov	ar6,r7
      00568F 74 80            [12] 1285 	mov	a,#0x80
      005691 C3               [12] 1286 	clr	c
      005692 9E               [12] 1287 	subb	a,r6
      005693 FE               [12] 1288 	mov	r6,a
      005694 80 04            [24] 1289 	sjmp	00108$
      005696                       1290 00107$:
      005696 74 80            [12] 1291 	mov	a,#0x80
      005698 2F               [12] 1292 	add	a, r7
      005699 FE               [12] 1293 	mov	r6,a
      00569A                       1294 00108$:
      00569A 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      00569C 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      00569D                       1312 _breathing_cie:
      00569D E5 82            [12] 1313 	mov	a,dpl
      00569F 90 07 49         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      0056A2 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      0056A3 E0               [24] 1317 	movx	a,@dptr
      0056A4 FF               [12] 1318 	mov	r7,a
      0056A5 12 5C 0C         [24] 1319 	lcall	_ak820_outline_0186
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0056A8 FE               [12] 1321 	mov	r6,a
      0056A9 90 C0 C9         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0056AC 93               [24] 1323 	movc	a,@a+dptr
      0056AD FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0056AE BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0056B1 8D 82            [24] 1327 	mov	dpl, r5
      0056B3 22               [24] 1328 	ret
      0056B4                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0056B4 EE               [12] 1331 	mov	a,r6
      0056B5 04               [12] 1332 	inc	a
      0056B6 90 C0 C9         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0056B9 93               [24] 1334 	movc	a,@a+dptr
      0056BA C3               [12] 1335 	clr	c
      0056BB 9D               [12] 1336 	subb	a,r5
      0056BC FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0056BD 74 07            [12] 1339 	mov	a,#0x07
      0056BF 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0056C0 F5 F0            [12] 1342 	mov	b,a
      0056C2 EE               [12] 1343 	mov	a,r6
      0056C3 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0056C4 12 5C 0C         [24] 1346 	lcall	_ak820_outline_0186
      0056C7 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0056C8 F5 82            [12] 1349 	mov	dpl,a
      0056CA 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      0056CB                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0056CB 91 4C            [12] 1367 	acall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0056CD 30 13 17         [24] 1369 	jnb	_dirty,00102$
      0056D0 90 06 D9         [24] 1370 	mov	dptr,#_changed_at
      0056D3 12 3A 62         [24] 1371 	lcall	_ak820_outline_0005
      0056D6 12 4B A0         [24] 1372 	lcall	_timer_elapsed
      0056D9 12 45 C4         [24] 1373 	lcall	_ak820_outline_0125
      0056DC C3               [12] 1374 	clr	c
      0056DD EE               [12] 1375 	mov	a,r6
      0056DE 94 E8            [12] 1376 	subb	a,#0xe8
      0056E0 EF               [12] 1377 	mov	a,r7
      0056E1 94 03            [12] 1378 	subb	a,#0x03
      0056E3 40 02            [24] 1379 	jc	00102$
      0056E5 B1 1B            [12] 1380 	acall	_eeconfig_update_rgb_matrix
      0056E7                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0056E7 30 14 02         [24] 1383 	jnb	_rendering,00254$
      0056EA E1 9F            [12] 1384 	ajmp	00109$
      0056EC                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0056EC 90 06 DB         [24] 1387 	mov	dptr,#_frame_at
      0056EF 12 3A 62         [24] 1388 	lcall	_ak820_outline_0005
      0056F2 12 4B A0         [24] 1389 	lcall	_timer_elapsed
      0056F5 12 45 C4         [24] 1390 	lcall	_ak820_outline_0125
      0056F8 C3               [12] 1391 	clr	c
      0056F9 EE               [12] 1392 	mov	a,r6
      0056FA 94 10            [12] 1393 	subb	a,#0x10
      0056FC EF               [12] 1394 	mov	a,r7
      0056FD 94 00            [12] 1395 	subb	a,#0x00
      0056FF 50 01            [24] 1396 	jnc	00105$
      005701 22               [24] 1397 	ret
      005702                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      005702 12 4B 9D         [24] 1400 	lcall	_timer_read
      005705 12 3B 0E         [24] 1401 	lcall	_ak820_outline_0136
      005708 90 06 DB         [24] 1402 	mov	dptr,#_frame_at
      00570B 12 5B EA         [24] 1403 	lcall	_ak820_outline_0170
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      00570E 90 06 D5         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005711 E0               [24] 1406 	movx	a,@dptr
      005712 FF               [12] 1407 	mov	r7,a
      005713 7E 00            [12] 1408 	mov	r6,#0x00
      005715 74 20            [12] 1409 	mov	a,#0x20
      005717 2F               [12] 1410 	add	a, r7
      005718 FF               [12] 1411 	mov	r7,a
      005719 E4               [12] 1412 	clr	a
      00571A 3E               [12] 1413 	addc	a, r6
      00571B FE               [12] 1414 	mov	r6,a
      00571C 90 06 DD         [24] 1415 	mov	dptr,#_phase
      00571F 12 3A C6         [24] 1416 	lcall	_ak820_outline_0061
      005722 EF               [12] 1417 	mov	a,r7
      005723 2C               [12] 1418 	add	a, r4
      005724 FF               [12] 1419 	mov	r7,a
      005725 EE               [12] 1420 	mov	a,r6
      005726 3D               [12] 1421 	addc	a, r5
      005727 FE               [12] 1422 	mov	r6,a
      005728 90 06 DD         [24] 1423 	mov	dptr,#_phase
      00572B EF               [12] 1424 	mov	a,r7
      00572C F0               [24] 1425 	movx	@dptr,a
      00572D EE               [12] 1426 	mov	a,r6
      00572E A3               [24] 1427 	inc	dptr
      00572F F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005730 90 06 DD         [24] 1430 	mov	dptr,#_phase
      005733 E0               [24] 1431 	movx	a,@dptr
      005734 A3               [24] 1432 	inc	dptr
      005735 E0               [24] 1433 	movx	a,@dptr
      005736 FF               [12] 1434 	mov	r7,a
      005737 90 06 E5         [24] 1435 	mov	dptr,#_frame_phase
      00573A F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      00573B 20 12 05         [24] 1438 	jb	_suspended,00135$
      00573E 12 5B BC         [24] 1439 	lcall	_ak820_outline_0066
      005741 70 04            [24] 1440 	jnz	00132$
      005743                       1441 00135$:
      005743 7E 00            [12] 1442 	mov	r6,#0x00
      005745 80 04            [24] 1443 	sjmp	00133$
      005747                       1444 00132$:
      005747 12 5B 9D         [24] 1445 	lcall	_ak820_outline_0019
      00574A FE               [12] 1446 	mov	r6,a
      00574B                       1447 00133$:
      00574B 90 06 E0         [24] 1448 	mov	dptr,#_frame_mode
      00574E EE               [12] 1449 	mov	a,r6
      00574F F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005750 90 06 D2         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005753 E0               [24] 1453 	movx	a,@dptr
      005754 90 06 E1         [24] 1454 	mov	dptr,#_frame_hue
      005757 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005758 90 06 D3         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00575B E0               [24] 1458 	movx	a,@dptr
      00575C 90 06 E2         [24] 1459 	mov	dptr,#_frame_sat
      00575F F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005760 90 06 D4         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005763 E0               [24] 1463 	movx	a,@dptr
      005764 FD               [12] 1464 	mov	r5,a
      005765 90 06 E3         [24] 1465 	mov	dptr,#_frame_val
      005768 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005769 90 06 D6         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      00576C E0               [24] 1469 	movx	a,@dptr
      00576D 90 06 E4         [24] 1470 	mov	dptr,#_frame_flags
      005770 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005771 BE 02 24         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005774 EF               [12] 1475 	mov	a,r7
      005775 24 C0            [12] 1476 	add	a,#0xc0
      005777 F5 82            [12] 1477 	mov	dpl,a
      005779 C0 05            [24] 1478 	push	ar5
      00577B D1 1F            [24] 1479 	acall	_sine8
      00577D AF 82            [24] 1480 	mov	r7, dpl
      00577F D0 05            [24] 1481 	pop	ar5
      005781 8D F0            [24] 1482 	mov	b,r5
      005783 EF               [12] 1483 	mov	a,r7
      005784 A4               [48] 1484 	mul	ab
      005785 AE F0            [24] 1485 	mov	r6,b
      005787 8E 05            [24] 1486 	mov	ar5,r6
      005789 90 06 E3         [24] 1487 	mov	dptr,#_frame_val
      00578C ED               [12] 1488 	mov	a,r5
      00578D F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      00578E 8D 82            [24] 1491 	mov	dpl, r5
      005790 D1 9D            [24] 1492 	acall	_breathing_cie
      005792 E5 82            [12] 1493 	mov	a, dpl
      005794 90 06 E3         [24] 1494 	mov	dptr,#_frame_val
      005797 F0               [24] 1495 	movx	@dptr,a
      005798                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005798 90 06 DF         [24] 1498 	mov	dptr,#_led_index
      00579B E4               [12] 1499 	clr	a
      00579C F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      00579D D2 14            [12] 1503 	setb	_rendering
      00579F                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00579F 12 5C 07         [24] 1506 	lcall	_ak820_outline_0184
      0057A2 24 08            [12] 1507 	add	a,#0x08
      0057A4 FF               [12] 1508 	mov	r7,a
      0057A5 90 07 4A         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057A8 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0057A9 EF               [12] 1512 	mov	a,r7
      0057AA 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0057AC 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0057AE 90 07 4A         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057B1 74 52            [12] 1517 	mov	a,#0x52
      0057B3 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0057B4                       1520 00125$:
      0057B4 12 5C 07         [24] 1521 	lcall	_ak820_outline_0184
      0057B7 FF               [12] 1522 	mov	r7,a
      0057B8 90 07 4A         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0057BB E0               [24] 1524 	movx	a,@dptr
      0057BC FE               [12] 1525 	mov	r6,a
      0057BD C3               [12] 1526 	clr	c
      0057BE EF               [12] 1527 	mov	a,r7
      0057BF 9E               [12] 1528 	subb	a,r6
      0057C0 40 03            [24] 1529 	jc	00261$
      0057C2 02 59 33         [24] 1530 	ljmp	00127$
      0057C5                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0057C5 12 5B E4         [24] 1533 	lcall	_ak820_outline_0138
      0057C8 E0               [24] 1534 	movx	a,@dptr
      0057C9 60 07            [24] 1535 	jz	00121$
      0057CB 90 06 E4         [24] 1536 	mov	dptr,#_frame_flags
      0057CE E0               [24] 1537 	movx	a,@dptr
      0057CF 20 E2 1A         [24] 1538 	jb	acc.2,00122$
      0057D2                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0057D2 12 5C 07         [24] 1541 	lcall	_ak820_outline_0184
      0057D5 FC               [12] 1542 	mov	r4,a
      0057D6 7D 00            [12] 1543 	mov	r5,#0x00
      0057D8 90 07 3E         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0057DB E4               [12] 1545 	clr	a
      0057DC F0               [24] 1546 	movx	@dptr,a
      0057DD 90 07 3F         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0057E0 F0               [24] 1548 	movx	@dptr,a
      0057E1 90 07 40         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0057E4 12 3A E4         [24] 1550 	lcall	_ak820_outline_0096
      0057E7 12 55 BD         [24] 1551 	lcall	_rgb_matrix_set_color
?ASlink-Warning-2K Page relocation error
      0057EA 21 2A            [12] 1552 	ajmp	00123$
      0057EC                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0057EC BE 05 28         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0057EF EF               [12] 1557 	mov	a,r7
      0057F0 75 F0 03         [24] 1558 	mov	b,#0x03
      0057F3 A4               [48] 1559 	mul	ab
      0057F4 24 BF            [12] 1560 	add	a, #_g_direct_mode_colors
      0057F6 FD               [12] 1561 	mov	r5,a
      0057F7 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      0057F9 35 F0            [12] 1563 	addc	a, b
      0057FB FE               [12] 1564 	mov	r6,a
      0057FC 90 0D D3         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      0057FF ED               [12] 1566 	mov	a,r5
      005800 F0               [24] 1567 	movx	@dptr,a
      005801 EE               [12] 1568 	mov	a,r6
      005802 12 3A CC         [24] 1569 	lcall	_ak820_outline_0072
      005805 90 0D D6         [24] 1570 	mov	dptr,#___memcpy_PARM_3
      005808 74 03            [12] 1571 	mov	a,#0x03
      00580A 12 3B 04         [24] 1572 	lcall	_ak820_outline_0124
      00580D 90 07 4B         [24] 1573 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005810 F5 F0            [12] 1574 	mov	b,a
      005812 12 BC 62         [24] 1575 	lcall	___memcpy
      005815 01 C6            [12] 1576 	ajmp	00120$
      005817                       1577 00119$:
                                   1578 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005817 90 06 E1         [24] 1579 	mov	dptr,#_frame_hue
      00581A E0               [24] 1580 	movx	a,@dptr
      00581B 90 07 4B         [24] 1581 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00581E F0               [24] 1582 	movx	@dptr,a
                                   1583 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      00581F 90 06 E2         [24] 1584 	mov	dptr,#_frame_sat
      005822 E0               [24] 1585 	movx	a,@dptr
      005823 90 07 4C         [24] 1586 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005826 F0               [24] 1587 	movx	@dptr,a
                                   1588 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005827 90 06 E3         [24] 1589 	mov	dptr,#_frame_val
      00582A E0               [24] 1590 	movx	a,@dptr
      00582B 90 07 4D         [24] 1591 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00582E F0               [24] 1592 	movx	@dptr,a
                                   1593 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      00582F 12 5B E4         [24] 1594 	lcall	_ak820_outline_0138
      005832 BE 03 0E         [24] 1595 	cjne	r6,#0x03,00113$
      005835 90 07 4B         [24] 1596 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005838 E0               [24] 1597 	movx	a,@dptr
      005839 FE               [12] 1598 	mov	r6,a
      00583A 90 06 E5         [24] 1599 	mov	dptr,#_frame_phase
      00583D E0               [24] 1600 	movx	a,@dptr
      00583E 2E               [12] 1601 	add	a, r6
      00583F 90 07 4B         [24] 1602 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005842 F0               [24] 1603 	movx	@dptr,a
      005843                       1604 00113$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005843 12 5B E4         [24] 1606 	lcall	_ak820_outline_0138
      005846 BE 04 23         [24] 1607 	cjne	r6,#0x04,00115$
      005849 90 07 4B         [24] 1608 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00584C E0               [24] 1609 	movx	a,@dptr
      00584D FE               [12] 1610 	mov	r6,a
      00584E 12 5C 07         [24] 1611 	lcall	_ak820_outline_0184
      005851 75 F0 02         [24] 1612 	mov	b,#0x02
      005854 A4               [48] 1613 	mul	ab
      005855 24 25            [12] 1614 	add	a, #_ak820_led_points
      005857 F5 82            [12] 1615 	mov	dpl,a
      005859 74 C0            [12] 1616 	mov	a,#(_ak820_led_points >> 8)
      00585B 12 5B D6         [24] 1617 	lcall	_ak820_outline_0109
      00585E FD               [12] 1618 	mov	r5,a
      00585F 90 06 E5         [24] 1619 	mov	dptr,#_frame_phase
      005862 E0               [24] 1620 	movx	a,@dptr
      005863 FC               [12] 1621 	mov	r4,a
      005864 ED               [12] 1622 	mov	a,r5
      005865 C3               [12] 1623 	clr	c
      005866 9C               [12] 1624 	subb	a,r4
      005867 2E               [12] 1625 	add	a, r6
      005868 90 07 4B         [24] 1626 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00586B F0               [24] 1627 	movx	@dptr,a
      00586C                       1628 00115$:
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00586C 12 5B E4         [24] 1630 	lcall	_ak820_outline_0138
      00586F BE 06 54         [24] 1631 	cjne	r6,#0x06,00120$
                                   1632 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005872 12 5B F5         [24] 1633 	lcall	_ak820_outline_0174
      005875 FE               [12] 1634 	mov	r6,a
      005876 74 07            [12] 1635 	mov	a,#0x07
      005878 C3               [12] 1636 	clr	c
      005879 9E               [12] 1637 	subb	a,r6
      00587A FE               [12] 1638 	mov	r6,a
                                   1639 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00587B 8E F0            [24] 1640 	mov	b,r6
      00587D 05 F0            [12] 1641 	inc	b
      00587F 74 01            [12] 1642 	mov	a,#0x01
      005881 80 02            [24] 1643 	sjmp	00273$
      005883                       1644 00272$:
      005883 25 E0            [12] 1645 	add	a,acc
      005885                       1646 00273$:
      005885 D5 F0 FB         [24] 1647 	djnz	b,00272$
      005888 FD               [12] 1648 	mov	r5,a
                                   1649 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      005889 12 5C 07         [24] 1650 	lcall	_ak820_outline_0184
      00588C 24 E6            [12] 1651 	add	a, #_reactive_age
      00588E F5 82            [12] 1652 	mov	dpl,a
      005890 E4               [12] 1653 	clr	a
      005891 34 06            [12] 1654 	addc	a, #(_reactive_age >> 8)
      005893 F5 83            [12] 1655 	mov	dph,a
      005895 E0               [24] 1656 	movx	a,@dptr
                                   1657 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005896 FC               [12] 1658 	mov	r4,a
      005897 C3               [12] 1659 	clr	c
      005898 9D               [12] 1660 	subb	a,r5
      005899 40 07            [24] 1661 	jc	00137$
      00589B 90 06 E3         [24] 1662 	mov	dptr,#_frame_val
      00589E E0               [24] 1663 	movx	a,@dptr
      00589F FB               [12] 1664 	mov	r3,a
      0058A0 80 1F            [24] 1665 	sjmp	00138$
      0058A2                       1666 00137$:
      0058A2 90 06 E3         [24] 1667 	mov	dptr,#_frame_val
      0058A5 E0               [24] 1668 	movx	a,@dptr
      0058A6 F5 F0            [12] 1669 	mov	b, a
      0058A8 EC               [12] 1670 	mov	a,r4
      0058A9 A4               [48] 1671 	mul	ab
      0058AA FC               [12] 1672 	mov	r4,a
      0058AB AA F0            [24] 1673 	mov	r2,b
      0058AD 8E F0            [24] 1674 	mov	b,r6
      0058AF 05 F0            [12] 1675 	inc	b
      0058B1 AB 04            [24] 1676 	mov	r3,ar4
      0058B3 AD 02            [24] 1677 	mov	r5,ar2
      0058B5 80 07            [24] 1678 	sjmp	00276$
      0058B7                       1679 00275$:
      0058B7 C3               [12] 1680 	clr	c
      0058B8 ED               [12] 1681 	mov	a,r5
      0058B9 13               [12] 1682 	rrc	a
      0058BA FD               [12] 1683 	mov	r5,a
      0058BB EB               [12] 1684 	mov	a,r3
      0058BC 13               [12] 1685 	rrc	a
      0058BD FB               [12] 1686 	mov	r3,a
      0058BE                       1687 00276$:
      0058BE D5 F0 F6         [24] 1688 	djnz	b,00275$
      0058C1                       1689 00138$:
      0058C1 90 07 4D         [24] 1690 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0058C4 EB               [12] 1691 	mov	a,r3
      0058C5 F0               [24] 1692 	movx	@dptr,a
      0058C6                       1693 00120$:
                                   1694 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0058C6 12 5B E4         [24] 1695 	lcall	_ak820_outline_0138
      0058C9 BE 02 03         [24] 1696 	cjne	r6,#0x02,00277$
      0058CC D3               [12] 1697 	setb	c
      0058CD 80 01            [24] 1698 	sjmp	00278$
      0058CF                       1699 00277$:
      0058CF C3               [12] 1700 	clr	c
      0058D0                       1701 00278$:
      0058D0 B3               [12] 1702 	cpl	c
      0058D1 92 15            [24] 1703 	mov	_rgb_matrix_task_sloc0_1_0,c
      0058D3 90 0D D3         [24] 1704 	mov	dptr,#___memcpy_PARM_2
      0058D6 74 4B            [12] 1705 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0058D8 F0               [24] 1706 	movx	@dptr,a
      0058D9 74 07            [12] 1707 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0058DB 12 3A CC         [24] 1708 	lcall	_ak820_outline_0072
      0058DE 90 0D D6         [24] 1709 	mov	dptr,#___memcpy_PARM_3
      0058E1 74 03            [12] 1710 	mov	a,#0x03
      0058E3 12 3B 04         [24] 1711 	lcall	_ak820_outline_0124
      0058E6 90 0A F5         [24] 1712 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0058E9 F5 F0            [12] 1713 	mov	b,a
      0058EB 12 BC 62         [24] 1714 	lcall	___memcpy
      0058EE 90 0A F8         [24] 1715 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0058F1 74 4E            [12] 1716 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0058F3 F0               [24] 1717 	movx	@dptr,a
      0058F4 74 07            [12] 1718 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0058F6 A3               [24] 1719 	inc	dptr
      0058F7 F0               [24] 1720 	movx	@dptr,a
      0058F8 A2 15            [12] 1721 	mov	c,_rgb_matrix_task_sloc0_1_0
      0058FA 12 3B 1F         [24] 1722 	lcall	_ak820_outline_0160
      0058FD 12 86 9D         [24] 1723 	lcall	_hsv_to_rgb_into
                                   1724 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      005900 12 5C 07         [24] 1725 	lcall	_ak820_outline_0184
      005903 FD               [12] 1726 	mov	r5,a
      005904 7E 00            [12] 1727 	mov	r6,#0x00
      005906 90 07 4F         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005909 E0               [24] 1729 	movx	a,@dptr
      00590A FC               [12] 1730 	mov	r4,a
      00590B 90 07 4E         [24] 1731 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      00590E E0               [24] 1732 	movx	a,@dptr
      00590F FB               [12] 1733 	mov	r3,a
      005910 90 07 50         [24] 1734 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005913 E0               [24] 1735 	movx	a,@dptr
      005914 FA               [12] 1736 	mov	r2,a
      005915 90 07 3E         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005918 EC               [12] 1738 	mov	a,r4
      005919 F0               [24] 1739 	movx	@dptr,a
      00591A 90 07 3F         [24] 1740 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00591D EB               [12] 1741 	mov	a,r3
      00591E F0               [24] 1742 	movx	@dptr,a
      00591F 90 07 40         [24] 1743 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005922 EA               [12] 1744 	mov	a,r2
      005923 F0               [24] 1745 	movx	@dptr,a
      005924 12 3B 09         [24] 1746 	lcall	_ak820_outline_0133
      005927 12 55 BD         [24] 1747 	lcall	_rgb_matrix_set_color
      00592A                       1748 00123$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      00592A 12 5C 07         [24] 1750 	lcall	_ak820_outline_0184
      00592D 24 01            [12] 1751 	add	a, #0x01
      00592F F0               [24] 1752 	movx	@dptr,a
      005930 02 57 B4         [24] 1753 	ljmp	00125$
      005933                       1754 00127$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005933 BF 52 02         [24] 1756 	cjne	r7,#0x52,00130$
                                   1757 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1758 ;	assignBit
      005936 C2 14            [12] 1759 	clr	_rendering
      005938                       1760 00130$:
                                   1761 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005938 22               [24] 1762 	ret
                                   1763 ;------------------------------------------------------------
                                   1764 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1765 ;------------------------------------------------------------
                                   1766 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1767 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1768 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1769 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1770 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1771 ;------------------------------------------------------------
                                   1772 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1773 ;	-----------------------------------------
                                   1774 ;	 function process_rgb_matrix
                                   1775 ;	-----------------------------------------
      005939                       1776 _process_rgb_matrix:
      005939 E5 82            [12] 1777 	mov	a,dpl
      00593B 90 07 53         [24] 1778 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00593E F0               [24] 1779 	movx	@dptr,a
                                   1780 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00593F 90 07 52         [24] 1781 	mov	dptr,#_process_rgb_matrix_PARM_3
      005942 E0               [24] 1782 	movx	a,@dptr
      005943 60 23            [24] 1783 	jz	00101$
      005945 20 12 20         [24] 1784 	jb	_suspended,00101$
      005948 12 5B BC         [24] 1785 	lcall	_ak820_outline_0066
      00594B 60 1B            [24] 1786 	jz	00101$
                                   1787 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00594D 12 5B 9D         [24] 1788 	lcall	_ak820_outline_0019
      005950 FF               [12] 1789 	mov	r7,a
      005951 BF 06 14         [24] 1790 	cjne	r7,#0x06,00101$
      005954 90 07 53         [24] 1791 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005957 E0               [24] 1792 	movx	a,@dptr
      005958 FF               [12] 1793 	mov	r7,a
      005959 BF 10 00         [24] 1794 	cjne	r7,#0x10,00169$
      00595C                       1795 00169$:
      00595C 50 0A            [24] 1796 	jnc	00101$
      00595E 90 07 51         [24] 1797 	mov	dptr,#_process_rgb_matrix_PARM_2
      005961 E0               [24] 1798 	movx	a,@dptr
      005962 FE               [12] 1799 	mov	r6,a
      005963 BE 08 00         [24] 1800 	cjne	r6,#0x08,00171$
      005966                       1801 00171$:
      005966 40 01            [24] 1802 	jc	00102$
      005968                       1803 00101$:
      005968 22               [24] 1804 	ret
      005969                       1805 00102$:
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005969 C0 07            [24] 1807 	push	ar7
      00596B C0 06            [24] 1808 	push	ar6
      00596D 12 54 4C         [24] 1809 	lcall	_age_reactive
      005970 D0 06            [24] 1810 	pop	ar6
      005972 D0 07            [24] 1811 	pop	ar7
                                   1812 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005974 EF               [12] 1813 	mov	a,r7
      005975 12 3B 34         [24] 1814 	lcall	_ak820_outline_0191
      005978 2E               [12] 1815 	add	a,r6
      005979 FF               [12] 1816 	mov	r7,a
                                   1817 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00597A 7E 00            [12] 1818 	mov	r6,#0x00
      00597C                       1819 00111$:
                                   1820 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      00597C EE               [12] 1821 	mov	a,r6
      00597D 90 BD 6B         [24] 1822 	mov	dptr,#_ak820_rgb_slots
      005980 93               [24] 1823 	movc	a,@a+dptr
      005981 B5 07 29         [24] 1824 	cjne	a,ar7,00112$
                                   1825 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005984 EE               [12] 1826 	mov	a,r6
      005985 24 E6            [12] 1827 	add	a, #_reactive_age
      005987 FC               [12] 1828 	mov	r4,a
      005988 E4               [12] 1829 	clr	a
      005989 34 06            [12] 1830 	addc	a, #(_reactive_age >> 8)
      00598B FD               [12] 1831 	mov	r5,a
      00598C 12 5B F5         [24] 1832 	lcall	_ak820_outline_0174
      00598F F5 F0            [12] 1833 	mov	b, a
      005991 05 F0            [12] 1834 	inc	b
      005993 7B 80            [12] 1835 	mov	r3,#0x80
      005995 E4               [12] 1836 	clr	a
      005996 FA               [12] 1837 	mov	r2,a
      005997 33               [12] 1838 	rlc	a
      005998 92 D2            [24] 1839 	mov	ov,c
      00599A 80 08            [24] 1840 	sjmp	00176$
      00599C                       1841 00175$:
      00599C A2 D2            [12] 1842 	mov	c,ov
      00599E EA               [12] 1843 	mov	a,r2
      00599F 13               [12] 1844 	rrc	a
      0059A0 FA               [12] 1845 	mov	r2,a
      0059A1 EB               [12] 1846 	mov	a,r3
      0059A2 13               [12] 1847 	rrc	a
      0059A3 FB               [12] 1848 	mov	r3,a
      0059A4                       1849 00176$:
      0059A4 D5 F0 F5         [24] 1850 	djnz	b,00175$
      0059A7 12 3A FF         [24] 1851 	lcall	_ak820_outline_0123
      0059AA EB               [12] 1852 	mov	a,r3
      0059AB F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      0059AC 22               [24] 1855 	ret
      0059AD                       1856 00112$:
                                   1857 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0059AD 0E               [12] 1858 	inc	r6
      0059AE BE 52 00         [24] 1859 	cjne	r6,#0x52,00177$
      0059B1                       1860 00177$:
      0059B1 40 C9            [24] 1861 	jc	00111$
                                   1862 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      0059B3 22               [24] 1863 	ret
                                   1864 ;------------------------------------------------------------
                                   1865 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1866 ;------------------------------------------------------------
                                   1867 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1868 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1869 ;------------------------------------------------------------
                                   1870 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1871 ;	-----------------------------------------
                                   1872 ;	 function rgb_matrix_set_suspend_state
                                   1873 ;	-----------------------------------------
      0059B4                       1874 _rgb_matrix_set_suspend_state:
      0059B4 E5 82            [12] 1875 	mov	a,dpl
      0059B6 90 07 54         [24] 1876 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0059B9 F0               [24] 1877 	movx	@dptr,a
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0059BA E0               [24] 1879 	movx	a,@dptr
                                   1880 ;	assignBit
      0059BB F5 15            [12] 1881 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0059BD 13               [12] 1882 	rrc	a
      0059BE 92 12            [24] 1883 	mov	_suspended,c
                                   1884 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1885 ;	assignBit
      0059C0 C2 14            [12] 1886 	clr	_rendering
                                   1887 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0059C2 12 54 2F         [24] 1888 	lcall	_clear_reactive
                                   1889 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0059C5 E5 15            [12] 1890 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0059C7 60 0F            [24] 1891 	jz	00103$
                                   1892 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0059C9 90 07 43         [24] 1893 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0059CC E4               [12] 1894 	clr	a
      0059CD F0               [24] 1895 	movx	@dptr,a
      0059CE 90 07 44         [24] 1896 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0059D1 F0               [24] 1897 	movx	@dptr,a
      0059D2 75 82 00         [24] 1898 	mov	dpl, #0x00
                                   1899 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0059D5 02 55 FE         [24] 1900 	ljmp	_rgb_matrix_set_color_all
      0059D8                       1901 00103$:
      0059D8 22               [24] 1902 	ret
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function rgb_matrix_is_enabled
                                   1909 ;	-----------------------------------------
      0059D9                       1910 _rgb_matrix_is_enabled:
      0059D9 12 5B BC         [24] 1911 	lcall	_ak820_outline_0066
      0059DC F5 82            [12] 1912 	mov	dpl,a
      0059DE 22               [24] 1913 	ret
                                   1914 ;------------------------------------------------------------
                                   1915 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1916 ;------------------------------------------------------------
                                   1917 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1918 ;	-----------------------------------------
                                   1919 ;	 function rgb_matrix_get_mode
                                   1920 ;	-----------------------------------------
      0059DF                       1921 _rgb_matrix_get_mode:
      0059DF 12 5B 9D         [24] 1922 	lcall	_ak820_outline_0019
      0059E2 F5 82            [12] 1923 	mov	dpl,a
      0059E4 22               [24] 1924 	ret
                                   1925 ;------------------------------------------------------------
                                   1926 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1927 ;------------------------------------------------------------
                                   1928 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1929 ;	-----------------------------------------
                                   1930 ;	 function rgb_matrix_get_hue
                                   1931 ;	-----------------------------------------
      0059E5                       1932 _rgb_matrix_get_hue:
      0059E5 90 06 D2         [24] 1933 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0059E8 E0               [24] 1934 	movx	a,@dptr
      0059E9 F5 82            [12] 1935 	mov	dpl,a
      0059EB 22               [24] 1936 	ret
                                   1937 ;------------------------------------------------------------
                                   1938 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1939 ;------------------------------------------------------------
                                   1940 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1941 ;	-----------------------------------------
                                   1942 ;	 function rgb_matrix_get_sat
                                   1943 ;	-----------------------------------------
      0059EC                       1944 _rgb_matrix_get_sat:
      0059EC 90 06 D3         [24] 1945 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0059EF E0               [24] 1946 	movx	a,@dptr
      0059F0 F5 82            [12] 1947 	mov	dpl,a
      0059F2 22               [24] 1948 	ret
                                   1949 ;------------------------------------------------------------
                                   1950 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1951 ;------------------------------------------------------------
                                   1952 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1953 ;	-----------------------------------------
                                   1954 ;	 function rgb_matrix_get_val
                                   1955 ;	-----------------------------------------
      0059F3                       1956 _rgb_matrix_get_val:
      0059F3 90 06 D4         [24] 1957 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0059F6 E0               [24] 1958 	movx	a,@dptr
      0059F7 F5 82            [12] 1959 	mov	dpl,a
      0059F9 22               [24] 1960 	ret
                                   1961 ;------------------------------------------------------------
                                   1962 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1963 ;------------------------------------------------------------
                                   1964 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1965 ;	-----------------------------------------
                                   1966 ;	 function rgb_matrix_get_speed
                                   1967 ;	-----------------------------------------
      0059FA                       1968 _rgb_matrix_get_speed:
      0059FA 90 06 D5         [24] 1969 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0059FD E0               [24] 1970 	movx	a,@dptr
      0059FE F5 82            [12] 1971 	mov	dpl,a
      005A00 22               [24] 1972 	ret
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1975 ;------------------------------------------------------------
                                   1976 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1977 ;	-----------------------------------------
                                   1978 ;	 function rgb_matrix_toggle_noeeprom
                                   1979 ;	-----------------------------------------
      005A01                       1980 _rgb_matrix_toggle_noeeprom:
      005A01 12 5B BC         [24] 1981 	lcall	_ak820_outline_0066
      005A04 FF               [12] 1982 	mov	r7,a
      005A05 63 07 01         [24] 1983 	xrl	ar7,#0x01
      005A08 90 06 D1         [24] 1984 	mov	dptr,#_rgb_matrix_config
      005A0B EF               [12] 1985 	mov	a,r7
      005A0C 54 03            [12] 1986 	anl	a,#0x03
      005A0E F5 F0            [12] 1987 	mov	b,a
      005A10 E0               [24] 1988 	movx	a,@dptr
      005A11 54 FC            [12] 1989 	anl	a,#0xfc
      005A13 45 F0            [12] 1990 	orl	a,b
      005A15 F0               [24] 1991 	movx	@dptr,a
                                   1992 ;	assignBit
      005A16 C2 14            [12] 1993 	clr	_rendering
      005A18 02 54 2F         [24] 1994 	ljmp	_clear_reactive
                                   1995 ;------------------------------------------------------------
                                   1996 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1997 ;------------------------------------------------------------
                                   1998 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1999 ;	-----------------------------------------
                                   2000 ;	 function rgb_matrix_enable_noeeprom
                                   2001 ;	-----------------------------------------
      005A1B                       2002 _rgb_matrix_enable_noeeprom:
      005A1B 12 5B BC         [24] 2003 	lcall	_ak820_outline_0066
      005A1E 70 03            [24] 2004 	jnz	00102$
      005A20 12 54 2F         [24] 2005 	lcall	_clear_reactive
      005A23                       2006 00102$:
      005A23 12 5B DD         [24] 2007 	lcall	_ak820_outline_0114
      005A26 44 01            [12] 2008 	orl	a,#0x01
      005A28 F0               [24] 2009 	movx	@dptr,a
                                   2010 ;	assignBit
      005A29 C2 14            [12] 2011 	clr	_rendering
      005A2B 22               [24] 2012 	ret
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2015 ;------------------------------------------------------------
                                   2016 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2017 ;	-----------------------------------------
                                   2018 ;	 function rgb_matrix_disable_noeeprom
                                   2019 ;	-----------------------------------------
      005A2C                       2020 _rgb_matrix_disable_noeeprom:
      005A2C 12 5B DD         [24] 2021 	lcall	_ak820_outline_0114
      005A2F F0               [24] 2022 	movx	@dptr,a
                                   2023 ;	assignBit
      005A30 C2 14            [12] 2024 	clr	_rendering
      005A32 02 54 2F         [24] 2025 	ljmp	_clear_reactive
                                   2026 ;------------------------------------------------------------
                                   2027 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2028 ;------------------------------------------------------------
                                   2029 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2030 ;------------------------------------------------------------
                                   2031 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2032 ;	-----------------------------------------
                                   2033 ;	 function rgb_matrix_mode_noeeprom
                                   2034 ;	-----------------------------------------
      005A35                       2035 _rgb_matrix_mode_noeeprom:
      005A35 E5 82            [12] 2036 	mov	a,dpl
      005A37 90 07 55         [24] 2037 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A3A F0               [24] 2038 	movx	@dptr,a
                                   2039 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005A3B E0               [24] 2040 	movx	a,@dptr
      005A3C FF               [12] 2041 	mov	r7,a
      005A3D 60 05            [24] 2042 	jz	00101$
      005A3F BF 07 00         [24] 2043 	cjne	r7,#0x07,00123$
      005A42                       2044 00123$:
      005A42 40 01            [24] 2045 	jc	00102$
      005A44                       2046 00101$:
      005A44 22               [24] 2047 	ret
      005A45                       2048 00102$:
                                   2049 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005A45 12 5B 9D         [24] 2050 	lcall	_ak820_outline_0019
      005A48 FE               [12] 2051 	mov	r6,a
      005A49 EF               [12] 2052 	mov	a,r7
      005A4A B5 06 02         [24] 2053 	cjne	a,ar6,00125$
      005A4D 80 03            [24] 2054 	sjmp	00105$
      005A4F                       2055 00125$:
      005A4F 12 54 2F         [24] 2056 	lcall	_clear_reactive
      005A52                       2057 00105$:
                                   2058 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005A52 90 07 55         [24] 2059 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005A55 E0               [24] 2060 	movx	a,@dptr
      005A56 90 06 D1         [24] 2061 	mov	dptr,#_rgb_matrix_config
      005A59 25 E0            [12] 2062 	add	a,acc
      005A5B 25 E0            [12] 2063 	add	a,acc
      005A5D 54 FC            [12] 2064 	anl	a,#0xfc
      005A5F F5 F0            [12] 2065 	mov	b,a
      005A61 E0               [24] 2066 	movx	a,@dptr
      005A62 54 03            [12] 2067 	anl	a,#0x03
      005A64 45 F0            [12] 2068 	orl	a,b
      005A66 F0               [24] 2069 	movx	@dptr,a
                                   2070 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2071 ;	assignBit
      005A67 C2 14            [12] 2072 	clr	_rendering
                                   2073 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005A69 22               [24] 2074 	ret
                                   2075 ;------------------------------------------------------------
                                   2076 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2077 ;------------------------------------------------------------
                                   2078 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2079 ;	-----------------------------------------
                                   2080 ;	 function rgb_matrix_step_noeeprom
                                   2081 ;	-----------------------------------------
      005A6A                       2082 _rgb_matrix_step_noeeprom:
                                   2083 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005A6A 12 5B 9D         [24] 2084 	lcall	_ak820_outline_0019
      005A6D FF               [12] 2085 	mov	r7,a
      005A6E 0F               [12] 2086 	inc	r7
      005A6F BF 07 00         [24] 2087 	cjne	r7,#0x07,00112$
      005A72                       2088 00112$:
      005A72 40 04            [24] 2089 	jc	00103$
      005A74 7F 01            [12] 2090 	mov	r7,#0x01
      005A76 80 07            [24] 2091 	sjmp	00104$
      005A78                       2092 00103$:
      005A78 12 5B 9D         [24] 2093 	lcall	_ak820_outline_0019
      005A7B FE               [12] 2094 	mov	r6,a
      005A7C 0E               [12] 2095 	inc	r6
      005A7D 8E 07            [24] 2096 	mov	ar7,r6
      005A7F                       2097 00104$:
      005A7F 8F 82            [24] 2098 	mov	dpl, r7
                                   2099 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005A81 41 35            [12] 2100 	ajmp	_rgb_matrix_mode_noeeprom
                                   2101 ;------------------------------------------------------------
                                   2102 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2103 ;------------------------------------------------------------
                                   2104 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2105 ;	-----------------------------------------
                                   2106 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2107 ;	-----------------------------------------
      005A83                       2108 _rgb_matrix_step_reverse_noeeprom:
                                   2109 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005A83 12 5B 9D         [24] 2110 	lcall	_ak820_outline_0019
      005A86 24 FE            [12] 2111 	add	a,#0xff - 0x01
      005A88 40 04            [24] 2112 	jc	00103$
                                   2113 ;	free result
      005A8A 7F 06            [12] 2114 	mov	r7,#0x06
      005A8C 80 05            [24] 2115 	sjmp	00104$
      005A8E                       2116 00103$:
      005A8E 12 5B 9D         [24] 2117 	lcall	_ak820_outline_0019
      005A91 14               [12] 2118 	dec	a
      005A92 FF               [12] 2119 	mov	r7,a
      005A93                       2120 00104$:
      005A93 8F 82            [24] 2121 	mov	dpl, r7
                                   2122 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005A95 41 35            [12] 2123 	ajmp	_rgb_matrix_mode_noeeprom
                                   2124 ;------------------------------------------------------------
                                   2125 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2126 ;------------------------------------------------------------
                                   2127 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2128 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2129 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2130 ;------------------------------------------------------------
                                   2131 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2132 ;	-----------------------------------------
                                   2133 ;	 function rgb_matrix_sethsv_noeeprom
                                   2134 ;	-----------------------------------------
      005A97                       2135 _rgb_matrix_sethsv_noeeprom:
      005A97 12 3A F0         [24] 2136 	lcall	_ak820_outline_0107
      005A9A 90 07 58         [24] 2137 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005A9D 12 3A F5         [24] 2138 	lcall	_ak820_outline_0108
                                   2139 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005AA0 90 07 58         [24] 2140 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005AA3 E0               [24] 2141 	movx	a,@dptr
      005AA4 90 06 D2         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AA7 F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005AA8 90 07 56         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005AAB E0               [24] 2146 	movx	a,@dptr
      005AAC FF               [12] 2147 	mov	r7,a
      005AAD 90 06 D3         [24] 2148 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AB0 F0               [24] 2149 	movx	@dptr,a
                                   2150 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005AB1 90 07 57         [24] 2151 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005AB4 E0               [24] 2152 	movx	a,@dptr
      005AB5 FF               [12] 2153 	mov  r7,a
      005AB6 24 5F            [12] 2154 	add	a,#0xff - 0xa0
      005AB8 50 04            [24] 2155 	jnc	00103$
                                   2156 ;	free result
      005ABA 7E A0            [12] 2157 	mov	r6,#0xa0
      005ABC 80 02            [24] 2158 	sjmp	00104$
      005ABE                       2159 00103$:
      005ABE 8F 06            [24] 2160 	mov	ar6,r7
      005AC0                       2161 00104$:
      005AC0 90 06 D4         [24] 2162 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005AC3 EE               [12] 2163 	mov	a,r6
      005AC4 F0               [24] 2164 	movx	@dptr,a
                                   2165 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005AC5 22               [24] 2166 	ret
                                   2167 ;------------------------------------------------------------
                                   2168 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2169 ;------------------------------------------------------------
                                   2170 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2171 ;------------------------------------------------------------
                                   2172 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2173 ;	-----------------------------------------
                                   2174 ;	 function rgb_matrix_set_speed_noeeprom
                                   2175 ;	-----------------------------------------
      005AC6                       2176 _rgb_matrix_set_speed_noeeprom:
      005AC6 E5 82            [12] 2177 	mov	a,dpl
      005AC8 90 07 5A         [24] 2178 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005ACB F0               [24] 2179 	movx	@dptr,a
      005ACC E0               [24] 2180 	movx	a,@dptr
      005ACD 90 06 D5         [24] 2181 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005AD0 F0               [24] 2182 	movx	@dptr,a
      005AD1 22               [24] 2183 	ret
                                   2184 ;------------------------------------------------------------
                                   2185 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2186 ;------------------------------------------------------------
                                   2187 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2188 ;------------------------------------------------------------
                                   2189 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2190 ;	-----------------------------------------
                                   2191 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2192 ;	-----------------------------------------
      005AD2                       2193 _rgb_matrix_increase_hue_noeeprom:
      005AD2 90 06 D2         [24] 2194 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AD5 E0               [24] 2195 	movx	a,@dptr
      005AD6 24 08            [12] 2196 	add	a,#0x08
      005AD8 90 06 D2         [24] 2197 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005ADB F0               [24] 2198 	movx	@dptr,a
      005ADC 22               [24] 2199 	ret
                                   2200 ;------------------------------------------------------------
                                   2201 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2202 ;------------------------------------------------------------
                                   2203 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2204 ;	-----------------------------------------
                                   2205 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2206 ;	-----------------------------------------
      005ADD                       2207 _rgb_matrix_decrease_hue_noeeprom:
      005ADD 90 06 D2         [24] 2208 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AE0 E0               [24] 2209 	movx	a,@dptr
      005AE1 24 F8            [12] 2210 	add	a,#0xf8
      005AE3 90 06 D2         [24] 2211 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005AE6 F0               [24] 2212 	movx	@dptr,a
      005AE7 22               [24] 2213 	ret
                                   2214 ;------------------------------------------------------------
                                   2215 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2216 ;------------------------------------------------------------
                                   2217 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2218 ;	-----------------------------------------
                                   2219 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2220 ;	-----------------------------------------
      005AE8                       2221 _rgb_matrix_increase_sat_noeeprom:
      005AE8 90 06 D3         [24] 2222 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AEB 12 5B A6         [24] 2223 	lcall	_ak820_outline_0048
      005AEE 12 54 CA         [24] 2224 	lcall	_add_sat
      005AF1 AF 82            [24] 2225 	mov	r7, dpl
      005AF3 90 06 D3         [24] 2226 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AF6 EF               [12] 2227 	mov	a,r7
      005AF7 F0               [24] 2228 	movx	@dptr,a
      005AF8 22               [24] 2229 	ret
                                   2230 ;------------------------------------------------------------
                                   2231 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2232 ;------------------------------------------------------------
                                   2233 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2234 ;	-----------------------------------------
                                   2235 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2236 ;	-----------------------------------------
      005AF9                       2237 _rgb_matrix_decrease_sat_noeeprom:
      005AF9 90 06 D3         [24] 2238 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005AFC 12 5B B1         [24] 2239 	lcall	_ak820_outline_0049
      005AFF 12 54 EF         [24] 2240 	lcall	_sub_sat
      005B02 AF 82            [24] 2241 	mov	r7, dpl
      005B04 90 06 D3         [24] 2242 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005B07 EF               [12] 2243 	mov	a,r7
      005B08 F0               [24] 2244 	movx	@dptr,a
      005B09 22               [24] 2245 	ret
                                   2246 ;------------------------------------------------------------
                                   2247 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2248 ;------------------------------------------------------------
                                   2249 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2250 ;------------------------------------------------------------
                                   2251 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2252 ;	-----------------------------------------
                                   2253 ;	 function rgb_matrix_increase_val_noeeprom
                                   2254 ;	-----------------------------------------
      005B0A                       2255 _rgb_matrix_increase_val_noeeprom:
                                   2256 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005B0A 90 06 D4         [24] 2257 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B0D 12 5B A6         [24] 2258 	lcall	_ak820_outline_0048
      005B10 12 54 CA         [24] 2259 	lcall	_add_sat
                                   2260 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005B13 E5 82            [12] 2261 	mov	a,dpl
      005B15 FF               [12] 2262 	mov	r7,a
      005B16 24 5F            [12] 2263 	add	a,#0xff - 0xa0
      005B18 50 04            [24] 2264 	jnc	00103$
                                   2265 ;	free result
      005B1A 7E A0            [12] 2266 	mov	r6,#0xa0
      005B1C 80 02            [24] 2267 	sjmp	00104$
      005B1E                       2268 00103$:
      005B1E 8F 06            [24] 2269 	mov	ar6,r7
      005B20                       2270 00104$:
      005B20 90 06 D4         [24] 2271 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B23 EE               [12] 2272 	mov	a,r6
      005B24 F0               [24] 2273 	movx	@dptr,a
                                   2274 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005B25 22               [24] 2275 	ret
                                   2276 ;------------------------------------------------------------
                                   2277 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2278 ;------------------------------------------------------------
                                   2279 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2280 ;	-----------------------------------------
                                   2281 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2282 ;	-----------------------------------------
      005B26                       2283 _rgb_matrix_decrease_val_noeeprom:
      005B26 90 06 D4         [24] 2284 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B29 12 5B B1         [24] 2285 	lcall	_ak820_outline_0049
      005B2C 12 54 EF         [24] 2286 	lcall	_sub_sat
      005B2F AF 82            [24] 2287 	mov	r7, dpl
      005B31 90 06 D4         [24] 2288 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005B34 EF               [12] 2289 	mov	a,r7
      005B35 F0               [24] 2290 	movx	@dptr,a
      005B36 22               [24] 2291 	ret
                                   2292 ;------------------------------------------------------------
                                   2293 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2294 ;------------------------------------------------------------
                                   2295 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2296 ;	-----------------------------------------
                                   2297 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2298 ;	-----------------------------------------
      005B37                       2299 _rgb_matrix_increase_speed_noeeprom:
      005B37 90 06 D5         [24] 2300 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B3A 12 5B A6         [24] 2301 	lcall	_ak820_outline_0048
      005B3D 12 54 CA         [24] 2302 	lcall	_add_sat
      005B40 AF 82            [24] 2303 	mov	r7, dpl
      005B42 90 06 D5         [24] 2304 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B45 EF               [12] 2305 	mov	a,r7
      005B46 F0               [24] 2306 	movx	@dptr,a
      005B47 22               [24] 2307 	ret
                                   2308 ;------------------------------------------------------------
                                   2309 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2310 ;------------------------------------------------------------
                                   2311 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2312 ;	-----------------------------------------
                                   2313 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2314 ;	-----------------------------------------
      005B48                       2315 _rgb_matrix_decrease_speed_noeeprom:
      005B48 90 06 D5         [24] 2316 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B4B 12 5B B1         [24] 2317 	lcall	_ak820_outline_0049
      005B4E 12 54 EF         [24] 2318 	lcall	_sub_sat
      005B51 AF 82            [24] 2319 	mov	r7, dpl
      005B53 90 06 D5         [24] 2320 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005B56 EF               [12] 2321 	mov	a,r7
      005B57 F0               [24] 2322 	movx	@dptr,a
      005B58 22               [24] 2323 	ret
                                   2324 ;------------------------------------------------------------
                                   2325 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2326 ;------------------------------------------------------------
                                   2327 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2328 ;	-----------------------------------------
                                   2329 ;	 function rgb_matrix_toggle
                                   2330 ;	-----------------------------------------
      005B59                       2331 _rgb_matrix_toggle:
      005B59 51 01            [12] 2332 	acall	_rgb_matrix_toggle_noeeprom
      005B5B 02 55 0C         [24] 2333 	ljmp	_mark_dirty
                                   2334 ;------------------------------------------------------------
                                   2335 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2336 ;------------------------------------------------------------
                                   2337 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2338 ;	-----------------------------------------
                                   2339 ;	 function rgb_matrix_step
                                   2340 ;	-----------------------------------------
      005B5E                       2341 _rgb_matrix_step:
      005B5E 51 6A            [12] 2342 	acall	_rgb_matrix_step_noeeprom
      005B60 02 55 0C         [24] 2343 	ljmp	_mark_dirty
                                   2344 ;------------------------------------------------------------
                                   2345 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2346 ;------------------------------------------------------------
                                   2347 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2348 ;	-----------------------------------------
                                   2349 ;	 function rgb_matrix_step_reverse
                                   2350 ;	-----------------------------------------
      005B63                       2351 _rgb_matrix_step_reverse:
      005B63 51 83            [12] 2352 	acall	_rgb_matrix_step_reverse_noeeprom
      005B65 02 55 0C         [24] 2353 	ljmp	_mark_dirty
                                   2354 ;------------------------------------------------------------
                                   2355 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2356 ;------------------------------------------------------------
                                   2357 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2358 ;	-----------------------------------------
                                   2359 ;	 function rgb_matrix_increase_hue
                                   2360 ;	-----------------------------------------
      005B68                       2361 _rgb_matrix_increase_hue:
      005B68 51 D2            [12] 2362 	acall	_rgb_matrix_increase_hue_noeeprom
      005B6A 02 55 0C         [24] 2363 	ljmp	_mark_dirty
                                   2364 ;------------------------------------------------------------
                                   2365 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2366 ;------------------------------------------------------------
                                   2367 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2368 ;	-----------------------------------------
                                   2369 ;	 function rgb_matrix_decrease_hue
                                   2370 ;	-----------------------------------------
      005B6D                       2371 _rgb_matrix_decrease_hue:
      005B6D 51 DD            [12] 2372 	acall	_rgb_matrix_decrease_hue_noeeprom
      005B6F 02 55 0C         [24] 2373 	ljmp	_mark_dirty
                                   2374 ;------------------------------------------------------------
                                   2375 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2376 ;------------------------------------------------------------
                                   2377 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2378 ;	-----------------------------------------
                                   2379 ;	 function rgb_matrix_increase_sat
                                   2380 ;	-----------------------------------------
      005B72                       2381 _rgb_matrix_increase_sat:
      005B72 51 E8            [12] 2382 	acall	_rgb_matrix_increase_sat_noeeprom
      005B74 02 55 0C         [24] 2383 	ljmp	_mark_dirty
                                   2384 ;------------------------------------------------------------
                                   2385 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2386 ;------------------------------------------------------------
                                   2387 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2388 ;	-----------------------------------------
                                   2389 ;	 function rgb_matrix_decrease_sat
                                   2390 ;	-----------------------------------------
      005B77                       2391 _rgb_matrix_decrease_sat:
      005B77 51 F9            [12] 2392 	acall	_rgb_matrix_decrease_sat_noeeprom
      005B79 02 55 0C         [24] 2393 	ljmp	_mark_dirty
                                   2394 ;------------------------------------------------------------
                                   2395 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2396 ;------------------------------------------------------------
                                   2397 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2398 ;	-----------------------------------------
                                   2399 ;	 function rgb_matrix_increase_val
                                   2400 ;	-----------------------------------------
      005B7C                       2401 _rgb_matrix_increase_val:
      005B7C 71 0A            [12] 2402 	acall	_rgb_matrix_increase_val_noeeprom
      005B7E 02 55 0C         [24] 2403 	ljmp	_mark_dirty
                                   2404 ;------------------------------------------------------------
                                   2405 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2406 ;------------------------------------------------------------
                                   2407 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2408 ;	-----------------------------------------
                                   2409 ;	 function rgb_matrix_decrease_val
                                   2410 ;	-----------------------------------------
      005B81                       2411 _rgb_matrix_decrease_val:
      005B81 71 26            [12] 2412 	acall	_rgb_matrix_decrease_val_noeeprom
      005B83 02 55 0C         [24] 2413 	ljmp	_mark_dirty
                                   2414 ;------------------------------------------------------------
                                   2415 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2416 ;------------------------------------------------------------
                                   2417 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2418 ;	-----------------------------------------
                                   2419 ;	 function rgb_matrix_increase_speed
                                   2420 ;	-----------------------------------------
      005B86                       2421 _rgb_matrix_increase_speed:
      005B86 71 37            [12] 2422 	acall	_rgb_matrix_increase_speed_noeeprom
      005B88 02 55 0C         [24] 2423 	ljmp	_mark_dirty
                                   2424 ;------------------------------------------------------------
                                   2425 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2426 ;------------------------------------------------------------
                                   2427 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2428 ;	-----------------------------------------
                                   2429 ;	 function rgb_matrix_decrease_speed
                                   2430 ;	-----------------------------------------
      005B8B                       2431 _rgb_matrix_decrease_speed:
      005B8B 71 48            [12] 2432 	acall	_rgb_matrix_decrease_speed_noeeprom
      005B8D 02 55 0C         [24] 2433 	ljmp	_mark_dirty
                                   2434 ;------------------------------------------------------------
                                   2435 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2436 ;------------------------------------------------------------
                                   2437 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2438 ;------------------------------------------------------------
                                   2439 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2440 ;	-----------------------------------------
                                   2441 ;	 function rgb_matrix_mode
                                   2442 ;	-----------------------------------------
      005B90                       2443 _rgb_matrix_mode:
      005B90 E5 82            [12] 2444 	mov	a,dpl
      005B92 90 07 5B         [24] 2445 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005B95 12 5B F0         [24] 2446 	lcall	_ak820_outline_0171
      005B98 51 35            [12] 2447 	acall	_rgb_matrix_mode_noeeprom
      005B9A 02 55 0C         [24] 2448 	ljmp	_mark_dirty
                                   2449 ;------------------------------------------------------------
                                   2450 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2451 ;------------------------------------------------------------
                                   2452 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2453 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2454 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2455 ;------------------------------------------------------------
                                   2456 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2457 ;	-----------------------------------------
                                   2458 	.area CSEG    (CODE)
                                   2459 	.area CONST   (CODE)
                                   2460 	.area CONST   (CODE)
      00BDBD                       2461 _sine8_coefficients_10000_290:
      00BDBD 00                    2462 	.db #0x00	; 0
      00BDBE 31                    2463 	.db #0x31	; 49	'1'
      00BDBF 31                    2464 	.db #0x31	; 49	'1'
      00BDC0 29                    2465 	.db #0x29	; 41
      00BDC1 5A                    2466 	.db #0x5a	; 90	'Z'
      00BDC2 1B                    2467 	.db #0x1b	; 27
      00BDC3 75                    2468 	.db #0x75	; 117	'u'
      00BDC4 0A                    2469 	.db #0x0a	; 10
                                   2470 	.area CSEG    (CODE)
                                   2471 	.area XINIT   (CODE)
                                   2472 	.area CABS    (ABS,CODE)
                                   2473 
                                   2474 ; Experimental exact instruction outlining.
                                   2475 	.globl _ak820_outline_0005
                                   2476 	.globl _ak820_outline_0019
                                   2477 	.globl _ak820_outline_0048
                                   2478 	.globl _ak820_outline_0049
                                   2479 	.globl _ak820_outline_0052
                                   2480 	.globl _ak820_outline_0060
                                   2481 	.globl _ak820_outline_0061
                                   2482 	.globl _ak820_outline_0066
                                   2483 	.globl _ak820_outline_0070
                                   2484 	.globl _ak820_outline_0072
                                   2485 	.globl _ak820_outline_0086
                                   2486 	.globl _ak820_outline_0087
                                   2487 	.globl _ak820_outline_0096
                                   2488 	.globl _ak820_outline_0107
                                   2489 	.globl _ak820_outline_0108
                                   2490 	.globl _ak820_outline_0109
                                   2491 	.globl _ak820_outline_0114
                                   2492 	.globl _ak820_outline_0123
                                   2493 	.globl _ak820_outline_0124
                                   2494 	.globl _ak820_outline_0125
                                   2495 	.globl _ak820_outline_0133
                                   2496 	.globl _ak820_outline_0136
                                   2497 	.globl _ak820_outline_0138
                                   2498 	.globl _ak820_outline_0160
                                   2499 	.globl _ak820_outline_0170
                                   2500 	.globl _ak820_outline_0171
                                   2501 	.globl _ak820_outline_0174
                                   2502 	.globl _ak820_outline_0179
                                   2503 	.globl _ak820_outline_0184
                                   2504 	.globl _ak820_outline_0186
                                   2505 	.globl _ak820_outline_0191
                                   2506 
                                   2507 	.area CSEG (CODE)
                                   2508 ; function ak820_outline_0019
      005B9D                       2509 _ak820_outline_0019:
      005B9D 90 06 D1         [24] 2510 	mov	dptr,#_rgb_matrix_config
      005BA0 E0               [24] 2511 	movx	a,@dptr
      005BA1 03               [12] 2512 	rr	a
      005BA2 03               [12] 2513 	rr	a
      005BA3 54 3F            [12] 2514 	anl	a,#0x3f
      005BA5 22               [24] 2515 	ret
                                   2516 
                                   2517 	.area CSEG (CODE)
                                   2518 ; function ak820_outline_0048
      005BA6                       2519 _ak820_outline_0048:
      005BA6 E0               [24] 2520 	movx	a,@dptr
      005BA7 FF               [12] 2521 	mov	r7,a
      005BA8 90 07 3A         [24] 2522 	mov	dptr,#_add_sat_PARM_2
      005BAB 74 10            [12] 2523 	mov	a,#0x10
      005BAD F0               [24] 2524 	movx	@dptr,a
      005BAE 8F 82            [24] 2525 	mov	dpl,r7
      005BB0 22               [24] 2526 	ret
                                   2527 
                                   2528 	.area CSEG (CODE)
                                   2529 ; function ak820_outline_0049
      005BB1                       2530 _ak820_outline_0049:
      005BB1 E0               [24] 2531 	movx	a,@dptr
      005BB2 FF               [12] 2532 	mov	r7,a
      005BB3 90 07 3C         [24] 2533 	mov	dptr,#_sub_sat_PARM_2
      005BB6 74 10            [12] 2534 	mov	a,#0x10
      005BB8 F0               [24] 2535 	movx	@dptr,a
      005BB9 8F 82            [24] 2536 	mov	dpl,r7
      005BBB 22               [24] 2537 	ret
                                   2538 
                                   2539 	.area CSEG (CODE)
                                   2540 ; function ak820_outline_0066
      005BBC                       2541 _ak820_outline_0066:
      005BBC 90 06 D1         [24] 2542 	mov	dptr,#_rgb_matrix_config
      005BBF E0               [24] 2543 	movx	a,@dptr
      005BC0 54 03            [12] 2544 	anl	a,#0x03
      005BC2 22               [24] 2545 	ret
                                   2546 
                                   2547 	.area CSEG (CODE)
                                   2548 ; function ak820_outline_0070
      005BC3                       2549 _ak820_outline_0070:
      005BC3 74 08            [12] 2550 	mov	a,#0x08
      005BC5 F0               [24] 2551 	movx	@dptr,a
      005BC6 E4               [12] 2552 	clr	a
      005BC7 A3               [24] 2553 	inc	dptr
      005BC8 F0               [24] 2554 	movx	@dptr,a
      005BC9 90 06 D1         [24] 2555 	mov	dptr,#_rgb_matrix_config
      005BCC 22               [24] 2556 	ret
                                   2557 
                                   2558 	.area CSEG (CODE)
                                   2559 ; function ak820_outline_0087
      005BCD                       2560 _ak820_outline_0087:
      005BCD 74 18            [12] 2561 	mov	a,#0x18
      005BCF F0               [24] 2562 	movx	@dptr,a
      005BD0 E4               [12] 2563 	clr	a
      005BD1 A3               [24] 2564 	inc	dptr
      005BD2 F0               [24] 2565 	movx	@dptr,a
      005BD3 A3               [24] 2566 	inc	dptr
      005BD4 F0               [24] 2567 	movx	@dptr,a
      005BD5 22               [24] 2568 	ret
                                   2569 
                                   2570 	.area CSEG (CODE)
                                   2571 ; function ak820_outline_0109
      005BD6                       2572 _ak820_outline_0109:
      005BD6 35 F0            [12] 2573 	addc	a,b
      005BD8 F5 83            [12] 2574 	mov	dph,a
      005BDA E4               [12] 2575 	clr	a
      005BDB 93               [24] 2576 	movc	a,@a+dptr
      005BDC 22               [24] 2577 	ret
                                   2578 
                                   2579 	.area CSEG (CODE)
                                   2580 ; function ak820_outline_0114
      005BDD                       2581 _ak820_outline_0114:
      005BDD 90 06 D1         [24] 2582 	mov	dptr,#_rgb_matrix_config
      005BE0 E0               [24] 2583 	movx	a,@dptr
      005BE1 54 FC            [12] 2584 	anl	a,#0xfc
      005BE3 22               [24] 2585 	ret
                                   2586 
                                   2587 	.area CSEG (CODE)
                                   2588 ; function ak820_outline_0138
      005BE4                       2589 _ak820_outline_0138:
      005BE4 90 06 E0         [24] 2590 	mov	dptr,#_frame_mode
      005BE7 E0               [24] 2591 	movx	a,@dptr
      005BE8 FE               [12] 2592 	mov	r6,a
      005BE9 22               [24] 2593 	ret
                                   2594 
                                   2595 	.area CSEG (CODE)
                                   2596 ; function ak820_outline_0170
      005BEA                       2597 _ak820_outline_0170:
      005BEA F0               [24] 2598 	movx	@dptr,a
      005BEB E5 F0            [12] 2599 	mov	a,b
      005BED A3               [24] 2600 	inc	dptr
      005BEE F0               [24] 2601 	movx	@dptr,a
      005BEF 22               [24] 2602 	ret
                                   2603 
                                   2604 	.area CSEG (CODE)
                                   2605 ; function ak820_outline_0171
      005BF0                       2606 _ak820_outline_0171:
      005BF0 F0               [24] 2607 	movx	@dptr,a
      005BF1 E0               [24] 2608 	movx	a,@dptr
      005BF2 F5 82            [12] 2609 	mov	dpl,a
      005BF4 22               [24] 2610 	ret
                                   2611 
                                   2612 	.area CSEG (CODE)
                                   2613 ; function ak820_outline_0174
      005BF5                       2614 _ak820_outline_0174:
      005BF5 90 06 D5         [24] 2615 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005BF8 E0               [24] 2616 	movx	a,@dptr
      005BF9 23               [12] 2617 	rl	a
      005BFA 23               [12] 2618 	rl	a
      005BFB 54 03            [12] 2619 	anl	a,#0x03
      005BFD 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0179
      005BFE                       2624 _ak820_outline_0179:
      005BFE 90 0D DB         [24] 2625 	mov	dptr,#_memset_PARM_2
      005C01 E4               [12] 2626 	clr	a
      005C02 F0               [24] 2627 	movx	@dptr,a
      005C03 90 0D DC         [24] 2628 	mov	dptr,#_memset_PARM_3
      005C06 22               [24] 2629 	ret
                                   2630 
                                   2631 	.area CSEG (CODE)
                                   2632 ; function ak820_outline_0184
      005C07                       2633 _ak820_outline_0184:
      005C07 90 06 DF         [24] 2634 	mov	dptr,#_led_index
      005C0A E0               [24] 2635 	movx	a,@dptr
      005C0B 22               [24] 2636 	ret
                                   2637 
                                   2638 	.area CSEG (CODE)
                                   2639 ; function ak820_outline_0186
      005C0C                       2640 _ak820_outline_0186:
      005C0C C4               [12] 2641 	swap	a
      005C0D 23               [12] 2642 	rl	a
      005C0E 54 1F            [12] 2643 	anl	a,#0x1f
      005C10 22               [24] 2644 	ret
