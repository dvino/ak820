                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
      000034                        601 _dynamic_keymap_macro_send_sloc0_1_0:
      000034                        602 	.ds 3
                                    603 ;--------------------------------------------------------
                                    604 ; overlayable items in internal ram
                                    605 ;--------------------------------------------------------
                                    606 ;--------------------------------------------------------
                                    607 ; indirectly addressable internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area ISEG    (DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; absolute internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area IABS    (ABS,DATA)
                                    614 	.area IABS    (ABS,DATA)
                                    615 ;--------------------------------------------------------
                                    616 ; bit data
                                    617 ;--------------------------------------------------------
                                    618 	.area BSEG    (BIT)
      000025                        619 _dynamic_keymap_macro_send_sloc1_1_0:
      000025                        620 	.ds 1
                                    621 ;--------------------------------------------------------
                                    622 ; paged external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area PSEG    (PAG,XDATA)
                                    625 ;--------------------------------------------------------
                                    626 ; uninitialized external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area XSEG    (XDATA)
      000B0A                        629 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B0A                        630 	.ds 1
      000B0B                        631 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B0B                        632 	.ds 1
      000B0C                        633 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000B0C                        634 	.ds 1
      000B0D                        635 _dynamic_keymap_get_keycode_PARM_2:
      000B0D                        636 	.ds 1
      000B0E                        637 _dynamic_keymap_get_keycode_PARM_3:
      000B0E                        638 	.ds 1
      000B0F                        639 _dynamic_keymap_get_keycode_layer_10000_367:
      000B0F                        640 	.ds 1
      000B10                        641 _dynamic_keymap_set_keycode_PARM_2:
      000B10                        642 	.ds 1
      000B11                        643 _dynamic_keymap_set_keycode_PARM_3:
      000B11                        644 	.ds 1
      000B12                        645 _dynamic_keymap_set_keycode_PARM_4:
      000B12                        646 	.ds 2
      000B14                        647 _dynamic_keymap_set_keycode_layer_10000_371:
      000B14                        648 	.ds 1
      000B15                        649 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B15                        650 	.ds 1
      000B16                        651 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000B16                        652 	.ds 1
      000B17                        653 _dynamic_keymap_get_encoder_PARM_2:
      000B17                        654 	.ds 1
      000B18                        655 _dynamic_keymap_get_encoder_PARM_3:
      000B18                        656 	.ds 1
      000B19                        657 _dynamic_keymap_get_encoder_layer_10000_377:
      000B19                        658 	.ds 1
      000B1A                        659 _dynamic_keymap_set_encoder_PARM_2:
      000B1A                        660 	.ds 1
      000B1B                        661 _dynamic_keymap_set_encoder_PARM_3:
      000B1B                        662 	.ds 1
      000B1C                        663 _dynamic_keymap_set_encoder_PARM_4:
      000B1C                        664 	.ds 2
      000B1E                        665 _dynamic_keymap_set_encoder_layer_10000_381:
      000B1E                        666 	.ds 1
      000B1F                        667 _dynamic_keymap_get_combo_PARM_2:
      000B1F                        668 	.ds 3
      000B22                        669 _dynamic_keymap_get_combo_index_10000_385:
      000B22                        670 	.ds 1
      000B23                        671 _dynamic_keymap_set_combo_PARM_2:
      000B23                        672 	.ds 3
      000B26                        673 _dynamic_keymap_set_combo_index_10000_391:
      000B26                        674 	.ds 1
      000B27                        675 _dynamic_keymap_set_combo_stored_10002_396:
      000B27                        676 	.ds 10
      000B31                        677 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B31                        678 	.ds 1
      000B32                        679 _dynamic_keymap_reset_combo_10001_408:
      000B32                        680 	.ds 10
      000B3C                        681 _ak820_dynamic_read_buffer_PARM_2:
      000B3C                        682 	.ds 2
      000B3E                        683 _ak820_dynamic_read_buffer_PARM_3:
      000B3E                        684 	.ds 2
      000B40                        685 _ak820_dynamic_read_buffer_PARM_4:
      000B40                        686 	.ds 2
      000B42                        687 _ak820_dynamic_read_buffer_PARM_5:
      000B42                        688 	.ds 3
      000B45                        689 _ak820_dynamic_read_buffer_base_10000_410:
      000B45                        690 	.ds 2
      000B47                        691 _ak820_dynamic_read_buffer_available_10000_411:
      000B47                        692 	.ds 1
      000B48                        693 _dynamic_keymap_get_buffer_PARM_2:
      000B48                        694 	.ds 2
      000B4A                        695 _dynamic_keymap_get_buffer_PARM_3:
      000B4A                        696 	.ds 3
      000B4D                        697 _dynamic_keymap_get_buffer_offset_10000_417:
      000B4D                        698 	.ds 2
      000B4F                        699 _dynamic_keymap_set_buffer_PARM_2:
      000B4F                        700 	.ds 2
      000B51                        701 _dynamic_keymap_set_buffer_PARM_3:
      000B51                        702 	.ds 3
      000B54                        703 _dynamic_keymap_set_buffer_offset_10000_419:
      000B54                        704 	.ds 2
      000B56                        705 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B56                        706 	.ds 1
      000B57                        707 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B57                        708 	.ds 1
      000B58                        709 _dynamic_keymap_set_buffer_i_40001_433:
      000B58                        710 	.ds 1
      000B59                        711 _keycode_at_keymap_location_PARM_2:
      000B59                        712 	.ds 1
      000B5A                        713 _keycode_at_keymap_location_PARM_3:
      000B5A                        714 	.ds 1
      000B5B                        715 _keycode_at_keymap_location_layer_num_10000_437:
      000B5B                        716 	.ds 1
      000B5C                        717 _keycode_at_encodermap_location_PARM_2:
      000B5C                        718 	.ds 1
      000B5D                        719 _keycode_at_encodermap_location_PARM_3:
      000B5D                        720 	.ds 1
      000B5E                        721 _keycode_at_encodermap_location_layer_num_10000_441:
      000B5E                        722 	.ds 1
      000B5F                        723 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B5F                        724 	.ds 2
      000B61                        725 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B61                        726 	.ds 3
      000B64                        727 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B64                        728 	.ds 2
      000B66                        729 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B66                        730 	.ds 2
      000B68                        731 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B68                        732 	.ds 3
      000B6B                        733 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B6B                        734 	.ds 2
      000B6D                        735 _decode_keycode_kc_10000_455:
      000B6D                        736 	.ds 2
      000B6F                        737 _dynamic_keymap_macro_send_id_10000_458:
      000B6F                        738 	.ds 1
      000B70                        739 _dynamic_keymap_macro_send_sending_10000_459:
      000B70                        740 	.ds 1
      000B71                        741 _dynamic_keymap_macro_send_p_10001_464:
      000B71                        742 	.ds 3
      000B74                        743 _dynamic_keymap_macro_send_data_10003_471:
      000B74                        744 	.ds 4
                                    745 ;--------------------------------------------------------
                                    746 ; absolute external ram data
                                    747 ;--------------------------------------------------------
                                    748 	.area XABS    (ABS,XDATA)
                                    749 ;--------------------------------------------------------
                                    750 ; initialized external ram data
                                    751 ;--------------------------------------------------------
                                    752 	.area XISEG   (XDATA)
                                    753 	.area HOME    (CODE)
                                    754 	.area GSINIT0 (CODE)
                                    755 	.area GSINIT1 (CODE)
                                    756 	.area GSINIT2 (CODE)
                                    757 	.area GSINIT3 (CODE)
                                    758 	.area GSINIT4 (CODE)
                                    759 	.area GSINIT5 (CODE)
                                    760 	.area GSINIT  (CODE)
                                    761 	.area GSFINAL (CODE)
                                    762 	.area CSEG    (CODE)
                                    763 ;--------------------------------------------------------
                                    764 ; global & static initialisations
                                    765 ;--------------------------------------------------------
                                    766 	.area HOME    (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 	.area GSFINAL (CODE)
                                    769 	.area GSINIT  (CODE)
                                    770 ;--------------------------------------------------------
                                    771 ; Home
                                    772 ;--------------------------------------------------------
                                    773 	.area HOME    (CODE)
                                    774 	.area HOME    (CODE)
                                    775 ;--------------------------------------------------------
                                    776 ; code
                                    777 ;--------------------------------------------------------
                                    778 	.area CSEG    (CODE)
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    781 ;------------------------------------------------------------
                                    782 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    783 ;------------------------------------------------------------
                                    784 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    785 ;	-----------------------------------------
                           000007   786 	ar7 = 0x07
                           000006   787 	ar6 = 0x06
                           000005   788 	ar5 = 0x05
                           000004   789 	ar4 = 0x04
                           000003   790 	ar3 = 0x03
                           000002   791 	ar2 = 0x02
                           000001   792 	ar1 = 0x01
                           000000   793 	ar0 = 0x00
                                    794 ;	 function dynamic_keymap_get_layer_count
                                    795 ;	-----------------------------------------
      0088C6                        796 _dynamic_keymap_get_layer_count:
                                    797 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0088C6 75 82 06         [24]  798 	mov	dpl, #0x06
                                    799 ;	quantum/dynamic_keymap.c:179: }
      0088C9 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    803 ;------------------------------------------------------------
                                    804 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    805 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    806 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function dynamic_keymap_key_to_eeprom_address
                                    811 ;	-----------------------------------------
      0088CA                        812 _dynamic_keymap_key_to_eeprom_address:
      0088CA E5 82            [12]  813 	mov	a,dpl
      0088CC 90 0B 0C         [24]  814 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      0088CF F0               [24]  815 	movx	@dptr,a
                                    816 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0088D0 E0               [24]  817 	movx	a,@dptr
      0088D1 FF               [12]  818 	mov	r7,a
      0088D2 7E 00            [12]  819 	mov	r6,#0x00
      0088D4 74 40            [12]  820 	mov	a,#0x40
      0088D6 12 45 C9         [24]  821 	lcall	_ak820_outline_0135
      0088D9 7D 00            [12]  822 	mov	r5,#0x00
      0088DB 90 0B 0A         [24]  823 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0088DE E0               [24]  824 	movx	a,@dptr
      0088DF 75 F0 10         [24]  825 	mov	b,#0x10
      0088E2 A4               [48]  826 	mul	ab
      0088E3 2E               [12]  827 	add	a, r6
      0088E4 FE               [12]  828 	mov	r6,a
      0088E5 EF               [12]  829 	mov	a,r7
      0088E6 35 F0            [12]  830 	addc	a, b
      0088E8 FF               [12]  831 	mov	r7,a
      0088E9 90 0B 0B         [24]  832 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0088EC E0               [24]  833 	movx	a,@dptr
      0088ED 7C 00            [12]  834 	mov	r4,#0x00
      0088EF 25 E0            [12]  835 	add	a,acc
      0088F1 FB               [12]  836 	mov	r3,a
      0088F2 EC               [12]  837 	mov	a,r4
      0088F3 33               [12]  838 	rlc	a
      0088F4 FC               [12]  839 	mov	r4,a
      0088F5 EB               [12]  840 	mov	a,r3
      0088F6 2E               [12]  841 	add	a, r6
      0088F7 FE               [12]  842 	mov	r6,a
      0088F8 EC               [12]  843 	mov	a,r4
      0088F9 3F               [12]  844 	addc	a, r7
      0088FA FF               [12]  845 	mov	r7,a
      0088FB 12 74 79         [24]  846 	lcall	_ak820_outline_0050
                                    847 ;	quantum/dynamic_keymap.c:184: }
      0088FE 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    851 ;------------------------------------------------------------
                                    852 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    853 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    854 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    855 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    856 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    857 ;------------------------------------------------------------
                                    858 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    859 ;	-----------------------------------------
                                    860 ;	 function dynamic_keymap_get_keycode
                                    861 ;	-----------------------------------------
      0088FF                        862 _dynamic_keymap_get_keycode:
      0088FF E5 82            [12]  863 	mov	a,dpl
      008901 90 0B 0F         [24]  864 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      008904 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008905 E0               [24]  867 	movx	a,@dptr
      008906 FF               [12]  868 	mov	r7,a
      008907 BF 06 00         [24]  869 	cjne	r7,#0x06,00121$
      00890A                        870 00121$:
      00890A 50 14            [24]  871 	jnc	00101$
      00890C 90 0B 0D         [24]  872 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00890F E0               [24]  873 	movx	a,@dptr
      008910 FE               [12]  874 	mov	r6,a
      008911 BE 10 00         [24]  875 	cjne	r6,#0x10,00123$
      008914                        876 00123$:
      008914 50 0A            [24]  877 	jnc	00101$
      008916 90 0B 0E         [24]  878 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008919 E0               [24]  879 	movx	a,@dptr
      00891A FD               [12]  880 	mov	r5,a
      00891B BD 08 00         [24]  881 	cjne	r5,#0x08,00125$
      00891E                        882 00125$:
      00891E 40 04            [24]  883 	jc	00102$
      008920                        884 00101$:
      008920 90 00 00         [24]  885 	mov	dptr,#0x0000
      008923 22               [24]  886 	ret
      008924                        887 00102$:
                                    888 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008924 12 93 2C         [24]  889 	lcall	_ak820_outline_0100
      008927 11 CA            [12]  890 	acall	_dynamic_keymap_key_to_eeprom_address
                                    891 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008929 12 93 39         [24]  892 	lcall	_ak820_outline_0115
      00892C 12 42 E2         [24]  893 	lcall	_eeprom_read_byte
      00892F AB 82            [24]  894 	mov	r3,dpl
      008931 7C 00            [12]  895 	mov	r4,#0x00
                                    896 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008933 0D               [12]  897 	inc	r5
      008934 BD 00 01         [24]  898 	cjne	r5,#0x00,00127$
      008937 0E               [12]  899 	inc	r6
      008938                        900 00127$:
      008938 12 72 58         [24]  901 	lcall	_ak820_outline_0059
      00893B 12 42 E2         [24]  902 	lcall	_eeprom_read_byte
      00893E AF 82            [24]  903 	mov	r7, dpl
      008940 7E 00            [12]  904 	mov	r6,#0x00
      008942 EF               [12]  905 	mov	a,r7
      008943 42 04            [12]  906 	orl	ar4,a
      008945 EE               [12]  907 	mov	a,r6
      008946 42 03            [12]  908 	orl	ar3,a
                                    909 ;	quantum/dynamic_keymap.c:192: return keycode;
      008948 12 45 F7         [24]  910 	lcall	_ak820_outline_0189
                                    911 ;	quantum/dynamic_keymap.c:193: }
      00894B 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    915 ;------------------------------------------------------------
                                    916 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    917 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    918 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    919 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    920 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function dynamic_keymap_set_keycode
                                    925 ;	-----------------------------------------
      00894C                        926 _dynamic_keymap_set_keycode:
      00894C E5 82            [12]  927 	mov	a,dpl
      00894E 90 0B 14         [24]  928 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008951 F0               [24]  929 	movx	@dptr,a
                                    930 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008952 E0               [24]  931 	movx	a,@dptr
      008953 FF               [12]  932 	mov	r7,a
      008954 BF 06 00         [24]  933 	cjne	r7,#0x06,00121$
      008957                        934 00121$:
      008957 50 14            [24]  935 	jnc	00101$
      008959 90 0B 10         [24]  936 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00895C E0               [24]  937 	movx	a,@dptr
      00895D FE               [12]  938 	mov	r6,a
      00895E BE 10 00         [24]  939 	cjne	r6,#0x10,00123$
      008961                        940 00123$:
      008961 50 0A            [24]  941 	jnc	00101$
      008963 90 0B 11         [24]  942 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008966 E0               [24]  943 	movx	a,@dptr
      008967 FD               [12]  944 	mov	r5,a
      008968 BD 08 00         [24]  945 	cjne	r5,#0x08,00125$
      00896B                        946 00125$:
      00896B 40 01            [24]  947 	jc	00102$
      00896D                        948 00101$:
      00896D 22               [24]  949 	ret
      00896E                        950 00102$:
                                    951 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00896E 12 93 2C         [24]  952 	lcall	_ak820_outline_0100
      008971 11 CA            [12]  953 	acall	_dynamic_keymap_key_to_eeprom_address
      008973 12 93 39         [24]  954 	lcall	_ak820_outline_0115
                                    955 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008976 90 0B 12         [24]  956 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008979 E0               [24]  957 	movx	a,@dptr
      00897A FB               [12]  958 	mov	r3,a
      00897B A3               [24]  959 	inc	dptr
      00897C E0               [24]  960 	movx	a,@dptr
      00897D 90 06 AE         [24]  961 	mov	dptr,#_eeprom_update_byte_PARM_2
      008980 12 51 85         [24]  962 	lcall	_ak820_outline_0034
      008983 12 50 6F         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008986 0D               [12]  965 	inc	r5
      008987 BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      00898A 0E               [12]  967 	inc	r6
      00898B                        968 00127$:
      00898B 90 06 AE         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      00898E EB               [12]  970 	mov	a,r3
      00898F 12 51 85         [24]  971 	lcall	_ak820_outline_0034
                                    972 ;	quantum/dynamic_keymap.c:201: }
      008992 02 50 6F         [24]  973 	ljmp	_eeprom_update_byte
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    976 ;------------------------------------------------------------
                                    977 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    978 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    979 ;------------------------------------------------------------
                                    980 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    981 ;	-----------------------------------------
                                    982 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    983 ;	-----------------------------------------
      008995                        984 _dynamic_keymap_encoder_to_eeprom_address:
      008995 E5 82            [12]  985 	mov	a,dpl
      008997 90 0B 16         [24]  986 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      00899A F0               [24]  987 	movx	@dptr,a
                                    988 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00899B E0               [24]  989 	movx	a,@dptr
      00899C 75 F0 04         [24]  990 	mov	b,#0x04
      00899F A4               [48]  991 	mul	ab
      0089A0 24 40            [12]  992 	add	a, #0x40
      0089A2 FD               [12]  993 	mov	r5,a
      0089A3 74 06            [12]  994 	mov	a,#0x06
      0089A5 35 F0            [12]  995 	addc	a, b
      0089A7 FE               [12]  996 	mov	r6,a
      0089A8 7F 00            [12]  997 	mov	r7,#0x00
      0089AA 90 0B 15         [24]  998 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089AD E0               [24]  999 	movx	a,@dptr
      0089AE 75 F0 04         [24] 1000 	mov	b,#0x04
      0089B1 A4               [48] 1001 	mul	ab
      0089B2 2D               [12] 1002 	add	a, r5
      0089B3 FD               [12] 1003 	mov	r5,a
      0089B4 EE               [12] 1004 	mov	a,r6
      0089B5 35 F0            [12] 1005 	addc	a, b
      0089B7 FE               [12] 1006 	mov	r6,a
      0089B8 12 72 58         [24] 1007 	lcall	_ak820_outline_0059
                                   1008 ;	quantum/dynamic_keymap.c:206: }
      0089BB 22               [24] 1009 	ret
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1012 ;------------------------------------------------------------
                                   1013 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1014 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1015 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1016 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1017 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function dynamic_keymap_get_encoder
                                   1022 ;	-----------------------------------------
      0089BC                       1023 _dynamic_keymap_get_encoder:
      0089BC E5 82            [12] 1024 	mov	a,dpl
      0089BE 90 0B 19         [24] 1025 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      0089C1 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0089C2 E0               [24] 1028 	movx	a,@dptr
      0089C3 FF               [12] 1029 	mov	r7,a
      0089C4 BF 06 00         [24] 1030 	cjne	r7,#0x06,00131$
      0089C7                       1031 00131$:
      0089C7 50 0A            [24] 1032 	jnc	00101$
      0089C9 90 0B 17         [24] 1033 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0089CC E0               [24] 1034 	movx	a,@dptr
      0089CD FE               [12] 1035 	mov	r6,a
      0089CE BE 01 00         [24] 1036 	cjne	r6,#0x01,00133$
      0089D1                       1037 00133$:
      0089D1 40 04            [24] 1038 	jc	00102$
      0089D3                       1039 00101$:
      0089D3 90 00 00         [24] 1040 	mov	dptr,#0x0000
      0089D6 22               [24] 1041 	ret
      0089D7                       1042 00102$:
                                   1043 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0089D7 90 0B 15         [24] 1044 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089DA 12 7C A7         [24] 1045 	lcall	_ak820_outline_0187
      0089DD 31 95            [12] 1046 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0089DF 12 93 39         [24] 1047 	lcall	_ak820_outline_0115
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0089E2 90 0B 18         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0089E5 E0               [24] 1050 	movx	a,@dptr
      0089E6 FC               [12] 1051 	mov	r4,a
      0089E7 E0               [24] 1052 	movx	a,@dptr
      0089E8 60 04            [24] 1053 	jz	00106$
      0089EA 7B 00            [12] 1054 	mov	r3,#0x00
      0089EC 80 02            [24] 1055 	sjmp	00107$
      0089EE                       1056 00106$:
      0089EE 7B 02            [12] 1057 	mov	r3,#0x02
      0089F0                       1058 00107$:
      0089F0 EB               [12] 1059 	mov	a,r3
      0089F1 12 7C 20         [24] 1060 	lcall	_ak820_outline_0013
      0089F4 12 42 E2         [24] 1061 	lcall	_eeprom_read_byte
      0089F7 AA 82            [24] 1062 	mov	r2,dpl
      0089F9 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0089FB EC               [12] 1065 	mov	a,r4
      0089FC 60 04            [24] 1066 	jz	00108$
      0089FE 7C 00            [12] 1067 	mov	r4,#0x00
      008A00 80 02            [24] 1068 	sjmp	00109$
      008A02                       1069 00108$:
      008A02 7C 02            [12] 1070 	mov	r4,#0x02
      008A04                       1071 00109$:
      008A04 EC               [12] 1072 	mov	a,r4
      008A05 12 3B 29         [24] 1073 	lcall	_ak820_outline_0163
      008A08 0D               [12] 1074 	inc	r5
      008A09 BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      008A0C 0E               [12] 1076 	inc	r6
      008A0D                       1077 00137$:
      008A0D 12 72 58         [24] 1078 	lcall	_ak820_outline_0059
      008A10 12 42 E2         [24] 1079 	lcall	_eeprom_read_byte
      008A13 AF 82            [24] 1080 	mov	r7, dpl
      008A15 7E 00            [12] 1081 	mov	r6,#0x00
      008A17 EF               [12] 1082 	mov	a,r7
      008A18 42 03            [12] 1083 	orl	ar3,a
      008A1A EE               [12] 1084 	mov	a,r6
      008A1B 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      008A1D 8B 82            [24] 1087 	mov	dpl, r3
      008A1F 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      008A21 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      008A22                       1105 _dynamic_keymap_set_encoder:
      008A22 E5 82            [12] 1106 	mov	a,dpl
      008A24 90 0B 1E         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      008A27 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008A28 E0               [24] 1110 	movx	a,@dptr
      008A29 FF               [12] 1111 	mov	r7,a
      008A2A BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      008A2D                       1113 00131$:
      008A2D 50 0A            [24] 1114 	jnc	00101$
      008A2F 90 0B 1A         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008A32 E0               [24] 1116 	movx	a,@dptr
      008A33 FE               [12] 1117 	mov	r6,a
      008A34 BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      008A37                       1119 00133$:
      008A37 40 01            [24] 1120 	jc	00102$
      008A39                       1121 00101$:
      008A39 22               [24] 1122 	ret
      008A3A                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008A3A 90 0B 15         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A3D 12 7C A7         [24] 1126 	lcall	_ak820_outline_0187
      008A40 31 95            [12] 1127 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008A42 12 93 39         [24] 1128 	lcall	_ak820_outline_0115
                                   1129 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008A45 90 0B 1B         [24] 1130 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008A48 E0               [24] 1131 	movx	a,@dptr
      008A49 FC               [12] 1132 	mov	r4,a
      008A4A E0               [24] 1133 	movx	a,@dptr
      008A4B 60 04            [24] 1134 	jz	00106$
      008A4D 7B 00            [12] 1135 	mov	r3,#0x00
      008A4F 80 02            [24] 1136 	sjmp	00107$
      008A51                       1137 00106$:
      008A51 7B 02            [12] 1138 	mov	r3,#0x02
      008A53                       1139 00107$:
      008A53 EB               [12] 1140 	mov	a,r3
      008A54 12 93 4B         [24] 1141 	lcall	_ak820_outline_0134
      008A57 8F 03            [24] 1142 	mov	ar3,r7
      008A59 90 0B 1C         [24] 1143 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A5C E0               [24] 1144 	movx	a,@dptr
      008A5D F5 29            [12] 1145 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008A5F A3               [24] 1146 	inc	dptr
      008A60 E0               [24] 1147 	movx	a,@dptr
      008A61 F5 2A            [12] 1148 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008A63 90 06 AE         [24] 1149 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A66 F0               [24] 1150 	movx	@dptr,a
      008A67 12 93 51         [24] 1151 	lcall	_ak820_outline_0155
      008A6A 12 50 6F         [24] 1152 	lcall	_eeprom_update_byte
                                   1153 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008A6D EC               [12] 1154 	mov	a,r4
      008A6E 60 04            [24] 1155 	jz	00108$
      008A70 7C 00            [12] 1156 	mov	r4,#0x00
      008A72 80 02            [24] 1157 	sjmp	00109$
      008A74                       1158 00108$:
      008A74 7C 02            [12] 1159 	mov	r4,#0x02
      008A76                       1160 00109$:
      008A76 EC               [12] 1161 	mov	a,r4
      008A77 12 3B 29         [24] 1162 	lcall	_ak820_outline_0163
      008A7A 0D               [12] 1163 	inc	r5
      008A7B BD 00 01         [24] 1164 	cjne	r5,#0x00,00137$
      008A7E 0E               [12] 1165 	inc	r6
      008A7F                       1166 00137$:
      008A7F 90 06 AE         [24] 1167 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A82 E5 29            [12] 1168 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008A84 12 51 85         [24] 1169 	lcall	_ak820_outline_0034
                                   1170 ;	quantum/dynamic_keymap.c:223: }
      008A87 02 50 6F         [24] 1171 	ljmp	_eeprom_update_byte
                                   1172 ;------------------------------------------------------------
                                   1173 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1174 ;------------------------------------------------------------
                                   1175 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1176 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1177 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1178 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1179 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1180 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1181 ;------------------------------------------------------------
                                   1182 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1183 ;	-----------------------------------------
                                   1184 ;	 function dynamic_keymap_get_combo
                                   1185 ;	-----------------------------------------
      008A8A                       1186 _dynamic_keymap_get_combo:
      008A8A E5 82            [12] 1187 	mov	a,dpl
      008A8C 90 0B 22         [24] 1188 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008A8F F0               [24] 1189 	movx	@dptr,a
                                   1190 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A90 90 0B 1F         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008A93 12 3A AF         [24] 1192 	lcall	_ak820_outline_0052
                                   1193 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008A96 90 0B 22         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008A99 E0               [24] 1195 	movx	a,@dptr
      008A9A FD               [12] 1196 	mov	r5,a
      008A9B BD 08 00         [24] 1197 	cjne	r5,#0x08,00132$
      008A9E                       1198 00132$:
      008A9E 40 04            [24] 1199 	jc	00102$
                                   1200 ;	quantum/dynamic_keymap.c:275: return -1;
      008AA0 90 FF FF         [24] 1201 	mov	dptr,#0xffff
      008AA3 22               [24] 1202 	ret
      008AA4                       1203 00102$:
                                   1204 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AA4 12 93 18         [24] 1205 	lcall	_ak820_outline_0082
                                   1206 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008AA7 8E 02            [24] 1207 	mov	ar2,r6
      008AA9 8F 03            [24] 1208 	mov	ar3,r7
      008AAB 90 05 95         [24] 1209 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008AAE EC               [12] 1210 	mov	a,r4
      008AAF F0               [24] 1211 	movx	@dptr,a
      008AB0 ED               [12] 1212 	mov	a,r5
      008AB1 12 3A CC         [24] 1213 	lcall	_ak820_outline_0072
      008AB4 90 05 98         [24] 1214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008AB7 12 93 11         [24] 1215 	lcall	_ak820_outline_0075
      008ABA 12 3B 1A         [24] 1216 	lcall	_ak820_outline_0144
      008ABD C0 07            [24] 1217 	push	ar7
      008ABF C0 06            [24] 1218 	push	ar6
      008AC1 12 43 1D         [24] 1219 	lcall	_ak820_eeprom_read_block_xdata
      008AC4 D0 06            [24] 1220 	pop	ar6
      008AC6 D0 07            [24] 1221 	pop	ar7
                                   1222 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008AC8 74 04            [12] 1223 	mov	a,#0x04
      008ACA 12 4A D7         [24] 1224 	lcall	_ak820_outline_0033
      008ACD FA               [12] 1225 	mov	r2,a
      008ACE A3               [24] 1226 	inc	dptr
      008ACF E0               [24] 1227 	movx	a,@dptr
      008AD0 FB               [12] 1228 	mov	r3,a
      008AD1 BA 20 13         [24] 1229 	cjne	r2,#0x20,00108$
      008AD4 BB 08 10         [24] 1230 	cjne	r3,#0x08,00108$
      008AD7 74 06            [12] 1231 	mov	a,#0x06
      008AD9 12 3A 9F         [24] 1232 	lcall	_ak820_outline_0022
      008ADC 12 45 AC         [24] 1233 	lcall	_ak820_outline_0086
      008ADF BA 01 05         [24] 1234 	cjne	r2,#0x01,00136$
      008AE2 BB 00 02         [24] 1235 	cjne	r3,#0x00,00136$
      008AE5 80 05            [24] 1236 	sjmp	00109$
      008AE7                       1237 00136$:
      008AE7                       1238 00108$:
      008AE7 75 2B 00         [24] 1239 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008AEA 80 03            [24] 1240 	sjmp	00110$
      008AEC                       1241 00109$:
      008AEC 75 2B 01         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008AEF                       1243 00110$:
                                   1244 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008AEF 74 06            [12] 1245 	mov	a,#0x06
      008AF1 12 3A 9F         [24] 1246 	lcall	_ak820_outline_0022
      008AF4 E4               [12] 1247 	clr	a
      008AF5 F0               [24] 1248 	movx	@dptr,a
      008AF6 A3               [24] 1249 	inc	dptr
      008AF7 12 3A E4         [24] 1250 	lcall	_ak820_outline_0096
      008AFA F0               [24] 1251 	movx	@dptr,a
      008AFB A3               [24] 1252 	inc	dptr
      008AFC F0               [24] 1253 	movx	@dptr,a
                                   1254 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008AFD E5 2B            [12] 1255 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008AFF 60 12            [24] 1256 	jz	00103$
      008B01 12 3A FA         [24] 1257 	lcall	_ak820_outline_0118
      008B04 C0 07            [24] 1258 	push	ar7
      008B06 C0 06            [24] 1259 	push	ar6
      008B08 12 37 49         [24] 1260 	lcall	_ak820_combo_valid
      008B0B E5 82            [12] 1261 	mov	a, dpl
      008B0D D0 06            [24] 1262 	pop	ar6
      008B0F D0 07            [24] 1263 	pop	ar7
      008B11 70 13            [24] 1264 	jnz	00104$
      008B13                       1265 00103$:
      008B13 7D 00            [12] 1266 	mov	r5,#0x00
      008B15 90 0D DB         [24] 1267 	mov	dptr,#_memset_PARM_2
      008B18 E4               [12] 1268 	clr	a
      008B19 F0               [24] 1269 	movx	@dptr,a
      008B1A 90 0D DC         [24] 1270 	mov	dptr,#_memset_PARM_3
      008B1D 12 93 11         [24] 1271 	lcall	_ak820_outline_0075
      008B20 12 74 79         [24] 1272 	lcall	_ak820_outline_0050
      008B23 12 BC EC         [24] 1273 	lcall	_memset
      008B26                       1274 00104$:
                                   1275 ;	quantum/dynamic_keymap.c:289: return 0;
      008B26 90 00 00         [24] 1276 	mov	dptr,#0x0000
                                   1277 ;	quantum/dynamic_keymap.c:290: }
      008B29 22               [24] 1278 	ret
                                   1279 ;------------------------------------------------------------
                                   1280 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1281 ;------------------------------------------------------------
                                   1282 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1283 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1284 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1285 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1286 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1287 ;------------------------------------------------------------
                                   1288 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1289 ;	-----------------------------------------
                                   1290 ;	 function dynamic_keymap_set_combo
                                   1291 ;	-----------------------------------------
      008B2A                       1292 _dynamic_keymap_set_combo:
      008B2A E5 82            [12] 1293 	mov	a,dpl
      008B2C 90 0B 26         [24] 1294 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008B2F F0               [24] 1295 	movx	@dptr,a
                                   1296 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B30 90 0B 23         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B33 12 3A 62         [24] 1298 	lcall	_ak820_outline_0005
                                   1299 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B36 C0 07            [24] 1300 	push	ar7
      008B38 C0 06            [24] 1301 	push	ar6
      008B3A 12 37 49         [24] 1302 	lcall	_ak820_combo_valid
      008B3D E5 82            [12] 1303 	mov	a, dpl
      008B3F D0 06            [24] 1304 	pop	ar6
      008B41 D0 07            [24] 1305 	pop	ar7
      008B43 60 07            [24] 1306 	jz	00101$
      008B45 12 40 88         [24] 1307 	lcall	_ak820_nvm_ok
      008B48 E5 82            [12] 1308 	mov	a, dpl
      008B4A 70 04            [24] 1309 	jnz	00102$
      008B4C                       1310 00101$:
      008B4C 90 FF FF         [24] 1311 	mov	dptr,#0xffff
      008B4F 22               [24] 1312 	ret
      008B50                       1313 00102$:
                                   1314 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008B50 90 0B 26         [24] 1315 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008B53 E0               [24] 1316 	movx	a,@dptr
      008B54 FD               [12] 1317 	mov	r5,a
      008B55 BD 08 00         [24] 1318 	cjne	r5,#0x08,00133$
      008B58                       1319 00133$:
      008B58 40 04            [24] 1320 	jc	00105$
                                   1321 ;	quantum/dynamic_keymap.c:302: return -1;
      008B5A 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      008B5D 22               [24] 1323 	ret
      008B5E                       1324 00105$:
                                   1325 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B5E 12 93 18         [24] 1326 	lcall	_ak820_outline_0082
                                   1327 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008B61 C0 07            [24] 1328 	push	ar7
      008B63 C0 06            [24] 1329 	push	ar6
      008B65 C0 05            [24] 1330 	push	ar5
      008B67 C0 04            [24] 1331 	push	ar4
      008B69 12 7B D2         [24] 1332 	lcall	_clear_keyboard
      008B6C D0 04            [24] 1333 	pop	ar4
      008B6E D0 05            [24] 1334 	pop	ar5
      008B70 D0 06            [24] 1335 	pop	ar6
      008B72 D0 07            [24] 1336 	pop	ar7
                                   1337 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008B74 90 0D D3         [24] 1338 	mov	dptr,#___memcpy_PARM_2
      008B77 12 4A EA         [24] 1339 	lcall	_ak820_outline_0060
      008B7A E4               [12] 1340 	clr	a
      008B7B A3               [24] 1341 	inc	dptr
      008B7C F0               [24] 1342 	movx	@dptr,a
      008B7D 90 0D D6         [24] 1343 	mov	dptr,#___memcpy_PARM_3
      008B80 12 93 11         [24] 1344 	lcall	_ak820_outline_0075
      008B83 90 0B 27         [24] 1345 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008B86 F5 F0            [12] 1346 	mov	b,a
      008B88 C0 05            [24] 1347 	push	ar5
      008B8A C0 04            [24] 1348 	push	ar4
      008B8C 12 BC 76         [24] 1349 	lcall	___memcpy
      008B8F D0 04            [24] 1350 	pop	ar4
      008B91 D0 05            [24] 1351 	pop	ar5
                                   1352 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008B93 90 0B 2B         [24] 1353 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      008B96 74 20            [12] 1354 	mov	a,#0x20
      008B98 F0               [24] 1355 	movx	@dptr,a
      008B99 74 08            [12] 1356 	mov	a,#0x08
      008B9B A3               [24] 1357 	inc	dptr
      008B9C F0               [24] 1358 	movx	@dptr,a
                                   1359 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008B9D 90 0B 2D         [24] 1360 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008BA0 74 01            [12] 1361 	mov	a,#0x01
      008BA2 12 3B 04         [24] 1362 	lcall	_ak820_outline_0124
                                   1363 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008BA5 90 05 9E         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008BA8 EC               [12] 1365 	mov	a,r4
      008BA9 F0               [24] 1366 	movx	@dptr,a
      008BAA ED               [12] 1367 	mov	a,r5
      008BAB 12 3A CC         [24] 1368 	lcall	_ak820_outline_0072
      008BAE 90 05 A1         [24] 1369 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008BB1 12 93 11         [24] 1370 	lcall	_ak820_outline_0075
      008BB4 90 0B 27         [24] 1371 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      008BB7 12 43 A3         [24] 1372 	lcall	_ak820_eeprom_write_block_xdata
                                   1373 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008BBA 12 40 97         [24] 1374 	lcall	_ak820_nvm_flush
                                   1375 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008BBD 12 40 88         [24] 1376 	lcall	_ak820_nvm_ok
      008BC0 E5 82            [12] 1377 	mov	a, dpl
      008BC2 70 04            [24] 1378 	jnz	00107$
      008BC4 90 FF FF         [24] 1379 	mov	dptr,#0xffff
      008BC7 22               [24] 1380 	ret
      008BC8                       1381 00107$:
                                   1382 ;	quantum/dynamic_keymap.c:320: return 0;
      008BC8 90 00 00         [24] 1383 	mov	dptr,#0x0000
                                   1384 ;	quantum/dynamic_keymap.c:321: }
      008BCB 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1388 ;------------------------------------------------------------
                                   1389 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1390 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1391 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1392 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1393 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1394 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1395 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1396 ;------------------------------------------------------------
                                   1397 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1398 ;	-----------------------------------------
                                   1399 ;	 function dynamic_keymap_reset
                                   1400 ;	-----------------------------------------
      008BCC                       1401 _dynamic_keymap_reset:
                                   1402 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008BCC 90 0E 54         [24] 1403 	mov	dptr,#_vial_unlocked
      008BCF E0               [24] 1404 	movx	a,@dptr
      008BD0 90 0B 31         [24] 1405 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008BD3 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008BD4 90 0E 54         [24] 1408 	mov	dptr,#_vial_unlocked
      008BD7 74 01            [12] 1409 	mov	a,#0x01
      008BD9 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BDA 7F 00            [12] 1412 	mov	r7,#0x00
      008BDC                       1413 00116$:
      008BDC BF 06 00         [24] 1414 	cjne	r7,#0x06,00198$
      008BDF                       1415 00198$:
      008BDF 40 02            [24] 1416 	jc	00199$
      008BE1 81 8A            [12] 1417 	ajmp	00104$
      008BE3                       1418 00199$:
                                   1419 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008BE3 7E 00            [12] 1420 	mov	r6,#0x00
      008BE5                       1421 00110$:
      008BE5 BE 10 00         [24] 1422 	cjne	r6,#0x10,00200$
      008BE8                       1423 00200$:
      008BE8 50 4C            [24] 1424 	jnc	00102$
                                   1425 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008BEA 7D 00            [12] 1426 	mov	r5,#0x00
      008BEC                       1427 00107$:
      008BEC BD 08 00         [24] 1428 	cjne	r5,#0x08,00202$
      008BEF                       1429 00202$:
      008BEF 50 42            [24] 1430 	jnc	00111$
                                   1431 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008BF1 90 0B CE         [24] 1432 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008BF4 EE               [12] 1433 	mov	a,r6
      008BF5 F0               [24] 1434 	movx	@dptr,a
      008BF6 90 0B CF         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008BF9 ED               [12] 1436 	mov	a,r5
      008BFA F0               [24] 1437 	movx	@dptr,a
      008BFB 8F 82            [24] 1438 	mov	dpl, r7
      008BFD C0 07            [24] 1439 	push	ar7
      008BFF C0 06            [24] 1440 	push	ar6
      008C01 C0 05            [24] 1441 	push	ar5
      008C03 12 9B 59         [24] 1442 	lcall	_keycode_at_keymap_location_raw
      008C06 AB 82            [24] 1443 	mov	r3, dpl
      008C08 AC 83            [24] 1444 	mov	r4, dph
      008C0A D0 05            [24] 1445 	pop	ar5
      008C0C D0 06            [24] 1446 	pop	ar6
      008C0E D0 07            [24] 1447 	pop	ar7
      008C10 90 0B 10         [24] 1448 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C13 EE               [12] 1449 	mov	a,r6
      008C14 F0               [24] 1450 	movx	@dptr,a
      008C15 90 0B 11         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C18 ED               [12] 1452 	mov	a,r5
      008C19 F0               [24] 1453 	movx	@dptr,a
      008C1A 90 0B 12         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C1D 12 3A DE         [24] 1455 	lcall	_ak820_outline_0093
      008C20 8F 82            [24] 1456 	mov	dpl, r7
      008C22 C0 07            [24] 1457 	push	ar7
      008C24 C0 06            [24] 1458 	push	ar6
      008C26 C0 05            [24] 1459 	push	ar5
      008C28 31 4C            [12] 1460 	acall	_dynamic_keymap_set_keycode
      008C2A D0 05            [24] 1461 	pop	ar5
      008C2C D0 06            [24] 1462 	pop	ar6
      008C2E D0 07            [24] 1463 	pop	ar7
                                   1464 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C30 0D               [12] 1465 	inc	r5
      008C31 80 B9            [24] 1466 	sjmp	00107$
      008C33                       1467 00111$:
                                   1468 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C33 0E               [12] 1469 	inc	r6
      008C34 80 AF            [24] 1470 	sjmp	00110$
      008C36                       1471 00102$:
                                   1472 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C36 7E 00            [12] 1473 	mov	r6,#0x00
      008C38                       1474 00113$:
      008C38 BE 01 00         [24] 1475 	cjne	r6,#0x01,00204$
      008C3B                       1476 00204$:
      008C3B 50 4A            [24] 1477 	jnc	00117$
                                   1478 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008C3D 12 93 6E         [24] 1479 	lcall	_ak820_outline_0178
      008C40 04               [12] 1480 	inc	a
      008C41 F0               [24] 1481 	movx	@dptr,a
      008C42 8F 82            [24] 1482 	mov	dpl, r7
      008C44 C0 07            [24] 1483 	push	ar7
      008C46 12 9B 9E         [24] 1484 	lcall	_keycode_at_encodermap_location_raw
      008C49 12 45 D5         [24] 1485 	lcall	_ak820_outline_0151
      008C4C D0 07            [24] 1486 	pop	ar7
      008C4E 12 93 65         [24] 1487 	lcall	_ak820_outline_0177
      008C51 04               [12] 1488 	inc	a
      008C52 F0               [24] 1489 	movx	@dptr,a
      008C53 90 0B 1C         [24] 1490 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C56 12 3A D2         [24] 1491 	lcall	_ak820_outline_0074
      008C59 8F 82            [24] 1492 	mov	dpl, r7
      008C5B C0 07            [24] 1493 	push	ar7
      008C5D 51 22            [24] 1494 	acall	_dynamic_keymap_set_encoder
      008C5F D0 07            [24] 1495 	pop	ar7
                                   1496 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008C61 12 93 6E         [24] 1497 	lcall	_ak820_outline_0178
      008C64 F0               [24] 1498 	movx	@dptr,a
      008C65 8F 82            [24] 1499 	mov	dpl, r7
      008C67 C0 07            [24] 1500 	push	ar7
      008C69 12 9B 9E         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      008C6C 12 45 D5         [24] 1502 	lcall	_ak820_outline_0151
      008C6F D0 07            [24] 1503 	pop	ar7
      008C71 12 93 65         [24] 1504 	lcall	_ak820_outline_0177
      008C74 F0               [24] 1505 	movx	@dptr,a
      008C75 90 0B 1C         [24] 1506 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C78 12 3A D2         [24] 1507 	lcall	_ak820_outline_0074
      008C7B 8F 82            [24] 1508 	mov	dpl, r7
      008C7D C0 07            [24] 1509 	push	ar7
      008C7F 51 22            [24] 1510 	acall	_dynamic_keymap_set_encoder
      008C81 D0 07            [24] 1511 	pop	ar7
                                   1512 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C83 7E 01            [12] 1513 	mov	r6,#0x01
      008C85 80 B1            [24] 1514 	sjmp	00113$
      008C87                       1515 00117$:
                                   1516 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C87 0F               [12] 1517 	inc	r7
      008C88 61 DC            [12] 1518 	ajmp	00116$
      008C8A                       1519 00104$:
                                   1520 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008C8A 90 0B 32         [24] 1521 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008C8D 12 51 C6         [24] 1522 	lcall	_ak820_outline_0182
      008C90 90 0B 34         [24] 1523 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      008C93 F0               [24] 1524 	movx	@dptr,a
      008C94 A3               [24] 1525 	inc	dptr
      008C95 F0               [24] 1526 	movx	@dptr,a
      008C96 90 0B 36         [24] 1527 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008C99 F0               [24] 1528 	movx	@dptr,a
      008C9A A3               [24] 1529 	inc	dptr
      008C9B F0               [24] 1530 	movx	@dptr,a
      008C9C 90 0B 38         [24] 1531 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      008C9F F0               [24] 1532 	movx	@dptr,a
      008CA0 A3               [24] 1533 	inc	dptr
      008CA1 F0               [24] 1534 	movx	@dptr,a
      008CA2 90 0B 3A         [24] 1535 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008CA5 F0               [24] 1536 	movx	@dptr,a
      008CA6 A3               [24] 1537 	inc	dptr
      008CA7 F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CA8 FF               [12] 1540 	mov	r7,a
      008CA9                       1541 00119$:
      008CA9 BF 08 00         [24] 1542 	cjne	r7,#0x08,00206$
      008CAC                       1543 00206$:
      008CAC 50 18            [24] 1544 	jnc	00105$
                                   1545 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008CAE 8F 06            [24] 1546 	mov	ar6,r7
      008CB0 90 0B 23         [24] 1547 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008CB3 74 32            [12] 1548 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008CB5 F0               [24] 1549 	movx	@dptr,a
      008CB6 74 0B            [12] 1550 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008CB8 12 3A CC         [24] 1551 	lcall	_ak820_outline_0072
      008CBB 8E 82            [24] 1552 	mov	dpl, r6
      008CBD C0 07            [24] 1553 	push	ar7
      008CBF 71 2A            [24] 1554 	acall	_dynamic_keymap_set_combo
      008CC1 D0 07            [24] 1555 	pop	ar7
                                   1556 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CC3 0F               [12] 1557 	inc	r7
      008CC4 80 E3            [24] 1558 	sjmp	00119$
      008CC6                       1559 00105$:
                                   1560 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008CC6 90 0B 31         [24] 1561 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008CC9 E0               [24] 1562 	movx	a,@dptr
      008CCA 90 0E 54         [24] 1563 	mov	dptr,#_vial_unlocked
      008CCD F0               [24] 1564 	movx	@dptr,a
                                   1565 ;	quantum/dynamic_keymap.c:405: }
      008CCE 22               [24] 1566 	ret
                                   1567 ;------------------------------------------------------------
                                   1568 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1569 ;------------------------------------------------------------
                                   1570 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1571 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1572 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1573 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1574 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1575 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1576 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1577 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1578 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1579 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1580 ;------------------------------------------------------------
                                   1581 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1582 ;	-----------------------------------------
                                   1583 ;	 function ak820_dynamic_read_buffer
                                   1584 ;	-----------------------------------------
      008CCF                       1585 _ak820_dynamic_read_buffer:
      008CCF 12 3A F0         [24] 1586 	lcall	_ak820_outline_0107
      008CD2 90 0B 45         [24] 1587 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008CD5 12 3A F5         [24] 1588 	lcall	_ak820_outline_0108
                                   1589 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008CD8 90 0B 42         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008CDB 12 3A AF         [24] 1591 	lcall	_ak820_outline_0052
                                   1592 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008CDE 90 0B 47         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008CE1 E4               [12] 1594 	clr	a
      008CE2 F0               [24] 1595 	movx	@dptr,a
                                   1596 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008CE3 90 0B 40         [24] 1597 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008CE6 12 3A C6         [24] 1598 	lcall	_ak820_outline_0061
      008CE9 8C 02            [24] 1599 	mov	ar2,r4
      008CEB 8D 03            [24] 1600 	mov	ar3,r5
      008CED C3               [12] 1601 	clr	c
      008CEE 74 1C            [12] 1602 	mov	a,#0x1c
      008CF0 9A               [12] 1603 	subb	a,r2
      008CF1 E4               [12] 1604 	clr	a
      008CF2 9B               [12] 1605 	subb	a,r3
      008CF3 50 01            [24] 1606 	jnc	00102$
                                   1607 ;	free result
      008CF5 22               [24] 1608 	ret
      008CF6                       1609 00102$:
                                   1610 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008CF6 90 0B 3E         [24] 1611 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CF9 12 45 AC         [24] 1612 	lcall	_ak820_outline_0086
      008CFC 90 0B 3C         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CFF 12 3A EA         [24] 1614 	lcall	_ak820_outline_0101
      008D02 C3               [12] 1615 	clr	c
      008D03 EA               [12] 1616 	mov	a,r2
      008D04 98               [12] 1617 	subb	a,r0
      008D05 EB               [12] 1618 	mov	a,r3
      008D06 99               [12] 1619 	subb	a,r1
      008D07 50 17            [24] 1620 	jnc	00104$
                                   1621 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008D09 E8               [12] 1622 	mov	a,r0
      008D0A C3               [12] 1623 	clr	c
      008D0B 9A               [12] 1624 	subb	a,r2
      008D0C F8               [12] 1625 	mov	r0,a
      008D0D E9               [12] 1626 	mov	a,r1
      008D0E 9B               [12] 1627 	subb	a,r3
      008D0F F9               [12] 1628 	mov	r1,a
                                   1629 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008D10 C3               [12] 1630 	clr	c
      008D11 E8               [12] 1631 	mov	a,r0
      008D12 9C               [12] 1632 	subb	a,r4
      008D13 E9               [12] 1633 	mov	a,r1
      008D14 9D               [12] 1634 	subb	a,r5
      008D15 40 04            [24] 1635 	jc	00114$
      008D17 8C 00            [24] 1636 	mov	ar0,r4
      008D19 8D 01            [24] 1637 	mov	ar1,r5
      008D1B                       1638 00114$:
      008D1B 90 0B 47         [24] 1639 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008D1E E8               [12] 1640 	mov	a,r0
      008D1F F0               [24] 1641 	movx	@dptr,a
      008D20                       1642 00104$:
                                   1643 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D20 90 0B 47         [24] 1644 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008D23 E0               [24] 1645 	movx	a,@dptr
      008D24 F5 2C            [12] 1646 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008D26 E0               [24] 1647 	movx	a,@dptr
      008D27 60 42            [24] 1648 	jz	00106$
      008D29 C0 04            [24] 1649 	push	ar4
      008D2B C0 05            [24] 1650 	push	ar5
      008D2D 8E 00            [24] 1651 	mov	ar0,r6
      008D2F 8F 05            [24] 1652 	mov	ar5,r7
      008D31 90 0B 45         [24] 1653 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008D34 E0               [24] 1654 	movx	a,@dptr
      008D35 F9               [12] 1655 	mov	r1,a
      008D36 A3               [24] 1656 	inc	dptr
      008D37 E0               [24] 1657 	movx	a,@dptr
      008D38 FC               [12] 1658 	mov	r4,a
      008D39 EA               [12] 1659 	mov	a,r2
      008D3A 29               [12] 1660 	add	a, r1
      008D3B FA               [12] 1661 	mov	r2,a
      008D3C EB               [12] 1662 	mov	a,r3
      008D3D 3C               [12] 1663 	addc	a, r4
      008D3E FB               [12] 1664 	mov	r3,a
      008D3F 90 05 95         [24] 1665 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008D42 EA               [12] 1666 	mov	a,r2
      008D43 F0               [24] 1667 	movx	@dptr,a
      008D44 EB               [12] 1668 	mov	a,r3
      008D45 12 3A CC         [24] 1669 	lcall	_ak820_outline_0072
      008D48 90 05 98         [24] 1670 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008D4B E5 2C            [12] 1671 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008D4D 12 3B 04         [24] 1672 	lcall	_ak820_outline_0124
      008D50 88 82            [24] 1673 	mov	dpl, r0
      008D52 8D 83            [24] 1674 	mov	dph, r5
      008D54 C0 07            [24] 1675 	push	ar7
      008D56 C0 06            [24] 1676 	push	ar6
      008D58 C0 05            [24] 1677 	push	ar5
      008D5A C0 04            [24] 1678 	push	ar4
      008D5C 12 43 1D         [24] 1679 	lcall	_ak820_eeprom_read_block_xdata
      008D5F D0 04            [24] 1680 	pop	ar4
      008D61 D0 05            [24] 1681 	pop	ar5
      008D63 D0 06            [24] 1682 	pop	ar6
      008D65 D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D67 D0 05            [24] 1685 	pop	ar5
      008D69 D0 04            [24] 1686 	pop	ar4
                                   1687 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D6B                       1688 00106$:
                                   1689 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D6B 90 0B 47         [24] 1690 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      008D6E E0               [24] 1691 	movx	a,@dptr
      008D6F FB               [12] 1692 	mov	r3,a
      008D70                       1693 00109$:
      008D70 8B 01            [24] 1694 	mov	ar1,r3
      008D72 7A 00            [12] 1695 	mov	r2,#0x00
      008D74 C3               [12] 1696 	clr	c
      008D75 E9               [12] 1697 	mov	a,r1
      008D76 9C               [12] 1698 	subb	a,r4
      008D77 EA               [12] 1699 	mov	a,r2
      008D78 9D               [12] 1700 	subb	a,r5
      008D79 50 09            [24] 1701 	jnc	00111$
      008D7B EB               [12] 1702 	mov	a,r3
      008D7C 12 3A 9F         [24] 1703 	lcall	_ak820_outline_0022
      008D7F E4               [12] 1704 	clr	a
      008D80 F0               [24] 1705 	movx	@dptr,a
      008D81 0B               [12] 1706 	inc	r3
      008D82 80 EC            [24] 1707 	sjmp	00109$
      008D84                       1708 00111$:
                                   1709 ;	quantum/dynamic_keymap.c:420: }
      008D84 22               [24] 1710 	ret
                                   1711 ;------------------------------------------------------------
                                   1712 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1713 ;------------------------------------------------------------
                                   1714 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1715 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1716 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function dynamic_keymap_get_buffer
                                   1721 ;	-----------------------------------------
      008D85                       1722 _dynamic_keymap_get_buffer:
      008D85 12 3A F0         [24] 1723 	lcall	_ak820_outline_0107
      008D88 90 0B 4D         [24] 1724 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008D8B 12 3A F5         [24] 1725 	lcall	_ak820_outline_0108
                                   1726 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008D8E 90 0B 4D         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008D91 12 3A AF         [24] 1728 	lcall	_ak820_outline_0052
      008D94 90 0B 48         [24] 1729 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008D97 12 3A C6         [24] 1730 	lcall	_ak820_outline_0061
      008D9A 90 0B 4A         [24] 1731 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008D9D E0               [24] 1732 	movx	a,@dptr
      008D9E F9               [12] 1733 	mov	r1,a
      008D9F A3               [24] 1734 	inc	dptr
      008DA0 12 45 AC         [24] 1735 	lcall	_ak820_outline_0086
      008DA3 90 0B 3C         [24] 1736 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DA6 E4               [12] 1737 	clr	a
      008DA7 F0               [24] 1738 	movx	@dptr,a
      008DA8 74 06            [12] 1739 	mov	a,#0x06
      008DAA A3               [24] 1740 	inc	dptr
      008DAB F0               [24] 1741 	movx	@dptr,a
      008DAC 90 0B 3E         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DAF 12 4A EA         [24] 1743 	lcall	_ak820_outline_0060
      008DB2 90 0B 40         [24] 1744 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DB5 12 3A D2         [24] 1745 	lcall	_ak820_outline_0074
      008DB8 90 0B 42         [24] 1746 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DBB E9               [12] 1747 	mov	a,r1
      008DBC 12 51 BF         [24] 1748 	lcall	_ak820_outline_0116
      008DBF F0               [24] 1749 	movx	@dptr,a
      008DC0 90 00 40         [24] 1750 	mov	dptr,#0x0040
                                   1751 ;	quantum/dynamic_keymap.c:448: }
      008DC3 81 CF            [12] 1752 	ajmp	_ak820_dynamic_read_buffer
                                   1753 ;------------------------------------------------------------
                                   1754 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1755 ;------------------------------------------------------------
                                   1756 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1757 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1758 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1759 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1760 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1761 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1762 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1763 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1764 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1765 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1766 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1767 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1769 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1770 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1771 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function dynamic_keymap_set_buffer
                                   1776 ;	-----------------------------------------
      008DC5                       1777 _dynamic_keymap_set_buffer:
      008DC5 12 3A F0         [24] 1778 	lcall	_ak820_outline_0107
      008DC8 90 0B 54         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008DCB 12 3A F5         [24] 1780 	lcall	_ak820_outline_0108
                                   1781 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008DCE 90 0B 54         [24] 1782 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008DD1 12 4A 8D         [24] 1783 	lcall	_ak820_outline_0008
      008DD4 74 40            [12] 1784 	mov	a,#0x40
      008DD6 2C               [12] 1785 	add	a, r4
      008DD7 FA               [12] 1786 	mov	r2,a
      008DD8 E4               [12] 1787 	clr	a
      008DD9 3D               [12] 1788 	addc	a, r5
      008DDA FB               [12] 1789 	mov	r3,a
                                   1790 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008DDB 90 0B 51         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008DDE 12 3A EA         [24] 1792 	lcall	_ak820_outline_0101
                                   1793 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008DE1 90 0B 4F         [24] 1794 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008DE4 E0               [24] 1795 	movx	a,@dptr
      008DE5 F5 2D            [12] 1796 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008DE7 A3               [24] 1797 	inc	dptr
      008DE8 E0               [24] 1798 	movx	a,@dptr
      008DE9 F5 2E            [12] 1799 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008DEB E5 2D            [12] 1800 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008DED 45 2E            [12] 1801 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DEF 70 01            [24] 1802 	jnz	00102$
      008DF1 22               [24] 1803 	ret
      008DF2                       1804 00102$:
                                   1805 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008DF2 85 2D 2F         [24] 1806 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008DF5 85 2E 30         [24] 1807 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DF8 C3               [12] 1808 	clr	c
      008DF9 74 1C            [12] 1809 	mov	a,#0x1c
      008DFB 95 2F            [12] 1810 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008DFD E4               [12] 1811 	clr	a
      008DFE 95 30            [12] 1812 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E00 50 01            [24] 1813 	jnc	00104$
                                   1814 ;	free result
      008E02 22               [24] 1815 	ret
      008E03                       1816 00104$:
                                   1817 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008E03 85 2D 31         [24] 1818 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1819 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008E06 74 FA            [12] 1820 	mov	a,#0x100 - 0x06
      008E08 2F               [12] 1821 	add	a,r7
      008E09 40 11            [24] 1822 	jc	00105$
      008E0B E4               [12] 1823 	clr	a
      008E0C C3               [12] 1824 	clr	c
      008E0D 9E               [12] 1825 	subb	a,r6
      008E0E FE               [12] 1826 	mov	r6,a
      008E0F 74 06            [12] 1827 	mov	a,#0x06
      008E11 9F               [12] 1828 	subb	a,r7
      008E12 FF               [12] 1829 	mov	r7,a
      008E13 C3               [12] 1830 	clr	c
      008E14 EE               [12] 1831 	mov	a,r6
      008E15 95 2D            [12] 1832 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E17 EF               [12] 1833 	mov	a,r7
      008E18 95 2E            [12] 1834 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E1A 50 01            [24] 1835 	jnc	00106$
      008E1C                       1836 00105$:
                                   1837 ;	quantum/dynamic_keymap.c:466: return;
      008E1C 22               [24] 1838 	ret
      008E1D                       1839 00106$:
                                   1840 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008E1D 90 0E 54         [24] 1841 	mov	dptr,#_vial_unlocked
      008E20 E0               [24] 1842 	movx	a,@dptr
      008E21 60 02            [24] 1843 	jz	00207$
      008E23 E1 2F            [12] 1844 	ajmp	00120$
      008E25                       1845 00207$:
                                   1846 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008E25 90 0B 56         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008E28 E4               [12] 1848 	clr	a
      008E29 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008E2A 90 0B 57         [24] 1851 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008E2D E5 31            [12] 1852 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E2F F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008E30 EC               [12] 1855 	mov	a,r4
      008E31 30 E0 31         [24] 1856 	jnb	acc.0,00111$
                                   1857 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008E34 EA               [12] 1858 	mov	a,r2
      008E35 24 FF            [12] 1859 	add	a,#0xff
      008E37 FE               [12] 1860 	mov	r6,a
      008E38 EB               [12] 1861 	mov	a,r3
      008E39 34 FF            [12] 1862 	addc	a,#0xff
      008E3B FF               [12] 1863 	mov	r7,a
      008E3C 7D 00            [12] 1864 	mov	r5,#0x00
      008E3E 12 74 79         [24] 1865 	lcall	_ak820_outline_0050
      008E41 12 42 E2         [24] 1866 	lcall	_eeprom_read_byte
      008E44 AE 82            [24] 1867 	mov	r6,dpl
      008E46 7F 00            [12] 1868 	mov	r7,#0x00
      008E48 12 3B 24         [24] 1869 	lcall	_ak820_outline_0161
      008E4B E0               [24] 1870 	movx	a,@dptr
      008E4C 7C 00            [12] 1871 	mov	r4,#0x00
      008E4E 42 07            [12] 1872 	orl	ar7,a
      008E50 EC               [12] 1873 	mov	a,r4
      008E51 42 06            [12] 1874 	orl	ar6,a
                                   1875 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008E53 BF 00 09         [24] 1876 	cjne	r7,#0x00,00109$
      008E56 BE 7C 06         [24] 1877 	cjne	r6,#0x7c,00109$
                                   1878 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008E59 12 3B 24         [24] 1879 	lcall	_ak820_outline_0161
      008E5C 74 FF            [12] 1880 	mov	a,#0xff
      008E5E F0               [24] 1881 	movx	@dptr,a
      008E5F                       1882 00109$:
                                   1883 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008E5F 90 0B 56         [24] 1884 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008E62 74 01            [12] 1885 	mov	a,#0x01
      008E64 F0               [24] 1886 	movx	@dptr,a
      008E65                       1887 00111$:
                                   1888 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008E65 90 0B 54         [24] 1889 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008E68 12 3A AF         [24] 1890 	lcall	_ak820_outline_0052
      008E6B E5 2D            [12] 1891 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E6D 2E               [12] 1892 	add	a, r6
      008E6E FE               [12] 1893 	mov	r6,a
      008E6F E5 2E            [12] 1894 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E71 3F               [12] 1895 	addc	a, r7
      008E72 EE               [12] 1896 	mov	a,r6
      008E73 30 E0 5A         [24] 1897 	jnb	acc.0,00115$
                                   1898 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008E76 AE 31            [24] 1899 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008E78 7F 00            [12] 1900 	mov	r7,#0x00
      008E7A EE               [12] 1901 	mov	a,r6
      008E7B 24 FF            [12] 1902 	add	a,#0xff
      008E7D FC               [12] 1903 	mov	r4,a
      008E7E EF               [12] 1904 	mov	a,r7
      008E7F 34 FF            [12] 1905 	addc	a,#0xff
      008E81 FD               [12] 1906 	mov	r5,a
      008E82 EC               [12] 1907 	mov	a,r4
      008E83 28               [12] 1908 	add	a, r0
      008E84 F5 82            [12] 1909 	mov	dpl,a
      008E86 ED               [12] 1910 	mov	a,r5
      008E87 39               [12] 1911 	addc	a, r1
      008E88 F5 83            [12] 1912 	mov	dph,a
      008E8A E0               [24] 1913 	movx	a,@dptr
      008E8B FC               [12] 1914 	mov	r4,a
      008E8C 7D 00            [12] 1915 	mov	r5,#0x00
      008E8E E5 31            [12] 1916 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E90 2A               [12] 1917 	add	a, r2
      008E91 FA               [12] 1918 	mov	r2,a
      008E92 E4               [12] 1919 	clr	a
      008E93 3B               [12] 1920 	addc	a, r3
      008E94 FB               [12] 1921 	mov	r3,a
      008E95 C0 00            [24] 1922 	push	ar0
      008E97 C0 01            [24] 1923 	push	ar1
      008E99 8B 01            [24] 1924 	mov	ar1,r3
      008E9B 7B 00            [12] 1925 	mov	r3,#0x00
      008E9D 8A 82            [24] 1926 	mov	dpl, r2
      008E9F 89 83            [24] 1927 	mov	dph, r1
      008EA1 8B F0            [24] 1928 	mov	b, r3
      008EA3 12 42 E2         [24] 1929 	lcall	_eeprom_read_byte
      008EA6 AB 82            [24] 1930 	mov	r3, dpl
      008EA8 7A 00            [12] 1931 	mov	r2,#0x00
      008EAA EB               [12] 1932 	mov	a,r3
      008EAB 12 45 CF         [24] 1933 	lcall	_ak820_outline_0143
                                   1934 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008EAE BD 00 05         [24] 1935 	cjne	r5,#0x00,00212$
      008EB1 BC 7C 02         [24] 1936 	cjne	r4,#0x7c,00212$
      008EB4 80 06            [24] 1937 	sjmp	00213$
      008EB6                       1938 00212$:
      008EB6 D0 01            [24] 1939 	pop	ar1
      008EB8 D0 00            [24] 1940 	pop	ar0
      008EBA 80 0D            [24] 1941 	sjmp	00113$
      008EBC                       1942 00213$:
      008EBC D0 01            [24] 1943 	pop	ar1
      008EBE D0 00            [24] 1944 	pop	ar0
                                   1945 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008EC0 1E               [12] 1946 	dec	r6
      008EC1 BE FF 01         [24] 1947 	cjne	r6,#0xff,00214$
      008EC4 1F               [12] 1948 	dec	r7
      008EC5                       1949 00214$:
      008EC5 EE               [12] 1950 	mov	a,r6
      008EC6 12 93 40         [24] 1951 	lcall	_ak820_outline_0129
      008EC9                       1952 00113$:
                                   1953 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008EC9 E5 31            [12] 1954 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008ECB 14               [12] 1955 	dec	a
      008ECC 90 0B 57         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008ECF F0               [24] 1957 	movx	@dptr,a
      008ED0                       1958 00115$:
                                   1959 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008ED0 90 0B 56         [24] 1960 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008ED3 E0               [24] 1961 	movx	a,@dptr
      008ED4 90 0B 58         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008ED7 F0               [24] 1963 	movx	@dptr,a
      008ED8                       1964 00122$:
      008ED8 90 0B 58         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008EDB E0               [24] 1966 	movx	a,@dptr
      008EDC FF               [12] 1967 	mov	r7,a
      008EDD 90 0B 57         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008EE0 E0               [24] 1969 	movx	a,@dptr
      008EE1 FE               [12] 1970 	mov	r6,a
      008EE2 C3               [12] 1971 	clr	c
      008EE3 EF               [12] 1972 	mov	a,r7
      008EE4 9E               [12] 1973 	subb	a,r6
      008EE5 50 48            [24] 1974 	jnc	00120$
                                   1975 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008EE7 EF               [12] 1976 	mov	a,r7
      008EE8 28               [12] 1977 	add	a, r0
      008EE9 FD               [12] 1978 	mov	r5,a
      008EEA E4               [12] 1979 	clr	a
      008EEB 39               [12] 1980 	addc	a, r1
      008EEC FE               [12] 1981 	mov	r6,a
      008EED 12 4A F7         [24] 1982 	lcall	_ak820_outline_0077
      008EF0 7B 00            [12] 1983 	mov	r3,#0x00
      008EF2 8C 2E            [24] 1984 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008EF4 8B 2D            [24] 1985 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008EF6 8F 02            [24] 1986 	mov	ar2,r7
      008EF8 7F 00            [12] 1987 	mov	r7,#0x00
      008EFA 74 01            [12] 1988 	mov	a,#0x01
      008EFC 2A               [12] 1989 	add	a, r2
      008EFD FB               [12] 1990 	mov	r3,a
      008EFE E4               [12] 1991 	clr	a
      008EFF 3F               [12] 1992 	addc	a, r7
      008F00 FC               [12] 1993 	mov	r4,a
      008F01 EB               [12] 1994 	mov	a,r3
      008F02 28               [12] 1995 	add	a, r0
      008F03 F5 82            [12] 1996 	mov	dpl,a
      008F05 EC               [12] 1997 	mov	a,r4
      008F06 39               [12] 1998 	addc	a, r1
      008F07 F5 83            [12] 1999 	mov	dph,a
      008F09 E0               [24] 2000 	movx	a,@dptr
      008F0A FC               [12] 2001 	mov	r4,a
      008F0B 7B 00            [12] 2002 	mov	r3,#0x00
      008F0D E5 2E            [12] 2003 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F0F 42 03            [12] 2004 	orl	ar3,a
                                   2005 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008F11 BC 00 12         [24] 2006 	cjne	r4,#0x00,00123$
      008F14 BB 7C 0F         [24] 2007 	cjne	r3,#0x7c,00123$
                                   2008 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008F17 12 3B 09         [24] 2009 	lcall	_ak820_outline_0133
      008F1A 74 FF            [12] 2010 	mov	a,#0xff
      008F1C F0               [24] 2011 	movx	@dptr,a
                                   2012 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008F1D 0A               [12] 2013 	inc	r2
      008F1E BA 00 01         [24] 2014 	cjne	r2,#0x00,00218$
      008F21 0F               [12] 2015 	inc	r7
      008F22                       2016 00218$:
      008F22 EA               [12] 2017 	mov	a,r2
      008F23 12 93 40         [24] 2018 	lcall	_ak820_outline_0129
      008F26                       2019 00123$:
                                   2020 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F26 90 0B 58         [24] 2021 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008F29 E0               [24] 2022 	movx	a,@dptr
      008F2A 24 02            [12] 2023 	add	a,#0x02
      008F2C F0               [24] 2024 	movx	@dptr,a
      008F2D 80 A9            [24] 2025 	sjmp	00122$
      008F2F                       2026 00120$:
                                   2027 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008F2F 90 0B 54         [24] 2028 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008F32 12 3A AF         [24] 2029 	lcall	_ak820_outline_0052
      008F35 74 40            [12] 2030 	mov	a,#0x40
      008F37 12 45 C9         [24] 2031 	lcall	_ak820_outline_0135
      008F3A 90 05 9E         [24] 2032 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008F3D 12 4A EA         [24] 2033 	lcall	_ak820_outline_0060
      008F40 E4               [12] 2034 	clr	a
      008F41 A3               [24] 2035 	inc	dptr
      008F42 F0               [24] 2036 	movx	@dptr,a
      008F43 90 05 A1         [24] 2037 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008F46 E5 2F            [12] 2038 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F48 F0               [24] 2039 	movx	@dptr,a
      008F49 E5 30            [12] 2040 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F4B A3               [24] 2041 	inc	dptr
      008F4C F0               [24] 2042 	movx	@dptr,a
      008F4D 12 3B 24         [24] 2043 	lcall	_ak820_outline_0161
                                   2044 ;	quantum/dynamic_keymap.c:521: }
      008F50 02 43 A3         [24] 2045 	ljmp	_ak820_eeprom_write_block_xdata
                                   2046 ;------------------------------------------------------------
                                   2047 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2048 ;------------------------------------------------------------
                                   2049 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2050 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2051 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2052 ;------------------------------------------------------------
                                   2053 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2054 ;	-----------------------------------------
                                   2055 ;	 function keycode_at_keymap_location
                                   2056 ;	-----------------------------------------
      008F53                       2057 _keycode_at_keymap_location:
      008F53 E5 82            [12] 2058 	mov	a,dpl
      008F55 90 0B 5B         [24] 2059 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008F58 F0               [24] 2060 	movx	@dptr,a
                                   2061 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008F59 E0               [24] 2062 	movx	a,@dptr
      008F5A FF               [12] 2063 	mov	r7,a
      008F5B BF 06 00         [24] 2064 	cjne	r7,#0x06,00128$
      008F5E                       2065 00128$:
      008F5E 50 22            [24] 2066 	jnc	00102$
      008F60 90 0B 59         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008F63 E0               [24] 2068 	movx	a,@dptr
      008F64 FE               [12] 2069 	mov	r6,a
      008F65 BE 10 00         [24] 2070 	cjne	r6,#0x10,00130$
      008F68                       2071 00130$:
      008F68 50 18            [24] 2072 	jnc	00102$
      008F6A 90 0B 5A         [24] 2073 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008F6D E0               [24] 2074 	movx	a,@dptr
      008F6E FD               [12] 2075 	mov	r5,a
      008F6F BD 08 00         [24] 2076 	cjne	r5,#0x08,00132$
      008F72                       2077 00132$:
      008F72 50 0E            [24] 2078 	jnc	00102$
                                   2079 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008F74 90 0B 0D         [24] 2080 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008F77 EE               [12] 2081 	mov	a,r6
      008F78 F0               [24] 2082 	movx	@dptr,a
      008F79 90 0B 0E         [24] 2083 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008F7C ED               [12] 2084 	mov	a,r5
      008F7D F0               [24] 2085 	movx	@dptr,a
      008F7E 8F 82            [24] 2086 	mov	dpl, r7
      008F80 01 FF            [12] 2087 	ajmp	_dynamic_keymap_get_keycode
      008F82                       2088 00102$:
                                   2089 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008F82 90 00 00         [24] 2090 	mov	dptr,#0x0000
                                   2091 ;	quantum/dynamic_keymap.c:528: }
      008F85 22               [24] 2092 	ret
                                   2093 ;------------------------------------------------------------
                                   2094 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2095 ;------------------------------------------------------------
                                   2096 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2097 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2098 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2099 ;------------------------------------------------------------
                                   2100 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2101 ;	-----------------------------------------
                                   2102 ;	 function keycode_at_encodermap_location
                                   2103 ;	-----------------------------------------
      008F86                       2104 _keycode_at_encodermap_location:
      008F86 E5 82            [12] 2105 	mov	a,dpl
      008F88 90 0B 5E         [24] 2106 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008F8B F0               [24] 2107 	movx	@dptr,a
                                   2108 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008F8C E0               [24] 2109 	movx	a,@dptr
      008F8D FF               [12] 2110 	mov	r7,a
      008F8E BF 06 00         [24] 2111 	cjne	r7,#0x06,00120$
      008F91                       2112 00120$:
      008F91 50 1E            [24] 2113 	jnc	00102$
      008F93 90 0B 5C         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008F96 E0               [24] 2115 	movx	a,@dptr
      008F97 FE               [12] 2116 	mov	r6,a
      008F98 BE 01 00         [24] 2117 	cjne	r6,#0x01,00122$
      008F9B                       2118 00122$:
      008F9B 50 14            [24] 2119 	jnc	00102$
                                   2120 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008F9D 90 0B 5D         [24] 2121 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008FA0 E0               [24] 2122 	movx	a,@dptr
      008FA1 FE               [12] 2123 	mov	r6,a
      008FA2 90 0B 17         [24] 2124 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008FA5 E4               [12] 2125 	clr	a
      008FA6 F0               [24] 2126 	movx	@dptr,a
      008FA7 90 0B 18         [24] 2127 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008FAA EE               [12] 2128 	mov	a,r6
      008FAB F0               [24] 2129 	movx	@dptr,a
      008FAC 8F 82            [24] 2130 	mov	dpl, r7
      008FAE 02 89 BC         [24] 2131 	ljmp	_dynamic_keymap_get_encoder
      008FB1                       2132 00102$:
                                   2133 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008FB1 90 00 00         [24] 2134 	mov	dptr,#0x0000
                                   2135 ;	quantum/dynamic_keymap.c:536: }
      008FB4 22               [24] 2136 	ret
                                   2137 ;------------------------------------------------------------
                                   2138 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2139 ;------------------------------------------------------------
                                   2140 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2141 ;	-----------------------------------------
                                   2142 ;	 function dynamic_keymap_macro_get_count
                                   2143 ;	-----------------------------------------
      008FB5                       2144 _dynamic_keymap_macro_get_count:
                                   2145 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008FB5 75 82 10         [24] 2146 	mov	dpl, #0x10
                                   2147 ;	quantum/dynamic_keymap.c:541: }
      008FB8 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2155 ;	-----------------------------------------
      008FB9                       2156 _dynamic_keymap_macro_get_buffer_size:
                                   2157 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008FB9 90 20 00         [24] 2158 	mov	dptr,#0x2000
                                   2159 ;	quantum/dynamic_keymap.c:545: }
      008FBC 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2163 ;------------------------------------------------------------
                                   2164 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2165 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2166 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2167 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2168 ;------------------------------------------------------------
                                   2169 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2170 ;	-----------------------------------------
                                   2171 ;	 function dynamic_keymap_macro_get_buffer
                                   2172 ;	-----------------------------------------
      008FBD                       2173 _dynamic_keymap_macro_get_buffer:
      008FBD 12 3A F0         [24] 2174 	lcall	_ak820_outline_0107
      008FC0 90 0B 64         [24] 2175 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008FC3 12 3A F5         [24] 2176 	lcall	_ak820_outline_0108
                                   2177 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008FC6 12 2B 2B         [24] 2178 	lcall	_ak820_macro_length
      008FC9 12 45 C4         [24] 2179 	lcall	_ak820_outline_0125
      008FCC 90 0B 64         [24] 2180 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008FCF 12 3A C6         [24] 2181 	lcall	_ak820_outline_0061
      008FD2 90 0B 5F         [24] 2182 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008FD5 E0               [24] 2183 	movx	a,@dptr
      008FD6 F5 32            [12] 2184 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008FD8 A3               [24] 2185 	inc	dptr
      008FD9 E0               [24] 2186 	movx	a,@dptr
      008FDA F5 33            [12] 2187 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008FDC 90 0B 61         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008FDF 12 3A EA         [24] 2189 	lcall	_ak820_outline_0101
      008FE2 A3               [24] 2190 	inc	dptr
      008FE3 E0               [24] 2191 	movx	a,@dptr
      008FE4 FB               [12] 2192 	mov	r3,a
      008FE5 90 0B 3C         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008FE8 12 4A EA         [24] 2194 	lcall	_ak820_outline_0060
      008FEB 90 0B 3E         [24] 2195 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008FEE 12 3A D2         [24] 2196 	lcall	_ak820_outline_0074
      008FF1 90 0B 40         [24] 2197 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008FF4 E5 32            [12] 2198 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008FF6 F0               [24] 2199 	movx	@dptr,a
      008FF7 E5 33            [12] 2200 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008FF9 A3               [24] 2201 	inc	dptr
      008FFA F0               [24] 2202 	movx	@dptr,a
      008FFB 90 0B 42         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008FFE E8               [12] 2204 	mov	a,r0
      008FFF F0               [24] 2205 	movx	@dptr,a
      009000 E9               [12] 2206 	mov	a,r1
      009001 A3               [24] 2207 	inc	dptr
      009002 12 7C A2         [24] 2208 	lcall	_ak820_outline_0185
      009005 90 08 00         [24] 2209 	mov	dptr,#0x0800
                                   2210 ;	quantum/dynamic_keymap.c:572: }
      009008 02 8C CF         [24] 2211 	ljmp	_ak820_dynamic_read_buffer
                                   2212 ;------------------------------------------------------------
                                   2213 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2214 ;------------------------------------------------------------
                                   2215 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2216 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2217 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2218 ;------------------------------------------------------------
                                   2219 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2220 ;	-----------------------------------------
                                   2221 ;	 function dynamic_keymap_macro_set_buffer
                                   2222 ;	-----------------------------------------
      00900B                       2223 _dynamic_keymap_macro_set_buffer:
      00900B 12 3A F0         [24] 2224 	lcall	_ak820_outline_0107
      00900E 90 0B 6B         [24] 2225 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      009011 12 3A F5         [24] 2226 	lcall	_ak820_outline_0108
                                   2227 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      009014 90 0B 6B         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      009017 12 3A AF         [24] 2229 	lcall	_ak820_outline_0052
      00901A 90 0B 66         [24] 2230 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00901D 12 3A C6         [24] 2231 	lcall	_ak820_outline_0061
      009020 90 0B 68         [24] 2232 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009023 E0               [24] 2233 	movx	a,@dptr
      009024 F9               [12] 2234 	mov	r1,a
      009025 A3               [24] 2235 	inc	dptr
      009026 12 45 AC         [24] 2236 	lcall	_ak820_outline_0086
      009029 90 05 24         [24] 2237 	mov	dptr,#_ak820_macro_write_PARM_2
      00902C 12 3A D2         [24] 2238 	lcall	_ak820_outline_0074
      00902F 90 05 26         [24] 2239 	mov	dptr,#_ak820_macro_write_PARM_3
      009032 E9               [12] 2240 	mov	a,r1
      009033 12 51 BF         [24] 2241 	lcall	_ak820_outline_0116
      009036 12 45 A6         [24] 2242 	lcall	_ak820_outline_0079
                                   2243 ;	quantum/dynamic_keymap.c:577: }
      009039 02 2B 45         [24] 2244 	ljmp	_ak820_macro_write
                                   2245 ;------------------------------------------------------------
                                   2246 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2247 ;------------------------------------------------------------
                                   2248 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2249 ;	-----------------------------------------
                                   2250 ;	 function dynamic_keymap_macro_reset
                                   2251 ;	-----------------------------------------
      00903C                       2252 _dynamic_keymap_macro_reset:
                                   2253 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2254 ;	quantum/dynamic_keymap.c:603: }
      00903C 02 2E 64         [24] 2255 	ljmp	_ak820_macro_reset
                                   2256 ;------------------------------------------------------------
                                   2257 ;Allocation info for local variables in function 'decode_keycode'
                                   2258 ;------------------------------------------------------------
                                   2259 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2260 ;------------------------------------------------------------
                                   2261 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2262 ;	-----------------------------------------
                                   2263 ;	 function decode_keycode
                                   2264 ;	-----------------------------------------
      00903F                       2265 _decode_keycode:
      00903F 12 3A F0         [24] 2266 	lcall	_ak820_outline_0107
      009042 90 0B 6D         [24] 2267 	mov	dptr,#_decode_keycode_kc_10000_455
      009045 12 3A F5         [24] 2268 	lcall	_ak820_outline_0108
                                   2269 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      009048 90 0B 6D         [24] 2270 	mov	dptr,#_decode_keycode_kc_10000_455
      00904B 12 4A 8D         [24] 2271 	lcall	_ak820_outline_0008
      00904E C3               [12] 2272 	clr	c
      00904F E4               [12] 2273 	clr	a
      009050 9C               [12] 2274 	subb	a,r4
      009051 74 FF            [12] 2275 	mov	a,#0xff
      009053 9D               [12] 2276 	subb	a,r5
      009054 50 08            [24] 2277 	jnc	00102$
                                   2278 ;	free result
                                   2279 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      009056 8C 05            [24] 2280 	mov	ar5,r4
      009058 7C 00            [12] 2281 	mov	r4,#0x00
      00905A 12 3A FF         [24] 2282 	lcall	_ak820_outline_0123
      00905D 22               [24] 2283 	ret
      00905E                       2284 00102$:
                                   2285 ;	quantum/dynamic_keymap.c:609: return kc;
      00905E 12 3A FA         [24] 2286 	lcall	_ak820_outline_0118
                                   2287 ;	quantum/dynamic_keymap.c:610: }
      009061 22               [24] 2288 	ret
                                   2289 ;------------------------------------------------------------
                                   2290 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2291 ;------------------------------------------------------------
                                   2292 ;sloc0         Allocated with name '_dynamic_keymap_macro_send_sloc0_1_0'
                                   2293 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2294 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2295 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2296 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2297 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2298 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2299 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2300 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2301 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2302 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2303 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2304 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2305 ;------------------------------------------------------------
                                   2306 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2307 ;	-----------------------------------------
                                   2308 ;	 function dynamic_keymap_macro_send
                                   2309 ;	-----------------------------------------
      009062                       2310 _dynamic_keymap_macro_send:
      009062 E5 82            [12] 2311 	mov	a,dpl
      009064 90 0B 6F         [24] 2312 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      009067 F0               [24] 2313 	movx	@dptr,a
                                   2314 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      009068 90 0B 70         [24] 2315 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      00906B E0               [24] 2316 	movx	a,@dptr
      00906C 60 01            [24] 2317 	jz	00102$
      00906E 22               [24] 2318 	ret
      00906F                       2319 00102$:
                                   2320 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00906F 90 0B 6F         [24] 2321 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      009072 E0               [24] 2322 	movx	a,@dptr
      009073 FF               [12] 2323 	mov	r7,a
      009074 BF 10 00         [24] 2324 	cjne	r7,#0x10,00422$
      009077                       2325 00422$:
      009077 40 01            [24] 2326 	jc	00104$
                                   2327 ;	quantum/dynamic_keymap.c:620: return;
      009079 22               [24] 2328 	ret
      00907A                       2329 00104$:
                                   2330 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      00907A C0 07            [24] 2331 	push	ar7
      00907C 12 2A F2         [24] 2332 	lcall	_ak820_macro_ready
      00907F E5 82            [12] 2333 	mov	a, dpl
      009081 D0 07            [24] 2334 	pop	ar7
      009083 70 01            [24] 2335 	jnz	00106$
      009085 22               [24] 2336 	ret
      009086                       2337 00106$:
                                   2338 ;	quantum/dynamic_keymap.c:641: p         = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR);
      009086 90 0B 71         [24] 2339 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009089 E4               [12] 2340 	clr	a
      00908A F0               [24] 2341 	movx	@dptr,a
      00908B 74 08            [12] 2342 	mov	a,#0x08
      00908D 12 3A CC         [24] 2343 	lcall	_ak820_outline_0072
                                   2344 ;	quantum/dynamic_keymap.c:643: uint8_t *end = (uint8_t *)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length());
      009090 C0 07            [24] 2345 	push	ar7
      009092 12 2B 2B         [24] 2346 	lcall	_ak820_macro_length
      009095 AD 82            [24] 2347 	mov	r5, dpl
      009097 AE 83            [24] 2348 	mov	r6, dph
      009099 D0 07            [24] 2349 	pop	ar7
      00909B 74 08            [12] 2350 	mov	a,#0x08
      00909D 2E               [12] 2351 	add	a, r6
      00909E FE               [12] 2352 	mov	r6,a
      00909F 8D 34            [24] 2353 	mov	_dynamic_keymap_macro_send_sloc0_1_0,r5
      0090A1 8E 35            [24] 2354 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 1),r6
      0090A3 75 36 00         [24] 2355 	mov	(_dynamic_keymap_macro_send_sloc0_1_0 + 2),#0x00
                                   2356 ;	quantum/dynamic_keymap.c:647: while (id > 0) {
      0090A6 79 00            [12] 2357 	mov	r1,#0x00
      0090A8 7A 08            [12] 2358 	mov	r2,#0x08
      0090AA 7B 00            [12] 2359 	mov	r3,#0x00
      0090AC                       2360 00111$:
      0090AC EF               [12] 2361 	mov	a,r7
      0090AD 60 34            [24] 2362 	jz	00113$
                                   2363 ;	quantum/dynamic_keymap.c:651: if (p == end) {
      0090AF C0 34            [24] 2364 	push	_dynamic_keymap_macro_send_sloc0_1_0
      0090B1 C0 35            [24] 2365 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      0090B3 C0 36            [24] 2366 	push	(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      0090B5 12 93 51         [24] 2367 	lcall	_ak820_outline_0155
      0090B8 12 30 77         [24] 2368 	lcall	___gptr_cmp
      0090BB 15 81            [12] 2369 	dec	sp
      0090BD 15 81            [12] 2370 	dec	sp
      0090BF 15 81            [12] 2371 	dec	sp
      0090C1 70 01            [24] 2372 	jnz	00108$
                                   2373 ;	quantum/dynamic_keymap.c:652: return;
      0090C3 22               [24] 2374 	ret
      0090C4                       2375 00108$:
                                   2376 ;	quantum/dynamic_keymap.c:654: if (eeprom_read_byte(p) == 0) {
      0090C4 12 93 51         [24] 2377 	lcall	_ak820_outline_0155
      0090C7 12 42 E2         [24] 2378 	lcall	_eeprom_read_byte
      0090CA E5 82            [12] 2379 	mov	a, dpl
      0090CC 70 06            [24] 2380 	jnz	00110$
                                   2381 ;	quantum/dynamic_keymap.c:655: --id;
      0090CE 1F               [12] 2382 	dec	r7
      0090CF 90 0B 6F         [24] 2383 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      0090D2 EF               [12] 2384 	mov	a,r7
      0090D3 F0               [24] 2385 	movx	@dptr,a
      0090D4                       2386 00110$:
                                   2387 ;	quantum/dynamic_keymap.c:657: ++p;
      0090D4 09               [12] 2388 	inc	r1
      0090D5 B9 00 01         [24] 2389 	cjne	r1,#0x00,00429$
      0090D8 0A               [12] 2390 	inc	r2
      0090D9                       2391 00429$:
      0090D9 90 0B 71         [24] 2392 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0090DC E9               [12] 2393 	mov	a,r1
      0090DD 12 51 BF         [24] 2394 	lcall	_ak820_outline_0116
      0090E0 F0               [24] 2395 	movx	@dptr,a
      0090E1 80 C9            [24] 2396 	sjmp	00111$
      0090E3                       2397 00113$:
                                   2398 ;	quantum/dynamic_keymap.c:663: sending = true;
      0090E3 90 0B 70         [24] 2399 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      0090E6 74 01            [12] 2400 	mov	a,#0x01
      0090E8 F0               [24] 2401 	movx	@dptr,a
                                   2402 ;	quantum/dynamic_keymap.c:665: ak820_macro_cancelled = ak820_macro_primitive = false;
      0090E9 12 93 5F         [24] 2403 	lcall	_ak820_outline_0168
      0090EC 90 09 B9         [24] 2404 	mov	dptr,#_ak820_macro_cancelled
      0090EF F0               [24] 2405 	movx	@dptr,a
                                   2406 ;	quantum/dynamic_keymap.c:670: char data[4] = {0, 0, 0, 0};
      0090F0 90 0B 74         [24] 2407 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0090F3 F0               [24] 2408 	movx	@dptr,a
      0090F4 90 0B 75         [24] 2409 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      0090F7 F0               [24] 2410 	movx	@dptr,a
      0090F8 90 0B 76         [24] 2411 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      0090FB F0               [24] 2412 	movx	@dptr,a
      0090FC 90 0B 77         [24] 2413 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      0090FF F0               [24] 2414 	movx	@dptr,a
                                   2415 ;	quantum/dynamic_keymap.c:673: while (p < end
      009100                       2416 00167$:
                                   2417 ;	quantum/dynamic_keymap.c:675: && !ak820_macro_cancelled
      009100 90 0B 71         [24] 2418 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009103 12 45 AC         [24] 2419 	lcall	_ak820_outline_0086
      009106 A3               [24] 2420 	inc	dptr
      009107 E0               [24] 2421 	movx	a,@dptr
      009108 FF               [12] 2422 	mov	r7,a
      009109 A8 34            [24] 2423 	mov	r0,_dynamic_keymap_macro_send_sloc0_1_0
      00910B A9 35            [24] 2424 	mov	r1,(_dynamic_keymap_macro_send_sloc0_1_0 + 1)
      00910D AE 36            [24] 2425 	mov	r6,(_dynamic_keymap_macro_send_sloc0_1_0 + 2)
      00910F C0 00            [24] 2426 	push	ar0
      009111 C0 01            [24] 2427 	push	ar1
      009113 C0 06            [24] 2428 	push	ar6
      009115 12 3B 1A         [24] 2429 	lcall	_ak820_outline_0144
      009118 8F F0            [24] 2430 	mov	b,r7
      00911A 12 30 77         [24] 2431 	lcall	___gptr_cmp
      00911D 15 81            [12] 2432 	dec	sp
      00911F 15 81            [12] 2433 	dec	sp
      009121 15 81            [12] 2434 	dec	sp
      009123 40 02            [24] 2435 	jc	00430$
      009125 41 E9            [12] 2436 	ajmp	00169$
      009127                       2437 00430$:
      009127 90 09 B9         [24] 2438 	mov	dptr,#_ak820_macro_cancelled
      00912A E0               [24] 2439 	movx	a,@dptr
      00912B 60 02            [24] 2440 	jz	00431$
      00912D 41 E9            [12] 2441 	ajmp	00169$
      00912F                       2442 00431$:
                                   2443 ;	quantum/dynamic_keymap.c:678: data[0] = eeprom_read_byte(p++);
      00912F 8A 04            [24] 2444 	mov	ar4,r2
      009131 8B 05            [24] 2445 	mov	ar5,r3
      009133 8F 06            [24] 2446 	mov	ar6,r7
      009135 90 0B 71         [24] 2447 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009138 74 01            [12] 2448 	mov	a,#0x01
      00913A 12 45 DA         [24] 2449 	lcall	_ak820_outline_0152
      00913D EF               [12] 2450 	mov	a,r7
      00913E A3               [24] 2451 	inc	dptr
      00913F 12 3A E4         [24] 2452 	lcall	_ak820_outline_0096
      009142 8E F0            [24] 2453 	mov	b, r6
      009144 12 42 E2         [24] 2454 	lcall	_eeprom_read_byte
      009147 AF 82            [24] 2455 	mov	r7, dpl
      009149 90 0B 74         [24] 2456 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00914C EF               [12] 2457 	mov	a,r7
      00914D F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	quantum/dynamic_keymap.c:679: data[1] = 0;
      00914E 90 0B 75         [24] 2460 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009151 E4               [12] 2461 	clr	a
      009152 F0               [24] 2462 	movx	@dptr,a
                                   2463 ;	quantum/dynamic_keymap.c:681: if (data[0] == 0) {
      009153 90 0B 74         [24] 2464 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      009156 E0               [24] 2465 	movx	a,@dptr
      009157 70 02            [24] 2466 	jnz	00432$
      009159 41 E9            [12] 2467 	ajmp	00169$
      00915B                       2468 00432$:
                                   2469 ;	quantum/dynamic_keymap.c:684: if (data[0] == SS_QMK_PREFIX) {
      00915B 90 0B 74         [24] 2470 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      00915E E0               [24] 2471 	movx	a,@dptr
      00915F FF               [12] 2472 	mov	r7,a
      009160 BF 01 02         [24] 2473 	cjne	r7,#0x01,00433$
      009163 80 02            [24] 2474 	sjmp	00434$
      009165                       2475 00433$:
      009165 41 D4            [12] 2476 	ajmp	00164$
      009167                       2477 00434$:
                                   2478 ;	quantum/dynamic_keymap.c:687: data[1] = eeprom_read_byte(p++);
      009167 12 92 F1         [24] 2479 	lcall	_ak820_outline_0000
      00916A 12 42 E2         [24] 2480 	lcall	_eeprom_read_byte
      00916D AF 82            [24] 2481 	mov	r7, dpl
      00916F 90 0B 75         [24] 2482 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009172 EF               [12] 2483 	mov	a,r7
      009173 F0               [24] 2484 	movx	@dptr,a
                                   2485 ;	quantum/dynamic_keymap.c:688: if (data[1] == 0)
      009174 EF               [12] 2486 	mov	a,r7
      009175 70 02            [24] 2487 	jnz	00435$
      009177 41 E9            [12] 2488 	ajmp	00169$
      009179                       2489 00435$:
                                   2490 ;	quantum/dynamic_keymap.c:690: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009179 12 93 26         [24] 2491 	lcall	_ak820_outline_0094
      00917C BF 01 02         [24] 2492 	cjne	r7,#0x01,00436$
      00917F 80 12            [24] 2493 	sjmp	00151$
      009181                       2494 00436$:
      009181 12 93 26         [24] 2495 	lcall	_ak820_outline_0094
      009184 BF 02 02         [24] 2496 	cjne	r7,#0x02,00437$
      009187 80 0A            [24] 2497 	sjmp	00151$
      009189                       2498 00437$:
      009189 12 93 26         [24] 2499 	lcall	_ak820_outline_0094
      00918C BF 03 02         [24] 2500 	cjne	r7,#0x03,00438$
      00918F 80 02            [24] 2501 	sjmp	00439$
      009191                       2502 00438$:
      009191 80 47            [24] 2503 	sjmp	00152$
      009193                       2504 00439$:
      009193                       2505 00151$:
                                   2506 ;	quantum/dynamic_keymap.c:692: data[2] = eeprom_read_byte(p++);
      009193 12 92 F1         [24] 2507 	lcall	_ak820_outline_0000
      009196 12 42 E2         [24] 2508 	lcall	_eeprom_read_byte
      009199 12 93 77         [24] 2509 	lcall	_ak820_outline_0181
                                   2510 ;	quantum/dynamic_keymap.c:696: if (data[2] != 0) {
      00919C 70 02            [24] 2511 	jnz	00440$
      00919E 21 00            [12] 2512 	ajmp	00167$
      0091A0                       2513 00440$:
                                   2514 ;	quantum/dynamic_keymap.c:698: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0091A0 12 93 26         [24] 2515 	lcall	_ak820_outline_0094
      0091A3 BF 01 03         [24] 2516 	cjne	r7,#0x01,00441$
      0091A6 D3               [12] 2517 	setb	c
      0091A7 80 01            [24] 2518 	sjmp	00442$
      0091A9                       2519 00441$:
      0091A9 C3               [12] 2520 	clr	c
      0091AA                       2521 00442$:
      0091AA 92 25            [24] 2522 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      0091AC 90 09 B8         [24] 2523 	mov	dptr,#_ak820_macro_primitive
      0091AF B3               [12] 2524 	cpl	c
      0091B0 E4               [12] 2525 	clr	a
      0091B1 33               [12] 2526 	rlc	a
      0091B2 F0               [24] 2527 	movx	@dptr,a
                                   2528 ;	quantum/dynamic_keymap.c:700: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0091B3 12 93 26         [24] 2529 	lcall	_ak820_outline_0094
      0091B6 BF 01 08         [24] 2530 	cjne	r7,#0x01,00122$
      0091B9 12 93 58         [24] 2531 	lcall	_ak820_outline_0156
      0091BC 12 7B 66         [24] 2532 	lcall	_tap_code
      0091BF 80 14            [24] 2533 	sjmp	00123$
      0091C1                       2534 00122$:
                                   2535 ;	quantum/dynamic_keymap.c:701: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0091C1 12 93 26         [24] 2536 	lcall	_ak820_outline_0094
      0091C4 BF 02 08         [24] 2537 	cjne	r7,#0x02,00119$
      0091C7 12 93 58         [24] 2538 	lcall	_ak820_outline_0156
      0091CA 12 7A 35         [24] 2539 	lcall	_register_code
      0091CD 80 06            [24] 2540 	sjmp	00123$
      0091CF                       2541 00119$:
                                   2542 ;	quantum/dynamic_keymap.c:702: else unregister_code((uint8_t)data[2]);
      0091CF 12 93 58         [24] 2543 	lcall	_ak820_outline_0156
      0091D2 12 7A BA         [24] 2544 	lcall	_unregister_code
      0091D5                       2545 00123$:
                                   2546 ;	quantum/dynamic_keymap.c:704: ak820_macro_primitive = false;
      0091D5 12 93 5F         [24] 2547 	lcall	_ak820_outline_0168
      0091D8 21 00            [12] 2548 	ajmp	00167$
      0091DA                       2549 00152$:
                                   2550 ;	quantum/dynamic_keymap.c:712: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0091DA 12 93 26         [24] 2551 	lcall	_ak820_outline_0094
      0091DD BF 05 02         [24] 2552 	cjne	r7,#0x05,00447$
      0091E0 80 12            [24] 2553 	sjmp	00146$
      0091E2                       2554 00447$:
      0091E2 12 93 26         [24] 2555 	lcall	_ak820_outline_0094
      0091E5 BF 06 02         [24] 2556 	cjne	r7,#0x06,00448$
      0091E8 80 0A            [24] 2557 	sjmp	00146$
      0091EA                       2558 00448$:
      0091EA 12 93 26         [24] 2559 	lcall	_ak820_outline_0094
      0091ED BF 07 02         [24] 2560 	cjne	r7,#0x07,00449$
      0091F0 80 02            [24] 2561 	sjmp	00450$
      0091F2                       2562 00449$:
      0091F2 41 73            [12] 2563 	ajmp	00147$
      0091F4                       2564 00450$:
      0091F4                       2565 00146$:
                                   2566 ;	quantum/dynamic_keymap.c:713: data[2] = eeprom_read_byte(p++);
      0091F4 12 92 F1         [24] 2567 	lcall	_ak820_outline_0000
      0091F7 12 42 E2         [24] 2568 	lcall	_eeprom_read_byte
      0091FA 12 93 77         [24] 2569 	lcall	_ak820_outline_0181
                                   2570 ;	quantum/dynamic_keymap.c:714: if (data[2] != 0) {
      0091FD 70 02            [24] 2571 	jnz	00451$
      0091FF 21 00            [12] 2572 	ajmp	00167$
      009201                       2573 00451$:
                                   2574 ;	quantum/dynamic_keymap.c:715: data[3] = eeprom_read_byte(p++);
      009201 12 92 F1         [24] 2575 	lcall	_ak820_outline_0000
      009204 12 42 E2         [24] 2576 	lcall	_eeprom_read_byte
      009207 AF 82            [24] 2577 	mov	r7, dpl
      009209 90 0B 77         [24] 2578 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      00920C EF               [12] 2579 	mov	a,r7
      00920D F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	quantum/dynamic_keymap.c:716: if (data[3] != 0) {
      00920E EF               [12] 2582 	mov	a,r7
      00920F 70 02            [24] 2583 	jnz	00452$
      009211 21 00            [12] 2584 	ajmp	00167$
      009213                       2585 00452$:
                                   2586 ;	quantum/dynamic_keymap.c:719: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009213 90 0B 76         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      009216 E0               [24] 2588 	movx	a,@dptr
      009217 FF               [12] 2589 	mov	r7,a
      009218 90 0B 77         [24] 2590 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      00921B E0               [24] 2591 	movx	a,@dptr
      00921C FD               [12] 2592 	mov	r5,a
      00921D E4               [12] 2593 	clr	a
      00921E FE               [12] 2594 	mov	r6,a
      00921F FC               [12] 2595 	mov	r4,a
      009220 EF               [12] 2596 	mov	a,r7
      009221 42 06            [12] 2597 	orl	ar6,a
      009223 EC               [12] 2598 	mov	a,r4
      009224 42 05            [12] 2599 	orl	ar5,a
                                   2600 ;	quantum/dynamic_keymap.c:723: kc = decode_keycode(kc);
      009226 8E 82            [24] 2601 	mov	dpl, r6
      009228 8D 83            [24] 2602 	mov	dph, r5
      00922A 11 3F            [12] 2603 	acall	_decode_keycode
      00922C 12 45 C4         [24] 2604 	lcall	_ak820_outline_0125
                                   2605 ;	quantum/dynamic_keymap.c:725: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00922F 90 0B 75         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009232 E0               [24] 2607 	movx	a,@dptr
      009233 FD               [12] 2608 	mov	r5,a
      009234 BD 05 03         [24] 2609 	cjne	r5,#0x05,00453$
      009237 D3               [12] 2610 	setb	c
      009238 80 01            [24] 2611 	sjmp	00454$
      00923A                       2612 00453$:
      00923A C3               [12] 2613 	clr	c
      00923B                       2614 00454$:
      00923B 92 25            [24] 2615 	mov	_dynamic_keymap_macro_send_sloc1_1_0,c
      00923D 90 09 B8         [24] 2616 	mov	dptr,#_ak820_macro_primitive
      009240 B3               [12] 2617 	cpl	c
      009241 E4               [12] 2618 	clr	a
      009242 33               [12] 2619 	rlc	a
      009243 F0               [24] 2620 	movx	@dptr,a
                                   2621 ;	quantum/dynamic_keymap.c:727: switch (data[1]) {
      009244 90 0B 75         [24] 2622 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      009247 E0               [24] 2623 	movx	a,@dptr
      009248 FD               [12] 2624 	mov	r5,a
      009249 BD 05 02         [24] 2625 	cjne	r5,#0x05,00455$
      00924C 80 0A            [24] 2626 	sjmp	00126$
      00924E                       2627 00455$:
      00924E BD 06 02         [24] 2628 	cjne	r5,#0x06,00456$
      009251 80 0D            [24] 2629 	sjmp	00127$
      009253                       2630 00456$:
                                   2631 ;	quantum/dynamic_keymap.c:728: case VIAL_MACRO_EXT_TAP:
      009253 BD 07 18         [24] 2632 	cjne	r5,#0x07,00129$
      009256 80 10            [24] 2633 	sjmp	00128$
      009258                       2634 00126$:
                                   2635 ;	quantum/dynamic_keymap.c:729: vial_keycode_tap(kc);
      009258 12 3A FA         [24] 2636 	lcall	_ak820_outline_0118
      00925B 12 B6 8B         [24] 2637 	lcall	_vial_keycode_tap
                                   2638 ;	quantum/dynamic_keymap.c:730: break;
                                   2639 ;	quantum/dynamic_keymap.c:731: case VIAL_MACRO_EXT_DOWN:
      00925E 80 0E            [24] 2640 	sjmp	00129$
      009260                       2641 00127$:
                                   2642 ;	quantum/dynamic_keymap.c:732: vial_keycode_down(kc);
      009260 12 3A FA         [24] 2643 	lcall	_ak820_outline_0118
      009263 12 B5 C0         [24] 2644 	lcall	_vial_keycode_down
                                   2645 ;	quantum/dynamic_keymap.c:733: break;
                                   2646 ;	quantum/dynamic_keymap.c:734: case VIAL_MACRO_EXT_UP:
      009266 80 06            [24] 2647 	sjmp	00129$
      009268                       2648 00128$:
                                   2649 ;	quantum/dynamic_keymap.c:735: vial_keycode_up(kc);
      009268 12 3A FA         [24] 2650 	lcall	_ak820_outline_0118
      00926B 12 B6 26         [24] 2651 	lcall	_vial_keycode_up
                                   2652 ;	quantum/dynamic_keymap.c:737: }
      00926E                       2653 00129$:
                                   2654 ;	quantum/dynamic_keymap.c:739: ak820_macro_primitive = false;
      00926E 12 93 5F         [24] 2655 	lcall	_ak820_outline_0168
      009271 21 00            [12] 2656 	ajmp	00167$
      009273                       2657 00147$:
                                   2658 ;	quantum/dynamic_keymap.c:743: } else if (data[1] == SS_DELAY_CODE) {
      009273 12 93 26         [24] 2659 	lcall	_ak820_outline_0094
      009276 BF 04 02         [24] 2660 	cjne	r7,#0x04,00458$
      009279 80 02            [24] 2661 	sjmp	00459$
      00927B                       2662 00458$:
      00927B 21 00            [12] 2663 	ajmp	00167$
      00927D                       2664 00459$:
                                   2665 ;	quantum/dynamic_keymap.c:745: uint8_t d0 = eeprom_read_byte(p++);
      00927D 12 92 F1         [24] 2666 	lcall	_ak820_outline_0000
      009280 12 42 E2         [24] 2667 	lcall	_eeprom_read_byte
      009283 AF 82            [24] 2668 	mov	r7, dpl
                                   2669 ;	quantum/dynamic_keymap.c:746: uint8_t d1 = eeprom_read_byte(p++);
      009285 90 0B 71         [24] 2670 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009288 12 3A C6         [24] 2671 	lcall	_ak820_outline_0061
      00928B A3               [24] 2672 	inc	dptr
      00928C E0               [24] 2673 	movx	a,@dptr
      00928D FE               [12] 2674 	mov	r6,a
      00928E 90 0B 71         [24] 2675 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      009291 74 01            [12] 2676 	mov	a,#0x01
      009293 2C               [12] 2677 	add	a, r4
      009294 F0               [24] 2678 	movx	@dptr,a
      009295 E4               [12] 2679 	clr	a
      009296 3D               [12] 2680 	addc	a, r5
      009297 A3               [24] 2681 	inc	dptr
      009298 F0               [24] 2682 	movx	@dptr,a
      009299 EE               [12] 2683 	mov	a,r6
      00929A A3               [24] 2684 	inc	dptr
      00929B 12 3A E4         [24] 2685 	lcall	_ak820_outline_0096
      00929E 8E F0            [24] 2686 	mov	b, r6
      0092A0 12 42 E2         [24] 2687 	lcall	_eeprom_read_byte
      0092A3 AE 82            [24] 2688 	mov	r6, dpl
                                   2689 ;	quantum/dynamic_keymap.c:747: if (d0 == 0 || d1 == 0)
      0092A5 EF               [12] 2690 	mov	a,r7
      0092A6 60 41            [24] 2691 	jz	00169$
      0092A8 EE               [12] 2692 	mov	a,r6
      0092A9 60 3E            [24] 2693 	jz	00169$
                                   2694 ;	quantum/dynamic_keymap.c:750: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0092AB 1F               [12] 2695 	dec	r7
      0092AC 1E               [12] 2696 	dec	r6
      0092AD EE               [12] 2697 	mov	a,r6
      0092AE 75 F0 FF         [24] 2698 	mov	b,#0xff
      0092B1 A4               [48] 2699 	mul	ab
      0092B2 FE               [12] 2700 	mov	r6,a
      0092B3 AD F0            [24] 2701 	mov	r5,b
      0092B5 7C 00            [12] 2702 	mov	r4,#0x00
      0092B7 EE               [12] 2703 	mov	a,r6
      0092B8 2F               [12] 2704 	add	a, r7
      0092B9 FE               [12] 2705 	mov	r6,a
      0092BA ED               [12] 2706 	mov	a,r5
      0092BB 3C               [12] 2707 	addc	a, r4
      0092BC FD               [12] 2708 	mov	r5,a
                                   2709 ;	quantum/dynamic_keymap.c:751: while (ms--) wait_ms(1);
      0092BD                       2710 00141$:
      0092BD 8E 04            [24] 2711 	mov	ar4,r6
      0092BF 8D 07            [24] 2712 	mov	ar7,r5
      0092C1 1E               [12] 2713 	dec	r6
      0092C2 BE FF 01         [24] 2714 	cjne	r6,#0xff,00462$
      0092C5 1D               [12] 2715 	dec	r5
      0092C6                       2716 00462$:
      0092C6 EC               [12] 2717 	mov	a,r4
      0092C7 4F               [12] 2718 	orl	a,r7
      0092C8 70 02            [24] 2719 	jnz	00463$
      0092CA 21 00            [12] 2720 	ajmp	00167$
      0092CC                       2721 00463$:
      0092CC 90 00 01         [24] 2722 	mov	dptr,#0x0001
      0092CF 12 5D 8C         [24] 2723 	lcall	_mDelaymS
      0092D2 80 E9            [24] 2724 	sjmp	00141$
      0092D4                       2725 00164$:
                                   2726 ;	quantum/dynamic_keymap.c:757: if ((uint8_t)data[0] >= 128) break;
      0092D4 90 0B 74         [24] 2727 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0092D7 E0               [24] 2728 	movx	a,@dptr
      0092D8 FF               [12] 2729 	mov	r7,a
      0092D9 BF 80 00         [24] 2730 	cjne	r7,#0x80,00464$
      0092DC                       2731 00464$:
      0092DC 50 0B            [24] 2732 	jnc	00169$
                                   2733 ;	quantum/dynamic_keymap.c:761: send_char(data[0]);
      0092DE 90 0B 74         [24] 2734 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      0092E1 E0               [24] 2735 	movx	a,@dptr
      0092E2 F5 82            [12] 2736 	mov	dpl,a
      0092E4 12 A9 41         [24] 2737 	lcall	_send_char
                                   2738 ;	quantum/dynamic_keymap.c:762: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      0092E7 21 00            [12] 2739 	ajmp	00167$
      0092E9                       2740 00169$:
                                   2741 ;	quantum/dynamic_keymap.c:770: ak820_macro_primitive = false;
      0092E9 12 93 5F         [24] 2742 	lcall	_ak820_outline_0168
                                   2743 ;	quantum/dynamic_keymap.c:772: sending = false;
      0092EC 90 0B 70         [24] 2744 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      0092EF F0               [24] 2745 	movx	@dptr,a
                                   2746 ;	quantum/dynamic_keymap.c:774: }
      0092F0 22               [24] 2747 	ret
                                   2748 	.area CSEG    (CODE)
                                   2749 	.area CONST   (CODE)
                                   2750 	.area XINIT   (CODE)
                                   2751 	.area CABS    (ABS,CODE)
                                   2752 
                                   2753 ; Experimental exact instruction outlining.
                                   2754 	.globl _ak820_outline_0000
                                   2755 	.globl _ak820_outline_0005
                                   2756 	.globl _ak820_outline_0008
                                   2757 	.globl _ak820_outline_0013
                                   2758 	.globl _ak820_outline_0022
                                   2759 	.globl _ak820_outline_0033
                                   2760 	.globl _ak820_outline_0034
                                   2761 	.globl _ak820_outline_0050
                                   2762 	.globl _ak820_outline_0052
                                   2763 	.globl _ak820_outline_0059
                                   2764 	.globl _ak820_outline_0060
                                   2765 	.globl _ak820_outline_0061
                                   2766 	.globl _ak820_outline_0072
                                   2767 	.globl _ak820_outline_0074
                                   2768 	.globl _ak820_outline_0075
                                   2769 	.globl _ak820_outline_0077
                                   2770 	.globl _ak820_outline_0079
                                   2771 	.globl _ak820_outline_0082
                                   2772 	.globl _ak820_outline_0086
                                   2773 	.globl _ak820_outline_0093
                                   2774 	.globl _ak820_outline_0094
                                   2775 	.globl _ak820_outline_0096
                                   2776 	.globl _ak820_outline_0100
                                   2777 	.globl _ak820_outline_0101
                                   2778 	.globl _ak820_outline_0107
                                   2779 	.globl _ak820_outline_0108
                                   2780 	.globl _ak820_outline_0115
                                   2781 	.globl _ak820_outline_0116
                                   2782 	.globl _ak820_outline_0118
                                   2783 	.globl _ak820_outline_0123
                                   2784 	.globl _ak820_outline_0124
                                   2785 	.globl _ak820_outline_0125
                                   2786 	.globl _ak820_outline_0129
                                   2787 	.globl _ak820_outline_0133
                                   2788 	.globl _ak820_outline_0134
                                   2789 	.globl _ak820_outline_0135
                                   2790 	.globl _ak820_outline_0143
                                   2791 	.globl _ak820_outline_0144
                                   2792 	.globl _ak820_outline_0151
                                   2793 	.globl _ak820_outline_0152
                                   2794 	.globl _ak820_outline_0155
                                   2795 	.globl _ak820_outline_0156
                                   2796 	.globl _ak820_outline_0161
                                   2797 	.globl _ak820_outline_0163
                                   2798 	.globl _ak820_outline_0168
                                   2799 	.globl _ak820_outline_0177
                                   2800 	.globl _ak820_outline_0178
                                   2801 	.globl _ak820_outline_0181
                                   2802 	.globl _ak820_outline_0182
                                   2803 	.globl _ak820_outline_0185
                                   2804 	.globl _ak820_outline_0187
                                   2805 	.globl _ak820_outline_0189
                                   2806 
                                   2807 	.area CSEG (CODE)
                                   2808 ; function ak820_outline_0000
      0092F1                       2809 _ak820_outline_0000:
      0092F1 90 0B 71         [24] 2810 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0092F4 E0               [24] 2811 	movx	a,@dptr
      0092F5 FD               [12] 2812 	mov	r5,a
      0092F6 A3               [24] 2813 	inc	dptr
      0092F7 E0               [24] 2814 	movx	a,@dptr
      0092F8 FE               [12] 2815 	mov	r6,a
      0092F9 A3               [24] 2816 	inc	dptr
      0092FA E0               [24] 2817 	movx	a,@dptr
      0092FB FF               [12] 2818 	mov	r7,a
      0092FC 90 0B 71         [24] 2819 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      0092FF 74 01            [12] 2820 	mov	a,#0x01
      009301 2D               [12] 2821 	add	a,r5
      009302 F0               [24] 2822 	movx	@dptr,a
      009303 E4               [12] 2823 	clr	a
      009304 3E               [12] 2824 	addc	a,r6
      009305 A3               [24] 2825 	inc	dptr
      009306 F0               [24] 2826 	movx	@dptr,a
      009307 EF               [12] 2827 	mov	a,r7
      009308 A3               [24] 2828 	inc	dptr
      009309 F0               [24] 2829 	movx	@dptr,a
      00930A 8D 82            [24] 2830 	mov	dpl,r5
      00930C 8E 83            [24] 2831 	mov	dph,r6
      00930E 8F F0            [24] 2832 	mov	b,r7
      009310 22               [24] 2833 	ret
                                   2834 
                                   2835 	.area CSEG (CODE)
                                   2836 ; function ak820_outline_0075
      009311                       2837 _ak820_outline_0075:
      009311 74 0A            [12] 2838 	mov	a,#0x0a
      009313 F0               [24] 2839 	movx	@dptr,a
      009314 E4               [12] 2840 	clr	a
      009315 A3               [24] 2841 	inc	dptr
      009316 F0               [24] 2842 	movx	@dptr,a
      009317 22               [24] 2843 	ret
                                   2844 
                                   2845 	.area CSEG (CODE)
                                   2846 ; function ak820_outline_0082
      009318                       2847 _ak820_outline_0082:
      009318 ED               [12] 2848 	mov	a,r5
      009319 75 F0 0A         [24] 2849 	mov	b,#0x0a
      00931C A4               [48] 2850 	mul	ab
      00931D 24 58            [12] 2851 	add	a,#0x58
      00931F FC               [12] 2852 	mov	r4,a
      009320 74 06            [12] 2853 	mov	a,#0x06
      009322 35 F0            [12] 2854 	addc	a,b
      009324 FD               [12] 2855 	mov	r5,a
      009325 22               [24] 2856 	ret
                                   2857 
                                   2858 	.area CSEG (CODE)
                                   2859 ; function ak820_outline_0094
      009326                       2860 _ak820_outline_0094:
      009326 90 0B 75         [24] 2861 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      009329 E0               [24] 2862 	movx	a,@dptr
      00932A FF               [12] 2863 	mov	r7,a
      00932B 22               [24] 2864 	ret
                                   2865 
                                   2866 	.area CSEG (CODE)
                                   2867 ; function ak820_outline_0100
      00932C                       2868 _ak820_outline_0100:
      00932C 90 0B 0A         [24] 2869 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00932F EE               [12] 2870 	mov	a,r6
      009330 F0               [24] 2871 	movx	@dptr,a
      009331 90 0B 0B         [24] 2872 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009334 ED               [12] 2873 	mov	a,r5
      009335 F0               [24] 2874 	movx	@dptr,a
      009336 8F 82            [24] 2875 	mov	dpl,r7
      009338 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0115
      009339                       2880 _ak820_outline_0115:
      009339 AD 82            [24] 2881 	mov	r5,dpl
      00933B AE 83            [24] 2882 	mov	r6,dph
      00933D AF F0            [24] 2883 	mov	r7,b
      00933F 22               [24] 2884 	ret
                                   2885 
                                   2886 	.area CSEG (CODE)
                                   2887 ; function ak820_outline_0129
      009340                       2888 _ak820_outline_0129:
      009340 28               [12] 2889 	add	a,r0
      009341 F5 82            [12] 2890 	mov	dpl,a
      009343 EF               [12] 2891 	mov	a,r7
      009344 39               [12] 2892 	addc	a,r1
      009345 F5 83            [12] 2893 	mov	dph,a
      009347 74 FF            [12] 2894 	mov	a,#0xff
      009349 F0               [24] 2895 	movx	@dptr,a
      00934A 22               [24] 2896 	ret
                                   2897 
                                   2898 	.area CSEG (CODE)
                                   2899 ; function ak820_outline_0134
      00934B                       2900 _ak820_outline_0134:
      00934B 2D               [12] 2901 	add	a,r5
      00934C F9               [12] 2902 	mov	r1,a
      00934D E4               [12] 2903 	clr	a
      00934E 3E               [12] 2904 	addc	a,r6
      00934F FA               [12] 2905 	mov	r2,a
      009350 22               [24] 2906 	ret
                                   2907 
                                   2908 	.area CSEG (CODE)
                                   2909 ; function ak820_outline_0155
      009351                       2910 _ak820_outline_0155:
      009351 89 82            [24] 2911 	mov	dpl,r1
      009353 8A 83            [24] 2912 	mov	dph,r2
      009355 8B F0            [24] 2913 	mov	b,r3
      009357 22               [24] 2914 	ret
                                   2915 
                                   2916 	.area CSEG (CODE)
                                   2917 ; function ak820_outline_0156
      009358                       2918 _ak820_outline_0156:
      009358 90 0B 76         [24] 2919 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00935B E0               [24] 2920 	movx	a,@dptr
      00935C F5 82            [12] 2921 	mov	dpl,a
      00935E 22               [24] 2922 	ret
                                   2923 
                                   2924 	.area CSEG (CODE)
                                   2925 ; function ak820_outline_0168
      00935F                       2926 _ak820_outline_0168:
      00935F 90 09 B8         [24] 2927 	mov	dptr,#_ak820_macro_primitive
      009362 E4               [12] 2928 	clr	a
      009363 F0               [24] 2929 	movx	@dptr,a
      009364 22               [24] 2930 	ret
                                   2931 
                                   2932 	.area CSEG (CODE)
                                   2933 ; function ak820_outline_0177
      009365                       2934 _ak820_outline_0177:
      009365 90 0B 1A         [24] 2935 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      009368 E4               [12] 2936 	clr	a
      009369 F0               [24] 2937 	movx	@dptr,a
      00936A 90 0B 1B         [24] 2938 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00936D 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0178
      00936E                       2943 _ak820_outline_0178:
      00936E 90 0B D1         [24] 2944 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009371 E4               [12] 2945 	clr	a
      009372 F0               [24] 2946 	movx	@dptr,a
      009373 90 0B D2         [24] 2947 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      009376 22               [24] 2948 	ret
                                   2949 
                                   2950 	.area CSEG (CODE)
                                   2951 ; function ak820_outline_0181
      009377                       2952 _ak820_outline_0181:
      009377 AF 82            [24] 2953 	mov	r7,dpl
      009379 90 0B 76         [24] 2954 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      00937C EF               [12] 2955 	mov	a,r7
      00937D F0               [24] 2956 	movx	@dptr,a
      00937E EF               [12] 2957 	mov	a,r7
      00937F 22               [24] 2958 	ret
