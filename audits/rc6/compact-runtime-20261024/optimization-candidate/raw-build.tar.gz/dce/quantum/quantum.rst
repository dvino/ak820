                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000026                        582 _get_record_keycode_sloc0_1_0:
      000026                        583 	.ds 1
      000027                        584 _pre_process_record_quantum_sloc0_1_0:
      000027                        585 	.ds 1
      000028                        586 _process_ak820_nkro_sloc0_1_0:
      000028                        587 	.ds 1
                                    588 ;--------------------------------------------------------
                                    589 ; paged external ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area PSEG    (PAG,XDATA)
                                    592 ;--------------------------------------------------------
                                    593 ; uninitialized external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XSEG    (XDATA)
      000C0C                        596 _extract_mod_bits_code_10000_600:
      000C0C                        597 	.ds 2
      000C0E                        598 _register_code16_code_10000_606:
      000C0E                        599 	.ds 2
      000C10                        600 _unregister_code16_code_10000_611:
      000C10                        601 	.ds 2
      000C12                        602 _pre_process_record_kb_PARM_2:
      000C12                        603 	.ds 3
      000C15                        604 _pre_process_record_kb_keycode_10000_625:
      000C15                        605 	.ds 2
      000C17                        606 _pre_process_record_user_PARM_2:
      000C17                        607 	.ds 3
      000C1A                        608 _process_record_kb_PARM_2:
      000C1A                        609 	.ds 3
      000C1D                        610 _process_record_kb_keycode_10000_631:
      000C1D                        611 	.ds 2
      000C1F                        612 _process_record_user_PARM_2:
      000C1F                        613 	.ds 3
      000C22                        614 _post_process_record_kb_PARM_2:
      000C22                        615 	.ds 3
      000C25                        616 _post_process_record_kb_keycode_10000_635:
      000C25                        617 	.ds 2
      000C27                        618 _post_process_record_user_PARM_2:
      000C27                        619 	.ds 3
      000C2A                        620 _get_record_keycode_PARM_2:
      000C2A                        621 	.ds 1
      000C2B                        622 _get_record_keycode_record_argument_10000_649:
      000C2B                        623 	.ds 3
      000C2E                        624 _pre_process_record_quantum_record_argument_10000_655:
      000C2E                        625 	.ds 3
      000C31                        626 _post_process_record_quantum_record_10000_657:
      000C31                        627 	.ds 3
      000C34                        628 _process_record_quantum_record_10000_659:
      000C34                        629 	.ds 3
      000C37                        630 _process_ak820_nkro_PARM_2:
      000C37                        631 	.ds 3
      000C3A                        632 _process_ak820_nkro_keycode_10000_661:
      000C3A                        633 	.ds 2
      000C3C                        634 _process_record_quantum_helper_PARM_2:
      000C3C                        635 	.ds 3
      000C3F                        636 _process_record_quantum_helper_keycode_10000_666:
      000C3F                        637 	.ds 2
      000C41                        638 _get_u8_str_last_num_10000_692:
      000C41                        639 	.ds 1
      000C42                        640 _get_u16_str_last_num_10000_696:
      000C42                        641 	.ds 2
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
                                    650 	.area HOME    (CODE)
                                    651 	.area GSINIT0 (CODE)
                                    652 	.area GSINIT1 (CODE)
                                    653 	.area GSINIT2 (CODE)
                                    654 	.area GSINIT3 (CODE)
                                    655 	.area GSINIT4 (CODE)
                                    656 	.area GSINIT5 (CODE)
                                    657 	.area GSINIT  (CODE)
                                    658 	.area GSFINAL (CODE)
                                    659 	.area CSEG    (CODE)
                                    660 ;--------------------------------------------------------
                                    661 ; global & static initialisations
                                    662 ;--------------------------------------------------------
                                    663 	.area HOME    (CODE)
                                    664 	.area GSINIT  (CODE)
                                    665 	.area GSFINAL (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 ;------------------------------------------------------------
                                    668 ;Allocation info for local variables in function 'get_u8_str'
                                    669 ;------------------------------------------------------------
                                    670 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    671 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_691'
                                    672 ;buf           Allocated with name '_get_u8_str_buf_10000_692'
                                    673 ;last_num      Allocated with name '_get_u8_str_last_num_10000_692'
                                    674 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_692'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/quantum.c:736: static uint8_t last_num = 0xFF;
      003121 90 0C 41         [24]  677 	mov	dptr,#_get_u8_str_last_num_10000_692
      003124 74 FF            [12]  678 	mov	a,#0xff
      003126 F0               [24]  679 	movx	@dptr,a
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'get_u16_str'
                                    682 ;------------------------------------------------------------
                                    683 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    684 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_695'
                                    685 ;buf           Allocated with name '_get_u16_str_buf_10000_696'
                                    686 ;last_num      Allocated with name '_get_u16_str_last_num_10000_696'
                                    687 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_696'
                                    688 ;------------------------------------------------------------
                                    689 ;	quantum/quantum.c:756: static uint16_t last_num = 0xFF;
      003127 90 0C 42         [24]  690 	mov	dptr,#_get_u16_str_last_num_10000_696
      00312A 74 FF            [12]  691 	mov	a,#0xff
      00312C F0               [24]  692 	movx	@dptr,a
      00312D E4               [12]  693 	clr	a
      00312E A3               [24]  694 	inc	dptr
      00312F F0               [24]  695 	movx	@dptr,a
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    707 ;------------------------------------------------------------
                                    708 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    709 ;------------------------------------------------------------
                                    710 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function extract_mod_bits
                                    721 ;	-----------------------------------------
      00A1EC                        722 _extract_mod_bits:
      00A1EC 12 3A F0         [24]  723 	lcall	_ak820_outline_0107
      00A1EF 90 0C 0C         [24]  724 	mov	dptr,#_extract_mod_bits_code_10000_600
      00A1F2 12 3A F5         [24]  725 	lcall	_ak820_outline_0108
                                    726 ;	quantum/quantum.c:104: uint8_t mods = (uint8_t)(code >> 8);
      00A1F5 90 0C 0C         [24]  727 	mov	dptr,#_extract_mod_bits_code_10000_600
      00A1F8 E0               [24]  728 	movx	a,@dptr
      00A1F9 A3               [24]  729 	inc	dptr
      00A1FA E0               [24]  730 	movx	a,@dptr
                                    731 ;	quantum/quantum.c:105: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A1FB FF               [12]  732 	mov	r7,a
      00A1FC 60 05            [24]  733 	jz	00101$
      00A1FE EF               [12]  734 	mov	a,r7
      00A1FF 24 E0            [12]  735 	add	a,#0xff - 0x1f
      00A201 50 04            [24]  736 	jnc	00102$
                                    737 ;	free result
      00A203                        738 00101$:
      00A203 75 82 00         [24]  739 	mov	dpl, #0x00
      00A206 22               [24]  740 	ret
      00A207                        741 00102$:
                                    742 ;	quantum/quantum.c:106: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A207 EF               [12]  743 	mov	a,r7
      00A208 30 E4 07         [24]  744 	jnb	acc.4,00106$
      00A20B EF               [12]  745 	mov	a,r7
      00A20C C4               [12]  746 	swap	a
      00A20D 54 F0            [12]  747 	anl	a,#0xf0
      00A20F FE               [12]  748 	mov	r6,a
      00A210 80 02            [24]  749 	sjmp	00107$
      00A212                        750 00106$:
      00A212 8F 06            [24]  751 	mov	ar6,r7
      00A214                        752 00107$:
      00A214 8E 82            [24]  753 	mov	dpl, r6
                                    754 ;	quantum/quantum.c:134: }
      00A216 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'do_code16'
                                    758 ;------------------------------------------------------------
                                    759 ;f             Allocated with name '_do_code16_PARM_2'
                                    760 ;code          Allocated with name '_do_code16_code_10000_603'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/quantum.c:136: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function register_code16
                                    765 ;	-----------------------------------------
      00A217                        766 _register_code16:
      00A217 12 3A F0         [24]  767 	lcall	_ak820_outline_0107
      00A21A 90 0C 0E         [24]  768 	mov	dptr,#_register_code16_code_10000_606
      00A21D 12 3A F5         [24]  769 	lcall	_ak820_outline_0108
                                    770 ;	quantum/quantum.c:142: uint8_t mods = extract_mod_bits(code);
      00A220 90 0C 0E         [24]  771 	mov	dptr,#_register_code16_code_10000_606
      00A223 12 3A 62         [24]  772 	lcall	_ak820_outline_0005
      00A226 C0 07            [24]  773 	push	ar7
      00A228 C0 06            [24]  774 	push	ar6
      00A22A 31 EC            [12]  775 	acall	_extract_mod_bits
      00A22C AD 82            [24]  776 	mov	r5, dpl
      00A22E D0 06            [24]  777 	pop	ar6
      00A230 D0 07            [24]  778 	pop	ar7
                                    779 ;	quantum/quantum.c:143: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A232 12 A0 27         [24]  780 	lcall	_ak820_outline_0119
      00A235 40 07            [24]  781 	jc	00105$
      00A237 74 E7            [12]  782 	mov	a,#0xe7
      00A239 9E               [12]  783 	subb	a,r6
      00A23A E4               [12]  784 	clr	a
      00A23B 9F               [12]  785 	subb	a,r7
      00A23C 50 08            [24]  786 	jnc	00101$
                                    787 ;	free result
      00A23E                        788 00105$:
      00A23E 90 0C 0E         [24]  789 	mov	dptr,#_register_code16_code_10000_606
      00A241 12 72 50         [24]  790 	lcall	_ak820_outline_0040
      00A244 70 07            [24]  791 	jnz	00102$
      00A246                        792 00101$:
                                    793 ;	quantum/quantum.c:144: register_mods(mods);
      00A246 8D 82            [24]  794 	mov	dpl, r5
      00A248 12 7B 82         [24]  795 	lcall	_register_mods
      00A24B 80 05            [24]  796 	sjmp	00103$
      00A24D                        797 00102$:
                                    798 ;	quantum/quantum.c:146: register_weak_mods(mods);
      00A24D 8D 82            [24]  799 	mov	dpl, r5
      00A24F 12 7B AA         [24]  800 	lcall	_register_weak_mods
      00A252                        801 00103$:
                                    802 ;	quantum/quantum.c:148: register_code(code);
      00A252 90 0C 0E         [24]  803 	mov	dptr,#_register_code16_code_10000_606
      00A255 E0               [24]  804 	movx	a,@dptr
      00A256 F5 82            [12]  805 	mov	dpl,a
                                    806 ;	quantum/quantum.c:158: }
      00A258 02 7A 35         [24]  807 	ljmp	_register_code
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'unregister_code16'
                                    810 ;------------------------------------------------------------
                                    811 ;code          Allocated with name '_unregister_code16_code_10000_611'
                                    812 ;mods          Allocated with name '_unregister_code16_mods_10000_612'
                                    813 ;------------------------------------------------------------
                                    814 ;	quantum/quantum.c:160: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    815 ;	-----------------------------------------
                                    816 ;	 function unregister_code16
                                    817 ;	-----------------------------------------
      00A25B                        818 _unregister_code16:
      00A25B 12 3A F0         [24]  819 	lcall	_ak820_outline_0107
      00A25E 90 0C 10         [24]  820 	mov	dptr,#_unregister_code16_code_10000_611
      00A261 12 3A F5         [24]  821 	lcall	_ak820_outline_0108
                                    822 ;	quantum/quantum.c:162: uint8_t mods = extract_mod_bits(code);
      00A264 90 0C 10         [24]  823 	mov	dptr,#_unregister_code16_code_10000_611
      00A267 12 3A 62         [24]  824 	lcall	_ak820_outline_0005
      00A26A C0 07            [24]  825 	push	ar7
      00A26C C0 06            [24]  826 	push	ar6
      00A26E 31 EC            [12]  827 	acall	_extract_mod_bits
      00A270 AD 82            [24]  828 	mov	r5, dpl
      00A272 D0 06            [24]  829 	pop	ar6
                                    830 ;	quantum/quantum.c:163: unregister_code(code);
      00A274 8E 04            [24]  831 	mov	ar4,r6
      00A276 8C 82            [24]  832 	mov	dpl, r4
      00A278 C0 06            [24]  833 	push	ar6
      00A27A C0 05            [24]  834 	push	ar5
      00A27C 12 7A BA         [24]  835 	lcall	_unregister_code
      00A27F D0 05            [24]  836 	pop	ar5
      00A281 D0 06            [24]  837 	pop	ar6
      00A283 D0 07            [24]  838 	pop	ar7
                                    839 ;	quantum/quantum.c:164: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A285 12 A0 27         [24]  840 	lcall	_ak820_outline_0119
      00A288 40 07            [24]  841 	jc	00105$
      00A28A 74 E7            [12]  842 	mov	a,#0xe7
      00A28C 9E               [12]  843 	subb	a,r6
      00A28D E4               [12]  844 	clr	a
      00A28E 9F               [12]  845 	subb	a,r7
      00A28F 50 08            [24]  846 	jnc	00101$
                                    847 ;	free result
      00A291                        848 00105$:
      00A291 90 0C 10         [24]  849 	mov	dptr,#_unregister_code16_code_10000_611
      00A294 12 72 50         [24]  850 	lcall	_ak820_outline_0040
      00A297 70 05            [24]  851 	jnz	00102$
      00A299                        852 00101$:
                                    853 ;	quantum/quantum.c:165: unregister_mods(mods);
      00A299 8D 82            [24]  854 	mov	dpl, r5
      00A29B 02 7B 96         [24]  855 	ljmp	_unregister_mods
      00A29E                        856 00102$:
                                    857 ;	quantum/quantum.c:167: unregister_weak_mods(mods);
      00A29E 8D 82            [24]  858 	mov	dpl, r5
                                    859 ;	quantum/quantum.c:178: }
      00A2A0 02 7B BE         [24]  860 	ljmp	_unregister_weak_mods
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'tap_code16_delay'
                                    863 ;------------------------------------------------------------
                                    864 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    865 ;code          Allocated with name '_tap_code16_delay_code_10000_616'
                                    866 ;i             Allocated with name '_tap_code16_delay_i_20000_618'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_50000_621'
                                    868 ;------------------------------------------------------------
                                    869 ;	quantum/quantum.c:185: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function pre_process_record_kb
                                    872 ;	-----------------------------------------
      00A2A3                        873 _pre_process_record_kb:
      00A2A3 12 3A F0         [24]  874 	lcall	_ak820_outline_0107
      00A2A6 90 0C 15         [24]  875 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A2A9 12 3A F5         [24]  876 	lcall	_ak820_outline_0108
                                    877 ;	quantum/quantum.c:202: return pre_process_record_user(keycode, record);
      00A2AC 90 0C 15         [24]  878 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A2AF 12 3A AF         [24]  879 	lcall	_ak820_outline_0052
      00A2B2 90 0C 12         [24]  880 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A2B5 12 A0 1E         [24]  881 	lcall	_ak820_outline_0026
      00A2B8 90 0C 17         [24]  882 	mov	dptr,#_pre_process_record_user_PARM_2
      00A2BB 12 A5 E8         [24]  883 	lcall	_ak820_outline_0010
                                    884 ;	quantum/quantum.c:203: }
      00A2BE 41 C0            [12]  885 	ajmp	_pre_process_record_user
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'pre_process_record_user'
                                    888 ;------------------------------------------------------------
                                    889 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    890 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_627'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/quantum.c:205: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function pre_process_record_user
                                    895 ;	-----------------------------------------
      00A2C0                        896 _pre_process_record_user:
                                    897 ;	quantum/quantum.c:206: return true;
      00A2C0 75 82 01         [24]  898 	mov	dpl, #0x01
                                    899 ;	quantum/quantum.c:207: }
      00A2C3 22               [24]  900 	ret
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'process_action_kb'
                                    903 ;------------------------------------------------------------
                                    904 ;record        Allocated with name '_process_action_kb_record_10000_629'
                                    905 ;------------------------------------------------------------
                                    906 ;	quantum/quantum.c:209: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    907 ;	-----------------------------------------
                                    908 ;	 function process_action_kb
                                    909 ;	-----------------------------------------
      00A2C4                        910 _process_action_kb:
                                    911 ;	quantum/quantum.c:210: return true;
      00A2C4 75 82 01         [24]  912 	mov	dpl, #0x01
                                    913 ;	quantum/quantum.c:211: }
      00A2C7 22               [24]  914 	ret
                                    915 ;------------------------------------------------------------
                                    916 ;Allocation info for local variables in function 'process_record_kb'
                                    917 ;------------------------------------------------------------
                                    918 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    919 ;keycode       Allocated with name '_process_record_kb_keycode_10000_631'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/quantum.c:213: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function process_record_kb
                                    924 ;	-----------------------------------------
      00A2C8                        925 _process_record_kb:
      00A2C8 12 3A F0         [24]  926 	lcall	_ak820_outline_0107
      00A2CB 90 0C 1D         [24]  927 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A2CE 12 3A F5         [24]  928 	lcall	_ak820_outline_0108
                                    929 ;	quantum/quantum.c:214: return process_record_user(keycode, record);
      00A2D1 90 0C 1D         [24]  930 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A2D4 12 3A AF         [24]  931 	lcall	_ak820_outline_0052
      00A2D7 90 0C 1A         [24]  932 	mov	dptr,#_process_record_kb_PARM_2
      00A2DA 12 A0 1E         [24]  933 	lcall	_ak820_outline_0026
      00A2DD 90 0C 1F         [24]  934 	mov	dptr,#_process_record_user_PARM_2
      00A2E0 12 A5 E8         [24]  935 	lcall	_ak820_outline_0010
                                    936 ;	quantum/quantum.c:215: }
      00A2E3 41 E5            [12]  937 	ajmp	_process_record_user
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'process_record_user'
                                    940 ;------------------------------------------------------------
                                    941 ;record        Allocated with name '_process_record_user_PARM_2'
                                    942 ;keycode       Allocated with name '_process_record_user_keycode_10000_633'
                                    943 ;------------------------------------------------------------
                                    944 ;	quantum/quantum.c:217: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function process_record_user
                                    947 ;	-----------------------------------------
      00A2E5                        948 _process_record_user:
                                    949 ;	quantum/quantum.c:218: return true;
      00A2E5 75 82 01         [24]  950 	mov	dpl, #0x01
                                    951 ;	quantum/quantum.c:219: }
      00A2E8 22               [24]  952 	ret
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'post_process_record_kb'
                                    955 ;------------------------------------------------------------
                                    956 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    957 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_635'
                                    958 ;------------------------------------------------------------
                                    959 ;	quantum/quantum.c:221: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function post_process_record_kb
                                    962 ;	-----------------------------------------
      00A2E9                        963 _post_process_record_kb:
      00A2E9 12 3A F0         [24]  964 	lcall	_ak820_outline_0107
      00A2EC 90 0C 25         [24]  965 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A2EF 12 3A F5         [24]  966 	lcall	_ak820_outline_0108
                                    967 ;	quantum/quantum.c:222: post_process_record_user(keycode, record);
      00A2F2 90 0C 25         [24]  968 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A2F5 12 3A AF         [24]  969 	lcall	_ak820_outline_0052
      00A2F8 90 0C 22         [24]  970 	mov	dptr,#_post_process_record_kb_PARM_2
      00A2FB 12 A0 1E         [24]  971 	lcall	_ak820_outline_0026
      00A2FE 90 0C 27         [24]  972 	mov	dptr,#_post_process_record_user_PARM_2
      00A301 12 A5 E8         [24]  973 	lcall	_ak820_outline_0010
                                    974 ;	quantum/quantum.c:223: }
      00A304 61 06            [24]  975 	ajmp	_post_process_record_user
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'post_process_record_user'
                                    978 ;------------------------------------------------------------
                                    979 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    980 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_637'
                                    981 ;------------------------------------------------------------
                                    982 ;	quantum/quantum.c:225: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    983 ;	-----------------------------------------
                                    984 ;	 function post_process_record_user
                                    985 ;	-----------------------------------------
      00A306                        986 _post_process_record_user:
      00A306 22               [24]  987 	ret
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'shutdown_quantum'
                                    990 ;------------------------------------------------------------
                                    991 ;i             Allocated with name '_shutdown_quantum_i_30000_643'
                                    992 ;------------------------------------------------------------
                                    993 ;	quantum/quantum.c:227: void shutdown_quantum(void) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function shutdown_quantum
                                    996 ;	-----------------------------------------
      00A307                        997 _shutdown_quantum:
                                    998 ;	quantum/quantum.c:228: clear_keyboard();
      00A307 12 7B D2         [24]  999 	lcall	_clear_keyboard
                                   1000 ;	quantum/quantum.c:243: shutdown_user();
      00A30A B1 DA            [12] 1001 	acall	_shutdown_user
                                   1002 ;	quantum/quantum.c:244: wait_ms(250);
      00A30C 7F FA            [12] 1003 	mov	r7,#0xfa
      00A30E                       1004 00106$:
      00A30E EF               [12] 1005 	mov	a,r7
      00A30F 60 09            [24] 1006 	jz	00108$
      00A311 90 00 01         [24] 1007 	mov	dptr,#0x0001
      00A314 12 5D 8C         [24] 1008 	lcall	_mDelaymS
      00A317 1F               [12] 1009 	dec	r7
      00A318 80 F4            [24] 1010 	sjmp	00106$
      00A31A                       1011 00108$:
                                   1012 ;	quantum/quantum.c:249: }
      00A31A 22               [24] 1013 	ret
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'reset_keyboard'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/quantum.c:251: void reset_keyboard(void) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function reset_keyboard
                                   1020 ;	-----------------------------------------
      00A31B                       1021 _reset_keyboard:
                                   1022 ;	quantum/quantum.c:252: shutdown_quantum();
      00A31B 71 07            [24] 1023 	acall	_shutdown_quantum
                                   1024 ;	quantum/quantum.c:253: bootloader_jump();
                                   1025 ;	quantum/quantum.c:254: }
      00A31D 02 36 87         [24] 1026 	ljmp	_bootloader_jump
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/quantum.c:256: void soft_reset_keyboard(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function soft_reset_keyboard
                                   1033 ;	-----------------------------------------
      00A320                       1034 _soft_reset_keyboard:
                                   1035 ;	quantum/quantum.c:257: shutdown_quantum();
      00A320 71 07            [24] 1036 	acall	_shutdown_quantum
                                   1037 ;	quantum/quantum.c:258: mcu_reset();
                                   1038 ;	quantum/quantum.c:259: }
      00A322 02 36 7A         [24] 1039 	ljmp	_mcu_reset
                                   1040 ;------------------------------------------------------------
                                   1041 ;Allocation info for local variables in function 'get_record_keycode'
                                   1042 ;------------------------------------------------------------
                                   1043 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1044 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_649'
                                   1045 ;record        Allocated with name '_get_record_keycode_record_10000_650'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/quantum.c:262: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function get_record_keycode
                                   1050 ;	-----------------------------------------
      00A325                       1051 _get_record_keycode:
      00A325 12 45 7B         [24] 1052 	lcall	_ak820_outline_0036
      00A328 90 0C 2B         [24] 1053 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A32B 12 3A 8D         [24] 1054 	lcall	_ak820_outline_0016
                                   1055 ;	quantum/quantum.c:264: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A32E 90 0C 2B         [24] 1056 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A331 12 3A 6C         [24] 1057 	lcall	_ak820_outline_0007
                                   1058 ;	quantum/quantum.c:269: if (record->keycode) {
      00A334 4C               [12] 1059 	orl	a,r4
      00A335 60 04            [24] 1060 	jz	00102$
                                   1061 ;	quantum/quantum.c:270: return record->keycode;
      00A337 12 3A FF         [24] 1062 	lcall	_ak820_outline_0123
      00A33A 22               [24] 1063 	ret
      00A33B                       1064 00102$:
                                   1065 ;	quantum/quantum.c:274: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A33B 12 7C 3C         [24] 1066 	lcall	_ak820_outline_0021
      00A33E 7A 00            [12] 1067 	mov	r2,#0x00
      00A340 12 45 CF         [24] 1068 	lcall	_ak820_outline_0143
      00A343 12 3A 80         [24] 1069 	lcall	_ak820_outline_0009
      00A346 60 06            [24] 1070 	jz	00105$
      00A348 90 0C 2A         [24] 1071 	mov	dptr,#_get_record_keycode_PARM_2
      00A34B E0               [24] 1072 	movx	a,@dptr
      00A34C 70 04            [24] 1073 	jnz	00106$
      00A34E                       1074 00105$:
                                   1075 ;	assignBit
      00A34E C2 26            [12] 1076 	clr	_get_record_keycode_sloc0_1_0
      00A350 80 02            [24] 1077 	sjmp	00107$
      00A352                       1078 00106$:
                                   1079 ;	assignBit
      00A352 D2 26            [12] 1080 	setb	_get_record_keycode_sloc0_1_0
      00A354                       1081 00107$:
      00A354 90 09 9E         [24] 1082 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A357 A2 26            [12] 1083 	mov	c,_get_record_keycode_sloc0_1_0
      00A359 E4               [12] 1084 	clr	a
      00A35A 33               [12] 1085 	rlc	a
      00A35B F0               [24] 1086 	movx	@dptr,a
      00A35C 8D 82            [24] 1087 	mov	dpl, r5
      00A35E 8C 83            [24] 1088 	mov	dph, r4
                                   1089 ;	quantum/quantum.c:278: }
      00A360 02 7F D2         [24] 1090 	ljmp	_ak820_resolve_key
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'get_event_keycode'
                                   1093 ;------------------------------------------------------------
                                   1094 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1095 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_653'
                                   1096 ;------------------------------------------------------------
                                   1097 ;	quantum/quantum.c:286: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1098 ;	-----------------------------------------
                                   1099 ;	 function pre_process_record_quantum
                                   1100 ;	-----------------------------------------
      00A363                       1101 _pre_process_record_quantum:
      00A363 12 45 7B         [24] 1102 	lcall	_ak820_outline_0036
      00A366 90 0C 2E         [24] 1103 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A369 12 3A 8D         [24] 1104 	lcall	_ak820_outline_0016
                                   1105 ;	quantum/quantum.c:319: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A36C 90 0C 2E         [24] 1106 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A36F 12 3A AF         [24] 1107 	lcall	_ak820_outline_0052
                                   1108 ;	quantum/quantum.c:323: uint16_t keycode = get_record_keycode(record, true);
      00A372 12 74 9B         [24] 1109 	lcall	_ak820_outline_0154
      00A375 90 0C 2A         [24] 1110 	mov	dptr,#_get_record_keycode_PARM_2
      00A378 74 01            [12] 1111 	mov	a,#0x01
      00A37A 12 74 80         [24] 1112 	lcall	_ak820_outline_0103
      00A37D 8D F0            [24] 1113 	mov	b, r5
      00A37F C0 07            [24] 1114 	push	ar7
      00A381 C0 06            [24] 1115 	push	ar6
      00A383 71 25            [24] 1116 	acall	_get_record_keycode
      00A385 12 45 D5         [24] 1117 	lcall	_ak820_outline_0151
      00A388 D0 06            [24] 1118 	pop	ar6
      00A38A D0 07            [24] 1119 	pop	ar7
                                   1120 ;	quantum/quantum.c:325: record->keycode = keycode;
      00A38C 74 07            [12] 1121 	mov	a,#0x07
      00A38E 12 3A 9F         [24] 1122 	lcall	_ak820_outline_0022
      00A391 12 3A D2         [24] 1123 	lcall	_ak820_outline_0074
                                   1124 ;	quantum/quantum.c:327: return pre_process_record_kb(keycode, record) &&
      00A394 90 0C 12         [24] 1125 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A397 12 A5 DB         [24] 1126 	lcall	_ak820_outline_0002
      00A39A C0 07            [24] 1127 	push	ar7
      00A39C C0 06            [24] 1128 	push	ar6
      00A39E 51 A3            [12] 1129 	acall	_pre_process_record_kb
      00A3A0 E5 82            [12] 1130 	mov	a, dpl
      00A3A2 D0 06            [24] 1131 	pop	ar6
      00A3A4 D0 07            [24] 1132 	pop	ar7
      00A3A6 60 0A            [24] 1133 	jz	00103$
                                   1134 ;	quantum/quantum.c:330: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A3A8 12 3A FA         [24] 1135 	lcall	_ak820_outline_0118
      00A3AB 12 38 AF         [24] 1136 	lcall	_ak820_combo_process
      00A3AE E5 82            [12] 1137 	mov	a, dpl
      00A3B0 70 04            [24] 1138 	jnz	00104$
                                   1139 ;	quantum/quantum.c:335: true;
      00A3B2                       1140 00103$:
                                   1141 ;	assignBit
      00A3B2 C2 27            [12] 1142 	clr	_pre_process_record_quantum_sloc0_1_0
      00A3B4 80 02            [24] 1143 	sjmp	00105$
      00A3B6                       1144 00104$:
                                   1145 ;	assignBit
      00A3B6 D2 27            [12] 1146 	setb	_pre_process_record_quantum_sloc0_1_0
      00A3B8                       1147 00105$:
      00A3B8 A2 27            [12] 1148 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A3BA 12 3B 1F         [24] 1149 	lcall	_ak820_outline_0160
                                   1150 ;	quantum/quantum.c:336: }
      00A3BD 22               [24] 1151 	ret
                                   1152 ;------------------------------------------------------------
                                   1153 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1154 ;------------------------------------------------------------
                                   1155 ;record        Allocated with name '_post_process_record_quantum_record_10000_657'
                                   1156 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_658'
                                   1157 ;------------------------------------------------------------
                                   1158 ;	quantum/quantum.c:339: void post_process_record_quantum(keyrecord_t *record) {
                                   1159 ;	-----------------------------------------
                                   1160 ;	 function post_process_record_quantum
                                   1161 ;	-----------------------------------------
      00A3BE                       1162 _post_process_record_quantum:
      00A3BE 12 45 7B         [24] 1163 	lcall	_ak820_outline_0036
      00A3C1 90 0C 31         [24] 1164 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A3C4 12 3A 8D         [24] 1165 	lcall	_ak820_outline_0016
                                   1166 ;	quantum/quantum.c:340: uint16_t keycode = get_record_keycode(record, false);
      00A3C7 90 0C 31         [24] 1167 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A3CA 12 51 7C         [24] 1168 	lcall	_ak820_outline_0012
      00A3CD 90 0C 2A         [24] 1169 	mov	dptr,#_get_record_keycode_PARM_2
      00A3D0 E4               [12] 1170 	clr	a
      00A3D1 12 51 85         [24] 1171 	lcall	_ak820_outline_0034
      00A3D4 71 25            [24] 1172 	acall	_get_record_keycode
      00A3D6 12 45 C4         [24] 1173 	lcall	_ak820_outline_0125
                                   1174 ;	quantum/quantum.c:341: post_process_record_kb(keycode, record);
      00A3D9 90 0C 31         [24] 1175 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A3DC 12 A0 1E         [24] 1176 	lcall	_ak820_outline_0026
      00A3DF 90 0C 22         [24] 1177 	mov	dptr,#_post_process_record_kb_PARM_2
      00A3E2 12 A5 E8         [24] 1178 	lcall	_ak820_outline_0010
                                   1179 ;	quantum/quantum.c:342: }
      00A3E5 41 E9            [12] 1180 	ajmp	_post_process_record_kb
                                   1181 ;------------------------------------------------------------
                                   1182 ;Allocation info for local variables in function 'process_record_quantum'
                                   1183 ;------------------------------------------------------------
                                   1184 ;record        Allocated with name '_process_record_quantum_record_10000_659'
                                   1185 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_660'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/quantum.c:344: bool process_record_quantum(keyrecord_t *record) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function process_record_quantum
                                   1190 ;	-----------------------------------------
      00A3E7                       1191 _process_record_quantum:
      00A3E7 12 45 7B         [24] 1192 	lcall	_ak820_outline_0036
      00A3EA 90 0C 34         [24] 1193 	mov	dptr,#_process_record_quantum_record_10000_659
      00A3ED 12 3A 8D         [24] 1194 	lcall	_ak820_outline_0016
                                   1195 ;	quantum/quantum.c:346: uint16_t keycode = get_record_keycode(record, false);
      00A3F0 90 0C 34         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_659
      00A3F3 12 51 7C         [24] 1197 	lcall	_ak820_outline_0012
      00A3F6 90 0C 2A         [24] 1198 	mov	dptr,#_get_record_keycode_PARM_2
      00A3F9 E4               [12] 1199 	clr	a
      00A3FA 12 51 85         [24] 1200 	lcall	_ak820_outline_0034
      00A3FD 71 25            [24] 1201 	acall	_get_record_keycode
      00A3FF 12 45 C4         [24] 1202 	lcall	_ak820_outline_0125
                                   1203 ;	quantum/quantum.c:350: return process_record_quantum_helper(keycode, record);
      00A402 90 0C 34         [24] 1204 	mov	dptr,#_process_record_quantum_record_10000_659
      00A405 12 A0 1E         [24] 1205 	lcall	_ak820_outline_0026
      00A408 90 0C 3C         [24] 1206 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A40B 12 A5 E8         [24] 1207 	lcall	_ak820_outline_0010
                                   1208 ;	quantum/quantum.c:351: }
      00A40E 81 7B            [24] 1209 	ajmp	_process_record_quantum_helper
                                   1210 ;------------------------------------------------------------
                                   1211 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1212 ;------------------------------------------------------------
                                   1213 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1214 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_661'
                                   1215 ;record        Allocated with name '_process_ak820_nkro_record_10000_662'
                                   1216 ;------------------------------------------------------------
                                   1217 ;	quantum/quantum.c:358: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1218 ;	-----------------------------------------
                                   1219 ;	 function process_ak820_nkro
                                   1220 ;	-----------------------------------------
      00A410                       1221 _process_ak820_nkro:
      00A410 12 3A F0         [24] 1222 	lcall	_ak820_outline_0107
      00A413 90 0C 3A         [24] 1223 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A416 12 3A F5         [24] 1224 	lcall	_ak820_outline_0108
                                   1225 ;	quantum/quantum.c:360: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A419 90 0C 37         [24] 1226 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A41C 12 3A AF         [24] 1227 	lcall	_ak820_outline_0052
                                   1228 ;	quantum/quantum.c:364: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A41F 90 0C 3A         [24] 1229 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A422 12 3A C6         [24] 1230 	lcall	_ak820_outline_0061
      00A425 C3               [12] 1231 	clr	c
      00A426 EC               [12] 1232 	mov	a,r4
      00A427 94 11            [12] 1233 	subb	a,#0x11
      00A429 ED               [12] 1234 	mov	a,r5
      00A42A 94 70            [12] 1235 	subb	a,#0x70
      00A42C 40 08            [24] 1236 	jc	00101$
      00A42E 74 13            [12] 1237 	mov	a,#0x13
      00A430 9C               [12] 1238 	subb	a,r4
      00A431 74 70            [12] 1239 	mov	a,#0x70
      00A433 9D               [12] 1240 	subb	a,r5
      00A434 50 04            [24] 1241 	jnc	00102$
                                   1242 ;	free result
      00A436                       1243 00101$:
      00A436 75 82 01         [24] 1244 	mov	dpl, #0x01
      00A439 22               [24] 1245 	ret
      00A43A                       1246 00102$:
                                   1247 ;	quantum/quantum.c:365: if (record->event.pressed) {
      00A43A 12 3A 80         [24] 1248 	lcall	_ak820_outline_0009
      00A43D 60 38            [24] 1249 	jz	00105$
                                   1250 ;	quantum/quantum.c:366: clear_keyboard();
      00A43F C0 05            [24] 1251 	push	ar5
      00A441 C0 04            [24] 1252 	push	ar4
      00A443 12 7B D2         [24] 1253 	lcall	_clear_keyboard
      00A446 D0 04            [24] 1254 	pop	ar4
      00A448 D0 05            [24] 1255 	pop	ar5
                                   1256 ;	quantum/quantum.c:367: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A44A BC 13 14         [24] 1257 	cjne	r4,#0x13,00108$
      00A44D BD 70 11         [24] 1258 	cjne	r5,#0x70,00108$
      00A450 90 0A F0         [24] 1259 	mov	dptr,#_keymap_config
      00A453 E0               [24] 1260 	movx	a,@dptr
      00A454 23               [12] 1261 	rl	a
      00A455 54 01            [12] 1262 	anl	a,#0x01
      00A457 B4 01 00         [24] 1263 	cjne	a,#0x01,00136$
      00A45A                       1264 00136$:
      00A45A 92 28            [24] 1265 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A45C E4               [12] 1266 	clr	a
      00A45D 33               [12] 1267 	rlc	a
      00A45E FF               [12] 1268 	mov	r7,a
      00A45F 80 09            [24] 1269 	sjmp	00109$
      00A461                       1270 00108$:
      00A461 E4               [12] 1271 	clr	a
      00A462 BC 11 04         [24] 1272 	cjne	r4,#0x11,00137$
      00A465 BD 70 01         [24] 1273 	cjne	r5,#0x70,00137$
      00A468 04               [12] 1274 	inc	a
      00A469                       1275 00137$:
      00A469 FF               [12] 1276 	mov	r7,a
      00A46A                       1277 00109$:
                                   1278 ;	assignBit
      00A46A EF               [12] 1279 	mov	a,r7
      00A46B 24 FF            [12] 1280 	add	a,#0xff
      00A46D E4               [12] 1281 	clr	a
      00A46E 33               [12] 1282 	rlc	a
      00A46F 90 0A F0         [24] 1283 	mov	dptr,#_keymap_config
      00A472 13               [12] 1284 	rrc	a
      00A473 E0               [24] 1285 	movx	a,@dptr
      00A474 92 E7            [24] 1286 	mov	acc.7,c
      00A476 F0               [24] 1287 	movx	@dptr,a
      00A477                       1288 00105$:
                                   1289 ;	quantum/quantum.c:369: return false;
      00A477 75 82 00         [24] 1290 	mov	dpl, #0x00
                                   1291 ;	quantum/quantum.c:370: }
      00A47A 22               [24] 1292 	ret
                                   1293 ;------------------------------------------------------------
                                   1294 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1295 ;------------------------------------------------------------
                                   1296 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1297 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_666'
                                   1298 ;record        Allocated with name '_process_record_quantum_helper_record_10000_667'
                                   1299 ;------------------------------------------------------------
                                   1300 ;	quantum/quantum.c:373: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1301 ;	-----------------------------------------
                                   1302 ;	 function process_record_quantum_helper
                                   1303 ;	-----------------------------------------
      00A47B                       1304 _process_record_quantum_helper:
      00A47B 12 3A F0         [24] 1305 	lcall	_ak820_outline_0107
      00A47E 90 0C 3F         [24] 1306 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A481 12 3A F5         [24] 1307 	lcall	_ak820_outline_0108
                                   1308 ;	quantum/quantum.c:375: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A484 90 0C 3C         [24] 1309 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A487 12 3A AF         [24] 1310 	lcall	_ak820_outline_0052
                                   1311 ;	quantum/quantum.c:415: process_ak820_nkro(keycode, record) &&
      00A48A 90 0C 3F         [24] 1312 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A48D 12 3A C6         [24] 1313 	lcall	_ak820_outline_0061
      00A490 90 0C 37         [24] 1314 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A493 12 A5 DB         [24] 1315 	lcall	_ak820_outline_0002
      00A496 C0 07            [24] 1316 	push	ar7
      00A498 C0 06            [24] 1317 	push	ar6
      00A49A C0 05            [24] 1318 	push	ar5
      00A49C C0 04            [24] 1319 	push	ar4
      00A49E 91 10            [24] 1320 	acall	_process_ak820_nkro
      00A4A0 E5 82            [12] 1321 	mov	a, dpl
      00A4A2 D0 04            [24] 1322 	pop	ar4
      00A4A4 D0 05            [24] 1323 	pop	ar5
      00A4A6 D0 06            [24] 1324 	pop	ar6
      00A4A8 D0 07            [24] 1325 	pop	ar7
      00A4AA 70 02            [24] 1326 	jnz	00204$
      00A4AC A1 9B            [12] 1327 	ajmp	00101$
      00A4AE                       1328 00204$:
                                   1329 ;	quantum/quantum.c:426: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A4AE 90 0B F5         [24] 1330 	mov	dptr,#_process_last_key_PARM_2
      00A4B1 12 A5 DB         [24] 1331 	lcall	_ak820_outline_0002
      00A4B4 C0 07            [24] 1332 	push	ar7
      00A4B6 C0 06            [24] 1333 	push	ar6
      00A4B8 C0 05            [24] 1334 	push	ar5
      00A4BA C0 04            [24] 1335 	push	ar4
      00A4BC 12 9F 57         [24] 1336 	lcall	_process_last_key
      00A4BF E5 82            [12] 1337 	mov	a, dpl
      00A4C1 D0 04            [24] 1338 	pop	ar4
      00A4C3 D0 05            [24] 1339 	pop	ar5
      00A4C5 D0 06            [24] 1340 	pop	ar6
      00A4C7 D0 07            [24] 1341 	pop	ar7
      00A4C9 70 02            [24] 1342 	jnz	00205$
      00A4CB A1 9B            [12] 1343 	ajmp	00101$
      00A4CD                       1344 00205$:
      00A4CD 90 0B FB         [24] 1345 	mov	dptr,#_process_repeat_key_PARM_2
      00A4D0 12 A5 DB         [24] 1346 	lcall	_ak820_outline_0002
      00A4D3 C0 07            [24] 1347 	push	ar7
      00A4D5 C0 06            [24] 1348 	push	ar6
      00A4D7 C0 05            [24] 1349 	push	ar5
      00A4D9 C0 04            [24] 1350 	push	ar4
      00A4DB 12 9F D5         [24] 1351 	lcall	_process_repeat_key
      00A4DE E5 82            [12] 1352 	mov	a, dpl
      00A4E0 D0 04            [24] 1353 	pop	ar4
      00A4E2 D0 05            [24] 1354 	pop	ar5
      00A4E4 D0 06            [24] 1355 	pop	ar6
      00A4E6 D0 07            [24] 1356 	pop	ar7
      00A4E8 70 02            [24] 1357 	jnz	00206$
      00A4EA A1 9B            [12] 1358 	ajmp	00101$
      00A4EC                       1359 00206$:
                                   1360 ;	quantum/quantum.c:435: process_record_via(keycode, record) &&
      00A4EC 90 0C 7C         [24] 1361 	mov	dptr,#_process_record_via_PARM_2
      00A4EF 12 A5 DB         [24] 1362 	lcall	_ak820_outline_0002
      00A4F2 C0 07            [24] 1363 	push	ar7
      00A4F4 C0 06            [24] 1364 	push	ar6
      00A4F6 C0 05            [24] 1365 	push	ar5
      00A4F8 C0 04            [24] 1366 	push	ar4
      00A4FA 12 AA E3         [24] 1367 	lcall	_process_record_via
      00A4FD E5 82            [12] 1368 	mov	a, dpl
      00A4FF D0 04            [24] 1369 	pop	ar4
      00A501 D0 05            [24] 1370 	pop	ar5
      00A503 D0 06            [24] 1371 	pop	ar6
      00A505 D0 07            [24] 1372 	pop	ar7
      00A507 70 02            [24] 1373 	jnz	00207$
      00A509 A1 9B            [12] 1374 	ajmp	00101$
      00A50B                       1375 00207$:
                                   1376 ;	quantum/quantum.c:445: process_record_kb(keycode, record) &&
      00A50B 90 0C 1A         [24] 1377 	mov	dptr,#_process_record_kb_PARM_2
      00A50E 12 A5 DB         [24] 1378 	lcall	_ak820_outline_0002
      00A511 C0 07            [24] 1379 	push	ar7
      00A513 C0 06            [24] 1380 	push	ar6
      00A515 C0 05            [24] 1381 	push	ar5
      00A517 C0 04            [24] 1382 	push	ar4
      00A519 51 C8            [12] 1383 	acall	_process_record_kb
      00A51B E5 82            [12] 1384 	mov	a, dpl
      00A51D D0 04            [24] 1385 	pop	ar4
      00A51F D0 05            [24] 1386 	pop	ar5
      00A521 D0 06            [24] 1387 	pop	ar6
      00A523 D0 07            [24] 1388 	pop	ar7
      00A525 70 02            [24] 1389 	jnz	00208$
      00A527 A1 9B            [12] 1390 	ajmp	00101$
      00A529                       1391 00208$:
                                   1392 ;	quantum/quantum.c:468: process_caps_word(keycode, record) &&
      00A529 90 0B DD         [24] 1393 	mov	dptr,#_process_caps_word_PARM_2
      00A52C 12 A5 DB         [24] 1394 	lcall	_ak820_outline_0002
      00A52F C0 07            [24] 1395 	push	ar7
      00A531 C0 06            [24] 1396 	push	ar6
      00A533 C0 05            [24] 1397 	push	ar5
      00A535 C0 04            [24] 1398 	push	ar4
      00A537 12 9C E3         [24] 1399 	lcall	_process_caps_word
      00A53A E5 82            [12] 1400 	mov	a, dpl
      00A53C D0 04            [24] 1401 	pop	ar4
      00A53E D0 05            [24] 1402 	pop	ar5
      00A540 D0 06            [24] 1403 	pop	ar6
      00A542 D0 07            [24] 1404 	pop	ar7
      00A544 60 55            [24] 1405 	jz	00101$
                                   1406 ;	quantum/quantum.c:495: process_grave_esc(keycode, record) &&
      00A546 90 0B E2         [24] 1407 	mov	dptr,#_process_grave_esc_PARM_2
      00A549 12 A5 DB         [24] 1408 	lcall	_ak820_outline_0002
      00A54C C0 07            [24] 1409 	push	ar7
      00A54E C0 06            [24] 1410 	push	ar6
      00A550 C0 05            [24] 1411 	push	ar5
      00A552 C0 04            [24] 1412 	push	ar4
      00A554 12 9D F5         [24] 1413 	lcall	_process_grave_esc
      00A557 E5 82            [12] 1414 	mov	a, dpl
      00A559 D0 04            [24] 1415 	pop	ar4
      00A55B D0 05            [24] 1416 	pop	ar5
      00A55D D0 06            [24] 1417 	pop	ar6
      00A55F D0 07            [24] 1418 	pop	ar7
      00A561 60 38            [24] 1419 	jz	00101$
                                   1420 ;	quantum/quantum.c:498: process_rgb(keycode, record) &&
      00A563 90 0C 00         [24] 1421 	mov	dptr,#_process_rgb_PARM_2
      00A566 12 A5 DB         [24] 1422 	lcall	_ak820_outline_0002
      00A569 C0 07            [24] 1423 	push	ar7
      00A56B C0 06            [24] 1424 	push	ar6
      00A56D C0 05            [24] 1425 	push	ar5
      00A56F C0 04            [24] 1426 	push	ar4
      00A571 11 2F            [12] 1427 	acall	_process_rgb
      00A573 E5 82            [12] 1428 	mov	a, dpl
      00A575 D0 04            [24] 1429 	pop	ar4
      00A577 D0 05            [24] 1430 	pop	ar5
      00A579 D0 06            [24] 1431 	pop	ar6
      00A57B D0 07            [24] 1432 	pop	ar7
      00A57D 60 1C            [24] 1433 	jz	00101$
                                   1434 ;	quantum/quantum.c:510: process_tri_layer(keycode, record) &&
      00A57F 90 0C 06         [24] 1435 	mov	dptr,#_process_tri_layer_PARM_2
      00A582 12 A5 DB         [24] 1436 	lcall	_ak820_outline_0002
      00A585 C0 07            [24] 1437 	push	ar7
      00A587 C0 06            [24] 1438 	push	ar6
      00A589 C0 05            [24] 1439 	push	ar5
      00A58B C0 04            [24] 1440 	push	ar4
      00A58D 11 E0            [12] 1441 	acall	_process_tri_layer
      00A58F E5 82            [12] 1442 	mov	a, dpl
      00A591 D0 04            [24] 1443 	pop	ar4
      00A593 D0 05            [24] 1444 	pop	ar5
      00A595 D0 06            [24] 1445 	pop	ar6
      00A597 D0 07            [24] 1446 	pop	ar7
      00A599 70 04            [24] 1447 	jnz	00102$
                                   1448 ;	quantum/quantum.c:512: true)) {
      00A59B                       1449 00101$:
                                   1450 ;	quantum/quantum.c:513: return false;
      00A59B 75 82 00         [24] 1451 	mov	dpl, #0x00
      00A59E 22               [24] 1452 	ret
      00A59F                       1453 00102$:
                                   1454 ;	quantum/quantum.c:516: if (record->event.pressed) {
      00A59F 74 05            [12] 1455 	mov	a,#0x05
      00A5A1 12 4A CC         [24] 1456 	lcall	_ak820_outline_0032
      00A5A4 60 2D            [24] 1457 	jz	00117$
                                   1458 ;	quantum/quantum.c:517: switch (keycode) {
      00A5A6 BC 00 05         [24] 1459 	cjne	r4,#0x00,00214$
      00A5A9 BD 7C 02         [24] 1460 	cjne	r5,#0x7c,00214$
      00A5AC 80 10            [24] 1461 	sjmp	00112$
      00A5AE                       1462 00214$:
      00A5AE BC 01 05         [24] 1463 	cjne	r4,#0x01,00215$
      00A5B1 BD 7C 02         [24] 1464 	cjne	r5,#0x7c,00215$
      00A5B4 80 0E            [24] 1465 	sjmp	00113$
      00A5B6                       1466 00215$:
                                   1467 ;	quantum/quantum.c:519: case QK_BOOTLOADER:
      00A5B6 BC 03 1A         [24] 1468 	cjne	r4,#0x03,00117$
      00A5B9 BD 7C 17         [24] 1469 	cjne	r5,#0x7c,00117$
      00A5BC 80 0C            [24] 1470 	sjmp	00114$
      00A5BE                       1471 00112$:
                                   1472 ;	quantum/quantum.c:520: reset_keyboard();
      00A5BE 71 1B            [24] 1473 	acall	_reset_keyboard
                                   1474 ;	quantum/quantum.c:521: return false;
      00A5C0 75 82 00         [24] 1475 	mov	dpl, #0x00
                                   1476 ;	quantum/quantum.c:522: case QK_REBOOT:
      00A5C3 22               [24] 1477 	ret
      00A5C4                       1478 00113$:
                                   1479 ;	quantum/quantum.c:523: soft_reset_keyboard();
      00A5C4 71 20            [24] 1480 	acall	_soft_reset_keyboard
                                   1481 ;	quantum/quantum.c:524: return false;
      00A5C6 75 82 00         [24] 1482 	mov	dpl, #0x00
                                   1483 ;	quantum/quantum.c:536: case QK_CLEAR_EEPROM:
      00A5C9 22               [24] 1484 	ret
      00A5CA                       1485 00114$:
                                   1486 ;	quantum/quantum.c:543: eeconfig_disable();
      00A5CA 12 94 5C         [24] 1487 	lcall	_eeconfig_disable
                                   1488 ;	quantum/quantum.c:544: soft_reset_keyboard();
      00A5CD 71 20            [24] 1489 	acall	_soft_reset_keyboard
                                   1490 ;	quantum/quantum.c:546: return false;
      00A5CF 75 82 00         [24] 1491 	mov	dpl, #0x00
                                   1492 ;	quantum/quantum.c:601: }
      00A5D2 22               [24] 1493 	ret
      00A5D3                       1494 00117$:
                                   1495 ;	quantum/quantum.c:604: return process_action_kb(record);
      00A5D3 7D 00            [12] 1496 	mov	r5,#0x00
      00A5D5 12 74 79         [24] 1497 	lcall	_ak820_outline_0050
                                   1498 ;	quantum/quantum.c:605: }
      00A5D8 41 C4            [12] 1499 	ajmp	_process_action_kb
                                   1500 ;------------------------------------------------------------
                                   1501 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1502 ;------------------------------------------------------------
                                   1503 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_674'
                                   1504 ;------------------------------------------------------------
                                   1505 ;	quantum/quantum.c:607: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1506 ;	-----------------------------------------
                                   1507 ;	 function shutdown_user
                                   1508 ;	-----------------------------------------
      00A5DA                       1509 _shutdown_user:
      00A5DA 22               [24] 1510 	ret
                                   1511 ;------------------------------------------------------------
                                   1512 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1513 ;------------------------------------------------------------
                                   1514 ;	quantum/quantum.c:623: void suspend_power_down_quantum(void) {
                                   1515 ;	-----------------------------------------
                                   1516 	.area CSEG    (CODE)
                                   1517 	.area CONST   (CODE)
                                   1518 	.area XINIT   (CODE)
                                   1519 	.area CABS    (ABS,CODE)
                                   1520 
                                   1521 ; Experimental exact instruction outlining.
                                   1522 	.globl _ak820_outline_0002
                                   1523 	.globl _ak820_outline_0005
                                   1524 	.globl _ak820_outline_0007
                                   1525 	.globl _ak820_outline_0009
                                   1526 	.globl _ak820_outline_0010
                                   1527 	.globl _ak820_outline_0012
                                   1528 	.globl _ak820_outline_0016
                                   1529 	.globl _ak820_outline_0021
                                   1530 	.globl _ak820_outline_0022
                                   1531 	.globl _ak820_outline_0026
                                   1532 	.globl _ak820_outline_0032
                                   1533 	.globl _ak820_outline_0034
                                   1534 	.globl _ak820_outline_0036
                                   1535 	.globl _ak820_outline_0040
                                   1536 	.globl _ak820_outline_0050
                                   1537 	.globl _ak820_outline_0052
                                   1538 	.globl _ak820_outline_0061
                                   1539 	.globl _ak820_outline_0074
                                   1540 	.globl _ak820_outline_0103
                                   1541 	.globl _ak820_outline_0107
                                   1542 	.globl _ak820_outline_0108
                                   1543 	.globl _ak820_outline_0118
                                   1544 	.globl _ak820_outline_0119
                                   1545 	.globl _ak820_outline_0123
                                   1546 	.globl _ak820_outline_0125
                                   1547 	.globl _ak820_outline_0143
                                   1548 	.globl _ak820_outline_0151
                                   1549 	.globl _ak820_outline_0154
                                   1550 	.globl _ak820_outline_0160
                                   1551 
                                   1552 	.area CSEG (CODE)
                                   1553 ; function ak820_outline_0002
      00A5DB                       1554 _ak820_outline_0002:
      00A5DB EE               [12] 1555 	mov	a,r6
      00A5DC F0               [24] 1556 	movx	@dptr,a
      00A5DD EF               [12] 1557 	mov	a,r7
      00A5DE A3               [24] 1558 	inc	dptr
      00A5DF F0               [24] 1559 	movx	@dptr,a
      00A5E0 E4               [12] 1560 	clr	a
      00A5E1 A3               [24] 1561 	inc	dptr
      00A5E2 F0               [24] 1562 	movx	@dptr,a
      00A5E3 8C 82            [24] 1563 	mov	dpl,r4
      00A5E5 8D 83            [24] 1564 	mov	dph,r5
      00A5E7 22               [24] 1565 	ret
                                   1566 
                                   1567 	.area CSEG (CODE)
                                   1568 ; function ak820_outline_0010
      00A5E8                       1569 _ak820_outline_0010:
      00A5E8 EB               [12] 1570 	mov	a,r3
      00A5E9 F0               [24] 1571 	movx	@dptr,a
      00A5EA EC               [12] 1572 	mov	a,r4
      00A5EB A3               [24] 1573 	inc	dptr
      00A5EC F0               [24] 1574 	movx	@dptr,a
      00A5ED ED               [12] 1575 	mov	a,r5
      00A5EE A3               [24] 1576 	inc	dptr
      00A5EF F0               [24] 1577 	movx	@dptr,a
      00A5F0 8E 82            [24] 1578 	mov	dpl,r6
      00A5F2 8F 83            [24] 1579 	mov	dph,r7
      00A5F4 22               [24] 1580 	ret
