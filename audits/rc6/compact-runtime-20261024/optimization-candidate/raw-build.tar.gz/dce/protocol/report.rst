                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 	.area	OSEG    (OVR,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      00081D                        556 _KEYCODE2CONSUMER_key_10000_118:
      00081D                        557 	.ds 1
      00081E                        558 _add_key_byte_PARM_2:
      00081E                        559 	.ds 1
      00081F                        560 _add_key_byte_report_arg_10000_145:
      00081F                        561 	.ds 3
      000822                        562 _add_key_byte_empty_10000_146:
      000822                        563 	.ds 1
      000823                        564 _del_key_byte_PARM_2:
      000823                        565 	.ds 1
      000824                        566 _del_key_byte_report_arg_10000_157:
      000824                        567 	.ds 3
      000827                        568 _add_key_bit_PARM_2:
      000827                        569 	.ds 1
      000828                        570 _add_key_bit_report_arg_10000_163:
      000828                        571 	.ds 3
      00082B                        572 _del_key_bit_PARM_2:
      00082B                        573 	.ds 1
      00082C                        574 _del_key_bit_report_arg_10000_168:
      00082C                        575 	.ds 3
      00082F                        576 _add_key_to_report_PARM_2:
      00082F                        577 	.ds 1
      000830                        578 _add_key_to_report_report_arg_10000_173:
      000830                        579 	.ds 3
      000833                        580 _del_key_from_report_PARM_2:
      000833                        581 	.ds 1
      000834                        582 _del_key_from_report_report_arg_10000_177:
      000834                        583 	.ds 3
      000837                        584 _clear_keys_from_report_report_arg_10000_181:
      000837                        585 	.ds 3
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      00725F                        637 _KEYCODE2CONSUMER:
      00725F E5 82            [12]  638 	mov	a,dpl
      007261 90 08 1D         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_118
      007264 F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      007265 E0               [24]  642 	movx	a,@dptr
      007266 FF               [12]  643 	mov	r7,a
      007267 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      00726A                        645 00113$:
      00726A 40 05            [24]  646 	jc	00101$
      00726C EF               [12]  647 	mov	a,r7
      00726D 24 3D            [12]  648 	add	a,#0xff - 0xc2
      00726F 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      007271                        651 00101$:
      007271 90 00 00         [24]  652 	mov	dptr,#0x0000
      007274 22               [24]  653 	ret
      007275                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      007275 EF               [12]  656 	mov	a,r7
      007276 24 58            [12]  657 	add	a,#0x58
      007278 FF               [12]  658 	mov	r7,a
      007279 C2 D5            [12]  659 	clr	F0
      00727B 75 F0 02         [24]  660 	mov	b,#0x02
      00727E EF               [12]  661 	mov	a,r7
      00727F 30 E7 04         [24]  662 	jnb	acc.7,00116$
      007282 B2 D5            [12]  663 	cpl	F0
      007284 F4               [12]  664 	cpl	a
      007285 04               [12]  665 	inc	a
      007286                        666 00116$:
      007286 A4               [48]  667 	mul	ab
      007287 30 D5 03         [24]  668 	jnb	F0,00117$
      00728A 12 74 86         [24]  669 	lcall	_ak820_outline_0130
      00728D                        670 00117$:
      00728D 24 FB            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_119
      00728F F5 82            [12]  672 	mov	dpl,a
      007291 74 BD            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_119 >> 8)
      007293 12 5B D7         [24]  674 	lcall	_ak820_outline_0109
      007296 FE               [12]  675 	mov	r6,a
      007297 A3               [24]  676 	inc	dptr
      007298 E4               [12]  677 	clr	a
      007299 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:54: }
      00729A 8E 82            [24]  680 	mov	dpl,r6
      00729C F5 83            [12]  681 	mov	dph,a
      00729E 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_121'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_122'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_122'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_122'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_122'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      00729F                        696 _add_key_byte:
      00729F 12 45 7B         [24]  697 	lcall	_ak820_outline_0036
      0072A2 90 08 1F         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_145
      0072A5 12 3A 8D         [24]  699 	lcall	_ak820_outline_0016
                                    700 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072A8 90 08 1F         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_145
      0072AB 12 3A AF         [24]  702 	lcall	_ak820_outline_0052
                                    703 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      0072AE 90 08 22         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_146
      0072B1 74 FF            [12]  705 	mov	a,#0xff
      0072B3 F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:209: }
      0072B4 7D 00            [12]  708 	mov	r5,#0x00
      0072B6                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      0072B6 C3               [12]  711 	clr	c
      0072B7 ED               [12]  712 	mov	a,r5
      0072B8 64 80            [12]  713 	xrl	a,#0x80
      0072BA 94 86            [12]  714 	subb	a,#0x86
      0072BC 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      0072BE 12 74 91         [24]  717 	lcall	_ak820_outline_0146
      0072C1 F5 82            [12]  718 	mov	dpl,a
      0072C3 E4               [12]  719 	clr	a
      0072C4 3C               [12]  720 	addc	a, r4
      0072C5 F5 83            [12]  721 	mov	dph,a
      0072C7 E0               [24]  722 	movx	a,@dptr
      0072C8 FC               [12]  723 	mov	r4,a
      0072C9 90 08 1E         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      0072CC E0               [24]  725 	movx	a,@dptr
      0072CD FB               [12]  726 	mov	r3,a
      0072CE EC               [12]  727 	mov	a,r4
      0072CF B5 03 02         [24]  728 	cjne	a,ar3,00167$
      0072D2 80 13            [24]  729 	sjmp	00106$
      0072D4                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      0072D4 90 08 22         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_146
      0072D7 E0               [24]  733 	movx	a,@dptr
      0072D8 FB               [12]  734 	mov	r3,a
      0072D9 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      0072DC EC               [12]  736 	mov	a,r4
      0072DD 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:200: empty = i;
      0072DF 90 08 22         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_146
      0072E2 ED               [12]  740 	mov	a,r5
      0072E3 F0               [24]  741 	movx	@dptr,a
      0072E4                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      0072E4 0D               [12]  744 	inc	r5
      0072E5 80 CF            [24]  745 	sjmp	00112$
      0072E7                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      0072E7 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      0072EA 90 08 22         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_146
      0072ED E0               [24]  751 	movx	a,@dptr
      0072EE FD               [12]  752 	mov	r5,a
      0072EF BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      0072F2 22               [24]  754 	ret
      0072F3                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      0072F3 74 02            [12]  757 	mov	a,#0x02
      0072F5 12 45 C9         [24]  758 	lcall	_ak820_outline_0135
      0072F8 ED               [12]  759 	mov	a,r5
      0072F9 2E               [12]  760 	add	a, r6
      0072FA FD               [12]  761 	mov	r5,a
      0072FB E4               [12]  762 	clr	a
      0072FC 3F               [12]  763 	addc	a, r7
      0072FD FC               [12]  764 	mov	r4,a
      0072FE 90 08 1E         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      007301 E0               [24]  766 	movx	a,@dptr
      007302 8D 82            [24]  767 	mov	dpl,r5
      007304 8C 83            [24]  768 	mov	dph,r4
      007306 F0               [24]  769 	movx	@dptr,a
      007307                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:209: }
      007307 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_157'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_158'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_159'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      007308                        785 _del_key_byte:
      007308 12 45 7B         [24]  786 	lcall	_ak820_outline_0036
      00730B 90 08 24         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_157
      00730E 12 3A 8D         [24]  788 	lcall	_ak820_outline_0016
                                    789 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007311 90 08 24         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_157
      007314 12 3A AF         [24]  791 	lcall	_ak820_outline_0052
                                    792 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      007317 7D 00            [12]  793 	mov	r5,#0x00
      007319                        794 00105$:
      007319 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      00731C                        796 00131$:
      00731C 50 1A            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      00731E 12 74 91         [24]  799 	lcall	_ak820_outline_0146
      007321 FB               [12]  800 	mov	r3,a
      007322 E4               [12]  801 	clr	a
      007323 3C               [12]  802 	addc	a, r4
      007324 12 4A E2         [24]  803 	lcall	_ak820_outline_0056
      007327 90 08 23         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      00732A E0               [24]  805 	movx	a,@dptr
      00732B F9               [12]  806 	mov	r1,a
      00732C EA               [12]  807 	mov	a,r2
      00732D B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      007330 12 36 75         [24]  810 	lcall	_ak820_outline_0122
      007333 E4               [12]  811 	clr	a
      007334 F0               [24]  812 	movx	@dptr,a
      007335                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      007335 0D               [12]  815 	inc	r5
      007336 80 E1            [24]  816 	sjmp	00105$
      007338                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:249: }
      007338 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_163'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_164'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      007339                        831 _add_key_bit:
      007339 12 45 7B         [24]  832 	lcall	_ak820_outline_0036
      00733C 90 08 28         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_163
      00733F 12 3A 8D         [24]  834 	lcall	_ak820_outline_0016
                                    835 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007342 90 08 28         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_163
      007345 12 3A AF         [24]  837 	lcall	_ak820_outline_0052
                                    838 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007348 90 08 27         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      00734B E0               [24]  840 	movx	a,@dptr
      00734C FD               [12]  841 	mov	r5,a
      00734D 12 5C 0D         [24]  842 	lcall	_ak820_outline_0186
      007350 FC               [12]  843 	mov	r4,a
      007351 BC 1E 00         [24]  844 	cjne	r4,#0x1e,00112$
      007354                        845 00112$:
      007354 50 16            [24]  846 	jnc	00103$
                                    847 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      007356 12 74 62         [24]  848 	lcall	_ak820_outline_0035
      007359 80 02            [24]  849 	sjmp	00115$
      00735B                        850 00114$:
      00735B 25 E0            [12]  851 	add	a,acc
      00735D                        852 00115$:
      00735D D5 F0 FB         [24]  853 	djnz	b,00114$
      007360 FF               [12]  854 	mov	r7,a
      007361 12 45 F7         [24]  855 	lcall	_ak820_outline_0189
      007364 E0               [24]  856 	movx	a,@dptr
      007365 42 07            [12]  857 	orl	ar7,a
      007367 12 45 F7         [24]  858 	lcall	_ak820_outline_0189
      00736A EF               [12]  859 	mov	a,r7
      00736B F0               [24]  860 	movx	@dptr,a
      00736C                        861 00103$:
                                    862 ;	tmk_core/protocol/report.c:263: }
      00736C 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'del_key_bit'
                                    866 ;------------------------------------------------------------
                                    867 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    868 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_168'
                                    869 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_169'
                                    870 ;------------------------------------------------------------
                                    871 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function del_key_bit
                                    874 ;	-----------------------------------------
      00736D                        875 _del_key_bit:
      00736D 12 45 7B         [24]  876 	lcall	_ak820_outline_0036
      007370 90 08 2C         [24]  877 	mov	dptr,#_del_key_bit_report_arg_10000_168
      007373 12 3A 8D         [24]  878 	lcall	_ak820_outline_0016
                                    879 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007376 90 08 2C         [24]  880 	mov	dptr,#_del_key_bit_report_arg_10000_168
      007379 12 3A AF         [24]  881 	lcall	_ak820_outline_0052
                                    882 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00737C 90 08 2B         [24]  883 	mov	dptr,#_del_key_bit_PARM_2
      00737F E0               [24]  884 	movx	a,@dptr
      007380 FD               [12]  885 	mov	r5,a
      007381 12 5C 0D         [24]  886 	lcall	_ak820_outline_0186
      007384 FC               [12]  887 	mov	r4,a
      007385 BC 1E 00         [24]  888 	cjne	r4,#0x1e,00112$
      007388                        889 00112$:
      007388 50 17            [24]  890 	jnc	00103$
                                    891 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      00738A 12 74 62         [24]  892 	lcall	_ak820_outline_0035
      00738D 80 02            [24]  893 	sjmp	00115$
      00738F                        894 00114$:
      00738F 25 E0            [12]  895 	add	a,acc
      007391                        896 00115$:
      007391 D5 F0 FB         [24]  897 	djnz	b,00114$
      007394 F4               [12]  898 	cpl	a
      007395 FF               [12]  899 	mov	r7,a
      007396 12 45 F7         [24]  900 	lcall	_ak820_outline_0189
      007399 E0               [24]  901 	movx	a,@dptr
      00739A 52 07            [12]  902 	anl	ar7,a
      00739C 12 45 F7         [24]  903 	lcall	_ak820_outline_0189
      00739F EF               [12]  904 	mov	a,r7
      0073A0 F0               [24]  905 	movx	@dptr,a
      0073A1                        906 00103$:
                                    907 ;	tmk_core/protocol/report.c:276: }
      0073A1 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'add_key_to_report'
                                    911 ;------------------------------------------------------------
                                    912 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    913 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_173'
                                    914 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_174'
                                    915 ;------------------------------------------------------------
                                    916 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function add_key_to_report
                                    919 ;	-----------------------------------------
      0073A2                        920 _add_key_to_report:
      0073A2 12 45 7B         [24]  921 	lcall	_ak820_outline_0036
      0073A5 90 08 30         [24]  922 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      0073A8 12 3A 8D         [24]  923 	lcall	_ak820_outline_0016
                                    924 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073AB 90 08 30         [24]  925 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      0073AE 12 3A AF         [24]  926 	lcall	_ak820_outline_0052
                                    927 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      0073B1 90 0D E6         [24]  928 	mov	dptr,#_keyboard_protocol
      0073B4 E0               [24]  929 	movx	a,@dptr
      0073B5 60 18            [24]  930 	jz	00102$
      0073B7 90 0A F0         [24]  931 	mov	dptr,#_keymap_config
      0073BA E0               [24]  932 	movx	a,@dptr
      0073BB 30 E7 11         [24]  933 	jnb	acc.7,00102$
                                    934 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      0073BE 12 74 9B         [24]  935 	lcall	_ak820_outline_0154
      0073C1 90 08 2F         [24]  936 	mov	dptr,#_add_key_to_report_PARM_2
      0073C4 E0               [24]  937 	movx	a,@dptr
      0073C5 90 08 27         [24]  938 	mov	dptr,#_add_key_bit_PARM_2
      0073C8 12 74 80         [24]  939 	lcall	_ak820_outline_0103
      0073CB 8D F0            [24]  940 	mov	b, r5
                                    941 ;	tmk_core/protocol/report.c:288: return;
      0073CD 61 39            [12]  942 	ajmp	_add_key_bit
      0073CF                        943 00102$:
                                    944 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      0073CF 7D 00            [12]  945 	mov	r5,#0x00
      0073D1 90 08 2F         [24]  946 	mov	dptr,#_add_key_to_report_PARM_2
      0073D4 E0               [24]  947 	movx	a,@dptr
      0073D5 90 08 1E         [24]  948 	mov	dptr,#_add_key_byte_PARM_2
      0073D8 F0               [24]  949 	movx	@dptr,a
      0073D9 12 74 79         [24]  950 	lcall	_ak820_outline_0050
                                    951 ;	tmk_core/protocol/report.c:292: }
      0073DC 41 9F            [12]  952 	ajmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_177'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_178'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      0073DE                        964 _del_key_from_report:
      0073DE 12 45 7B         [24]  965 	lcall	_ak820_outline_0036
      0073E1 90 08 34         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      0073E4 12 3A 8D         [24]  967 	lcall	_ak820_outline_0016
                                    968 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073E7 90 08 34         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      0073EA 12 3A AF         [24]  970 	lcall	_ak820_outline_0052
                                    971 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      0073ED 90 0D E6         [24]  972 	mov	dptr,#_keyboard_protocol
      0073F0 E0               [24]  973 	movx	a,@dptr
      0073F1 60 18            [24]  974 	jz	00102$
      0073F3 90 0A F0         [24]  975 	mov	dptr,#_keymap_config
      0073F6 E0               [24]  976 	movx	a,@dptr
      0073F7 30 E7 11         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      0073FA 12 74 9B         [24]  979 	lcall	_ak820_outline_0154
      0073FD 90 08 33         [24]  980 	mov	dptr,#_del_key_from_report_PARM_2
      007400 E0               [24]  981 	movx	a,@dptr
      007401 90 08 2B         [24]  982 	mov	dptr,#_del_key_bit_PARM_2
      007404 12 74 80         [24]  983 	lcall	_ak820_outline_0103
      007407 8D F0            [24]  984 	mov	b, r5
                                    985 ;	tmk_core/protocol/report.c:303: return;
      007409 61 6D            [24]  986 	ajmp	_del_key_bit
      00740B                        987 00102$:
                                    988 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      00740B 7D 00            [12]  989 	mov	r5,#0x00
      00740D 90 08 33         [24]  990 	mov	dptr,#_del_key_from_report_PARM_2
      007410 E0               [24]  991 	movx	a,@dptr
      007411 90 08 23         [24]  992 	mov	dptr,#_del_key_byte_PARM_2
      007414 F0               [24]  993 	movx	@dptr,a
      007415 12 74 79         [24]  994 	lcall	_ak820_outline_0050
                                    995 ;	tmk_core/protocol/report.c:307: }
      007418 61 08            [12]  996 	ajmp	_del_key_byte
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    999 ;------------------------------------------------------------
                                   1000 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_181'
                                   1001 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_182'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function clear_keys_from_report
                                   1006 ;	-----------------------------------------
      00741A                       1007 _clear_keys_from_report:
      00741A 12 45 7B         [24] 1008 	lcall	_ak820_outline_0036
      00741D 90 08 37         [24] 1009 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      007420 12 3A 8D         [24] 1010 	lcall	_ak820_outline_0016
                                   1011 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007423 90 08 37         [24] 1012 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      007426 12 3A AF         [24] 1013 	lcall	_ak820_outline_0052
                                   1014 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      007429 90 0D E6         [24] 1015 	mov	dptr,#_keyboard_protocol
      00742C E0               [24] 1016 	movx	a,@dptr
      00742D 60 1E            [24] 1017 	jz	00102$
      00742F 90 0A F0         [24] 1018 	mov	dptr,#_keymap_config
      007432 E0               [24] 1019 	movx	a,@dptr
      007433 30 E7 17         [24] 1020 	jnb	acc.7,00102$
                                   1021 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      007436 74 02            [12] 1022 	mov	a,#0x02
      007438 12 45 E6         [24] 1023 	lcall	_ak820_outline_0164
      00743B 7B 00            [12] 1024 	mov	r3,#0x00
      00743D 12 74 A2         [24] 1025 	lcall	_ak820_outline_0180
      007440 74 1E            [12] 1026 	mov	a,#0x1e
      007442 F0               [24] 1027 	movx	@dptr,a
      007443 E4               [12] 1028 	clr	a
      007444 A3               [24] 1029 	inc	dptr
      007445 12 3A E4         [24] 1030 	lcall	_ak820_outline_0096
      007448 8B F0            [24] 1031 	mov	b, r3
                                   1032 ;	tmk_core/protocol/report.c:319: return;
      00744A 02 BC EC         [24] 1033 	ljmp	_memset
      00744D                       1034 00102$:
                                   1035 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      00744D 74 02            [12] 1036 	mov	a,#0x02
      00744F 12 45 C9         [24] 1037 	lcall	_ak820_outline_0135
      007452 7D 00            [12] 1038 	mov	r5,#0x00
      007454 12 74 A2         [24] 1039 	lcall	_ak820_outline_0180
      007457 74 06            [12] 1040 	mov	a,#0x06
      007459 12 3B 04         [24] 1041 	lcall	_ak820_outline_0124
      00745C 12 74 79         [24] 1042 	lcall	_ak820_outline_0050
                                   1043 ;	tmk_core/protocol/report.c:323: }
      00745F 02 BC EC         [24] 1044 	ljmp	_memset
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'has_mouse_report_changed'
                                   1047 ;------------------------------------------------------------
                                   1048 ;old_report    Allocated with name '_has_mouse_report_changed_PARM_2'
                                   1049 ;new_report    Allocated with name '_has_mouse_report_changed_new_report_10000_185'
                                   1050 ;changed       Allocated with name '_has_mouse_report_changed_changed_10000_186'
                                   1051 ;sloc0         Allocated with name '_has_mouse_report_changed_sloc0_1_0'
                                   1052 ;sloc1         Allocated with name '_has_mouse_report_changed_sloc1_1_0'
                                   1053 ;------------------------------------------------------------
                                   1054 ;	tmk_core/protocol/report.c:334: __attribute__((weak)) bool has_mouse_report_changed(report_mouse_t* new_report, report_mouse_t* old_report) {
                                   1055 ;	-----------------------------------------
                                   1056 	.area CSEG    (CODE)
                                   1057 	.area CONST   (CODE)
                                   1058 	.area CONST   (CODE)
      00BDFB                       1059 _KEYCODE2CONSUMER_usages_10000_119:
      00BDFB E2 00                 1060 	.byte #0xe2, #0x00	; 226
      00BDFD E9 00                 1061 	.byte #0xe9, #0x00	; 233
      00BDFF EA 00                 1062 	.byte #0xea, #0x00	; 234
      00BE01 B5 00                 1063 	.byte #0xb5, #0x00	; 181
      00BE03 B6 00                 1064 	.byte #0xb6, #0x00	; 182
      00BE05 B7 00                 1065 	.byte #0xb7, #0x00	; 183
      00BE07 CD 00                 1066 	.byte #0xcd, #0x00	; 205
      00BE09 83 01                 1067 	.byte #0x83, #0x01	; 387
      00BE0B CC 00                 1068 	.byte #0xcc, #0x00	; 204
      00BE0D 8A 01                 1069 	.byte #0x8a, #0x01	; 394
      00BE0F 92 01                 1070 	.byte #0x92, #0x01	; 402
      00BE11 94 01                 1071 	.byte #0x94, #0x01	; 404
      00BE13 21 02                 1072 	.byte #0x21, #0x02	; 545
      00BE15 23 02                 1073 	.byte #0x23, #0x02	; 547
      00BE17 24 02                 1074 	.byte #0x24, #0x02	; 548
      00BE19 25 02                 1075 	.byte #0x25, #0x02	; 549
      00BE1B 26 02                 1076 	.byte #0x26, #0x02	; 550
      00BE1D 27 02                 1077 	.byte #0x27, #0x02	; 551
      00BE1F 2A 02                 1078 	.byte #0x2a, #0x02	; 554
      00BE21 B3 00                 1079 	.byte #0xb3, #0x00	; 179
      00BE23 B4 00                 1080 	.byte #0xb4, #0x00	; 180
      00BE25 6F 00                 1081 	.byte #0x6f, #0x00	; 111
      00BE27 70 00                 1082 	.byte #0x70, #0x00	; 112
      00BE29 9F 01                 1083 	.byte #0x9f, #0x01	; 415
      00BE2B CB 01                 1084 	.byte #0xcb, #0x01	; 459
      00BE2D 9F 02                 1085 	.byte #0x9f, #0x02	; 671
      00BE2F A0 02                 1086 	.byte #0xa0, #0x02	; 672
                                   1087 	.area CSEG    (CODE)
                                   1088 	.area XINIT   (CODE)
                                   1089 	.area CABS    (ABS,CODE)
                                   1090 
                                   1091 ; Experimental exact instruction outlining.
                                   1092 	.globl _ak820_outline_0016
                                   1093 	.globl _ak820_outline_0035
                                   1094 	.globl _ak820_outline_0036
                                   1095 	.globl _ak820_outline_0050
                                   1096 	.globl _ak820_outline_0052
                                   1097 	.globl _ak820_outline_0056
                                   1098 	.globl _ak820_outline_0096
                                   1099 	.globl _ak820_outline_0103
                                   1100 	.globl _ak820_outline_0109
                                   1101 	.globl _ak820_outline_0122
                                   1102 	.globl _ak820_outline_0124
                                   1103 	.globl _ak820_outline_0130
                                   1104 	.globl _ak820_outline_0135
                                   1105 	.globl _ak820_outline_0146
                                   1106 	.globl _ak820_outline_0154
                                   1107 	.globl _ak820_outline_0164
                                   1108 	.globl _ak820_outline_0180
                                   1109 	.globl _ak820_outline_0186
                                   1110 	.globl _ak820_outline_0189
                                   1111 
                                   1112 	.area CSEG (CODE)
                                   1113 ; function ak820_outline_0035
      007462                       1114 _ak820_outline_0035:
      007462 74 02            [12] 1115 	mov	a,#0x02
      007464 2E               [12] 1116 	add	a,r6
      007465 FE               [12] 1117 	mov	r6,a
      007466 E4               [12] 1118 	clr	a
      007467 3F               [12] 1119 	addc	a,r7
      007468 FF               [12] 1120 	mov	r7,a
      007469 EC               [12] 1121 	mov	a,r4
      00746A 2E               [12] 1122 	add	a,r6
      00746B FC               [12] 1123 	mov	r4,a
      00746C E4               [12] 1124 	clr	a
      00746D 3F               [12] 1125 	addc	a,r7
      00746E FB               [12] 1126 	mov	r3,a
      00746F 74 07            [12] 1127 	mov	a,#0x07
      007471 5D               [12] 1128 	anl	a,r5
      007472 F5 F0            [12] 1129 	mov	b,a
      007474 05 F0            [12] 1130 	inc	b
      007476 74 01            [12] 1131 	mov	a,#0x01
      007478 22               [24] 1132 	ret
                                   1133 
                                   1134 	.area CSEG (CODE)
                                   1135 ; function ak820_outline_0050
      007479                       1136 _ak820_outline_0050:
      007479 8E 82            [24] 1137 	mov	dpl,r6
      00747B 8F 83            [24] 1138 	mov	dph,r7
      00747D 8D F0            [24] 1139 	mov	b,r5
      00747F 22               [24] 1140 	ret
                                   1141 
                                   1142 	.area CSEG (CODE)
                                   1143 ; function ak820_outline_0103
      007480                       1144 _ak820_outline_0103:
      007480 F0               [24] 1145 	movx	@dptr,a
      007481 8B 82            [24] 1146 	mov	dpl,r3
      007483 8C 83            [24] 1147 	mov	dph,r4
      007485 22               [24] 1148 	ret
                                   1149 
                                   1150 	.area CSEG (CODE)
                                   1151 ; function ak820_outline_0130
      007486                       1152 _ak820_outline_0130:
      007486 F4               [12] 1153 	cpl	a
      007487 24 01            [12] 1154 	add	a,#0x01
      007489 C5 F0            [12] 1155 	xch	a,b
      00748B F4               [12] 1156 	cpl	a
      00748C 34 00            [12] 1157 	addc	a,#0x00
      00748E C5 F0            [12] 1158 	xch	a,b
      007490 22               [24] 1159 	ret
                                   1160 
                                   1161 	.area CSEG (CODE)
                                   1162 ; function ak820_outline_0146
      007491                       1163 _ak820_outline_0146:
      007491 74 02            [12] 1164 	mov	a,#0x02
      007493 2E               [12] 1165 	add	a,r6
      007494 FB               [12] 1166 	mov	r3,a
      007495 E4               [12] 1167 	clr	a
      007496 3F               [12] 1168 	addc	a,r7
      007497 FC               [12] 1169 	mov	r4,a
      007498 ED               [12] 1170 	mov	a,r5
      007499 2B               [12] 1171 	add	a,r3
      00749A 22               [24] 1172 	ret
                                   1173 
                                   1174 	.area CSEG (CODE)
                                   1175 ; function ak820_outline_0154
      00749B                       1176 _ak820_outline_0154:
      00749B 8E 03            [24] 1177 	mov	ar3,r6
      00749D 8F 04            [24] 1178 	mov	ar4,r7
      00749F 7D 00            [12] 1179 	mov	r5,#0x00
      0074A1 22               [24] 1180 	ret
                                   1181 
                                   1182 	.area CSEG (CODE)
                                   1183 ; function ak820_outline_0180
      0074A2                       1184 _ak820_outline_0180:
      0074A2 90 0D DB         [24] 1185 	mov	dptr,#_memset_PARM_2
      0074A5 E4               [12] 1186 	clr	a
      0074A6 F0               [24] 1187 	movx	@dptr,a
      0074A7 90 0D DC         [24] 1188 	mov	dptr,#_memset_PARM_3
      0074AA 22               [24] 1189 	ret
