                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_287:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_287:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_287:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_287:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00078B                        602 _D0SetupReqCode::
      00078B                        603 	.ds 1
      00078C                        604 _D0SetupLen::
      00078C                        605 	.ds 2
      00078E                        606 _pD0Descr::
      00078E                        607 	.ds 3
      000791                        608 _D0UsbConfig::
      000791                        609 	.ds 1
      000792                        610 _USB_EnumStatus::
      000792                        611 	.ds 1
      000793                        612 _USB_SleepStatus::
      000793                        613 	.ds 1
      000794                        614 _MCU_Sleep_Operate::
      000794                        615 	.ds 1
      000795                        616 _KB_USB_UpStatus::
      000795                        617 	.ds 1
      000796                        618 _KB_USB_SetReport::
      000796                        619 	.ds 1
      000797                        620 _ak820_boot_stage::
      000797                        621 	.ds 1
      000798                        622 _ak820_main_heartbeat::
      000798                        623 	.ds 1
      000799                        624 _raw_state:
      000799                        625 	.ds 1
      00079A                        626 _raw_buffer:
      00079A                        627 	.ds 32
      0007BA                        628 _raw_reply_without_nvm:
      0007BA                        629 	.ds 1
      0007BB                        630 _keyboard_reset:
      0007BB                        631 	.ds 1
      0007BC                        632 _input_snapshot:
      0007BC                        633 	.ds 52
      0007F0                        634 _control_phase:
      0007F0                        635 	.ds 1
      0007F1                        636 _output_kind:
      0007F1                        637 	.ds 1
      0007F2                        638 _output_report_id:
      0007F2                        639 	.ds 1
      0007F3                        640 _control_zlp:
      0007F3                        641 	.ds 1
      0007F4                        642 _control_pointer:
      0007F4                        643 	.ds 2
      0007F6                        644 _descriptor_select_PARM_2:
      0007F6                        645 	.ds 1
      0007F7                        646 _descriptor_select_PARM_3:
      0007F7                        647 	.ds 2
      0007F9                        648 _descriptor_select_type_10000_269:
      0007F9                        649 	.ds 1
      0007FA                        650 _control_setup_length_10000_287:
      0007FA                        651 	.ds 2
      0007FC                        652 _control_setup_offset_10000_287:
      0007FC                        653 	.ds 1
      0007FD                        654 _ak820_usb_send_PARM_2:
      0007FD                        655 	.ds 2
      0007FF                        656 _ak820_usb_send_PARM_3:
      0007FF                        657 	.ds 1
      000800                        658 _ak820_usb_send_endpoint_10000_423:
      000800                        659 	.ds 1
      000801                        660 _ak820_usb_send_offset_10000_424:
      000801                        661 	.ds 1
      000802                        662 _ak820_usb_try_send_PARM_2:
      000802                        663 	.ds 2
      000804                        664 _ak820_usb_try_send_PARM_3:
      000804                        665 	.ds 1
      000805                        666 _ak820_usb_try_send_endpoint_10000_444:
      000805                        667 	.ds 1
      000806                        668 _ak820_usb_try_send_sent_10000_445:
      000806                        669 	.ds 1
      000807                        670 _ak820_usb_raw_send_PARM_2:
      000807                        671 	.ds 1
      000808                        672 _ak820_usb_raw_send_report_10000_460:
      000808                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005F0F                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005F0F 90 07 99         [24]  727 	mov	dptr,#_raw_state
      005F12 E0               [24]  728 	movx	a,@dptr
      005F13 FF               [12]  729 	mov	r7,a
      005F14 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005F17 80 1C            [24]  731 	sjmp	00101$
      005F19                        732 00130$:
      005F19 90 07 99         [24]  733 	mov	dptr,#_raw_state
      005F1C E0               [24]  734 	movx	a,@dptr
      005F1D FF               [12]  735 	mov	r7,a
      005F1E BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005F21 80 12            [24]  737 	sjmp	00101$
      005F23                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005F23 90 07 99         [24]  740 	mov	dptr,#_raw_state
      005F26 E0               [24]  741 	movx	a,@dptr
      005F27 FF               [12]  742 	mov	r7,a
      005F28 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005F2B 80 08            [24]  744 	sjmp	00101$
      005F2D                        745 00132$:
      005F2D 90 07 99         [24]  746 	mov	dptr,#_raw_state
      005F30 E0               [24]  747 	movx	a,@dptr
      005F31 FF               [12]  748 	mov	r7,a
      005F32 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005F35                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005F35 90 07 99         [24]  752 	mov	dptr,#_raw_state
      005F38 74 07            [12]  753 	mov	a,#0x07
      005F3A F0               [24]  754 	movx	@dptr,a
      005F3B 80 05            [24]  755 	sjmp	00103$
      005F3D                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005F3D 90 07 99         [24]  758 	mov	dptr,#_raw_state
      005F40 E4               [12]  759 	clr	a
      005F41 F0               [24]  760 	movx	@dptr,a
      005F42                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005F42 90 07 F1         [24]  763 	mov	dptr,#_output_kind
      005F45 E4               [12]  764 	clr	a
      005F46 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005F47 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005F48                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005F48 90 07 99         [24]  777 	mov	dptr,#_raw_state
      005F4B E0               [24]  778 	movx	a,@dptr
      005F4C FF               [12]  779 	mov	r7,a
      005F4D BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005F50 90 07 99         [24]  781 	mov	dptr,#_raw_state
      005F53 74 06            [12]  782 	mov	a,#0x06
      005F55 F0               [24]  783 	movx	@dptr,a
      005F56 22               [24]  784 	ret
      005F57                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005F57 90 07 99         [24]  787 	mov	dptr,#_raw_state
      005F5A E0               [24]  788 	movx	a,@dptr
      005F5B FF               [12]  789 	mov	r7,a
      005F5C BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005F5F 90 07 99         [24]  791 	mov	dptr,#_raw_state
      005F62 E4               [12]  792 	clr	a
      005F63 F0               [24]  793 	movx	@dptr,a
      005F64                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005F64 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005F65                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005F65 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005F68 74 01            [12]  809 	mov	a,#0x01
      005F6A F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F6B F5 82            [12]  812 	mov	dpl,a
      005F6D 74 12            [12]  813 	mov	a,#0x12
      005F6F F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F70 A3               [24]  816 	inc	dptr
      005F71 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F72 A3               [24]  819 	inc	dptr
      005F73 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005F74 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005F77 E4               [12]  823 	clr	a
      005F78 F0               [24]  824 	movx	@dptr,a
      005F79 15 82            [12]  825 	dec	dpl
      005F7B F0               [24]  826 	movx	@dptr,a
      005F7C 15 82            [12]  827 	dec	dpl
      005F7E F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005F7F FF               [12]  830 	mov	r7,a
      005F80                        831 00103$:
      005F80 EF               [12]  832 	mov	a,r7
      005F81 24 BC            [12]  833 	add	a, #_input_snapshot
      005F83 F5 82            [12]  834 	mov	dpl,a
      005F85 E4               [12]  835 	clr	a
      005F86 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005F88 F5 83            [12]  837 	mov	dph,a
      005F8A E4               [12]  838 	clr	a
      005F8B F0               [24]  839 	movx	@dptr,a
      005F8C 0F               [12]  840 	inc	r7
      005F8D BF 34 00         [24]  841 	cjne	r7,#0x34,00139$
      005F90                        842 00139$:
      005F90 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005F92 90 07 C4         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005F95 74 06            [12]  846 	mov	a,#0x06
      005F97 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:118: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005F98 90 07 E4         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005F9B 74 02            [12]  850 	mov	a,#0x02
      005F9D F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005F9E 90 07 EA         [24]  853 	mov	dptr,#(_input_snapshot + 0x002e)
      005FA1 04               [12]  854 	inc	a
      005FA2 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005FA3 90 07 ED         [24]  857 	mov	dptr,#(_input_snapshot + 0x0031)
      005FA6 04               [12]  858 	inc	a
      005FA7 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005FA8 7F 00            [12]  861 	mov	r7,#0x00
      005FAA                        862 00105$:
      005FAA 8F 06            [24]  863 	mov	ar6,r7
      005FAC 74 C0            [12]  864 	mov	a,#0xc0
      005FAE 2E               [12]  865 	add	a, r6
      005FAF F5 82            [12]  866 	mov	dpl,a
      005FB1 74 10            [12]  867 	mov	a,#0x10
      005FB3 24 00            [12]  868 	add	a, #0x00
      005FB5 F5 83            [12]  869 	mov	dph,a
      005FB7 E4               [12]  870 	clr	a
      005FB8 F0               [24]  871 	movx	@dptr,a
      005FB9 0F               [12]  872 	inc	r7
      005FBA BF 20 00         [24]  873 	cjne	r7,#0x20,00141$
      005FBD                        874 00141$:
      005FBD 40 EB            [24]  875 	jc	00105$
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    877 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005FBF 02 5F 0F         [24]  878 	ljmp	_raw_abort
                                    879 ;------------------------------------------------------------
                                    880 ;Allocation info for local variables in function 'control_stall'
                                    881 ;------------------------------------------------------------
                                    882 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function control_stall
                                    885 ;	-----------------------------------------
      005FC2                        886 _control_stall:
                                    887 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005FC2 90 07 99         [24]  888 	mov	dptr,#_raw_state
      005FC5 E0               [24]  889 	movx	a,@dptr
      005FC6 FF               [12]  890 	mov	r7,a
      005FC7 BF 01 05         [24]  891 	cjne	r7,#0x01,00102$
      005FCA 90 07 99         [24]  892 	mov	dptr,#_raw_state
      005FCD E4               [12]  893 	clr	a
      005FCE F0               [24]  894 	movx	@dptr,a
      005FCF                        895 00102$:
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005FCF 90 07 F1         [24]  897 	mov	dptr,#_output_kind
      005FD2 E4               [12]  898 	clr	a
      005FD3 F0               [24]  899 	movx	@dptr,a
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005FD4 90 07 F0         [24]  901 	mov	dptr,#_control_phase
      005FD7 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005FD8 90 07 8B         [24]  904 	mov	dptr,#_D0SetupReqCode
      005FDB 14               [12]  905 	dec	a
      005FDC F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005FDD 90 22 00         [24]  908 	mov	dptr,#0x2200
      005FE0 74 CF            [12]  909 	mov	a,#0xcf
      005FE2 F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005FE3 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'control_next'
                                    915 ;------------------------------------------------------------
                                    916 ;i             Allocated with name '_control_next_i_10000_266'
                                    917 ;length        Allocated with name '_control_next_length_10000_266'
                                    918 ;------------------------------------------------------------
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    920 ;	-----------------------------------------
                                    921 ;	 function control_next
                                    922 ;	-----------------------------------------
      005FE4                        923 _control_next:
                                    924 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005FE4 90 07 8C         [24]  925 	mov	dptr,#_D0SetupLen
      005FE7 E0               [24]  926 	movx	a,@dptr
      005FE8 FE               [12]  927 	mov	r6,a
      005FE9 A3               [24]  928 	inc	dptr
      005FEA E0               [24]  929 	movx	a,@dptr
      005FEB FF               [12]  930 	mov	r7,a
      005FEC C3               [12]  931 	clr	c
      005FED 74 40            [12]  932 	mov	a,#0x40
      005FEF 9E               [12]  933 	subb	a,r6
      005FF0 E4               [12]  934 	clr	a
      005FF1 9F               [12]  935 	subb	a,r7
      005FF2 50 04            [24]  936 	jnc	00109$
                                    937 ;	free result
      005FF4 7E 40            [12]  938 	mov	r6,#0x40
      005FF6 80 07            [24]  939 	sjmp	00110$
      005FF8                        940 00109$:
      005FF8 90 07 8C         [24]  941 	mov	dptr,#_D0SetupLen
      005FFB E0               [24]  942 	movx	a,@dptr
      005FFC FE               [12]  943 	mov	r6,a
      005FFD A3               [24]  944 	inc	dptr
      005FFE E0               [24]  945 	movx	a,@dptr
      005FFF                        946 00110$:
                                    947 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005FFF 7F 00            [12]  948 	mov	r7,#0x00
      006001                        949 00105$:
      006001 C3               [12]  950 	clr	c
      006002 EF               [12]  951 	mov	a,r7
      006003 9E               [12]  952 	subb	a,r6
      006004 50 2A            [24]  953 	jnc	00101$
      006006 8F 04            [24]  954 	mov	ar4,r7
      006008 74 10            [12]  955 	mov	a,#0x10
      00600A 24 00            [12]  956 	add	a, #0x00
      00600C FD               [12]  957 	mov	r5,a
      00600D 90 07 F4         [24]  958 	mov	dptr,#_control_pointer
      006010 E0               [24]  959 	movx	a,@dptr
      006011 FA               [12]  960 	mov	r2,a
      006012 A3               [24]  961 	inc	dptr
      006013 E0               [24]  962 	movx	a,@dptr
      006014 FB               [12]  963 	mov	r3,a
      006015 8A 82            [24]  964 	mov	dpl,r2
      006017 8B 83            [24]  965 	mov	dph,r3
      006019 E4               [12]  966 	clr	a
      00601A 93               [24]  967 	movc	a,@a+dptr
      00601B F9               [12]  968 	mov	r1,a
      00601C 90 07 F4         [24]  969 	mov	dptr,#_control_pointer
      00601F 74 01            [12]  970 	mov	a,#0x01
      006021 2A               [12]  971 	add	a, r2
      006022 F0               [24]  972 	movx	@dptr,a
      006023 E4               [12]  973 	clr	a
      006024 3B               [12]  974 	addc	a, r3
      006025 A3               [24]  975 	inc	dptr
      006026 F0               [24]  976 	movx	@dptr,a
      006027 8C 82            [24]  977 	mov	dpl,r4
      006029 8D 83            [24]  978 	mov	dph,r5
      00602B E9               [12]  979 	mov	a,r1
      00602C F0               [24]  980 	movx	@dptr,a
      00602D 0F               [12]  981 	inc	r7
      00602E 80 D1            [24]  982 	sjmp	00105$
      006030                        983 00101$:
                                    984 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      006030 8E 05            [24]  985 	mov	ar5,r6
      006032 7F 00            [12]  986 	mov	r7,#0x00
      006034 90 07 8C         [24]  987 	mov	dptr,#_D0SetupLen
      006037 E0               [24]  988 	movx	a,@dptr
      006038 FB               [12]  989 	mov	r3,a
      006039 A3               [24]  990 	inc	dptr
      00603A E0               [24]  991 	movx	a,@dptr
      00603B FC               [12]  992 	mov	r4,a
      00603C EB               [12]  993 	mov	a,r3
      00603D C3               [12]  994 	clr	c
      00603E 9D               [12]  995 	subb	a,r5
      00603F FB               [12]  996 	mov	r3,a
      006040 EC               [12]  997 	mov	a,r4
      006041 9F               [12]  998 	subb	a,r7
      006042 FC               [12]  999 	mov	r4,a
      006043 90 07 8C         [24] 1000 	mov	dptr,#_D0SetupLen
      006046 EB               [12] 1001 	mov	a,r3
      006047 F0               [24] 1002 	movx	@dptr,a
      006048 EC               [12] 1003 	mov	a,r4
      006049 A3               [24] 1004 	inc	dptr
      00604A F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      00604B EE               [12] 1007 	mov	a,r6
      00604C 70 05            [24] 1008 	jnz	00103$
      00604E 90 07 F3         [24] 1009 	mov	dptr,#_control_zlp
      006051 E4               [12] 1010 	clr	a
      006052 F0               [24] 1011 	movx	@dptr,a
      006053                       1012 00103$:
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      006053 90 22 08         [24] 1014 	mov	dptr,#0x2208
      006056 EE               [12] 1015 	mov	a,r6
      006057 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      006058 90 22 00         [24] 1018 	mov	dptr,#0x2200
      00605B E0               [24] 1019 	movx	a,@dptr
      00605C 54 C0            [12] 1020 	anl	a,#0xc0
      00605E F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      00605F 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'descriptor_select'
                                   1026 ;------------------------------------------------------------
                                   1027 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1028 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1029 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1030 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function descriptor_select
                                   1035 ;	-----------------------------------------
      006060                       1036 _descriptor_select:
      006060 E5 82            [12] 1037 	mov	a,dpl
      006062 90 07 F9         [24] 1038 	mov	dptr,#_descriptor_select_type_10000_269
      006065 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      006066 E0               [24] 1041 	movx	a,@dptr
      006067 FF               [12] 1042 	mov	r7,a
      006068 BF 01 20         [24] 1043 	cjne	r7,#0x01,00102$
      00606B 90 07 F6         [24] 1044 	mov	dptr,#_descriptor_select_PARM_2
      00606E E0               [24] 1045 	movx	a,@dptr
      00606F 70 1A            [24] 1046 	jnz	00102$
      006071 90 07 F7         [24] 1047 	mov	dptr,#_descriptor_select_PARM_3
      006074 E0               [24] 1048 	movx	a,@dptr
      006075 F5 F0            [12] 1049 	mov	b,a
      006077 A3               [24] 1050 	inc	dptr
      006078 E0               [24] 1051 	movx	a,@dptr
      006079 45 F0            [12] 1052 	orl	a,b
      00607B 70 0E            [24] 1053 	jnz	00102$
                                   1054 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      00607D 90 07 F4         [24] 1055 	mov	dptr,#_control_pointer
      006080 74 B7            [12] 1056 	mov	a,#_DeviceDescriptor
      006082 F0               [24] 1057 	movx	@dptr,a
      006083 74 C4            [12] 1058 	mov	a,#(_DeviceDescriptor >> 8)
      006085 A3               [24] 1059 	inc	dptr
      006086 F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      006087 90 00 12         [24] 1062 	mov	dptr,#0x0012
      00608A 22               [24] 1063 	ret
      00608B                       1064 00102$:
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      00608B 90 07 F9         [24] 1066 	mov	dptr,#_descriptor_select_type_10000_269
      00608E E0               [24] 1067 	movx	a,@dptr
      00608F FF               [12] 1068 	mov	r7,a
      006090 BF 02 20         [24] 1069 	cjne	r7,#0x02,00106$
      006093 90 07 F6         [24] 1070 	mov	dptr,#_descriptor_select_PARM_2
      006096 E0               [24] 1071 	movx	a,@dptr
      006097 70 1A            [24] 1072 	jnz	00106$
      006099 90 07 F7         [24] 1073 	mov	dptr,#_descriptor_select_PARM_3
      00609C E0               [24] 1074 	movx	a,@dptr
      00609D F5 F0            [12] 1075 	mov	b,a
      00609F A3               [24] 1076 	inc	dptr
      0060A0 E0               [24] 1077 	movx	a,@dptr
      0060A1 45 F0            [12] 1078 	orl	a,b
      0060A3 70 0E            [24] 1079 	jnz	00106$
                                   1080 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      0060A5 90 07 F4         [24] 1081 	mov	dptr,#_control_pointer
      0060A8 74 C9            [12] 1082 	mov	a,#_ConfigurationDescriptor
      0060AA F0               [24] 1083 	movx	@dptr,a
      0060AB 74 C4            [12] 1084 	mov	a,#(_ConfigurationDescriptor >> 8)
      0060AD A3               [24] 1085 	inc	dptr
      0060AE F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      0060AF 90 00 54         [24] 1088 	mov	dptr,#0x0054
      0060B2 22               [24] 1089 	ret
      0060B3                       1090 00106$:
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      0060B3 90 07 F9         [24] 1092 	mov	dptr,#_descriptor_select_type_10000_269
      0060B6 E0               [24] 1093 	movx	a,@dptr
      0060B7 FF               [12] 1094 	mov	r7,a
      0060B8 BF 03 02         [24] 1095 	cjne	r7,#0x03,00238$
      0060BB 80 03            [24] 1096 	sjmp	00239$
      0060BD                       1097 00238$:
      0060BD 02 61 57         [24] 1098 	ljmp	00119$
      0060C0                       1099 00239$:
                                   1100 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      0060C0 90 07 F7         [24] 1101 	mov	dptr,#_descriptor_select_PARM_3
      0060C3 E0               [24] 1102 	movx	a,@dptr
      0060C4 FD               [12] 1103 	mov	r5,a
      0060C5 A3               [24] 1104 	inc	dptr
      0060C6 E0               [24] 1105 	movx	a,@dptr
      0060C7 FE               [12] 1106 	mov	r6,a
      0060C8 90 07 F7         [24] 1107 	mov	dptr,#_descriptor_select_PARM_3
      0060CB E0               [24] 1108 	movx	a,@dptr
      0060CC F5 F0            [12] 1109 	mov	b,a
      0060CE A3               [24] 1110 	inc	dptr
      0060CF E0               [24] 1111 	movx	a,@dptr
      0060D0 45 F0            [12] 1112 	orl	a,b
      0060D2 60 0C            [24] 1113 	jz	00110$
      0060D4 BD 09 05         [24] 1114 	cjne	r5,#0x09,00241$
      0060D7 BE 04 02         [24] 1115 	cjne	r6,#0x04,00241$
      0060DA 80 04            [24] 1116 	sjmp	00110$
      0060DC                       1117 00241$:
      0060DC 90 00 00         [24] 1118 	mov	dptr,#0x0000
      0060DF 22               [24] 1119 	ret
      0060E0                       1120 00110$:
                                   1121 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      0060E0 90 07 F6         [24] 1122 	mov	dptr,#_descriptor_select_PARM_2
      0060E3 E0               [24] 1123 	movx	a,@dptr
      0060E4 FE               [12] 1124 	mov  r6,a
      0060E5 24 FC            [12] 1125 	add	a,#0xff - 0x03
      0060E7 40 6A            [24] 1126 	jc	00116$
                                   1127 ;	free result
      0060E9 EE               [12] 1128 	mov	a,r6
      0060EA 2E               [12] 1129 	add	a,r6
                                   1130 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      0060EB 90 60 EF         [24] 1131 	mov	dptr,#00243$
      0060EE 73               [24] 1132 	jmp	@a+dptr
      0060EF                       1133 00243$:
      0060EF 80 06            [24] 1134 	sjmp	00112$
      0060F1 80 1B            [24] 1135 	sjmp	00113$
      0060F3 80 30            [24] 1136 	sjmp	00114$
      0060F5 80 45            [24] 1137 	sjmp	00115$
      0060F7                       1138 00112$:
      0060F7 90 07 F4         [24] 1139 	mov	dptr,#_control_pointer
      0060FA 74 1D            [12] 1140 	mov	a,#_LanguageString
      0060FC F0               [24] 1141 	movx	@dptr,a
      0060FD 74 C5            [12] 1142 	mov	a,#(_LanguageString >> 8)
      0060FF A3               [24] 1143 	inc	dptr
      006100 F0               [24] 1144 	movx	@dptr,a
      006101 90 C5 1D         [24] 1145 	mov	dptr,#_LanguageString
      006104 E4               [12] 1146 	clr	a
      006105 93               [24] 1147 	movc	a,@a+dptr
      006106 FE               [12] 1148 	mov	r6,a
      006107 7D 00            [12] 1149 	mov	r5,#0x00
      006109 8E 82            [24] 1150 	mov	dpl, r6
      00610B 8D 83            [24] 1151 	mov	dph, r5
      00610D 22               [24] 1152 	ret
                                   1153 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      00610E                       1154 00113$:
      00610E 90 07 F4         [24] 1155 	mov	dptr,#_control_pointer
      006111 74 21            [12] 1156 	mov	a,#_ManufacturerString
      006113 F0               [24] 1157 	movx	@dptr,a
      006114 74 C5            [12] 1158 	mov	a,#(_ManufacturerString >> 8)
      006116 A3               [24] 1159 	inc	dptr
      006117 F0               [24] 1160 	movx	@dptr,a
      006118 90 C5 21         [24] 1161 	mov	dptr,#_ManufacturerString
      00611B E4               [12] 1162 	clr	a
      00611C 93               [24] 1163 	movc	a,@a+dptr
      00611D FE               [12] 1164 	mov	r6,a
      00611E 7D 00            [12] 1165 	mov	r5,#0x00
      006120 8E 82            [24] 1166 	mov	dpl, r6
      006122 8D 83            [24] 1167 	mov	dph, r5
      006124 22               [24] 1168 	ret
                                   1169 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      006125                       1170 00114$:
      006125 90 07 F4         [24] 1171 	mov	dptr,#_control_pointer
      006128 74 2F            [12] 1172 	mov	a,#_ProductString
      00612A F0               [24] 1173 	movx	@dptr,a
      00612B 74 C5            [12] 1174 	mov	a,#(_ProductString >> 8)
      00612D A3               [24] 1175 	inc	dptr
      00612E F0               [24] 1176 	movx	@dptr,a
      00612F 90 C5 2F         [24] 1177 	mov	dptr,#_ProductString
      006132 E4               [12] 1178 	clr	a
      006133 93               [24] 1179 	movc	a,@a+dptr
      006134 FE               [12] 1180 	mov	r6,a
      006135 7D 00            [12] 1181 	mov	r5,#0x00
      006137 8E 82            [24] 1182 	mov	dpl, r6
      006139 8D 83            [24] 1183 	mov	dph, r5
      00613B 22               [24] 1184 	ret
                                   1185 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      00613C                       1186 00115$:
      00613C 90 07 F4         [24] 1187 	mov	dptr,#_control_pointer
      00613F 74 67            [12] 1188 	mov	a,#_SerialNumberString
      006141 F0               [24] 1189 	movx	@dptr,a
      006142 74 C5            [12] 1190 	mov	a,#(_SerialNumberString >> 8)
      006144 A3               [24] 1191 	inc	dptr
      006145 F0               [24] 1192 	movx	@dptr,a
      006146 90 C5 67         [24] 1193 	mov	dptr,#_SerialNumberString
      006149 E4               [12] 1194 	clr	a
      00614A 93               [24] 1195 	movc	a,@a+dptr
      00614B FE               [12] 1196 	mov	r6,a
      00614C 7D 00            [12] 1197 	mov	r5,#0x00
      00614E 8E 82            [24] 1198 	mov	dpl, r6
      006150 8D 83            [24] 1199 	mov	dph, r5
      006152 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      006153                       1202 00116$:
      006153 90 00 00         [24] 1203 	mov	dptr,#0x0000
      006156 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      006157                       1206 00119$:
                                   1207 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      006157 90 07 F6         [24] 1208 	mov	dptr,#_descriptor_select_PARM_2
      00615A E0               [24] 1209 	movx	a,@dptr
      00615B 70 11            [24] 1210 	jnz	00120$
      00615D 90 07 F7         [24] 1211 	mov	dptr,#_descriptor_select_PARM_3
      006160 E0               [24] 1212 	movx	a,@dptr
      006161 FD               [12] 1213 	mov	r5,a
      006162 A3               [24] 1214 	inc	dptr
      006163 E0               [24] 1215 	movx	a,@dptr
      006164 FE               [12] 1216 	mov	r6,a
      006165 C3               [12] 1217 	clr	c
      006166 ED               [12] 1218 	mov	a,r5
      006167 94 03            [12] 1219 	subb	a,#0x03
      006169 EE               [12] 1220 	mov	a,r6
      00616A 94 00            [12] 1221 	subb	a,#0x00
      00616C 40 04            [24] 1222 	jc	00121$
      00616E                       1223 00120$:
      00616E 90 00 00         [24] 1224 	mov	dptr,#0x0000
      006171 22               [24] 1225 	ret
      006172                       1226 00121$:
                                   1227 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006172 BF 22 02         [24] 1228 	cjne	r7,#0x22,00246$
      006175 80 03            [24] 1229 	sjmp	00127$
      006177                       1230 00246$:
      006177 BF 21 5D         [24] 1231 	cjne	r7,#0x21,00128$
      00617A                       1232 00127$:
                                   1233 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      00617A ED               [12] 1234 	mov	a,r5
      00617B 75 F0 04         [24] 1235 	mov	b,#0x04
      00617E A4               [48] 1236 	mul	ab
      00617F 24 EF            [12] 1237 	add	a, #_interface_descriptors
      006181 FE               [12] 1238 	mov	r6,a
      006182 74 BD            [12] 1239 	mov	a,#(_interface_descriptors >> 8)
      006184 35 F0            [12] 1240 	addc	a, b
      006186 FF               [12] 1241 	mov	r7,a
      006187 8E 82            [24] 1242 	mov	dpl,r6
      006189 8F 83            [24] 1243 	mov	dph,r7
      00618B A3               [24] 1244 	inc	dptr
      00618C A3               [24] 1245 	inc	dptr
      00618D E4               [12] 1246 	clr	a
      00618E 93               [24] 1247 	movc	a,@a+dptr
      00618F FC               [12] 1248 	mov	r4,a
      006190 A3               [24] 1249 	inc	dptr
      006191 E4               [12] 1250 	clr	a
      006192 93               [24] 1251 	movc	a,@a+dptr
                                   1252 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      006193 FD               [12] 1253 	mov	r5,a
      006194 4C               [12] 1254 	orl	a,r4
      006195 70 04            [24] 1255 	jnz	00124$
      006197 90 00 00         [24] 1256 	mov	dptr,#0x0000
      00619A 22               [24] 1257 	ret
      00619B                       1258 00124$:
                                   1259 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      00619B 90 07 F9         [24] 1260 	mov	dptr,#_descriptor_select_type_10000_269
      00619E E0               [24] 1261 	movx	a,@dptr
      00619F FB               [12] 1262 	mov	r3,a
      0061A0 BB 22 28         [24] 1263 	cjne	r3,#0x22,00126$
                                   1264 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      0061A3 8E 82            [24] 1265 	mov	dpl,r6
      0061A5 8F 83            [24] 1266 	mov	dph,r7
      0061A7 E4               [12] 1267 	clr	a
      0061A8 93               [24] 1268 	movc	a,@a+dptr
      0061A9 FE               [12] 1269 	mov	r6,a
      0061AA A3               [24] 1270 	inc	dptr
      0061AB E4               [12] 1271 	clr	a
      0061AC 93               [24] 1272 	movc	a,@a+dptr
      0061AD FF               [12] 1273 	mov	r7,a
      0061AE 90 07 F4         [24] 1274 	mov	dptr,#_control_pointer
      0061B1 EE               [12] 1275 	mov	a,r6
      0061B2 F0               [24] 1276 	movx	@dptr,a
      0061B3 EF               [12] 1277 	mov	a,r7
      0061B4 A3               [24] 1278 	inc	dptr
      0061B5 F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      0061B6 74 07            [12] 1281 	mov	a,#0x07
      0061B8 2C               [12] 1282 	add	a, r4
      0061B9 F5 82            [12] 1283 	mov	dpl,a
      0061BB E4               [12] 1284 	clr	a
      0061BC 3D               [12] 1285 	addc	a, r5
      0061BD F5 83            [12] 1286 	mov	dph,a
      0061BF E4               [12] 1287 	clr	a
      0061C0 93               [24] 1288 	movc	a,@a+dptr
      0061C1 FE               [12] 1289 	mov	r6,a
      0061C2 A3               [24] 1290 	inc	dptr
      0061C3 E4               [12] 1291 	clr	a
      0061C4 93               [24] 1292 	movc	a,@a+dptr
      0061C5 FF               [12] 1293 	mov	r7,a
      0061C6 8E 82            [24] 1294 	mov	dpl, r6
      0061C8 8F 83            [24] 1295 	mov	dph, r7
      0061CA 22               [24] 1296 	ret
      0061CB                       1297 00126$:
                                   1298 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      0061CB 90 07 F4         [24] 1299 	mov	dptr,#_control_pointer
      0061CE EC               [12] 1300 	mov	a,r4
      0061CF F0               [24] 1301 	movx	@dptr,a
      0061D0 ED               [12] 1302 	mov	a,r5
      0061D1 A3               [24] 1303 	inc	dptr
      0061D2 F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      0061D3 90 00 09         [24] 1306 	mov	dptr,#0x0009
      0061D6 22               [24] 1307 	ret
      0061D7                       1308 00128$:
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      0061D7 90 00 00         [24] 1310 	mov	dptr,#0x0000
                                   1311 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      0061DA 22               [24] 1312 	ret
                                   1313 ;------------------------------------------------------------
                                   1314 ;Allocation info for local variables in function 'control_setup'
                                   1315 ;------------------------------------------------------------
                                   1316 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1317 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1318 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1319 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1320 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1321 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1322 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1323 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1324 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1325 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1326 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1327 ;------------------------------------------------------------
                                   1328 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1329 ;	-----------------------------------------
                                   1330 ;	 function control_setup
                                   1331 ;	-----------------------------------------
      0061DB                       1332 _control_setup:
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      0061DB 90 10 00         [24] 1334 	mov	dptr,#0x1000
      0061DE E0               [24] 1335 	movx	a,@dptr
      0061DF FF               [12] 1336 	mov	r7,a
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      0061E0 A3               [24] 1338 	inc	dptr
      0061E1 A3               [24] 1339 	inc	dptr
      0061E2 E0               [24] 1340 	movx	a,@dptr
      0061E3 FE               [12] 1341 	mov	r6,a
      0061E4 A3               [24] 1342 	inc	dptr
      0061E5 E0               [24] 1343 	movx	a,@dptr
      0061E6 FC               [12] 1344 	mov	r4,a
      0061E7 7D 00            [12] 1345 	mov	r5,#0x00
      0061E9 8E 03            [24] 1346 	mov	ar3,r6
      0061EB 7E 00            [12] 1347 	mov	r6,#0x00
      0061ED ED               [12] 1348 	mov	a,r5
      0061EE 4B               [12] 1349 	orl	a,r3
      0061EF FD               [12] 1350 	mov	r5,a
      0061F0 EC               [12] 1351 	mov	a,r4
      0061F1 4E               [12] 1352 	orl	a,r6
      0061F2 FE               [12] 1353 	mov	r6,a
                                   1354 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0061F3 A3               [24] 1355 	inc	dptr
      0061F4 E0               [24] 1356 	movx	a,@dptr
      0061F5 FC               [12] 1357 	mov	r4,a
      0061F6 A3               [24] 1358 	inc	dptr
      0061F7 E0               [24] 1359 	movx	a,@dptr
      0061F8 FA               [12] 1360 	mov	r2,a
      0061F9 7B 00            [12] 1361 	mov	r3,#0x00
      0061FB 8C 01            [24] 1362 	mov	ar1,r4
      0061FD 7C 00            [12] 1363 	mov	r4,#0x00
      0061FF EB               [12] 1364 	mov	a,r3
      006200 49               [12] 1365 	orl	a,r1
      006201 FB               [12] 1366 	mov	r3,a
      006202 EA               [12] 1367 	mov	a,r2
      006203 4C               [12] 1368 	orl	a,r4
      006204 FC               [12] 1369 	mov	r4,a
                                   1370 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      006205 C3               [12] 1371 	clr	c
      006206 EB               [12] 1372 	mov	a,r3
      006207 94 03            [12] 1373 	subb	a,#0x03
      006209 EC               [12] 1374 	mov	a,r4
      00620A 94 00            [12] 1375 	subb	a,#0x00
      00620C 92 17            [24] 1376 	mov	_control_setup_valid_interface_10000_287,c
                                   1377 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      00620E EB               [12] 1378 	mov	a,r3
      00620F 4C               [12] 1379 	orl	a,r4
      006210 B4 01 00         [24] 1380 	cjne	a,#0x01,01201$
      006213                       1381 01201$:
      006213 92 18            [24] 1382 	mov	_control_setup_zero_index_10000_287,c
                                   1383 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      006215 ED               [12] 1384 	mov	a,r5
      006216 4E               [12] 1385 	orl	a,r6
      006217 B4 01 00         [24] 1386 	cjne	a,#0x01,01202$
      00621A                       1387 01202$:
                                   1388 ;	assignBit
      00621A 92 1B            [24] 1389 	mov  _control_setup_sloc0_1_0,c
      00621C 92 19            [24] 1390 	mov	_control_setup_zero_value_10000_287,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      00621E 90 07 FC         [24] 1392 	mov	dptr,#_control_setup_offset_10000_287
      006221 E4               [12] 1393 	clr	a
      006222 F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006223 90 07 99         [24] 1396 	mov	dptr,#_raw_state
      006226 E0               [24] 1397 	movx	a,@dptr
      006227 FA               [12] 1398 	mov	r2,a
      006228 BA 01 05         [24] 1399 	cjne	r2,#0x01,00102$
      00622B 90 07 99         [24] 1400 	mov	dptr,#_raw_state
      00622E E4               [12] 1401 	clr	a
      00622F F0               [24] 1402 	movx	@dptr,a
      006230                       1403 00102$:
                                   1404 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      006230 C0 07            [24] 1405 	push	ar7
      006232 90 07 F1         [24] 1406 	mov	dptr,#_output_kind
      006235 E4               [12] 1407 	clr	a
      006236 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      006237 90 07 F0         [24] 1410 	mov	dptr,#_control_phase
      00623A F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      00623B 90 07 F3         [24] 1413 	mov	dptr,#_control_zlp
      00623E F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      00623F 90 10 01         [24] 1416 	mov	dptr,#0x1001
      006242 E0               [24] 1417 	movx	a,@dptr
      006243 90 07 8B         [24] 1418 	mov	dptr,#_D0SetupReqCode
      006246 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      006247 90 10 06         [24] 1421 	mov	dptr,#0x1006
      00624A E0               [24] 1422 	movx	a,@dptr
      00624B FA               [12] 1423 	mov	r2,a
      00624C A3               [24] 1424 	inc	dptr
      00624D E0               [24] 1425 	movx	a,@dptr
      00624E F9               [12] 1426 	mov	r1,a
      00624F 78 00            [12] 1427 	mov	r0,#0x00
      006251 7F 00            [12] 1428 	mov	r7,#0x00
      006253 90 07 8C         [24] 1429 	mov	dptr,#_D0SetupLen
      006256 E8               [12] 1430 	mov	a,r0
      006257 4A               [12] 1431 	orl	a,r2
      006258 F0               [24] 1432 	movx	@dptr,a
      006259 E9               [12] 1433 	mov	a,r1
      00625A 4F               [12] 1434 	orl	a,r7
      00625B A3               [24] 1435 	inc	dptr
      00625C F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      00625D 90 07 8C         [24] 1438 	mov	dptr,#_D0SetupLen
      006260 E0               [24] 1439 	movx	a,@dptr
      006261 FA               [12] 1440 	mov	r2,a
      006262 A3               [24] 1441 	inc	dptr
      006263 E0               [24] 1442 	movx	a,@dptr
      006264 4A               [12] 1443 	orl	a,r2
      006265 B4 01 00         [24] 1444 	cjne	a,#0x01,01205$
      006268                       1445 01205$:
      006268 92 1A            [24] 1446 	mov	_control_setup_zero_length_10000_287,c
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00626A 90 22 00         [24] 1448 	mov	dptr,#0x2200
      00626D 74 C2            [12] 1449 	mov	a,#0xc2
      00626F F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      006270 90 22 08         [24] 1452 	mov	dptr,#0x2208
      006273 E4               [12] 1453 	clr	a
      006274 F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      006275 90 07 8B         [24] 1456 	mov	dptr,#_D0SetupReqCode
      006278 E0               [24] 1457 	movx	a,@dptr
      006279 F5 16            [12] 1458 	mov	_control_setup_sloc1_1_0,a
      00627B C3               [12] 1459 	clr	c
      00627C 74 0B            [12] 1460 	mov	a,#0x0b
      00627E 95 16            [12] 1461 	subb	a,_control_setup_sloc1_1_0
      006280 D0 07            [24] 1462 	pop	ar7
      006282 50 03            [24] 1463 	jnc	01206$
      006284 02 5F C2         [24] 1464 	ljmp	_control_stall
      006287                       1465 01206$:
                                   1466 ;	free result
      006287 E5 16            [12] 1467 	mov	a,_control_setup_sloc1_1_0
      006289 F5 F0            [12] 1468 	mov	b,a
      00628B 24 0B            [12] 1469 	add	a,#(01207$-3-.)
      00628D 83               [24] 1470 	movc	a,@a+pc
      00628E F5 82            [12] 1471 	mov	dpl,a
      006290 E5 F0            [12] 1472 	mov	a,b
      006292 24 10            [12] 1473 	add	a,#(01208$-3-.)
      006294 83               [24] 1474 	movc	a,@a+pc
      006295 F5 83            [12] 1475 	mov	dph,a
      006297 E4               [12] 1476 	clr	a
      006298 73               [24] 1477 	jmp	@a+dptr
      006299                       1478 01207$:
      006299 41                    1479 	.db	00188$
      00629A E7                    1480 	.db	00205$
      00629B 2A                    1481 	.db	00282$
      00629C E7                    1482 	.db	00205$
      00629D 6E                    1483 	.db	00290$
      00629E 6B                    1484 	.db	00116$
      00629F B1                    1485 	.db	00103$
      0062A0 6E                    1486 	.db	00290$
      0062A1 70                    1487 	.db	00150$
      0062A2 94                    1488 	.db	00123$
      0062A3 A0                    1489 	.db	00157$
      0062A4 F3                    1490 	.db	00173$
      0062A5                       1491 01208$:
      0062A5 65                    1492 	.db	00188$>>8
      0062A6 65                    1493 	.db	00205$>>8
      0062A7 69                    1494 	.db	00282$>>8
      0062A8 65                    1495 	.db	00205$>>8
      0062A9 69                    1496 	.db	00290$>>8
      0062AA 63                    1497 	.db	00116$>>8
      0062AB 62                    1498 	.db	00103$>>8
      0062AC 69                    1499 	.db	00290$>>8
      0062AD 64                    1500 	.db	00150$>>8
      0062AE 63                    1501 	.db	00123$>>8
      0062AF 64                    1502 	.db	00157$>>8
      0062B0 64                    1503 	.db	00173$>>8
                                   1504 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      0062B1                       1505 00103$:
                                   1506 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      0062B1 BF 80 02         [24] 1507 	cjne	r7,#0x80,01209$
      0062B4 80 08            [24] 1508 	sjmp	00112$
      0062B6                       1509 01209$:
      0062B6 BF 81 02         [24] 1510 	cjne	r7,#0x81,01210$
      0062B9 80 03            [24] 1511 	sjmp	01211$
      0062BB                       1512 01210$:
      0062BB 02 5F C2         [24] 1513 	ljmp	_control_stall
      0062BE                       1514 01211$:
      0062BE                       1515 00112$:
                                   1516 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0062BE 8E 01            [24] 1517 	mov	ar1,r6
      0062C0 B9 21 02         [24] 1518 	cjne	r1,#0x21,01212$
      0062C3 80 09            [24] 1519 	sjmp	00301$
      0062C5                       1520 01212$:
      0062C5 B9 22 02         [24] 1521 	cjne	r1,#0x22,01213$
      0062C8 80 04            [24] 1522 	sjmp	00301$
      0062CA                       1523 01213$:
                                   1524 ;	assignBit
      0062CA C2 1C            [12] 1525 	clr	_control_setup_sloc2_1_0
      0062CC 80 02            [24] 1526 	sjmp	00302$
      0062CE                       1527 00301$:
                                   1528 ;	assignBit
      0062CE D2 1C            [12] 1529 	setb	_control_setup_sloc2_1_0
      0062D0                       1530 00302$:
      0062D0 E4               [12] 1531 	clr	a
      0062D1 BF 81 01         [24] 1532 	cjne	r7,#0x81,01214$
      0062D4 04               [12] 1533 	inc	a
      0062D5                       1534 01214$:
      0062D5 FA               [12] 1535 	mov	r2,a
      0062D6 A2 1C            [12] 1536 	mov	c,_control_setup_sloc2_1_0
      0062D8 E4               [12] 1537 	clr	a
      0062D9 33               [12] 1538 	rlc	a
      0062DA B5 02 02         [24] 1539 	cjne	a,ar2,01216$
      0062DD 80 03            [24] 1540 	sjmp	00105$
      0062DF                       1541 01216$:
                                   1542 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      0062DF 02 5F C2         [24] 1543 	ljmp	_control_stall
      0062E2                       1544 00105$:
                                   1545 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      0062E2 8E 02            [24] 1546 	mov	ar2,r6
      0062E4 90 07 F6         [24] 1547 	mov	dptr,#_descriptor_select_PARM_2
      0062E7 ED               [12] 1548 	mov	a,r5
      0062E8 F0               [24] 1549 	movx	@dptr,a
      0062E9 90 07 F7         [24] 1550 	mov	dptr,#_descriptor_select_PARM_3
      0062EC EB               [12] 1551 	mov	a,r3
      0062ED F0               [24] 1552 	movx	@dptr,a
      0062EE EC               [12] 1553 	mov	a,r4
      0062EF A3               [24] 1554 	inc	dptr
      0062F0 F0               [24] 1555 	movx	@dptr,a
      0062F1 8A 82            [24] 1556 	mov	dpl, r2
      0062F3 12 60 60         [24] 1557 	lcall	_descriptor_select
      0062F6 85 82 17         [24] 1558 	mov	_control_setup_sloc3_1_0,dpl
      0062F9 85 83 18         [24] 1559 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1560 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      0062FC E5 17            [12] 1561 	mov	a,_control_setup_sloc3_1_0
      0062FE 45 18            [12] 1562 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006300 70 03            [24] 1563 	jnz	00107$
      006302 02 5F C2         [24] 1564 	ljmp	_control_stall
      006305                       1565 00107$:
                                   1566 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006305 90 07 8C         [24] 1567 	mov	dptr,#_D0SetupLen
      006308 E0               [24] 1568 	movx	a,@dptr
      006309 F8               [12] 1569 	mov	r0,a
      00630A A3               [24] 1570 	inc	dptr
      00630B E0               [24] 1571 	movx	a,@dptr
      00630C FA               [12] 1572 	mov	r2,a
      00630D C3               [12] 1573 	clr	c
      00630E E5 17            [12] 1574 	mov	a,_control_setup_sloc3_1_0
      006310 98               [12] 1575 	subb	a,r0
      006311 E5 18            [12] 1576 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006313 9A               [12] 1577 	subb	a,r2
      006314 50 06            [24] 1578 	jnc	00303$
      006316 E5 17            [12] 1579 	mov	a,_control_setup_sloc3_1_0
      006318 54 3F            [12] 1580 	anl	a,#0x3f
      00631A 60 04            [24] 1581 	jz	00304$
      00631C                       1582 00303$:
                                   1583 ;	assignBit
      00631C C2 1C            [12] 1584 	clr	_control_setup_sloc2_1_0
      00631E 80 02            [24] 1585 	sjmp	00305$
      006320                       1586 00304$:
                                   1587 ;	assignBit
      006320 D2 1C            [12] 1588 	setb	_control_setup_sloc2_1_0
      006322                       1589 00305$:
      006322 90 07 F3         [24] 1590 	mov	dptr,#_control_zlp
      006325 A2 1C            [12] 1591 	mov	c,_control_setup_sloc2_1_0
      006327 E4               [12] 1592 	clr	a
      006328 33               [12] 1593 	rlc	a
      006329 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      00632A 90 07 8C         [24] 1596 	mov	dptr,#_D0SetupLen
      00632D E0               [24] 1597 	movx	a,@dptr
      00632E F9               [12] 1598 	mov	r1,a
      00632F A3               [24] 1599 	inc	dptr
      006330 E0               [24] 1600 	movx	a,@dptr
      006331 FA               [12] 1601 	mov	r2,a
      006332 C3               [12] 1602 	clr	c
      006333 E5 17            [12] 1603 	mov	a,_control_setup_sloc3_1_0
      006335 99               [12] 1604 	subb	a,r1
      006336 E5 18            [12] 1605 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006338 9A               [12] 1606 	subb	a,r2
      006339 50 0A            [24] 1607 	jnc	00109$
                                   1608 ;	free result
      00633B 90 07 8C         [24] 1609 	mov	dptr,#_D0SetupLen
      00633E E5 17            [12] 1610 	mov	a,_control_setup_sloc3_1_0
      006340 F0               [24] 1611 	movx	@dptr,a
      006341 E5 18            [12] 1612 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006343 A3               [24] 1613 	inc	dptr
      006344 F0               [24] 1614 	movx	@dptr,a
      006345                       1615 00109$:
                                   1616 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      006345 90 07 8C         [24] 1617 	mov	dptr,#_D0SetupLen
      006348 E0               [24] 1618 	movx	a,@dptr
      006349 F9               [12] 1619 	mov	r1,a
      00634A A3               [24] 1620 	inc	dptr
      00634B E0               [24] 1621 	movx	a,@dptr
      00634C 49               [12] 1622 	orl	a,r1
      00634D 60 04            [24] 1623 	jz	00306$
      00634F 7A 01            [12] 1624 	mov	r2,#0x01
      006351 80 02            [24] 1625 	sjmp	00307$
      006353                       1626 00306$:
      006353 7A 02            [12] 1627 	mov	r2,#0x02
      006355                       1628 00307$:
      006355 90 07 F0         [24] 1629 	mov	dptr,#_control_phase
      006358 EA               [12] 1630 	mov	a,r2
      006359 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      00635A 90 07 8C         [24] 1633 	mov	dptr,#_D0SetupLen
      00635D E0               [24] 1634 	movx	a,@dptr
      00635E F9               [12] 1635 	mov	r1,a
      00635F A3               [24] 1636 	inc	dptr
      006360 E0               [24] 1637 	movx	a,@dptr
      006361 49               [12] 1638 	orl	a,r1
      006362 60 03            [24] 1639 	jz	00111$
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      006364 02 5F E4         [24] 1641 	ljmp	_control_next
      006367                       1642 00111$:
      006367 22               [24] 1643 	ret
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      006368 02 5F C2         [24] 1645 	ljmp	_control_stall
                                   1646 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      00636B                       1647 00116$:
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      00636B EF               [12] 1649 	mov	a,r7
      00636C 70 23            [24] 1650 	jnz	00118$
      00636E 30 18 20         [24] 1651 	jnb	_control_setup_zero_index_10000_287,00118$
      006371 30 1A 1D         [24] 1652 	jnb	_control_setup_zero_length_10000_287,00118$
      006374 8D 01            [24] 1653 	mov	ar1,r5
      006376 8E 02            [24] 1654 	mov	ar2,r6
      006378 C3               [12] 1655 	clr	c
      006379 74 7F            [12] 1656 	mov	a,#0x7f
      00637B 99               [12] 1657 	subb	a,r1
      00637C E4               [12] 1658 	clr	a
      00637D 9A               [12] 1659 	subb	a,r2
      00637E 40 11            [24] 1660 	jc	00118$
                                   1661 ;	free result
                                   1662 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      006380 90 07 8C         [24] 1663 	mov	dptr,#_D0SetupLen
      006383 ED               [12] 1664 	mov	a,r5
      006384 F0               [24] 1665 	movx	@dptr,a
      006385 EE               [12] 1666 	mov	a,r6
      006386 A3               [24] 1667 	inc	dptr
      006387 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      006388 90 07 F0         [24] 1670 	mov	dptr,#_control_phase
      00638B 74 03            [12] 1671 	mov	a,#0x03
      00638D F0               [24] 1672 	movx	@dptr,a
      00638E 02 69 71         [24] 1673 	ljmp	00291$
      006391                       1674 00118$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006391 02 5F C2         [24] 1676 	ljmp	_control_stall
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006394                       1678 00123$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006394 EF               [12] 1680 	mov	a,r7
      006395 70 3C            [24] 1681 	jnz	00145$
      006397 30 18 39         [24] 1682 	jnb	_control_setup_zero_index_10000_287,00145$
      00639A 30 1A 36         [24] 1683 	jnb	_control_setup_zero_length_10000_287,00145$
      00639D 8D 01            [24] 1684 	mov	ar1,r5
      00639F 8E 02            [24] 1685 	mov	ar2,r6
      0063A1 C3               [12] 1686 	clr	c
      0063A2 74 01            [12] 1687 	mov	a,#0x01
      0063A4 99               [12] 1688 	subb	a,r1
      0063A5 E4               [12] 1689 	clr	a
      0063A6 9A               [12] 1690 	subb	a,r2
      0063A7 40 2A            [24] 1691 	jc	00145$
                                   1692 ;	free result
                                   1693 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      0063A9 C0 06            [24] 1694 	push	ar6
      0063AB C0 05            [24] 1695 	push	ar5
      0063AD 12 5F 65         [24] 1696 	lcall	_endpoints_reset
      0063B0 D0 05            [24] 1697 	pop	ar5
      0063B2 D0 06            [24] 1698 	pop	ar6
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      0063B4 90 07 91         [24] 1700 	mov	dptr,#_D0UsbConfig
      0063B7 ED               [12] 1701 	mov	a,r5
      0063B8 F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      0063B9 A2 1B            [12] 1704 	mov	c,_control_setup_sloc0_1_0
      0063BB B3               [12] 1705 	cpl	c
      0063BC 92 1C            [24] 1706 	mov	_control_setup_sloc2_1_0,c
      0063BE 90 07 92         [24] 1707 	mov	dptr,#_USB_EnumStatus
      0063C1 E4               [12] 1708 	clr	a
      0063C2 33               [12] 1709 	rlc	a
      0063C3 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      0063C4 90 07 BB         [24] 1712 	mov	dptr,#_keyboard_reset
      0063C7 74 01            [12] 1713 	mov	a,#0x01
      0063C9 F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      0063CA 90 07 F0         [24] 1716 	mov	dptr,#_control_phase
      0063CD 74 03            [12] 1717 	mov	a,#0x03
      0063CF F0               [24] 1718 	movx	@dptr,a
      0063D0 02 69 71         [24] 1719 	ljmp	00291$
      0063D3                       1720 00145$:
                                   1721 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      0063D3 BF 21 02         [24] 1722 	cjne	r7,#0x21,01231$
      0063D6 80 03            [24] 1723 	sjmp	01232$
      0063D8                       1724 01231$:
      0063D8 02 5F C2         [24] 1725 	ljmp	_control_stall
      0063DB                       1726 01232$:
      0063DB 90 07 91         [24] 1727 	mov	dptr,#_D0UsbConfig
      0063DE E0               [24] 1728 	movx	a,@dptr
      0063DF 70 03            [24] 1729 	jnz	01233$
      0063E1 02 5F C2         [24] 1730 	ljmp	_control_stall
      0063E4                       1731 01233$:
                                   1732 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0063E4 BB 01 2D         [24] 1733 	cjne	r3,#0x01,00135$
      0063E7 BC 00 2A         [24] 1734 	cjne	r4,#0x00,00135$
      0063EA 8D 01            [24] 1735 	mov	ar1,r5
      0063EC 8E 02            [24] 1736 	mov	ar2,r6
      0063EE B9 00 23         [24] 1737 	cjne	r1,#0x00,00135$
      0063F1 BA 02 20         [24] 1738 	cjne	r2,#0x02,00135$
      0063F4 90 07 8C         [24] 1739 	mov	dptr,#_D0SetupLen
      0063F7 E0               [24] 1740 	movx	a,@dptr
      0063F8 F9               [12] 1741 	mov	r1,a
      0063F9 A3               [24] 1742 	inc	dptr
      0063FA E0               [24] 1743 	movx	a,@dptr
      0063FB FA               [12] 1744 	mov	r2,a
      0063FC B9 20 15         [24] 1745 	cjne	r1,#0x20,00135$
      0063FF BA 00 12         [24] 1746 	cjne	r2,#0x00,00135$
      006402 90 07 99         [24] 1747 	mov	dptr,#_raw_state
      006405 E0               [24] 1748 	movx	a,@dptr
      006406 70 0C            [24] 1749 	jnz	00135$
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      006408 90 07 99         [24] 1751 	mov	dptr,#_raw_state
      00640B 74 01            [12] 1752 	mov	a,#0x01
      00640D F0               [24] 1753 	movx	@dptr,a
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      00640E 90 07 F1         [24] 1755 	mov	dptr,#_output_kind
      006411 F0               [24] 1756 	movx	@dptr,a
      006412 80 52            [24] 1757 	sjmp	00136$
      006414                       1758 00135$:
                                   1759 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006414 EB               [12] 1760 	mov	a,r3
      006415 4C               [12] 1761 	orl	a,r4
      006416 70 20            [24] 1762 	jnz	00130$
      006418 8D 01            [24] 1763 	mov	ar1,r5
      00641A 8E 02            [24] 1764 	mov	ar2,r6
      00641C B9 00 19         [24] 1765 	cjne	r1,#0x00,00130$
      00641F BA 02 16         [24] 1766 	cjne	r2,#0x02,00130$
      006422 90 07 8C         [24] 1767 	mov	dptr,#_D0SetupLen
      006425 E0               [24] 1768 	movx	a,@dptr
      006426 F9               [12] 1769 	mov	r1,a
      006427 A3               [24] 1770 	inc	dptr
      006428 E0               [24] 1771 	movx	a,@dptr
      006429 FA               [12] 1772 	mov	r2,a
      00642A B9 01 0B         [24] 1773 	cjne	r1,#0x01,00130$
      00642D BA 00 08         [24] 1774 	cjne	r2,#0x00,00130$
                                   1775 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      006430 90 07 F1         [24] 1776 	mov	dptr,#_output_kind
      006433 74 02            [12] 1777 	mov	a,#0x02
      006435 F0               [24] 1778 	movx	@dptr,a
      006436 80 2E            [24] 1779 	sjmp	00136$
      006438                       1780 00130$:
                                   1781 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006438 BB 02 28         [24] 1782 	cjne	r3,#0x02,00125$
      00643B BC 00 25         [24] 1783 	cjne	r4,#0x00,00125$
      00643E 8D 01            [24] 1784 	mov	ar1,r5
      006440 8E 02            [24] 1785 	mov	ar2,r6
      006442 B9 06 1E         [24] 1786 	cjne	r1,#0x06,00125$
      006445 BA 02 1B         [24] 1787 	cjne	r2,#0x02,00125$
      006448 90 07 8C         [24] 1788 	mov	dptr,#_D0SetupLen
      00644B E0               [24] 1789 	movx	a,@dptr
      00644C F9               [12] 1790 	mov	r1,a
      00644D A3               [24] 1791 	inc	dptr
      00644E E0               [24] 1792 	movx	a,@dptr
      00644F FA               [12] 1793 	mov	r2,a
      006450 B9 02 10         [24] 1794 	cjne	r1,#0x02,00125$
      006453 BA 00 0D         [24] 1795 	cjne	r2,#0x00,00125$
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      006456 90 07 F1         [24] 1797 	mov	dptr,#_output_kind
      006459 74 03            [12] 1798 	mov	a,#0x03
      00645B F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      00645C 90 07 F2         [24] 1801 	mov	dptr,#_output_report_id
      00645F 23               [12] 1802 	rl	a
      006460 F0               [24] 1803 	movx	@dptr,a
      006461 80 03            [24] 1804 	sjmp	00136$
      006463                       1805 00125$:
                                   1806 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      006463 02 5F C2         [24] 1807 	ljmp	_control_stall
      006466                       1808 00136$:
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      006466 90 07 F0         [24] 1810 	mov	dptr,#_control_phase
      006469 74 04            [12] 1811 	mov	a,#0x04
      00646B F0               [24] 1812 	movx	@dptr,a
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      00646C 22               [24] 1814 	ret
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      00646D 02 5F C2         [24] 1816 	ljmp	_control_stall
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006470                       1818 00150$:
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006470 BF 80 2A         [24] 1820 	cjne	r7,#0x80,00152$
      006473 30 18 27         [24] 1821 	jnb	_control_setup_zero_index_10000_287,00152$
      006476 30 19 24         [24] 1822 	jnb	_control_setup_zero_value_10000_287,00152$
      006479 90 07 8C         [24] 1823 	mov	dptr,#_D0SetupLen
      00647C E0               [24] 1824 	movx	a,@dptr
      00647D F9               [12] 1825 	mov	r1,a
      00647E A3               [24] 1826 	inc	dptr
      00647F E0               [24] 1827 	movx	a,@dptr
      006480 FA               [12] 1828 	mov	r2,a
      006481 B9 01 19         [24] 1829 	cjne	r1,#0x01,00152$
      006484 BA 00 16         [24] 1830 	cjne	r2,#0x00,00152$
                                   1831 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      006487 90 07 91         [24] 1832 	mov	dptr,#_D0UsbConfig
      00648A E0               [24] 1833 	movx	a,@dptr
      00648B 90 10 00         [24] 1834 	mov	dptr,#0x1000
      00648E F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      00648F 90 22 08         [24] 1837 	mov	dptr,#0x2208
      006492 74 01            [12] 1838 	mov	a,#0x01
      006494 F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      006495 90 07 F0         [24] 1841 	mov	dptr,#_control_phase
      006498 04               [12] 1842 	inc	a
      006499 F0               [24] 1843 	movx	@dptr,a
      00649A 02 69 71         [24] 1844 	ljmp	00291$
      00649D                       1845 00152$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      00649D 02 5F C2         [24] 1847 	ljmp	_control_stall
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0064A0                       1849 00157$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0064A0 BF 81 2C         [24] 1851 	cjne	r7,#0x81,00167$
      0064A3 30 17 29         [24] 1852 	jnb	_control_setup_valid_interface_10000_287,00167$
      0064A6 30 19 26         [24] 1853 	jnb	_control_setup_zero_value_10000_287,00167$
      0064A9 90 07 8C         [24] 1854 	mov	dptr,#_D0SetupLen
      0064AC E0               [24] 1855 	movx	a,@dptr
      0064AD F9               [12] 1856 	mov	r1,a
      0064AE A3               [24] 1857 	inc	dptr
      0064AF E0               [24] 1858 	movx	a,@dptr
      0064B0 FA               [12] 1859 	mov	r2,a
      0064B1 B9 01 1B         [24] 1860 	cjne	r1,#0x01,00167$
      0064B4 BA 00 18         [24] 1861 	cjne	r2,#0x00,00167$
      0064B7 90 07 91         [24] 1862 	mov	dptr,#_D0UsbConfig
      0064BA E0               [24] 1863 	movx	a,@dptr
      0064BB 60 12            [24] 1864 	jz	00167$
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      0064BD 90 10 00         [24] 1866 	mov	dptr,#0x1000
      0064C0 E4               [12] 1867 	clr	a
      0064C1 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      0064C2 90 22 08         [24] 1870 	mov	dptr,#0x2208
      0064C5 04               [12] 1871 	inc	a
      0064C6 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      0064C7 90 07 F0         [24] 1874 	mov	dptr,#_control_phase
      0064CA 04               [12] 1875 	inc	a
      0064CB F0               [24] 1876 	movx	@dptr,a
      0064CC 02 69 71         [24] 1877 	ljmp	00291$
      0064CF                       1878 00167$:
                                   1879 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0064CF 30 17 1E         [24] 1880 	jnb	_control_setup_valid_interface_10000_287,00161$
      0064D2 90 07 91         [24] 1881 	mov	dptr,#_D0UsbConfig
      0064D5 E0               [24] 1882 	movx	a,@dptr
      0064D6 60 18            [24] 1883 	jz	00161$
      0064D8 BF 21 15         [24] 1884 	cjne	r7,#0x21,00161$
      0064DB 30 1A 12         [24] 1885 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1886 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0064DE EB               [12] 1887 	mov	a,r3
      0064DF 4C               [12] 1888 	orl	a,r4
      0064E0 70 05            [24] 1889 	jnz	00159$
      0064E2 90 06 53         [24] 1890 	mov	dptr,#_keyboard_idle
      0064E5 EE               [12] 1891 	mov	a,r6
      0064E6 F0               [24] 1892 	movx	@dptr,a
      0064E7                       1893 00159$:
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      0064E7 90 07 F0         [24] 1895 	mov	dptr,#_control_phase
      0064EA 74 03            [12] 1896 	mov	a,#0x03
      0064EC F0               [24] 1897 	movx	@dptr,a
      0064ED 02 69 71         [24] 1898 	ljmp	00291$
      0064F0                       1899 00161$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      0064F0 02 5F C2         [24] 1901 	ljmp	_control_stall
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0064F3                       1903 00173$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0064F3 BF 01 18         [24] 1905 	cjne	r7,#0x01,00182$
      0064F6 30 17 15         [24] 1906 	jnb	_control_setup_valid_interface_10000_287,00182$
      0064F9 30 19 12         [24] 1907 	jnb	_control_setup_zero_value_10000_287,00182$
      0064FC 30 1A 0F         [24] 1908 	jnb	_control_setup_zero_length_10000_287,00182$
      0064FF 90 07 91         [24] 1909 	mov	dptr,#_D0UsbConfig
      006502 E0               [24] 1910 	movx	a,@dptr
      006503 60 09            [24] 1911 	jz	00182$
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      006505 90 07 F0         [24] 1913 	mov	dptr,#_control_phase
      006508 74 03            [12] 1914 	mov	a,#0x03
      00650A F0               [24] 1915 	movx	@dptr,a
      00650B 02 69 71         [24] 1916 	ljmp	00291$
      00650E                       1917 00182$:
                                   1918 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00650E EB               [12] 1919 	mov	a,r3
      00650F 4C               [12] 1920 	orl	a,r4
      006510 70 2C            [24] 1921 	jnz	00175$
      006512 90 07 91         [24] 1922 	mov	dptr,#_D0UsbConfig
      006515 E0               [24] 1923 	movx	a,@dptr
      006516 60 26            [24] 1924 	jz	00175$
      006518 BF 21 23         [24] 1925 	cjne	r7,#0x21,00175$
      00651B 30 1A 20         [24] 1926 	jnb	_control_setup_zero_length_10000_287,00175$
      00651E 8D 01            [24] 1927 	mov	ar1,r5
      006520 8E 02            [24] 1928 	mov	ar2,r6
      006522 C3               [12] 1929 	clr	c
      006523 74 01            [12] 1930 	mov	a,#0x01
      006525 99               [12] 1931 	subb	a,r1
      006526 E4               [12] 1932 	clr	a
      006527 9A               [12] 1933 	subb	a,r2
      006528 40 14            [24] 1934 	jc	00175$
                                   1935 ;	free result
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      00652A 90 0D E6         [24] 1937 	mov	dptr,#_keyboard_protocol
      00652D ED               [12] 1938 	mov	a,r5
      00652E F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      00652F 90 07 BB         [24] 1941 	mov	dptr,#_keyboard_reset
      006532 74 01            [12] 1942 	mov	a,#0x01
      006534 F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      006535 90 07 F0         [24] 1945 	mov	dptr,#_control_phase
      006538 74 03            [12] 1946 	mov	a,#0x03
      00653A F0               [24] 1947 	movx	@dptr,a
      00653B 02 69 71         [24] 1948 	ljmp	00291$
      00653E                       1949 00175$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      00653E 02 5F C2         [24] 1951 	ljmp	_control_stall
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      006541                       1953 00188$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      006541 20 19 03         [24] 1955 	jb	_control_setup_zero_value_10000_287,01283$
      006544 02 5F C2         [24] 1956 	ljmp	_control_stall
      006547                       1957 01283$:
      006547 90 07 8C         [24] 1958 	mov	dptr,#_D0SetupLen
      00654A E0               [24] 1959 	movx	a,@dptr
      00654B F9               [12] 1960 	mov	r1,a
      00654C A3               [24] 1961 	inc	dptr
      00654D E0               [24] 1962 	movx	a,@dptr
      00654E FA               [12] 1963 	mov	r2,a
      00654F B9 02 05         [24] 1964 	cjne	r1,#0x02,01284$
      006552 BA 00 02         [24] 1965 	cjne	r2,#0x00,01284$
      006555 80 03            [24] 1966 	sjmp	01285$
      006557                       1967 01284$:
      006557 02 5F C2         [24] 1968 	ljmp	_control_stall
      00655A                       1969 01285$:
                                   1970 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00655A E4               [12] 1971 	clr	a
      00655B BF 80 01         [24] 1972 	cjne	r7,#0x80,01286$
      00655E 04               [12] 1973 	inc	a
      00655F                       1974 01286$:
      00655F FA               [12] 1975 	mov	r2,a
      006560 60 03            [24] 1976 	jz	00196$
      006562 20 18 35         [24] 1977 	jb	_control_setup_zero_index_10000_287,00189$
      006565                       1978 00196$:
      006565 BF 81 09         [24] 1979 	cjne	r7,#0x81,00202$
      006568 30 17 06         [24] 1980 	jnb	_control_setup_valid_interface_10000_287,00202$
      00656B 90 07 91         [24] 1981 	mov	dptr,#_D0UsbConfig
      00656E E0               [24] 1982 	movx	a,@dptr
      00656F 70 29            [24] 1983 	jnz	00189$
      006571                       1984 00202$:
                                   1985 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006571 BF 82 70         [24] 1986 	cjne	r7,#0x82,00190$
      006574 90 07 91         [24] 1987 	mov	dptr,#_D0UsbConfig
      006577 E0               [24] 1988 	movx	a,@dptr
      006578 60 6A            [24] 1989 	jz	00190$
      00657A EB               [12] 1990 	mov	a,r3
      00657B 4C               [12] 1991 	orl	a,r4
      00657C 60 1C            [24] 1992 	jz	00189$
      00657E 8B 00            [24] 1993 	mov	ar0,r3
      006580 8C 01            [24] 1994 	mov	ar1,r4
      006582 B8 80 05         [24] 1995 	cjne	r0,#0x80,01298$
      006585 B9 00 02         [24] 1996 	cjne	r1,#0x00,01298$
      006588 80 10            [24] 1997 	sjmp	00189$
      00658A                       1998 01298$:
      00658A C3               [12] 1999 	clr	c
      00658B E8               [12] 2000 	mov	a,r0
      00658C 94 81            [12] 2001 	subb	a,#0x81
      00658E E9               [12] 2002 	mov	a,r1
      00658F 94 00            [12] 2003 	subb	a,#0x00
      006591 40 51            [24] 2004 	jc	00190$
      006593 74 83            [12] 2005 	mov	a,#0x83
      006595 98               [12] 2006 	subb	a,r0
      006596 E4               [12] 2007 	clr	a
      006597 99               [12] 2008 	subb	a,r1
      006598 40 4A            [24] 2009 	jc	00190$
                                   2010 ;	free result
      00659A                       2011 00189$:
                                   2012 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      00659A 8B 01            [24] 2013 	mov	ar1,r3
      00659C 53 01 07         [24] 2014 	anl	ar1,#0x07
                                   2015 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      00659F EA               [12] 2016 	mov	a,r2
      0065A0 60 0B            [24] 2017 	jz	00308$
      0065A2 90 07 93         [24] 2018 	mov	dptr,#_USB_SleepStatus
      0065A5 E0               [24] 2019 	movx	a,@dptr
      0065A6 54 01            [12] 2020 	anl	a,#0x01
      0065A8 25 E0            [12] 2021 	add	a,acc
      0065AA FA               [12] 2022 	mov	r2,a
      0065AB 80 22            [24] 2023 	sjmp	00309$
      0065AD                       2024 00308$:
                                   2025 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0065AD BF 82 1B         [24] 2026 	cjne	r7,#0x82,00310$
      0065B0 E9               [12] 2027 	mov	a,r1
      0065B1 60 18            [24] 2028 	jz	00310$
      0065B3 89 00            [24] 2029 	mov	ar0,r1
      0065B5 79 00            [12] 2030 	mov	r1,#0x00
      0065B7 74 22            [12] 2031 	mov	a,#0x22
      0065B9 29               [12] 2032 	add	a, r1
      0065BA F9               [12] 2033 	mov	r1,a
      0065BB 88 82            [24] 2034 	mov	dpl,r0
      0065BD 89 83            [24] 2035 	mov	dph,r1
      0065BF E0               [24] 2036 	movx	a,@dptr
      0065C0 F9               [12] 2037 	mov	r1,a
      0065C1 53 01 03         [24] 2038 	anl	ar1,#0x03
      0065C4 B9 03 04         [24] 2039 	cjne	r1,#0x03,00310$
      0065C7 79 01            [12] 2040 	mov	r1,#0x01
      0065C9 80 02            [24] 2041 	sjmp	00311$
      0065CB                       2042 00310$:
      0065CB 79 00            [12] 2043 	mov	r1,#0x00
      0065CD                       2044 00311$:
      0065CD 89 02            [24] 2045 	mov	ar2,r1
      0065CF                       2046 00309$:
      0065CF 90 10 00         [24] 2047 	mov	dptr,#0x1000
      0065D2 EA               [12] 2048 	mov	a,r2
      0065D3 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0065D4 A3               [24] 2051 	inc	dptr
      0065D5 E4               [12] 2052 	clr	a
      0065D6 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0065D7 90 22 08         [24] 2055 	mov	dptr,#0x2208
      0065DA 74 02            [12] 2056 	mov	a,#0x02
      0065DC F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      0065DD 90 07 F0         [24] 2059 	mov	dptr,#_control_phase
      0065E0 F0               [24] 2060 	movx	@dptr,a
      0065E1 02 69 71         [24] 2061 	ljmp	00291$
      0065E4                       2062 00190$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      0065E4 02 5F C2         [24] 2064 	ljmp	_control_stall
                                   2065 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0065E7                       2066 00205$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      0065E7 20 1A 03         [24] 2068 	jb	_control_setup_zero_length_10000_287,01307$
      0065EA 02 66 7A         [24] 2069 	ljmp	00279$
      0065ED                       2070 01307$:
      0065ED 90 07 91         [24] 2071 	mov	dptr,#_D0UsbConfig
      0065F0 E0               [24] 2072 	movx	a,@dptr
      0065F1 70 03            [24] 2073 	jnz	01308$
      0065F3 02 66 7A         [24] 2074 	ljmp	00279$
      0065F6                       2075 01308$:
                                   2076 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      0065F6 EF               [12] 2077 	mov	a,r7
      0065F7 70 29            [24] 2078 	jnz	00218$
      0065F9 8D 01            [24] 2079 	mov	ar1,r5
      0065FB 8E 02            [24] 2080 	mov	ar2,r6
      0065FD B9 01 22         [24] 2081 	cjne	r1,#0x01,00218$
      006600 BA 00 1F         [24] 2082 	cjne	r2,#0x00,00218$
      006603 30 18 1C         [24] 2083 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006606 90 07 8B         [24] 2085 	mov	dptr,#_D0SetupReqCode
      006609 E0               [24] 2086 	movx	a,@dptr
      00660A FA               [12] 2087 	mov	r2,a
      00660B BA 03 0A         [24] 2088 	cjne	r2,#0x03,00207$
      00660E 90 07 93         [24] 2089 	mov	dptr,#_USB_SleepStatus
      006611 E0               [24] 2090 	movx	a,@dptr
      006612 43 E0 01         [24] 2091 	orl	acc,#0x01
      006615 F0               [24] 2092 	movx	@dptr,a
      006616 80 59            [24] 2093 	sjmp	00219$
      006618                       2094 00207$:
                                   2095 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      006618 90 07 93         [24] 2096 	mov	dptr,#_USB_SleepStatus
      00661B E0               [24] 2097 	movx	a,@dptr
      00661C 53 E0 FE         [24] 2098 	anl	acc,#0xfe
      00661F F0               [24] 2099 	movx	@dptr,a
      006620 80 4F            [24] 2100 	sjmp	00219$
      006622                       2101 00218$:
                                   2102 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006622 BF 02 49         [24] 2103 	cjne	r7,#0x02,00212$
      006625 30 19 46         [24] 2104 	jnb	_control_setup_zero_value_10000_287,00212$
      006628 8B 01            [24] 2105 	mov	ar1,r3
      00662A 8C 02            [24] 2106 	mov	ar2,r4
      00662C C3               [12] 2107 	clr	c
      00662D E9               [12] 2108 	mov	a,r1
      00662E 94 81            [12] 2109 	subb	a,#0x81
      006630 EA               [12] 2110 	mov	a,r2
      006631 94 00            [12] 2111 	subb	a,#0x00
      006633 40 39            [24] 2112 	jc	00212$
      006635 74 83            [12] 2113 	mov	a,#0x83
      006637 99               [12] 2114 	subb	a,r1
      006638 E4               [12] 2115 	clr	a
      006639 9A               [12] 2116 	subb	a,r2
      00663A 40 32            [24] 2117 	jc	00212$
                                   2118 ;	free result
                                   2119 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      00663C 8B 02            [24] 2120 	mov	ar2,r3
      00663E 53 02 07         [24] 2121 	anl	ar2,#0x07
                                   2122 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006641 8A 00            [24] 2123 	mov	ar0,r2
      006643 79 00            [12] 2124 	mov	r1,#0x00
      006645 74 22            [12] 2125 	mov	a,#0x22
      006647 29               [12] 2126 	add	a, r1
      006648 F9               [12] 2127 	mov	r1,a
      006649 88 17            [24] 2128 	mov	_control_setup_sloc3_1_0,r0
      00664B 89 18            [24] 2129 	mov	(_control_setup_sloc3_1_0 + 1),r1
      00664D 90 07 8B         [24] 2130 	mov	dptr,#_D0SetupReqCode
      006650 E0               [24] 2131 	movx	a,@dptr
      006651 F9               [12] 2132 	mov	r1,a
      006652 B9 03 04         [24] 2133 	cjne	r1,#0x03,00318$
      006655 79 03            [12] 2134 	mov	r1,#0x03
      006657 80 02            [24] 2135 	sjmp	00319$
      006659                       2136 00318$:
      006659 79 02            [12] 2137 	mov	r1,#0x02
      00665B                       2138 00319$:
      00665B 43 01 10         [24] 2139 	orl	ar1,#0x10
      00665E 85 17 82         [24] 2140 	mov	dpl,_control_setup_sloc3_1_0
      006661 85 18 83         [24] 2141 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006664 E9               [12] 2142 	mov	a,r1
      006665 F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006666 BA 03 08         [24] 2145 	cjne	r2,#0x03,00219$
      006669 12 5F 48         [24] 2146 	lcall	_raw_complete
      00666C 80 03            [24] 2147 	sjmp	00219$
      00666E                       2148 00212$:
                                   2149 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      00666E 02 5F C2         [24] 2150 	ljmp	_control_stall
      006671                       2151 00219$:
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006671 90 07 F0         [24] 2153 	mov	dptr,#_control_phase
      006674 74 03            [12] 2154 	mov	a,#0x03
      006676 F0               [24] 2155 	movx	@dptr,a
      006677 02 69 71         [24] 2156 	ljmp	00291$
      00667A                       2157 00279$:
                                   2158 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00667A E4               [12] 2159 	clr	a
      00667B BF A1 01         [24] 2160 	cjne	r7,#0xa1,01324$
      00667E 04               [12] 2161 	inc	a
      00667F                       2162 01324$:
      00667F FA               [12] 2163 	mov	r2,a
      006680 70 03            [24] 2164 	jnz	01326$
      006682 02 68 EC         [24] 2165 	ljmp	00273$
      006685                       2166 01326$:
      006685 90 07 8B         [24] 2167 	mov	dptr,#_D0SetupReqCode
      006688 E0               [24] 2168 	movx	a,@dptr
      006689 F9               [12] 2169 	mov	r1,a
      00668A B9 01 02         [24] 2170 	cjne	r1,#0x01,01327$
      00668D 80 03            [24] 2171 	sjmp	01328$
      00668F                       2172 01327$:
      00668F 02 68 EC         [24] 2173 	ljmp	00273$
      006692                       2174 01328$:
      006692 90 07 91         [24] 2175 	mov	dptr,#_D0UsbConfig
      006695 E0               [24] 2176 	movx	a,@dptr
      006696 70 03            [24] 2177 	jnz	01329$
      006698 02 68 EC         [24] 2178 	ljmp	00273$
      00669B                       2179 01329$:
      00669B 90 07 8C         [24] 2180 	mov	dptr,#_D0SetupLen
      00669E E0               [24] 2181 	movx	a,@dptr
      00669F F8               [12] 2182 	mov	r0,a
      0066A0 A3               [24] 2183 	inc	dptr
      0066A1 E0               [24] 2184 	movx	a,@dptr
      0066A2 48               [12] 2185 	orl	a,r0
      0066A3 70 03            [24] 2186 	jnz	01330$
      0066A5 02 68 EC         [24] 2187 	ljmp	00273$
      0066A8                       2188 01330$:
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0066A8 C0 03            [24] 2190 	push	ar3
      0066AA C0 04            [24] 2191 	push	ar4
      0066AC 8D 01            [24] 2192 	mov	ar1,r5
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0066AE 8E 00            [24] 2194 	mov	ar0,r6
      0066B0 B8 01 03         [24] 2195 	cjne	r0,#0x01,01331$
      0066B3 E8               [12] 2196 	mov	a,r0
      0066B4 80 01            [24] 2197 	sjmp	01332$
      0066B6                       2198 01331$:
      0066B6 E4               [12] 2199 	clr	a
      0066B7                       2200 01332$:
      0066B7 F5 17            [12] 2201 	mov	_control_setup_sloc3_1_0,a
      0066B9 D0 04            [24] 2202 	pop	ar4
      0066BB D0 03            [24] 2203 	pop	ar3
      0066BD E5 17            [12] 2204 	mov	a,_control_setup_sloc3_1_0
      0066BF 60 17            [24] 2205 	jz	00251$
      0066C1 EB               [12] 2206 	mov	a,r3
      0066C2 4C               [12] 2207 	orl	a,r4
      0066C3 70 13            [24] 2208 	jnz	00251$
      0066C5 E9               [12] 2209 	mov	a,r1
      0066C6 70 10            [24] 2210 	jnz	00251$
                                   2211 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0066C8 90 07 FA         [24] 2212 	mov	dptr,#_control_setup_length_10000_287
      0066CB 74 08            [12] 2213 	mov	a,#0x08
      0066CD F0               [24] 2214 	movx	@dptr,a
      0066CE E4               [12] 2215 	clr	a
      0066CF A3               [24] 2216 	inc	dptr
      0066D0 F0               [24] 2217 	movx	@dptr,a
                                   2218 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0066D1 90 07 FC         [24] 2219 	mov	dptr,#_control_setup_offset_10000_287
      0066D4 F0               [24] 2220 	movx	@dptr,a
      0066D5 02 68 5C         [24] 2221 	ljmp	00252$
      0066D8                       2222 00251$:
                                   2223 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0066D8 E5 17            [12] 2224 	mov	a,_control_setup_sloc3_1_0
      0066DA 60 27            [24] 2225 	jz	00245$
      0066DC BB 02 24         [24] 2226 	cjne	r3,#0x02,00245$
      0066DF BC 00 21         [24] 2227 	cjne	r4,#0x00,00245$
                                   2228 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0066E2 B9 07 00         [24] 2229 	cjne	r1,#0x07,01339$
      0066E5                       2230 01339$:
      0066E5 50 1C            [24] 2231 	jnc	00245$
      0066E7 E9               [12] 2232 	mov	a,r1
      0066E8 90 BD E8         [24] 2233 	mov	dptr,#_shared_lengths
      0066EB 93               [24] 2234 	movc	a,@a+dptr
      0066EC F8               [12] 2235 	mov	r0,a
      0066ED 60 14            [24] 2236 	jz	00245$
                                   2237 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0066EF 90 07 FA         [24] 2238 	mov	dptr,#_control_setup_length_10000_287
      0066F2 E8               [12] 2239 	mov	a,r0
      0066F3 F0               [24] 2240 	movx	@dptr,a
      0066F4 E4               [12] 2241 	clr	a
      0066F5 A3               [24] 2242 	inc	dptr
      0066F6 F0               [24] 2243 	movx	@dptr,a
                                   2244 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      0066F7 E9               [12] 2245 	mov	a,r1
      0066F8 90 BD E1         [24] 2246 	mov	dptr,#_shared_offsets
      0066FB 93               [24] 2247 	movc	a,@a+dptr
      0066FC 90 07 FC         [24] 2248 	mov	dptr,#_control_setup_offset_10000_287
      0066FF F0               [24] 2249 	movx	@dptr,a
      006700 02 68 5C         [24] 2250 	ljmp	00252$
      006703                       2251 00245$:
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006703 E5 17            [12] 2253 	mov	a,_control_setup_sloc3_1_0
      006705 60 7A            [24] 2254 	jz	00240$
      006707 BB 01 77         [24] 2255 	cjne	r3,#0x01,00240$
      00670A BC 00 74         [24] 2256 	cjne	r4,#0x00,00240$
      00670D E9               [12] 2257 	mov	a,r1
      00670E 70 71            [24] 2258 	jnz	00240$
                                   2259 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006710 90 07 8C         [24] 2260 	mov	dptr,#_D0SetupLen
      006713 E0               [24] 2261 	movx	a,@dptr
      006714 F8               [12] 2262 	mov	r0,a
      006715 A3               [24] 2263 	inc	dptr
      006716 E0               [24] 2264 	movx	a,@dptr
      006717 F9               [12] 2265 	mov	r1,a
      006718 C3               [12] 2266 	clr	c
      006719 E8               [12] 2267 	mov	a,r0
      00671A 94 20            [12] 2268 	subb	a,#0x20
      00671C E9               [12] 2269 	mov	a,r1
      00671D 94 00            [12] 2270 	subb	a,#0x00
      00671F 50 0A            [24] 2271 	jnc	00320$
      006721 90 07 8C         [24] 2272 	mov	dptr,#_D0SetupLen
      006724 E0               [24] 2273 	movx	a,@dptr
      006725 F8               [12] 2274 	mov	r0,a
      006726 A3               [24] 2275 	inc	dptr
      006727 E0               [24] 2276 	movx	a,@dptr
      006728 F9               [12] 2277 	mov	r1,a
      006729 80 04            [24] 2278 	sjmp	00321$
      00672B                       2279 00320$:
      00672B 78 20            [12] 2280 	mov	r0,#0x20
      00672D 79 00            [12] 2281 	mov	r1,#0x00
      00672F                       2282 00321$:
                                   2283 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00672F 75 17 00         [24] 2284 	mov	_control_setup_sloc3_1_0,#0x00
      006732                       2285 00293$:
      006732 C0 03            [24] 2286 	push	ar3
      006734 C0 04            [24] 2287 	push	ar4
      006736 AB 17            [24] 2288 	mov	r3,_control_setup_sloc3_1_0
      006738 7C 00            [12] 2289 	mov	r4,#0x00
      00673A C3               [12] 2290 	clr	c
      00673B EB               [12] 2291 	mov	a,r3
      00673C 98               [12] 2292 	subb	a,r0
      00673D EC               [12] 2293 	mov	a,r4
      00673E 99               [12] 2294 	subb	a,r1
      00673F D0 04            [24] 2295 	pop	ar4
      006741 D0 03            [24] 2296 	pop	ar3
      006743 50 32            [24] 2297 	jnc	00222$
      006745 C0 00            [24] 2298 	push	ar0
      006747 C0 01            [24] 2299 	push	ar1
      006749 85 17 19         [24] 2300 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      00674C 74 10            [12] 2301 	mov	a,#0x10
      00674E 24 00            [12] 2302 	add	a, #0x00
      006750 F5 1A            [12] 2303 	mov	(_control_setup_sloc4_1_0 + 1),a
      006752 A8 17            [24] 2304 	mov	r0,_control_setup_sloc3_1_0
      006754 79 00            [12] 2305 	mov	r1,#0x00
      006756 74 C0            [12] 2306 	mov	a,#0xc0
      006758 28               [12] 2307 	add	a, r0
      006759 F8               [12] 2308 	mov	r0,a
      00675A E4               [12] 2309 	clr	a
      00675B 39               [12] 2310 	addc	a, r1
      00675C F9               [12] 2311 	mov	r1,a
      00675D 88 82            [24] 2312 	mov	dpl,r0
      00675F 74 10            [12] 2313 	mov	a,#0x10
      006761 29               [12] 2314 	add	a, r1
      006762 F5 83            [12] 2315 	mov	dph,a
      006764 E0               [24] 2316 	movx	a,@dptr
      006765 85 19 82         [24] 2317 	mov	dpl,_control_setup_sloc4_1_0
      006768 85 1A 83         [24] 2318 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00676B F0               [24] 2319 	movx	@dptr,a
      00676C E5 17            [12] 2320 	mov	a,_control_setup_sloc3_1_0
      00676E 04               [12] 2321 	inc	a
      00676F F5 17            [12] 2322 	mov	_control_setup_sloc3_1_0,a
      006771 D0 01            [24] 2323 	pop	ar1
      006773 D0 00            [24] 2324 	pop	ar0
      006775 80 BB            [24] 2325 	sjmp	00293$
      006777                       2326 00222$:
                                   2327 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      006777 90 07 FA         [24] 2328 	mov	dptr,#_control_setup_length_10000_287
      00677A E4               [12] 2329 	clr	a
      00677B F0               [24] 2330 	movx	@dptr,a
      00677C A3               [24] 2331 	inc	dptr
      00677D F0               [24] 2332 	movx	@dptr,a
      00677E 02 68 5C         [24] 2333 	ljmp	00252$
      006781                       2334 00240$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006781 8D 00            [24] 2336 	mov	ar0,r5
      006783 8E 01            [24] 2337 	mov	ar1,r6
      006785 B8 00 21         [24] 2338 	cjne	r0,#0x00,00236$
      006788 B9 02 1E         [24] 2339 	cjne	r1,#0x02,00236$
      00678B EB               [12] 2340 	mov	a,r3
      00678C 4C               [12] 2341 	orl	a,r4
      00678D 70 1A            [24] 2342 	jnz	00236$
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      00678F 90 07 96         [24] 2344 	mov	dptr,#_KB_USB_SetReport
      006792 E0               [24] 2345 	movx	a,@dptr
      006793 90 10 00         [24] 2346 	mov	dptr,#0x1000
      006796 F0               [24] 2347 	movx	@dptr,a
                                   2348 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      006797 90 07 FA         [24] 2349 	mov	dptr,#_control_setup_length_10000_287
      00679A E4               [12] 2350 	clr	a
      00679B F0               [24] 2351 	movx	@dptr,a
      00679C A3               [24] 2352 	inc	dptr
      00679D F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      00679E 90 07 8C         [24] 2355 	mov	dptr,#_D0SetupLen
      0067A1 04               [12] 2356 	inc	a
      0067A2 F0               [24] 2357 	movx	@dptr,a
      0067A3 E4               [12] 2358 	clr	a
      0067A4 A3               [24] 2359 	inc	dptr
      0067A5 F0               [24] 2360 	movx	@dptr,a
      0067A6 02 68 5C         [24] 2361 	ljmp	00252$
      0067A9                       2362 00236$:
                                   2363 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0067A9 B8 06 41         [24] 2364 	cjne	r0,#0x06,00232$
      0067AC B9 02 3E         [24] 2365 	cjne	r1,#0x02,00232$
      0067AF BB 02 3B         [24] 2366 	cjne	r3,#0x02,00232$
      0067B2 BC 00 38         [24] 2367 	cjne	r4,#0x00,00232$
                                   2368 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0067B5 C0 03            [24] 2369 	push	ar3
      0067B7 C0 04            [24] 2370 	push	ar4
      0067B9 90 10 00         [24] 2371 	mov	dptr,#0x1000
      0067BC 74 06            [12] 2372 	mov	a,#0x06
      0067BE F0               [24] 2373 	movx	@dptr,a
                                   2374 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0067BF 90 07 96         [24] 2375 	mov	dptr,#_KB_USB_SetReport
      0067C2 E0               [24] 2376 	movx	a,@dptr
      0067C3 90 10 01         [24] 2377 	mov	dptr,#0x1001
      0067C6 F0               [24] 2378 	movx	@dptr,a
                                   2379 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      0067C7 90 07 FA         [24] 2380 	mov	dptr,#_control_setup_length_10000_287
      0067CA E4               [12] 2381 	clr	a
      0067CB F0               [24] 2382 	movx	@dptr,a
      0067CC A3               [24] 2383 	inc	dptr
      0067CD F0               [24] 2384 	movx	@dptr,a
                                   2385 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      0067CE 90 07 8C         [24] 2386 	mov	dptr,#_D0SetupLen
      0067D1 E0               [24] 2387 	movx	a,@dptr
      0067D2 FB               [12] 2388 	mov	r3,a
      0067D3 A3               [24] 2389 	inc	dptr
      0067D4 E0               [24] 2390 	movx	a,@dptr
      0067D5 FC               [12] 2391 	mov	r4,a
      0067D6 C3               [12] 2392 	clr	c
      0067D7 74 02            [12] 2393 	mov	a,#0x02
      0067D9 9B               [12] 2394 	subb	a,r3
      0067DA E4               [12] 2395 	clr	a
      0067DB 9C               [12] 2396 	subb	a,r4
      0067DC D0 04            [24] 2397 	pop	ar4
      0067DE D0 03            [24] 2398 	pop	ar3
      0067E0 50 7A            [24] 2399 	jnc	00252$
                                   2400 ;	free result
      0067E2 90 07 8C         [24] 2401 	mov	dptr,#_D0SetupLen
      0067E5 74 02            [12] 2402 	mov	a,#0x02
      0067E7 F0               [24] 2403 	movx	@dptr,a
      0067E8 E4               [12] 2404 	clr	a
      0067E9 A3               [24] 2405 	inc	dptr
      0067EA F0               [24] 2406 	movx	@dptr,a
      0067EB 80 6F            [24] 2407 	sjmp	00252$
      0067ED                       2408 00232$:
                                   2409 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0067ED B8 00 69         [24] 2410 	cjne	r0,#0x00,00228$
      0067F0 B9 03 66         [24] 2411 	cjne	r1,#0x03,00228$
      0067F3 BB 01 63         [24] 2412 	cjne	r3,#0x01,00228$
      0067F6 BC 00 60         [24] 2413 	cjne	r4,#0x00,00228$
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      0067F9 90 10 00         [24] 2415 	mov	dptr,#0x1000
      0067FC 74 41            [12] 2416 	mov	a,#0x41
      0067FE F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      0067FF A3               [24] 2419 	inc	dptr
      006800 74 4B            [12] 2420 	mov	a,#0x4b
      006802 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      006803 A3               [24] 2423 	inc	dptr
      006804 74 42            [12] 2424 	mov	a,#0x42
      006806 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006807 A3               [24] 2427 	inc	dptr
      006808 74 54            [12] 2428 	mov	a,#0x54
      00680A F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      00680B A3               [24] 2431 	inc	dptr
      00680C 74 01            [12] 2432 	mov	a,#0x01
      00680E F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      00680F 90 07 97         [24] 2435 	mov	dptr,#_ak820_boot_stage
      006812 E0               [24] 2436 	movx	a,@dptr
      006813 90 10 05         [24] 2437 	mov	dptr,#0x1005
      006816 F0               [24] 2438 	movx	@dptr,a
                                   2439 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006817 90 07 98         [24] 2440 	mov	dptr,#_ak820_main_heartbeat
      00681A E0               [24] 2441 	movx	a,@dptr
      00681B 90 10 06         [24] 2442 	mov	dptr,#0x1006
      00681E F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00681F 90 07 92         [24] 2445 	mov	dptr,#_USB_EnumStatus
      006822 E0               [24] 2446 	movx	a,@dptr
      006823 60 02            [24] 2447 	jz	00322$
      006825 74 01            [12] 2448 	mov	a,#0x01
      006827                       2449 00322$:
      006827 F9               [12] 2450 	mov	r1,a
      006828 90 07 93         [24] 2451 	mov	dptr,#_USB_SleepStatus
      00682B E0               [24] 2452 	movx	a,@dptr
      00682C 54 02            [12] 2453 	anl	a,#0x02
      00682E F8               [12] 2454 	mov	r0,a
      00682F E9               [12] 2455 	mov	a,r1
      006830 42 00            [12] 2456 	orl	ar0,a
      006832 90 10 07         [24] 2457 	mov	dptr,#0x1007
      006835 E8               [12] 2458 	mov	a,r0
      006836 F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      006837 90 07 FA         [24] 2461 	mov	dptr,#_control_setup_length_10000_287
      00683A E4               [12] 2462 	clr	a
      00683B F0               [24] 2463 	movx	@dptr,a
      00683C A3               [24] 2464 	inc	dptr
      00683D F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      00683E 90 07 8C         [24] 2467 	mov	dptr,#_D0SetupLen
      006841 E0               [24] 2468 	movx	a,@dptr
      006842 F8               [12] 2469 	mov	r0,a
      006843 A3               [24] 2470 	inc	dptr
      006844 E0               [24] 2471 	movx	a,@dptr
      006845 F9               [12] 2472 	mov	r1,a
      006846 C3               [12] 2473 	clr	c
      006847 74 08            [12] 2474 	mov	a,#0x08
      006849 98               [12] 2475 	subb	a,r0
      00684A E4               [12] 2476 	clr	a
      00684B 99               [12] 2477 	subb	a,r1
      00684C 50 0E            [24] 2478 	jnc	00252$
                                   2479 ;	free result
      00684E 90 07 8C         [24] 2480 	mov	dptr,#_D0SetupLen
      006851 74 08            [12] 2481 	mov	a,#0x08
      006853 F0               [24] 2482 	movx	@dptr,a
      006854 E4               [12] 2483 	clr	a
      006855 A3               [24] 2484 	inc	dptr
      006856 F0               [24] 2485 	movx	@dptr,a
      006857 80 03            [24] 2486 	sjmp	00252$
      006859                       2487 00228$:
                                   2488 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006859 02 5F C2         [24] 2489 	ljmp	_control_stall
      00685C                       2490 00252$:
                                   2491 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      00685C 90 07 FA         [24] 2492 	mov	dptr,#_control_setup_length_10000_287
      00685F E0               [24] 2493 	movx	a,@dptr
      006860 F5 19            [12] 2494 	mov	_control_setup_sloc4_1_0,a
      006862 A3               [24] 2495 	inc	dptr
      006863 E0               [24] 2496 	movx	a,@dptr
      006864 F5 1A            [12] 2497 	mov	(_control_setup_sloc4_1_0 + 1),a
      006866 E5 19            [12] 2498 	mov	a,_control_setup_sloc4_1_0
      006868 45 1A            [12] 2499 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00686A 60 50            [24] 2500 	jz	00262$
                                   2501 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      00686C 90 07 8C         [24] 2502 	mov	dptr,#_D0SetupLen
      00686F E0               [24] 2503 	movx	a,@dptr
      006870 F8               [12] 2504 	mov	r0,a
      006871 A3               [24] 2505 	inc	dptr
      006872 E0               [24] 2506 	movx	a,@dptr
      006873 F9               [12] 2507 	mov	r1,a
      006874 C3               [12] 2508 	clr	c
      006875 E5 19            [12] 2509 	mov	a,_control_setup_sloc4_1_0
      006877 98               [12] 2510 	subb	a,r0
      006878 E5 1A            [12] 2511 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00687A 99               [12] 2512 	subb	a,r1
      00687B 50 0A            [24] 2513 	jnc	00559$
                                   2514 ;	free result
      00687D 90 07 8C         [24] 2515 	mov	dptr,#_D0SetupLen
      006880 E5 19            [12] 2516 	mov	a,_control_setup_sloc4_1_0
      006882 F0               [24] 2517 	movx	@dptr,a
      006883 E5 1A            [12] 2518 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006885 A3               [24] 2519 	inc	dptr
      006886 F0               [24] 2520 	movx	@dptr,a
                                   2521 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      006887                       2522 00559$:
      006887 75 19 00         [24] 2523 	mov	_control_setup_sloc4_1_0,#0x00
      00688A                       2524 00296$:
      00688A 90 07 8C         [24] 2525 	mov	dptr,#_D0SetupLen
      00688D E0               [24] 2526 	movx	a,@dptr
      00688E F8               [12] 2527 	mov	r0,a
      00688F C3               [12] 2528 	clr	c
      006890 E5 19            [12] 2529 	mov	a,_control_setup_sloc4_1_0
      006892 98               [12] 2530 	subb	a,r0
      006893 50 46            [24] 2531 	jnc	00263$
      006895 85 19 17         [24] 2532 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006898 74 10            [12] 2533 	mov	a,#0x10
      00689A 24 00            [12] 2534 	add	a, #0x00
      00689C F5 18            [12] 2535 	mov	(_control_setup_sloc3_1_0 + 1),a
      00689E 90 07 FC         [24] 2536 	mov	dptr,#_control_setup_offset_10000_287
      0068A1 E0               [24] 2537 	movx	a,@dptr
      0068A2 25 19            [12] 2538 	add	a, _control_setup_sloc4_1_0
      0068A4 24 BC            [12] 2539 	add	a, #_input_snapshot
      0068A6 F5 82            [12] 2540 	mov	dpl,a
      0068A8 E4               [12] 2541 	clr	a
      0068A9 34 07            [12] 2542 	addc	a,#(_input_snapshot >> 8)
      0068AB F5 83            [12] 2543 	mov	dph,a
      0068AD E0               [24] 2544 	movx	a,@dptr
      0068AE 85 17 82         [24] 2545 	mov	dpl,_control_setup_sloc3_1_0
      0068B1 85 18 83         [24] 2546 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0068B4 F0               [24] 2547 	movx	@dptr,a
      0068B5 E5 19            [12] 2548 	mov	a,_control_setup_sloc4_1_0
      0068B7 04               [12] 2549 	inc	a
      0068B8 F5 19            [12] 2550 	mov	_control_setup_sloc4_1_0,a
      0068BA 80 CE            [24] 2551 	sjmp	00296$
      0068BC                       2552 00262$:
                                   2553 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0068BC BB 01 1C         [24] 2554 	cjne	r3,#0x01,00263$
      0068BF BC 00 19         [24] 2555 	cjne	r4,#0x00,00263$
      0068C2 90 07 8C         [24] 2556 	mov	dptr,#_D0SetupLen
      0068C5 E0               [24] 2557 	movx	a,@dptr
      0068C6 F8               [12] 2558 	mov	r0,a
      0068C7 A3               [24] 2559 	inc	dptr
      0068C8 E0               [24] 2560 	movx	a,@dptr
      0068C9 F9               [12] 2561 	mov	r1,a
      0068CA C3               [12] 2562 	clr	c
      0068CB 74 20            [12] 2563 	mov	a,#0x20
      0068CD 98               [12] 2564 	subb	a,r0
      0068CE E4               [12] 2565 	clr	a
      0068CF 99               [12] 2566 	subb	a,r1
      0068D0 50 09            [24] 2567 	jnc	00263$
                                   2568 ;	free result
      0068D2 90 07 8C         [24] 2569 	mov	dptr,#_D0SetupLen
      0068D5 74 20            [12] 2570 	mov	a,#0x20
      0068D7 F0               [24] 2571 	movx	@dptr,a
      0068D8 E4               [12] 2572 	clr	a
      0068D9 A3               [24] 2573 	inc	dptr
      0068DA F0               [24] 2574 	movx	@dptr,a
      0068DB                       2575 00263$:
                                   2576 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      0068DB 90 07 8C         [24] 2577 	mov	dptr,#_D0SetupLen
      0068DE E0               [24] 2578 	movx	a,@dptr
      0068DF 90 22 08         [24] 2579 	mov	dptr,#0x2208
      0068E2 F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      0068E3 90 07 F0         [24] 2582 	mov	dptr,#_control_phase
      0068E6 74 02            [12] 2583 	mov	a,#0x02
      0068E8 F0               [24] 2584 	movx	@dptr,a
      0068E9 02 69 71         [24] 2585 	ljmp	00291$
      0068EC                       2586 00273$:
                                   2587 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0068EC EB               [12] 2588 	mov	a,r3
      0068ED 4C               [12] 2589 	orl	a,r4
      0068EE 70 37            [24] 2590 	jnz	00265$
      0068F0 90 07 91         [24] 2591 	mov	dptr,#_D0UsbConfig
      0068F3 E0               [24] 2592 	movx	a,@dptr
      0068F4 60 31            [24] 2593 	jz	00265$
      0068F6 EA               [12] 2594 	mov	a,r2
      0068F7 60 2E            [24] 2595 	jz	00265$
      0068F9 90 07 8B         [24] 2596 	mov	dptr,#_D0SetupReqCode
      0068FC E0               [24] 2597 	movx	a,@dptr
      0068FD FA               [12] 2598 	mov	r2,a
      0068FE BA 03 26         [24] 2599 	cjne	r2,#0x03,00265$
      006901 30 19 23         [24] 2600 	jnb	_control_setup_zero_value_10000_287,00265$
      006904 90 07 8C         [24] 2601 	mov	dptr,#_D0SetupLen
      006907 E0               [24] 2602 	movx	a,@dptr
      006908 F9               [12] 2603 	mov	r1,a
      006909 A3               [24] 2604 	inc	dptr
      00690A E0               [24] 2605 	movx	a,@dptr
      00690B FA               [12] 2606 	mov	r2,a
      00690C B9 01 18         [24] 2607 	cjne	r1,#0x01,00265$
      00690F BA 00 15         [24] 2608 	cjne	r2,#0x00,00265$
                                   2609 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006912 90 0D E6         [24] 2610 	mov	dptr,#_keyboard_protocol
      006915 E0               [24] 2611 	movx	a,@dptr
      006916 90 10 00         [24] 2612 	mov	dptr,#0x1000
      006919 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      00691A 90 22 08         [24] 2615 	mov	dptr,#0x2208
      00691D 74 01            [12] 2616 	mov	a,#0x01
      00691F F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      006920 90 07 F0         [24] 2619 	mov	dptr,#_control_phase
      006923 04               [12] 2620 	inc	a
      006924 F0               [24] 2621 	movx	@dptr,a
      006925 80 4A            [24] 2622 	sjmp	00291$
      006927                       2623 00265$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2625 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006927 02 5F C2         [24] 2626 	ljmp	_control_stall
      00692A                       2627 00282$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      00692A 30 17 3E         [24] 2629 	jnb	_control_setup_valid_interface_10000_287,00284$
      00692D 90 07 91         [24] 2630 	mov	dptr,#_D0UsbConfig
      006930 E0               [24] 2631 	movx	a,@dptr
      006931 60 38            [24] 2632 	jz	00284$
      006933 BF A1 35         [24] 2633 	cjne	r7,#0xa1,00284$
      006936 8E 05            [24] 2634 	mov	ar5,r6
      006938 7E 00            [12] 2635 	mov	r6,#0x00
      00693A ED               [12] 2636 	mov	a,r5
      00693B 4E               [12] 2637 	orl	a,r6
      00693C 70 2D            [24] 2638 	jnz	00284$
      00693E 90 07 8C         [24] 2639 	mov	dptr,#_D0SetupLen
      006941 E0               [24] 2640 	movx	a,@dptr
      006942 FE               [12] 2641 	mov	r6,a
      006943 A3               [24] 2642 	inc	dptr
      006944 E0               [24] 2643 	movx	a,@dptr
      006945 FF               [12] 2644 	mov	r7,a
      006946 BE 01 22         [24] 2645 	cjne	r6,#0x01,00284$
      006949 BF 00 1F         [24] 2646 	cjne	r7,#0x00,00284$
                                   2647 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      00694C EB               [12] 2648 	mov	a,r3
      00694D 4C               [12] 2649 	orl	a,r4
      00694E 70 07            [24] 2650 	jnz	00324$
      006950 90 06 53         [24] 2651 	mov	dptr,#_keyboard_idle
      006953 E0               [24] 2652 	movx	a,@dptr
      006954 FF               [12] 2653 	mov	r7,a
      006955 80 02            [24] 2654 	sjmp	00325$
      006957                       2655 00324$:
      006957 7F 00            [12] 2656 	mov	r7,#0x00
      006959                       2657 00325$:
      006959 90 10 00         [24] 2658 	mov	dptr,#0x1000
      00695C EF               [12] 2659 	mov	a,r7
      00695D F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      00695E 90 22 08         [24] 2662 	mov	dptr,#0x2208
      006961 74 01            [12] 2663 	mov	a,#0x01
      006963 F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      006964 90 07 F0         [24] 2666 	mov	dptr,#_control_phase
      006967 04               [12] 2667 	inc	a
      006968 F0               [24] 2668 	movx	@dptr,a
      006969 80 06            [24] 2669 	sjmp	00291$
      00696B                       2670 00284$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2672 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      00696B 02 5F C2         [24] 2673 	ljmp	_control_stall
      00696E                       2674 00290$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      00696E 02 5F C2         [24] 2676 	ljmp	_control_stall
      006971                       2677 00291$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006971 90 22 00         [24] 2679 	mov	dptr,#0x2200
      006974 74 C0            [12] 2680 	mov	a,#0xc0
      006976 F0               [24] 2681 	movx	@dptr,a
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      006977 22               [24] 2683 	ret
                                   2684 ;------------------------------------------------------------
                                   2685 ;Allocation info for local variables in function 'control_out'
                                   2686 ;------------------------------------------------------------
                                   2687 ;i             Allocated with name '_control_out_i_10000_371'
                                   2688 ;------------------------------------------------------------
                                   2689 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2690 ;	-----------------------------------------
                                   2691 ;	 function control_out
                                   2692 ;	-----------------------------------------
      006978                       2693 _control_out:
                                   2694 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006978 90 22 0F         [24] 2695 	mov	dptr,#0x220f
      00697B E0               [24] 2696 	movx	a,@dptr
      00697C 20 E6 01         [24] 2697 	jb	acc.6,00102$
      00697F 22               [24] 2698 	ret
      006980                       2699 00102$:
                                   2700 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006980 90 07 F0         [24] 2701 	mov	dptr,#_control_phase
      006983 E0               [24] 2702 	movx	a,@dptr
      006984 FF               [12] 2703 	mov	r7,a
      006985 BF 02 12         [24] 2704 	cjne	r7,#0x02,00104$
      006988 90 22 0E         [24] 2705 	mov	dptr,#0x220e
      00698B E0               [24] 2706 	movx	a,@dptr
      00698C 70 0C            [24] 2707 	jnz	00104$
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      00698E 90 07 F0         [24] 2709 	mov	dptr,#_control_phase
      006991 E4               [12] 2710 	clr	a
      006992 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006993 90 22 00         [24] 2713 	mov	dptr,#0x2200
      006996 74 02            [12] 2714 	mov	a,#0x02
      006998 F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006999 22               [24] 2717 	ret
      00699A                       2718 00104$:
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      00699A BF 04 19         [24] 2720 	cjne	r7,#0x04,00106$
      00699D 90 22 0E         [24] 2721 	mov	dptr,#0x220e
      0069A0 E0               [24] 2722 	movx	a,@dptr
      0069A1 FF               [12] 2723 	mov	r7,a
      0069A2 90 07 8C         [24] 2724 	mov	dptr,#_D0SetupLen
      0069A5 E0               [24] 2725 	movx	a,@dptr
      0069A6 FD               [12] 2726 	mov	r5,a
      0069A7 A3               [24] 2727 	inc	dptr
      0069A8 E0               [24] 2728 	movx	a,@dptr
      0069A9 FE               [12] 2729 	mov	r6,a
      0069AA 7C 00            [12] 2730 	mov	r4,#0x00
      0069AC EF               [12] 2731 	mov	a,r7
      0069AD B5 05 06         [24] 2732 	cjne	a,ar5,00209$
      0069B0 EC               [12] 2733 	mov	a,r4
      0069B1 B5 06 02         [24] 2734 	cjne	a,ar6,00209$
      0069B4 80 03            [24] 2735 	sjmp	00107$
      0069B6                       2736 00209$:
      0069B6                       2737 00106$:
      0069B6 02 5F C2         [24] 2738 	ljmp	_control_stall
      0069B9                       2739 00107$:
                                   2740 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0069B9 90 07 F1         [24] 2741 	mov	dptr,#_output_kind
      0069BC E0               [24] 2742 	movx	a,@dptr
      0069BD FF               [12] 2743 	mov	r7,a
      0069BE BF 01 2E         [24] 2744 	cjne	r7,#0x01,00118$
      0069C1 90 07 99         [24] 2745 	mov	dptr,#_raw_state
      0069C4 E0               [24] 2746 	movx	a,@dptr
      0069C5 FE               [12] 2747 	mov	r6,a
      0069C6 BE 01 26         [24] 2748 	cjne	r6,#0x01,00118$
                                   2749 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0069C9 7E 00            [12] 2750 	mov	r6,#0x00
      0069CB                       2751 00121$:
      0069CB EE               [12] 2752 	mov	a,r6
      0069CC 24 9A            [12] 2753 	add	a, #_raw_buffer
      0069CE FC               [12] 2754 	mov	r4,a
      0069CF E4               [12] 2755 	clr	a
      0069D0 34 07            [12] 2756 	addc	a, #(_raw_buffer >> 8)
      0069D2 FD               [12] 2757 	mov	r5,a
      0069D3 8E 82            [24] 2758 	mov	dpl,r6
      0069D5 74 10            [12] 2759 	mov	a,#0x10
      0069D7 24 00            [12] 2760 	add	a, #0x00
      0069D9 F5 83            [12] 2761 	mov	dph,a
      0069DB E0               [24] 2762 	movx	a,@dptr
      0069DC 8C 82            [24] 2763 	mov	dpl,r4
      0069DE 8D 83            [24] 2764 	mov	dph,r5
      0069E0 F0               [24] 2765 	movx	@dptr,a
      0069E1 0E               [12] 2766 	inc	r6
      0069E2 BE 20 00         [24] 2767 	cjne	r6,#0x20,00214$
      0069E5                       2768 00214$:
      0069E5 40 E4            [24] 2769 	jc	00121$
                                   2770 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0069E7 90 07 99         [24] 2771 	mov	dptr,#_raw_state
      0069EA 74 02            [12] 2772 	mov	a,#0x02
      0069EC F0               [24] 2773 	movx	@dptr,a
      0069ED 80 2B            [24] 2774 	sjmp	00119$
      0069EF                       2775 00118$:
                                   2776 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0069EF BF 02 0A         [24] 2777 	cjne	r7,#0x02,00115$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0069F2 90 10 00         [24] 2779 	mov	dptr,#0x1000
      0069F5 E0               [24] 2780 	movx	a,@dptr
      0069F6 90 07 96         [24] 2781 	mov	dptr,#_KB_USB_SetReport
      0069F9 F0               [24] 2782 	movx	@dptr,a
      0069FA 80 1E            [24] 2783 	sjmp	00119$
      0069FC                       2784 00115$:
                                   2785 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0069FC BF 03 18         [24] 2786 	cjne	r7,#0x03,00111$
      0069FF 90 10 00         [24] 2787 	mov	dptr,#0x1000
      006A02 E0               [24] 2788 	movx	a,@dptr
      006A03 FF               [12] 2789 	mov	r7,a
      006A04 90 07 F2         [24] 2790 	mov	dptr,#_output_report_id
      006A07 E0               [24] 2791 	movx	a,@dptr
      006A08 FE               [12] 2792 	mov	r6,a
      006A09 EF               [12] 2793 	mov	a,r7
      006A0A B5 06 0A         [24] 2794 	cjne	a,ar6,00111$
                                   2795 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006A0D 90 10 01         [24] 2796 	mov	dptr,#0x1001
      006A10 E0               [24] 2797 	movx	a,@dptr
      006A11 90 07 96         [24] 2798 	mov	dptr,#_KB_USB_SetReport
      006A14 F0               [24] 2799 	movx	@dptr,a
      006A15 80 03            [24] 2800 	sjmp	00119$
      006A17                       2801 00111$:
                                   2802 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006A17 02 5F C2         [24] 2803 	ljmp	_control_stall
      006A1A                       2804 00119$:
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006A1A 90 07 F1         [24] 2806 	mov	dptr,#_output_kind
      006A1D E4               [12] 2807 	clr	a
      006A1E F0               [24] 2808 	movx	@dptr,a
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006A1F 90 07 8C         [24] 2810 	mov	dptr,#_D0SetupLen
      006A22 F0               [24] 2811 	movx	@dptr,a
      006A23 A3               [24] 2812 	inc	dptr
      006A24 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006A25 90 07 F0         [24] 2815 	mov	dptr,#_control_phase
      006A28 74 03            [12] 2816 	mov	a,#0x03
      006A2A F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006A2B 90 22 08         [24] 2819 	mov	dptr,#0x2208
      006A2E E4               [12] 2820 	clr	a
      006A2F F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006A30 F5 82            [12] 2823 	mov	dpl,a
      006A32 74 48            [12] 2824 	mov	a,#0x48
      006A34 F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006A35 22               [24] 2827 	ret
                                   2828 ;------------------------------------------------------------
                                   2829 ;Allocation info for local variables in function 'control_in'
                                   2830 ;------------------------------------------------------------
                                   2831 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2832 ;	-----------------------------------------
                                   2833 ;	 function control_in
                                   2834 ;	-----------------------------------------
      006A36                       2835 _control_in:
                                   2836 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006A36 90 07 F0         [24] 2837 	mov	dptr,#_control_phase
      006A39 E0               [24] 2838 	movx	a,@dptr
      006A3A FF               [12] 2839 	mov	r7,a
      006A3B BF 01 22         [24] 2840 	cjne	r7,#0x01,00109$
                                   2841 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006A3E 90 07 8C         [24] 2842 	mov	dptr,#_D0SetupLen
      006A41 E0               [24] 2843 	movx	a,@dptr
      006A42 FD               [12] 2844 	mov	r5,a
      006A43 A3               [24] 2845 	inc	dptr
      006A44 E0               [24] 2846 	movx	a,@dptr
      006A45 4D               [12] 2847 	orl	a,r5
      006A46 70 06            [24] 2848 	jnz	00101$
      006A48 90 07 F3         [24] 2849 	mov	dptr,#_control_zlp
      006A4B E0               [24] 2850 	movx	a,@dptr
      006A4C 60 0A            [24] 2851 	jz	00102$
      006A4E                       2852 00101$:
                                   2853 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006A4E 90 22 00         [24] 2854 	mov	dptr,#0x2200
      006A51 E0               [24] 2855 	movx	a,@dptr
      006A52 64 40            [12] 2856 	xrl	a,#0x40
      006A54 F0               [24] 2857 	movx	@dptr,a
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2859 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006A55 02 5F E4         [24] 2860 	ljmp	_control_next
      006A58                       2861 00102$:
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006A58 90 07 F0         [24] 2863 	mov	dptr,#_control_phase
      006A5B 74 02            [12] 2864 	mov	a,#0x02
      006A5D F0               [24] 2865 	movx	@dptr,a
      006A5E 80 18            [24] 2866 	sjmp	00110$
      006A60                       2867 00109$:
                                   2868 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006A60 BF 03 15         [24] 2869 	cjne	r7,#0x03,00110$
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006A63 90 07 8B         [24] 2871 	mov	dptr,#_D0SetupReqCode
      006A66 E0               [24] 2872 	movx	a,@dptr
      006A67 FF               [12] 2873 	mov	r7,a
      006A68 BF 05 08         [24] 2874 	cjne	r7,#0x05,00105$
      006A6B 90 07 8C         [24] 2875 	mov	dptr,#_D0SetupLen
      006A6E E0               [24] 2876 	movx	a,@dptr
      006A6F 90 22 07         [24] 2877 	mov	dptr,#0x2207
      006A72 F0               [24] 2878 	movx	@dptr,a
      006A73                       2879 00105$:
                                   2880 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006A73 90 07 F0         [24] 2881 	mov	dptr,#_control_phase
      006A76 E4               [12] 2882 	clr	a
      006A77 F0               [24] 2883 	movx	@dptr,a
      006A78                       2884 00110$:
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A78 90 22 00         [24] 2886 	mov	dptr,#0x2200
      006A7B 74 82            [12] 2887 	mov	a,#0x82
      006A7D F0               [24] 2888 	movx	@dptr,a
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006A7E 22               [24] 2890 	ret
                                   2891 ;------------------------------------------------------------
                                   2892 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2893 ;------------------------------------------------------------
                                   2894 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2895 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2896 ;------------------------------------------------------------
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2898 ;	-----------------------------------------
                                   2899 ;	 function USB_DeviceInterrupt
                                   2900 ;	-----------------------------------------
      006A7F                       2901 _USB_DeviceInterrupt:
                                   2902 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006A7F                       2903 00129$:
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006A7F 90 22 3D         [24] 2905 	mov	dptr,#0x223d
      006A82 E0               [24] 2906 	movx	a,@dptr
      006A83 30 E0 4B         [24] 2907 	jnb	acc.0,00127$
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      006A86 12 5F 65         [24] 2909 	lcall	_endpoints_reset
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006A89 90 22 07         [24] 2911 	mov	dptr,#0x2207
      006A8C E4               [12] 2912 	clr	a
      006A8D F0               [24] 2913 	movx	@dptr,a
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A8E 90 07 93         [24] 2915 	mov	dptr,#_USB_SleepStatus
      006A91 F0               [24] 2916 	movx	@dptr,a
      006A92 90 07 92         [24] 2917 	mov	dptr,#_USB_EnumStatus
      006A95 F0               [24] 2918 	movx	@dptr,a
      006A96 90 07 91         [24] 2919 	mov	dptr,#_D0UsbConfig
      006A99 F0               [24] 2920 	movx	@dptr,a
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006A9A 90 07 96         [24] 2922 	mov	dptr,#_KB_USB_SetReport
      006A9D F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006A9E 90 0D E6         [24] 2925 	mov	dptr,#_keyboard_protocol
      006AA1 04               [12] 2926 	inc	a
      006AA2 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      006AA3 90 06 53         [24] 2929 	mov	dptr,#_keyboard_idle
      006AA6 E4               [12] 2930 	clr	a
      006AA7 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006AA8 90 07 BB         [24] 2933 	mov	dptr,#_keyboard_reset
      006AAB 04               [12] 2934 	inc	a
      006AAC F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006AAD 90 07 8B         [24] 2937 	mov	dptr,#_D0SetupReqCode
      006AB0 74 FF            [12] 2938 	mov	a,#0xff
      006AB2 F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      006AB3 90 07 8C         [24] 2941 	mov	dptr,#_D0SetupLen
      006AB6 E4               [12] 2942 	clr	a
      006AB7 F0               [24] 2943 	movx	@dptr,a
      006AB8 A3               [24] 2944 	inc	dptr
      006AB9 F0               [24] 2945 	movx	@dptr,a
                                   2946 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006ABA 90 07 F0         [24] 2947 	mov	dptr,#_control_phase
      006ABD F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006ABE 90 22 00         [24] 2950 	mov	dptr,#0x2200
      006AC1 74 02            [12] 2951 	mov	a,#0x02
      006AC3 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      006AC4 90 22 0F         [24] 2954 	mov	dptr,#0x220f
      006AC7 E4               [12] 2955 	clr	a
      006AC8 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006AC9 90 22 3D         [24] 2958 	mov	dptr,#0x223d
      006ACC 04               [12] 2959 	inc	a
      006ACD F0               [24] 2960 	movx	@dptr,a
      006ACE 02 6B 64         [24] 2961 	ljmp	00130$
      006AD1                       2962 00127$:
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006AD1 90 22 3D         [24] 2964 	mov	dptr,#0x223d
      006AD4 E0               [24] 2965 	movx	a,@dptr
      006AD5 30 E5 60         [24] 2966 	jnb	acc.5,00124$
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006AD8 90 22 0F         [24] 2968 	mov	dptr,#0x220f
      006ADB E0               [24] 2969 	movx	a,@dptr
      006ADC FF               [12] 2970 	mov	r7,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006ADD 74 07            [12] 2972 	mov	a,#0x07
      006ADF 5F               [12] 2973 	anl	a,r7
      006AE0 FE               [12] 2974 	mov	r6,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006AE1 EF               [12] 2976 	mov	a,r7
      006AE2 54 18            [12] 2977 	anl	a,#0x18
      006AE4 70 08            [24] 2978 	jnz	00115$
      006AE6 EE               [12] 2979 	mov	a,r6
      006AE7 70 05            [24] 2980 	jnz	00115$
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006AE9 12 69 78         [24] 2982 	lcall	_control_out
      006AEC 80 43            [24] 2983 	sjmp	00116$
      006AEE                       2984 00115$:
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006AEE 8F 05            [24] 2986 	mov	ar5,r7
      006AF0 74 18            [12] 2987 	mov	a,#0x18
      006AF2 5D               [12] 2988 	anl	a,r5
      006AF3 FC               [12] 2989 	mov	r4,a
      006AF4 BC 10 2D         [24] 2990 	cjne	r4,#0x10,00112$
                                   2991 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006AF7 EE               [12] 2992 	mov	a,r6
      006AF8 70 05            [24] 2993 	jnz	00106$
      006AFA 12 6A 36         [24] 2994 	lcall	_control_in
      006AFD 80 32            [24] 2995 	sjmp	00116$
      006AFF                       2996 00106$:
                                   2997 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006AFF EE               [12] 2998 	mov	a,r6
      006B00 24 FC            [12] 2999 	add	a,#0xff - 0x03
      006B02 40 2D            [24] 3000 	jc	00116$
                                   3001 ;	free result
                                   3002 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006B04 8E 04            [24] 3003 	mov	ar4,r6
      006B06 7B 00            [12] 3004 	mov	r3,#0x00
      006B08 74 22            [12] 3005 	mov	a,#0x22
      006B0A 2B               [12] 3006 	add	a, r3
      006B0B FB               [12] 3007 	mov	r3,a
      006B0C 8C 82            [24] 3008 	mov	dpl,r4
      006B0E 8B 83            [24] 3009 	mov	dph,r3
      006B10 E0               [24] 3010 	movx	a,@dptr
      006B11 FA               [12] 3011 	mov	r2,a
      006B12 74 FC            [12] 3012 	mov	a,#0xfc
      006B14 5A               [12] 3013 	anl	a,r2
      006B15 44 02            [12] 3014 	orl	a,#0x02
      006B17 8C 82            [24] 3015 	mov	dpl,r4
      006B19 8B 83            [24] 3016 	mov	dph,r3
      006B1B F0               [24] 3017 	movx	@dptr,a
                                   3018 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006B1C BE 03 12         [24] 3019 	cjne	r6,#0x03,00116$
      006B1F 12 5F 48         [24] 3020 	lcall	_raw_complete
      006B22 80 0D            [24] 3021 	sjmp	00116$
      006B24                       3022 00112$:
                                   3023 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006B24 53 05 18         [24] 3024 	anl	ar5,#0x18
      006B27 BD 18 07         [24] 3025 	cjne	r5,#0x18,00116$
      006B2A EF               [12] 3026 	mov	a,r7
      006B2B 30 E5 03         [24] 3027 	jnb	acc.5,00116$
                                   3028 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006B2E 12 61 DB         [24] 3029 	lcall	_control_setup
      006B31                       3030 00116$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006B31 90 22 0F         [24] 3032 	mov	dptr,#0x220f
      006B34 E4               [12] 3033 	clr	a
      006B35 F0               [24] 3034 	movx	@dptr,a
      006B36 80 2C            [24] 3035 	sjmp	00130$
      006B38                       3036 00124$:
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006B38 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006B3B E0               [24] 3039 	movx	a,@dptr
      006B3C 30 E2 25         [24] 3040 	jnb	acc.2,00130$
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006B3F 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      006B42 E0               [24] 3043 	movx	a,@dptr
      006B43 30 E3 0A         [24] 3044 	jnb	acc.3,00119$
      006B46 90 07 93         [24] 3045 	mov	dptr,#_USB_SleepStatus
      006B49 E0               [24] 3046 	movx	a,@dptr
      006B4A 43 E0 02         [24] 3047 	orl	acc,#0x02
      006B4D F0               [24] 3048 	movx	@dptr,a
      006B4E 80 0E            [24] 3049 	sjmp	00120$
      006B50                       3050 00119$:
                                   3051 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006B50 90 07 93         [24] 3052 	mov	dptr,#_USB_SleepStatus
      006B53 E0               [24] 3053 	movx	a,@dptr
      006B54 53 E0 FD         [24] 3054 	anl	acc,#0xfd
      006B57 F0               [24] 3055 	movx	@dptr,a
                                   3056 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006B58 90 07 BB         [24] 3057 	mov	dptr,#_keyboard_reset
      006B5B 74 01            [12] 3058 	mov	a,#0x01
      006B5D F0               [24] 3059 	movx	@dptr,a
      006B5E                       3060 00120$:
                                   3061 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006B5E 90 22 3D         [24] 3062 	mov	dptr,#0x223d
      006B61 74 04            [12] 3063 	mov	a,#0x04
      006B63 F0               [24] 3064 	movx	@dptr,a
      006B64                       3065 00130$:
                                   3066 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006B64 90 22 3D         [24] 3067 	mov	dptr,#0x223d
      006B67 E0               [24] 3068 	movx	a,@dptr
      006B68 54 25            [12] 3069 	anl	a,#0x25
      006B6A 60 03            [24] 3070 	jz	00242$
      006B6C 02 6A 7F         [24] 3071 	ljmp	00129$
      006B6F                       3072 00242$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006B6F 22               [24] 3074 	ret
                                   3075 ;------------------------------------------------------------
                                   3076 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3077 ;------------------------------------------------------------
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3079 ;	-----------------------------------------
                                   3080 ;	 function USB_Device_Init
                                   3081 ;	-----------------------------------------
      006B70                       3082 _USB_Device_Init:
                                   3083 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3084 ;	assignBit
      006B70 C2 E9            [12] 3085 	clr	_IE_USB
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006B72 90 22 3C         [24] 3087 	mov	dptr,#0x223c
      006B75 E4               [12] 3088 	clr	a
      006B76 F0               [24] 3089 	movx	@dptr,a
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006B77 90 07 99         [24] 3091 	mov	dptr,#_raw_state
      006B7A F0               [24] 3092 	movx	@dptr,a
                                   3093 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006B7B 12 5F 65         [24] 3094 	lcall	_endpoints_reset
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B7E 90 07 93         [24] 3096 	mov	dptr,#_USB_SleepStatus
      006B81 E4               [12] 3097 	clr	a
      006B82 F0               [24] 3098 	movx	@dptr,a
      006B83 90 07 92         [24] 3099 	mov	dptr,#_USB_EnumStatus
      006B86 F0               [24] 3100 	movx	@dptr,a
      006B87 90 07 91         [24] 3101 	mov	dptr,#_D0UsbConfig
      006B8A F0               [24] 3102 	movx	@dptr,a
      006B8B 90 22 07         [24] 3103 	mov	dptr,#0x2207
      006B8E F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006B8F 90 07 94         [24] 3106 	mov	dptr,#_MCU_Sleep_Operate
      006B92 F0               [24] 3107 	movx	@dptr,a
      006B93 90 07 95         [24] 3108 	mov	dptr,#_KB_USB_UpStatus
      006B96 F0               [24] 3109 	movx	@dptr,a
      006B97 90 07 96         [24] 3110 	mov	dptr,#_KB_USB_SetReport
      006B9A F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006B9B 90 0D E6         [24] 3113 	mov	dptr,#_keyboard_protocol
      006B9E 04               [12] 3114 	inc	a
      006B9F F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006BA0 90 06 53         [24] 3117 	mov	dptr,#_keyboard_idle
      006BA3 E4               [12] 3118 	clr	a
      006BA4 F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006BA5 90 07 BB         [24] 3121 	mov	dptr,#_keyboard_reset
      006BA8 F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006BA9 90 07 F0         [24] 3124 	mov	dptr,#_control_phase
      006BAC F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006BAD 90 07 8B         [24] 3127 	mov	dptr,#_D0SetupReqCode
      006BB0 14               [12] 3128 	dec	a
      006BB1 F0               [24] 3129 	movx	@dptr,a
                                   3130 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006BB2 90 07 8C         [24] 3131 	mov	dptr,#_D0SetupLen
      006BB5 E4               [12] 3132 	clr	a
      006BB6 F0               [24] 3133 	movx	@dptr,a
      006BB7 A3               [24] 3134 	inc	dptr
      006BB8 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006BB9 90 22 00         [24] 3137 	mov	dptr,#0x2200
      006BBC 74 02            [12] 3138 	mov	a,#0x02
      006BBE F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006BBF 90 22 37         [24] 3141 	mov	dptr,#0x2237
      006BC2 74 7F            [12] 3142 	mov	a,#0x7f
      006BC4 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006BC5 90 22 3D         [24] 3145 	mov	dptr,#0x223d
      006BC8 74 FF            [12] 3146 	mov	a,#0xff
      006BCA F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006BCB 90 22 3B         [24] 3149 	mov	dptr,#0x223b
      006BCE 74 07            [12] 3150 	mov	a,#0x07
      006BD0 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006BD1 A3               [24] 3153 	inc	dptr
      006BD2 74 80            [12] 3154 	mov	a,#0x80
      006BD4 F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3157 ;	assignBit
      006BD5 D2 E9            [12] 3158 	setb	_IE_USB
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006BD7 22               [24] 3160 	ret
                                   3161 ;------------------------------------------------------------
                                   3162 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3163 ;------------------------------------------------------------
                                   3164 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3165 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3166 ;------------------------------------------------------------
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3168 ;	-----------------------------------------
                                   3169 ;	 function USB_WakeUp_PC
                                   3170 ;	-----------------------------------------
      006BD8                       3171 _USB_WakeUp_PC:
                                   3172 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006BD8 90 07 93         [24] 3173 	mov	dptr,#_USB_SleepStatus
      006BDB E0               [24] 3174 	movx	a,@dptr
      006BDC FF               [12] 3175 	mov	r7,a
      006BDD BF 03 22         [24] 3176 	cjne	r7,#0x03,00110$
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006BE0 90 22 3C         [24] 3178 	mov	dptr,#0x223c
      006BE3 E0               [24] 3179 	movx	a,@dptr
      006BE4 FF               [12] 3180 	mov	r7,a
                                   3181 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006BE5 E0               [24] 3182 	movx	a,@dptr
      006BE6 FE               [12] 3183 	mov	r6,a
      006BE7 63 06 C0         [24] 3184 	xrl	ar6,#0xc0
      006BEA 90 22 3C         [24] 3185 	mov	dptr,#0x223c
      006BED EE               [12] 3186 	mov	a,r6
      006BEE F0               [24] 3187 	movx	@dptr,a
                                   3188 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006BEF 7E 0A            [12] 3189 	mov	r6,#0x0a
      006BF1                       3190 00108$:
      006BF1 EE               [12] 3191 	mov	a,r6
      006BF2 60 09            [24] 3192 	jz	00105$
      006BF4 90 00 01         [24] 3193 	mov	dptr,#0x0001
      006BF7 12 5D 8C         [24] 3194 	lcall	_mDelaymS
      006BFA 1E               [12] 3195 	dec	r6
      006BFB 80 F4            [24] 3196 	sjmp	00108$
      006BFD                       3197 00105$:
                                   3198 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006BFD 90 22 3C         [24] 3199 	mov	dptr,#0x223c
      006C00 EF               [12] 3200 	mov	a,r7
      006C01 F0               [24] 3201 	movx	@dptr,a
      006C02                       3202 00110$:
                                   3203 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006C02 22               [24] 3204 	ret
                                   3205 ;------------------------------------------------------------
                                   3206 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3207 ;------------------------------------------------------------
                                   3208 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3209 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3210 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3211 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3212 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3213 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3215 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3216 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3217 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3218 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3219 ;------------------------------------------------------------
                                   3220 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3221 ;	-----------------------------------------
                                   3222 ;	 function ak820_usb_send
                                   3223 ;	-----------------------------------------
      006C03                       3224 _ak820_usb_send:
      006C03 E5 82            [12] 3225 	mov	a,dpl
      006C05 90 08 00         [24] 3226 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C08 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006C09 90 08 01         [24] 3229 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C0C 74 34            [12] 3230 	mov	a,#0x34
      006C0E F0               [24] 3231 	movx	@dptr,a
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006C0F 90 08 00         [24] 3233 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C12 E0               [24] 3234 	movx	a,@dptr
      006C13 FF               [12] 3235 	mov	r7,a
      006C14 BF 01 00         [24] 3236 	cjne	r7,#0x01,00306$
      006C17                       3237 00306$:
      006C17 40 14            [24] 3238 	jc	00101$
      006C19 EF               [12] 3239 	mov	a,r7
      006C1A 24 FC            [12] 3240 	add	a,#0xff - 0x03
      006C1C 40 0F            [24] 3241 	jc	00101$
                                   3242 ;	free result
      006C1E 90 07 FF         [24] 3243 	mov	dptr,#_ak820_usb_send_PARM_3
      006C21 E0               [24] 3244 	movx	a,@dptr
      006C22 FE               [12] 3245 	mov  r6,a
      006C23 24 BF            [12] 3246 	add	a,#0xff - 0x40
      006C25 40 06            [24] 3247 	jc	00101$
                                   3248 ;	free result
      006C27 90 07 92         [24] 3249 	mov	dptr,#_USB_EnumStatus
      006C2A E0               [24] 3250 	movx	a,@dptr
      006C2B 70 04            [24] 3251 	jnz	00102$
      006C2D                       3252 00101$:
      006C2D 75 82 00         [24] 3253 	mov	dpl, #0x00
      006C30 22               [24] 3254 	ret
      006C31                       3255 00102$:
                                   3256 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006C31 BF 01 10         [24] 3257 	cjne	r7,#0x01,00118$
                                   3258 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006C34 BE 08 02         [24] 3259 	cjne	r6,#0x08,00313$
      006C37 80 04            [24] 3260 	sjmp	00107$
      006C39                       3261 00313$:
      006C39 75 82 00         [24] 3262 	mov	dpl, #0x00
      006C3C 22               [24] 3263 	ret
      006C3D                       3264 00107$:
                                   3265 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006C3D 90 08 01         [24] 3266 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C40 E4               [12] 3267 	clr	a
      006C41 F0               [24] 3268 	movx	@dptr,a
      006C42 80 3C            [24] 3269 	sjmp	00119$
      006C44                       3270 00118$:
                                   3271 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006C44 BF 02 30         [24] 3272 	cjne	r7,#0x02,00115$
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006C47 90 07 FD         [24] 3274 	mov	dptr,#_ak820_usb_send_PARM_2
      006C4A E0               [24] 3275 	movx	a,@dptr
      006C4B FD               [12] 3276 	mov	r5,a
      006C4C A3               [24] 3277 	inc	dptr
      006C4D E0               [24] 3278 	movx	a,@dptr
      006C4E FF               [12] 3279 	mov	r7,a
      006C4F 8D 82            [24] 3280 	mov	dpl,r5
      006C51 8F 83            [24] 3281 	mov	dph,r7
      006C53 E0               [24] 3282 	movx	a,@dptr
      006C54 FF               [12] 3283 	mov	r7,a
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006C55 BF 07 00         [24] 3285 	cjne	r7,#0x07,00316$
      006C58                       3286 00316$:
      006C58 50 0E            [24] 3287 	jnc	00108$
      006C5A EF               [12] 3288 	mov	a,r7
      006C5B 90 BD E8         [24] 3289 	mov	dptr,#_shared_lengths
      006C5E 93               [24] 3290 	movc	a,@a+dptr
      006C5F FD               [12] 3291 	mov	r5,a
      006C60 60 06            [24] 3292 	jz	00108$
      006C62 EE               [12] 3293 	mov	a,r6
      006C63 B5 05 02         [24] 3294 	cjne	a,ar5,00319$
      006C66 80 04            [24] 3295 	sjmp	00109$
      006C68                       3296 00319$:
      006C68                       3297 00108$:
      006C68 75 82 00         [24] 3298 	mov	dpl, #0x00
      006C6B 22               [24] 3299 	ret
      006C6C                       3300 00109$:
                                   3301 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006C6C EF               [12] 3302 	mov	a,r7
      006C6D 90 BD E1         [24] 3303 	mov	dptr,#_shared_offsets
      006C70 93               [24] 3304 	movc	a,@a+dptr
      006C71 90 08 01         [24] 3305 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C74 F0               [24] 3306 	movx	@dptr,a
      006C75 80 09            [24] 3307 	sjmp	00119$
      006C77                       3308 00115$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006C77 BE 20 02         [24] 3310 	cjne	r6,#0x20,00320$
      006C7A 80 04            [24] 3311 	sjmp	00119$
      006C7C                       3312 00320$:
      006C7C 75 82 00         [24] 3313 	mov	dpl, #0x00
      006C7F 22               [24] 3314 	ret
      006C80                       3315 00119$:
                                   3316 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006C80 90 07 93         [24] 3317 	mov	dptr,#_USB_SleepStatus
      006C83 E0               [24] 3318 	movx	a,@dptr
      006C84 30 E1 07         [24] 3319 	jnb	acc.1,00184$
      006C87 12 6B D8         [24] 3320 	lcall	_USB_WakeUp_PC
      006C8A 75 82 00         [24] 3321 	mov	dpl, #0x00
      006C8D 22               [24] 3322 	ret
                                   3323 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006C8E                       3324 00184$:
      006C8E 7F FA            [12] 3325 	mov	r7,#0xfa
      006C90                       3326 00127$:
      006C90 90 08 00         [24] 3327 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C93 E0               [24] 3328 	movx	a,@dptr
      006C94 FC               [12] 3329 	mov	r4,a
      006C95 7D 00            [12] 3330 	mov	r5,#0x00
      006C97 8C 02            [24] 3331 	mov	ar2,r4
      006C99 74 22            [12] 3332 	mov	a,#0x22
      006C9B 2D               [12] 3333 	add	a, r5
      006C9C FB               [12] 3334 	mov	r3,a
      006C9D 8A 82            [24] 3335 	mov	dpl,r2
      006C9F 8B 83            [24] 3336 	mov	dph,r3
      006CA1 E0               [24] 3337 	movx	a,@dptr
      006CA2 54 03            [12] 3338 	anl	a,#0x03
      006CA4 70 20            [24] 3339 	jnz	00129$
      006CA6 8F 03            [24] 3340 	mov	ar3,r7
      006CA8 1F               [12] 3341 	dec	r7
      006CA9 EB               [12] 3342 	mov	a,r3
      006CAA 60 1A            [24] 3343 	jz	00129$
      006CAC 7B 28            [12] 3344 	mov	r3,#0x28
      006CAE                       3345 00141$:
      006CAE EB               [12] 3346 	mov	a,r3
      006CAF 60 DF            [24] 3347 	jz	00127$
      006CB1 90 00 01         [24] 3348 	mov	dptr,#0x0001
      006CB4 C0 07            [24] 3349 	push	ar7
      006CB6 C0 06            [24] 3350 	push	ar6
      006CB8 C0 03            [24] 3351 	push	ar3
      006CBA 12 5D 50         [24] 3352 	lcall	_mDelayuS
      006CBD D0 03            [24] 3353 	pop	ar3
      006CBF D0 06            [24] 3354 	pop	ar6
      006CC1 D0 07            [24] 3355 	pop	ar7
      006CC3 1B               [12] 3356 	dec	r3
      006CC4 80 E8            [24] 3357 	sjmp	00141$
      006CC6                       3358 00129$:
                                   3359 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006CC6 A2 AF            [12] 3360 	mov	c,_EA
      006CC8 E4               [12] 3361 	clr	a
      006CC9 33               [12] 3362 	rlc	a
      006CCA FF               [12] 3363 	mov	r7,a
                                   3364 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3365 ;	assignBit
      006CCB C2 AF            [12] 3366 	clr	_EA
                                   3367 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006CCD 90 07 92         [24] 3368 	mov	dptr,#_USB_EnumStatus
      006CD0 E0               [24] 3369 	movx	a,@dptr
      006CD1 60 25            [24] 3370 	jz	00130$
      006CD3 90 08 00         [24] 3371 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CD6 E0               [24] 3372 	movx	a,@dptr
      006CD7 FB               [12] 3373 	mov	r3,a
      006CD8 F9               [12] 3374 	mov	r1,a
      006CD9 7A 00            [12] 3375 	mov	r2,#0x00
      006CDB 74 22            [12] 3376 	mov	a,#0x22
      006CDD 2A               [12] 3377 	add	a, r2
      006CDE FA               [12] 3378 	mov	r2,a
      006CDF 89 82            [24] 3379 	mov	dpl,r1
      006CE1 8A 83            [24] 3380 	mov	dph,r2
      006CE3 E0               [24] 3381 	movx	a,@dptr
      006CE4 FA               [12] 3382 	mov	r2,a
      006CE5 53 02 03         [24] 3383 	anl	ar2,#0x03
      006CE8 BA 02 0D         [24] 3384 	cjne	r2,#0x02,00130$
                                   3385 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006CEB BB 03 13         [24] 3386 	cjne	r3,#0x03,00192$
      006CEE 90 07 99         [24] 3387 	mov	dptr,#_raw_state
      006CF1 E0               [24] 3388 	movx	a,@dptr
      006CF2 FB               [12] 3389 	mov	r3,a
      006CF3 BB 03 02         [24] 3390 	cjne	r3,#0x03,00331$
      006CF6 80 09            [24] 3391 	sjmp	00192$
      006CF8                       3392 00331$:
      006CF8                       3393 00130$:
                                   3394 ;	assignBit
      006CF8 EF               [12] 3395 	mov	a,r7
      006CF9 24 FF            [12] 3396 	add	a,#0xff
      006CFB 92 AF            [24] 3397 	mov	_EA,c
      006CFD 75 82 00         [24] 3398 	mov	dpl, #0x00
      006D00 22               [24] 3399 	ret
                                   3400 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006D01                       3401 00192$:
      006D01 7B 00            [12] 3402 	mov	r3,#0x00
      006D03                       3403 00144$:
      006D03 C3               [12] 3404 	clr	c
      006D04 EB               [12] 3405 	mov	a,r3
      006D05 9E               [12] 3406 	subb	a,r6
      006D06 50 67            [24] 3407 	jnc	00137$
                                   3408 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006D08 C0 07            [24] 3409 	push	ar7
      006D0A 90 08 00         [24] 3410 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D0D E0               [24] 3411 	movx	a,@dptr
      006D0E F9               [12] 3412 	mov	r1,a
      006D0F E4               [12] 3413 	clr	a
      006D10 C3               [12] 3414 	clr	c
      006D11 C9               [12] 3415 	xch	a,r1
      006D12 13               [12] 3416 	rrc	a
      006D13 C9               [12] 3417 	xch	a,r1
      006D14 13               [12] 3418 	rrc	a
      006D15 A2 E0            [12] 3419 	mov	c,acc.0
      006D17 C9               [12] 3420 	xch	a,r1
      006D18 13               [12] 3421 	rrc	a
      006D19 C9               [12] 3422 	xch	a,r1
      006D1A 13               [12] 3423 	rrc	a
      006D1B C9               [12] 3424 	xch	a,r1
      006D1C FA               [12] 3425 	mov	r2,a
      006D1D 8B 00            [24] 3426 	mov	ar0,r3
      006D1F 7F 00            [12] 3427 	mov	r7,#0x00
      006D21 E8               [12] 3428 	mov	a,r0
      006D22 29               [12] 3429 	add	a, r1
      006D23 F9               [12] 3430 	mov	r1,a
      006D24 EF               [12] 3431 	mov	a,r7
      006D25 3A               [12] 3432 	addc	a, r2
      006D26 24 10            [12] 3433 	add	a,#0x10
      006D28 FA               [12] 3434 	mov	r2,a
      006D29 90 07 FD         [24] 3435 	mov	dptr,#_ak820_usb_send_PARM_2
      006D2C E0               [24] 3436 	movx	a,@dptr
      006D2D F8               [12] 3437 	mov	r0,a
      006D2E A3               [24] 3438 	inc	dptr
      006D2F E0               [24] 3439 	movx	a,@dptr
      006D30 FF               [12] 3440 	mov	r7,a
      006D31 EB               [12] 3441 	mov	a,r3
      006D32 28               [12] 3442 	add	a, r0
      006D33 F5 1B            [12] 3443 	mov	_ak820_usb_send_sloc0_1_0,a
      006D35 E4               [12] 3444 	clr	a
      006D36 3F               [12] 3445 	addc	a, r7
      006D37 F5 1C            [12] 3446 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006D39 85 1B 82         [24] 3447 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D3C 85 1C 83         [24] 3448 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D3F E0               [24] 3449 	movx	a,@dptr
      006D40 89 82            [24] 3450 	mov	dpl,r1
      006D42 8A 83            [24] 3451 	mov	dph,r2
      006D44 F0               [24] 3452 	movx	@dptr,a
                                   3453 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006D45 90 08 01         [24] 3454 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006D48 E0               [24] 3455 	movx	a,@dptr
      006D49 F5 1D            [12] 3456 	mov	_ak820_usb_send_sloc1_1_0,a
      006D4B 74 34            [12] 3457 	mov	a,#0x34
      006D4D B5 1D 04         [24] 3458 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006D50 D0 07            [24] 3459 	pop	ar7
      006D52 80 18            [24] 3460 	sjmp	00145$
      006D54                       3461 00333$:
      006D54 D0 07            [24] 3462 	pop	ar7
      006D56 EB               [12] 3463 	mov	a,r3
      006D57 25 1D            [12] 3464 	add	a, _ak820_usb_send_sloc1_1_0
      006D59 24 BC            [12] 3465 	add	a, #_input_snapshot
      006D5B F9               [12] 3466 	mov	r1,a
      006D5C E4               [12] 3467 	clr	a
      006D5D 34 07            [12] 3468 	addc	a,#(_input_snapshot >> 8)
      006D5F FA               [12] 3469 	mov	r2,a
      006D60 85 1B 82         [24] 3470 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D63 85 1C 83         [24] 3471 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D66 E0               [24] 3472 	movx	a,@dptr
      006D67 89 82            [24] 3473 	mov	dpl,r1
      006D69 8A 83            [24] 3474 	mov	dph,r2
      006D6B F0               [24] 3475 	movx	@dptr,a
      006D6C                       3476 00145$:
                                   3477 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006D6C 0B               [12] 3478 	inc	r3
      006D6D 80 94            [24] 3479 	sjmp	00144$
      006D6F                       3480 00137$:
                                   3481 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006D6F 90 08 00         [24] 3482 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D72 E0               [24] 3483 	movx	a,@dptr
      006D73 FB               [12] 3484 	mov	r3,a
      006D74 F9               [12] 3485 	mov	r1,a
      006D75 7A 00            [12] 3486 	mov	r2,#0x00
      006D77 74 08            [12] 3487 	mov	a,#0x08
      006D79 29               [12] 3488 	add	a, r1
      006D7A F9               [12] 3489 	mov	r1,a
      006D7B 74 22            [12] 3490 	mov	a,#0x22
      006D7D 3A               [12] 3491 	addc	a, r2
      006D7E FA               [12] 3492 	mov	r2,a
      006D7F 89 82            [24] 3493 	mov	dpl,r1
      006D81 8A 83            [24] 3494 	mov	dph,r2
      006D83 EE               [12] 3495 	mov	a,r6
      006D84 F0               [24] 3496 	movx	@dptr,a
                                   3497 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006D85 BB 03 06         [24] 3498 	cjne	r3,#0x03,00139$
      006D88 90 07 99         [24] 3499 	mov	dptr,#_raw_state
      006D8B 74 04            [12] 3500 	mov	a,#0x04
      006D8D F0               [24] 3501 	movx	@dptr,a
      006D8E                       3502 00139$:
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006D8E 74 22            [12] 3504 	mov	a,#0x22
      006D90 2D               [12] 3505 	add	a, r5
      006D91 FD               [12] 3506 	mov	r5,a
      006D92 8C 82            [24] 3507 	mov	dpl,r4
      006D94 8D 83            [24] 3508 	mov	dph,r5
      006D96 E0               [24] 3509 	movx	a,@dptr
      006D97 FE               [12] 3510 	mov	r6,a
      006D98 53 06 FC         [24] 3511 	anl	ar6,#0xfc
      006D9B 8C 82            [24] 3512 	mov	dpl,r4
      006D9D 8D 83            [24] 3513 	mov	dph,r5
      006D9F EE               [12] 3514 	mov	a,r6
      006DA0 F0               [24] 3515 	movx	@dptr,a
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3517 ;	assignBit
      006DA1 EF               [12] 3518 	mov	a,r7
      006DA2 24 FF            [12] 3519 	add	a,#0xff
      006DA4 92 AF            [24] 3520 	mov	_EA,c
                                   3521 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006DA6 75 82 01         [24] 3522 	mov	dpl, #0x01
                                   3523 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006DA9 22               [24] 3524 	ret
                                   3525 ;------------------------------------------------------------
                                   3526 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3527 ;------------------------------------------------------------
                                   3528 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3529 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3530 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3531 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3532 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3533 ;------------------------------------------------------------
                                   3534 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3535 ;	-----------------------------------------
                                   3536 ;	 function ak820_usb_try_send
                                   3537 ;	-----------------------------------------
      006DAA                       3538 _ak820_usb_try_send:
      006DAA E5 82            [12] 3539 	mov	a,dpl
      006DAC 90 08 05         [24] 3540 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006DAF F0               [24] 3541 	movx	@dptr,a
                                   3542 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3543 ;	assignBit
      006DB0 A2 AF            [12] 3544 	mov	c,_EA
      006DB2 92 1D            [24] 3545 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006DB4 90 08 06         [24] 3547 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DB7 E4               [12] 3548 	clr	a
      006DB8 F0               [24] 3549 	movx	@dptr,a
                                   3550 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3551 ;	assignBit
      006DB9 C2 AF            [12] 3552 	clr	_EA
                                   3553 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006DBB 90 08 05         [24] 3554 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006DBE E0               [24] 3555 	movx	a,@dptr
      006DBF FF               [12] 3556 	mov	r7,a
      006DC0 BF 01 00         [24] 3557 	cjne	r7,#0x01,00152$
      006DC3                       3558 00152$:
      006DC3 40 4E            [24] 3559 	jc	00102$
      006DC5 EF               [12] 3560 	mov	a,r7
      006DC6 24 FD            [12] 3561 	add	a,#0xff - 0x02
      006DC8 40 49            [24] 3562 	jc	00102$
                                   3563 ;	free result
      006DCA 90 07 92         [24] 3564 	mov	dptr,#_USB_EnumStatus
      006DCD E0               [24] 3565 	movx	a,@dptr
      006DCE 60 43            [24] 3566 	jz	00102$
                                   3567 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006DD0 90 07 93         [24] 3568 	mov	dptr,#_USB_SleepStatus
      006DD3 E0               [24] 3569 	movx	a,@dptr
      006DD4 20 E1 3C         [24] 3570 	jb	acc.1,00102$
      006DD7 90 07 BB         [24] 3571 	mov	dptr,#_keyboard_reset
      006DDA E0               [24] 3572 	movx	a,@dptr
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006DDB 70 36            [24] 3574 	jnz	00102$
      006DDD 8F 06            [24] 3575 	mov	ar6,r7
      006DDF 24 22            [12] 3576 	add	a,#0x22
      006DE1 FD               [12] 3577 	mov	r5,a
      006DE2 8E 82            [24] 3578 	mov	dpl,r6
      006DE4 8D 83            [24] 3579 	mov	dph,r5
      006DE6 E0               [24] 3580 	movx	a,@dptr
      006DE7 FE               [12] 3581 	mov	r6,a
      006DE8 53 06 03         [24] 3582 	anl	ar6,#0x03
      006DEB BE 02 25         [24] 3583 	cjne	r6,#0x02,00102$
                                   3584 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006DEE 90 08 02         [24] 3585 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006DF1 E0               [24] 3586 	movx	a,@dptr
      006DF2 FD               [12] 3587 	mov	r5,a
      006DF3 A3               [24] 3588 	inc	dptr
      006DF4 E0               [24] 3589 	movx	a,@dptr
      006DF5 FE               [12] 3590 	mov	r6,a
      006DF6 90 08 04         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006DF9 E0               [24] 3592 	movx	a,@dptr
      006DFA FC               [12] 3593 	mov	r4,a
      006DFB 90 07 FD         [24] 3594 	mov	dptr,#_ak820_usb_send_PARM_2
      006DFE ED               [12] 3595 	mov	a,r5
      006DFF F0               [24] 3596 	movx	@dptr,a
      006E00 EE               [12] 3597 	mov	a,r6
      006E01 A3               [24] 3598 	inc	dptr
      006E02 F0               [24] 3599 	movx	@dptr,a
      006E03 90 07 FF         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_3
      006E06 EC               [12] 3601 	mov	a,r4
      006E07 F0               [24] 3602 	movx	@dptr,a
      006E08 8F 82            [24] 3603 	mov	dpl, r7
      006E0A 12 6C 03         [24] 3604 	lcall	_ak820_usb_send
      006E0D E5 82            [12] 3605 	mov	a, dpl
      006E0F 90 08 06         [24] 3606 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006E12 F0               [24] 3607 	movx	@dptr,a
      006E13                       3608 00102$:
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3610 ;	assignBit
      006E13 A2 1D            [12] 3611 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006E15 92 AF            [24] 3612 	mov	_EA,c
                                   3613 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006E17 90 08 06         [24] 3614 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006E1A E0               [24] 3615 	movx	a,@dptr
                                   3616 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006E1B F5 82            [12] 3617 	mov	dpl,a
      006E1D 22               [24] 3618 	ret
                                   3619 ;------------------------------------------------------------
                                   3620 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3621 ;------------------------------------------------------------
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3623 ;	-----------------------------------------
                                   3624 ;	 function raw_request_is_nonpersistent
                                   3625 ;	-----------------------------------------
      006E1E                       3626 _raw_request_is_nonpersistent:
                                   3627 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006E1E 90 07 9A         [24] 3628 	mov	dptr,#_raw_buffer
      006E21 E0               [24] 3629 	movx	a,@dptr
      006E22 FF               [12] 3630 	mov	r7,a
      006E23 BF 01 02         [24] 3631 	cjne	r7,#0x01,00302$
      006E26 80 35            [24] 3632 	sjmp	00108$
      006E28                       3633 00302$:
      006E28 BF 02 02         [24] 3634 	cjne	r7,#0x02,00303$
      006E2B 80 34            [24] 3635 	sjmp	00109$
      006E2D                       3636 00303$:
      006E2D BF 04 02         [24] 3637 	cjne	r7,#0x04,00304$
      006E30 80 2B            [24] 3638 	sjmp	00108$
      006E32                       3639 00304$:
      006E32 BF 08 02         [24] 3640 	cjne	r7,#0x08,00305$
      006E35 80 47            [24] 3641 	sjmp	00116$
      006E37                       3642 00305$:
      006E37 BF 0B 02         [24] 3643 	cjne	r7,#0x0b,00306$
      006E3A 80 21            [24] 3644 	sjmp	00108$
      006E3C                       3645 00306$:
      006E3C BF 0C 02         [24] 3646 	cjne	r7,#0x0c,00307$
      006E3F 80 1C            [24] 3647 	sjmp	00108$
      006E41                       3648 00307$:
      006E41 BF 0D 02         [24] 3649 	cjne	r7,#0x0d,00308$
      006E44 80 17            [24] 3650 	sjmp	00108$
      006E46                       3651 00308$:
      006E46 BF 0E 02         [24] 3652 	cjne	r7,#0x0e,00309$
      006E49 80 12            [24] 3653 	sjmp	00108$
      006E4B                       3654 00309$:
      006E4B BF 11 02         [24] 3655 	cjne	r7,#0x11,00310$
      006E4E 80 0D            [24] 3656 	sjmp	00108$
      006E50                       3657 00310$:
      006E50 BF 12 02         [24] 3658 	cjne	r7,#0x12,00311$
      006E53 80 08            [24] 3659 	sjmp	00108$
      006E55                       3660 00311$:
      006E55 BF FE 02         [24] 3661 	cjne	r7,#0xfe,00312$
      006E58 80 46            [24] 3662 	sjmp	00124$
      006E5A                       3663 00312$:
      006E5A 02 6E F5         [24] 3664 	ljmp	00144$
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006E5D                       3666 00108$:
                                   3667 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006E5D 75 82 01         [24] 3668 	mov	dpl, #0x01
      006E60 22               [24] 3669 	ret
                                   3670 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006E61                       3671 00109$:
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006E61 12 71 27         [24] 3673 	lcall	_ak820_outline_0167
      006E64 BF 01 02         [24] 3674 	cjne	r7,#0x01,00313$
      006E67 80 0D            [24] 3675 	sjmp	00113$
      006E69                       3676 00313$:
      006E69 BF 02 02         [24] 3677 	cjne	r7,#0x02,00314$
      006E6C 80 08            [24] 3678 	sjmp	00113$
      006E6E                       3679 00314$:
      006E6E BF 03 02         [24] 3680 	cjne	r7,#0x03,00315$
      006E71 80 03            [24] 3681 	sjmp	00113$
      006E73                       3682 00315$:
      006E73 BF 04 04         [24] 3683 	cjne	r7,#0x04,00114$
                                   3684 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006E76                       3685 00113$:
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006E76 75 82 01         [24] 3687 	mov	dpl, #0x01
      006E79 22               [24] 3688 	ret
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006E7A                       3690 00114$:
      006E7A 75 82 00         [24] 3691 	mov	dpl, #0x00
      006E7D 22               [24] 3692 	ret
                                   3693 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006E7E                       3694 00116$:
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006E7E 12 71 27         [24] 3696 	lcall	_ak820_outline_0167
      006E81 BF 40 02         [24] 3697 	cjne	r7,#0x40,00318$
      006E84 80 12            [24] 3698 	sjmp	00121$
      006E86                       3699 00318$:
      006E86 BF 41 02         [24] 3700 	cjne	r7,#0x41,00319$
      006E89 80 0D            [24] 3701 	sjmp	00121$
      006E8B                       3702 00319$:
      006E8B BF 42 02         [24] 3703 	cjne	r7,#0x42,00320$
      006E8E 80 08            [24] 3704 	sjmp	00121$
      006E90                       3705 00320$:
      006E90 BF 43 02         [24] 3706 	cjne	r7,#0x43,00321$
      006E93 80 03            [24] 3707 	sjmp	00121$
      006E95                       3708 00321$:
      006E95 BF 44 04         [24] 3709 	cjne	r7,#0x44,00122$
                                   3710 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006E98                       3711 00121$:
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006E98 75 82 01         [24] 3713 	mov	dpl, #0x01
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006E9B 22               [24] 3715 	ret
      006E9C                       3716 00122$:
      006E9C 75 82 00         [24] 3717 	mov	dpl, #0x00
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006E9F 22               [24] 3719 	ret
      006EA0                       3720 00124$:
                                   3721 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006EA0 12 71 27         [24] 3722 	lcall	_ak820_outline_0167
      006EA3 24 F2            [12] 3723 	add	a,#0xff - 0x0d
      006EA5 40 4A            [24] 3724 	jc	00142$
                                   3725 ;	free result
      006EA7 EF               [12] 3726 	mov	a,r7
      006EA8 24 0A            [12] 3727 	add	a,#(00325$-3-.)
      006EAA 83               [24] 3728 	movc	a,@a+pc
      006EAB F5 82            [12] 3729 	mov	dpl,a
      006EAD EF               [12] 3730 	mov	a,r7
      006EAE 24 12            [12] 3731 	add	a,#(00326$-3-.)
      006EB0 83               [24] 3732 	movc	a,@a+pc
      006EB1 F5 83            [12] 3733 	mov	dph,a
      006EB3 E4               [12] 3734 	clr	a
      006EB4 73               [24] 3735 	jmp	@a+dptr
      006EB5                       3736 00325$:
      006EB5 D1                    3737 	.db	00134$
      006EB6 D1                    3738 	.db	00134$
      006EB7 D1                    3739 	.db	00134$
      006EB8 D1                    3740 	.db	00134$
      006EB9 F1                    3741 	.db	00142$
      006EBA D1                    3742 	.db	00134$
      006EBB D1                    3743 	.db	00134$
      006EBC D1                    3744 	.db	00134$
      006EBD D1                    3745 	.db	00134$
      006EBE D1                    3746 	.db	00134$
      006EBF D1                    3747 	.db	00134$
      006EC0 F1                    3748 	.db	00142$
      006EC1 F1                    3749 	.db	00142$
      006EC2 D5                    3750 	.db	00135$
      006EC3                       3751 00326$:
      006EC3 6E                    3752 	.db	00134$>>8
      006EC4 6E                    3753 	.db	00134$>>8
      006EC5 6E                    3754 	.db	00134$>>8
      006EC6 6E                    3755 	.db	00134$>>8
      006EC7 6E                    3756 	.db	00142$>>8
      006EC8 6E                    3757 	.db	00134$>>8
      006EC9 6E                    3758 	.db	00134$>>8
      006ECA 6E                    3759 	.db	00134$>>8
      006ECB 6E                    3760 	.db	00134$>>8
      006ECC 6E                    3761 	.db	00134$>>8
      006ECD 6E                    3762 	.db	00134$>>8
      006ECE 6E                    3763 	.db	00142$>>8
      006ECF 6E                    3764 	.db	00142$>>8
      006ED0 6E                    3765 	.db	00135$>>8
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006ED1                       3767 00134$:
                                   3768 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006ED1 75 82 01         [24] 3769 	mov	dpl, #0x01
                                   3770 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006ED4 22               [24] 3771 	ret
      006ED5                       3772 00135$:
                                   3773 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006ED5 90 07 9C         [24] 3774 	mov	dptr,#(_raw_buffer + 0x0002)
      006ED8 E0               [24] 3775 	movx	a,@dptr
      006ED9 FF               [12] 3776 	mov	r7,a
      006EDA 60 0D            [24] 3777 	jz	00139$
      006EDC BF 01 02         [24] 3778 	cjne	r7,#0x01,00328$
      006EDF 80 08            [24] 3779 	sjmp	00139$
      006EE1                       3780 00328$:
      006EE1 BF 03 02         [24] 3781 	cjne	r7,#0x03,00329$
      006EE4 80 03            [24] 3782 	sjmp	00139$
      006EE6                       3783 00329$:
      006EE6 BF 05 04         [24] 3784 	cjne	r7,#0x05,00140$
                                   3785 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006EE9                       3786 00139$:
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006EE9 75 82 01         [24] 3788 	mov	dpl, #0x01
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006EEC 22               [24] 3790 	ret
      006EED                       3791 00140$:
      006EED 75 82 00         [24] 3792 	mov	dpl, #0x00
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006EF0 22               [24] 3794 	ret
      006EF1                       3795 00142$:
      006EF1 75 82 00         [24] 3796 	mov	dpl, #0x00
                                   3797 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006EF4 22               [24] 3798 	ret
      006EF5                       3799 00144$:
      006EF5 75 82 00         [24] 3800 	mov	dpl, #0x00
                                   3801 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3802 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006EF8 22               [24] 3803 	ret
                                   3804 ;------------------------------------------------------------
                                   3805 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3806 ;------------------------------------------------------------
                                   3807 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3808 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3809 ;------------------------------------------------------------
                                   3810 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3811 ;	-----------------------------------------
                                   3812 ;	 function ak820_usb_raw_send
                                   3813 ;	-----------------------------------------
      006EF9                       3814 _ak820_usb_raw_send:
      006EF9 12 45 7B         [24] 3815 	lcall	_ak820_outline_0036
      006EFC 90 08 08         [24] 3816 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006EFF 12 3A 8D         [24] 3817 	lcall	_ak820_outline_0016
                                   3818 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006F02 90 08 07         [24] 3819 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006F05 E0               [24] 3820 	movx	a,@dptr
      006F06 FF               [12] 3821 	mov	r7,a
      006F07 BF 20 2B         [24] 3822 	cjne	r7,#0x20,00106$
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006F0A C0 07            [24] 3824 	push	ar7
      006F0C 12 40 97         [24] 3825 	lcall	_ak820_nvm_flush
      006F0F D0 07            [24] 3826 	pop	ar7
                                   3827 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006F11 90 07 BA         [24] 3828 	mov	dptr,#_raw_reply_without_nvm
      006F14 E0               [24] 3829 	movx	a,@dptr
      006F15 70 07            [24] 3830 	jnz	00103$
      006F17 12 40 88         [24] 3831 	lcall	_ak820_nvm_ok
      006F1A E5 82            [12] 3832 	mov	a, dpl
      006F1C 60 17            [24] 3833 	jz	00106$
      006F1E                       3834 00103$:
      006F1E 90 08 08         [24] 3835 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006F21 12 3A D8         [24] 3836 	lcall	_ak820_outline_0080
      006F24 90 07 FD         [24] 3837 	mov	dptr,#_ak820_usb_send_PARM_2
      006F27 12 45 EC         [24] 3838 	lcall	_ak820_outline_0165
      006F2A 90 07 FF         [24] 3839 	mov	dptr,#_ak820_usb_send_PARM_3
      006F2D EF               [12] 3840 	mov	a,r7
      006F2E F0               [24] 3841 	movx	@dptr,a
      006F2F 75 82 03         [24] 3842 	mov	dpl, #0x03
                                   3843 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006F32 02 6C 03         [24] 3844 	ljmp	_ak820_usb_send
      006F35                       3845 00106$:
      006F35 22               [24] 3846 	ret
                                   3847 ;------------------------------------------------------------
                                   3848 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3849 ;------------------------------------------------------------
                                   3850 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3851 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3852 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3853 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3854 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3855 ;------------------------------------------------------------
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3857 ;	-----------------------------------------
                                   3858 ;	 function ak820_usb_raw_task
                                   3859 ;	-----------------------------------------
      006F36                       3860 _ak820_usb_raw_task:
                                   3861 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006F36 A2 AF            [12] 3862 	mov	c,_EA
      006F38 E4               [12] 3863 	clr	a
      006F39 33               [12] 3864 	rlc	a
      006F3A FF               [12] 3865 	mov	r7,a
                                   3866 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3867 ;	assignBit
      006F3B C2 AF            [12] 3868 	clr	_EA
                                   3869 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006F3D 90 07 92         [24] 3870 	mov	dptr,#_USB_EnumStatus
      006F40 E0               [24] 3871 	movx	a,@dptr
      006F41 60 0A            [24] 3872 	jz	00101$
      006F43 90 07 99         [24] 3873 	mov	dptr,#_raw_state
      006F46 E0               [24] 3874 	movx	a,@dptr
      006F47 FE               [12] 3875 	mov	r6,a
      006F48 BE 02 02         [24] 3876 	cjne	r6,#0x02,00270$
      006F4B 80 06            [24] 3877 	sjmp	00102$
      006F4D                       3878 00270$:
      006F4D                       3879 00101$:
                                   3880 ;	assignBit
      006F4D EF               [12] 3881 	mov	a,r7
      006F4E 24 FF            [12] 3882 	add	a,#0xff
      006F50 92 AF            [24] 3883 	mov	_EA,c
      006F52 22               [24] 3884 	ret
      006F53                       3885 00102$:
                                   3886 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006F53 90 07 99         [24] 3887 	mov	dptr,#_raw_state
      006F56 74 03            [12] 3888 	mov	a,#0x03
      006F58 F0               [24] 3889 	movx	@dptr,a
                                   3890 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3891 ;	assignBit
      006F59 EF               [12] 3892 	mov	a,r7
      006F5A 24 FF            [12] 3893 	add	a,#0xff
      006F5C 92 AF            [24] 3894 	mov	_EA,c
                                   3895 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006F5E 90 07 9A         [24] 3896 	mov	dptr,#_raw_buffer
      006F61 E0               [24] 3897 	movx	a,@dptr
      006F62 FF               [12] 3898 	mov	r7,a
      006F63 E4               [12] 3899 	clr	a
      006F64 BF FD 01         [24] 3900 	cjne	r7,#0xfd,00271$
      006F67 04               [12] 3901 	inc	a
      006F68                       3902 00271$:
      006F68 FF               [12] 3903 	mov	r7,a
      006F69 70 03            [24] 3904 	jnz	00273$
      006F6B 02 70 0B         [24] 3905 	ljmp	00118$
      006F6E                       3906 00273$:
      006F6E 90 07 9B         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0001)
      006F71 E0               [24] 3908 	movx	a,@dptr
      006F72 60 03            [24] 3909 	jz	00274$
      006F74 02 70 0B         [24] 3910 	ljmp	00118$
      006F77                       3911 00274$:
                                   3912 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006F77 90 07 9C         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0002)
      006F7A E0               [24] 3914 	movx	a,@dptr
      006F7B FD               [12] 3915 	mov	r5,a
      006F7C 7E 00            [12] 3916 	mov	r6,#0x00
      006F7E 90 07 9D         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0003)
      006F81 E0               [24] 3918 	movx	a,@dptr
      006F82 7B 00            [12] 3919 	mov	r3,#0x00
      006F84 42 06            [12] 3920 	orl	ar6,a
      006F86 EB               [12] 3921 	mov	a,r3
      006F87 42 05            [12] 3922 	orl	ar5,a
                                   3923 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006F89 90 07 9E         [24] 3924 	mov	dptr,#(_raw_buffer + 0x0004)
      006F8C E0               [24] 3925 	movx	a,@dptr
      006F8D FC               [12] 3926 	mov	r4,a
                                   3927 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F8E 7B 05            [12] 3928 	mov	r3,#0x05
      006F90                       3929 00128$:
      006F90 EB               [12] 3930 	mov	a,r3
      006F91 12 71 15         [24] 3931 	lcall	_ak820_outline_0104
      006F94 0B               [12] 3932 	inc	r3
      006F95 BB 20 00         [24] 3933 	cjne	r3,#0x20,00275$
      006F98                       3934 00275$:
      006F98 40 F6            [24] 3935 	jc	00128$
                                   3936 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006F9A EC               [12] 3937 	mov	a,r4
      006F9B 24 E4            [12] 3938 	add	a,#0xff - 0x1b
      006F9D 40 1C            [24] 3939 	jc	00106$
                                   3940 ;	free result
      006F9F EC               [12] 3941 	mov	a,r4
      006FA0 60 26            [24] 3942 	jz	00165$
      006FA2 8C 03            [24] 3943 	mov	ar3,r4
      006FA4 1B               [12] 3944 	dec	r3
      006FA5 7A 00            [12] 3945 	mov	r2,#0x00
      006FA7 74 FF            [12] 3946 	mov	a,#0xff
      006FA9 C3               [12] 3947 	clr	c
      006FAA 9B               [12] 3948 	subb	a,r3
      006FAB FB               [12] 3949 	mov	r3,a
      006FAC 74 FF            [12] 3950 	mov	a,#0xff
      006FAE 9A               [12] 3951 	subb	a,r2
      006FAF FA               [12] 3952 	mov	r2,a
      006FB0 8E 00            [24] 3953 	mov	ar0,r6
      006FB2 8D 01            [24] 3954 	mov	ar1,r5
      006FB4 C3               [12] 3955 	clr	c
      006FB5 EB               [12] 3956 	mov	a,r3
      006FB6 98               [12] 3957 	subb	a,r0
      006FB7 EA               [12] 3958 	mov	a,r2
      006FB8 99               [12] 3959 	subb	a,r1
      006FB9 50 0D            [24] 3960 	jnc	00165$
                                   3961 ;	free result
      006FBB                       3962 00106$:
                                   3963 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006FBB 90 07 9B         [24] 3964 	mov	dptr,#(_raw_buffer + 0x0001)
      006FBE 74 FF            [12] 3965 	mov	a,#0xff
      006FC0 F0               [24] 3966 	movx	@dptr,a
                                   3967 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006FC1 90 07 9E         [24] 3968 	mov	dptr,#(_raw_buffer + 0x0004)
      006FC4 E4               [12] 3969 	clr	a
      006FC5 F0               [24] 3970 	movx	@dptr,a
                                   3971 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006FC6 80 3A            [24] 3972 	sjmp	00108$
      006FC8                       3973 00165$:
      006FC8 7B 00            [12] 3974 	mov	r3,#0x00
      006FCA                       3975 00131$:
      006FCA C3               [12] 3976 	clr	c
      006FCB EB               [12] 3977 	mov	a,r3
      006FCC 9C               [12] 3978 	subb	a,r4
      006FCD 50 33            [24] 3979 	jnc	00108$
      006FCF C0 04            [24] 3980 	push	ar4
      006FD1 8B 02            [24] 3981 	mov	ar2,r3
      006FD3 74 05            [12] 3982 	mov	a,#0x05
      006FD5 2A               [12] 3983 	add	a, r2
      006FD6 F9               [12] 3984 	mov	r1,a
      006FD7 33               [12] 3985 	rlc	a
      006FD8 95 E0            [12] 3986 	subb	a,acc
      006FDA FA               [12] 3987 	mov	r2,a
      006FDB E9               [12] 3988 	mov	a,r1
      006FDC 24 9A            [12] 3989 	add	a, #_raw_buffer
      006FDE F9               [12] 3990 	mov	r1,a
      006FDF EA               [12] 3991 	mov	a,r2
      006FE0 34 07            [12] 3992 	addc	a, #(_raw_buffer >> 8)
      006FE2 FA               [12] 3993 	mov	r2,a
      006FE3 8B 1E            [24] 3994 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006FE5 75 1F 00         [24] 3995 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006FE8 8E 00            [24] 3996 	mov	ar0,r6
      006FEA 8D 04            [24] 3997 	mov	ar4,r5
      006FEC E5 1E            [12] 3998 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006FEE 28               [12] 3999 	add	a, r0
      006FEF F8               [12] 4000 	mov	r0,a
      006FF0 E5 1F            [12] 4001 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006FF2 3C               [12] 4002 	addc	a, r4
      006FF3 FC               [12] 4003 	mov	r4,a
      006FF4 88 82            [24] 4004 	mov	dpl,r0
      006FF6 8C 83            [24] 4005 	mov	dph,r4
      006FF8 E4               [12] 4006 	clr	a
      006FF9 93               [24] 4007 	movc	a,@a+dptr
      006FFA 12 71 21         [24] 4008 	lcall	_ak820_outline_0137
      006FFD 0B               [12] 4009 	inc	r3
      006FFE D0 04            [24] 4010 	pop	ar4
      007000 80 C8            [24] 4011 	sjmp	00131$
      007002                       4012 00108$:
                                   4013 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007002 12 71 01         [24] 4014 	lcall	_ak820_outline_0045
      007005 12 6C 03         [24] 4015 	lcall	_ak820_usb_send
      007008 02 70 B1         [24] 4016 	ljmp	00119$
      00700B                       4017 00118$:
                                   4018 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      00700B EF               [12] 4019 	mov	a,r7
      00700C 70 03            [24] 4020 	jnz	00281$
      00700E 02 70 8E         [24] 4021 	ljmp	00114$
      007011                       4022 00281$:
      007011 12 71 27         [24] 4023 	lcall	_ak820_outline_0167
      007014 BF 01 02         [24] 4024 	cjne	r7,#0x01,00282$
      007017 80 03            [24] 4025 	sjmp	00283$
      007019                       4026 00282$:
      007019 02 70 8E         [24] 4027 	ljmp	00114$
      00701C                       4028 00283$:
                                   4029 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00701C 7F 02            [12] 4030 	mov	r7,#0x02
      00701E                       4031 00133$:
      00701E EF               [12] 4032 	mov	a,r7
      00701F 12 71 15         [24] 4033 	lcall	_ak820_outline_0104
      007022 0F               [12] 4034 	inc	r7
      007023 BF 20 00         [24] 4035 	cjne	r7,#0x20,00284$
      007026                       4036 00284$:
      007026 40 F6            [24] 4037 	jc	00133$
                                   4038 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      007028 90 07 9C         [24] 4039 	mov	dptr,#(_raw_buffer + 0x0002)
      00702B 74 01            [12] 4040 	mov	a,#0x01
      00702D F0               [24] 4041 	movx	@dptr,a
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      00702E 90 07 9D         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0003)
      007031 74 A8            [12] 4044 	mov	a,#0xa8
      007033 F0               [24] 4045 	movx	@dptr,a
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      007034 90 07 9E         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0004)
      007037 12 3E 05         [24] 4048 	lcall	_ak820_nvm_diagnostic
                                   4049 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      00703A 7F 00            [12] 4050 	mov	r7,#0x00
      00703C                       4051 00135$:
      00703C 8F 06            [24] 4052 	mov	ar6,r7
      00703E 74 0B            [12] 4053 	mov	a,#0x0b
      007040 2E               [12] 4054 	add	a, r6
      007041 24 9A            [12] 4055 	add	a,#_raw_buffer
      007043 FE               [12] 4056 	mov	r6,a
      007044 E4               [12] 4057 	clr	a
      007045 34 07            [12] 4058 	addc	a, #(_raw_buffer >> 8)
      007047 FD               [12] 4059 	mov	r5,a
      007048 EF               [12] 4060 	mov	a,r7
      007049 24 74            [12] 4061 	add	a, #_ak820_flash_diagnostic
      00704B F5 82            [12] 4062 	mov	dpl,a
      00704D E4               [12] 4063 	clr	a
      00704E 34 04            [12] 4064 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007050 F5 83            [12] 4065 	mov	dph,a
      007052 E0               [24] 4066 	movx	a,@dptr
      007053 8E 82            [24] 4067 	mov	dpl,r6
      007055 8D 83            [24] 4068 	mov	dph,r5
      007057 F0               [24] 4069 	movx	@dptr,a
      007058 0F               [12] 4070 	inc	r7
      007059 BF 06 00         [24] 4071 	cjne	r7,#0x06,00286$
      00705C                       4072 00286$:
      00705C 40 DE            [24] 4073 	jc	00135$
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      00705E 90 0E 54         [24] 4075 	mov	dptr,#_vial_unlocked
      007061 E0               [24] 4076 	movx	a,@dptr
      007062 90 07 AB         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0011)
      007065 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      007066 90 0E 55         [24] 4080 	mov	dptr,#_vial_unlock_in_progress
      007069 E0               [24] 4081 	movx	a,@dptr
      00706A 90 07 AC         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0012)
      00706D F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      00706E 90 07 92         [24] 4085 	mov	dptr,#_USB_EnumStatus
      007071 E0               [24] 4086 	movx	a,@dptr
      007072 90 07 AD         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0013)
      007075 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      007076 90 07 93         [24] 4090 	mov	dptr,#_USB_SleepStatus
      007079 E0               [24] 4091 	movx	a,@dptr
      00707A 90 07 AE         [24] 4092 	mov	dptr,#(_raw_buffer + 0x0014)
      00707D F0               [24] 4093 	movx	@dptr,a
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      00707E 90 07 99         [24] 4095 	mov	dptr,#_raw_state
      007081 E0               [24] 4096 	movx	a,@dptr
      007082 90 07 AF         [24] 4097 	mov	dptr,#(_raw_buffer + 0x0015)
      007085 F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007086 12 71 01         [24] 4100 	lcall	_ak820_outline_0045
      007089 12 6C 03         [24] 4101 	lcall	_ak820_usb_send
      00708C 80 23            [24] 4102 	sjmp	00119$
      00708E                       4103 00114$:
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      00708E 12 6E 1E         [24] 4105 	lcall	_raw_request_is_nonpersistent
      007091 E5 82            [12] 4106 	mov	a, dpl
      007093 90 07 BA         [24] 4107 	mov	dptr,#_raw_reply_without_nvm
      007096 F0               [24] 4108 	movx	@dptr,a
                                   4109 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      007097 12 41 EA         [24] 4110 	lcall	_ak820_nvm_begin
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      00709A 90 0C 85         [24] 4112 	mov	dptr,#_raw_hid_receive_PARM_2
      00709D 74 20            [12] 4113 	mov	a,#0x20
      00709F F0               [24] 4114 	movx	@dptr,a
      0070A0 90 07 9A         [24] 4115 	mov	dptr,#_raw_buffer
      0070A3 75 F0 00         [24] 4116 	mov	b, #0x00
      0070A6 12 AB 34         [24] 4117 	lcall	_raw_hid_receive
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      0070A9 12 41 FF         [24] 4119 	lcall	_ak820_nvm_end
                                   4120 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      0070AC 90 07 BA         [24] 4121 	mov	dptr,#_raw_reply_without_nvm
      0070AF E4               [12] 4122 	clr	a
      0070B0 F0               [24] 4123 	movx	@dptr,a
      0070B1                       4124 00119$:
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4126 ;	assignBit
      0070B1 A2 AF            [12] 4127 	mov	c,_EA
      0070B3 92 1E            [24] 4128 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4129 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4130 ;	assignBit
      0070B5 C2 AF            [12] 4131 	clr	_EA
                                   4132 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0070B7 12 71 2D         [24] 4133 	lcall	_ak820_outline_0169
      0070BA BF 04 08         [24] 4134 	cjne	r7,#0x04,00126$
      0070BD 90 07 99         [24] 4135 	mov	dptr,#_raw_state
      0070C0 74 05            [12] 4136 	mov	a,#0x05
      0070C2 F0               [24] 4137 	movx	@dptr,a
      0070C3 80 1B            [24] 4138 	sjmp	00127$
      0070C5                       4139 00126$:
                                   4140 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      0070C5 12 71 2D         [24] 4141 	lcall	_ak820_outline_0169
      0070C8 BF 03 02         [24] 4142 	cjne	r7,#0x03,00290$
      0070CB 80 0E            [24] 4143 	sjmp	00121$
      0070CD                       4144 00290$:
      0070CD 12 71 2D         [24] 4145 	lcall	_ak820_outline_0169
      0070D0 BF 06 02         [24] 4146 	cjne	r7,#0x06,00291$
      0070D3 80 06            [24] 4147 	sjmp	00121$
      0070D5                       4148 00291$:
      0070D5 12 71 2D         [24] 4149 	lcall	_ak820_outline_0169
      0070D8 BF 07 05         [24] 4150 	cjne	r7,#0x07,00127$
      0070DB                       4151 00121$:
      0070DB 90 07 99         [24] 4152 	mov	dptr,#_raw_state
      0070DE E4               [12] 4153 	clr	a
      0070DF F0               [24] 4154 	movx	@dptr,a
      0070E0                       4155 00127$:
                                   4156 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4157 ;	assignBit
      0070E0 A2 1E            [12] 4158 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0070E2 92 AF            [24] 4159 	mov	_EA,c
                                   4160 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      0070E4 22               [24] 4161 	ret
                                   4162 ;------------------------------------------------------------
                                   4163 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4164 ;------------------------------------------------------------
                                   4165 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_483'
                                   4166 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_483'
                                   4167 ;------------------------------------------------------------
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:664: bool ak820_usb_take_keyboard_reset(void) {
                                   4169 ;	-----------------------------------------
                                   4170 ;	 function ak820_usb_take_keyboard_reset
                                   4171 ;	-----------------------------------------
      0070E5                       4172 _ak820_usb_take_keyboard_reset:
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:666: uint8_t saved_ea = EA;
                                   4174 ;	assignBit
      0070E5 A2 AF            [12] 4175 	mov	c,_EA
      0070E7 92 1F            [24] 4176 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:667: EA = 0;
                                   4178 ;	assignBit
      0070E9 C2 AF            [12] 4179 	clr	_EA
                                   4180 ;	tmk_core/protocol/ch555/usb_ak820.c:668: result = keyboard_reset;
      0070EB 90 07 BB         [24] 4181 	mov	dptr,#_keyboard_reset
      0070EE E0               [24] 4182 	movx	a,@dptr
      0070EF FF               [12] 4183 	mov	r7,a
                                   4184 ;	tmk_core/protocol/ch555/usb_ak820.c:669: keyboard_reset = 0;
      0070F0 E4               [12] 4185 	clr	a
      0070F1 F0               [24] 4186 	movx	@dptr,a
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:670: EA = saved_ea;
                                   4188 ;	assignBit
      0070F2 A2 1F            [12] 4189 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      0070F4 92 AF            [24] 4190 	mov	_EA,c
                                   4191 ;	tmk_core/protocol/ch555/usb_ak820.c:671: return result != 0;
      0070F6 EF               [12] 4192 	mov	a,r7
      0070F7 B4 01 00         [24] 4193 	cjne	a,#0x01,00103$
      0070FA                       4194 00103$:
      0070FA B3               [12] 4195 	cpl	c
      0070FB 92 1F            [24] 4196 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0070FD 12 3B 1F         [24] 4197 	lcall	_ak820_outline_0160
                                   4198 ;	tmk_core/protocol/ch555/usb_ak820.c:672: }
      007100 22               [24] 4199 	ret
                                   4200 	.area CSEG    (CODE)
                                   4201 	.area CONST   (CODE)
                                   4202 	.area CONST   (CODE)
      00BDE1                       4203 _shared_offsets:
      00BDE1 00                    4204 	.db #0x00	; 0
      00BDE2 00                    4205 	.db #0x00	; 0
      00BDE3 28                    4206 	.db #0x28	; 40
      00BDE4 2E                    4207 	.db #0x2e	; 46
      00BDE5 31                    4208 	.db #0x31	; 49	'1'
      00BDE6 00                    4209 	.db #0x00	; 0
      00BDE7 08                    4210 	.db #0x08	; 8
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00BDE8                       4213 _shared_lengths:
      00BDE8 00                    4214 	.db #0x00	; 0
      00BDE9 00                    4215 	.db #0x00	; 0
      00BDEA 06                    4216 	.db #0x06	; 6
      00BDEB 03                    4217 	.db #0x03	; 3
      00BDEC 03                    4218 	.db #0x03	; 3
      00BDED 00                    4219 	.db #0x00	; 0
      00BDEE 20                    4220 	.db #0x20	; 32
                                   4221 	.area CSEG    (CODE)
                                   4222 	.area CONST   (CODE)
      00BDEF                       4223 _interface_descriptors:
      00BDEF 92 C3                 4224 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BDF1 DB C4                 4225 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BDF3 8E C4                 4226 	.byte _RawReport, (_RawReport >> 8)
      00BDF5 F4 C4                 4227 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BDF7 D7 C3                 4228 	.byte _SharedReport, (_SharedReport >> 8)
      00BDF9 0D C5                 4229 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4230 	.area CSEG    (CODE)
                                   4231 	.area XINIT   (CODE)
                                   4232 	.area CABS    (ABS,CODE)
                                   4233 
                                   4234 ; Experimental exact instruction outlining.
                                   4235 	.globl _ak820_outline_0016
                                   4236 	.globl _ak820_outline_0036
                                   4237 	.globl _ak820_outline_0045
                                   4238 	.globl _ak820_outline_0080
                                   4239 	.globl _ak820_outline_0104
                                   4240 	.globl _ak820_outline_0137
                                   4241 	.globl _ak820_outline_0160
                                   4242 	.globl _ak820_outline_0165
                                   4243 	.globl _ak820_outline_0167
                                   4244 	.globl _ak820_outline_0169
                                   4245 
                                   4246 	.area CSEG (CODE)
                                   4247 ; function ak820_outline_0045
      007101                       4248 _ak820_outline_0045:
      007101 90 07 FD         [24] 4249 	mov	dptr,#_ak820_usb_send_PARM_2
      007104 74 9A            [12] 4250 	mov	a,#_raw_buffer
      007106 F0               [24] 4251 	movx	@dptr,a
      007107 74 07            [12] 4252 	mov	a,#(_raw_buffer>>8)
      007109 A3               [24] 4253 	inc	dptr
      00710A F0               [24] 4254 	movx	@dptr,a
      00710B 90 07 FF         [24] 4255 	mov	dptr,#_ak820_usb_send_PARM_3
      00710E 74 20            [12] 4256 	mov	a,#0x20
      007110 F0               [24] 4257 	movx	@dptr,a
      007111 75 82 03         [24] 4258 	mov	dpl,#0x03
      007114 22               [24] 4259 	ret
                                   4260 
                                   4261 	.area CSEG (CODE)
                                   4262 ; function ak820_outline_0104
      007115                       4263 _ak820_outline_0104:
      007115 24 9A            [12] 4264 	add	a,#_raw_buffer
      007117 F5 82            [12] 4265 	mov	dpl,a
      007119 E4               [12] 4266 	clr	a
      00711A 34 07            [12] 4267 	addc	a,#(_raw_buffer>>8)
      00711C F5 83            [12] 4268 	mov	dph,a
      00711E E4               [12] 4269 	clr	a
      00711F F0               [24] 4270 	movx	@dptr,a
      007120 22               [24] 4271 	ret
                                   4272 
                                   4273 	.area CSEG (CODE)
                                   4274 ; function ak820_outline_0137
      007121                       4275 _ak820_outline_0137:
      007121 89 82            [24] 4276 	mov	dpl,r1
      007123 8A 83            [24] 4277 	mov	dph,r2
      007125 F0               [24] 4278 	movx	@dptr,a
      007126 22               [24] 4279 	ret
                                   4280 
                                   4281 	.area CSEG (CODE)
                                   4282 ; function ak820_outline_0167
      007127                       4283 _ak820_outline_0167:
      007127 90 07 9B         [24] 4284 	mov	dptr,#(_raw_buffer+0x0001)
      00712A E0               [24] 4285 	movx	a,@dptr
      00712B FF               [12] 4286 	mov	r7,a
      00712C 22               [24] 4287 	ret
                                   4288 
                                   4289 	.area CSEG (CODE)
                                   4290 ; function ak820_outline_0169
      00712D                       4291 _ak820_outline_0169:
      00712D 90 07 99         [24] 4292 	mov	dptr,#_raw_state
      007130 E0               [24] 4293 	movx	a,@dptr
      007131 FF               [12] 4294 	mov	r7,a
      007132 22               [24] 4295 	ret
