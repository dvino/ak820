                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00052D                        109 _page_data:
      00052D                        110 	.ds 64
      00056D                        111 _cached_page:
      00056D                        112 	.ds 1
      00056E                        113 _batch_depth:
      00056E                        114 	.ds 1
      00056F                        115 _first_failure_stage:
      00056F                        116 	.ds 1
      000570                        117 _nvm_fail_stage_10000_20:
      000570                        118 	.ds 1
      000571                        119 _ak820_nvm_diagnostic_out_10000_23:
      000571                        120 	.ds 2
      000573                        121 _crc_byte_PARM_2:
      000573                        122 	.ds 1
      000574                        123 _crc_byte_crc_10000_25:
      000574                        124 	.ds 2
      000576                        125 _page_crc_crc_10000_30:
      000576                        126 	.ds 2
      000578                        127 _write_page_address_10000_32:
      000578                        128 	.ds 2
      00057A                        129 _journal_header_valid_header_10000_39:
      00057A                        130 	.ds 2
      00057C                        131 _recover_journal_header_10000_46:
      00057C                        132 	.ds 9
      000585                        133 _ak820_nvm_flush_header_10000_62:
      000585                        134 	.ds 9
      00058E                        135 _ak820_nvm_flush_stage_10000_62:
      00058E                        136 	.ds 1
      00058F                        137 _load_page_page_10000_87:
      00058F                        138 	.ds 1
      000590                        139 _read_offset_offset_10000_93:
      000590                        140 	.ds 2
      000592                        141 _eeprom_read_byte_addr_10000_97:
      000592                        142 	.ds 3
      000595                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000595                        144 	.ds 3
      000598                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000598                        146 	.ds 2
      00059A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00059A                        148 	.ds 2
      00059C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00059C                        150 	.ds 2
      00059E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059E                        152 	.ds 3
      0005A1                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005A1                        154 	.ds 2
      0005A3                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005A3                        156 	.ds 2
      0005A5                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A5                        158 	.ds 3
      0005A8                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A8                        160 	.ds 2
      0005AA                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005AA                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DF1                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DF1 E5 82            [12]  215 	mov	a,dpl
      003DF3 90 05 70         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003DF6 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003DF7 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      003DFA 90 05 70         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003DFD E0               [24]  221 	movx	a,@dptr
      003DFE 90 05 6F         [24]  222 	mov	dptr,#_first_failure_stage
      003E01 F0               [24]  223 	movx	@dptr,a
      003E02                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E02 D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E04 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E05                        239 _ak820_nvm_diagnostic:
      003E05 12 3A F0         [24]  240 	lcall	_ak820_outline_0107
      003E08 90 05 71         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E0B 12 3A F5         [24]  242 	lcall	_ak820_outline_0108
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003E0E 90 05 71         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E11 12 3A AF         [24]  245 	lcall	_ak820_outline_0052
      003E14 A2 0C            [12]  246 	mov	c,_storage_failed
      003E16 E4               [12]  247 	clr	a
      003E17 33               [12]  248 	rlc	a
      003E18 12 3A FA         [24]  249 	lcall	_ak820_outline_0118
      003E1B 12 45 A6         [24]  250 	lcall	_ak820_outline_0079
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003E1E A3               [24]  252 	inc	dptr
      003E1F A2 0A            [12]  253 	mov	c,_page_valid
      003E21 E4               [12]  254 	clr	a
      003E22 33               [12]  255 	rlc	a
      003E23 12 45 73         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E26 A2 0B            [12]  258 	mov	c,_page_dirty
      003E28 E4               [12]  259 	clr	a
      003E29 33               [12]  260 	rlc	a
      003E2A F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E2B 74 03            [12]  263 	mov	a,#0x03
      003E2D 12 45 E6         [24]  264 	lcall	_ak820_outline_0164
      003E30 90 05 6E         [24]  265 	mov	dptr,#_batch_depth
      003E33 E0               [24]  266 	movx	a,@dptr
      003E34 12 3A FF         [24]  267 	lcall	_ak820_outline_0123
      003E37 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E38 74 04            [12]  270 	mov	a,#0x04
      003E3A 12 45 E6         [24]  271 	lcall	_ak820_outline_0164
      003E3D 90 05 6D         [24]  272 	mov	dptr,#_cached_page
      003E40 E0               [24]  273 	movx	a,@dptr
      003E41 12 3A FF         [24]  274 	lcall	_ak820_outline_0123
      003E44 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E45 12 45 69         [24]  277 	lcall	_ak820_outline_0011
      003E48 E4               [12]  278 	clr	a
      003E49 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E4A 74 06            [12]  281 	mov	a,#0x06
      003E4C 12 45 C9         [24]  282 	lcall	_ak820_outline_0135
      003E4F 90 05 6F         [24]  283 	mov	dptr,#_first_failure_stage
      003E52 E0               [24]  284 	movx	a,@dptr
      003E53 12 3A FA         [24]  285 	lcall	_ak820_outline_0118
      003E56 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E57 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E58                        300 _crc_byte:
      003E58 12 3A F0         [24]  301 	lcall	_ak820_outline_0107
      003E5B 90 05 74         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E5E 12 3A F5         [24]  303 	lcall	_ak820_outline_0108
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E61 90 05 73         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E64 E0               [24]  306 	movx	a,@dptr
      003E65 FF               [12]  307 	mov	r7,a
      003E66 7E 00            [12]  308 	mov	r6,#0x00
      003E68 90 05 74         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E6B E0               [24]  310 	movx	a,@dptr
      003E6C 6E               [12]  311 	xrl	a,r6
      003E6D F0               [24]  312 	movx	@dptr,a
      003E6E A3               [24]  313 	inc	dptr
      003E6F E0               [24]  314 	movx	a,@dptr
      003E70 6F               [12]  315 	xrl	a,r7
      003E71 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E72 7F 00            [12]  318 	mov	r7,#0x00
      003E74                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E74 90 05 74         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E77 12 3A D8         [24]  322 	lcall	_ak820_outline_0080
      003E7A 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E7D ED               [12]  324 	mov	a,r5
      003E7E 2D               [12]  325 	add	a,r5
      003E7F FB               [12]  326 	mov	r3,a
      003E80 EE               [12]  327 	mov	a,r6
      003E81 33               [12]  328 	rlc	a
      003E82 FC               [12]  329 	mov	r4,a
      003E83 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E86 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E89 80 06            [24]  332 	sjmp	00107$
      003E8B                        333 00106$:
      003E8B ED               [12]  334 	mov	a,r5
      003E8C 2D               [12]  335 	add	a,r5
      003E8D FB               [12]  336 	mov	r3,a
      003E8E EE               [12]  337 	mov	a,r6
      003E8F 33               [12]  338 	rlc	a
      003E90 FC               [12]  339 	mov	r4,a
      003E91                        340 00107$:
      003E91 90 05 74         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E94 12 3A DE         [24]  342 	lcall	_ak820_outline_0093
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E97 0F               [12]  344 	inc	r7
      003E98 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E9B 12 36 75         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003E9E 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003E9F                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003E9F 90 05 76         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003EA2 74 FF            [12]  363 	mov	a,#0xff
      003EA4 F0               [24]  364 	movx	@dptr,a
      003EA5 A3               [24]  365 	inc	dptr
      003EA6 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003EA7 7F 00            [12]  368 	mov	r7,#0x00
      003EA9                        369 00102$:
      003EA9 90 05 76         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003EAC 12 3A D8         [24]  371 	lcall	_ak820_outline_0080
      003EAF 12 45 B8         [24]  372 	lcall	_ak820_outline_0105
      003EB2 90 05 73         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003EB5 F0               [24]  374 	movx	@dptr,a
      003EB6 12 3B 09         [24]  375 	lcall	_ak820_outline_0133
      003EB9 C0 07            [24]  376 	push	ar7
      003EBB 12 3E 58         [24]  377 	lcall	_crc_byte
      003EBE AD 82            [24]  378 	mov	r5, dpl
      003EC0 AE 83            [24]  379 	mov	r6, dph
      003EC2 D0 07            [24]  380 	pop	ar7
      003EC4 90 05 76         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003EC7 12 45 EC         [24]  382 	lcall	_ak820_outline_0165
      003ECA 0F               [12]  383 	inc	r7
      003ECB BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003ECE 12 3B 09         [24]  386 	lcall	_ak820_outline_0133
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003ED1 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003ED2                        399 _write_page:
      003ED2 12 3A F0         [24]  400 	lcall	_ak820_outline_0107
      003ED5 90 05 78         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003ED8 12 3A F5         [24]  402 	lcall	_ak820_outline_0108
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EDB 90 05 78         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EDE 12 3A 62         [24]  405 	lcall	_ak820_outline_0005
      003EE1 C0 07            [24]  406 	push	ar7
      003EE3 C0 06            [24]  407 	push	ar6
      003EE5 12 3C 6A         [24]  408 	lcall	_ak820_flash_erase
      003EE8 E5 82            [12]  409 	mov	a, dpl
      003EEA D0 06            [24]  410 	pop	ar6
      003EEC D0 07            [24]  411 	pop	ar7
      003EEE 70 03            [24]  412 	jnz	00102$
      003EF0 F5 82            [12]  413 	mov	dpl,a
      003EF2 22               [24]  414 	ret
      003EF3                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003EF3 90 05 09         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003EF6 74 2D            [12]  418 	mov	a,#_page_data
      003EF8 F0               [24]  419 	movx	@dptr,a
      003EF9 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003EFB A3               [24]  421 	inc	dptr
      003EFC 12 45 A6         [24]  422 	lcall	_ak820_outline_0079
      003EFF 12 3D 7E         [24]  423 	lcall	_ak820_flash_program_page
      003F02 E5 82            [12]  424 	mov	a, dpl
      003F04 70 03            [24]  425 	jnz	00120$
      003F06 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F08 22               [24]  428 	ret
      003F09                        429 00120$:
      003F09 7F 00            [12]  430 	mov	r7,#0x00
      003F0B                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003F0B 8F 05            [24]  433 	mov	ar5,r7
      003F0D 7E 00            [12]  434 	mov	r6,#0x00
      003F0F 90 05 78         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003F12 12 3B 14         [24]  436 	lcall	_ak820_outline_0141
      003F15 ED               [12]  437 	mov	a,r5
      003F16 2B               [12]  438 	add	a, r3
      003F17 FB               [12]  439 	mov	r3,a
      003F18 EE               [12]  440 	mov	a,r6
      003F19 3C               [12]  441 	addc	a, r4
      003F1A FC               [12]  442 	mov	r4,a
      003F1B 12 36 75         [24]  443 	lcall	_ak820_outline_0122
      003F1E 12 3B 5D         [24]  444 	lcall	_ak820_flash_read
      003F21 AE 82            [24]  445 	mov	r6, dpl
      003F23 12 45 B8         [24]  446 	lcall	_ak820_outline_0105
      003F26 FD               [12]  447 	mov	r5,a
      003F27 EE               [12]  448 	mov	a,r6
      003F28 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F2B 80 04            [24]  450 	sjmp	00109$
      003F2D                        451 00149$:
      003F2D 75 82 00         [24]  452 	mov	dpl, #0x00
      003F30 22               [24]  453 	ret
      003F31                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F31 0F               [12]  456 	inc	r7
      003F32 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F35 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F38 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F39                        472 _journal_header_valid:
      003F39 12 3A F0         [24]  473 	lcall	_ak820_outline_0107
      003F3C 90 05 7A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F3F 12 3A F5         [24]  475 	lcall	_ak820_outline_0108
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F42 90 05 7A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F45 12 3A 62         [24]  478 	lcall	_ak820_outline_0005
      003F48 E0               [24]  479 	movx	a,@dptr
      003F49 FD               [12]  480 	mov	r5,a
      003F4A BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F4D 80 04            [24]  482 	sjmp	00116$
      003F4F                        483 00138$:
      003F4F 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F52 22               [24]  486 	ret
      003F53                        487 00116$:
      003F53 7D 01            [12]  488 	mov	r5,#0x01
      003F55                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F55 ED               [12]  491 	mov	a,r5
      003F56 12 3A 9F         [24]  492 	lcall	_ak820_outline_0022
      003F59 E0               [24]  493 	movx	a,@dptr
      003F5A FC               [12]  494 	mov	r4,a
      003F5B 8D 02            [24]  495 	mov	ar2,r5
      003F5D 7B 00            [12]  496 	mov	r3,#0x00
      003F5F 74 04            [12]  497 	mov	a,#0x04
      003F61 2A               [12]  498 	add	a, r2
      003F62 FA               [12]  499 	mov	r2,a
      003F63 E4               [12]  500 	clr	a
      003F64 3B               [12]  501 	addc	a, r3
      003F65 FB               [12]  502 	mov	r3,a
      003F66 EA               [12]  503 	mov	a,r2
      003F67 2E               [12]  504 	add	a, r6
      003F68 F5 82            [12]  505 	mov	dpl,a
      003F6A EB               [12]  506 	mov	a,r3
      003F6B 3F               [12]  507 	addc	a, r7
      003F6C F5 83            [12]  508 	mov	dph,a
      003F6E E0               [24]  509 	movx	a,@dptr
      003F6F 62 04            [12]  510 	xrl	ar4,a
      003F71 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003F74 80 04            [24]  512 	sjmp	00107$
      003F76                        513 00139$:
      003F76 75 82 00         [24]  514 	mov	dpl, #0x00
      003F79 22               [24]  515 	ret
      003F7A                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F7A 0D               [12]  518 	inc	r5
      003F7B BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F7E 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F81 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003F82                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F82 7F 00            [12]  538 	mov	r7,#0x00
      003F84                        539 00115$:
      003F84 EF               [12]  540 	mov	a,r7
      003F85 24 7C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003F87 FD               [12]  542 	mov	r5,a
      003F88 E4               [12]  543 	clr	a
      003F89 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F8B FE               [12]  545 	mov	r6,a
      003F8C 8F 04            [24]  546 	mov	ar4,r7
      003F8E 7B 00            [12]  547 	mov	r3,#0x00
      003F90 74 40            [12]  548 	mov	a,#0x40
      003F92 2C               [12]  549 	add	a, r4
      003F93 FC               [12]  550 	mov	r4,a
      003F94 74 EF            [12]  551 	mov	a,#0xef
      003F96 3B               [12]  552 	addc	a, r3
      003F97 FB               [12]  553 	mov	r3,a
      003F98 12 45 F7         [24]  554 	lcall	_ak820_outline_0189
      003F9B 12 3B 5D         [24]  555 	lcall	_ak820_flash_read
      003F9E AC 82            [24]  556 	mov	r4, dpl
      003FA0 12 45 9F         [24]  557 	lcall	_ak820_outline_0065
      003FA3 0F               [12]  558 	inc	r7
      003FA4 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003FA7 90 05 7C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003FAA 12 3F 39         [24]  562 	lcall	_journal_header_valid
      003FAD E5 82            [12]  563 	mov	a, dpl
      003FAF 70 01            [24]  564 	jnz	00103$
      003FB1 22               [24]  565 	ret
      003FB2                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003FB2 90 05 7D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003FB5 E0               [24]  569 	movx	a,@dptr
      003FB6 FF               [12]  570 	mov	r7,a
      003FB7 7E 00            [12]  571 	mov	r6,#0x00
      003FB9 90 05 7E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003FBC E0               [24]  573 	movx	a,@dptr
      003FBD FC               [12]  574 	mov	r4,a
      003FBE E4               [12]  575 	clr	a
      003FBF 42 07            [12]  576 	orl	ar7,a
      003FC1 EC               [12]  577 	mov	a,r4
      003FC2 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FC4 90 05 7F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FC7 E0               [24]  581 	movx	a,@dptr
      003FC8 FD               [12]  582 	mov	r5,a
      003FC9 7C 00            [12]  583 	mov	r4,#0x00
      003FCB 90 05 80         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FCE E0               [24]  585 	movx	a,@dptr
      003FCF FA               [12]  586 	mov	r2,a
      003FD0 E4               [12]  587 	clr	a
      003FD1 12 45 CF         [24]  588 	lcall	_ak820_outline_0143
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FD4 C3               [12]  590 	clr	c
      003FD5 EF               [12]  591 	mov	a,r7
      003FD6 94 A0            [12]  592 	subb	a,#0xa0
      003FD8 EE               [12]  593 	mov	a,r6
      003FD9 94 00            [12]  594 	subb	a,#0x00
      003FDB 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FDD 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FE0 02 3D F1         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FE3                        601 00134$:
      003FE3 7B 00            [12]  602 	mov	r3,#0x00
      003FE5                        603 00117$:
      003FE5 C0 05            [24]  604 	push	ar5
      003FE7 C0 04            [24]  605 	push	ar4
      003FE9 EB               [12]  606 	mov	a,r3
      003FEA 24 2D            [12]  607 	add	a, #_page_data
      003FEC F9               [12]  608 	mov	r1,a
      003FED E4               [12]  609 	clr	a
      003FEE 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003FF0 FA               [12]  611 	mov	r2,a
      003FF1 8B 00            [24]  612 	mov	ar0,r3
      003FF3 7D 00            [12]  613 	mov	r5,#0x00
      003FF5 74 EF            [12]  614 	mov	a,#0xef
      003FF7 2D               [12]  615 	add	a, r5
      003FF8 FD               [12]  616 	mov	r5,a
      003FF9 88 82            [24]  617 	mov	dpl, r0
      003FFB 8D 83            [24]  618 	mov	dph, r5
      003FFD 12 3B 5D         [24]  619 	lcall	_ak820_flash_read
      004000 AD 82            [24]  620 	mov	r5, dpl
      004002 12 45 F2         [24]  621 	lcall	_ak820_outline_0188
      004005 ED               [12]  622 	mov	a,r5
      004006 F0               [24]  623 	movx	@dptr,a
      004007 0B               [12]  624 	inc	r3
      004008 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      00400B 80 06            [24]  626 	sjmp	00191$
      00400D                        627 00190$:
      00400D D0 04            [24]  628 	pop	ar4
      00400F D0 05            [24]  629 	pop	ar5
      004011 80 D2            [24]  630 	sjmp	00117$
      004013                        631 00191$:
      004013 D0 04            [24]  632 	pop	ar4
      004015 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      004017 C0 07            [24]  635 	push	ar7
      004019 C0 06            [24]  636 	push	ar6
      00401B C0 05            [24]  637 	push	ar5
      00401D C0 04            [24]  638 	push	ar4
      00401F 12 3E 9F         [24]  639 	lcall	_page_crc
      004022 AA 82            [24]  640 	mov	r2, dpl
      004024 AB 83            [24]  641 	mov	r3, dph
      004026 D0 04            [24]  642 	pop	ar4
      004028 D0 05            [24]  643 	pop	ar5
      00402A D0 06            [24]  644 	pop	ar6
      00402C D0 07            [24]  645 	pop	ar7
      00402E EA               [12]  646 	mov	a,r2
      00402F B5 05 06         [24]  647 	cjne	a,ar5,00192$
      004032 EB               [12]  648 	mov	a,r3
      004033 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004036 80 06            [24]  650 	sjmp	00113$
      004038                        651 00192$:
      004038 75 82 02         [24]  652 	mov	dpl, #0x02
      00403B 02 3D F1         [24]  653 	ljmp	_nvm_fail
      00403E                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00403E EE               [12]  656 	mov	a,r6
      00403F 54 03            [12]  657 	anl	a,#0x03
      004041 A2 E0            [12]  658 	mov	c,acc.0
      004043 CF               [12]  659 	xch	a,r7
      004044 13               [12]  660 	rrc	a
      004045 CF               [12]  661 	xch	a,r7
      004046 13               [12]  662 	rrc	a
      004047 A2 E0            [12]  663 	mov	c,acc.0
      004049 CF               [12]  664 	xch	a,r7
      00404A 13               [12]  665 	rrc	a
      00404B CF               [12]  666 	xch	a,r7
      00404C 13               [12]  667 	rrc	a
      00404D CF               [12]  668 	xch	a,r7
      00404E 24 C7            [12]  669 	add	a,#0xc7
      004050 FE               [12]  670 	mov	r6,a
      004051 12 45 E1         [24]  671 	lcall	_ak820_outline_0162
      004054 12 3E D2         [24]  672 	lcall	_write_page
      004057 E5 82            [12]  673 	mov	a, dpl
      004059 70 06            [24]  674 	jnz	00110$
      00405B 75 82 03         [24]  675 	mov	dpl, #0x03
      00405E 02 3D F1         [24]  676 	ljmp	_nvm_fail
      004061                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004061 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004064 12 3C 6A         [24]  680 	lcall	_ak820_flash_erase
      004067 E5 82            [12]  681 	mov	a, dpl
      004069 70 06            [24]  682 	jnz	00119$
      00406B 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00406E 02 3D F1         [24]  685 	ljmp	_nvm_fail
      004071                        686 00119$:
      004071 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      004072                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      004072 C2 0C            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004074 90 05 6F         [24]  700 	mov	dptr,#_first_failure_stage
      004077 E4               [12]  701 	clr	a
      004078 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      004079 C2 0B            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      00407B C2 0A            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00407D 90 05 6E         [24]  709 	mov	dptr,#_batch_depth
      004080 E4               [12]  710 	clr	a
      004081 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004082 12 3F 82         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004085 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      004088                        724 _ak820_nvm_ok:
      004088 A2 0C            [12]  725 	mov	c,_storage_failed
      00408A B3               [12]  726 	cpl	c
      00408B 92 0D            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00408D 12 3B 1F         [24]  728 	lcall	_ak820_outline_0160
      004090 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      004091                        737 _ak820_nvm_schema_fault:
      004091 75 82 10         [24]  738 	mov	dpl, #0x10
      004094 02 3D F1         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      004097                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004097 30 0B 03         [24]  754 	jnb	_page_dirty,00101$
      00409A 30 0C 01         [24]  755 	jnb	_storage_failed,00102$
      00409D                        756 00101$:
      00409D 22               [24]  757 	ret
      00409E                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00409E 12 3E 9F         [24]  760 	lcall	_page_crc
      0040A1 12 45 C4         [24]  761 	lcall	_ak820_outline_0125
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0040A4 90 05 85         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0040A7 74 A5            [12]  764 	mov	a,#0xa5
      0040A9 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0040AA 90 05 6D         [24]  767 	mov	dptr,#_cached_page
      0040AD E0               [24]  768 	movx	a,@dptr
      0040AE 90 05 86         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0040B1 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0040B2 90 05 87         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0040B5 E4               [12]  773 	clr	a
      0040B6 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0040B7 8E 05            [24]  776 	mov	ar5,r6
      0040B9 90 05 88         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0040BC ED               [12]  778 	mov	a,r5
      0040BD F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0040BE 8F 06            [24]  781 	mov	ar6,r7
      0040C0 90 05 89         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040C3 EE               [12]  783 	mov	a,r6
      0040C4 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040C5 7F 01            [12]  786 	mov	r7,#0x01
      0040C7                        787 00128$:
      0040C7 8F 06            [24]  788 	mov	ar6,r7
      0040C9 EE               [12]  789 	mov	a,r6
      0040CA 24 04            [12]  790 	add	a,#0x04
      0040CC FE               [12]  791 	mov	r6,a
      0040CD 33               [12]  792 	rlc	a
      0040CE 95 E0            [12]  793 	subb	a,acc
      0040D0 FD               [12]  794 	mov	r5,a
      0040D1 EE               [12]  795 	mov	a,r6
      0040D2 24 85            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0040D4 FE               [12]  797 	mov	r6,a
      0040D5 ED               [12]  798 	mov	a,r5
      0040D6 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040D8 FD               [12]  800 	mov	r5,a
      0040D9 12 45 82         [24]  801 	lcall	_ak820_outline_0043
      0040DC FC               [12]  802 	mov	r4,a
      0040DD 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0040E0 8E 82            [24]  804 	mov	dpl,r6
      0040E2 8D 83            [24]  805 	mov	dph,r5
      0040E4 EC               [12]  806 	mov	a,r4
      0040E5 F0               [24]  807 	movx	@dptr,a
      0040E6 0F               [12]  808 	inc	r7
      0040E7 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040EA 90 05 8E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040ED 74 05            [12]  812 	mov	a,#0x05
      0040EF F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040F0 90 EF 40         [24]  815 	mov	dptr,#0xef40
      0040F3 12 3C 6A         [24]  816 	lcall	_ak820_flash_erase
      0040F6 E5 82            [12]  817 	mov	a, dpl
      0040F8 70 03            [24]  818 	jnz	00269$
      0040FA 02 41 E1         [24]  819 	ljmp	00127$
      0040FD                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      0040FD 90 05 8E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004100 74 06            [12]  823 	mov	a,#0x06
      004102 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004103 7F 00            [12]  826 	mov	r7,#0x00
      004105                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      004105 12 45 8E         [24]  829 	lcall	_ak820_outline_0053
      004108 12 3B 5D         [24]  830 	lcall	_ak820_flash_read
      00410B E5 82            [12]  831 	mov	a, dpl
      00410D 60 03            [24]  832 	jz	00270$
      00410F 02 41 E1         [24]  833 	ljmp	00127$
      004112                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004112 0F               [12]  836 	inc	r7
      004113 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      004116 90 05 8E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004119 74 07            [12]  840 	mov	a,#0x07
      00411B F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      00411C 90 EF 00         [24]  843 	mov	dptr,#0xef00
      00411F 12 3E D2         [24]  844 	lcall	_write_page
      004122 E5 82            [12]  845 	mov	a, dpl
      004124 70 03            [24]  846 	jnz	00273$
      004126 02 41 E1         [24]  847 	ljmp	00127$
      004129                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004129 90 05 8E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00412C 74 08            [12]  851 	mov	a,#0x08
      00412E F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00412F 7F 01            [12]  854 	mov	r7,#0x01
      004131                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004131 12 45 82         [24]  857 	lcall	_ak820_outline_0043
      004134 FE               [12]  858 	mov	r6,a
      004135 60 23            [24]  859 	jz	00133$
      004137 8F 05            [24]  860 	mov	ar5,r7
      004139 7C 00            [12]  861 	mov	r4,#0x00
      00413B 74 40            [12]  862 	mov	a,#0x40
      00413D 2D               [12]  863 	add	a, r5
      00413E FD               [12]  864 	mov	r5,a
      00413F 74 EF            [12]  865 	mov	a,#0xef
      004141 3C               [12]  866 	addc	a, r4
      004142 FC               [12]  867 	mov	r4,a
      004143 90 05 06         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004146 EE               [12]  869 	mov	a,r6
      004147 F0               [24]  870 	movx	@dptr,a
      004148 8D 82            [24]  871 	mov	dpl, r5
      00414A 8C 83            [24]  872 	mov	dph, r4
      00414C C0 07            [24]  873 	push	ar7
      00414E 12 3C CA         [24]  874 	lcall	_ak820_flash_program
      004151 E5 82            [12]  875 	mov	a, dpl
      004153 D0 07            [24]  876 	pop	ar7
      004155 70 03            [24]  877 	jnz	00275$
      004157 02 41 E1         [24]  878 	ljmp	00127$
      00415A                        879 00275$:
      00415A                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00415A 0F               [12]  882 	inc	r7
      00415B BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00415E 90 05 8E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004161 74 09            [12]  886 	mov	a,#0x09
      004163 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004164 7F 01            [12]  889 	mov	r7,#0x01
      004166                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004166 12 45 8E         [24]  892 	lcall	_ak820_outline_0053
      004169 12 3B 5D         [24]  893 	lcall	_ak820_flash_read
      00416C AE 82            [24]  894 	mov	r6, dpl
      00416E 12 45 82         [24]  895 	lcall	_ak820_outline_0043
      004171 FD               [12]  896 	mov	r5,a
      004172 EE               [12]  897 	mov	a,r6
      004173 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004176 0F               [12]  900 	inc	r7
      004177 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      00417A 90 05 8E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00417D 74 0A            [12]  904 	mov	a,#0x0a
      00417F F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004180 90 05 85         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004183 E0               [24]  908 	movx	a,@dptr
      004184 90 05 06         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      004187 F0               [24]  910 	movx	@dptr,a
      004188 90 EF 40         [24]  911 	mov	dptr,#0xef40
      00418B 12 3C CA         [24]  912 	lcall	_ak820_flash_program
      00418E E5 82            [12]  913 	mov	a, dpl
      004190 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004192 90 05 8E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004195 74 0B            [12]  917 	mov	a,#0x0b
      004197 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004198 90 EF 40         [24]  920 	mov	dptr,#0xef40
      00419B 12 3B 5D         [24]  921 	lcall	_ak820_flash_read
      00419E AF 82            [24]  922 	mov	r7, dpl
      0041A0 90 05 85         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0041A3 E0               [24]  924 	movx	a,@dptr
      0041A4 FE               [12]  925 	mov	r6,a
      0041A5 EF               [12]  926 	mov	a,r7
      0041A6 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0041A9 90 05 8E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041AC 74 0C            [12]  930 	mov	a,#0x0c
      0041AE F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0041AF 90 05 6D         [24]  933 	mov	dptr,#_cached_page
      0041B2 E0               [24]  934 	movx	a,@dptr
      0041B3 FE               [12]  935 	mov	r6,a
      0041B4 E4               [12]  936 	clr	a
      0041B5 C3               [12]  937 	clr	c
      0041B6 CE               [12]  938 	xch	a,r6
      0041B7 13               [12]  939 	rrc	a
      0041B8 CE               [12]  940 	xch	a,r6
      0041B9 13               [12]  941 	rrc	a
      0041BA A2 E0            [12]  942 	mov	c,acc.0
      0041BC CE               [12]  943 	xch	a,r6
      0041BD 13               [12]  944 	rrc	a
      0041BE CE               [12]  945 	xch	a,r6
      0041BF 13               [12]  946 	rrc	a
      0041C0 CE               [12]  947 	xch	a,r6
      0041C1 24 C7            [12]  948 	add	a,#0xc7
      0041C3 FF               [12]  949 	mov	r7,a
      0041C4 12 3A FA         [24]  950 	lcall	_ak820_outline_0118
      0041C7 12 3E D2         [24]  951 	lcall	_write_page
      0041CA E5 82            [12]  952 	mov	a, dpl
      0041CC 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041CE 90 05 8E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041D1 74 0D            [12]  956 	mov	a,#0x0d
      0041D3 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041D4 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0041D7 12 3C 6A         [24]  960 	lcall	_ak820_flash_erase
      0041DA E5 82            [12]  961 	mov	a, dpl
      0041DC 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0041DE C2 0B            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041E0 22               [24]  968 	ret
      0041E1                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041E1 90 05 8E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041E4 E0               [24]  972 	movx	a,@dptr
      0041E5 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041E7 02 3D F1         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0041EA                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041EA 90 05 6E         [24]  985 	mov	dptr,#_batch_depth
      0041ED E0               [24]  986 	movx	a,@dptr
      0041EE FF               [12]  987 	mov	r7,a
      0041EF BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      0041F2 75 82 0F         [24]  989 	mov	dpl, #0x0f
      0041F5 02 3D F1         [24]  990 	ljmp	_nvm_fail
      0041F8                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0041F8 90 05 6E         [24]  993 	mov	dptr,#_batch_depth
      0041FB EF               [12]  994 	mov	a,r7
      0041FC 04               [12]  995 	inc	a
      0041FD F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      0041FE 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      0041FF                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      0041FF 90 05 6E         [24] 1008 	mov	dptr,#_batch_depth
      004202 E0               [24] 1009 	movx	a,@dptr
      004203 FF               [12] 1010 	mov	r7,a
      004204 E0               [24] 1011 	movx	a,@dptr
      004205 60 06            [24] 1012 	jz	00102$
      004207 EF               [12] 1013 	mov	a,r7
      004208 14               [12] 1014 	dec	a
      004209 90 05 6E         [24] 1015 	mov	dptr,#_batch_depth
      00420C F0               [24] 1016 	movx	@dptr,a
      00420D                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00420D 90 05 6E         [24] 1019 	mov	dptr,#_batch_depth
      004210 E0               [24] 1020 	movx	a,@dptr
      004211 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004213 02 40 97         [24] 1023 	ljmp	_ak820_nvm_flush
      004216                       1024 00105$:
      004216 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      004217                       1036 _load_page:
      004217 E5 82            [12] 1037 	mov	a,dpl
      004219 90 05 8F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      00421C F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      00421D 30 0A 17         [24] 1041 	jnb	_page_valid,00102$
      004220 90 05 6D         [24] 1042 	mov	dptr,#_cached_page
      004223 E0               [24] 1043 	movx	a,@dptr
      004224 FF               [12] 1044 	mov	r7,a
      004225 90 05 8F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      004228 E0               [24] 1046 	movx	a,@dptr
      004229 FE               [12] 1047 	mov	r6,a
      00422A EF               [12] 1048 	mov	a,r7
      00422B B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      00422E A2 0C            [12] 1050 	mov	c,_storage_failed
      004230 B3               [12] 1051 	cpl	c
      004231 92 0E            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004233 12 3B 1F         [24] 1053 	lcall	_ak820_outline_0160
      004236 22               [24] 1054 	ret
      004237                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004237 12 40 97         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      00423A 30 0C 04         [24] 1059 	jnb	_storage_failed,00119$
      00423D 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004240 22               [24] 1062 	ret
      004241                       1063 00119$:
      004241 7F 00            [12] 1064 	mov	r7,#0x00
      004243                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004243 EF               [12] 1067 	mov	a,r7
      004244 24 2D            [12] 1068 	add	a, #_page_data
      004246 FD               [12] 1069 	mov	r5,a
      004247 E4               [12] 1070 	clr	a
      004248 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      00424A FE               [12] 1072 	mov	r6,a
      00424B 90 05 8F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00424E E0               [24] 1074 	movx	a,@dptr
      00424F FC               [12] 1075 	mov	r4,a
      004250 FA               [12] 1076 	mov	r2,a
      004251 E4               [12] 1077 	clr	a
      004252 C3               [12] 1078 	clr	c
      004253 CA               [12] 1079 	xch	a,r2
      004254 13               [12] 1080 	rrc	a
      004255 CA               [12] 1081 	xch	a,r2
      004256 13               [12] 1082 	rrc	a
      004257 A2 E0            [12] 1083 	mov	c,acc.0
      004259 CA               [12] 1084 	xch	a,r2
      00425A 13               [12] 1085 	rrc	a
      00425B CA               [12] 1086 	xch	a,r2
      00425C 13               [12] 1087 	rrc	a
      00425D CA               [12] 1088 	xch	a,r2
      00425E 24 C7            [12] 1089 	add	a,#0xc7
      004260 FB               [12] 1090 	mov	r3,a
      004261 8F 01            [24] 1091 	mov	ar1,r7
      004263 89 00            [24] 1092 	mov	ar0,r1
      004265 79 00            [12] 1093 	mov	r1,#0x00
      004267 E8               [12] 1094 	mov	a,r0
      004268 2A               [12] 1095 	add	a, r2
      004269 FA               [12] 1096 	mov	r2,a
      00426A E9               [12] 1097 	mov	a,r1
      00426B 3B               [12] 1098 	addc	a, r3
      00426C FB               [12] 1099 	mov	r3,a
      00426D 12 3B 1A         [24] 1100 	lcall	_ak820_outline_0144
      004270 12 3B 5D         [24] 1101 	lcall	_ak820_flash_read
      004273 AB 82            [24] 1102 	mov	r3, dpl
      004275 12 3B 09         [24] 1103 	lcall	_ak820_outline_0133
      004278 EB               [12] 1104 	mov	a,r3
      004279 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00427A 0F               [12] 1107 	inc	r7
      00427B BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00427E 90 05 6D         [24] 1110 	mov	dptr,#_cached_page
      004281 EC               [12] 1111 	mov	a,r4
      004282 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004283 D2 0A            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004285 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004288 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004289                       1129 _read_offset:
      004289 12 3A F0         [24] 1130 	lcall	_ak820_outline_0107
      00428C 90 05 90         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00428F 12 3A F5         [24] 1132 	lcall	_ak820_outline_0108
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004292 90 05 90         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004295 12 3A AF         [24] 1135 	lcall	_ak820_outline_0052
      004298 C3               [12] 1136 	clr	c
      004299 94 28            [12] 1137 	subb	a,#0x28
      00429B 40 04            [24] 1138 	jc	00102$
      00429D 75 82 00         [24] 1139 	mov	dpl, #0x00
      0042A0 22               [24] 1140 	ret
      0042A1                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0042A1 30 0A 34         [24] 1143 	jnb	_page_valid,00104$
      0042A4 8E 04            [24] 1144 	mov	ar4,r6
      0042A6 EF               [12] 1145 	mov	a,r7
      0042A7 A2 E7            [12] 1146 	mov	c,acc.7
      0042A9 CC               [12] 1147 	xch	a,r4
      0042AA 33               [12] 1148 	rlc	a
      0042AB CC               [12] 1149 	xch	a,r4
      0042AC 33               [12] 1150 	rlc	a
      0042AD A2 E7            [12] 1151 	mov	c,acc.7
      0042AF CC               [12] 1152 	xch	a,r4
      0042B0 33               [12] 1153 	rlc	a
      0042B1 CC               [12] 1154 	xch	a,r4
      0042B2 33               [12] 1155 	rlc	a
      0042B3 CC               [12] 1156 	xch	a,r4
      0042B4 54 03            [12] 1157 	anl	a,#0x03
      0042B6 FD               [12] 1158 	mov	r5,a
      0042B7 90 05 6D         [24] 1159 	mov	dptr,#_cached_page
      0042BA E0               [24] 1160 	movx	a,@dptr
      0042BB FA               [12] 1161 	mov	r2,a
      0042BC 7B 00            [12] 1162 	mov	r3,#0x00
      0042BE EC               [12] 1163 	mov	a,r4
      0042BF B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0042C2 ED               [12] 1165 	mov	a,r5
      0042C3 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042C6 74 3F            [12] 1168 	mov	a,#0x3f
      0042C8 5E               [12] 1169 	anl	a,r6
      0042C9 7D 00            [12] 1170 	mov	r5,#0x00
      0042CB 24 2D            [12] 1171 	add	a, #_page_data
      0042CD F5 82            [12] 1172 	mov	dpl,a
      0042CF ED               [12] 1173 	mov	a,r5
      0042D0 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0042D2 F5 83            [12] 1175 	mov	dph,a
      0042D4 E0               [24] 1176 	movx	a,@dptr
      0042D5 F5 82            [12] 1177 	mov	dpl,a
      0042D7 22               [24] 1178 	ret
      0042D8                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042D8 74 C7            [12] 1181 	mov	a,#0xc7
      0042DA 2F               [12] 1182 	add	a, r7
      0042DB FF               [12] 1183 	mov	r7,a
      0042DC 12 3A FA         [24] 1184 	lcall	_ak820_outline_0118
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042DF 02 3B 5D         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0042E2                       1196 _eeprom_read_byte:
      0042E2 C0 07            [24] 1197 	push	ar7
      0042E4 C0 06            [24] 1198 	push	ar6
      0042E6 12 45 7B         [24] 1199 	lcall	_ak820_outline_0036
      0042E9 90 05 92         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042EC 12 3A 8D         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042EF 90 05 92         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F2 12 3A 62         [24] 1204 	lcall	_ak820_outline_0005
      0042F5 C0 06            [24] 1205 	push	ar6
      0042F7 C0 05            [24] 1206 	push	ar5
      0042F9 C0 04            [24] 1207 	push	ar4
      0042FB C0 03            [24] 1208 	push	ar3
      0042FD C0 02            [24] 1209 	push	ar2
      0042FF C0 01            [24] 1210 	push	ar1
      004301 C0 00            [24] 1211 	push	ar0
      004303 12 42 89         [24] 1212 	lcall	_read_offset
      004306 AF 82            [24] 1213 	mov	r7, dpl
      004308 D0 00            [24] 1214 	pop	ar0
      00430A D0 01            [24] 1215 	pop	ar1
      00430C D0 02            [24] 1216 	pop	ar2
      00430E D0 03            [24] 1217 	pop	ar3
      004310 D0 04            [24] 1218 	pop	ar4
      004312 D0 05            [24] 1219 	pop	ar5
      004314 D0 06            [24] 1220 	pop	ar6
      004316 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004318 D0 06            [24] 1223 	pop	ar6
      00431A D0 07            [24] 1224 	pop	ar7
      00431C 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      00431D                       1239 _ak820_eeprom_read_block_xdata:
      00431D 12 3A F0         [24] 1240 	lcall	_ak820_outline_0107
      004320 90 05 9A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004323 12 3A F5         [24] 1242 	lcall	_ak820_outline_0108
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004326 90 05 95         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004329 12 3A AF         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00432C 90 05 9A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00432F 12 3A C6         [24] 1248 	lcall	_ak820_outline_0061
      004332 90 05 9C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004335 12 3A D2         [24] 1250 	lcall	_ak820_outline_0074
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004338 90 05 98         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00433B 12 3A C6         [24] 1253 	lcall	_ak820_outline_0061
      00433E                       1254 00103$:
      00433E 8C 02            [24] 1255 	mov	ar2,r4
      004340 8D 03            [24] 1256 	mov	ar3,r5
      004342 1C               [12] 1257 	dec	r4
      004343 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004346 1D               [12] 1259 	dec	r5
      004347                       1260 00130$:
      004347 EA               [12] 1261 	mov	a,r2
      004348 4B               [12] 1262 	orl	a,r3
      004349 60 57            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00434B 8E 02            [24] 1265 	mov	ar2,r6
      00434D 8F 03            [24] 1266 	mov	ar3,r7
      00434F 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004351 2B               [12] 1268 	add	a,r3
      004352 50 14            [24] 1269 	jnc	00102$
      004354 90 05 9C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004357 12 45 AC         [24] 1271 	lcall	_ak820_outline_0086
      00435A 12 3B 1A         [24] 1272 	lcall	_ak820_outline_0144
      00435D E4               [12] 1273 	clr	a
      00435E F0               [24] 1274 	movx	@dptr,a
      00435F 90 05 9C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004362 04               [12] 1276 	inc	a
      004363 12 45 DA         [24] 1277 	lcall	_ak820_outline_0152
      004366 80 D6            [24] 1278 	sjmp	00103$
      004368                       1279 00102$:
                                   1280 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004368 90 05 9C         [24] 1281 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00436B 12 45 AC         [24] 1282 	lcall	_ak820_outline_0086
      00436E 12 3A FA         [24] 1283 	lcall	_ak820_outline_0118
      004371 C0 07            [24] 1284 	push	ar7
      004373 C0 06            [24] 1285 	push	ar6
      004375 C0 05            [24] 1286 	push	ar5
      004377 C0 04            [24] 1287 	push	ar4
      004379 C0 03            [24] 1288 	push	ar3
      00437B C0 02            [24] 1289 	push	ar2
      00437D 12 42 89         [24] 1290 	lcall	_read_offset
      004380 A9 82            [24] 1291 	mov	r1, dpl
      004382 D0 02            [24] 1292 	pop	ar2
      004384 D0 03            [24] 1293 	pop	ar3
      004386 D0 04            [24] 1294 	pop	ar4
      004388 D0 05            [24] 1295 	pop	ar5
      00438A D0 06            [24] 1296 	pop	ar6
      00438C D0 07            [24] 1297 	pop	ar7
      00438E 12 3B 1A         [24] 1298 	lcall	_ak820_outline_0144
      004391 E9               [12] 1299 	mov	a,r1
      004392 F0               [24] 1300 	movx	@dptr,a
      004393 90 05 9C         [24] 1301 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004396 74 01            [12] 1302 	mov	a,#0x01
      004398 12 45 DA         [24] 1303 	lcall	_ak820_outline_0152
                                   1304 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00439B 0E               [12] 1305 	inc	r6
      00439C BE 00 9F         [24] 1306 	cjne	r6,#0x00,00103$
      00439F 0F               [12] 1307 	inc	r7
      0043A0 80 9C            [24] 1308 	sjmp	00103$
      0043A2                       1309 00106$:
                                   1310 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0043A2 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1316 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1317 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1318 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1319 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1320 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1321 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1322 ;------------------------------------------------------------
                                   1323 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1324 ;	-----------------------------------------
                                   1325 ;	 function ak820_eeprom_write_block_xdata
                                   1326 ;	-----------------------------------------
      0043A3                       1327 _ak820_eeprom_write_block_xdata:
      0043A3 12 3A F0         [24] 1328 	lcall	_ak820_outline_0107
      0043A6 90 05 A3         [24] 1329 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043A9 12 3A F5         [24] 1330 	lcall	_ak820_outline_0108
                                   1331 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043AC 90 05 9E         [24] 1332 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0043AF 12 3A AF         [24] 1333 	lcall	_ak820_outline_0052
                                   1334 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0043B2 90 05 A3         [24] 1335 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043B5 12 3A C6         [24] 1336 	lcall	_ak820_outline_0061
                                   1337 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0043B8 8E 02            [24] 1338 	mov	ar2,r6
      0043BA 8F 03            [24] 1339 	mov	ar3,r7
      0043BC C3               [12] 1340 	clr	c
      0043BD E4               [12] 1341 	clr	a
      0043BE 9A               [12] 1342 	subb	a,r2
      0043BF 74 28            [12] 1343 	mov	a,#0x28
      0043C1 9B               [12] 1344 	subb	a,r3
      0043C2 40 15            [24] 1345 	jc	00101$
                                   1346 ;	free result
      0043C4 E4               [12] 1347 	clr	a
      0043C5 C3               [12] 1348 	clr	c
      0043C6 9E               [12] 1349 	subb	a,r6
      0043C7 FA               [12] 1350 	mov	r2,a
      0043C8 74 28            [12] 1351 	mov	a,#0x28
      0043CA 9F               [12] 1352 	subb	a,r7
      0043CB FB               [12] 1353 	mov	r3,a
      0043CC 90 05 A1         [24] 1354 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043CF 12 3A EA         [24] 1355 	lcall	_ak820_outline_0101
      0043D2 C3               [12] 1356 	clr	c
      0043D3 EA               [12] 1357 	mov	a,r2
      0043D4 98               [12] 1358 	subb	a,r0
      0043D5 EB               [12] 1359 	mov	a,r3
      0043D6 99               [12] 1360 	subb	a,r1
      0043D7 50 06            [24] 1361 	jnc	00125$
                                   1362 ;	free result
      0043D9                       1363 00101$:
                                   1364 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043D9 75 82 0E         [24] 1365 	mov	dpl, #0x0e
                                   1366 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043DC 02 3D F1         [24] 1367 	ljmp	_nvm_fail
                                   1368 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043DF                       1369 00125$:
      0043DF 90 05 A1         [24] 1370 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043E2 12 45 AC         [24] 1371 	lcall	_ak820_outline_0086
      0043E5                       1372 00108$:
      0043E5 8A 00            [24] 1373 	mov	ar0,r2
      0043E7 8B 01            [24] 1374 	mov	ar1,r3
      0043E9 1A               [12] 1375 	dec	r2
      0043EA BA FF 01         [24] 1376 	cjne	r2,#0xff,00159$
      0043ED 1B               [12] 1377 	dec	r3
      0043EE                       1378 00159$:
      0043EE E8               [12] 1379 	mov	a,r0
      0043EF 49               [12] 1380 	orl	a,r1
      0043F0 70 03            [24] 1381 	jnz	00160$
      0043F2 02 44 7C         [24] 1382 	ljmp	00110$
      0043F5                       1383 00160$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0043F5 C0 02            [24] 1385 	push	ar2
      0043F7 C0 03            [24] 1386 	push	ar3
      0043F9 12 45 B2         [24] 1387 	lcall	_ak820_outline_0095
      0043FC F9               [12] 1388 	mov	r1,a
      0043FD A3               [24] 1389 	inc	dptr
      0043FE 12 45 D5         [24] 1390 	lcall	_ak820_outline_0151
                                   1391 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004401 8E 0C            [24] 1392 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004403 8F 0D            [24] 1393 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004405 A8 0C            [24] 1394 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004407 E5 0D            [12] 1395 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004409 A2 E7            [12] 1396 	mov	c,acc.7
      00440B C8               [12] 1397 	xch	a,r0
      00440C 33               [12] 1398 	rlc	a
      00440D C8               [12] 1399 	xch	a,r0
      00440E 33               [12] 1400 	rlc	a
      00440F A2 E7            [12] 1401 	mov	c,acc.7
      004411 C8               [12] 1402 	xch	a,r0
      004412 33               [12] 1403 	rlc	a
      004413 C8               [12] 1404 	xch	a,r0
      004414 33               [12] 1405 	rlc	a
      004415 C8               [12] 1406 	xch	a,r0
      004416 54 03            [12] 1407 	anl	a,#0x03
      004418 FB               [12] 1408 	mov	r3,a
      004419 88 82            [24] 1409 	mov	dpl, r0
      00441B C0 07            [24] 1410 	push	ar7
      00441D C0 06            [24] 1411 	push	ar6
      00441F C0 05            [24] 1412 	push	ar5
      004421 C0 04            [24] 1413 	push	ar4
      004423 C0 03            [24] 1414 	push	ar3
      004425 C0 02            [24] 1415 	push	ar2
      004427 C0 01            [24] 1416 	push	ar1
      004429 12 42 17         [24] 1417 	lcall	_load_page
      00442C E5 82            [12] 1418 	mov	a, dpl
      00442E D0 01            [24] 1419 	pop	ar1
      004430 D0 02            [24] 1420 	pop	ar2
      004432 D0 03            [24] 1421 	pop	ar3
      004434 D0 04            [24] 1422 	pop	ar4
      004436 D0 05            [24] 1423 	pop	ar5
      004438 D0 06            [24] 1424 	pop	ar6
      00443A D0 07            [24] 1425 	pop	ar7
      00443C D0 03            [24] 1426 	pop	ar3
      00443E D0 02            [24] 1427 	pop	ar2
      004440 70 01            [24] 1428 	jnz	00105$
      004442 22               [24] 1429 	ret
      004443                       1430 00105$:
                                   1431 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004443 C0 06            [24] 1432 	push	ar6
      004445 C0 07            [24] 1433 	push	ar7
      004447 74 3F            [12] 1434 	mov	a,#0x3f
      004449 55 0C            [12] 1435 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00444B 7F 00            [12] 1436 	mov	r7,#0x00
      00444D 24 2D            [12] 1437 	add	a, #_page_data
      00444F F5 0C            [12] 1438 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004451 EF               [12] 1439 	mov	a,r7
      004452 34 05            [12] 1440 	addc	a, #(_page_data >> 8)
      004454 F5 0D            [12] 1441 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004456 85 0C 82         [24] 1442 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004459 85 0D 83         [24] 1443 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00445C E0               [24] 1444 	movx	a,@dptr
      00445D B5 01 06         [24] 1445 	cjne	a,ar1,00162$
      004460 D0 07            [24] 1446 	pop	ar7
      004462 D0 06            [24] 1447 	pop	ar6
      004464 80 0E            [24] 1448 	sjmp	00107$
      004466                       1449 00162$:
      004466 D0 07            [24] 1450 	pop	ar7
      004468 D0 06            [24] 1451 	pop	ar6
                                   1452 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00446A 85 0C 82         [24] 1453 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00446D 85 0D 83         [24] 1454 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004470 E9               [12] 1455 	mov	a,r1
      004471 F0               [24] 1456 	movx	@dptr,a
                                   1457 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1458 ;	assignBit
      004472 D2 0B            [12] 1459 	setb	_page_dirty
      004474                       1460 00107$:
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004474 0E               [12] 1462 	inc	r6
      004475 BE 00 01         [24] 1463 	cjne	r6,#0x00,00163$
      004478 0F               [12] 1464 	inc	r7
      004479                       1465 00163$:
      004479 02 43 E5         [24] 1466 	ljmp	00108$
      00447C                       1467 00110$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00447C 90 05 6E         [24] 1469 	mov	dptr,#_batch_depth
      00447F E0               [24] 1470 	movx	a,@dptr
      004480 70 03            [24] 1471 	jnz	00113$
                                   1472 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004482 02 40 97         [24] 1473 	ljmp	_ak820_nvm_flush
      004485                       1474 00113$:
      004485 22               [24] 1475 	ret
                                   1476 ;------------------------------------------------------------
                                   1477 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1478 ;------------------------------------------------------------
                                   1479 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1480 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1481 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1482 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1483 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1484 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1485 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1486 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1487 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1488 ;------------------------------------------------------------
                                   1489 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1490 ;	-----------------------------------------
                                   1491 ;	 function ak820_eeprom_update_block_xdata
                                   1492 ;	-----------------------------------------
      004486                       1493 _ak820_eeprom_update_block_xdata:
      004486 12 3A F0         [24] 1494 	lcall	_ak820_outline_0107
      004489 90 05 AA         [24] 1495 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00448C 12 3A F5         [24] 1496 	lcall	_ak820_outline_0108
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00448F 90 05 AA         [24] 1498 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004492 12 3A AF         [24] 1499 	lcall	_ak820_outline_0052
                                   1500 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004495 90 05 A5         [24] 1501 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004498 E0               [24] 1502 	movx	a,@dptr
      004499 F5 12            [12] 1503 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00449B A3               [24] 1504 	inc	dptr
      00449C E0               [24] 1505 	movx	a,@dptr
      00449D F5 13            [12] 1506 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00449F A3               [24] 1507 	inc	dptr
      0044A0 E0               [24] 1508 	movx	a,@dptr
      0044A1 F5 14            [12] 1509 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0044A3 A9 12            [24] 1510 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044A5 AA 13            [24] 1511 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1512 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044A7 E4               [12] 1513 	clr	a
      0044A8 F5 0E            [12] 1514 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0044AA F5 0F            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0044AC                       1516 00105$:
      0044AC 90 05 A8         [24] 1517 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0044AF E0               [24] 1518 	movx	a,@dptr
      0044B0 F5 10            [12] 1519 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0044B2 A3               [24] 1520 	inc	dptr
      0044B3 E0               [24] 1521 	movx	a,@dptr
      0044B4 F5 11            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0044B6 C3               [12] 1523 	clr	c
      0044B7 E5 0E            [12] 1524 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044B9 95 10            [12] 1525 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044BB E5 0F            [12] 1526 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044BD 95 11            [12] 1527 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044BF 50 68            [24] 1528 	jnc	00107$
                                   1529 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044C1 89 00            [24] 1530 	mov	ar0,r1
      0044C3 8A 05            [24] 1531 	mov	ar5,r2
      0044C5 E5 0E            [12] 1532 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C7 28               [12] 1533 	add	a, r0
      0044C8 F8               [12] 1534 	mov	r0,a
      0044C9 E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044CB 3D               [12] 1536 	addc	a, r5
      0044CC FD               [12] 1537 	mov	r5,a
      0044CD 88 82            [24] 1538 	mov	dpl, r0
      0044CF 8D 83            [24] 1539 	mov	dph, r5
      0044D1 C0 07            [24] 1540 	push	ar7
      0044D3 C0 06            [24] 1541 	push	ar6
      0044D5 C0 02            [24] 1542 	push	ar2
      0044D7 C0 01            [24] 1543 	push	ar1
      0044D9 12 42 89         [24] 1544 	lcall	_read_offset
      0044DC AD 82            [24] 1545 	mov	r5, dpl
      0044DE D0 01            [24] 1546 	pop	ar1
      0044E0 D0 02            [24] 1547 	pop	ar2
      0044E2 D0 06            [24] 1548 	pop	ar6
      0044E4 D0 07            [24] 1549 	pop	ar7
      0044E6 E5 0E            [12] 1550 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044E8 2E               [12] 1551 	add	a, r6
      0044E9 F5 82            [12] 1552 	mov	dpl,a
      0044EB E5 0F            [12] 1553 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044ED 3F               [12] 1554 	addc	a, r7
      0044EE F5 83            [12] 1555 	mov	dph,a
      0044F0 E0               [24] 1556 	movx	a,@dptr
      0044F1 FC               [12] 1557 	mov	r4,a
      0044F2 ED               [12] 1558 	mov	a,r5
      0044F3 B5 04 02         [24] 1559 	cjne	a,ar4,00131$
      0044F6 80 27            [24] 1560 	sjmp	00106$
      0044F8                       1561 00131$:
                                   1562 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0044F8 90 05 AA         [24] 1563 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0044FB E0               [24] 1564 	movx	a,@dptr
      0044FC F8               [12] 1565 	mov	r0,a
      0044FD A3               [24] 1566 	inc	dptr
      0044FE E0               [24] 1567 	movx	a,@dptr
      0044FF FD               [12] 1568 	mov	r5,a
      004500 90 05 9E         [24] 1569 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004503 E5 12            [12] 1570 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004505 F0               [24] 1571 	movx	@dptr,a
      004506 E5 13            [12] 1572 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004508 A3               [24] 1573 	inc	dptr
      004509 F0               [24] 1574 	movx	@dptr,a
      00450A E5 14            [12] 1575 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00450C A3               [24] 1576 	inc	dptr
      00450D F0               [24] 1577 	movx	@dptr,a
      00450E 90 05 A1         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004511 E5 10            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004513 F0               [24] 1580 	movx	@dptr,a
      004514 E5 11            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004516 A3               [24] 1582 	inc	dptr
      004517 F0               [24] 1583 	movx	@dptr,a
      004518 88 82            [24] 1584 	mov	dpl, r0
      00451A 8D 83            [24] 1585 	mov	dph, r5
                                   1586 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00451C 02 43 A3         [24] 1587 	ljmp	_ak820_eeprom_write_block_xdata
      00451F                       1588 00106$:
                                   1589 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00451F 05 0E            [12] 1590 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004521 E4               [12] 1591 	clr	a
      004522 B5 0E 87         [24] 1592 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004525 05 0F            [12] 1593 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004527 80 83            [24] 1594 	sjmp	00105$
      004529                       1595 00107$:
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004529 22               [24] 1597 	ret
                                   1598 ;------------------------------------------------------------
                                   1599 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1600 ;------------------------------------------------------------
                                   1601 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1602 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1603 ;------------------------------------------------------------
                                   1604 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1605 ;	-----------------------------------------
                                   1606 ;	 function eeprom_driver_erase
                                   1607 ;	-----------------------------------------
      00452A                       1608 _eeprom_driver_erase:
                                   1609 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00452A 12 40 97         [24] 1610 	lcall	_ak820_nvm_flush
                                   1611 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00452D 7F 00            [12] 1612 	mov	r7,#0x00
      00452F                       1613 00111$:
      00452F BF A0 01         [24] 1614 	cjne	r7,#0xa0,00165$
      004532 22               [24] 1615 	ret
      004533                       1616 00165$:
      004533 20 0C 32         [24] 1617 	jb	_storage_failed,00113$
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004536 8F 82            [24] 1619 	mov	dpl, r7
      004538 C0 07            [24] 1620 	push	ar7
      00453A 12 42 17         [24] 1621 	lcall	_load_page
      00453D E5 82            [12] 1622 	mov	a, dpl
      00453F D0 07            [24] 1623 	pop	ar7
      004541 70 01            [24] 1624 	jnz	00126$
                                   1625 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004543 22               [24] 1626 	ret
      004544                       1627 00126$:
      004544 7E 00            [12] 1628 	mov	r6,#0x00
      004546                       1629 00107$:
                                   1630 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004546 EE               [12] 1631 	mov	a,r6
      004547 24 2D            [12] 1632 	add	a, #_page_data
      004549 FC               [12] 1633 	mov	r4,a
      00454A E4               [12] 1634 	clr	a
      00454B 34 05            [12] 1635 	addc	a, #(_page_data >> 8)
      00454D FD               [12] 1636 	mov	r5,a
      00454E 12 45 B2         [24] 1637 	lcall	_ak820_outline_0095
      004551 60 07            [24] 1638 	jz	00108$
      004553 12 3A FF         [24] 1639 	lcall	_ak820_outline_0123
      004556 E4               [12] 1640 	clr	a
      004557 F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	assignBit
      004558 D2 0B            [12] 1643 	setb	_page_dirty
      00455A                       1644 00108$:
                                   1645 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00455A 0E               [12] 1646 	inc	r6
      00455B BE 40 E8         [24] 1647 	cjne	r6,#0x40,00107$
                                   1648 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00455E C0 07            [24] 1649 	push	ar7
      004560 12 40 97         [24] 1650 	lcall	_ak820_nvm_flush
      004563 D0 07            [24] 1651 	pop	ar7
                                   1652 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004565 0F               [12] 1653 	inc	r7
      004566 80 C7            [24] 1654 	sjmp	00111$
      004568                       1655 00113$:
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004568 22               [24] 1657 	ret
                                   1658 	.area CSEG    (CODE)
                                   1659 	.area CONST   (CODE)
                                   1660 	.area XINIT   (CODE)
                                   1661 	.area CABS    (ABS,CODE)
                                   1662 
                                   1663 ; Experimental exact instruction outlining.
                                   1664 	.globl _ak820_outline_0005
                                   1665 	.globl _ak820_outline_0011
                                   1666 	.globl _ak820_outline_0016
                                   1667 	.globl _ak820_outline_0022
                                   1668 	.globl _ak820_outline_0031
                                   1669 	.globl _ak820_outline_0036
                                   1670 	.globl _ak820_outline_0043
                                   1671 	.globl _ak820_outline_0052
                                   1672 	.globl _ak820_outline_0053
                                   1673 	.globl _ak820_outline_0061
                                   1674 	.globl _ak820_outline_0065
                                   1675 	.globl _ak820_outline_0074
                                   1676 	.globl _ak820_outline_0079
                                   1677 	.globl _ak820_outline_0080
                                   1678 	.globl _ak820_outline_0086
                                   1679 	.globl _ak820_outline_0093
                                   1680 	.globl _ak820_outline_0095
                                   1681 	.globl _ak820_outline_0101
                                   1682 	.globl _ak820_outline_0105
                                   1683 	.globl _ak820_outline_0107
                                   1684 	.globl _ak820_outline_0108
                                   1685 	.globl _ak820_outline_0118
                                   1686 	.globl _ak820_outline_0122
                                   1687 	.globl _ak820_outline_0123
                                   1688 	.globl _ak820_outline_0125
                                   1689 	.globl _ak820_outline_0133
                                   1690 	.globl _ak820_outline_0135
                                   1691 	.globl _ak820_outline_0141
                                   1692 	.globl _ak820_outline_0143
                                   1693 	.globl _ak820_outline_0144
                                   1694 	.globl _ak820_outline_0151
                                   1695 	.globl _ak820_outline_0152
                                   1696 	.globl _ak820_outline_0160
                                   1697 	.globl _ak820_outline_0162
                                   1698 	.globl _ak820_outline_0164
                                   1699 	.globl _ak820_outline_0165
                                   1700 	.globl _ak820_outline_0188
                                   1701 	.globl _ak820_outline_0189
                                   1702 
                                   1703 	.area CSEG (CODE)
                                   1704 ; function ak820_outline_0011
      004569                       1705 _ak820_outline_0011:
      004569 8E 82            [24] 1706 	mov	dpl,r6
      00456B 8F 83            [24] 1707 	mov	dph,r7
      00456D A3               [24] 1708 	inc	dptr
      00456E A3               [24] 1709 	inc	dptr
      00456F A3               [24] 1710 	inc	dptr
      004570 A3               [24] 1711 	inc	dptr
      004571 A3               [24] 1712 	inc	dptr
      004572 22               [24] 1713 	ret
                                   1714 
                                   1715 	.area CSEG (CODE)
                                   1716 ; function ak820_outline_0031
      004573                       1717 _ak820_outline_0031:
      004573 F0               [24] 1718 	movx	@dptr,a
      004574 8E 82            [24] 1719 	mov	dpl,r6
      004576 8F 83            [24] 1720 	mov	dph,r7
      004578 A3               [24] 1721 	inc	dptr
      004579 A3               [24] 1722 	inc	dptr
      00457A 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0036
      00457B                       1727 _ak820_outline_0036:
      00457B AF F0            [24] 1728 	mov	r7,b
      00457D AE 83            [24] 1729 	mov	r6,dph
      00457F E5 82            [12] 1730 	mov	a,dpl
      004581 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0043
      004582                       1735 _ak820_outline_0043:
      004582 EF               [12] 1736 	mov	a,r7
      004583 24 85            [12] 1737 	add	a,#_ak820_nvm_flush_header_10000_62
      004585 F5 82            [12] 1738 	mov	dpl,a
      004587 E4               [12] 1739 	clr	a
      004588 34 05            [12] 1740 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00458A F5 83            [12] 1741 	mov	dph,a
      00458C E0               [24] 1742 	movx	a,@dptr
      00458D 22               [24] 1743 	ret
                                   1744 
                                   1745 	.area CSEG (CODE)
                                   1746 ; function ak820_outline_0053
      00458E                       1747 _ak820_outline_0053:
      00458E 8F 06            [24] 1748 	mov	ar6,r7
      004590 7D 00            [12] 1749 	mov	r5,#0x00
      004592 74 40            [12] 1750 	mov	a,#0x40
      004594 2E               [12] 1751 	add	a,r6
      004595 FE               [12] 1752 	mov	r6,a
      004596 74 EF            [12] 1753 	mov	a,#0xef
      004598 3D               [12] 1754 	addc	a,r5
      004599 FD               [12] 1755 	mov	r5,a
      00459A 8E 82            [24] 1756 	mov	dpl,r6
      00459C 8D 83            [24] 1757 	mov	dph,r5
      00459E 22               [24] 1758 	ret
                                   1759 
                                   1760 	.area CSEG (CODE)
                                   1761 ; function ak820_outline_0065
      00459F                       1762 _ak820_outline_0065:
      00459F 8D 82            [24] 1763 	mov	dpl,r5
      0045A1 8E 83            [24] 1764 	mov	dph,r6
      0045A3 EC               [12] 1765 	mov	a,r4
      0045A4 F0               [24] 1766 	movx	@dptr,a
      0045A5 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0079
      0045A6                       1771 _ak820_outline_0079:
      0045A6 F0               [24] 1772 	movx	@dptr,a
      0045A7 8E 82            [24] 1773 	mov	dpl,r6
      0045A9 8F 83            [24] 1774 	mov	dph,r7
      0045AB 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0086
      0045AC                       1779 _ak820_outline_0086:
      0045AC E0               [24] 1780 	movx	a,@dptr
      0045AD FA               [12] 1781 	mov	r2,a
      0045AE A3               [24] 1782 	inc	dptr
      0045AF E0               [24] 1783 	movx	a,@dptr
      0045B0 FB               [12] 1784 	mov	r3,a
      0045B1 22               [24] 1785 	ret
                                   1786 
                                   1787 	.area CSEG (CODE)
                                   1788 ; function ak820_outline_0095
      0045B2                       1789 _ak820_outline_0095:
      0045B2 8C 82            [24] 1790 	mov	dpl,r4
      0045B4 8D 83            [24] 1791 	mov	dph,r5
      0045B6 E0               [24] 1792 	movx	a,@dptr
      0045B7 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0105
      0045B8                       1797 _ak820_outline_0105:
      0045B8 EF               [12] 1798 	mov	a,r7
      0045B9 24 2D            [12] 1799 	add	a,#_page_data
      0045BB F5 82            [12] 1800 	mov	dpl,a
      0045BD E4               [12] 1801 	clr	a
      0045BE 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      0045C0 F5 83            [12] 1803 	mov	dph,a
      0045C2 E0               [24] 1804 	movx	a,@dptr
      0045C3 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0125
      0045C4                       1809 _ak820_outline_0125:
      0045C4 AE 82            [24] 1810 	mov	r6,dpl
      0045C6 AF 83            [24] 1811 	mov	r7,dph
      0045C8 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0135
      0045C9                       1816 _ak820_outline_0135:
      0045C9 2E               [12] 1817 	add	a,r6
      0045CA FE               [12] 1818 	mov	r6,a
      0045CB E4               [12] 1819 	clr	a
      0045CC 3F               [12] 1820 	addc	a,r7
      0045CD FF               [12] 1821 	mov	r7,a
      0045CE 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0143
      0045CF                       1826 _ak820_outline_0143:
      0045CF 42 05            [12] 1827 	orl	ar5,a
      0045D1 EA               [12] 1828 	mov	a,r2
      0045D2 42 04            [12] 1829 	orl	ar4,a
      0045D4 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0151
      0045D5                       1834 _ak820_outline_0151:
      0045D5 AC 82            [24] 1835 	mov	r4,dpl
      0045D7 AD 83            [24] 1836 	mov	r5,dph
      0045D9 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0152
      0045DA                       1841 _ak820_outline_0152:
      0045DA 2A               [12] 1842 	add	a,r2
      0045DB F0               [24] 1843 	movx	@dptr,a
      0045DC E4               [12] 1844 	clr	a
      0045DD 3B               [12] 1845 	addc	a,r3
      0045DE A3               [24] 1846 	inc	dptr
      0045DF F0               [24] 1847 	movx	@dptr,a
      0045E0 22               [24] 1848 	ret
                                   1849 
                                   1850 	.area CSEG (CODE)
                                   1851 ; function ak820_outline_0162
      0045E1                       1852 _ak820_outline_0162:
      0045E1 8F 82            [24] 1853 	mov	dpl,r7
      0045E3 8E 83            [24] 1854 	mov	dph,r6
      0045E5 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0164
      0045E6                       1859 _ak820_outline_0164:
      0045E6 2E               [12] 1860 	add	a,r6
      0045E7 FC               [12] 1861 	mov	r4,a
      0045E8 E4               [12] 1862 	clr	a
      0045E9 3F               [12] 1863 	addc	a,r7
      0045EA FD               [12] 1864 	mov	r5,a
      0045EB 22               [24] 1865 	ret
                                   1866 
                                   1867 	.area CSEG (CODE)
                                   1868 ; function ak820_outline_0165
      0045EC                       1869 _ak820_outline_0165:
      0045EC ED               [12] 1870 	mov	a,r5
      0045ED F0               [24] 1871 	movx	@dptr,a
      0045EE EE               [12] 1872 	mov	a,r6
      0045EF A3               [24] 1873 	inc	dptr
      0045F0 F0               [24] 1874 	movx	@dptr,a
      0045F1 22               [24] 1875 	ret
                                   1876 
                                   1877 	.area CSEG (CODE)
                                   1878 ; function ak820_outline_0188
      0045F2                       1879 _ak820_outline_0188:
      0045F2 89 82            [24] 1880 	mov	dpl,r1
      0045F4 8A 83            [24] 1881 	mov	dph,r2
      0045F6 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0189
      0045F7                       1886 _ak820_outline_0189:
      0045F7 8C 82            [24] 1887 	mov	dpl,r4
      0045F9 8B 83            [24] 1888 	mov	dph,r3
      0045FB 22               [24] 1889 	ret
