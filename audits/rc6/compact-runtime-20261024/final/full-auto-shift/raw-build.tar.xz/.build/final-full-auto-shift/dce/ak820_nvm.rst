                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      00000A                         91 _page_valid:
      00000A                         92 	.ds 1
      00000B                         93 _page_dirty:
      00000B                         94 	.ds 1
      00000C                         95 _storage_failed:
      00000C                         96 	.ds 1
      00000D                         97 _ak820_nvm_ok_sloc0_1_0:
      00000D                         98 	.ds 1
      00000E                         99 _load_page_sloc0_1_0:
      00000E                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00052D                        109 _page_data:
      00052D                        110 	.ds 64
      00056D                        111 _cached_page:
      00056D                        112 	.ds 1
      00056E                        113 _batch_depth:
      00056E                        114 	.ds 1
      00056F                        115 _first_failure_stage:
      00056F                        116 	.ds 1
      000570                        117 _nvm_fail_stage_10000_20:
      000570                        118 	.ds 1
      000571                        119 _ak820_nvm_diagnostic_out_10000_23:
      000571                        120 	.ds 2
      000573                        121 _crc_byte_PARM_2:
      000573                        122 	.ds 1
      000574                        123 _crc_byte_crc_10000_25:
      000574                        124 	.ds 2
      000576                        125 _page_crc_crc_10000_30:
      000576                        126 	.ds 2
      000578                        127 _write_page_address_10000_32:
      000578                        128 	.ds 2
      00057A                        129 _journal_header_valid_header_10000_39:
      00057A                        130 	.ds 2
      00057C                        131 _recover_journal_header_10000_46:
      00057C                        132 	.ds 9
      000585                        133 _ak820_nvm_flush_header_10000_62:
      000585                        134 	.ds 9
      00058E                        135 _ak820_nvm_flush_stage_10000_62:
      00058E                        136 	.ds 1
      00058F                        137 _load_page_page_10000_87:
      00058F                        138 	.ds 1
      000590                        139 _read_offset_offset_10000_93:
      000590                        140 	.ds 2
      000592                        141 _eeprom_read_byte_addr_10000_97:
      000592                        142 	.ds 3
      000595                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000595                        144 	.ds 3
      000598                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000598                        146 	.ds 2
      00059A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00059A                        148 	.ds 2
      00059C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00059C                        150 	.ds 2
      00059E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059E                        152 	.ds 3
      0005A1                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      0005A1                        154 	.ds 2
      0005A3                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      0005A3                        156 	.ds 2
      0005A5                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A5                        158 	.ds 3
      0005A8                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A8                        160 	.ds 2
      0005AA                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005AA                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DCE                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DCE E5 82            [12]  215 	mov	a,dpl
      003DD0 90 05 70         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003DD3 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003DD4 20 0C 08         [24]  219 	jb	_storage_failed,00102$
      003DD7 90 05 70         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003DDA E0               [24]  221 	movx	a,@dptr
      003DDB 90 05 6F         [24]  222 	mov	dptr,#_first_failure_stage
      003DDE F0               [24]  223 	movx	@dptr,a
      003DDF                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003DDF D2 0C            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003DE1 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003DE2                        239 _ak820_nvm_diagnostic:
      003DE2 12 3A CD         [24]  240 	lcall	_ak820_outline_0109
      003DE5 90 05 71         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DE8 12 3A D2         [24]  242 	lcall	_ak820_outline_0110
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003DEB 90 05 71         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003DEE 12 3A 8C         [24]  245 	lcall	_ak820_outline_0052
      003DF1 A2 0C            [12]  246 	mov	c,_storage_failed
      003DF3 E4               [12]  247 	clr	a
      003DF4 33               [12]  248 	rlc	a
      003DF5 12 3A D7         [24]  249 	lcall	_ak820_outline_0120
      003DF8 12 45 89         [24]  250 	lcall	_ak820_outline_0079
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003DFB A3               [24]  252 	inc	dptr
      003DFC A2 0A            [12]  253 	mov	c,_page_valid
      003DFE E4               [12]  254 	clr	a
      003DFF 33               [12]  255 	rlc	a
      003E00 12 45 56         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E03 A2 0B            [12]  258 	mov	c,_page_dirty
      003E05 E4               [12]  259 	clr	a
      003E06 33               [12]  260 	rlc	a
      003E07 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E08 74 03            [12]  263 	mov	a,#0x03
      003E0A 12 45 C2         [24]  264 	lcall	_ak820_outline_0164
      003E0D 90 05 6E         [24]  265 	mov	dptr,#_batch_depth
      003E10 E0               [24]  266 	movx	a,@dptr
      003E11 12 3A E2         [24]  267 	lcall	_ak820_outline_0126
      003E14 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E15 74 04            [12]  270 	mov	a,#0x04
      003E17 12 45 C2         [24]  271 	lcall	_ak820_outline_0164
      003E1A 90 05 6D         [24]  272 	mov	dptr,#_cached_page
      003E1D E0               [24]  273 	movx	a,@dptr
      003E1E 12 3A E2         [24]  274 	lcall	_ak820_outline_0126
      003E21 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E22 12 45 4C         [24]  277 	lcall	_ak820_outline_0011
      003E25 E4               [12]  278 	clr	a
      003E26 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E27 74 06            [12]  281 	mov	a,#0x06
      003E29 12 45 AC         [24]  282 	lcall	_ak820_outline_0139
      003E2C 90 05 6F         [24]  283 	mov	dptr,#_first_failure_stage
      003E2F E0               [24]  284 	movx	a,@dptr
      003E30 12 3A D7         [24]  285 	lcall	_ak820_outline_0120
      003E33 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E34 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E35                        300 _crc_byte:
      003E35 12 3A CD         [24]  301 	lcall	_ak820_outline_0109
      003E38 90 05 74         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E3B 12 3A D2         [24]  303 	lcall	_ak820_outline_0110
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E3E 90 05 73         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E41 E0               [24]  306 	movx	a,@dptr
      003E42 FF               [12]  307 	mov	r7,a
      003E43 7E 00            [12]  308 	mov	r6,#0x00
      003E45 90 05 74         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E48 E0               [24]  310 	movx	a,@dptr
      003E49 6E               [12]  311 	xrl	a,r6
      003E4A F0               [24]  312 	movx	@dptr,a
      003E4B A3               [24]  313 	inc	dptr
      003E4C E0               [24]  314 	movx	a,@dptr
      003E4D 6F               [12]  315 	xrl	a,r7
      003E4E F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E4F 7F 00            [12]  318 	mov	r7,#0x00
      003E51                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E51 90 05 74         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E54 12 3A AF         [24]  322 	lcall	_ak820_outline_0080
      003E57 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E5A ED               [12]  324 	mov	a,r5
      003E5B 2D               [12]  325 	add	a,r5
      003E5C FB               [12]  326 	mov	r3,a
      003E5D EE               [12]  327 	mov	a,r6
      003E5E 33               [12]  328 	rlc	a
      003E5F FC               [12]  329 	mov	r4,a
      003E60 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E63 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E66 80 06            [24]  332 	sjmp	00107$
      003E68                        333 00106$:
      003E68 ED               [12]  334 	mov	a,r5
      003E69 2D               [12]  335 	add	a,r5
      003E6A FB               [12]  336 	mov	r3,a
      003E6B EE               [12]  337 	mov	a,r6
      003E6C 33               [12]  338 	rlc	a
      003E6D FC               [12]  339 	mov	r4,a
      003E6E                        340 00107$:
      003E6E 90 05 74         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E71 12 3A B5         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E74 0F               [12]  344 	inc	r7
      003E75 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003E78 12 36 47         [24]  347 	lcall	_ak820_outline_0125
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003E7B 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003E7C                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003E7C 90 05 76         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003E7F 74 FF            [12]  363 	mov	a,#0xff
      003E81 F0               [24]  364 	movx	@dptr,a
      003E82 A3               [24]  365 	inc	dptr
      003E83 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003E84 7F 00            [12]  368 	mov	r7,#0x00
      003E86                        369 00102$:
      003E86 90 05 76         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003E89 12 3A AF         [24]  371 	lcall	_ak820_outline_0080
      003E8C 12 45 9B         [24]  372 	lcall	_ak820_outline_0107
      003E8F 90 05 73         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003E92 F0               [24]  374 	movx	@dptr,a
      003E93 12 3A EC         [24]  375 	lcall	_ak820_outline_0137
      003E96 C0 07            [24]  376 	push	ar7
      003E98 12 3E 35         [24]  377 	lcall	_crc_byte
      003E9B AD 82            [24]  378 	mov	r5, dpl
      003E9D AE 83            [24]  379 	mov	r6, dph
      003E9F D0 07            [24]  380 	pop	ar7
      003EA1 90 05 76         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003EA4 12 45 C8         [24]  382 	lcall	_ak820_outline_0165
      003EA7 0F               [12]  383 	inc	r7
      003EA8 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003EAB 12 3A EC         [24]  386 	lcall	_ak820_outline_0137
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003EAE 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003EAF                        399 _write_page:
      003EAF 12 3A CD         [24]  400 	lcall	_ak820_outline_0109
      003EB2 90 05 78         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003EB5 12 3A D2         [24]  402 	lcall	_ak820_outline_0110
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EB8 90 05 78         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EBB 12 3A 3F         [24]  405 	lcall	_ak820_outline_0005
      003EBE C0 07            [24]  406 	push	ar7
      003EC0 C0 06            [24]  407 	push	ar6
      003EC2 12 3C 47         [24]  408 	lcall	_ak820_flash_erase
      003EC5 E5 82            [12]  409 	mov	a, dpl
      003EC7 D0 06            [24]  410 	pop	ar6
      003EC9 D0 07            [24]  411 	pop	ar7
      003ECB 70 03            [24]  412 	jnz	00102$
      003ECD F5 82            [12]  413 	mov	dpl,a
      003ECF 22               [24]  414 	ret
      003ED0                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003ED0 90 05 09         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003ED3 74 2D            [12]  418 	mov	a,#_page_data
      003ED5 F0               [24]  419 	movx	@dptr,a
      003ED6 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003ED8 A3               [24]  421 	inc	dptr
      003ED9 12 45 89         [24]  422 	lcall	_ak820_outline_0079
      003EDC 12 3D 5B         [24]  423 	lcall	_ak820_flash_program_page
      003EDF E5 82            [12]  424 	mov	a, dpl
      003EE1 70 03            [24]  425 	jnz	00120$
      003EE3 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EE5 22               [24]  428 	ret
      003EE6                        429 00120$:
      003EE6 7F 00            [12]  430 	mov	r7,#0x00
      003EE8                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003EE8 8F 05            [24]  433 	mov	ar5,r7
      003EEA 7E 00            [12]  434 	mov	r6,#0x00
      003EEC 90 05 78         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003EEF 12 3A DC         [24]  436 	lcall	_ak820_outline_0124
      003EF2 ED               [12]  437 	mov	a,r5
      003EF3 2B               [12]  438 	add	a, r3
      003EF4 FB               [12]  439 	mov	r3,a
      003EF5 EE               [12]  440 	mov	a,r6
      003EF6 3C               [12]  441 	addc	a, r4
      003EF7 FC               [12]  442 	mov	r4,a
      003EF8 12 36 47         [24]  443 	lcall	_ak820_outline_0125
      003EFB 12 3B 3A         [24]  444 	lcall	_ak820_flash_read
      003EFE AE 82            [24]  445 	mov	r6, dpl
      003F00 12 45 9B         [24]  446 	lcall	_ak820_outline_0107
      003F03 FD               [12]  447 	mov	r5,a
      003F04 EE               [12]  448 	mov	a,r6
      003F05 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F08 80 04            [24]  450 	sjmp	00109$
      003F0A                        451 00149$:
      003F0A 75 82 00         [24]  452 	mov	dpl, #0x00
      003F0D 22               [24]  453 	ret
      003F0E                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F0E 0F               [12]  456 	inc	r7
      003F0F BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F12 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F15 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F16                        472 _journal_header_valid:
      003F16 12 3A CD         [24]  473 	lcall	_ak820_outline_0109
      003F19 90 05 7A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F1C 12 3A D2         [24]  475 	lcall	_ak820_outline_0110
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F1F 90 05 7A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F22 12 3A 3F         [24]  478 	lcall	_ak820_outline_0005
      003F25 E0               [24]  479 	movx	a,@dptr
      003F26 FD               [12]  480 	mov	r5,a
      003F27 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F2A 80 04            [24]  482 	sjmp	00116$
      003F2C                        483 00138$:
      003F2C 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F2F 22               [24]  486 	ret
      003F30                        487 00116$:
      003F30 7D 01            [12]  488 	mov	r5,#0x01
      003F32                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F32 ED               [12]  491 	mov	a,r5
      003F33 12 3A 7C         [24]  492 	lcall	_ak820_outline_0022
      003F36 E0               [24]  493 	movx	a,@dptr
      003F37 FC               [12]  494 	mov	r4,a
      003F38 8D 02            [24]  495 	mov	ar2,r5
      003F3A 7B 00            [12]  496 	mov	r3,#0x00
      003F3C 74 04            [12]  497 	mov	a,#0x04
      003F3E 2A               [12]  498 	add	a, r2
      003F3F FA               [12]  499 	mov	r2,a
      003F40 E4               [12]  500 	clr	a
      003F41 3B               [12]  501 	addc	a, r3
      003F42 FB               [12]  502 	mov	r3,a
      003F43 EA               [12]  503 	mov	a,r2
      003F44 2E               [12]  504 	add	a, r6
      003F45 F5 82            [12]  505 	mov	dpl,a
      003F47 EB               [12]  506 	mov	a,r3
      003F48 3F               [12]  507 	addc	a, r7
      003F49 F5 83            [12]  508 	mov	dph,a
      003F4B E0               [24]  509 	movx	a,@dptr
      003F4C 62 04            [12]  510 	xrl	ar4,a
      003F4E BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003F51 80 04            [24]  512 	sjmp	00107$
      003F53                        513 00139$:
      003F53 75 82 00         [24]  514 	mov	dpl, #0x00
      003F56 22               [24]  515 	ret
      003F57                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F57 0D               [12]  518 	inc	r5
      003F58 BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F5B 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F5E 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003F5F                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F5F 7F 00            [12]  538 	mov	r7,#0x00
      003F61                        539 00115$:
      003F61 EF               [12]  540 	mov	a,r7
      003F62 24 7C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003F64 FD               [12]  542 	mov	r5,a
      003F65 E4               [12]  543 	clr	a
      003F66 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F68 FE               [12]  545 	mov	r6,a
      003F69 8F 04            [24]  546 	mov	ar4,r7
      003F6B 7B 00            [12]  547 	mov	r3,#0x00
      003F6D 74 40            [12]  548 	mov	a,#0x40
      003F6F 2C               [12]  549 	add	a, r4
      003F70 FC               [12]  550 	mov	r4,a
      003F71 74 EF            [12]  551 	mov	a,#0xef
      003F73 3B               [12]  552 	addc	a, r3
      003F74 FB               [12]  553 	mov	r3,a
      003F75 12 45 D3         [24]  554 	lcall	_ak820_outline_0186
      003F78 12 3B 3A         [24]  555 	lcall	_ak820_flash_read
      003F7B AC 82            [24]  556 	mov	r4, dpl
      003F7D 12 45 82         [24]  557 	lcall	_ak820_outline_0065
      003F80 0F               [12]  558 	inc	r7
      003F81 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003F84 90 05 7C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003F87 12 3F 16         [24]  562 	lcall	_journal_header_valid
      003F8A E5 82            [12]  563 	mov	a, dpl
      003F8C 70 01            [24]  564 	jnz	00103$
      003F8E 22               [24]  565 	ret
      003F8F                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003F8F 90 05 7D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003F92 E0               [24]  569 	movx	a,@dptr
      003F93 FF               [12]  570 	mov	r7,a
      003F94 7E 00            [12]  571 	mov	r6,#0x00
      003F96 90 05 7E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003F99 E0               [24]  573 	movx	a,@dptr
      003F9A FC               [12]  574 	mov	r4,a
      003F9B E4               [12]  575 	clr	a
      003F9C 42 07            [12]  576 	orl	ar7,a
      003F9E EC               [12]  577 	mov	a,r4
      003F9F 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FA1 90 05 7F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FA4 E0               [24]  581 	movx	a,@dptr
      003FA5 FD               [12]  582 	mov	r5,a
      003FA6 7C 00            [12]  583 	mov	r4,#0x00
      003FA8 90 05 80         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FAB E0               [24]  585 	movx	a,@dptr
      003FAC FA               [12]  586 	mov	r2,a
      003FAD E4               [12]  587 	clr	a
      003FAE 12 45 B2         [24]  588 	lcall	_ak820_outline_0144
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FB1 C3               [12]  590 	clr	c
      003FB2 EF               [12]  591 	mov	a,r7
      003FB3 94 A0            [12]  592 	subb	a,#0xa0
      003FB5 EE               [12]  593 	mov	a,r6
      003FB6 94 00            [12]  594 	subb	a,#0x00
      003FB8 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FBA 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FBD 02 3D CE         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FC0                        601 00134$:
      003FC0 7B 00            [12]  602 	mov	r3,#0x00
      003FC2                        603 00117$:
      003FC2 C0 05            [24]  604 	push	ar5
      003FC4 C0 04            [24]  605 	push	ar4
      003FC6 EB               [12]  606 	mov	a,r3
      003FC7 24 2D            [12]  607 	add	a, #_page_data
      003FC9 F9               [12]  608 	mov	r1,a
      003FCA E4               [12]  609 	clr	a
      003FCB 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003FCD FA               [12]  611 	mov	r2,a
      003FCE 8B 00            [24]  612 	mov	ar0,r3
      003FD0 7D 00            [12]  613 	mov	r5,#0x00
      003FD2 74 EF            [12]  614 	mov	a,#0xef
      003FD4 2D               [12]  615 	add	a, r5
      003FD5 FD               [12]  616 	mov	r5,a
      003FD6 88 82            [24]  617 	mov	dpl, r0
      003FD8 8D 83            [24]  618 	mov	dph, r5
      003FDA 12 3B 3A         [24]  619 	lcall	_ak820_flash_read
      003FDD AD 82            [24]  620 	mov	r5, dpl
      003FDF 12 45 CE         [24]  621 	lcall	_ak820_outline_0185
      003FE2 ED               [12]  622 	mov	a,r5
      003FE3 F0               [24]  623 	movx	@dptr,a
      003FE4 0B               [12]  624 	inc	r3
      003FE5 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003FE8 80 06            [24]  626 	sjmp	00191$
      003FEA                        627 00190$:
      003FEA D0 04            [24]  628 	pop	ar4
      003FEC D0 05            [24]  629 	pop	ar5
      003FEE 80 D2            [24]  630 	sjmp	00117$
      003FF0                        631 00191$:
      003FF0 D0 04            [24]  632 	pop	ar4
      003FF2 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003FF4 C0 07            [24]  635 	push	ar7
      003FF6 C0 06            [24]  636 	push	ar6
      003FF8 C0 05            [24]  637 	push	ar5
      003FFA C0 04            [24]  638 	push	ar4
      003FFC 12 3E 7C         [24]  639 	lcall	_page_crc
      003FFF AA 82            [24]  640 	mov	r2, dpl
      004001 AB 83            [24]  641 	mov	r3, dph
      004003 D0 04            [24]  642 	pop	ar4
      004005 D0 05            [24]  643 	pop	ar5
      004007 D0 06            [24]  644 	pop	ar6
      004009 D0 07            [24]  645 	pop	ar7
      00400B EA               [12]  646 	mov	a,r2
      00400C B5 05 06         [24]  647 	cjne	a,ar5,00192$
      00400F EB               [12]  648 	mov	a,r3
      004010 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      004013 80 06            [24]  650 	sjmp	00113$
      004015                        651 00192$:
      004015 75 82 02         [24]  652 	mov	dpl, #0x02
      004018 02 3D CE         [24]  653 	ljmp	_nvm_fail
      00401B                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      00401B EE               [12]  656 	mov	a,r6
      00401C 54 03            [12]  657 	anl	a,#0x03
      00401E A2 E0            [12]  658 	mov	c,acc.0
      004020 CF               [12]  659 	xch	a,r7
      004021 13               [12]  660 	rrc	a
      004022 CF               [12]  661 	xch	a,r7
      004023 13               [12]  662 	rrc	a
      004024 A2 E0            [12]  663 	mov	c,acc.0
      004026 CF               [12]  664 	xch	a,r7
      004027 13               [12]  665 	rrc	a
      004028 CF               [12]  666 	xch	a,r7
      004029 13               [12]  667 	rrc	a
      00402A CF               [12]  668 	xch	a,r7
      00402B 24 C7            [12]  669 	add	a,#0xc7
      00402D FE               [12]  670 	mov	r6,a
      00402E 12 45 BD         [24]  671 	lcall	_ak820_outline_0161
      004031 12 3E AF         [24]  672 	lcall	_write_page
      004034 E5 82            [12]  673 	mov	a, dpl
      004036 70 06            [24]  674 	jnz	00110$
      004038 75 82 03         [24]  675 	mov	dpl, #0x03
      00403B 02 3D CE         [24]  676 	ljmp	_nvm_fail
      00403E                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      00403E 90 EF 40         [24]  679 	mov	dptr,#0xef40
      004041 12 3C 47         [24]  680 	lcall	_ak820_flash_erase
      004044 E5 82            [12]  681 	mov	a, dpl
      004046 70 06            [24]  682 	jnz	00119$
      004048 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      00404B 02 3D CE         [24]  685 	ljmp	_nvm_fail
      00404E                        686 00119$:
      00404E 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      00404F                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      00404F C2 0C            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      004051 90 05 6F         [24]  700 	mov	dptr,#_first_failure_stage
      004054 E4               [12]  701 	clr	a
      004055 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      004056 C2 0B            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      004058 C2 0A            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      00405A 90 05 6E         [24]  709 	mov	dptr,#_batch_depth
      00405D E4               [12]  710 	clr	a
      00405E F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      00405F 12 3F 5F         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      004062 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      004065                        724 _ak820_nvm_ok:
      004065 A2 0C            [12]  725 	mov	c,_storage_failed
      004067 B3               [12]  726 	cpl	c
      004068 92 0D            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      00406A 12 3A FC         [24]  728 	lcall	_ak820_outline_0159
      00406D 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      00406E                        737 _ak820_nvm_schema_fault:
      00406E 75 82 10         [24]  738 	mov	dpl, #0x10
      004071 02 3D CE         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      004074                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      004074 30 0B 03         [24]  754 	jnb	_page_dirty,00101$
      004077 30 0C 01         [24]  755 	jnb	_storage_failed,00102$
      00407A                        756 00101$:
      00407A 22               [24]  757 	ret
      00407B                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      00407B 12 3E 7C         [24]  760 	lcall	_page_crc
      00407E 12 45 A7         [24]  761 	lcall	_ak820_outline_0135
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      004081 90 05 85         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004084 74 A5            [12]  764 	mov	a,#0xa5
      004086 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      004087 90 05 6D         [24]  767 	mov	dptr,#_cached_page
      00408A E0               [24]  768 	movx	a,@dptr
      00408B 90 05 86         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      00408E F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      00408F 90 05 87         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      004092 E4               [12]  773 	clr	a
      004093 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      004094 8E 05            [24]  776 	mov	ar5,r6
      004096 90 05 88         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      004099 ED               [12]  778 	mov	a,r5
      00409A F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      00409B 8F 06            [24]  781 	mov	ar6,r7
      00409D 90 05 89         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040A0 EE               [12]  783 	mov	a,r6
      0040A1 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040A2 7F 01            [12]  786 	mov	r7,#0x01
      0040A4                        787 00128$:
      0040A4 8F 06            [24]  788 	mov	ar6,r7
      0040A6 EE               [12]  789 	mov	a,r6
      0040A7 24 04            [12]  790 	add	a,#0x04
      0040A9 FE               [12]  791 	mov	r6,a
      0040AA 33               [12]  792 	rlc	a
      0040AB 95 E0            [12]  793 	subb	a,acc
      0040AD FD               [12]  794 	mov	r5,a
      0040AE EE               [12]  795 	mov	a,r6
      0040AF 24 85            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      0040B1 FE               [12]  797 	mov	r6,a
      0040B2 ED               [12]  798 	mov	a,r5
      0040B3 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040B5 FD               [12]  800 	mov	r5,a
      0040B6 12 45 65         [24]  801 	lcall	_ak820_outline_0043
      0040B9 FC               [12]  802 	mov	r4,a
      0040BA 63 04 FF         [24]  803 	xrl	ar4,#0xff
      0040BD 8E 82            [24]  804 	mov	dpl,r6
      0040BF 8D 83            [24]  805 	mov	dph,r5
      0040C1 EC               [12]  806 	mov	a,r4
      0040C2 F0               [24]  807 	movx	@dptr,a
      0040C3 0F               [12]  808 	inc	r7
      0040C4 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040C7 90 05 8E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040CA 74 05            [12]  812 	mov	a,#0x05
      0040CC F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040CD 90 EF 40         [24]  815 	mov	dptr,#0xef40
      0040D0 12 3C 47         [24]  816 	lcall	_ak820_flash_erase
      0040D3 E5 82            [12]  817 	mov	a, dpl
      0040D5 70 03            [24]  818 	jnz	00269$
      0040D7 02 41 BE         [24]  819 	ljmp	00127$
      0040DA                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      0040DA 90 05 8E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040DD 74 06            [12]  823 	mov	a,#0x06
      0040DF F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040E0 7F 00            [12]  826 	mov	r7,#0x00
      0040E2                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      0040E2 12 45 71         [24]  829 	lcall	_ak820_outline_0053
      0040E5 12 3B 3A         [24]  830 	lcall	_ak820_flash_read
      0040E8 E5 82            [12]  831 	mov	a, dpl
      0040EA 60 03            [24]  832 	jz	00270$
      0040EC 02 41 BE         [24]  833 	ljmp	00127$
      0040EF                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0040EF 0F               [12]  836 	inc	r7
      0040F0 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      0040F3 90 05 8E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040F6 74 07            [12]  840 	mov	a,#0x07
      0040F8 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      0040F9 90 EF 00         [24]  843 	mov	dptr,#0xef00
      0040FC 12 3E AF         [24]  844 	lcall	_write_page
      0040FF E5 82            [12]  845 	mov	a, dpl
      004101 70 03            [24]  846 	jnz	00273$
      004103 02 41 BE         [24]  847 	ljmp	00127$
      004106                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004106 90 05 8E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004109 74 08            [12]  851 	mov	a,#0x08
      00410B F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00410C 7F 01            [12]  854 	mov	r7,#0x01
      00410E                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      00410E 12 45 65         [24]  857 	lcall	_ak820_outline_0043
      004111 FE               [12]  858 	mov	r6,a
      004112 60 23            [24]  859 	jz	00133$
      004114 8F 05            [24]  860 	mov	ar5,r7
      004116 7C 00            [12]  861 	mov	r4,#0x00
      004118 74 40            [12]  862 	mov	a,#0x40
      00411A 2D               [12]  863 	add	a, r5
      00411B FD               [12]  864 	mov	r5,a
      00411C 74 EF            [12]  865 	mov	a,#0xef
      00411E 3C               [12]  866 	addc	a, r4
      00411F FC               [12]  867 	mov	r4,a
      004120 90 05 06         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      004123 EE               [12]  869 	mov	a,r6
      004124 F0               [24]  870 	movx	@dptr,a
      004125 8D 82            [24]  871 	mov	dpl, r5
      004127 8C 83            [24]  872 	mov	dph, r4
      004129 C0 07            [24]  873 	push	ar7
      00412B 12 3C A7         [24]  874 	lcall	_ak820_flash_program
      00412E E5 82            [12]  875 	mov	a, dpl
      004130 D0 07            [24]  876 	pop	ar7
      004132 70 03            [24]  877 	jnz	00275$
      004134 02 41 BE         [24]  878 	ljmp	00127$
      004137                        879 00275$:
      004137                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004137 0F               [12]  882 	inc	r7
      004138 BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      00413B 90 05 8E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00413E 74 09            [12]  886 	mov	a,#0x09
      004140 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004141 7F 01            [12]  889 	mov	r7,#0x01
      004143                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      004143 12 45 71         [24]  892 	lcall	_ak820_outline_0053
      004146 12 3B 3A         [24]  893 	lcall	_ak820_flash_read
      004149 AE 82            [24]  894 	mov	r6, dpl
      00414B 12 45 65         [24]  895 	lcall	_ak820_outline_0043
      00414E FD               [12]  896 	mov	r5,a
      00414F EE               [12]  897 	mov	a,r6
      004150 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004153 0F               [12]  900 	inc	r7
      004154 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004157 90 05 8E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00415A 74 0A            [12]  904 	mov	a,#0x0a
      00415C F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      00415D 90 05 85         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004160 E0               [24]  908 	movx	a,@dptr
      004161 90 05 06         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      004164 F0               [24]  910 	movx	@dptr,a
      004165 90 EF 40         [24]  911 	mov	dptr,#0xef40
      004168 12 3C A7         [24]  912 	lcall	_ak820_flash_program
      00416B E5 82            [12]  913 	mov	a, dpl
      00416D 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      00416F 90 05 8E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004172 74 0B            [12]  917 	mov	a,#0x0b
      004174 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      004175 90 EF 40         [24]  920 	mov	dptr,#0xef40
      004178 12 3B 3A         [24]  921 	lcall	_ak820_flash_read
      00417B AF 82            [24]  922 	mov	r7, dpl
      00417D 90 05 85         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004180 E0               [24]  924 	movx	a,@dptr
      004181 FE               [12]  925 	mov	r6,a
      004182 EF               [12]  926 	mov	a,r7
      004183 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      004186 90 05 8E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004189 74 0C            [12]  930 	mov	a,#0x0c
      00418B F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      00418C 90 05 6D         [24]  933 	mov	dptr,#_cached_page
      00418F E0               [24]  934 	movx	a,@dptr
      004190 FE               [12]  935 	mov	r6,a
      004191 E4               [12]  936 	clr	a
      004192 C3               [12]  937 	clr	c
      004193 CE               [12]  938 	xch	a,r6
      004194 13               [12]  939 	rrc	a
      004195 CE               [12]  940 	xch	a,r6
      004196 13               [12]  941 	rrc	a
      004197 A2 E0            [12]  942 	mov	c,acc.0
      004199 CE               [12]  943 	xch	a,r6
      00419A 13               [12]  944 	rrc	a
      00419B CE               [12]  945 	xch	a,r6
      00419C 13               [12]  946 	rrc	a
      00419D CE               [12]  947 	xch	a,r6
      00419E 24 C7            [12]  948 	add	a,#0xc7
      0041A0 FF               [12]  949 	mov	r7,a
      0041A1 12 3A D7         [24]  950 	lcall	_ak820_outline_0120
      0041A4 12 3E AF         [24]  951 	lcall	_write_page
      0041A7 E5 82            [12]  952 	mov	a, dpl
      0041A9 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041AB 90 05 8E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041AE 74 0D            [12]  956 	mov	a,#0x0d
      0041B0 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041B1 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0041B4 12 3C 47         [24]  960 	lcall	_ak820_flash_erase
      0041B7 E5 82            [12]  961 	mov	a, dpl
      0041B9 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0041BB C2 0B            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041BD 22               [24]  968 	ret
      0041BE                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041BE 90 05 8E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041C1 E0               [24]  972 	movx	a,@dptr
      0041C2 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041C4 02 3D CE         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0041C7                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041C7 90 05 6E         [24]  985 	mov	dptr,#_batch_depth
      0041CA E0               [24]  986 	movx	a,@dptr
      0041CB FF               [12]  987 	mov	r7,a
      0041CC BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      0041CF 75 82 0F         [24]  989 	mov	dpl, #0x0f
      0041D2 02 3D CE         [24]  990 	ljmp	_nvm_fail
      0041D5                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0041D5 90 05 6E         [24]  993 	mov	dptr,#_batch_depth
      0041D8 EF               [12]  994 	mov	a,r7
      0041D9 04               [12]  995 	inc	a
      0041DA F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      0041DB 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      0041DC                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      0041DC 90 05 6E         [24] 1008 	mov	dptr,#_batch_depth
      0041DF E0               [24] 1009 	movx	a,@dptr
      0041E0 FF               [12] 1010 	mov	r7,a
      0041E1 E0               [24] 1011 	movx	a,@dptr
      0041E2 60 06            [24] 1012 	jz	00102$
      0041E4 EF               [12] 1013 	mov	a,r7
      0041E5 14               [12] 1014 	dec	a
      0041E6 90 05 6E         [24] 1015 	mov	dptr,#_batch_depth
      0041E9 F0               [24] 1016 	movx	@dptr,a
      0041EA                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      0041EA 90 05 6E         [24] 1019 	mov	dptr,#_batch_depth
      0041ED E0               [24] 1020 	movx	a,@dptr
      0041EE 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      0041F0 02 40 74         [24] 1023 	ljmp	_ak820_nvm_flush
      0041F3                       1024 00105$:
      0041F3 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      0041F4                       1036 _load_page:
      0041F4 E5 82            [12] 1037 	mov	a,dpl
      0041F6 90 05 8F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      0041F9 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      0041FA 30 0A 17         [24] 1041 	jnb	_page_valid,00102$
      0041FD 90 05 6D         [24] 1042 	mov	dptr,#_cached_page
      004200 E0               [24] 1043 	movx	a,@dptr
      004201 FF               [12] 1044 	mov	r7,a
      004202 90 05 8F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      004205 E0               [24] 1046 	movx	a,@dptr
      004206 FE               [12] 1047 	mov	r6,a
      004207 EF               [12] 1048 	mov	a,r7
      004208 B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      00420B A2 0C            [12] 1050 	mov	c,_storage_failed
      00420D B3               [12] 1051 	cpl	c
      00420E 92 0E            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004210 12 3A FC         [24] 1053 	lcall	_ak820_outline_0159
      004213 22               [24] 1054 	ret
      004214                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004214 12 40 74         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004217 30 0C 04         [24] 1059 	jnb	_storage_failed,00119$
      00421A 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00421D 22               [24] 1062 	ret
      00421E                       1063 00119$:
      00421E 7F 00            [12] 1064 	mov	r7,#0x00
      004220                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004220 EF               [12] 1067 	mov	a,r7
      004221 24 2D            [12] 1068 	add	a, #_page_data
      004223 FD               [12] 1069 	mov	r5,a
      004224 E4               [12] 1070 	clr	a
      004225 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      004227 FE               [12] 1072 	mov	r6,a
      004228 90 05 8F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      00422B E0               [24] 1074 	movx	a,@dptr
      00422C FC               [12] 1075 	mov	r4,a
      00422D FA               [12] 1076 	mov	r2,a
      00422E E4               [12] 1077 	clr	a
      00422F C3               [12] 1078 	clr	c
      004230 CA               [12] 1079 	xch	a,r2
      004231 13               [12] 1080 	rrc	a
      004232 CA               [12] 1081 	xch	a,r2
      004233 13               [12] 1082 	rrc	a
      004234 A2 E0            [12] 1083 	mov	c,acc.0
      004236 CA               [12] 1084 	xch	a,r2
      004237 13               [12] 1085 	rrc	a
      004238 CA               [12] 1086 	xch	a,r2
      004239 13               [12] 1087 	rrc	a
      00423A CA               [12] 1088 	xch	a,r2
      00423B 24 C7            [12] 1089 	add	a,#0xc7
      00423D FB               [12] 1090 	mov	r3,a
      00423E 8F 01            [24] 1091 	mov	ar1,r7
      004240 89 00            [24] 1092 	mov	ar0,r1
      004242 79 00            [12] 1093 	mov	r1,#0x00
      004244 E8               [12] 1094 	mov	a,r0
      004245 2A               [12] 1095 	add	a, r2
      004246 FA               [12] 1096 	mov	r2,a
      004247 E9               [12] 1097 	mov	a,r1
      004248 3B               [12] 1098 	addc	a, r3
      004249 FB               [12] 1099 	mov	r3,a
      00424A 12 3A F7         [24] 1100 	lcall	_ak820_outline_0145
      00424D 12 3B 3A         [24] 1101 	lcall	_ak820_flash_read
      004250 AB 82            [24] 1102 	mov	r3, dpl
      004252 12 3A EC         [24] 1103 	lcall	_ak820_outline_0137
      004255 EB               [12] 1104 	mov	a,r3
      004256 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004257 0F               [12] 1107 	inc	r7
      004258 BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00425B 90 05 6D         [24] 1110 	mov	dptr,#_cached_page
      00425E EC               [12] 1111 	mov	a,r4
      00425F F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004260 D2 0A            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004262 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004265 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004266                       1129 _read_offset:
      004266 12 3A CD         [24] 1130 	lcall	_ak820_outline_0109
      004269 90 05 90         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00426C 12 3A D2         [24] 1132 	lcall	_ak820_outline_0110
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00426F 90 05 90         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004272 12 3A 8C         [24] 1135 	lcall	_ak820_outline_0052
      004275 C3               [12] 1136 	clr	c
      004276 94 28            [12] 1137 	subb	a,#0x28
      004278 40 04            [24] 1138 	jc	00102$
      00427A 75 82 00         [24] 1139 	mov	dpl, #0x00
      00427D 22               [24] 1140 	ret
      00427E                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00427E 30 0A 34         [24] 1143 	jnb	_page_valid,00104$
      004281 8E 04            [24] 1144 	mov	ar4,r6
      004283 EF               [12] 1145 	mov	a,r7
      004284 A2 E7            [12] 1146 	mov	c,acc.7
      004286 CC               [12] 1147 	xch	a,r4
      004287 33               [12] 1148 	rlc	a
      004288 CC               [12] 1149 	xch	a,r4
      004289 33               [12] 1150 	rlc	a
      00428A A2 E7            [12] 1151 	mov	c,acc.7
      00428C CC               [12] 1152 	xch	a,r4
      00428D 33               [12] 1153 	rlc	a
      00428E CC               [12] 1154 	xch	a,r4
      00428F 33               [12] 1155 	rlc	a
      004290 CC               [12] 1156 	xch	a,r4
      004291 54 03            [12] 1157 	anl	a,#0x03
      004293 FD               [12] 1158 	mov	r5,a
      004294 90 05 6D         [24] 1159 	mov	dptr,#_cached_page
      004297 E0               [24] 1160 	movx	a,@dptr
      004298 FA               [12] 1161 	mov	r2,a
      004299 7B 00            [12] 1162 	mov	r3,#0x00
      00429B EC               [12] 1163 	mov	a,r4
      00429C B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      00429F ED               [12] 1165 	mov	a,r5
      0042A0 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042A3 74 3F            [12] 1168 	mov	a,#0x3f
      0042A5 5E               [12] 1169 	anl	a,r6
      0042A6 7D 00            [12] 1170 	mov	r5,#0x00
      0042A8 24 2D            [12] 1171 	add	a, #_page_data
      0042AA F5 82            [12] 1172 	mov	dpl,a
      0042AC ED               [12] 1173 	mov	a,r5
      0042AD 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0042AF F5 83            [12] 1175 	mov	dph,a
      0042B1 E0               [24] 1176 	movx	a,@dptr
      0042B2 F5 82            [12] 1177 	mov	dpl,a
      0042B4 22               [24] 1178 	ret
      0042B5                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042B5 74 C7            [12] 1181 	mov	a,#0xc7
      0042B7 2F               [12] 1182 	add	a, r7
      0042B8 FF               [12] 1183 	mov	r7,a
      0042B9 12 3A D7         [24] 1184 	lcall	_ak820_outline_0120
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042BC 02 3B 3A         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0042BF                       1196 _eeprom_read_byte:
      0042BF C0 07            [24] 1197 	push	ar7
      0042C1 C0 06            [24] 1198 	push	ar6
      0042C3 12 45 5E         [24] 1199 	lcall	_ak820_outline_0036
      0042C6 90 05 92         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042C9 12 3A 6A         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042CC 90 05 92         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042CF 12 3A 3F         [24] 1204 	lcall	_ak820_outline_0005
      0042D2 C0 06            [24] 1205 	push	ar6
      0042D4 C0 05            [24] 1206 	push	ar5
      0042D6 C0 04            [24] 1207 	push	ar4
      0042D8 C0 03            [24] 1208 	push	ar3
      0042DA C0 02            [24] 1209 	push	ar2
      0042DC C0 01            [24] 1210 	push	ar1
      0042DE C0 00            [24] 1211 	push	ar0
      0042E0 12 42 66         [24] 1212 	lcall	_read_offset
      0042E3 AF 82            [24] 1213 	mov	r7, dpl
      0042E5 D0 00            [24] 1214 	pop	ar0
      0042E7 D0 01            [24] 1215 	pop	ar1
      0042E9 D0 02            [24] 1216 	pop	ar2
      0042EB D0 03            [24] 1217 	pop	ar3
      0042ED D0 04            [24] 1218 	pop	ar4
      0042EF D0 05            [24] 1219 	pop	ar5
      0042F1 D0 06            [24] 1220 	pop	ar6
      0042F3 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0042F5 D0 06            [24] 1223 	pop	ar6
      0042F7 D0 07            [24] 1224 	pop	ar7
      0042F9 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0042FA                       1239 _ak820_eeprom_read_block_xdata:
      0042FA 12 3A CD         [24] 1240 	lcall	_ak820_outline_0109
      0042FD 90 05 9A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004300 12 3A D2         [24] 1242 	lcall	_ak820_outline_0110
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004303 90 05 95         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004306 12 3A 8C         [24] 1245 	lcall	_ak820_outline_0052
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004309 90 05 9A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00430C 12 3A A3         [24] 1248 	lcall	_ak820_outline_0061
      00430F 90 05 9C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004312 12 3A A9         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004315 90 05 98         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004318 12 3A A3         [24] 1253 	lcall	_ak820_outline_0061
      00431B                       1254 00103$:
      00431B 8C 02            [24] 1255 	mov	ar2,r4
      00431D 8D 03            [24] 1256 	mov	ar3,r5
      00431F 1C               [12] 1257 	dec	r4
      004320 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      004323 1D               [12] 1259 	dec	r5
      004324                       1260 00130$:
      004324 EA               [12] 1261 	mov	a,r2
      004325 4B               [12] 1262 	orl	a,r3
      004326 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004328 8E 02            [24] 1265 	mov	ar2,r6
      00432A 8F 03            [24] 1266 	mov	ar3,r7
      00432C 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      00432E 2B               [12] 1268 	add	a,r3
      00432F 50 17            [24] 1269 	jnc	00102$
      004331 90 05 9C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004334 12 45 95         [24] 1271 	lcall	_ak820_outline_0105
      004337 12 3A F7         [24] 1272 	lcall	_ak820_outline_0145
      00433A E4               [12] 1273 	clr	a
      00433B F0               [24] 1274 	movx	@dptr,a
      00433C 90 05 9C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00433F 04               [12] 1276 	inc	a
      004340 2A               [12] 1277 	add	a, r2
      004341 F0               [24] 1278 	movx	@dptr,a
      004342 E4               [12] 1279 	clr	a
      004343 3B               [12] 1280 	addc	a, r3
      004344 A3               [24] 1281 	inc	dptr
      004345 F0               [24] 1282 	movx	@dptr,a
      004346 80 D3            [24] 1283 	sjmp	00103$
      004348                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004348 90 05 9C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00434B 12 45 95         [24] 1287 	lcall	_ak820_outline_0105
      00434E 12 3A D7         [24] 1288 	lcall	_ak820_outline_0120
      004351 C0 07            [24] 1289 	push	ar7
      004353 C0 06            [24] 1290 	push	ar6
      004355 C0 05            [24] 1291 	push	ar5
      004357 C0 04            [24] 1292 	push	ar4
      004359 C0 03            [24] 1293 	push	ar3
      00435B C0 02            [24] 1294 	push	ar2
      00435D 12 42 66         [24] 1295 	lcall	_read_offset
      004360 A9 82            [24] 1296 	mov	r1, dpl
      004362 D0 02            [24] 1297 	pop	ar2
      004364 D0 03            [24] 1298 	pop	ar3
      004366 D0 04            [24] 1299 	pop	ar4
      004368 D0 05            [24] 1300 	pop	ar5
      00436A D0 06            [24] 1301 	pop	ar6
      00436C D0 07            [24] 1302 	pop	ar7
      00436E 12 3A F7         [24] 1303 	lcall	_ak820_outline_0145
      004371 E9               [12] 1304 	mov	a,r1
      004372 F0               [24] 1305 	movx	@dptr,a
      004373 90 05 9C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004376 74 01            [12] 1307 	mov	a,#0x01
      004378 2A               [12] 1308 	add	a, r2
      004379 F0               [24] 1309 	movx	@dptr,a
      00437A E4               [12] 1310 	clr	a
      00437B 3B               [12] 1311 	addc	a, r3
      00437C A3               [24] 1312 	inc	dptr
      00437D F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00437E 0E               [12] 1315 	inc	r6
      00437F BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      004382 0F               [12] 1317 	inc	r7
      004383 80 96            [24] 1318 	sjmp	00103$
      004385                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004385 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      004386                       1337 _ak820_eeprom_write_block_xdata:
      004386 12 3A CD         [24] 1338 	lcall	_ak820_outline_0109
      004389 90 05 A3         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00438C 12 3A D2         [24] 1340 	lcall	_ak820_outline_0110
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00438F 90 05 9E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004392 12 3A 8C         [24] 1343 	lcall	_ak820_outline_0052
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004395 90 05 A3         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004398 12 3A A3         [24] 1346 	lcall	_ak820_outline_0061
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00439B 8E 02            [24] 1348 	mov	ar2,r6
      00439D 8F 03            [24] 1349 	mov	ar3,r7
      00439F C3               [12] 1350 	clr	c
      0043A0 E4               [12] 1351 	clr	a
      0043A1 9A               [12] 1352 	subb	a,r2
      0043A2 74 28            [12] 1353 	mov	a,#0x28
      0043A4 9B               [12] 1354 	subb	a,r3
      0043A5 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0043A7 E4               [12] 1357 	clr	a
      0043A8 C3               [12] 1358 	clr	c
      0043A9 9E               [12] 1359 	subb	a,r6
      0043AA FA               [12] 1360 	mov	r2,a
      0043AB 74 28            [12] 1361 	mov	a,#0x28
      0043AD 9F               [12] 1362 	subb	a,r7
      0043AE FB               [12] 1363 	mov	r3,a
      0043AF 90 05 A1         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043B2 12 3A C7         [24] 1365 	lcall	_ak820_outline_0104
      0043B5 C3               [12] 1366 	clr	c
      0043B6 EA               [12] 1367 	mov	a,r2
      0043B7 98               [12] 1368 	subb	a,r0
      0043B8 EB               [12] 1369 	mov	a,r3
      0043B9 99               [12] 1370 	subb	a,r1
      0043BA 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0043BC                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043BC 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043BF 02 3D CE         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043C2                       1379 00125$:
      0043C2 90 05 A1         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043C5 12 45 95         [24] 1381 	lcall	_ak820_outline_0105
      0043C8                       1382 00108$:
      0043C8 8A 00            [24] 1383 	mov	ar0,r2
      0043CA 8B 01            [24] 1384 	mov	ar1,r3
      0043CC 1A               [12] 1385 	dec	r2
      0043CD BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      0043D0 1B               [12] 1387 	dec	r3
      0043D1                       1388 00159$:
      0043D1 E8               [12] 1389 	mov	a,r0
      0043D2 49               [12] 1390 	orl	a,r1
      0043D3 70 03            [24] 1391 	jnz	00160$
      0043D5 02 44 5F         [24] 1392 	ljmp	00110$
      0043D8                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0043D8 C0 02            [24] 1395 	push	ar2
      0043DA C0 03            [24] 1396 	push	ar3
      0043DC 12 45 8F         [24] 1397 	lcall	_ak820_outline_0096
      0043DF F9               [12] 1398 	mov	r1,a
      0043E0 A3               [24] 1399 	inc	dptr
      0043E1 12 45 B8         [24] 1400 	lcall	_ak820_outline_0151
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      0043E4 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      0043E6 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      0043E8 A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0043EA E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0043EC A2 E7            [12] 1406 	mov	c,acc.7
      0043EE C8               [12] 1407 	xch	a,r0
      0043EF 33               [12] 1408 	rlc	a
      0043F0 C8               [12] 1409 	xch	a,r0
      0043F1 33               [12] 1410 	rlc	a
      0043F2 A2 E7            [12] 1411 	mov	c,acc.7
      0043F4 C8               [12] 1412 	xch	a,r0
      0043F5 33               [12] 1413 	rlc	a
      0043F6 C8               [12] 1414 	xch	a,r0
      0043F7 33               [12] 1415 	rlc	a
      0043F8 C8               [12] 1416 	xch	a,r0
      0043F9 54 03            [12] 1417 	anl	a,#0x03
      0043FB FB               [12] 1418 	mov	r3,a
      0043FC 88 82            [24] 1419 	mov	dpl, r0
      0043FE C0 07            [24] 1420 	push	ar7
      004400 C0 06            [24] 1421 	push	ar6
      004402 C0 05            [24] 1422 	push	ar5
      004404 C0 04            [24] 1423 	push	ar4
      004406 C0 03            [24] 1424 	push	ar3
      004408 C0 02            [24] 1425 	push	ar2
      00440A C0 01            [24] 1426 	push	ar1
      00440C 12 41 F4         [24] 1427 	lcall	_load_page
      00440F E5 82            [12] 1428 	mov	a, dpl
      004411 D0 01            [24] 1429 	pop	ar1
      004413 D0 02            [24] 1430 	pop	ar2
      004415 D0 03            [24] 1431 	pop	ar3
      004417 D0 04            [24] 1432 	pop	ar4
      004419 D0 05            [24] 1433 	pop	ar5
      00441B D0 06            [24] 1434 	pop	ar6
      00441D D0 07            [24] 1435 	pop	ar7
      00441F D0 03            [24] 1436 	pop	ar3
      004421 D0 02            [24] 1437 	pop	ar2
      004423 70 01            [24] 1438 	jnz	00105$
      004425 22               [24] 1439 	ret
      004426                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004426 C0 06            [24] 1442 	push	ar6
      004428 C0 07            [24] 1443 	push	ar7
      00442A 74 3F            [12] 1444 	mov	a,#0x3f
      00442C 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00442E 7F 00            [12] 1446 	mov	r7,#0x00
      004430 24 2D            [12] 1447 	add	a, #_page_data
      004432 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004434 EF               [12] 1449 	mov	a,r7
      004435 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      004437 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004439 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00443C 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00443F E0               [24] 1454 	movx	a,@dptr
      004440 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      004443 D0 07            [24] 1456 	pop	ar7
      004445 D0 06            [24] 1457 	pop	ar6
      004447 80 0E            [24] 1458 	sjmp	00107$
      004449                       1459 00162$:
      004449 D0 07            [24] 1460 	pop	ar7
      00444B D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00444D 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004450 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004453 E9               [12] 1465 	mov	a,r1
      004454 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004455 D2 0B            [12] 1469 	setb	_page_dirty
      004457                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004457 0E               [12] 1472 	inc	r6
      004458 BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00445B 0F               [12] 1474 	inc	r7
      00445C                       1475 00163$:
      00445C 02 43 C8         [24] 1476 	ljmp	00108$
      00445F                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00445F 90 05 6E         [24] 1479 	mov	dptr,#_batch_depth
      004462 E0               [24] 1480 	movx	a,@dptr
      004463 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004465 02 40 74         [24] 1483 	ljmp	_ak820_nvm_flush
      004468                       1484 00113$:
      004468 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      004469                       1503 _ak820_eeprom_update_block_xdata:
      004469 12 3A CD         [24] 1504 	lcall	_ak820_outline_0109
      00446C 90 05 AA         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00446F 12 3A D2         [24] 1506 	lcall	_ak820_outline_0110
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004472 90 05 AA         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004475 12 3A 8C         [24] 1509 	lcall	_ak820_outline_0052
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004478 90 05 A5         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00447B E0               [24] 1512 	movx	a,@dptr
      00447C F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00447E A3               [24] 1514 	inc	dptr
      00447F E0               [24] 1515 	movx	a,@dptr
      004480 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004482 A3               [24] 1517 	inc	dptr
      004483 E0               [24] 1518 	movx	a,@dptr
      004484 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004486 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004488 AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00448A E4               [12] 1523 	clr	a
      00448B F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00448D F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00448F                       1526 00105$:
      00448F 90 05 A8         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004492 E0               [24] 1528 	movx	a,@dptr
      004493 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004495 A3               [24] 1530 	inc	dptr
      004496 E0               [24] 1531 	movx	a,@dptr
      004497 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004499 C3               [12] 1533 	clr	c
      00449A E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00449C 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00449E E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044A0 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044A2 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044A4 89 00            [24] 1540 	mov	ar0,r1
      0044A6 8A 05            [24] 1541 	mov	ar5,r2
      0044A8 E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044AA 28               [12] 1543 	add	a, r0
      0044AB F8               [12] 1544 	mov	r0,a
      0044AC E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044AE 3D               [12] 1546 	addc	a, r5
      0044AF FD               [12] 1547 	mov	r5,a
      0044B0 88 82            [24] 1548 	mov	dpl, r0
      0044B2 8D 83            [24] 1549 	mov	dph, r5
      0044B4 C0 07            [24] 1550 	push	ar7
      0044B6 C0 06            [24] 1551 	push	ar6
      0044B8 C0 02            [24] 1552 	push	ar2
      0044BA C0 01            [24] 1553 	push	ar1
      0044BC 12 42 66         [24] 1554 	lcall	_read_offset
      0044BF AD 82            [24] 1555 	mov	r5, dpl
      0044C1 D0 01            [24] 1556 	pop	ar1
      0044C3 D0 02            [24] 1557 	pop	ar2
      0044C5 D0 06            [24] 1558 	pop	ar6
      0044C7 D0 07            [24] 1559 	pop	ar7
      0044C9 E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044CB 2E               [12] 1561 	add	a, r6
      0044CC F5 82            [12] 1562 	mov	dpl,a
      0044CE E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044D0 3F               [12] 1564 	addc	a, r7
      0044D1 F5 83            [12] 1565 	mov	dph,a
      0044D3 E0               [24] 1566 	movx	a,@dptr
      0044D4 FC               [12] 1567 	mov	r4,a
      0044D5 ED               [12] 1568 	mov	a,r5
      0044D6 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      0044D9 80 27            [24] 1570 	sjmp	00106$
      0044DB                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0044DB 90 05 AA         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0044DE E0               [24] 1574 	movx	a,@dptr
      0044DF F8               [12] 1575 	mov	r0,a
      0044E0 A3               [24] 1576 	inc	dptr
      0044E1 E0               [24] 1577 	movx	a,@dptr
      0044E2 FD               [12] 1578 	mov	r5,a
      0044E3 90 05 9E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0044E6 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044E8 F0               [24] 1581 	movx	@dptr,a
      0044E9 E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0044EB A3               [24] 1583 	inc	dptr
      0044EC F0               [24] 1584 	movx	@dptr,a
      0044ED E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0044EF A3               [24] 1586 	inc	dptr
      0044F0 F0               [24] 1587 	movx	@dptr,a
      0044F1 90 05 A1         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0044F4 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044F6 F0               [24] 1590 	movx	@dptr,a
      0044F7 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044F9 A3               [24] 1592 	inc	dptr
      0044FA F0               [24] 1593 	movx	@dptr,a
      0044FB 88 82            [24] 1594 	mov	dpl, r0
      0044FD 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0044FF 02 43 86         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      004502                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004502 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004504 E4               [12] 1601 	clr	a
      004505 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004508 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00450A 80 83            [24] 1604 	sjmp	00105$
      00450C                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00450C 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      00450D                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00450D 12 40 74         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004510 7F 00            [12] 1622 	mov	r7,#0x00
      004512                       1623 00111$:
      004512 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      004515 22               [24] 1625 	ret
      004516                       1626 00165$:
      004516 20 0C 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004519 8F 82            [24] 1629 	mov	dpl, r7
      00451B C0 07            [24] 1630 	push	ar7
      00451D 12 41 F4         [24] 1631 	lcall	_load_page
      004520 E5 82            [12] 1632 	mov	a, dpl
      004522 D0 07            [24] 1633 	pop	ar7
      004524 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004526 22               [24] 1636 	ret
      004527                       1637 00126$:
      004527 7E 00            [12] 1638 	mov	r6,#0x00
      004529                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004529 EE               [12] 1641 	mov	a,r6
      00452A 24 2D            [12] 1642 	add	a, #_page_data
      00452C FC               [12] 1643 	mov	r4,a
      00452D E4               [12] 1644 	clr	a
      00452E 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004530 FD               [12] 1646 	mov	r5,a
      004531 12 45 8F         [24] 1647 	lcall	_ak820_outline_0096
      004534 60 07            [24] 1648 	jz	00108$
      004536 12 3A E2         [24] 1649 	lcall	_ak820_outline_0126
      004539 E4               [12] 1650 	clr	a
      00453A F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      00453B D2 0B            [12] 1653 	setb	_page_dirty
      00453D                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00453D 0E               [12] 1656 	inc	r6
      00453E BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004541 C0 07            [24] 1659 	push	ar7
      004543 12 40 74         [24] 1660 	lcall	_ak820_nvm_flush
      004546 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004548 0F               [12] 1663 	inc	r7
      004549 80 C7            [24] 1664 	sjmp	00111$
      00454B                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00454B 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0031
                                   1679 	.globl _ak820_outline_0036
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0052
                                   1682 	.globl _ak820_outline_0053
                                   1683 	.globl _ak820_outline_0061
                                   1684 	.globl _ak820_outline_0065
                                   1685 	.globl _ak820_outline_0072
                                   1686 	.globl _ak820_outline_0079
                                   1687 	.globl _ak820_outline_0080
                                   1688 	.globl _ak820_outline_0086
                                   1689 	.globl _ak820_outline_0096
                                   1690 	.globl _ak820_outline_0104
                                   1691 	.globl _ak820_outline_0105
                                   1692 	.globl _ak820_outline_0107
                                   1693 	.globl _ak820_outline_0109
                                   1694 	.globl _ak820_outline_0110
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0124
                                   1697 	.globl _ak820_outline_0125
                                   1698 	.globl _ak820_outline_0126
                                   1699 	.globl _ak820_outline_0135
                                   1700 	.globl _ak820_outline_0137
                                   1701 	.globl _ak820_outline_0139
                                   1702 	.globl _ak820_outline_0144
                                   1703 	.globl _ak820_outline_0145
                                   1704 	.globl _ak820_outline_0151
                                   1705 	.globl _ak820_outline_0159
                                   1706 	.globl _ak820_outline_0161
                                   1707 	.globl _ak820_outline_0164
                                   1708 	.globl _ak820_outline_0165
                                   1709 	.globl _ak820_outline_0185
                                   1710 	.globl _ak820_outline_0186
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0011
      00454C                       1714 _ak820_outline_0011:
      00454C 8E 82            [24] 1715 	mov	dpl,r6
      00454E 8F 83            [24] 1716 	mov	dph,r7
      004550 A3               [24] 1717 	inc	dptr
      004551 A3               [24] 1718 	inc	dptr
      004552 A3               [24] 1719 	inc	dptr
      004553 A3               [24] 1720 	inc	dptr
      004554 A3               [24] 1721 	inc	dptr
      004555 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0031
      004556                       1726 _ak820_outline_0031:
      004556 F0               [24] 1727 	movx	@dptr,a
      004557 8E 82            [24] 1728 	mov	dpl,r6
      004559 8F 83            [24] 1729 	mov	dph,r7
      00455B A3               [24] 1730 	inc	dptr
      00455C A3               [24] 1731 	inc	dptr
      00455D 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      00455E                       1736 _ak820_outline_0036:
      00455E AF F0            [24] 1737 	mov	r7,b
      004560 AE 83            [24] 1738 	mov	r6,dph
      004562 E5 82            [12] 1739 	mov	a,dpl
      004564 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      004565                       1744 _ak820_outline_0043:
      004565 EF               [12] 1745 	mov	a,r7
      004566 24 85            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004568 F5 82            [12] 1747 	mov	dpl,a
      00456A E4               [12] 1748 	clr	a
      00456B 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00456D F5 83            [12] 1750 	mov	dph,a
      00456F E0               [24] 1751 	movx	a,@dptr
      004570 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      004571                       1756 _ak820_outline_0053:
      004571 8F 06            [24] 1757 	mov	ar6,r7
      004573 7D 00            [12] 1758 	mov	r5,#0x00
      004575 74 40            [12] 1759 	mov	a,#0x40
      004577 2E               [12] 1760 	add	a,r6
      004578 FE               [12] 1761 	mov	r6,a
      004579 74 EF            [12] 1762 	mov	a,#0xef
      00457B 3D               [12] 1763 	addc	a,r5
      00457C FD               [12] 1764 	mov	r5,a
      00457D 8E 82            [24] 1765 	mov	dpl,r6
      00457F 8D 83            [24] 1766 	mov	dph,r5
      004581 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0065
      004582                       1771 _ak820_outline_0065:
      004582 8D 82            [24] 1772 	mov	dpl,r5
      004584 8E 83            [24] 1773 	mov	dph,r6
      004586 EC               [12] 1774 	mov	a,r4
      004587 F0               [24] 1775 	movx	@dptr,a
      004588 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0079
      004589                       1780 _ak820_outline_0079:
      004589 F0               [24] 1781 	movx	@dptr,a
      00458A 8E 82            [24] 1782 	mov	dpl,r6
      00458C 8F 83            [24] 1783 	mov	dph,r7
      00458E 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0096
      00458F                       1788 _ak820_outline_0096:
      00458F 8C 82            [24] 1789 	mov	dpl,r4
      004591 8D 83            [24] 1790 	mov	dph,r5
      004593 E0               [24] 1791 	movx	a,@dptr
      004594 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0105
      004595                       1796 _ak820_outline_0105:
      004595 E0               [24] 1797 	movx	a,@dptr
      004596 FA               [12] 1798 	mov	r2,a
      004597 A3               [24] 1799 	inc	dptr
      004598 E0               [24] 1800 	movx	a,@dptr
      004599 FB               [12] 1801 	mov	r3,a
      00459A 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0107
      00459B                       1806 _ak820_outline_0107:
      00459B EF               [12] 1807 	mov	a,r7
      00459C 24 2D            [12] 1808 	add	a,#_page_data
      00459E F5 82            [12] 1809 	mov	dpl,a
      0045A0 E4               [12] 1810 	clr	a
      0045A1 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0045A3 F5 83            [12] 1812 	mov	dph,a
      0045A5 E0               [24] 1813 	movx	a,@dptr
      0045A6 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0135
      0045A7                       1818 _ak820_outline_0135:
      0045A7 AE 82            [24] 1819 	mov	r6,dpl
      0045A9 AF 83            [24] 1820 	mov	r7,dph
      0045AB 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0139
      0045AC                       1825 _ak820_outline_0139:
      0045AC 2E               [12] 1826 	add	a,r6
      0045AD FE               [12] 1827 	mov	r6,a
      0045AE E4               [12] 1828 	clr	a
      0045AF 3F               [12] 1829 	addc	a,r7
      0045B0 FF               [12] 1830 	mov	r7,a
      0045B1 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0144
      0045B2                       1835 _ak820_outline_0144:
      0045B2 42 05            [12] 1836 	orl	ar5,a
      0045B4 EA               [12] 1837 	mov	a,r2
      0045B5 42 04            [12] 1838 	orl	ar4,a
      0045B7 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0151
      0045B8                       1843 _ak820_outline_0151:
      0045B8 AC 82            [24] 1844 	mov	r4,dpl
      0045BA AD 83            [24] 1845 	mov	r5,dph
      0045BC 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0161
      0045BD                       1850 _ak820_outline_0161:
      0045BD 8F 82            [24] 1851 	mov	dpl,r7
      0045BF 8E 83            [24] 1852 	mov	dph,r6
      0045C1 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0164
      0045C2                       1857 _ak820_outline_0164:
      0045C2 2E               [12] 1858 	add	a,r6
      0045C3 FC               [12] 1859 	mov	r4,a
      0045C4 E4               [12] 1860 	clr	a
      0045C5 3F               [12] 1861 	addc	a,r7
      0045C6 FD               [12] 1862 	mov	r5,a
      0045C7 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0165
      0045C8                       1867 _ak820_outline_0165:
      0045C8 ED               [12] 1868 	mov	a,r5
      0045C9 F0               [24] 1869 	movx	@dptr,a
      0045CA EE               [12] 1870 	mov	a,r6
      0045CB A3               [24] 1871 	inc	dptr
      0045CC F0               [24] 1872 	movx	@dptr,a
      0045CD 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0185
      0045CE                       1877 _ak820_outline_0185:
      0045CE 89 82            [24] 1878 	mov	dpl,r1
      0045D0 8A 83            [24] 1879 	mov	dph,r2
      0045D2 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0186
      0045D3                       1884 _ak820_outline_0186:
      0045D3 8C 82            [24] 1885 	mov	dpl,r4
      0045D5 8B 83            [24] 1886 	mov	dph,r3
      0045D7 22               [24] 1887 	ret
