                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007F1                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007F1                        556 	.ds 1
      0007F2                        557 _add_key_byte_PARM_2:
      0007F2                        558 	.ds 1
      0007F3                        559 _add_key_byte_report_arg_10000_144:
      0007F3                        560 	.ds 3
      0007F6                        561 _add_key_byte_empty_10000_145:
      0007F6                        562 	.ds 1
      0007F7                        563 _del_key_byte_PARM_2:
      0007F7                        564 	.ds 1
      0007F8                        565 _del_key_byte_report_arg_10000_156:
      0007F8                        566 	.ds 3
      0007FB                        567 _add_key_bit_PARM_2:
      0007FB                        568 	.ds 1
      0007FC                        569 _add_key_bit_report_arg_10000_162:
      0007FC                        570 	.ds 3
      0007FF                        571 _del_key_bit_PARM_2:
      0007FF                        572 	.ds 1
      000800                        573 _del_key_bit_report_arg_10000_167:
      000800                        574 	.ds 3
      000803                        575 _add_key_to_report_PARM_2:
      000803                        576 	.ds 1
      000804                        577 _add_key_to_report_report_arg_10000_172:
      000804                        578 	.ds 3
      000807                        579 _del_key_from_report_PARM_2:
      000807                        580 	.ds 1
      000808                        581 _del_key_from_report_report_arg_10000_176:
      000808                        582 	.ds 3
      00080B                        583 _clear_keys_from_report_report_arg_10000_180:
      00080B                        584 	.ds 3
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006D42                        636 _KEYCODE2CONSUMER:
      006D42 E5 82            [12]  637 	mov	a,dpl
      006D44 90 07 F1         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006D47 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006D48 E0               [24]  641 	movx	a,@dptr
      006D49 FF               [12]  642 	mov	r7,a
      006D4A BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006D4D                        644 00113$:
      006D4D 40 05            [24]  645 	jc	00101$
      006D4F EF               [12]  646 	mov	a,r7
      006D50 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006D52 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006D54                        650 00101$:
      006D54 90 00 00         [24]  651 	mov	dptr,#0x0000
      006D57 22               [24]  652 	ret
      006D58                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      006D58 EF               [12]  655 	mov	a,r7
      006D59 24 58            [12]  656 	add	a,#0x58
      006D5B FF               [12]  657 	mov	r7,a
      006D5C C2 D5            [12]  658 	clr	F0
      006D5E 75 F0 02         [24]  659 	mov	b,#0x02
      006D61 EF               [12]  660 	mov	a,r7
      006D62 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006D65 B2 D5            [12]  662 	cpl	F0
      006D67 F4               [12]  663 	cpl	a
      006D68 04               [12]  664 	inc	a
      006D69                        665 00116$:
      006D69 A4               [48]  666 	mul	ab
      006D6A 30 D5 03         [24]  667 	jnb	F0,00117$
      006D6D 12 6F 69         [24]  668 	lcall	_ak820_outline_0131
      006D70                        669 00117$:
      006D70 24 63            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006D72 F5 82            [12]  671 	mov	dpl,a
      006D74 74 B8            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006D76 12 56 C0         [24]  673 	lcall	_ak820_outline_0111
      006D79 FE               [12]  674 	mov	r6,a
      006D7A A3               [24]  675 	inc	dptr
      006D7B E4               [12]  676 	clr	a
      006D7C 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:54: }
      006D7D 8E 82            [24]  679 	mov	dpl,r6
      006D7F F5 83            [12]  680 	mov	dph,a
      006D81 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006D82                        695 _add_key_byte:
      006D82 12 43 06         [24]  696 	lcall	_ak820_outline_0036
      006D85 90 07 F3         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006D88 12 38 12         [24]  698 	lcall	_ak820_outline_0016
                                    699 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006D8B 90 07 F3         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006D8E 12 38 34         [24]  701 	lcall	_ak820_outline_0052
                                    702 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      006D91 90 07 F6         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006D94 74 FF            [12]  704 	mov	a,#0xff
      006D96 F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:209: }
      006D97 7D 00            [12]  707 	mov	r5,#0x00
      006D99                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006D99 C3               [12]  710 	clr	c
      006D9A ED               [12]  711 	mov	a,r5
      006D9B 64 80            [12]  712 	xrl	a,#0x80
      006D9D 94 86            [12]  713 	subb	a,#0x86
      006D9F 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      006DA1 12 6F 74         [24]  716 	lcall	_ak820_outline_0147
      006DA4 F5 82            [12]  717 	mov	dpl,a
      006DA6 E4               [12]  718 	clr	a
      006DA7 3C               [12]  719 	addc	a, r4
      006DA8 F5 83            [12]  720 	mov	dph,a
      006DAA E0               [24]  721 	movx	a,@dptr
      006DAB FC               [12]  722 	mov	r4,a
      006DAC 90 07 F2         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      006DAF E0               [24]  724 	movx	a,@dptr
      006DB0 FB               [12]  725 	mov	r3,a
      006DB1 EC               [12]  726 	mov	a,r4
      006DB2 B5 03 02         [24]  727 	cjne	a,ar3,00167$
      006DB5 80 13            [24]  728 	sjmp	00106$
      006DB7                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006DB7 90 07 F6         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      006DBA E0               [24]  732 	movx	a,@dptr
      006DBB FB               [12]  733 	mov	r3,a
      006DBC BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      006DBF EC               [12]  735 	mov	a,r4
      006DC0 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:200: empty = i;
      006DC2 90 07 F6         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      006DC5 ED               [12]  739 	mov	a,r5
      006DC6 F0               [24]  740 	movx	@dptr,a
      006DC7                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006DC7 0D               [12]  743 	inc	r5
      006DC8 80 CF            [24]  744 	sjmp	00112$
      006DCA                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      006DCA BD 06 1D         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      006DCD 90 07 F6         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      006DD0 E0               [24]  750 	movx	a,@dptr
      006DD1 FD               [12]  751 	mov	r5,a
      006DD2 BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      006DD5 22               [24]  753 	ret
      006DD6                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      006DD6 74 02            [12]  756 	mov	a,#0x02
      006DD8 12 43 54         [24]  757 	lcall	_ak820_outline_0139
      006DDB ED               [12]  758 	mov	a,r5
      006DDC 2E               [12]  759 	add	a, r6
      006DDD FD               [12]  760 	mov	r5,a
      006DDE E4               [12]  761 	clr	a
      006DDF 3F               [12]  762 	addc	a, r7
      006DE0 FC               [12]  763 	mov	r4,a
      006DE1 90 07 F2         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      006DE4 E0               [24]  765 	movx	a,@dptr
      006DE5 8D 82            [24]  766 	mov	dpl,r5
      006DE7 8C 83            [24]  767 	mov	dph,r4
      006DE9 F0               [24]  768 	movx	@dptr,a
      006DEA                        769 00114$:
                                    770 ;	tmk_core/protocol/report.c:209: }
      006DEA 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'del_key_byte'
                                    774 ;------------------------------------------------------------
                                    775 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    776 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    777 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    778 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    779 ;------------------------------------------------------------
                                    780 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function del_key_byte
                                    783 ;	-----------------------------------------
      006DEB                        784 _del_key_byte:
      006DEB 12 43 06         [24]  785 	lcall	_ak820_outline_0036
      006DEE 90 07 F8         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006DF1 12 38 12         [24]  787 	lcall	_ak820_outline_0016
                                    788 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006DF4 90 07 F8         [24]  789 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006DF7 12 38 34         [24]  790 	lcall	_ak820_outline_0052
                                    791 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006DFA 7D 00            [12]  792 	mov	r5,#0x00
      006DFC                        793 00105$:
      006DFC BD 06 00         [24]  794 	cjne	r5,#0x06,00131$
      006DFF                        795 00131$:
      006DFF 50 1A            [24]  796 	jnc	00107$
                                    797 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      006E01 12 6F 74         [24]  798 	lcall	_ak820_outline_0147
      006E04 FB               [12]  799 	mov	r3,a
      006E05 E4               [12]  800 	clr	a
      006E06 3C               [12]  801 	addc	a, r4
      006E07 12 48 65         [24]  802 	lcall	_ak820_outline_0056
      006E0A 90 07 F7         [24]  803 	mov	dptr,#_del_key_byte_PARM_2
      006E0D E0               [24]  804 	movx	a,@dptr
      006E0E F9               [12]  805 	mov	r1,a
      006E0F EA               [12]  806 	mov	a,r2
      006E10 B5 01 05         [24]  807 	cjne	a,ar1,00106$
                                    808 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      006E13 12 33 FC         [24]  809 	lcall	_ak820_outline_0125
      006E16 E4               [12]  810 	clr	a
      006E17 F0               [24]  811 	movx	@dptr,a
      006E18                        812 00106$:
                                    813 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006E18 0D               [12]  814 	inc	r5
      006E19 80 E1            [24]  815 	sjmp	00105$
      006E1B                        816 00107$:
                                    817 ;	tmk_core/protocol/report.c:249: }
      006E1B 22               [24]  818 	ret
                                    819 ;------------------------------------------------------------
                                    820 ;Allocation info for local variables in function 'add_key_bit'
                                    821 ;------------------------------------------------------------
                                    822 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    823 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    824 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    825 ;------------------------------------------------------------
                                    826 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    827 ;	-----------------------------------------
                                    828 ;	 function add_key_bit
                                    829 ;	-----------------------------------------
      006E1C                        830 _add_key_bit:
      006E1C 12 43 06         [24]  831 	lcall	_ak820_outline_0036
      006E1F 90 07 FC         [24]  832 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006E22 12 38 12         [24]  833 	lcall	_ak820_outline_0016
                                    834 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E25 90 07 FC         [24]  835 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006E28 12 38 34         [24]  836 	lcall	_ak820_outline_0052
                                    837 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006E2B 90 07 FB         [24]  838 	mov	dptr,#_add_key_bit_PARM_2
      006E2E E0               [24]  839 	movx	a,@dptr
      006E2F FD               [12]  840 	mov	r5,a
      006E30 12 56 F6         [24]  841 	lcall	_ak820_outline_0190
      006E33 FC               [12]  842 	mov	r4,a
      006E34 BC 1E 00         [24]  843 	cjne	r4,#0x1e,00112$
      006E37                        844 00112$:
      006E37 50 16            [24]  845 	jnc	00103$
                                    846 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      006E39 12 6F 45         [24]  847 	lcall	_ak820_outline_0035
      006E3C 80 02            [24]  848 	sjmp	00115$
      006E3E                        849 00114$:
      006E3E 25 E0            [12]  850 	add	a,acc
      006E40                        851 00115$:
      006E40 D5 F0 FB         [24]  852 	djnz	b,00114$
      006E43 FF               [12]  853 	mov	r7,a
      006E44 12 43 7B         [24]  854 	lcall	_ak820_outline_0186
      006E47 E0               [24]  855 	movx	a,@dptr
      006E48 42 07            [12]  856 	orl	ar7,a
      006E4A 12 43 7B         [24]  857 	lcall	_ak820_outline_0186
      006E4D EF               [12]  858 	mov	a,r7
      006E4E F0               [24]  859 	movx	@dptr,a
      006E4F                        860 00103$:
                                    861 ;	tmk_core/protocol/report.c:263: }
      006E4F 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'del_key_bit'
                                    865 ;------------------------------------------------------------
                                    866 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    867 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    868 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    869 ;------------------------------------------------------------
                                    870 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function del_key_bit
                                    873 ;	-----------------------------------------
      006E50                        874 _del_key_bit:
      006E50 12 43 06         [24]  875 	lcall	_ak820_outline_0036
      006E53 90 08 00         [24]  876 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006E56 12 38 12         [24]  877 	lcall	_ak820_outline_0016
                                    878 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E59 90 08 00         [24]  879 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006E5C 12 38 34         [24]  880 	lcall	_ak820_outline_0052
                                    881 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006E5F 90 07 FF         [24]  882 	mov	dptr,#_del_key_bit_PARM_2
      006E62 E0               [24]  883 	movx	a,@dptr
      006E63 FD               [12]  884 	mov	r5,a
      006E64 12 56 F6         [24]  885 	lcall	_ak820_outline_0190
      006E67 FC               [12]  886 	mov	r4,a
      006E68 BC 1E 00         [24]  887 	cjne	r4,#0x1e,00112$
      006E6B                        888 00112$:
      006E6B 50 17            [24]  889 	jnc	00103$
                                    890 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      006E6D 12 6F 45         [24]  891 	lcall	_ak820_outline_0035
      006E70 80 02            [24]  892 	sjmp	00115$
      006E72                        893 00114$:
      006E72 25 E0            [12]  894 	add	a,acc
      006E74                        895 00115$:
      006E74 D5 F0 FB         [24]  896 	djnz	b,00114$
      006E77 F4               [12]  897 	cpl	a
      006E78 FF               [12]  898 	mov	r7,a
      006E79 12 43 7B         [24]  899 	lcall	_ak820_outline_0186
      006E7C E0               [24]  900 	movx	a,@dptr
      006E7D 52 07            [12]  901 	anl	ar7,a
      006E7F 12 43 7B         [24]  902 	lcall	_ak820_outline_0186
      006E82 EF               [12]  903 	mov	a,r7
      006E83 F0               [24]  904 	movx	@dptr,a
      006E84                        905 00103$:
                                    906 ;	tmk_core/protocol/report.c:276: }
      006E84 22               [24]  907 	ret
                                    908 ;------------------------------------------------------------
                                    909 ;Allocation info for local variables in function 'add_key_to_report'
                                    910 ;------------------------------------------------------------
                                    911 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    912 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    913 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function add_key_to_report
                                    918 ;	-----------------------------------------
      006E85                        919 _add_key_to_report:
      006E85 12 43 06         [24]  920 	lcall	_ak820_outline_0036
      006E88 90 08 04         [24]  921 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006E8B 12 38 12         [24]  922 	lcall	_ak820_outline_0016
                                    923 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E8E 90 08 04         [24]  924 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006E91 12 38 34         [24]  925 	lcall	_ak820_outline_0052
                                    926 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      006E94 90 0D B6         [24]  927 	mov	dptr,#_keyboard_protocol
      006E97 E0               [24]  928 	movx	a,@dptr
      006E98 60 18            [24]  929 	jz	00102$
      006E9A 90 0A C2         [24]  930 	mov	dptr,#_keymap_config
      006E9D E0               [24]  931 	movx	a,@dptr
      006E9E 30 E7 11         [24]  932 	jnb	acc.7,00102$
                                    933 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      006EA1 12 6F 7E         [24]  934 	lcall	_ak820_outline_0153
      006EA4 90 08 03         [24]  935 	mov	dptr,#_add_key_to_report_PARM_2
      006EA7 E0               [24]  936 	movx	a,@dptr
      006EA8 90 07 FB         [24]  937 	mov	dptr,#_add_key_bit_PARM_2
      006EAB 12 6F 63         [24]  938 	lcall	_ak820_outline_0102
      006EAE 8D F0            [24]  939 	mov	b, r5
                                    940 ;	tmk_core/protocol/report.c:288: return;
      006EB0 C1 1C            [12]  941 	ajmp	_add_key_bit
      006EB2                        942 00102$:
                                    943 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      006EB2 7D 00            [12]  944 	mov	r5,#0x00
      006EB4 90 08 03         [24]  945 	mov	dptr,#_add_key_to_report_PARM_2
      006EB7 E0               [24]  946 	movx	a,@dptr
      006EB8 90 07 F2         [24]  947 	mov	dptr,#_add_key_byte_PARM_2
      006EBB F0               [24]  948 	movx	@dptr,a
      006EBC 12 6F 5C         [24]  949 	lcall	_ak820_outline_0050
                                    950 ;	tmk_core/protocol/report.c:292: }
      006EBF A1 82            [12]  951 	ajmp	_add_key_byte
                                    952 ;------------------------------------------------------------
                                    953 ;Allocation info for local variables in function 'del_key_from_report'
                                    954 ;------------------------------------------------------------
                                    955 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    956 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    957 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    958 ;------------------------------------------------------------
                                    959 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function del_key_from_report
                                    962 ;	-----------------------------------------
      006EC1                        963 _del_key_from_report:
      006EC1 12 43 06         [24]  964 	lcall	_ak820_outline_0036
      006EC4 90 08 08         [24]  965 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006EC7 12 38 12         [24]  966 	lcall	_ak820_outline_0016
                                    967 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006ECA 90 08 08         [24]  968 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006ECD 12 38 34         [24]  969 	lcall	_ak820_outline_0052
                                    970 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      006ED0 90 0D B6         [24]  971 	mov	dptr,#_keyboard_protocol
      006ED3 E0               [24]  972 	movx	a,@dptr
      006ED4 60 18            [24]  973 	jz	00102$
      006ED6 90 0A C2         [24]  974 	mov	dptr,#_keymap_config
      006ED9 E0               [24]  975 	movx	a,@dptr
      006EDA 30 E7 11         [24]  976 	jnb	acc.7,00102$
                                    977 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      006EDD 12 6F 7E         [24]  978 	lcall	_ak820_outline_0153
      006EE0 90 08 07         [24]  979 	mov	dptr,#_del_key_from_report_PARM_2
      006EE3 E0               [24]  980 	movx	a,@dptr
      006EE4 90 07 FF         [24]  981 	mov	dptr,#_del_key_bit_PARM_2
      006EE7 12 6F 63         [24]  982 	lcall	_ak820_outline_0102
      006EEA 8D F0            [24]  983 	mov	b, r5
                                    984 ;	tmk_core/protocol/report.c:303: return;
      006EEC C1 50            [24]  985 	ajmp	_del_key_bit
      006EEE                        986 00102$:
                                    987 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      006EEE 7D 00            [12]  988 	mov	r5,#0x00
      006EF0 90 08 07         [24]  989 	mov	dptr,#_del_key_from_report_PARM_2
      006EF3 E0               [24]  990 	movx	a,@dptr
      006EF4 90 07 F7         [24]  991 	mov	dptr,#_del_key_byte_PARM_2
      006EF7 F0               [24]  992 	movx	@dptr,a
      006EF8 12 6F 5C         [24]  993 	lcall	_ak820_outline_0050
                                    994 ;	tmk_core/protocol/report.c:307: }
      006EFB A1 EB            [12]  995 	ajmp	_del_key_byte
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    998 ;------------------------------------------------------------
                                    999 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                   1000 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function clear_keys_from_report
                                   1005 ;	-----------------------------------------
      006EFD                       1006 _clear_keys_from_report:
      006EFD 12 43 06         [24] 1007 	lcall	_ak820_outline_0036
      006F00 90 08 0B         [24] 1008 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006F03 12 38 12         [24] 1009 	lcall	_ak820_outline_0016
                                   1010 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F06 90 08 0B         [24] 1011 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006F09 12 38 34         [24] 1012 	lcall	_ak820_outline_0052
                                   1013 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      006F0C 90 0D B6         [24] 1014 	mov	dptr,#_keyboard_protocol
      006F0F E0               [24] 1015 	movx	a,@dptr
      006F10 60 1E            [24] 1016 	jz	00102$
      006F12 90 0A C2         [24] 1017 	mov	dptr,#_keymap_config
      006F15 E0               [24] 1018 	movx	a,@dptr
      006F16 30 E7 17         [24] 1019 	jnb	acc.7,00102$
                                   1020 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      006F19 74 02            [12] 1021 	mov	a,#0x02
      006F1B 12 43 6A         [24] 1022 	lcall	_ak820_outline_0164
      006F1E 7B 00            [12] 1023 	mov	r3,#0x00
      006F20 12 6F 85         [24] 1024 	lcall	_ak820_outline_0182
      006F23 74 1E            [12] 1025 	mov	a,#0x1e
      006F25 F0               [24] 1026 	movx	@dptr,a
      006F26 E4               [12] 1027 	clr	a
      006F27 A3               [24] 1028 	inc	dptr
      006F28 12 38 69         [24] 1029 	lcall	_ak820_outline_0103
      006F2B 8B F0            [24] 1030 	mov	b, r3
                                   1031 ;	tmk_core/protocol/report.c:319: return;
      006F2D 02 B7 54         [24] 1032 	ljmp	_memset
      006F30                       1033 00102$:
                                   1034 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      006F30 74 02            [12] 1035 	mov	a,#0x02
      006F32 12 43 54         [24] 1036 	lcall	_ak820_outline_0139
      006F35 7D 00            [12] 1037 	mov	r5,#0x00
      006F37 12 6F 85         [24] 1038 	lcall	_ak820_outline_0182
      006F3A 74 06            [12] 1039 	mov	a,#0x06
      006F3C 12 38 8F         [24] 1040 	lcall	_ak820_outline_0136
      006F3F 12 6F 5C         [24] 1041 	lcall	_ak820_outline_0050
                                   1042 ;	tmk_core/protocol/report.c:323: }
      006F42 02 B7 54         [24] 1043 	ljmp	_memset
                                   1044 	.area CSEG    (CODE)
                                   1045 	.area CONST   (CODE)
                                   1046 	.area CONST   (CODE)
      00B863                       1047 _KEYCODE2CONSUMER_usages_10000_118:
      00B863 E2 00                 1048 	.byte #0xe2, #0x00	; 226
      00B865 E9 00                 1049 	.byte #0xe9, #0x00	; 233
      00B867 EA 00                 1050 	.byte #0xea, #0x00	; 234
      00B869 B5 00                 1051 	.byte #0xb5, #0x00	; 181
      00B86B B6 00                 1052 	.byte #0xb6, #0x00	; 182
      00B86D B7 00                 1053 	.byte #0xb7, #0x00	; 183
      00B86F CD 00                 1054 	.byte #0xcd, #0x00	; 205
      00B871 83 01                 1055 	.byte #0x83, #0x01	; 387
      00B873 CC 00                 1056 	.byte #0xcc, #0x00	; 204
      00B875 8A 01                 1057 	.byte #0x8a, #0x01	; 394
      00B877 92 01                 1058 	.byte #0x92, #0x01	; 402
      00B879 94 01                 1059 	.byte #0x94, #0x01	; 404
      00B87B 21 02                 1060 	.byte #0x21, #0x02	; 545
      00B87D 23 02                 1061 	.byte #0x23, #0x02	; 547
      00B87F 24 02                 1062 	.byte #0x24, #0x02	; 548
      00B881 25 02                 1063 	.byte #0x25, #0x02	; 549
      00B883 26 02                 1064 	.byte #0x26, #0x02	; 550
      00B885 27 02                 1065 	.byte #0x27, #0x02	; 551
      00B887 2A 02                 1066 	.byte #0x2a, #0x02	; 554
      00B889 B3 00                 1067 	.byte #0xb3, #0x00	; 179
      00B88B B4 00                 1068 	.byte #0xb4, #0x00	; 180
      00B88D 6F 00                 1069 	.byte #0x6f, #0x00	; 111
      00B88F 70 00                 1070 	.byte #0x70, #0x00	; 112
      00B891 9F 01                 1071 	.byte #0x9f, #0x01	; 415
      00B893 CB 01                 1072 	.byte #0xcb, #0x01	; 459
      00B895 9F 02                 1073 	.byte #0x9f, #0x02	; 671
      00B897 A0 02                 1074 	.byte #0xa0, #0x02	; 672
                                   1075 	.area CSEG    (CODE)
                                   1076 	.area XINIT   (CODE)
                                   1077 	.area CABS    (ABS,CODE)
                                   1078 
                                   1079 ; Experimental exact instruction outlining.
                                   1080 	.globl _ak820_outline_0016
                                   1081 	.globl _ak820_outline_0035
                                   1082 	.globl _ak820_outline_0036
                                   1083 	.globl _ak820_outline_0050
                                   1084 	.globl _ak820_outline_0052
                                   1085 	.globl _ak820_outline_0056
                                   1086 	.globl _ak820_outline_0102
                                   1087 	.globl _ak820_outline_0103
                                   1088 	.globl _ak820_outline_0111
                                   1089 	.globl _ak820_outline_0125
                                   1090 	.globl _ak820_outline_0131
                                   1091 	.globl _ak820_outline_0136
                                   1092 	.globl _ak820_outline_0139
                                   1093 	.globl _ak820_outline_0147
                                   1094 	.globl _ak820_outline_0153
                                   1095 	.globl _ak820_outline_0164
                                   1096 	.globl _ak820_outline_0182
                                   1097 	.globl _ak820_outline_0186
                                   1098 	.globl _ak820_outline_0190
                                   1099 
                                   1100 	.area CSEG (CODE)
                                   1101 ; function ak820_outline_0035
      006F45                       1102 _ak820_outline_0035:
      006F45 74 02            [12] 1103 	mov	a,#0x02
      006F47 2E               [12] 1104 	add	a,r6
      006F48 FE               [12] 1105 	mov	r6,a
      006F49 E4               [12] 1106 	clr	a
      006F4A 3F               [12] 1107 	addc	a,r7
      006F4B FF               [12] 1108 	mov	r7,a
      006F4C EC               [12] 1109 	mov	a,r4
      006F4D 2E               [12] 1110 	add	a,r6
      006F4E FC               [12] 1111 	mov	r4,a
      006F4F E4               [12] 1112 	clr	a
      006F50 3F               [12] 1113 	addc	a,r7
      006F51 FB               [12] 1114 	mov	r3,a
      006F52 74 07            [12] 1115 	mov	a,#0x07
      006F54 5D               [12] 1116 	anl	a,r5
      006F55 F5 F0            [12] 1117 	mov	b,a
      006F57 05 F0            [12] 1118 	inc	b
      006F59 74 01            [12] 1119 	mov	a,#0x01
      006F5B 22               [24] 1120 	ret
                                   1121 
                                   1122 	.area CSEG (CODE)
                                   1123 ; function ak820_outline_0050
      006F5C                       1124 _ak820_outline_0050:
      006F5C 8E 82            [24] 1125 	mov	dpl,r6
      006F5E 8F 83            [24] 1126 	mov	dph,r7
      006F60 8D F0            [24] 1127 	mov	b,r5
      006F62 22               [24] 1128 	ret
                                   1129 
                                   1130 	.area CSEG (CODE)
                                   1131 ; function ak820_outline_0102
      006F63                       1132 _ak820_outline_0102:
      006F63 F0               [24] 1133 	movx	@dptr,a
      006F64 8B 82            [24] 1134 	mov	dpl,r3
      006F66 8C 83            [24] 1135 	mov	dph,r4
      006F68 22               [24] 1136 	ret
                                   1137 
                                   1138 	.area CSEG (CODE)
                                   1139 ; function ak820_outline_0131
      006F69                       1140 _ak820_outline_0131:
      006F69 F4               [12] 1141 	cpl	a
      006F6A 24 01            [12] 1142 	add	a,#0x01
      006F6C C5 F0            [12] 1143 	xch	a,b
      006F6E F4               [12] 1144 	cpl	a
      006F6F 34 00            [12] 1145 	addc	a,#0x00
      006F71 C5 F0            [12] 1146 	xch	a,b
      006F73 22               [24] 1147 	ret
                                   1148 
                                   1149 	.area CSEG (CODE)
                                   1150 ; function ak820_outline_0147
      006F74                       1151 _ak820_outline_0147:
      006F74 74 02            [12] 1152 	mov	a,#0x02
      006F76 2E               [12] 1153 	add	a,r6
      006F77 FB               [12] 1154 	mov	r3,a
      006F78 E4               [12] 1155 	clr	a
      006F79 3F               [12] 1156 	addc	a,r7
      006F7A FC               [12] 1157 	mov	r4,a
      006F7B ED               [12] 1158 	mov	a,r5
      006F7C 2B               [12] 1159 	add	a,r3
      006F7D 22               [24] 1160 	ret
                                   1161 
                                   1162 	.area CSEG (CODE)
                                   1163 ; function ak820_outline_0153
      006F7E                       1164 _ak820_outline_0153:
      006F7E 8E 03            [24] 1165 	mov	ar3,r6
      006F80 8F 04            [24] 1166 	mov	ar4,r7
      006F82 7D 00            [12] 1167 	mov	r5,#0x00
      006F84 22               [24] 1168 	ret
                                   1169 
                                   1170 	.area CSEG (CODE)
                                   1171 ; function ak820_outline_0182
      006F85                       1172 _ak820_outline_0182:
      006F85 90 0D AC         [24] 1173 	mov	dptr,#_memset_PARM_2
      006F88 E4               [12] 1174 	clr	a
      006F89 F0               [24] 1175 	movx	@dptr,a
      006F8A 90 0D AD         [24] 1176 	mov	dptr,#_memset_PARM_3
      006F8D 22               [24] 1177 	ret
