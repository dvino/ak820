                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000976                        580 _owned_mod_refs:
      000976                        581 	.ds 8
      00097E                        582 _owned_weak_refs:
      00097E                        583 	.ds 8
      000986                        584 _owned_mods:
      000986                        585 	.ds 1
      000987                        586 _owned_weak_mods:
      000987                        587 	.ds 1
      000988                        588 _macro_mods:
      000988                        589 	.ds 2
      00098A                        590 _ak820_macro_primitive::
      00098A                        591 	.ds 1
      00098B                        592 _ak820_macro_cancelled::
      00098B                        593 	.ds 1
      00098C                        594 _ak820_macro_change_PARM_2:
      00098C                        595 	.ds 1
      00098D                        596 _ak820_macro_change_PARM_3:
      00098D                        597 	.ds 1
      00098E                        598 _ak820_macro_change_bits_10000_293:
      00098E                        599 	.ds 2
      000990                        600 _change_owned_PARM_2:
      000990                        601 	.ds 1
      000991                        602 _change_owned_mods_10000_298:
      000991                        603 	.ds 1
      000992                        604 _change_owned_result_10001_302:
      000992                        605 	.ds 1
      000993                        606 _change_owned_bit_20001_303:
      000993                        607 	.ds 1
      000994                        608 _add_owned_mods_mods_10000_311:
      000994                        609 	.ds 1
      000995                        610 _del_owned_mods_mods_10000_313:
      000995                        611 	.ds 1
      000996                        612 _add_owned_weak_mods_mods_10000_315:
      000996                        613 	.ds 1
      000997                        614 _del_owned_weak_mods_mods_10000_317:
      000997                        615 	.ds 1
      000998                        616 _key_refs:
      000998                        617 	.ds 165
      000A3D                        618 _distinct_keys:
      000A3D                        619 	.ds 1
      000A3E                        620 _macro_keys:
      000A3E                        621 	.ds 21
      000A53                        622 _add_owned_key_code_10000_326:
      000A53                        623 	.ds 1
      000A54                        624 _del_owned_key_code_10000_341:
      000A54                        625 	.ds 1
      000A55                        626 _usage_refs:
      000A55                        627 	.ds 30
      000A73                        628 _usage_order:
      000A73                        629 	.ds 30
      000A91                        630 _usage_lengths:
      000A91                        631 	.ds 2
      000A93                        632 _macro_usages:
      000A93                        633 	.ds 4
      000A97                        634 _owned_usage_key_PARM_2:
      000A97                        635 	.ds 1
      000A98                        636 _owned_usage_key_code_10000_368:
      000A98                        637 	.ds 1
      000A99                        638 _owned_usage_key___200000085_20000_369:
      000A99                        639 	.ds 2
      000A9B                        640 _owned_usage_key_which_10000_369:
      000A9B                        641 	.ds 1
      000A9C                        642 _owned_usage_key_count_10000_369:
      000A9C                        643 	.ds 1
      000A9D                        644 _owned_usage_key_pos_30001_376:
      000A9D                        645 	.ds 1
      000A9E                        646 _owned_usage_key_key_40000_381:
      000A9E                        647 	.ds 1
      000A9F                        648 _send_keyboard_report_last_report_10001_388:
      000A9F                        649 	.ds 32
      000ABF                        650 _send_keyboard_report_changed_10001_388:
      000ABF                        651 	.ds 1
      000AC0                        652 _add_weak_mods_mods_10000_406:
      000AC0                        653 	.ds 1
      000AC1                        654 _del_weak_mods_mods_10000_408:
      000AC1                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC7                        664 _real_mods:
      000DC7                        665 	.ds 1
      000DC8                        666 _weak_mods:
      000DC8                        667 	.ds 1
      000DC9                        668 _actual_keyboard_report::
      000DC9                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007B09                        713 _ak820_macro_change:
      007B09 12 38 75         [24]  714 	lcall	_ak820_outline_0109
      007B0C 90 09 8E         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B0F 12 38 7A         [24]  716 	lcall	_ak820_outline_0110
                                    717 ;	quantum/action_util.c:57: if (!ak820_macro_primitive) return true;
      007B12 90 09 8A         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007B15 E0               [24]  719 	movx	a,@dptr
      007B16 70 04            [24]  720 	jnz	00102$
      007B18 75 82 01         [24]  721 	mov	dpl, #0x01
      007B1B 22               [24]  722 	ret
      007B1C                        723 00102$:
                                    724 ;	quantum/action_util.c:58: uint8_t mask = 1u << (index & 7);
      007B1C 90 09 8C         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007B1F E0               [24]  726 	movx	a,@dptr
      007B20 FF               [12]  727 	mov	r7,a
      007B21 74 07            [12]  728 	mov	a,#0x07
      007B23 5F               [12]  729 	anl	a,r7
      007B24 12 76 B4         [24]  730 	lcall	_ak820_outline_0063
      007B27 80 02            [24]  731 	sjmp	00123$
      007B29                        732 00122$:
      007B29 25 E0            [12]  733 	add	a,acc
      007B2B                        734 00123$:
      007B2B D5 F0 FB         [24]  735 	djnz	b,00122$
      007B2E FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:59: bits += index >> 3;
      007B2F EF               [12]  738 	mov	a,r7
      007B30 12 56 F3         [24]  739 	lcall	_ak820_outline_0190
      007B33 FF               [12]  740 	mov	r7,a
      007B34 90 09 8E         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B37 12 38 4B         [24]  742 	lcall	_ak820_outline_0061
      007B3A 90 09 8E         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B3D EF               [12]  744 	mov	a,r7
      007B3E 2C               [12]  745 	add	a, r4
      007B3F F0               [24]  746 	movx	@dptr,a
      007B40 E4               [12]  747 	clr	a
      007B41 3D               [12]  748 	addc	a, r5
      007B42 A3               [24]  749 	inc	dptr
      007B43 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:60: if (((*bits & mask) != 0) == pressed) return false;
      007B44 90 09 8E         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B47 E0               [24]  753 	movx	a,@dptr
      007B48 FD               [12]  754 	mov	r5,a
      007B49 A3               [24]  755 	inc	dptr
      007B4A E0               [24]  756 	movx	a,@dptr
      007B4B FF               [12]  757 	mov	r7,a
      007B4C 12 80 8D         [24]  758 	lcall	_ak820_outline_0191
      007B4F E0               [24]  759 	movx	a,@dptr
      007B50 FC               [12]  760 	mov	r4,a
      007B51 EE               [12]  761 	mov	a,r6
      007B52 5C               [12]  762 	anl	a,r4
      007B53 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007B56                        764 00124$:
      007B56 B3               [12]  765 	cpl	c
      007B57 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007B59 90 09 8D         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007B5C E0               [24]  768 	movx	a,@dptr
      007B5D FB               [12]  769 	mov	r3,a
      007B5E A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007B60 E4               [12]  771 	clr	a
      007B61 33               [12]  772 	rlc	a
      007B62 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007B65 75 82 00         [24]  774 	mov	dpl, #0x00
      007B68 22               [24]  775 	ret
      007B69                        776 00104$:
                                    777 ;	quantum/action_util.c:61: *bits ^= mask;
      007B69 EC               [12]  778 	mov	a,r4
      007B6A 62 06            [12]  779 	xrl	ar6,a
      007B6C 12 80 8D         [24]  780 	lcall	_ak820_outline_0191
      007B6F EE               [12]  781 	mov	a,r6
      007B70 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:62: return true;
      007B71 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:63: }
      007B74 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:64: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007B75                        805 _change_owned:
      007B75 E5 82            [12]  806 	mov	a,dpl
      007B77 90 09 91         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007B7A F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:65: uint8_t kind = mode >> 1;
      007B7B 90 09 90         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007B7E E0               [24]  811 	movx	a,@dptr
      007B7F FF               [12]  812 	mov	r7,a
      007B80 C3               [12]  813 	clr	c
      007B81 13               [12]  814 	rrc	a
      007B82 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:66: bool pressed = (mode & 1) != 0;
      007B83 53 07 01         [24]  817 	anl	ar7,#0x01
      007B86 EF               [12]  818 	mov	a,r7
      007B87 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007B8A                        820 00205$:
      007B8A 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007B8C B3               [12]  822 	cpl	c
      007B8D E4               [12]  823 	clr	a
      007B8E 33               [12]  824 	rlc	a
      007B8F F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:67: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007B91 EE               [12]  827 	mov	a,r6
      007B92 60 06            [24]  828 	jz	00121$
      007B94 7D 7E            [12]  829 	mov	r5,#_owned_weak_refs
      007B96 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007B98 80 04            [24]  831 	sjmp	00122$
      007B9A                        832 00121$:
      007B9A 7D 76            [12]  833 	mov	r5,#_owned_mod_refs
      007B9C 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007B9E                        835 00122$:
                                    836 ;	quantum/action_util.c:68: if (ak820_macro_primitive) {
      007B9E 90 09 8A         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007BA1 E0               [24]  838 	movx	a,@dptr
      007BA2 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:69: uint8_t old = macro_mods[kind];
      007BA4 EE               [12]  841 	mov	a,r6
      007BA5 24 88            [12]  842 	add	a, #_macro_mods
      007BA7 FB               [12]  843 	mov	r3,a
      007BA8 E4               [12]  844 	clr	a
      007BA9 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007BAB 12 48 65         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:70: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007BAE E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007BB0 60 0A            [24]  849 	jz	00123$
      007BB2 90 09 91         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007BB5 E0               [24]  851 	movx	a,@dptr
      007BB6 F9               [12]  852 	mov	r1,a
      007BB7 EA               [12]  853 	mov	a,r2
      007BB8 42 01            [12]  854 	orl	ar1,a
      007BBA 80 07            [24]  855 	sjmp	00124$
      007BBC                        856 00123$:
      007BBC 90 09 91         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007BBF E0               [24]  858 	movx	a,@dptr
      007BC0 F4               [12]  859 	cpl	a
      007BC1 5A               [12]  860 	anl	a,r2
      007BC2 F9               [12]  861 	mov	r1,a
      007BC3                        862 00124$:
      007BC3 12 33 FC         [24]  863 	lcall	_ak820_outline_0125
      007BC6 E9               [12]  864 	mov	a,r1
      007BC7 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:71: mods &= pressed ? ~old : old;
      007BC8 E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007BCA 60 06            [24]  868 	jz	00125$
      007BCC 74 FF            [12]  869 	mov	a,#0xff
      007BCE 6A               [12]  870 	xrl	a,r2
      007BCF FC               [12]  871 	mov	r4,a
      007BD0 80 02            [24]  872 	sjmp	00126$
      007BD2                        873 00125$:
      007BD2 8A 04            [24]  874 	mov	ar4,r2
      007BD4                        875 00126$:
      007BD4 90 09 91         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007BD7 E0               [24]  877 	movx	a,@dptr
      007BD8 5C               [12]  878 	anl	a,r4
      007BD9 F0               [24]  879 	movx	@dptr,a
      007BDA                        880 00102$:
                                    881 ;	quantum/action_util.c:73: uint8_t result = 0;
      007BDA 90 09 92         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007BDD E4               [12]  883 	clr	a
      007BDE F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BDF 90 09 93         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007BE2 04               [12]  887 	inc	a
      007BE3 F0               [24]  888 	movx	@dptr,a
      007BE4 90 09 91         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007BE7 E0               [24]  890 	movx	a,@dptr
      007BE8 FC               [12]  891 	mov	r4,a
      007BE9 7B 00            [12]  892 	mov	r3,#0x00
      007BEB                        893 00117$:
      007BEB BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007BEE                        895 00210$:
      007BEE 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:75: if (mods & bit) {
      007BF0 90 09 93         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007BF3 E0               [24]  899 	movx	a,@dptr
      007BF4 5C               [12]  900 	anl	a,r4
      007BF5 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:76: if (pressed) ++refs[i];
      007BF7 E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007BF9 60 0C            [24]  904 	jz	00106$
      007BFB EB               [12]  905 	mov	a,r3
      007BFC 2D               [12]  906 	add	a, r5
      007BFD 12 38 1A         [24]  907 	lcall	_ak820_outline_0017
      007C00 F8               [12]  908 	mov	r0,a
      007C01 08               [12]  909 	inc	r0
      007C02 12 80 4A         [24]  910 	lcall	_ak820_outline_0064
      007C05 80 0C            [24]  911 	sjmp	00109$
      007C07                        912 00106$:
                                    913 ;	quantum/action_util.c:77: else if (refs[i]) --refs[i];
      007C07 EB               [12]  914 	mov	a,r3
      007C08 2D               [12]  915 	add	a, r5
      007C09 12 38 1A         [24]  916 	lcall	_ak820_outline_0017
      007C0C F8               [12]  917 	mov	r0,a
      007C0D 60 04            [24]  918 	jz	00109$
      007C0F 18               [12]  919 	dec	r0
      007C10 12 80 4A         [24]  920 	lcall	_ak820_outline_0064
      007C13                        921 00109$:
                                    922 ;	quantum/action_util.c:79: if (refs[i]) result |= bit;
      007C13 EB               [12]  923 	mov	a,r3
      007C14 2D               [12]  924 	add	a, r5
      007C15 12 38 1A         [24]  925 	lcall	_ak820_outline_0017
      007C18 60 0B            [24]  926 	jz	00118$
      007C1A 90 09 93         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007C1D E0               [24]  928 	movx	a,@dptr
      007C1E FA               [12]  929 	mov	r2,a
      007C1F 90 09 92         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007C22 E0               [24]  931 	movx	a,@dptr
      007C23 4A               [12]  932 	orl	a,r2
      007C24 F0               [24]  933 	movx	@dptr,a
      007C25                        934 00118$:
                                    935 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C25 0B               [12]  936 	inc	r3
      007C26 90 09 93         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007C29 E0               [24]  938 	movx	a,@dptr
      007C2A 25 E0            [12]  939 	add	a,acc
      007C2C F0               [24]  940 	movx	@dptr,a
      007C2D 80 BC            [24]  941 	sjmp	00117$
      007C2F                        942 00112$:
                                    943 ;	quantum/action_util.c:81: if (kind) owned_weak_mods = result;
      007C2F EE               [12]  944 	mov	a,r6
      007C30 60 09            [24]  945 	jz	00114$
      007C32 90 09 92         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007C35 E0               [24]  947 	movx	a,@dptr
      007C36 90 09 87         [24]  948 	mov	dptr,#_owned_weak_mods
      007C39 F0               [24]  949 	movx	@dptr,a
      007C3A 22               [24]  950 	ret
      007C3B                        951 00114$:
                                    952 ;	quantum/action_util.c:82: else owned_mods = result;
      007C3B 90 09 92         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007C3E E0               [24]  954 	movx	a,@dptr
      007C3F 90 09 86         [24]  955 	mov	dptr,#_owned_mods
      007C42 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:83: }
      007C43 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:84: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007C44                        968 _add_owned_mods:
      007C44 E5 82            [12]  969 	mov	a,dpl
      007C46 90 09 94         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007C49 12 80 6A         [24]  971 	lcall	_ak820_outline_0119
      007C4C 74 01            [12]  972 	mov	a,#0x01
      007C4E F0               [24]  973 	movx	@dptr,a
      007C4F 8F 82            [24]  974 	mov	dpl, r7
      007C51 61 75            [12]  975 	ajmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:85: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007C53                        985 _del_owned_mods:
      007C53 E5 82            [12]  986 	mov	a,dpl
      007C55 90 09 95         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007C58 12 80 6A         [24]  988 	lcall	_ak820_outline_0119
      007C5B E4               [12]  989 	clr	a
      007C5C F0               [24]  990 	movx	@dptr,a
      007C5D 8F 82            [24]  991 	mov	dpl, r7
      007C5F 61 75            [12]  992 	ajmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:86: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007C61                       1002 _add_owned_weak_mods:
      007C61 E5 82            [12] 1003 	mov	a,dpl
      007C63 90 09 96         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007C66 12 80 6A         [24] 1005 	lcall	_ak820_outline_0119
      007C69 74 03            [12] 1006 	mov	a,#0x03
      007C6B F0               [24] 1007 	movx	@dptr,a
      007C6C 8F 82            [24] 1008 	mov	dpl, r7
      007C6E 61 75            [12] 1009 	ajmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:87: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007C70                       1019 _del_owned_weak_mods:
      007C70 E5 82            [12] 1020 	mov	a,dpl
      007C72 90 09 97         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007C75 12 80 6A         [24] 1022 	lcall	_ak820_outline_0119
      007C78 74 02            [12] 1023 	mov	a,#0x02
      007C7A F0               [24] 1024 	movx	@dptr,a
      007C7B 8F 82            [24] 1025 	mov	dpl, r7
      007C7D 61 75            [12] 1026 	ajmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:88: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007C7F                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:89: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007C7F 7F 00            [12] 1038 	mov	r7,#0x00
      007C81                       1039 00103$:
      007C81 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007C84                       1041 00122$:
      007C84 50 1A            [24] 1042 	jnc	00101$
      007C86 EF               [12] 1043 	mov	a,r7
      007C87 24 76            [12] 1044 	add	a, #_owned_mod_refs
      007C89 FD               [12] 1045 	mov	r5,a
      007C8A E4               [12] 1046 	clr	a
      007C8B 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007C8D FE               [12] 1048 	mov	r6,a
      007C8E EF               [12] 1049 	mov	a,r7
      007C8F 24 7E            [12] 1050 	add	a, #_owned_weak_refs
      007C91 F5 82            [12] 1051 	mov	dpl,a
      007C93 E4               [12] 1052 	clr	a
      007C94 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007C96 F5 83            [12] 1054 	mov	dph,a
      007C98 E4               [12] 1055 	clr	a
      007C99 F0               [24] 1056 	movx	@dptr,a
      007C9A 12 80 71         [24] 1057 	lcall	_ak820_outline_0123
      007C9D 0F               [12] 1058 	inc	r7
      007C9E 80 E1            [24] 1059 	sjmp	00103$
      007CA0                       1060 00101$:
                                   1061 ;	quantum/action_util.c:90: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007CA0 90 09 89         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007CA3 E4               [12] 1063 	clr	a
      007CA4 F0               [24] 1064 	movx	@dptr,a
      007CA5 90 09 88         [24] 1065 	mov	dptr,#_macro_mods
      007CA8 F0               [24] 1066 	movx	@dptr,a
      007CA9 90 09 87         [24] 1067 	mov	dptr,#_owned_weak_mods
      007CAC F0               [24] 1068 	movx	@dptr,a
      007CAD 90 09 86         [24] 1069 	mov	dptr,#_owned_mods
      007CB0 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:91: ak820_macro_cancelled = true;
      007CB1 90 09 8B         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007CB4 04               [12] 1073 	inc	a
      007CB5 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:92: }
      007CB6 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:98: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007CB7                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:99: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007CB7 7F 00            [12] 1089 	mov	r7,#0x00
      007CB9                       1090 00104$:
      007CB9 EF               [12] 1091 	mov	a,r7
      007CBA 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007CBC 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007CBE EF               [12] 1095 	mov	a,r7
      007CBF 24 98            [12] 1096 	add	a, #_key_refs
      007CC1 F5 82            [12] 1097 	mov	dpl,a
      007CC3 E4               [12] 1098 	clr	a
      007CC4 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007CC6 12 7A FA         [24] 1100 	lcall	_ak820_outline_0166
      007CC9 80 EE            [24] 1101 	sjmp	00104$
      007CCB                       1102 00101$:
                                   1103 ;	quantum/action_util.c:100: distinct_keys = 0;
      007CCB 90 0A 3D         [24] 1104 	mov	dptr,#_distinct_keys
      007CCE E4               [12] 1105 	clr	a
      007CCF F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:101: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007CD0 FF               [12] 1108 	mov	r7,a
      007CD1                       1109 00107$:
      007CD1 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007CD4                       1111 00142$:
      007CD4 50 0D            [24] 1112 	jnc	00109$
      007CD6 EF               [12] 1113 	mov	a,r7
      007CD7 24 3E            [12] 1114 	add	a, #_macro_keys
      007CD9 F5 82            [12] 1115 	mov	dpl,a
      007CDB E4               [12] 1116 	clr	a
      007CDC 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007CDE 12 7A FA         [24] 1118 	lcall	_ak820_outline_0166
      007CE1 80 EE            [24] 1119 	sjmp	00107$
      007CE3                       1120 00109$:
                                   1121 ;	quantum/action_util.c:102: }
      007CE3 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:103: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007CE4                       1137 _add_owned_key:
      007CE4 E5 82            [12] 1138 	mov	a,dpl
      007CE6 90 0A 53         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007CE9 12 80 82         [24] 1140 	lcall	_ak820_outline_0134
                                   1141 ;	quantum/action_util.c:104: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007CEC 74 01            [12] 1142 	mov	a,#0x01
      007CEE F0               [24] 1143 	movx	@dptr,a
      007CEF 90 0A 3E         [24] 1144 	mov	dptr,#_macro_keys
      007CF2 C0 07            [24] 1145 	push	ar7
      007CF4 71 09            [12] 1146 	acall	_ak820_macro_change
      007CF6 E5 82            [12] 1147 	mov	a, dpl
      007CF8 D0 07            [24] 1148 	pop	ar7
      007CFA 70 03            [24] 1149 	jnz	00102$
      007CFC F5 82            [12] 1150 	mov	dpl,a
      007CFE 22               [24] 1151 	ret
      007CFF                       1152 00102$:
                                   1153 ;	quantum/action_util.c:105: if (key_refs[code]++) return false;
      007CFF 12 80 34         [24] 1154 	lcall	_ak820_outline_0030
      007D02 FC               [12] 1155 	mov	r4,a
      007D03 04               [12] 1156 	inc	a
      007D04 12 80 71         [24] 1157 	lcall	_ak820_outline_0123
      007D07 EC               [12] 1158 	mov	a,r4
      007D08 60 04            [24] 1159 	jz	00104$
      007D0A 75 82 00         [24] 1160 	mov	dpl, #0x00
      007D0D 22               [24] 1161 	ret
      007D0E                       1162 00104$:
                                   1163 ;	quantum/action_util.c:106: ++distinct_keys;
      007D0E 90 0A 3D         [24] 1164 	mov	dptr,#_distinct_keys
      007D11 E0               [24] 1165 	movx	a,@dptr
      007D12 24 01            [12] 1166 	add	a, #0x01
      007D14 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D15 90 0D B6         [24] 1169 	mov	dptr,#_keyboard_protocol
      007D18 E0               [24] 1170 	movx	a,@dptr
      007D19 60 15            [24] 1171 	jz	00106$
      007D1B 90 0A C2         [24] 1172 	mov	dptr,#_keymap_config
      007D1E E0               [24] 1173 	movx	a,@dptr
      007D1F 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D22 90 08 03         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007D25 EF               [12] 1177 	mov	a,r7
      007D26 12 80 42         [24] 1178 	lcall	_ak820_outline_0058
      007D29 12 6E 82         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D2C 75 82 01         [24] 1181 	mov	dpl, #0x01
      007D2F 22               [24] 1182 	ret
      007D30                       1183 00106$:
                                   1184 ;	quantum/action_util.c:110: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007D30 90 0A 3D         [24] 1185 	mov	dptr,#_distinct_keys
      007D33 E0               [24] 1186 	movx	a,@dptr
      007D34 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007D36 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007D38 7F 00            [12] 1191 	mov	r7,#0x00
      007D3A                       1192 00115$:
      007D3A BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007D3D                       1194 00174$:
      007D3D 50 1D            [24] 1195 	jnc	00111$
      007D3F EF               [12] 1196 	mov	a,r7
      007D40 24 CB            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007D42 F5 82            [12] 1198 	mov	dpl,a
      007D44 E4               [12] 1199 	clr	a
      007D45 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007D47 F5 83            [12] 1201 	mov	dph,a
      007D49 74 01            [12] 1202 	mov	a,#0x01
      007D4B F0               [24] 1203 	movx	@dptr,a
      007D4C 0F               [12] 1204 	inc	r7
      007D4D 80 EB            [24] 1205 	sjmp	00115$
      007D4F                       1206 00110$:
                                   1207 ;	quantum/action_util.c:112: } else add_key(code);
      007D4F 90 0A 53         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_326
      007D52 E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D53 90 08 03         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007D56 12 80 42         [24] 1212 	lcall	_ak820_outline_0058
      007D59 12 6E 82         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:112: } else add_key(code);
      007D5C                       1215 00111$:
                                   1216 ;	quantum/action_util.c:113: return true;
      007D5C 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:114: }
      007D5F 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:115: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007D60                       1236 _del_owned_key:
      007D60 E5 82            [12] 1237 	mov	a,dpl
      007D62 90 0A 54         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_341
      007D65 12 80 82         [24] 1239 	lcall	_ak820_outline_0134
                                   1240 ;	quantum/action_util.c:116: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D68 E4               [12] 1241 	clr	a
      007D69 F0               [24] 1242 	movx	@dptr,a
      007D6A 90 0A 3E         [24] 1243 	mov	dptr,#_macro_keys
      007D6D C0 07            [24] 1244 	push	ar7
      007D6F 71 09            [12] 1245 	acall	_ak820_macro_change
      007D71 E5 82            [12] 1246 	mov	a, dpl
      007D73 D0 07            [24] 1247 	pop	ar7
      007D75 70 03            [24] 1248 	jnz	00102$
      007D77 F5 82            [12] 1249 	mov	dpl,a
      007D79 22               [24] 1250 	ret
      007D7A                       1251 00102$:
                                   1252 ;	quantum/action_util.c:117: if (!key_refs[code] || --key_refs[code]) return false;
      007D7A 12 80 34         [24] 1253 	lcall	_ak820_outline_0030
      007D7D FC               [12] 1254 	mov	r4,a
      007D7E 60 07            [24] 1255 	jz	00103$
      007D80 1C               [12] 1256 	dec	r4
      007D81 12 43 2A         [24] 1257 	lcall	_ak820_outline_0065
      007D84 EC               [12] 1258 	mov	a,r4
      007D85 60 04            [24] 1259 	jz	00104$
      007D87                       1260 00103$:
      007D87 75 82 00         [24] 1261 	mov	dpl, #0x00
      007D8A 22               [24] 1262 	ret
      007D8B                       1263 00104$:
                                   1264 ;	quantum/action_util.c:118: --distinct_keys;
      007D8B 90 0A 3D         [24] 1265 	mov	dptr,#_distinct_keys
      007D8E E0               [24] 1266 	movx	a,@dptr
      007D8F 14               [12] 1267 	dec	a
      007D90 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D91 90 0D B6         [24] 1270 	mov	dptr,#_keyboard_protocol
      007D94 E0               [24] 1271 	movx	a,@dptr
      007D95 60 15            [24] 1272 	jz	00107$
      007D97 90 0A C2         [24] 1273 	mov	dptr,#_keymap_config
      007D9A E0               [24] 1274 	movx	a,@dptr
      007D9B 30 E7 0E         [24] 1275 	jnb	acc.7,00107$
                                   1276 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D9E 90 08 07         [24] 1277 	mov	dptr,#_del_key_from_report_PARM_2
      007DA1 EF               [12] 1278 	mov	a,r7
      007DA2 12 80 42         [24] 1279 	lcall	_ak820_outline_0058
      007DA5 12 6E BE         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007DA8 75 82 01         [24] 1282 	mov	dpl, #0x01
      007DAB 22               [24] 1283 	ret
      007DAC                       1284 00107$:
                                   1285 ;	quantum/action_util.c:122: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007DAC 90 0A 3D         [24] 1286 	mov	dptr,#_distinct_keys
      007DAF E0               [24] 1287 	movx	a,@dptr
      007DB0 FF               [12] 1288 	mov  r7,a
      007DB1 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007DB3 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007DB5 75 82 01         [24] 1292 	mov	dpl, #0x01
      007DB8 22               [24] 1293 	ret
      007DB9                       1294 00110$:
                                   1295 ;	quantum/action_util.c:123: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007DB9 BF 06 26         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007DBC 90 0D C9         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007DBF 75 F0 00         [24] 1299 	mov	b, #0x00
      007DC2 12 6E FA         [24] 1300 	lcall	_clear_keys_from_report
                                   1301 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007DC5 7F 04            [12] 1302 	mov	r7,#0x04
      007DC7                       1303 00122$:
      007DC7 EF               [12] 1304 	mov	a,r7
      007DC8 24 5B            [12] 1305 	add	a,#0xff - 0xa4
      007DCA 40 23            [24] 1306 	jc	00116$
                                   1307 ;	free result
      007DCC 12 80 34         [24] 1308 	lcall	_ak820_outline_0030
      007DCF 60 0E            [24] 1309 	jz	00123$
                                   1310 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DD1 90 08 03         [24] 1311 	mov	dptr,#_add_key_to_report_PARM_2
      007DD4 EF               [12] 1312 	mov	a,r7
      007DD5 12 80 42         [24] 1313 	lcall	_ak820_outline_0058
      007DD8 C0 07            [24] 1314 	push	ar7
      007DDA 12 6E 82         [24] 1315 	lcall	_add_key_to_report
      007DDD D0 07            [24] 1316 	pop	ar7
                                   1317 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007DDF                       1318 00123$:
      007DDF 0F               [12] 1319 	inc	r7
      007DE0 80 E5            [24] 1320 	sjmp	00122$
      007DE2                       1321 00115$:
                                   1322 ;	quantum/action_util.c:127: } else del_key(code);
      007DE2 90 0A 54         [24] 1323 	mov	dptr,#_del_owned_key_code_10000_341
      007DE5 E0               [24] 1324 	movx	a,@dptr
                                   1325 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007DE6 90 08 07         [24] 1326 	mov	dptr,#_del_key_from_report_PARM_2
      007DE9 12 80 42         [24] 1327 	lcall	_ak820_outline_0058
      007DEC 12 6E BE         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:127: } else del_key(code);
      007DEF                       1330 00116$:
                                   1331 ;	quantum/action_util.c:128: return true;
      007DEF 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:129: }
      007DF2 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:139: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007DF3                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007DF3 7F 00            [12] 1347 	mov	r7,#0x00
      007DF5                       1348 00104$:
      007DF5 BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007DF8                       1350 00141$:
      007DF8 50 14            [24] 1351 	jnc	00101$
      007DFA EF               [12] 1352 	mov	a,r7
      007DFB 24 55            [12] 1353 	add	a, #_usage_refs
      007DFD FD               [12] 1354 	mov	r5,a
      007DFE E4               [12] 1355 	clr	a
      007DFF 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007E01 FE               [12] 1357 	mov	r6,a
      007E02 EF               [12] 1358 	mov	a,r7
      007E03 12 80 51         [24] 1359 	lcall	_ak820_outline_0068
      007E06 E4               [12] 1360 	clr	a
      007E07 F0               [24] 1361 	movx	@dptr,a
      007E08 12 80 71         [24] 1362 	lcall	_ak820_outline_0123
      007E0B 0F               [12] 1363 	inc	r7
      007E0C 80 E7            [24] 1364 	sjmp	00104$
      007E0E                       1365 00101$:
                                   1366 ;	quantum/action_util.c:141: usage_lengths[0] = usage_lengths[1] = 0;
      007E0E 90 0A 92         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007E11 E4               [12] 1368 	clr	a
      007E12 F0               [24] 1369 	movx	@dptr,a
      007E13 90 0A 91         [24] 1370 	mov	dptr,#_usage_lengths
      007E16 F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:142: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007E17 FF               [12] 1373 	mov	r7,a
      007E18                       1374 00107$:
      007E18 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007E1B                       1376 00143$:
      007E1B 50 0D            [24] 1377 	jnc	00109$
      007E1D EF               [12] 1378 	mov	a,r7
      007E1E 24 93            [12] 1379 	add	a, #_macro_usages
      007E20 F5 82            [12] 1380 	mov	dpl,a
      007E22 E4               [12] 1381 	clr	a
      007E23 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007E25 12 7A FA         [24] 1383 	lcall	_ak820_outline_0166
      007E28 80 EE            [24] 1384 	sjmp	00107$
      007E2A                       1385 00109$:
                                   1386 ;	quantum/action_util.c:143: }
      007E2A 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:144: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007E2B                       1407 _owned_usage_key:
      007E2B E5 82            [12] 1408 	mov	a,dpl
      007E2D 90 0A 98         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_368
      007E30 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:145: uint8_t which = code >= KC_AUDIO_MUTE;
      007E31 E0               [24] 1412 	movx	a,@dptr
      007E32 FF               [12] 1413 	mov	r7,a
      007E33 BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007E36                       1415 00244$:
      007E36 B3               [12] 1416 	cpl	c
      007E37 92 22            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007E39 E4               [12] 1418 	clr	a
      007E3A 33               [12] 1419 	rlc	a
      007E3B FF               [12] 1420 	mov	r7,a
      007E3C 90 0A 9B         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_369
      007E3F F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:146: uint8_t base = which ? SYSTEM_COUNT : 0;
      007E40 EF               [12] 1424 	mov	a,r7
      007E41 60 02            [24] 1425 	jz	00129$
      007E43 74 03            [12] 1426 	mov	a,#0x03
      007E45                       1427 00129$:
      007E45 FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:147: uint8_t count = usage_lengths[which];
      007E46 EF               [12] 1430 	mov	a,r7
      007E47 24 91            [12] 1431 	add	a, #_usage_lengths
      007E49 FD               [12] 1432 	mov	r5,a
      007E4A E4               [12] 1433 	clr	a
      007E4B 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      007E4D FF               [12] 1435 	mov	r7,a
      007E4E 12 80 8D         [24] 1436 	lcall	_ak820_outline_0191
      007E51 E0               [24] 1437 	movx	a,@dptr
      007E52 FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:148: uint8_t index = code - KC_SYSTEM_POWER;
      007E53 90 0A 98         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_368
      007E56 E0               [24] 1441 	movx	a,@dptr
      007E57 24 5B            [12] 1442 	add	a,#0x5b
      007E59 FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:149: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E5A 90 0A 97         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      007E5D E0               [24] 1446 	movx	a,@dptr
      007E5E FA               [12] 1447 	mov	r2,a
      007E5F 90 09 8C         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      007E62 EB               [12] 1449 	mov	a,r3
      007E63 F0               [24] 1450 	movx	@dptr,a
      007E64 90 09 8D         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      007E67 EA               [12] 1452 	mov	a,r2
      007E68 F0               [24] 1453 	movx	@dptr,a
      007E69 90 0A 93         [24] 1454 	mov	dptr,#_macro_usages
      007E6C C0 07            [24] 1455 	push	ar7
      007E6E C0 06            [24] 1456 	push	ar6
      007E70 C0 05            [24] 1457 	push	ar5
      007E72 C0 04            [24] 1458 	push	ar4
      007E74 C0 03            [24] 1459 	push	ar3
      007E76 C0 02            [24] 1460 	push	ar2
      007E78 71 09            [12] 1461 	acall	_ak820_macro_change
      007E7A E5 82            [12] 1462 	mov	a, dpl
      007E7C D0 02            [24] 1463 	pop	ar2
      007E7E D0 03            [24] 1464 	pop	ar3
      007E80 D0 04            [24] 1465 	pop	ar4
      007E82 D0 05            [24] 1466 	pop	ar5
      007E84 D0 06            [24] 1467 	pop	ar6
      007E86 D0 07            [24] 1468 	pop	ar7
      007E88 70 01            [24] 1469 	jnz	00102$
      007E8A 22               [24] 1470 	ret
      007E8B                       1471 00102$:
                                   1472 ;	quantum/action_util.c:150: if (pressed) {
      007E8B EA               [12] 1473 	mov	a,r2
      007E8C 60 1A            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:151: if (usage_refs[index]++) return;
      007E8E 12 80 5B         [24] 1476 	lcall	_ak820_outline_0075
      007E91 04               [12] 1477 	inc	a
      007E92 12 6C 01         [24] 1478 	lcall	_ak820_outline_0141
      007E95 E8               [12] 1479 	mov	a,r0
      007E96 60 01            [24] 1480 	jz	00104$
      007E98 22               [24] 1481 	ret
      007E99                       1482 00104$:
                                   1483 ;	quantum/action_util.c:152: usage_order[base + count++] = index;
      007E99 90 0A 9C         [24] 1484 	mov	dptr,#_owned_usage_key_count_10000_369
      007E9C EC               [12] 1485 	mov	a,r4
      007E9D 04               [12] 1486 	inc	a
      007E9E F0               [24] 1487 	movx	@dptr,a
      007E9F EC               [12] 1488 	mov	a,r4
      007EA0 2E               [12] 1489 	add	a, r6
      007EA1 12 80 51         [24] 1490 	lcall	_ak820_outline_0068
      007EA4 EB               [12] 1491 	mov	a,r3
      007EA5 F0               [24] 1492 	movx	@dptr,a
      007EA6 E1 09            [12] 1493 	ajmp	00116$
      007EA8                       1494 00115$:
                                   1495 ;	quantum/action_util.c:154: if (!usage_refs[index] || --usage_refs[index]) return;
      007EA8 12 80 5B         [24] 1496 	lcall	_ak820_outline_0075
      007EAB 60 07            [24] 1497 	jz	00105$
      007EAD 18               [12] 1498 	dec	r0
      007EAE 12 80 4A         [24] 1499 	lcall	_ak820_outline_0064
      007EB1 E8               [12] 1500 	mov	a,r0
      007EB2 60 01            [24] 1501 	jz	00106$
      007EB4                       1502 00105$:
      007EB4 22               [24] 1503 	ret
      007EB5                       1504 00106$:
                                   1505 ;	quantum/action_util.c:156: while (usage_order[base + pos] != index) ++pos;
      007EB5 7A 00            [12] 1506 	mov	r2,#0x00
      007EB7                       1507 00108$:
      007EB7 EA               [12] 1508 	mov	a,r2
      007EB8 2E               [12] 1509 	add	a, r6
      007EB9 12 80 51         [24] 1510 	lcall	_ak820_outline_0068
      007EBC E0               [24] 1511 	movx	a,@dptr
      007EBD B5 03 02         [24] 1512 	cjne	a,ar3,00251$
      007EC0 80 03            [24] 1513 	sjmp	00167$
      007EC2                       1514 00251$:
      007EC2 0A               [12] 1515 	inc	r2
      007EC3 80 F2            [24] 1516 	sjmp	00108$
      007EC5                       1517 00167$:
      007EC5 90 0A 9D         [24] 1518 	mov	dptr,#_owned_usage_key_pos_30001_376
      007EC8 EA               [12] 1519 	mov	a,r2
      007EC9 F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action_util.c:157: --count;
      007ECA 1C               [12] 1522 	dec	r4
      007ECB 90 0A 9C         [24] 1523 	mov	dptr,#_owned_usage_key_count_10000_369
      007ECE EC               [12] 1524 	mov	a,r4
      007ECF F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:158: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007ED0 8A 03            [24] 1527 	mov	ar3,r2
      007ED2                       1528 00125$:
      007ED2 C3               [12] 1529 	clr	c
      007ED3 EB               [12] 1530 	mov	a,r3
      007ED4 9C               [12] 1531 	subb	a,r4
      007ED5 50 23            [24] 1532 	jnc	00111$
      007ED7 C0 05            [24] 1533 	push	ar5
      007ED9 C0 07            [24] 1534 	push	ar7
      007EDB EB               [12] 1535 	mov	a,r3
      007EDC 2E               [12] 1536 	add	a, r6
      007EDD FA               [12] 1537 	mov	r2,a
      007EDE 24 73            [12] 1538 	add	a, #_usage_order
      007EE0 F8               [12] 1539 	mov	r0,a
      007EE1 E4               [12] 1540 	clr	a
      007EE2 34 0A            [12] 1541 	addc	a, #(_usage_order >> 8)
      007EE4 F9               [12] 1542 	mov	r1,a
      007EE5 0A               [12] 1543 	inc	r2
      007EE6 EA               [12] 1544 	mov	a,r2
      007EE7 33               [12] 1545 	rlc	a
      007EE8 95 E0            [12] 1546 	subb	a,acc
      007EEA FF               [12] 1547 	mov	r7,a
      007EEB EA               [12] 1548 	mov	a,r2
      007EEC 12 80 77         [24] 1549 	lcall	_ak820_outline_0127
      007EEF 12 38 A9         [24] 1550 	lcall	_ak820_outline_0160
      007EF2 F0               [24] 1551 	movx	@dptr,a
      007EF3 0B               [12] 1552 	inc	r3
      007EF4 D0 07            [24] 1553 	pop	ar7
      007EF6 D0 05            [24] 1554 	pop	ar5
      007EF8 80 D8            [24] 1555 	sjmp	00125$
      007EFA                       1556 00111$:
                                   1557 ;	quantum/action_util.c:159: usage_lengths[which] = count;
      007EFA 12 80 8D         [24] 1558 	lcall	_ak820_outline_0191
      007EFD EC               [12] 1559 	mov	a,r4
      007EFE F0               [24] 1560 	movx	@dptr,a
                                   1561 ;	quantum/action_util.c:160: if (pos != count) return; /* A non-winning owner changed only storage. */
      007EFF 90 0A 9D         [24] 1562 	mov	dptr,#_owned_usage_key_pos_30001_376
      007F02 E0               [24] 1563 	movx	a,@dptr
      007F03 B5 04 02         [24] 1564 	cjne	a,ar4,00253$
      007F06 80 01            [24] 1565 	sjmp	00116$
      007F08                       1566 00253$:
      007F08 22               [24] 1567 	ret
      007F09                       1568 00116$:
                                   1569 ;	quantum/action_util.c:162: usage_lengths[which] = count;
      007F09 90 0A 9C         [24] 1570 	mov	dptr,#_owned_usage_key_count_10000_369
      007F0C E0               [24] 1571 	movx	a,@dptr
      007F0D FC               [12] 1572 	mov	r4,a
      007F0E 12 80 8D         [24] 1573 	lcall	_ak820_outline_0191
      007F11 F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/action_util.c:163: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007F12 EC               [12] 1576 	mov	a,r4
      007F13 60 15            [24] 1577 	jz	00131$
      007F15 EC               [12] 1578 	mov	a,r4
      007F16 2E               [12] 1579 	add	a, r6
      007F17 FE               [12] 1580 	mov	r6,a
      007F18 1E               [12] 1581 	dec	r6
      007F19 EE               [12] 1582 	mov	a,r6
      007F1A 33               [12] 1583 	rlc	a
      007F1B 95 E0            [12] 1584 	subb	a,acc
      007F1D FF               [12] 1585 	mov	r7,a
      007F1E EE               [12] 1586 	mov	a,r6
      007F1F 12 80 77         [24] 1587 	lcall	_ak820_outline_0127
      007F22 24 A5            [12] 1588 	add	a,#0xa5
      007F24 FE               [12] 1589 	mov	r6,a
      007F25 33               [12] 1590 	rlc	a
      007F26 95 E0            [12] 1591 	subb	a,acc
      007F28 80 02            [24] 1592 	sjmp	00132$
      007F2A                       1593 00131$:
      007F2A 7E 00            [12] 1594 	mov	r6,#0x00
      007F2C                       1595 00132$:
      007F2C 90 0A 98         [24] 1596 	mov	dptr,#_owned_usage_key_code_10000_368
      007F2F EE               [12] 1597 	mov	a,r6
      007F30 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/action_util.c:164: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007F31 90 0A 9B         [24] 1600 	mov	dptr,#_owned_usage_key_which_10000_369
      007F34 E0               [24] 1601 	movx	a,@dptr
      007F35 60 18            [24] 1602 	jz	00118$
      007F37 EE               [12] 1603 	mov	a,r6
      007F38 60 0B            [24] 1604 	jz	00133$
      007F3A 8E 82            [24] 1605 	mov	dpl, r6
      007F3C 12 6D 3F         [24] 1606 	lcall	_KEYCODE2CONSUMER
      007F3F AD 82            [24] 1607 	mov	r5, dpl
      007F41 AF 83            [24] 1608 	mov	r7, dph
      007F43 80 04            [24] 1609 	sjmp	00134$
      007F45                       1610 00133$:
      007F45 7D 00            [12] 1611 	mov	r5,#0x00
      007F47 7F 00            [12] 1612 	mov	r7,#0x00
      007F49                       1613 00134$:
      007F49 12 80 8D         [24] 1614 	lcall	_ak820_outline_0191
      007F4C 02 6C F3         [24] 1615 	ljmp	_host_consumer_send
      007F4F                       1616 00118$:
                                   1617 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F4F EE               [12] 1618 	mov	a,r6
      007F50 60 22            [24] 1619 	jz	00135$
                                   1620 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007F52 BE A5 00         [24] 1621 	cjne	r6,#0xa5,00258$
      007F55                       1622 00258$:
      007F55 40 05            [24] 1623 	jc	00121$
      007F57 EE               [12] 1624 	mov	a,r6
      007F58 24 58            [12] 1625 	add	a,#0xff - 0xa7
      007F5A 50 08            [24] 1626 	jnc	00122$
                                   1627 ;	free result
      007F5C                       1628 00121$:
      007F5C 90 0A 99         [24] 1629 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F5F 12 4F 26         [24] 1630 	lcall	_ak820_outline_0184
      007F62 80 09            [24] 1631 	sjmp	00123$
      007F64                       1632 00122$:
                                   1633 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F64 74 DC            [12] 1634 	mov	a,#0xdc
      007F66 2E               [12] 1635 	add	a, r6
      007F67 90 0A 99         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F6A 12 38 8F         [24] 1637 	lcall	_ak820_outline_0136
                                   1638 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F6D                       1639 00123$:
      007F6D 90 0A 99         [24] 1640 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F70 E0               [24] 1641 	movx	a,@dptr
      007F71 FF               [12] 1642 	mov	r7,a
      007F72 80 02            [24] 1643 	sjmp	00136$
      007F74                       1644 00135$:
      007F74 7F 00            [12] 1645 	mov	r7,#0x00
      007F76                       1646 00136$:
      007F76 7E 00            [12] 1647 	mov	r6,#0x00
      007F78 12 43 65         [24] 1648 	lcall	_ak820_outline_0161
                                   1649 ;	quantum/action_util.c:166: }
      007F7B 02 6C C4         [24] 1650 	ljmp	_host_system_send
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1653 ;------------------------------------------------------------
                                   1654 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1655 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1656 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1657 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1658 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1659 ;------------------------------------------------------------
                                   1660 ;	quantum/action_util.c:388: void send_keyboard_report(void) {
                                   1661 ;	-----------------------------------------
                                   1662 ;	 function send_keyboard_report
                                   1663 ;	-----------------------------------------
      007F7E                       1664 _send_keyboard_report:
                                   1665 ;	quantum/action_util.c:389: keyboard_report->mods = real_mods;
      007F7E 90 0D C7         [24] 1666 	mov	dptr,#_real_mods
      007F81 E0               [24] 1667 	movx	a,@dptr
      007F82 FF               [12] 1668 	mov	r7,a
      007F83 90 0D C9         [24] 1669 	mov	dptr,#_actual_keyboard_report
      007F86 F0               [24] 1670 	movx	@dptr,a
                                   1671 ;	quantum/action_util.c:390: keyboard_report->mods |= weak_mods;
      007F87 90 0D C8         [24] 1672 	mov	dptr,#_weak_mods
      007F8A E0               [24] 1673 	movx	a,@dptr
      007F8B 42 07            [12] 1674 	orl	ar7,a
      007F8D 90 0D C9         [24] 1675 	mov	dptr,#_actual_keyboard_report
      007F90 EF               [12] 1676 	mov	a,r7
      007F91 F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:392: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007F92 90 09 87         [24] 1679 	mov	dptr,#_owned_weak_mods
      007F95 E0               [24] 1680 	movx	a,@dptr
      007F96 FE               [12] 1681 	mov	r6,a
      007F97 90 09 86         [24] 1682 	mov	dptr,#_owned_mods
      007F9A E0               [24] 1683 	movx	a,@dptr
      007F9B 4E               [12] 1684 	orl	a,r6
      007F9C 42 07            [12] 1685 	orl	ar7,a
      007F9E 90 0D C9         [24] 1686 	mov	dptr,#_actual_keyboard_report
      007FA1 EF               [12] 1687 	mov	a,r7
      007FA2 F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:427: bool changed = false;
      007FA3 90 0A BF         [24] 1690 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007FA6 E4               [12] 1691 	clr	a
      007FA7 F0               [24] 1692 	movx	@dptr,a
                                   1693 ;	quantum/action_util.c:429: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1694 ;	quantum/action_util.c:430: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1695 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007FA8 FF               [12] 1696 	mov	r7,a
      007FA9                       1697 00107$:
      007FA9 BF 20 00         [24] 1698 	cjne	r7,#0x20,00140$
      007FAC                       1699 00140$:
      007FAC 50 2B            [24] 1700 	jnc	00103$
                                   1701 ;	quantum/action_util.c:436: if (dest[i] != src[i]) {
      007FAE EF               [12] 1702 	mov	a,r7
      007FAF 24 9F            [12] 1703 	add	a, #_send_keyboard_report_last_report_10001_388
      007FB1 FD               [12] 1704 	mov	r5,a
      007FB2 E4               [12] 1705 	clr	a
      007FB3 34 0A            [12] 1706 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007FB5 FE               [12] 1707 	mov	r6,a
      007FB6 12 48 7A         [24] 1708 	lcall	_ak820_outline_0077
      007FB9 EF               [12] 1709 	mov	a,r7
      007FBA 24 C9            [12] 1710 	add	a, #_actual_keyboard_report
      007FBC F5 82            [12] 1711 	mov	dpl,a
      007FBE E4               [12] 1712 	clr	a
      007FBF 34 0D            [12] 1713 	addc	a, #(_actual_keyboard_report >> 8)
      007FC1 F5 83            [12] 1714 	mov	dph,a
      007FC3 E0               [24] 1715 	movx	a,@dptr
      007FC4 FB               [12] 1716 	mov	r3,a
      007FC5 EC               [12] 1717 	mov	a,r4
      007FC6 B5 03 02         [24] 1718 	cjne	a,ar3,00142$
      007FC9 80 0B            [24] 1719 	sjmp	00108$
      007FCB                       1720 00142$:
                                   1721 ;	quantum/action_util.c:437: dest[i] = src[i];
      007FCB 12 38 94         [24] 1722 	lcall	_ak820_outline_0137
      007FCE EB               [12] 1723 	mov	a,r3
      007FCF F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action_util.c:438: changed = true;
      007FD0 90 0A BF         [24] 1726 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007FD3 74 01            [12] 1727 	mov	a,#0x01
      007FD5 F0               [24] 1728 	movx	@dptr,a
      007FD6                       1729 00108$:
                                   1730 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007FD6 0F               [12] 1731 	inc	r7
      007FD7 80 D0            [24] 1732 	sjmp	00107$
      007FD9                       1733 00103$:
                                   1734 ;	quantum/action_util.c:441: if (changed) host_keyboard_send(keyboard_report);
      007FD9 90 0A BF         [24] 1735 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007FDC E0               [24] 1736 	movx	a,@dptr
      007FDD 60 09            [24] 1737 	jz	00109$
      007FDF 90 0D C9         [24] 1738 	mov	dptr,#_actual_keyboard_report
      007FE2 75 F0 00         [24] 1739 	mov	b, #0x00
                                   1740 ;	quantum/action_util.c:449: }
      007FE5 02 6C 39         [24] 1741 	ljmp	_host_keyboard_send
      007FE8                       1742 00109$:
      007FE8 22               [24] 1743 	ret
                                   1744 ;------------------------------------------------------------
                                   1745 ;Allocation info for local variables in function 'get_mods'
                                   1746 ;------------------------------------------------------------
                                   1747 ;	quantum/action_util.c:455: uint8_t get_mods(void) {
                                   1748 ;	-----------------------------------------
                                   1749 ;	 function get_mods
                                   1750 ;	-----------------------------------------
      007FE9                       1751 _get_mods:
      007FE9 C0 07            [24] 1752 	push	ar7
                                   1753 ;	quantum/action_util.c:460: ;
      007FEB 90 09 86         [24] 1754 	mov	dptr,#_owned_mods
      007FEE E0               [24] 1755 	movx	a,@dptr
      007FEF FF               [12] 1756 	mov	r7,a
      007FF0 90 0D C7         [24] 1757 	mov	dptr,#_real_mods
      007FF3 12 7A F4         [24] 1758 	lcall	_ak820_outline_0143
                                   1759 ;	quantum/action_util.c:461: }
      007FF6 D0 07            [24] 1760 	pop	ar7
      007FF8 22               [24] 1761 	ret
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'add_mods'
                                   1764 ;------------------------------------------------------------
                                   1765 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	quantum/action_util.c:466: void add_mods(uint8_t mods) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function clear_mods
                                   1770 ;	-----------------------------------------
      007FF9                       1771 _clear_mods:
                                   1772 ;	quantum/action_util.c:488: real_mods = 0;
      007FF9 90 0D C7         [24] 1773 	mov	dptr,#_real_mods
      007FFC E4               [12] 1774 	clr	a
      007FFD F0               [24] 1775 	movx	@dptr,a
                                   1776 ;	quantum/action_util.c:489: }
      007FFE 22               [24] 1777 	ret
                                   1778 ;------------------------------------------------------------
                                   1779 ;Allocation info for local variables in function 'get_weak_mods'
                                   1780 ;------------------------------------------------------------
                                   1781 ;	quantum/action_util.c:495: uint8_t get_weak_mods(void) {
                                   1782 ;	-----------------------------------------
                                   1783 ;	 function get_weak_mods
                                   1784 ;	-----------------------------------------
      007FFF                       1785 _get_weak_mods:
      007FFF C0 07            [24] 1786 	push	ar7
                                   1787 ;	quantum/action_util.c:500: ;
      008001 90 09 87         [24] 1788 	mov	dptr,#_owned_weak_mods
      008004 E0               [24] 1789 	movx	a,@dptr
      008005 FF               [12] 1790 	mov	r7,a
      008006 90 0D C8         [24] 1791 	mov	dptr,#_weak_mods
      008009 12 7A F4         [24] 1792 	lcall	_ak820_outline_0143
                                   1793 ;	quantum/action_util.c:501: }
      00800C D0 07            [24] 1794 	pop	ar7
      00800E 22               [24] 1795 	ret
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'add_weak_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1800 ;------------------------------------------------------------
                                   1801 ;	quantum/action_util.c:506: void add_weak_mods(uint8_t mods) {
                                   1802 ;	-----------------------------------------
                                   1803 ;	 function add_weak_mods
                                   1804 ;	-----------------------------------------
      00800F                       1805 _add_weak_mods:
      00800F E5 82            [12] 1806 	mov	a,dpl
      008011 90 0A C0         [24] 1807 	mov	dptr,#_add_weak_mods_mods_10000_406
      008014 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	quantum/action_util.c:507: weak_mods |= mods;
      008015 E0               [24] 1810 	movx	a,@dptr
      008016 FF               [12] 1811 	mov	r7,a
      008017 90 0D C8         [24] 1812 	mov	dptr,#_weak_mods
      00801A E0               [24] 1813 	movx	a,@dptr
      00801B 4F               [12] 1814 	orl	a,r7
      00801C F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	quantum/action_util.c:508: }
      00801D 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'del_weak_mods'
                                   1820 ;------------------------------------------------------------
                                   1821 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/action_util.c:513: void del_weak_mods(uint8_t mods) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function del_weak_mods
                                   1826 ;	-----------------------------------------
      00801E                       1827 _del_weak_mods:
      00801E E5 82            [12] 1828 	mov	a,dpl
      008020 90 0A C1         [24] 1829 	mov	dptr,#_del_weak_mods_mods_10000_408
      008023 F0               [24] 1830 	movx	@dptr,a
                                   1831 ;	quantum/action_util.c:514: weak_mods &= ~mods;
      008024 E0               [24] 1832 	movx	a,@dptr
      008025 F4               [12] 1833 	cpl	a
      008026 FF               [12] 1834 	mov	r7,a
      008027 90 0D C8         [24] 1835 	mov	dptr,#_weak_mods
      00802A E0               [24] 1836 	movx	a,@dptr
      00802B 5F               [12] 1837 	anl	a,r7
      00802C F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	quantum/action_util.c:515: }
      00802D 22               [24] 1840 	ret
                                   1841 ;------------------------------------------------------------
                                   1842 ;Allocation info for local variables in function 'set_weak_mods'
                                   1843 ;------------------------------------------------------------
                                   1844 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1845 ;------------------------------------------------------------
                                   1846 ;	quantum/action_util.c:520: void set_weak_mods(uint8_t mods) {
                                   1847 ;	-----------------------------------------
                                   1848 ;	 function clear_weak_mods
                                   1849 ;	-----------------------------------------
      00802E                       1850 _clear_weak_mods:
                                   1851 ;	quantum/action_util.c:528: weak_mods = 0;
      00802E 90 0D C8         [24] 1852 	mov	dptr,#_weak_mods
      008031 E4               [12] 1853 	clr	a
      008032 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/action_util.c:529: }
      008033 22               [24] 1856 	ret
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1859 ;------------------------------------------------------------
                                   1860 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1861 ;------------------------------------------------------------
                                   1862 ;	quantum/action_util.c:611: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1863 ;	-----------------------------------------
                                   1864 	.area CSEG    (CODE)
                                   1865 	.area CONST   (CODE)
                                   1866 	.area XINIT   (CODE)
      00BF9F                       1867 __xinit__real_mods:
      00BF9F 00                    1868 	.db #0x00	; 0
      00BFA0                       1869 __xinit__weak_mods:
      00BFA0 00                    1870 	.db #0x00	; 0
      00BFA1                       1871 __xinit__actual_keyboard_report:
      00BFA1 00                    1872 	.db #0x00	; 0
      00BFA2 00                    1873 	.db #0x00	; 0
      00BFA3 00                    1874 	.db #0x00	; 0
      00BFA4 00                    1875 	.db #0x00	; 0
      00BFA5 00                    1876 	.db #0x00	; 0
      00BFA6 00                    1877 	.db #0x00	; 0
      00BFA7 00                    1878 	.db #0x00	; 0
      00BFA8 00                    1879 	.db #0x00	; 0
      00BFA9 00                    1880 	.db 0x00
      00BFAA 00                    1881 	.db 0x00
      00BFAB 00                    1882 	.db 0x00
      00BFAC 00                    1883 	.db 0x00
      00BFAD 00                    1884 	.db 0x00
      00BFAE 00                    1885 	.db 0x00
      00BFAF 00                    1886 	.db 0x00
      00BFB0 00                    1887 	.db 0x00
      00BFB1 00                    1888 	.db 0x00
      00BFB2 00                    1889 	.db 0x00
      00BFB3 00                    1890 	.db 0x00
      00BFB4 00                    1891 	.db 0x00
      00BFB5 00                    1892 	.db 0x00
      00BFB6 00                    1893 	.db 0x00
      00BFB7 00                    1894 	.db 0x00
      00BFB8 00                    1895 	.db 0x00
      00BFB9 00                    1896 	.db 0x00
      00BFBA 00                    1897 	.db 0x00
      00BFBB 00                    1898 	.db 0x00
      00BFBC 00                    1899 	.db 0x00
      00BFBD 00                    1900 	.db 0x00
      00BFBE 00                    1901 	.db 0x00
      00BFBF 00                    1902 	.db 0x00
      00BFC0 00                    1903 	.db 0x00
                                   1904 	.area CABS    (ABS,CODE)
                                   1905 
                                   1906 ; Experimental exact instruction outlining.
                                   1907 	.globl _ak820_outline_0017
                                   1908 	.globl _ak820_outline_0030
                                   1909 	.globl _ak820_outline_0056
                                   1910 	.globl _ak820_outline_0058
                                   1911 	.globl _ak820_outline_0061
                                   1912 	.globl _ak820_outline_0063
                                   1913 	.globl _ak820_outline_0064
                                   1914 	.globl _ak820_outline_0065
                                   1915 	.globl _ak820_outline_0068
                                   1916 	.globl _ak820_outline_0075
                                   1917 	.globl _ak820_outline_0077
                                   1918 	.globl _ak820_outline_0109
                                   1919 	.globl _ak820_outline_0110
                                   1920 	.globl _ak820_outline_0119
                                   1921 	.globl _ak820_outline_0123
                                   1922 	.globl _ak820_outline_0125
                                   1923 	.globl _ak820_outline_0127
                                   1924 	.globl _ak820_outline_0134
                                   1925 	.globl _ak820_outline_0136
                                   1926 	.globl _ak820_outline_0137
                                   1927 	.globl _ak820_outline_0141
                                   1928 	.globl _ak820_outline_0143
                                   1929 	.globl _ak820_outline_0160
                                   1930 	.globl _ak820_outline_0161
                                   1931 	.globl _ak820_outline_0166
                                   1932 	.globl _ak820_outline_0184
                                   1933 	.globl _ak820_outline_0190
                                   1934 	.globl _ak820_outline_0191
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0030
      008034                       1938 _ak820_outline_0030:
      008034 EF               [12] 1939 	mov	a,r7
      008035 24 98            [12] 1940 	add	a,#_key_refs
      008037 FD               [12] 1941 	mov	r5,a
      008038 E4               [12] 1942 	clr	a
      008039 34 09            [12] 1943 	addc	a,#(_key_refs>>8)
      00803B FE               [12] 1944 	mov	r6,a
      00803C 8D 82            [24] 1945 	mov	dpl,r5
      00803E 8E 83            [24] 1946 	mov	dph,r6
      008040 E0               [24] 1947 	movx	a,@dptr
      008041 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0058
      008042                       1952 _ak820_outline_0058:
      008042 F0               [24] 1953 	movx	@dptr,a
      008043 90 0D C9         [24] 1954 	mov	dptr,#_actual_keyboard_report
      008046 75 F0 00         [24] 1955 	mov	b,#0x00
      008049 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0064
      00804A                       1960 _ak820_outline_0064:
      00804A 89 82            [24] 1961 	mov	dpl,r1
      00804C 8A 83            [24] 1962 	mov	dph,r2
      00804E E8               [12] 1963 	mov	a,r0
      00804F F0               [24] 1964 	movx	@dptr,a
      008050 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0068
      008051                       1969 _ak820_outline_0068:
      008051 24 73            [12] 1970 	add	a,#_usage_order
      008053 F5 82            [12] 1971 	mov	dpl,a
      008055 E4               [12] 1972 	clr	a
      008056 34 0A            [12] 1973 	addc	a,#(_usage_order>>8)
      008058 F5 83            [12] 1974 	mov	dph,a
      00805A 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0075
      00805B                       1979 _ak820_outline_0075:
      00805B EB               [12] 1980 	mov	a,r3
      00805C 24 55            [12] 1981 	add	a,#_usage_refs
      00805E F9               [12] 1982 	mov	r1,a
      00805F E4               [12] 1983 	clr	a
      008060 34 0A            [12] 1984 	addc	a,#(_usage_refs>>8)
      008062 FA               [12] 1985 	mov	r2,a
      008063 89 82            [24] 1986 	mov	dpl,r1
      008065 8A 83            [24] 1987 	mov	dph,r2
      008067 E0               [24] 1988 	movx	a,@dptr
      008068 F8               [12] 1989 	mov	r0,a
      008069 22               [24] 1990 	ret
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0119
      00806A                       1994 _ak820_outline_0119:
      00806A F0               [24] 1995 	movx	@dptr,a
      00806B E0               [24] 1996 	movx	a,@dptr
      00806C FF               [12] 1997 	mov	r7,a
      00806D 90 09 90         [24] 1998 	mov	dptr,#_change_owned_PARM_2
      008070 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0123
      008071                       2003 _ak820_outline_0123:
      008071 8D 82            [24] 2004 	mov	dpl,r5
      008073 8E 83            [24] 2005 	mov	dph,r6
      008075 F0               [24] 2006 	movx	@dptr,a
      008076 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0127
      008077                       2011 _ak820_outline_0127:
      008077 24 73            [12] 2012 	add	a,#_usage_order
      008079 F5 82            [12] 2013 	mov	dpl,a
      00807B EF               [12] 2014 	mov	a,r7
      00807C 34 0A            [12] 2015 	addc	a,#(_usage_order>>8)
      00807E F5 83            [12] 2016 	mov	dph,a
      008080 E0               [24] 2017 	movx	a,@dptr
      008081 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0134
      008082                       2022 _ak820_outline_0134:
      008082 F0               [24] 2023 	movx	@dptr,a
      008083 E0               [24] 2024 	movx	a,@dptr
      008084 FF               [12] 2025 	mov	r7,a
      008085 90 09 8C         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_2
      008088 F0               [24] 2027 	movx	@dptr,a
      008089 90 09 8D         [24] 2028 	mov	dptr,#_ak820_macro_change_PARM_3
      00808C 22               [24] 2029 	ret
                                   2030 
                                   2031 	.area CSEG (CODE)
                                   2032 ; function ak820_outline_0191
      00808D                       2033 _ak820_outline_0191:
      00808D 8D 82            [24] 2034 	mov	dpl,r5
      00808F 8F 83            [24] 2035 	mov	dph,r7
      008091 22               [24] 2036 	ret
