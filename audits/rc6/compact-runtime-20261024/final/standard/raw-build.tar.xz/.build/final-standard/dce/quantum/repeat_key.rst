                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000C04                        554 _last_record:
      000C04                        555 	.ds 9
      000C0D                        556 _ak820_repeat_invoking:
      000C0D                        557 	.ds 1
      000C0E                        558 _registered_record:
      000C0E                        559 	.ds 9
      000C17                        560 _registered_repeat_count:
      000C17                        561 	.ds 1
      000C18                        562 _registered_mods:
      000C18                        563 	.ds 1
      000C19                        564 _set_last_mods_mods_10000_170:
      000C19                        565 	.ds 1
      000C1A                        566 _set_last_record_PARM_2:
      000C1A                        567 	.ds 3
      000C1D                        568 _set_last_record_keycode_10000_172:
      000C1D                        569 	.ds 2
      000C1F                        570 _update_last_repeat_count_dir_10000_174:
      000C1F                        571 	.ds 1
      000C20                        572 _repeat_invoke_PARM_2:
      000C20                        573 	.ds 1
      000C21                        574 _repeat_invoke_event_10000_182:
      000C21                        575 	.ds 3
      000C24                        576 _repeat_key_invoke_event_10000_197:
      000C24                        577 	.ds 3
      000C27                        578 _find_alt_keycode_PARM_2:
      000C27                        579 	.ds 1
      000C28                        580 _find_alt_keycode_PARM_3:
      000C28                        581 	.ds 1
      000C29                        582 _find_alt_keycode_table_10000_199:
      000C29                        583 	.ds 3
      000C2C                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000C2C                        585 	.ds 2
      000C2E                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000C2E                        587 	.ds 1
      000C2F                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000C2F                        589 	.ds 2
      000C31                        590 _alt_repeat_key_invoke_event_10000_220:
      000C31                        591 	.ds 3
      000C34                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000C34                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000E0A                        602 _last_mods:
      000E0A                        603 	.ds 1
      000E0B                        604 _last_repeat_count:
      000E0B                        605 	.ds 1
      000E0C                        606 _processing_repeat_count:
      000E0C                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      009E14                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      009E14 90 0C 15         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      009E17 12 4D 73         [24]  652 	lcall	_ak820_outline_0166
                                    653 ;	quantum/repeat_key.c:46: }
      009E1A 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      009E1B                        662 _set_last_mods:
      009E1B E5 82            [12]  663 	mov	a,dpl
      009E1D 90 0C 19         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      009E20 F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      009E21 E0               [24]  667 	movx	a,@dptr
      009E22 90 0E 0A         [24]  668 	mov	dptr,#_last_mods
      009E25 F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      009E26 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      009E27                        682 _set_last_record:
      009E27 12 38 88         [24]  683 	lcall	_ak820_outline_0113
      009E2A 90 0C 1D         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      009E2D 12 38 83         [24]  685 	lcall	_ak820_outline_0112
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      009E30 90 0C 1A         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      009E33 12 4D 27         [24]  688 	lcall	_ak820_outline_0012
      009E36 90 0D 93         [24]  689 	mov	dptr,#___memcpy_PARM_2
      009E39 ED               [12]  690 	mov	a,r5
      009E3A 12 38 20         [24]  691 	lcall	_ak820_outline_0014
      009E3D 90 0D 96         [24]  692 	mov	dptr,#___memcpy_PARM_3
      009E40 74 09            [12]  693 	mov	a,#0x09
      009E42 12 38 97         [24]  694 	lcall	_ak820_outline_0122
      009E45 90 0C 04         [24]  695 	mov	dptr,#_last_record
      009E48 F5 F0            [12]  696 	mov	b,a
      009E4A 12 B4 CB         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      009E4D 90 0C 1D         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      009E50 12 38 42         [24]  700 	lcall	_ak820_outline_0052
      009E53 90 0C 0B         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      009E56 12 46 DE         [24]  702 	lcall	_ak820_outline_0060
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      009E59 90 0E 0B         [24]  704 	mov	dptr,#_last_repeat_count
      009E5C E4               [12]  705 	clr	a
      009E5D F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      009E5E 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      009E5F                        718 _update_last_repeat_count:
      009E5F E5 82            [12]  719 	mov	a,dpl
      009E61 90 0C 1F         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      009E64 F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      009E65 E0               [24]  723 	movx	a,@dptr
      009E66 FF               [12]  724 	mov	r7,a
      009E67 33               [12]  725 	rlc	a
      009E68 E4               [12]  726 	clr	a
      009E69 33               [12]  727 	rlc	a
      009E6A FE               [12]  728 	mov	r6,a
      009E6B 90 0E 0B         [24]  729 	mov	dptr,#_last_repeat_count
      009E6E E0               [24]  730 	movx	a,@dptr
      009E6F FD               [12]  731 	mov	r5,a
      009E70 33               [12]  732 	rlc	a
      009E71 E4               [12]  733 	clr	a
      009E72 33               [12]  734 	rlc	a
      009E73 FC               [12]  735 	mov	r4,a
      009E74 EE               [12]  736 	mov	a,r6
      009E75 B5 04 02         [24]  737 	cjne	a,ar4,00131$
      009E78 80 06            [24]  738 	sjmp	00104$
      009E7A                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      009E7A 90 0E 0B         [24]  741 	mov	dptr,#_last_repeat_count
      009E7D EF               [12]  742 	mov	a,r7
      009E7E F0               [24]  743 	movx	@dptr,a
      009E7F 22               [24]  744 	ret
      009E80                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      009E80 EE               [12]  747 	mov	a,r6
      009E81 60 0F            [24]  748 	jz	00108$
      009E83 C3               [12]  749 	clr	c
      009E84 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      009E86 8D F0            [24]  751 	mov	b,r5
      009E88 63 F0 80         [24]  752 	xrl	b,#0x80
      009E8B 95 F0            [12]  753 	subb	a,b
      009E8D E4               [12]  754 	clr	a
      009E8E 33               [12]  755 	rlc	a
      009E8F FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      009E90 80 09            [24]  758 	sjmp	00109$
      009E92                        759 00108$:
      009E92 C3               [12]  760 	clr	c
      009E93 ED               [12]  761 	mov	a,r5
      009E94 64 80            [12]  762 	xrl	a,#0x80
      009E96 94 FF            [12]  763 	subb	a,#0xff
      009E98 E4               [12]  764 	clr	a
      009E99 33               [12]  765 	rlc	a
      009E9A FF               [12]  766 	mov	r7,a
      009E9B                        767 00109$:
      009E9B EF               [12]  768 	mov	a,r7
      009E9C 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      009E9E 90 0C 1F         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      009EA1 E0               [24]  772 	movx	a,@dptr
      009EA2 90 0E 0B         [24]  773 	mov	dptr,#_last_repeat_count
      009EA5 2D               [12]  774 	add	a, r5
      009EA6 F0               [24]  775 	movx	@dptr,a
      009EA7                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      009EA7 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      009EA8                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      009EA8 90 0E 0C         [24]  788 	mov	dptr,#_processing_repeat_count
      009EAB E0               [24]  789 	movx	a,@dptr
                                    790 ;	quantum/repeat_key.c:86: }
      009EAC F5 82            [12]  791 	mov	dpl,a
      009EAE 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      009EAF                        803 _repeat_invoke:
      009EAF 12 43 0E         [24]  804 	lcall	_ak820_outline_0035
      009EB2 90 0C 21         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      009EB5 12 38 20         [24]  806 	lcall	_ak820_outline_0014
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      009EB8 90 0C 0D         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      009EBB E0               [24]  809 	movx	a,@dptr
      009EBC 60 01            [24]  810 	jz	00102$
      009EBE 22               [24]  811 	ret
      009EBF                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      009EBF 90 0E 0C         [24]  814 	mov	dptr,#_processing_repeat_count
      009EC2 E0               [24]  815 	movx	a,@dptr
      009EC3 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      009EC5 22               [24]  818 	ret
      009EC6                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      009EC6 90 0C 21         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      009EC9 12 4D 27         [24]  822 	lcall	_ak820_outline_0012
      009ECC 74 05            [12]  823 	mov	a,#0x05
      009ECE 12 74 3F         [24]  824 	lcall	_ak820_outline_0011
      009ED1 12 B5 A4         [24]  825 	lcall	__gptrget
      009ED4 70 03            [24]  826 	jnz	00197$
      009ED6 02 9F 51         [24]  827 	ljmp	00117$
      009ED9                        828 00197$:
                                    829 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      009ED9 12 A1 5B         [24]  830 	lcall	_ak820_outline_0170
      009EDC 70 0A            [24]  831 	jnz	00105$
      009EDE 90 0C 0B         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      009EE1 E0               [24]  833 	movx	a,@dptr
      009EE2 FB               [12]  834 	mov	r3,a
      009EE3 A3               [24]  835 	inc	dptr
      009EE4 E0               [24]  836 	movx	a,@dptr
      009EE5 4B               [12]  837 	orl	a,r3
      009EE6 70 01            [24]  838 	jnz	00106$
      009EE8                        839 00105$:
      009EE8 22               [24]  840 	ret
      009EE9                        841 00106$:
                                    842 ;	quantum/repeat_key.c:107: registered_record = last_record;
      009EE9 90 0D 93         [24]  843 	mov	dptr,#___memcpy_PARM_2
      009EEC 74 04            [12]  844 	mov	a,#_last_record
      009EEE F0               [24]  845 	movx	@dptr,a
      009EEF 74 0C            [12]  846 	mov	a,#(_last_record >> 8)
      009EF1 12 38 6B         [24]  847 	lcall	_ak820_outline_0089
      009EF4 90 0D 96         [24]  848 	mov	dptr,#___memcpy_PARM_3
      009EF7 74 09            [12]  849 	mov	a,#0x09
      009EF9 12 38 97         [24]  850 	lcall	_ak820_outline_0122
      009EFC 90 0C 0E         [24]  851 	mov	dptr,#_registered_record
      009EFF F5 F0            [12]  852 	mov	b,a
      009F01 12 B4 CB         [24]  853 	lcall	___memcpy
                                    854 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      009F04 90 0E 0A         [24]  855 	mov	dptr,#_last_mods
      009F07 E0               [24]  856 	movx	a,@dptr
      009F08 90 0C 18         [24]  857 	mov	dptr,#_registered_mods
      009F0B F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/repeat_key.c:110: if (alternate) {
      009F0C 90 0C 20         [24]  860 	mov	dptr,#_repeat_invoke_PARM_2
      009F0F E0               [24]  861 	movx	a,@dptr
      009F10 FC               [12]  862 	mov	r4,a
      009F11 E0               [24]  863 	movx	a,@dptr
      009F12 60 1C            [24]  864 	jz	00111$
                                    865 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      009F14 C0 04            [24]  866 	push	ar4
      009F16 12 A0 24         [24]  867 	lcall	_get_alt_repeat_key_keycode
      009F19 AA 82            [24]  868 	mov	r2, dpl
      009F1B AB 83            [24]  869 	mov	r3, dph
      009F1D D0 04            [24]  870 	pop	ar4
      009F1F 90 0C 15         [24]  871 	mov	dptr,#(_registered_record + 0x0007)
      009F22 EA               [12]  872 	mov	a,r2
      009F23 12 8B DC         [24]  873 	lcall	_ak820_outline_0184
                                    874 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      009F26 EA               [12]  875 	mov	a,r2
      009F27 4B               [12]  876 	orl	a,r3
      009F28 70 01            [24]  877 	jnz	00109$
      009F2A 22               [24]  878 	ret
      009F2B                        879 00109$:
                                    880 ;	quantum/repeat_key.c:114: registered_mods = 0;
      009F2B 90 0C 18         [24]  881 	mov	dptr,#_registered_mods
      009F2E E4               [12]  882 	clr	a
      009F2F F0               [24]  883 	movx	@dptr,a
      009F30                        884 00111$:
                                    885 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      009F30 EC               [12]  886 	mov	a,r4
      009F31 60 04            [24]  887 	jz	00123$
      009F33 7C FF            [12]  888 	mov	r4,#0xff
      009F35 80 02            [24]  889 	sjmp	00124$
      009F37                        890 00123$:
      009F37 7C 01            [12]  891 	mov	r4,#0x01
      009F39                        892 00124$:
      009F39 8C 82            [24]  893 	mov	dpl, r4
      009F3B 12 9E 5F         [24]  894 	lcall	_update_last_repeat_count
                                    895 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      009F3E 90 0C 18         [24]  896 	mov	dptr,#_registered_mods
      009F41 E0               [24]  897 	movx	a,@dptr
      009F42 F5 82            [12]  898 	mov	dpl,a
      009F44 12 73 D2         [24]  899 	lcall	_register_weak_mods
                                    900 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      009F47 90 0E 0B         [24]  901 	mov	dptr,#_last_repeat_count
      009F4A E0               [24]  902 	movx	a,@dptr
      009F4B 90 0C 17         [24]  903 	mov	dptr,#_registered_repeat_count
      009F4E F0               [24]  904 	movx	@dptr,a
      009F4F 80 2A            [24]  905 	sjmp	00118$
      009F51                        906 00117$:
                                    907 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      009F51 12 A1 5B         [24]  908 	lcall	_ak820_outline_0170
      009F54 60 24            [24]  909 	jz	00112$
      009F56 74 01            [12]  910 	mov	a,#0x01
      009F58 12 74 3F         [24]  911 	lcall	_ak820_outline_0011
      009F5B 12 B5 A4         [24]  912 	lcall	__gptrget
      009F5E FA               [12]  913 	mov	r2,a
      009F5F 90 0C 0F         [24]  914 	mov	dptr,#(_registered_record + 0x0001)
      009F62 E0               [24]  915 	movx	a,@dptr
      009F63 FC               [12]  916 	mov	r4,a
      009F64 EA               [12]  917 	mov	a,r2
      009F65 B5 04 12         [24]  918 	cjne	a,ar4,00112$
                                    919 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      009F68 12 6B B5         [24]  920 	lcall	_ak820_outline_0046
      009F6B 12 B5 A4         [24]  921 	lcall	__gptrget
      009F6E FD               [12]  922 	mov	r5,a
      009F6F 90 0C 0E         [24]  923 	mov	dptr,#_registered_record
      009F72 E0               [24]  924 	movx	a,@dptr
      009F73 FF               [12]  925 	mov	r7,a
      009F74 ED               [12]  926 	mov	a,r5
      009F75 B5 07 02         [24]  927 	cjne	a,ar7,00206$
      009F78 80 01            [24]  928 	sjmp	00118$
      009F7A                        929 00206$:
      009F7A                        930 00112$:
      009F7A 22               [24]  931 	ret
      009F7B                        932 00118$:
                                    933 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      009F7B 90 0C 21         [24]  934 	mov	dptr,#_repeat_invoke_event_10000_182
      009F7E 12 4D 27         [24]  935 	lcall	_ak820_outline_0012
      009F81 90 0D 93         [24]  936 	mov	dptr,#___memcpy_PARM_2
      009F84 ED               [12]  937 	mov	a,r5
      009F85 12 38 20         [24]  938 	lcall	_ak820_outline_0014
      009F88 90 0D 96         [24]  939 	mov	dptr,#___memcpy_PARM_3
      009F8B 74 06            [12]  940 	mov	a,#0x06
      009F8D 12 38 97         [24]  941 	lcall	_ak820_outline_0122
      009F90 90 0C 0E         [24]  942 	mov	dptr,#_registered_record
      009F93 F5 F0            [12]  943 	mov	b,a
      009F95 12 B4 CB         [24]  944 	lcall	___memcpy
                                    945 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      009F98 90 0C 17         [24]  946 	mov	dptr,#_registered_repeat_count
      009F9B E0               [24]  947 	movx	a,@dptr
      009F9C 90 0E 0C         [24]  948 	mov	dptr,#_processing_repeat_count
      009F9F F0               [24]  949 	movx	@dptr,a
                                    950 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      009FA0 90 0C 0D         [24]  951 	mov	dptr,#_ak820_repeat_invoking
      009FA3 74 01            [12]  952 	mov	a,#0x01
      009FA5 F0               [24]  953 	movx	@dptr,a
                                    954 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      009FA6 90 0C 0E         [24]  955 	mov	dptr,#_registered_record
      009FA9 75 F0 00         [24]  956 	mov	b, #0x00
      009FAC 12 6F 0A         [24]  957 	lcall	_process_record
                                    958 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      009FAF 90 0C 0D         [24]  959 	mov	dptr,#_ak820_repeat_invoking
      009FB2 E4               [12]  960 	clr	a
      009FB3 F0               [24]  961 	movx	@dptr,a
                                    962 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      009FB4 90 0E 0C         [24]  963 	mov	dptr,#_processing_repeat_count
      009FB7 F0               [24]  964 	movx	@dptr,a
                                    965 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      009FB8 90 0C 13         [24]  966 	mov	dptr,#(_registered_record + 0x0005)
      009FBB E0               [24]  967 	movx	a,@dptr
      009FBC 70 0F            [24]  968 	jnz	00121$
                                    969 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      009FBE 90 0C 18         [24]  970 	mov	dptr,#_registered_mods
      009FC1 E0               [24]  971 	movx	a,@dptr
      009FC2 F5 82            [12]  972 	mov	dpl,a
      009FC4 12 73 E6         [24]  973 	lcall	_unregister_weak_mods
                                    974 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      009FC7 90 0C 15         [24]  975 	mov	dptr,#(_registered_record + 0x0007)
      009FCA 12 4D 73         [24]  976 	lcall	_ak820_outline_0166
      009FCD                        977 00121$:
                                    978 ;	quantum/repeat_key.c:146: }
      009FCD 22               [24]  979 	ret
                                    980 ;------------------------------------------------------------
                                    981 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    982 ;------------------------------------------------------------
                                    983 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    984 ;------------------------------------------------------------
                                    985 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t* event) {
                                    986 ;	-----------------------------------------
                                    987 ;	 function repeat_key_invoke
                                    988 ;	-----------------------------------------
      009FCE                        989 _repeat_key_invoke:
      009FCE 12 43 0E         [24]  990 	lcall	_ak820_outline_0035
      009FD1 90 0C 24         [24]  991 	mov	dptr,#_repeat_key_invoke_event_10000_197
      009FD4 12 38 20         [24]  992 	lcall	_ak820_outline_0014
                                    993 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      009FD7 90 0C 24         [24]  994 	mov	dptr,#_repeat_key_invoke_event_10000_197
      009FDA 12 4D 27         [24]  995 	lcall	_ak820_outline_0012
      009FDD 90 0C 20         [24]  996 	mov	dptr,#_repeat_invoke_PARM_2
      009FE0 E4               [12]  997 	clr	a
      009FE1 12 4D 30         [24]  998 	lcall	_ak820_outline_0038
                                    999 ;	quantum/repeat_key.c:150: }
      009FE4 02 9E AF         [24] 1000 	ljmp	_repeat_invoke
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1003 ;------------------------------------------------------------
                                   1004 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1005 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1006 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                   1007 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1008 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1009 ;------------------------------------------------------------
                                   1010 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1011 ;	-----------------------------------------
                                   1012 ;	 function find_alt_keycode
                                   1013 ;	-----------------------------------------
      009FE7                       1014 _find_alt_keycode:
      009FE7 12 43 0E         [24] 1015 	lcall	_ak820_outline_0035
      009FEA 90 0C 29         [24] 1016 	mov	dptr,#_find_alt_keycode_table_10000_199
      009FED 12 38 20         [24] 1017 	lcall	_ak820_outline_0014
                                   1018 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      009FF0 90 0C 29         [24] 1019 	mov	dptr,#_find_alt_keycode_table_10000_199
      009FF3 12 4D 27         [24] 1020 	lcall	_ak820_outline_0012
                                   1021 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      009FF6 7C 00            [12] 1022 	mov	r4,#0x00
      009FF8                       1023 00105$:
      009FF8 90 0C 27         [24] 1024 	mov	dptr,#_find_alt_keycode_PARM_2
      009FFB E0               [24] 1025 	movx	a,@dptr
      009FFC FB               [12] 1026 	mov	r3,a
      009FFD C3               [12] 1027 	clr	c
      009FFE EC               [12] 1028 	mov	a,r4
      009FFF 9B               [12] 1029 	subb	a,r3
      00A000 50 1E            [24] 1030 	jnc	00103$
                                   1031 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00A002 EC               [12] 1032 	mov	a,r4
      00A003 12 8B 66         [24] 1033 	lcall	_ak820_outline_0025
      00A006 12 B5 A4         [24] 1034 	lcall	__gptrget
      00A009 F9               [12] 1035 	mov	r1,a
      00A00A 90 0C 28         [24] 1036 	mov	dptr,#_find_alt_keycode_PARM_3
      00A00D E0               [24] 1037 	movx	a,@dptr
      00A00E B5 01 0C         [24] 1038 	cjne	a,ar1,00106$
                                   1039 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00A011 74 01            [12] 1040 	mov	a,#0x01
      00A013 6C               [12] 1041 	xrl	a,r4
      00A014 12 8B 66         [24] 1042 	lcall	_ak820_outline_0025
      00A017 12 B5 A4         [24] 1043 	lcall	__gptrget
      00A01A F5 82            [12] 1044 	mov	dpl,a
      00A01C 22               [24] 1045 	ret
      00A01D                       1046 00106$:
                                   1047 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A01D 0C               [12] 1048 	inc	r4
      00A01E 80 D8            [24] 1049 	sjmp	00105$
      00A020                       1050 00103$:
                                   1051 ;	quantum/repeat_key.c:174: return KC_NO;
      00A020 75 82 00         [24] 1052 	mov	dpl, #0x00
                                   1053 ;	quantum/repeat_key.c:175: }
      00A023 22               [24] 1054 	ret
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1057 ;------------------------------------------------------------
                                   1058 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1059 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1060 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1061 ;------------------------------------------------------------
                                   1062 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1063 ;	-----------------------------------------
                                   1064 ;	 function get_alt_repeat_key_keycode
                                   1065 ;	-----------------------------------------
      00A024                       1066 _get_alt_repeat_key_keycode:
                                   1067 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00A024 90 0C 0B         [24] 1068 	mov	dptr,#(_last_record + 0x0007)
      00A027 12 38 42         [24] 1069 	lcall	_ak820_outline_0052
      00A02A 90 0C 2C         [24] 1070 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A02D 12 46 DE         [24] 1071 	lcall	_ak820_outline_0060
                                   1072 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00A030 90 0E 0A         [24] 1073 	mov	dptr,#_last_mods
      00A033 E0               [24] 1074 	movx	a,@dptr
      00A034 FD               [12] 1075 	mov	r5,a
      00A035 90 0C 2E         [24] 1076 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A038 F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A039 90 0C 34         [24] 1079 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A03C ED               [12] 1080 	mov	a,r5
      00A03D 12 43 32         [24] 1081 	lcall	_ak820_outline_0076
      00A040 C0 07            [24] 1082 	push	ar7
      00A042 C0 06            [24] 1083 	push	ar6
      00A044 12 A1 57         [24] 1084 	lcall	_get_alt_repeat_key_keycode_user
      00A047 12 43 6C         [24] 1085 	lcall	_ak820_outline_0144
      00A04A D0 06            [24] 1086 	pop	ar6
      00A04C D0 07            [24] 1087 	pop	ar7
                                   1088 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00A04E 8C 02            [24] 1089 	mov	ar2,r4
      00A050 8D 03            [24] 1090 	mov	ar3,r5
      00A052 BA 01 05         [24] 1091 	cjne	r2,#0x01,00176$
      00A055 BB 00 02         [24] 1092 	cjne	r3,#0x00,00176$
      00A058 80 04            [24] 1093 	sjmp	00102$
      00A05A                       1094 00176$:
                                   1095 ;	quantum/repeat_key.c:186: return alt_keycode;
      00A05A 12 38 92         [24] 1096 	lcall	_ak820_outline_0121
      00A05D 22               [24] 1097 	ret
      00A05E                       1098 00102$:
                                   1099 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A05E 90 0C 2E         [24] 1100 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A061 E0               [24] 1101 	movx	a,@dptr
      00A062 54 F0            [12] 1102 	anl	a,#0xf0
      00A064 60 02            [24] 1103 	jz	00118$
      00A066 74 10            [12] 1104 	mov	a,#0x10
      00A068                       1105 00118$:
      00A068 FD               [12] 1106 	mov	r5,a
                                   1107 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00A069 90 0C 2E         [24] 1108 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A06C E0               [24] 1109 	movx	a,@dptr
      00A06D FC               [12] 1110 	mov	r4,a
      00A06E C4               [12] 1111 	swap	a
      00A06F 54 0F            [12] 1112 	anl	a,#0x0f
      00A071 4C               [12] 1113 	orl	a,r4
      00A072 54 0F            [12] 1114 	anl	a,#0x0f
      00A074 4D               [12] 1115 	orl	a,r5
      00A075 F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A076 8E 04            [24] 1118 	mov	ar4,r6
      00A078 8F 05            [24] 1119 	mov	ar5,r7
      00A07A 74 FF            [12] 1120 	mov	a,#0x100 - 0x01
      00A07C 2D               [12] 1121 	add	a,r5
      00A07D 50 1C            [24] 1122 	jnc	00115$
      00A07F C3               [12] 1123 	clr	c
      00A080 74 FF            [12] 1124 	mov	a,#0xff
      00A082 9C               [12] 1125 	subb	a,r4
      00A083 74 1F            [12] 1126 	mov	a,#0x1f
      00A085 9D               [12] 1127 	subb	a,r5
      00A086 40 13            [24] 1128 	jc	00115$
                                   1129 ;	free result
                                   1130 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00A088 8F 06            [24] 1131 	mov	ar6,r7
      00A08A 53 06 1F         [24] 1132 	anl	ar6,#0x1f
      00A08D 90 0C 2E         [24] 1133 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A090 E0               [24] 1134 	movx	a,@dptr
      00A091 4E               [12] 1135 	orl	a,r6
      00A092 F0               [24] 1136 	movx	@dptr,a
                                   1137 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A093 7D 00            [12] 1138 	mov	r5,#0x00
      00A095 90 0C 2C         [24] 1139 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A098 12 38 5F         [24] 1140 	lcall	_ak820_outline_0071
                                   1141 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00A09B                       1142 00115$:
      00A09B 90 0C 2C         [24] 1143 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A09E 12 46 89         [24] 1144 	lcall	_ak820_outline_0008
      00A0A1 C3               [12] 1145 	clr	c
      00A0A2 74 FF            [12] 1146 	mov	a,#0xff
      00A0A4 9C               [12] 1147 	subb	a,r4
      00A0A5 E4               [12] 1148 	clr	a
      00A0A6 9D               [12] 1149 	subb	a,r5
      00A0A7 50 03            [24] 1150 	jnc	00180$
      00A0A9 02 A1 39         [24] 1151 	ljmp	00114$
      00A0AC                       1152 00180$:
                                   1153 ;	free result
                                   1154 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A0AC 90 0C 2E         [24] 1155 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A0AF E0               [24] 1156 	movx	a,@dptr
      00A0B0 54 0D            [12] 1157 	anl	a,#0x0d
      00A0B2 60 21            [24] 1158 	jz	00107$
                                   1159 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A0B4 8E 05            [24] 1160 	mov	ar5,r6
      00A0B6 90 0C 27         [24] 1161 	mov	dptr,#_find_alt_keycode_PARM_2
      00A0B9 74 0A            [12] 1162 	mov	a,#0x0a
      00A0BB F0               [24] 1163 	movx	@dptr,a
      00A0BC 90 0C 28         [24] 1164 	mov	dptr,#_find_alt_keycode_PARM_3
      00A0BF ED               [12] 1165 	mov	a,r5
      00A0C0 F0               [24] 1166 	movx	@dptr,a
      00A0C1 90 B9 69         [24] 1167 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00A0C4 75 F0 80         [24] 1168 	mov	b, #0x80
      00A0C7 12 9F E7         [24] 1169 	lcall	_find_alt_keycode
      00A0CA AD 82            [24] 1170 	mov	r5, dpl
      00A0CC 90 0C 2F         [24] 1171 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A0CF ED               [12] 1172 	mov	a,r5
      00A0D0 12 38 97         [24] 1173 	lcall	_ak820_outline_0122
      00A0D3 80 1D            [24] 1174 	sjmp	00108$
      00A0D5                       1175 00107$:
                                   1176 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A0D5 90 0C 27         [24] 1177 	mov	dptr,#_find_alt_keycode_PARM_2
      00A0D8 74 08            [12] 1178 	mov	a,#0x08
      00A0DA F0               [24] 1179 	movx	@dptr,a
      00A0DB 90 0C 28         [24] 1180 	mov	dptr,#_find_alt_keycode_PARM_3
      00A0DE EE               [12] 1181 	mov	a,r6
      00A0DF F0               [24] 1182 	movx	@dptr,a
      00A0E0 90 B9 73         [24] 1183 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A0E3 75 F0 80         [24] 1184 	mov	b, #0x80
      00A0E6 12 9F E7         [24] 1185 	lcall	_find_alt_keycode
      00A0E9 AF 82            [24] 1186 	mov	r7, dpl
      00A0EB 90 0C 2F         [24] 1187 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A0EE EF               [12] 1188 	mov	a,r7
      00A0EF 12 38 97         [24] 1189 	lcall	_ak820_outline_0122
      00A0F2                       1190 00108$:
                                   1191 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00A0F2 90 0C 2F         [24] 1192 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A0F5 12 6B AD         [24] 1193 	lcall	_ak820_outline_0039
      00A0F8 70 22            [24] 1194 	jnz	00110$
                                   1195 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A0FA 90 0C 2C         [24] 1196 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A0FD E0               [24] 1197 	movx	a,@dptr
      00A0FE FF               [12] 1198 	mov	r7,a
      00A0FF 90 0C 27         [24] 1199 	mov	dptr,#_find_alt_keycode_PARM_2
      00A102 74 16            [12] 1200 	mov	a,#0x16
      00A104 F0               [24] 1201 	movx	@dptr,a
      00A105 90 0C 28         [24] 1202 	mov	dptr,#_find_alt_keycode_PARM_3
      00A108 EF               [12] 1203 	mov	a,r7
      00A109 F0               [24] 1204 	movx	@dptr,a
      00A10A 90 B9 7B         [24] 1205 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00A10D 75 F0 80         [24] 1206 	mov	b, #0x80
      00A110 12 9F E7         [24] 1207 	lcall	_find_alt_keycode
      00A113 AF 82            [24] 1208 	mov	r7, dpl
      00A115 90 0C 2F         [24] 1209 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A118 EF               [12] 1210 	mov	a,r7
      00A119 12 38 97         [24] 1211 	lcall	_ak820_outline_0122
      00A11C                       1212 00110$:
                                   1213 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00A11C 90 0C 2F         [24] 1214 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A11F 12 38 42         [24] 1215 	lcall	_ak820_outline_0052
      00A122 90 0C 2F         [24] 1216 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A125 12 6B AD         [24] 1217 	lcall	_ak820_outline_0039
      00A128 60 0F            [24] 1218 	jz	00114$
                                   1219 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00A12A 90 0C 2E         [24] 1220 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A12D E0               [24] 1221 	movx	a,@dptr
      00A12E FD               [12] 1222 	mov	r5,a
      00A12F E4               [12] 1223 	clr	a
      00A130 42 06            [12] 1224 	orl	ar6,a
      00A132 ED               [12] 1225 	mov	a,r5
      00A133 42 07            [12] 1226 	orl	ar7,a
      00A135 12 38 8D         [24] 1227 	lcall	_ak820_outline_0114
      00A138 22               [24] 1228 	ret
      00A139                       1229 00114$:
                                   1230 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00A139 90 00 00         [24] 1231 	mov	dptr,#0x0000
                                   1232 ;	quantum/repeat_key.c:281: }
      00A13C 22               [24] 1233 	ret
                                   1234 ;------------------------------------------------------------
                                   1235 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1236 ;------------------------------------------------------------
                                   1237 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1238 ;------------------------------------------------------------
                                   1239 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1240 ;	-----------------------------------------
                                   1241 ;	 function alt_repeat_key_invoke
                                   1242 ;	-----------------------------------------
      00A13D                       1243 _alt_repeat_key_invoke:
      00A13D 12 43 0E         [24] 1244 	lcall	_ak820_outline_0035
      00A140 90 0C 31         [24] 1245 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A143 12 38 20         [24] 1246 	lcall	_ak820_outline_0014
                                   1247 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00A146 90 0C 31         [24] 1248 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A149 12 4D 27         [24] 1249 	lcall	_ak820_outline_0012
      00A14C 90 0C 20         [24] 1250 	mov	dptr,#_repeat_invoke_PARM_2
      00A14F 74 01            [12] 1251 	mov	a,#0x01
      00A151 12 4D 30         [24] 1252 	lcall	_ak820_outline_0038
                                   1253 ;	quantum/repeat_key.c:286: }
      00A154 02 9E AF         [24] 1254 	ljmp	_repeat_invoke
                                   1255 ;------------------------------------------------------------
                                   1256 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1257 ;------------------------------------------------------------
                                   1258 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1259 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1260 ;------------------------------------------------------------
                                   1261 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1262 ;	-----------------------------------------
                                   1263 ;	 function get_alt_repeat_key_keycode_user
                                   1264 ;	-----------------------------------------
      00A157                       1265 _get_alt_repeat_key_keycode_user:
                                   1266 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00A157 90 00 01         [24] 1267 	mov	dptr,#0x0001
                                   1268 ;	quantum/repeat_key.c:291: }
      00A15A 22               [24] 1269 	ret
                                   1270 	.area CSEG    (CODE)
                                   1271 	.area CONST   (CODE)
                                   1272 	.area CONST   (CODE)
      00B969                       1273 _get_alt_repeat_key_keycode_pairs_50000_214:
      00B969 09                    1274 	.db #0x09	; 9
      00B96A 05                    1275 	.db #0x05	; 5
      00B96B 07                    1276 	.db #0x07	; 7
      00B96C 18                    1277 	.db #0x18	; 24
      00B96D 11                    1278 	.db #0x11	; 17
      00B96E 13                    1279 	.db #0x13	; 19
      00B96F 04                    1280 	.db #0x04	; 4
      00B970 08                    1281 	.db #0x08	; 8
      00B971 12                    1282 	.db #0x12	; 18
      00B972 0C                    1283 	.db #0x0c	; 12
                                   1284 	.area CSEG    (CODE)
                                   1285 	.area CONST   (CODE)
      00B973                       1286 _get_alt_repeat_key_keycode_pairs_50000_215:
      00B973 0D                    1287 	.db #0x0d	; 13
      00B974 0E                    1288 	.db #0x0e	; 14
      00B975 0B                    1289 	.db #0x0b	; 11
      00B976 0F                    1290 	.db #0x0f	; 15
      00B977 1A                    1291 	.db #0x1a	; 26
      00B978 05                    1292 	.db #0x05	; 5
      00B979 08                    1293 	.db #0x08	; 8
      00B97A 05                    1294 	.db #0x05	; 5
                                   1295 	.area CSEG    (CODE)
                                   1296 	.area CONST   (CODE)
      00B97B                       1297 _get_alt_repeat_key_keycode_pairs_50000_217:
      00B97B 50                    1298 	.db #0x50	; 80	'P'
      00B97C 4F                    1299 	.db #0x4f	; 79	'O'
      00B97D 52                    1300 	.db #0x52	; 82	'R'
      00B97E 51                    1301 	.db #0x51	; 81	'Q'
      00B97F 4A                    1302 	.db #0x4a	; 74	'J'
      00B980 4D                    1303 	.db #0x4d	; 77	'M'
      00B981 4B                    1304 	.db #0x4b	; 75	'K'
      00B982 4E                    1305 	.db #0x4e	; 78	'N'
      00B983 2A                    1306 	.db #0x2a	; 42
      00B984 4C                    1307 	.db #0x4c	; 76	'L'
      00B985 2F                    1308 	.db #0x2f	; 47
      00B986 30                    1309 	.db #0x30	; 48	'0'
      00B987 B6                    1310 	.db #0xb6	; 182
      00B988 B7                    1311 	.db #0xb7	; 183
      00B989 AB                    1312 	.db #0xab	; 171
      00B98A AC                    1313 	.db #0xac	; 172
      00B98B BB                    1314 	.db #0xbb	; 187
      00B98C BC                    1315 	.db #0xbc	; 188
      00B98D A9                    1316 	.db #0xa9	; 169
      00B98E AA                    1317 	.db #0xaa	; 170
      00B98F BD                    1318 	.db #0xbd	; 189
      00B990 BE                    1319 	.db #0xbe	; 190
                                   1320 	.area CSEG    (CODE)
                                   1321 	.area XINIT   (CODE)
      00BDF2                       1322 __xinit__last_mods:
      00BDF2 00                    1323 	.db #0x00	; 0
      00BDF3                       1324 __xinit__last_repeat_count:
      00BDF3 00                    1325 	.db #0x00	;  0
      00BDF4                       1326 __xinit__processing_repeat_count:
      00BDF4 00                    1327 	.db #0x00	;  0
                                   1328 	.area CABS    (ABS,CODE)
                                   1329 
                                   1330 ; Experimental exact instruction outlining.
                                   1331 	.globl _ak820_outline_0008
                                   1332 	.globl _ak820_outline_0011
                                   1333 	.globl _ak820_outline_0012
                                   1334 	.globl _ak820_outline_0014
                                   1335 	.globl _ak820_outline_0025
                                   1336 	.globl _ak820_outline_0035
                                   1337 	.globl _ak820_outline_0038
                                   1338 	.globl _ak820_outline_0039
                                   1339 	.globl _ak820_outline_0046
                                   1340 	.globl _ak820_outline_0052
                                   1341 	.globl _ak820_outline_0060
                                   1342 	.globl _ak820_outline_0071
                                   1343 	.globl _ak820_outline_0076
                                   1344 	.globl _ak820_outline_0089
                                   1345 	.globl _ak820_outline_0112
                                   1346 	.globl _ak820_outline_0113
                                   1347 	.globl _ak820_outline_0114
                                   1348 	.globl _ak820_outline_0121
                                   1349 	.globl _ak820_outline_0122
                                   1350 	.globl _ak820_outline_0144
                                   1351 	.globl _ak820_outline_0166
                                   1352 	.globl _ak820_outline_0170
                                   1353 	.globl _ak820_outline_0184
                                   1354 
                                   1355 	.area CSEG (CODE)
                                   1356 ; function ak820_outline_0170
      00A15B                       1357 _ak820_outline_0170:
      00A15B 90 0C 15         [24] 1358 	mov	dptr,#(_registered_record+0x0007)
      00A15E E0               [24] 1359 	movx	a,@dptr
      00A15F FB               [12] 1360 	mov	r3,a
      00A160 A3               [24] 1361 	inc	dptr
      00A161 E0               [24] 1362 	movx	a,@dptr
      00A162 4B               [12] 1363 	orl	a,r3
      00A163 22               [24] 1364 	ret
