                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _del_owned_mods
                                     12 	.globl _add_owned_mods
                                     13 	.globl _send_keyboard_report
                                     14 	.globl _layer_hold_off
                                     15 	.globl _layer_hold_on
                                     16 	.globl _unregister_mods
                                     17 	.globl _register_mods
                                     18 	.globl _process_record
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_tapping_before
                                    263 	.globl _ak820_tapping_process
                                    264 	.globl _ak820_tapping_cancel
                                    265 ;--------------------------------------------------------
                                    266 ; special function registers
                                    267 ;--------------------------------------------------------
                                    268 	.area RSEG    (ABS,DATA)
      000000                        269 	.org 0x0000
                           0000D0   270 _PSW	=	0x00d0
                           0000E0   271 _ACC	=	0x00e0
                           0000F0   272 _B	=	0x00f0
                           0000FD   273 _A_INV	=	0x00fd
                           000081   274 _SP	=	0x0081
                           000082   275 _DPL	=	0x0082
                           000083   276 _DPH	=	0x0083
                           0000A1   277 _SAFE_MOD	=	0x00a1
                           0000B1   278 _GLOBAL_CFG	=	0x00b1
                           000087   279 _PCON	=	0x0087
                           0000BA   280 _POWER_CFG	=	0x00ba
                           0000B9   281 _CLOCK_CFG	=	0x00b9
                           0000A9   282 _WAKE_CTRL	=	0x00a9
                           0000FE   283 _RESET_KEEP	=	0x00fe
                           0000FF   284 _WDOG_COUNT	=	0x00ff
                           0000A8   285 _IE	=	0x00a8
                           0000B8   286 _IP	=	0x00b8
                           0000E8   287 _IE_EX	=	0x00e8
                           0000E9   288 _IP_EX	=	0x00e9
                           0000B2   289 _GPIO_IE	=	0x00b2
                           008584   290 _ROM_ADDR	=	0x8584
                           000084   291 _ROM_ADDR_L	=	0x0084
                           000085   292 _ROM_ADDR_H	=	0x0085
                           008F8E   293 _ROM_DATA_HI	=	0x8f8e
                           00008E   294 _ROM_DATA_HL	=	0x008e
                           00008F   295 _ROM_DATA_HH	=	0x008f
                           000086   296 _ROM_CTRL	=	0x0086
                           000080   297 _P0	=	0x0080
                           0000C4   298 _P0_MOD_OC	=	0x00c4
                           0000C5   299 _P0_DIR_PU	=	0x00c5
                           000090   300 _P1	=	0x0090
                           000092   301 _P1_MOD_OC	=	0x0092
                           000093   302 _P1_DIR_PU	=	0x0093
                           0000A0   303 _P2	=	0x00a0
                           000094   304 _P2_MOD_OC	=	0x0094
                           000095   305 _P2_DIR_PU	=	0x0095
                           0000B0   306 _P3	=	0x00b0
                           000096   307 _P3_MOD_OC	=	0x0096
                           000097   308 _P3_DIR_PU	=	0x0097
                           0000C0   309 _P4	=	0x00c0
                           0000C2   310 _P4_MOD_OC	=	0x00c2
                           0000C3   311 _P4_DIR_PU	=	0x00c3
                           0000C1   312 _P4_LED_KEY	=	0x00c1
                           0000AA   313 _P5_IN	=	0x00aa
                           0000AB   314 _P5_OUT_PU	=	0x00ab
                           0000AC   315 _P5_DIR	=	0x00ac
                           0000AD   316 _P6_IN	=	0x00ad
                           0000AE   317 _P6_OUT_PU	=	0x00ae
                           0000AF   318 _P6_DIR	=	0x00af
                           0000F1   319 _P7	=	0x00f1
                           0000A2   320 _XBUS_AUX	=	0x00a2
                           000088   321 _TCON	=	0x0088
                           000089   322 _TMOD	=	0x0089
                           00008A   323 _TL0	=	0x008a
                           00008B   324 _TL1	=	0x008b
                           00008C   325 _TH0	=	0x008c
                           00008D   326 _TH1	=	0x008d
                           000098   327 _SCON	=	0x0098
                           000099   328 _SBUF	=	0x0099
                           0000C8   329 _T2CON	=	0x00c8
                           0000C9   330 _T2MOD	=	0x00c9
                           00CBCA   331 _RCAP2	=	0xcbca
                           0000CA   332 _RCAP2L	=	0x00ca
                           0000CB   333 _RCAP2H	=	0x00cb
                           00CDCC   334 _T2COUNT	=	0xcdcc
                           0000CC   335 _TL2	=	0x00cc
                           0000CD   336 _TH2	=	0x00cd
                           00CFCE   337 _T2CAP1	=	0xcfce
                           0000CE   338 _T2CAP1L	=	0x00ce
                           0000CF   339 _T2CAP1H	=	0x00cf
                           0000F8   340 _SPI0_STAT	=	0x00f8
                           0000F9   341 _SPI0_DATA	=	0x00f9
                           0000FA   342 _SPI0_CTRL	=	0x00fa
                           0000FB   343 _SPI0_CK_SE	=	0x00fb
                           0000FC   344 _SPI0_SETUP	=	0x00fc
                           0000BC   345 _SCON1	=	0x00bc
                           0000BD   346 _SBUF1	=	0x00bd
                           0000BE   347 _SBAUD1	=	0x00be
                           0000BF   348 _SIF1	=	0x00bf
                           0000B4   349 _SPI1_STAT	=	0x00b4
                           0000B5   350 _SPI1_DATA	=	0x00b5
                           0000B6   351 _SPI1_CTRL	=	0x00b6
                           0000B7   352 _SPI1_CK_SE	=	0x00b7
                           0000F3   353 _ADC_CTRL	=	0x00f3
                           00F5F4   354 _ADC_DAT	=	0xf5f4
                           0000F4   355 _ADC_DAT_L	=	0x00f4
                           0000F5   356 _ADC_DAT_H	=	0x00f5
                           0000F6   357 _ADC_CHAN	=	0x00f6
                           0000A6   358 _LED_COMMON	=	0x00a6
                           0000A7   359 _LED_PWM_OE	=	0x00a7
                           00C7C6   360 _LED_DMA	=	0xc7c6
                           0000C6   361 _LED_DMA_L	=	0x00c6
                           0000C7   362 _LED_DMA_H	=	0x00c7
                           0000F7   363 _LED_STATUS	=	0x00f7
                           0000B3   364 _I2CX_INT	=	0x00b3
                           0000BB   365 _I2CS_INT_ST	=	0x00bb
                                    366 ;--------------------------------------------------------
                                    367 ; special function bits
                                    368 ;--------------------------------------------------------
                                    369 	.area RSEG    (ABS,DATA)
      000000                        370 	.org 0x0000
                           0000D7   371 _CY	=	0x00d7
                           0000D6   372 _AC	=	0x00d6
                           0000D5   373 _F0	=	0x00d5
                           0000D4   374 _RS1	=	0x00d4
                           0000D3   375 _RS0	=	0x00d3
                           0000D2   376 _OV	=	0x00d2
                           0000D1   377 _F1	=	0x00d1
                           0000D0   378 _P	=	0x00d0
                           0000AF   379 _EA	=	0x00af
                           0000AE   380 _E_DIS	=	0x00ae
                           0000AD   381 _ET2	=	0x00ad
                           0000AC   382 _ES	=	0x00ac
                           0000AB   383 _ET1	=	0x00ab
                           0000AA   384 _EX1	=	0x00aa
                           0000A9   385 _ET0	=	0x00a9
                           0000A8   386 _EX0	=	0x00a8
                           0000BF   387 _PH_FLAG	=	0x00bf
                           0000BE   388 _PL_FLAG	=	0x00be
                           0000BD   389 _PT2	=	0x00bd
                           0000BC   390 _PS	=	0x00bc
                           0000BB   391 _PT1	=	0x00bb
                           0000BA   392 _PX1	=	0x00ba
                           0000B9   393 _PT0	=	0x00b9
                           0000B8   394 _PX0	=	0x00b8
                           0000EF   395 _IE_WDOG	=	0x00ef
                           0000EE   396 _IE_GPIO	=	0x00ee
                           0000ED   397 _IE_PWM_I2C	=	0x00ed
                           0000EC   398 _IE_UART1	=	0x00ec
                           0000EB   399 _IE_ADC	=	0x00eb
                           0000E9   400 _IE_USB	=	0x00e9
                           0000E8   401 _IE_SPI0	=	0x00e8
                           000087   402 _P0_7	=	0x0087
                           000086   403 _P0_6	=	0x0086
                           000085   404 _P0_5	=	0x0085
                           000084   405 _P0_4	=	0x0084
                           000083   406 _P0_3	=	0x0083
                           000082   407 _P0_2	=	0x0082
                           000081   408 _P0_1	=	0x0081
                           000080   409 _P0_0	=	0x0080
                           000081   410 _SDA0	=	0x0081
                           000080   411 _SCL0	=	0x0080
                           000083   412 _TXD_	=	0x0083
                           000082   413 _RXD_	=	0x0082
                           000085   414 _AIN13	=	0x0085
                           000084   415 _AIN12	=	0x0084
                           000083   416 _AIN11	=	0x0083
                           000082   417 _AIN10	=	0x0082
                           000081   418 _AIN9	=	0x0081
                           000080   419 _AIN8	=	0x0080
                           000097   420 _P1_7	=	0x0097
                           000096   421 _P1_6	=	0x0096
                           000095   422 _P1_5	=	0x0095
                           000094   423 _P1_4	=	0x0094
                           000093   424 _P1_3	=	0x0093
                           000092   425 _P1_2	=	0x0092
                           000091   426 _P1_1	=	0x0091
                           000090   427 _P1_0	=	0x0090
                           000097   428 _TXD1_	=	0x0097
                           000096   429 _RXD1_	=	0x0096
                           000097   430 _SCK	=	0x0097
                           000096   431 _MISO	=	0x0096
                           000095   432 _MOSI	=	0x0095
                           000094   433 _SCS	=	0x0094
                           000092   434 _INT0_	=	0x0092
                           000091   435 _T2EX	=	0x0091
                           000091   436 _CAP2	=	0x0091
                           000090   437 _T2	=	0x0090
                           000090   438 _CAP1	=	0x0090
                           000097   439 _AIN7	=	0x0097
                           000096   440 _AIN6	=	0x0096
                           000095   441 _AIN5	=	0x0095
                           000094   442 _AIN4	=	0x0094
                           000093   443 _AIN3	=	0x0093
                           000092   444 _AIN2	=	0x0092
                           000091   445 _AIN1	=	0x0091
                           000090   446 _AIN0	=	0x0090
                           0000A7   447 _P2_7	=	0x00a7
                           0000A6   448 _P2_6	=	0x00a6
                           0000A5   449 _P2_5	=	0x00a5
                           0000A4   450 _P2_4	=	0x00a4
                           0000A3   451 _P2_3	=	0x00a3
                           0000A2   452 _P2_2	=	0x00a2
                           0000A1   453 _P2_1	=	0x00a1
                           0000A0   454 _P2_0	=	0x00a0
                           0000A7   455 _TXD1	=	0x00a7
                           0000A6   456 _RXD1	=	0x00a6
                           0000A5   457 _T2EX_	=	0x00a5
                           0000A5   458 _CAP2_	=	0x00a5
                           0000A4   459 _T2_	=	0x00a4
                           0000A4   460 _CAP1_	=	0x00a4
                           0000B7   461 _P3_7	=	0x00b7
                           0000B6   462 _P3_6	=	0x00b6
                           0000B5   463 _P3_5	=	0x00b5
                           0000B4   464 _P3_4	=	0x00b4
                           0000B3   465 _P3_3	=	0x00b3
                           0000B2   466 _P3_2	=	0x00b2
                           0000B1   467 _P3_1	=	0x00b1
                           0000B0   468 _P3_0	=	0x00b0
                           0000B7   469 _SCK1	=	0x00b7
                           0000B6   470 _MISO1	=	0x00b6
                           0000B5   471 _MOSI1	=	0x00b5
                           0000B5   472 _T1	=	0x00b5
                           0000B4   473 _T0	=	0x00b4
                           0000B3   474 _INT1	=	0x00b3
                           0000B2   475 _INT0	=	0x00b2
                           0000B1   476 _TXD	=	0x00b1
                           0000B0   477 _RXD	=	0x00b0
                           0000C6   478 _P4_6	=	0x00c6
                           0000C5   479 _P4_5	=	0x00c5
                           0000C4   480 _P4_4	=	0x00c4
                           0000C3   481 _P4_3	=	0x00c3
                           0000C2   482 _P4_2	=	0x00c2
                           0000C1   483 _P4_1	=	0x00c1
                           0000C0   484 _P4_0	=	0x00c0
                           00008F   485 _TF1	=	0x008f
                           00008E   486 _TR1	=	0x008e
                           00008D   487 _TF0	=	0x008d
                           00008C   488 _TR0	=	0x008c
                           00008B   489 _IE1	=	0x008b
                           00008A   490 _IT1	=	0x008a
                           000089   491 _IE0	=	0x0089
                           000088   492 _IT0	=	0x0088
                           00009F   493 _SM0	=	0x009f
                           00009E   494 _SM1	=	0x009e
                           00009D   495 _SM2	=	0x009d
                           00009C   496 _REN	=	0x009c
                           00009B   497 _TB8	=	0x009b
                           00009A   498 _RB8	=	0x009a
                           000099   499 _TI	=	0x0099
                           000098   500 _RI	=	0x0098
                           0000CF   501 _TF2	=	0x00cf
                           0000CF   502 _CAP1F	=	0x00cf
                           0000CE   503 _EXF2	=	0x00ce
                           0000CD   504 _RCLK	=	0x00cd
                           0000CC   505 _TCLK	=	0x00cc
                           0000CB   506 _EXEN2	=	0x00cb
                           0000CA   507 _TR2	=	0x00ca
                           0000C9   508 _C_T2	=	0x00c9
                           0000C8   509 _CP_RL2	=	0x00c8
                           0000FF   510 _S0_FST_ACT	=	0x00ff
                           0000FE   511 _S0_IF_OV	=	0x00fe
                           0000FD   512 _S0_IF_FIRST	=	0x00fd
                           0000FC   513 _S0_IF_BYTE	=	0x00fc
                           0000FB   514 _S0_FREE	=	0x00fb
                           0000FA   515 _S0_T_FIFO	=	0x00fa
                           0000F8   516 _S0_R_FIFO	=	0x00f8
                           0000F7   517 _ADC_START	=	0x00f7
                                    518 ;--------------------------------------------------------
                                    519 ; overlayable register banks
                                    520 ;--------------------------------------------------------
                                    521 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        522 	.ds 8
                                    523 ;--------------------------------------------------------
                                    524 ; internal ram data
                                    525 ;--------------------------------------------------------
                                    526 	.area DSEG    (DATA)
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable items in internal ram
                                    529 ;--------------------------------------------------------
                                    530 ;--------------------------------------------------------
                                    531 ; indirectly addressable internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area ISEG    (DATA)
                                    534 ;--------------------------------------------------------
                                    535 ; absolute internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area IABS    (ABS,DATA)
                                    538 	.area IABS    (ABS,DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; bit data
                                    541 ;--------------------------------------------------------
                                    542 	.area BSEG    (BIT)
      00000E                        543 _ak820_tapping_before_sloc0_1_0:
      00000E                        544 	.ds 1
                                    545 ;--------------------------------------------------------
                                    546 ; paged external ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area PSEG    (PAG,XDATA)
                                    549 ;--------------------------------------------------------
                                    550 ; uninitialized external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area XSEG    (XDATA)
      00059C                        553 _source_state:
      00059C                        554 	.ds 130
      00061E                        555 _pending_time:
      00061E                        556 	.ds 2
      000620                        557 _pending_code:
      000620                        558 	.ds 2
      000622                        559 _source_PARM_1:
      000622                        560 	.ds 2
      000624                        561 _hold_PARM_2:
      000624                        562 	.ds 1
      000625                        563 _hold_code_10000_597:
      000625                        564 	.ds 2
      000627                        565 _hold_mods_30000_600:
      000627                        566 	.ds 1
      000628                        567 _commit_pending_id_10000_606:
      000628                        568 	.ds 1
      000629                        569 _ak820_tapping_before_event_10000_607:
      000629                        570 	.ds 2
      00062B                        571 _ak820_tapping_process_record_10000_618:
      00062B                        572 	.ds 2
      00062D                        573 _ak820_tapping_process_code_10000_619:
      00062D                        574 	.ds 2
      00062F                        575 _ak820_tapping_process_sc_mods_10000_619:
      00062F                        576 	.ds 1
                                    577 ;--------------------------------------------------------
                                    578 ; absolute external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XABS    (ABS,XDATA)
                                    581 ;--------------------------------------------------------
                                    582 ; initialized external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XISEG   (XDATA)
      000DAB                        585 _pending:
      000DAB                        586 	.ds 1
                                    587 	.area HOME    (CODE)
                                    588 	.area GSINIT0 (CODE)
                                    589 	.area GSINIT1 (CODE)
                                    590 	.area GSINIT2 (CODE)
                                    591 	.area GSINIT3 (CODE)
                                    592 	.area GSINIT4 (CODE)
                                    593 	.area GSINIT5 (CODE)
                                    594 	.area GSINIT  (CODE)
                                    595 	.area GSFINAL (CODE)
                                    596 	.area CSEG    (CODE)
                                    597 ;--------------------------------------------------------
                                    598 ; global & static initialisations
                                    599 ;--------------------------------------------------------
                                    600 	.area HOME    (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area GSINIT  (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; Home
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area HOME    (CODE)
                                    609 ;--------------------------------------------------------
                                    610 ; code
                                    611 ;--------------------------------------------------------
                                    612 	.area CSEG    (CODE)
                                    613 ;------------------------------------------------------------
                                    614 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    615 ;------------------------------------------------------------
                                    616 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    617 ;------------------------------------------------------------
                                    618 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    619 ;	-----------------------------------------
                           000007   620 	ar7 = 0x07
                           000006   621 	ar6 = 0x06
                           000005   622 	ar5 = 0x05
                           000004   623 	ar4 = 0x04
                           000003   624 	ar3 = 0x03
                           000002   625 	ar2 = 0x02
                           000001   626 	ar1 = 0x01
                           000000   627 	ar0 = 0x00
                                    628 ;	 function source
                                    629 ;	-----------------------------------------
      004387                        630 _source:
                                    631 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004387 90 06 23         [24]  632 	mov	dptr,#(_source_PARM_1 + 0x0001)
      00438A E0               [24]  633 	movx	a,@dptr
      00438B FF               [12]  634 	mov	r7,a
      00438C BF 10 00         [24]  635 	cjne	r7,#0x10,00147$
      00438F                        636 00147$:
      00438F 50 14            [24]  637 	jnc	00102$
      004391 90 06 22         [24]  638 	mov	dptr,#_source_PARM_1
      004394 E0               [24]  639 	movx	a,@dptr
      004395 FE               [12]  640 	mov	r6,a
      004396 BE 08 00         [24]  641 	cjne	r6,#0x08,00149$
      004399                        642 00149$:
      004399 50 0A            [24]  643 	jnc	00102$
      00439B 8F 05            [24]  644 	mov	ar5,r7
      00439D ED               [12]  645 	mov	a,r5
      00439E 12 38 C1         [24]  646 	lcall	_ak820_outline_0185
      0043A1 2E               [12]  647 	add	a,r6
      0043A2 F5 82            [12]  648 	mov	dpl,a
      0043A4 22               [24]  649 	ret
      0043A5                        650 00102$:
                                    651 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0043A5 90 06 22         [24]  652 	mov	dptr,#_source_PARM_1
      0043A8 E0               [24]  653 	movx	a,@dptr
      0043A9 FE               [12]  654 	mov	r6,a
      0043AA BE 01 00         [24]  655 	cjne	r6,#0x01,00151$
      0043AD                        656 00151$:
      0043AD 50 0E            [24]  657 	jnc	00109$
                                    658 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043AF BF FD 04         [24]  659 	cjne	r7,#0xfd,00105$
      0043B2 75 82 80         [24]  660 	mov	dpl, #0x80
      0043B5 22               [24]  661 	ret
      0043B6                        662 00105$:
                                    663 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043B6 BF FC 04         [24]  664 	cjne	r7,#0xfc,00109$
      0043B9 75 82 81         [24]  665 	mov	dpl, #0x81
      0043BC 22               [24]  666 	ret
      0043BD                        667 00109$:
                                    668 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0043BD 75 82 FF         [24]  669 	mov	dpl, #0xff
                                    670 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      0043C0 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'hold'
                                    674 ;------------------------------------------------------------
                                    675 ;pressed       Allocated with name '_hold_PARM_2'
                                    676 ;code          Allocated with name '_hold_code_10000_597'
                                    677 ;mods          Allocated with name '_hold_mods_30000_600'
                                    678 ;layer         Allocated with name '_hold_layer_30000_603'
                                    679 ;------------------------------------------------------------
                                    680 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    681 ;	-----------------------------------------
                                    682 ;	 function hold
                                    683 ;	-----------------------------------------
      0043C1                        684 _hold:
      0043C1 12 38 7D         [24]  685 	lcall	_ak820_outline_0112
      0043C4 90 06 25         [24]  686 	mov	dptr,#_hold_code_10000_597
      0043C7 12 38 82         [24]  687 	lcall	_ak820_outline_0113
                                    688 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      0043CA 90 06 25         [24]  689 	mov	dptr,#_hold_code_10000_597
      0043CD 12 46 F6         [24]  690 	lcall	_ak820_outline_0008
      0043D0 74 C0            [12]  691 	mov	a,#0x100 - 0x40
      0043D2 2D               [12]  692 	add	a,r5
      0043D3 40 2E            [24]  693 	jc	00110$
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      0043D5 8F 05            [24]  695 	mov	ar5,r7
      0043D7 53 05 1F         [24]  696 	anl	ar5,#0x1f
      0043DA 90 06 27         [24]  697 	mov	dptr,#_hold_mods_30000_600
      0043DD ED               [12]  698 	mov	a,r5
      0043DE F0               [24]  699 	movx	@dptr,a
                                    700 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      0043DF ED               [12]  701 	mov	a,r5
      0043E0 30 E4 08         [24]  702 	jnb	acc.4,00102$
      0043E3 ED               [12]  703 	mov	a,r5
      0043E4 C4               [12]  704 	swap	a
      0043E5 54 F0            [12]  705 	anl	a,#0xf0
      0043E7 90 06 27         [24]  706 	mov	dptr,#_hold_mods_30000_600
      0043EA F0               [24]  707 	movx	@dptr,a
      0043EB                        708 00102$:
                                    709 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      0043EB 90 06 24         [24]  710 	mov	dptr,#_hold_PARM_2
      0043EE E0               [24]  711 	movx	a,@dptr
      0043EF 60 09            [24]  712 	jz	00104$
      0043F1 90 06 27         [24]  713 	mov	dptr,#_hold_mods_30000_600
      0043F4 E0               [24]  714 	movx	a,@dptr
      0043F5 F5 82            [12]  715 	mov	dpl,a
      0043F7 02 74 27         [24]  716 	ljmp	_register_mods
      0043FA                        717 00104$:
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      0043FA 90 06 27         [24]  719 	mov	dptr,#_hold_mods_30000_600
      0043FD E0               [24]  720 	movx	a,@dptr
      0043FE F5 82            [12]  721 	mov	dpl,a
      004400 02 74 3B         [24]  722 	ljmp	_unregister_mods
      004403                        723 00110$:
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004403 8F 06            [24]  725 	mov	ar6,r7
      004405 74 0F            [12]  726 	mov	a,#0x0f
      004407 5E               [12]  727 	anl	a,r6
      004408 FF               [12]  728 	mov	r7,a
                                    729 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      004409 90 06 24         [24]  730 	mov	dptr,#_hold_PARM_2
      00440C E0               [24]  731 	movx	a,@dptr
      00440D 60 05            [24]  732 	jz	00107$
      00440F 8F 82            [24]  733 	mov	dpl, r7
      004411 02 75 F6         [24]  734 	ljmp	_layer_hold_on
      004414                        735 00107$:
                                    736 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004414 8F 82            [24]  737 	mov	dpl, r7
                                    738 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004416 02 76 2E         [24]  739 	ljmp	_layer_hold_off
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'commit_pending'
                                    742 ;------------------------------------------------------------
                                    743 ;id            Allocated with name '_commit_pending_id_10000_606'
                                    744 ;------------------------------------------------------------
                                    745 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function commit_pending
                                    748 ;	-----------------------------------------
      004419                        749 _commit_pending:
                                    750 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      004419 90 0D AB         [24]  751 	mov	dptr,#_pending
      00441C E0               [24]  752 	movx	a,@dptr
      00441D 90 06 28         [24]  753 	mov	dptr,#_commit_pending_id_10000_606
      004420 F0               [24]  754 	movx	@dptr,a
                                    755 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004421 12 47 66         [24]  756 	lcall	_ak820_outline_0151
                                    757 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004424 90 06 28         [24]  758 	mov	dptr,#_commit_pending_id_10000_606
      004427 E0               [24]  759 	movx	a,@dptr
      004428 24 9C            [12]  760 	add	a,#_source_state
      00442A FF               [12]  761 	mov	r7,a
      00442B E4               [12]  762 	clr	a
      00442C 34 05            [12]  763 	addc	a, #(_source_state >> 8)
      00442E FE               [12]  764 	mov	r6,a
      00442F 12 43 6C         [24]  765 	lcall	_ak820_outline_0154
      004432 E0               [24]  766 	movx	a,@dptr
      004433 FD               [12]  767 	mov	r5,a
      004434 43 05 04         [24]  768 	orl	ar5,#0x04
      004437 12 43 6C         [24]  769 	lcall	_ak820_outline_0154
      00443A ED               [12]  770 	mov	a,r5
      00443B F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00443C 90 06 20         [24]  773 	mov	dptr,#_pending_code
      00443F 12 38 42         [24]  774 	lcall	_ak820_outline_0052
      004442 90 06 24         [24]  775 	mov	dptr,#_hold_PARM_2
      004445 74 01            [12]  776 	mov	a,#0x01
      004447 12 43 32         [24]  777 	lcall	_ak820_outline_0077
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00444A 02 43 C1         [24]  779 	ljmp	_hold
                                    780 ;------------------------------------------------------------
                                    781 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    782 ;------------------------------------------------------------
                                    783 ;event         Allocated with name '_ak820_tapping_before_event_10000_607'
                                    784 ;id            Allocated with name '_ak820_tapping_before_id_10000_608'
                                    785 ;------------------------------------------------------------
                                    786 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function ak820_tapping_before
                                    789 ;	-----------------------------------------
      00444D                        790 _ak820_tapping_before:
      00444D 12 38 7D         [24]  791 	lcall	_ak820_outline_0112
      004450 90 06 29         [24]  792 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004453 12 38 82         [24]  793 	lcall	_ak820_outline_0113
                                    794 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      004456 90 06 29         [24]  795 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004459 12 46 F6         [24]  796 	lcall	_ak820_outline_0008
      00445C 12 47 0C         [24]  797 	lcall	_ak820_outline_0022
      00445F C0 07            [24]  798 	push	ar7
      004461 C0 06            [24]  799 	push	ar6
      004463 12 B5 CA         [24]  800 	lcall	___memcpy
      004466 12 43 87         [24]  801 	lcall	_source
      004469 AD 82            [24]  802 	mov	r5, dpl
      00446B D0 06            [24]  803 	pop	ar6
      00446D D0 07            [24]  804 	pop	ar7
                                    805 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      00446F 90 0E 1B         [24]  806 	mov	dptr,#_vial_unlock_in_progress
      004472 E0               [24]  807 	movx	a,@dptr
      004473 60 26            [24]  808 	jz	00106$
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004475 12 47 59         [24]  810 	lcall	_ak820_outline_0095
      004478 60 1D            [24]  811 	jz	00102$
      00447A BD FF 02         [24]  812 	cjne	r5,#0xff,00218$
      00447D 80 18            [24]  813 	sjmp	00102$
      00447F                        814 00218$:
      00447F 12 47 00         [24]  815 	lcall	_ak820_outline_0014
      004482 E0               [24]  816 	movx	a,@dptr
      004483 70 12            [24]  817 	jnz	00102$
      004485 ED               [12]  818 	mov	a,r5
      004486 24 9C            [12]  819 	add	a, #_source_state
      004488 FB               [12]  820 	mov	r3,a
      004489 E4               [12]  821 	clr	a
      00448A 34 05            [12]  822 	addc	a, #(_source_state >> 8)
      00448C 12 47 3C         [24]  823 	lcall	_ak820_outline_0056
      00448F 53 02 FD         [24]  824 	anl	ar2,#0xfd
      004492 12 33 FC         [24]  825 	lcall	_ak820_outline_0120
      004495 EA               [12]  826 	mov	a,r2
      004496 F0               [24]  827 	movx	@dptr,a
      004497                        828 00102$:
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      004497 75 82 00         [24]  830 	mov	dpl, #0x00
      00449A 22               [24]  831 	ret
      00449B                        832 00106$:
                                    833 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      00449B 90 0D AB         [24]  834 	mov	dptr,#_pending
      00449E E0               [24]  835 	movx	a,@dptr
      00449F FC               [12]  836 	mov	r4,a
      0044A0 BC FF 02         [24]  837 	cjne	r4,#0xff,00220$
      0044A3 80 3B            [24]  838 	sjmp	00108$
      0044A5                        839 00220$:
      0044A5 12 38 3A         [24]  840 	lcall	_ak820_outline_0036
      0044A8 FA               [12]  841 	mov	r2,a
      0044A9 A3               [24]  842 	inc	dptr
      0044AA E0               [24]  843 	movx	a,@dptr
      0044AB FB               [12]  844 	mov	r3,a
      0044AC 90 06 1E         [24]  845 	mov	dptr,#_pending_time
      0044AF 12 38 77         [24]  846 	lcall	_ak820_outline_0100
      0044B2 EA               [12]  847 	mov	a,r2
      0044B3 C3               [12]  848 	clr	c
      0044B4 98               [12]  849 	subb	a,r0
      0044B5 FA               [12]  850 	mov	r2,a
      0044B6 EB               [12]  851 	mov	a,r3
      0044B7 99               [12]  852 	subb	a,r1
      0044B8 FB               [12]  853 	mov	r3,a
      0044B9 C3               [12]  854 	clr	c
      0044BA EA               [12]  855 	mov	a,r2
      0044BB 94 C8            [12]  856 	subb	a,#0xc8
      0044BD EB               [12]  857 	mov	a,r3
      0044BE 94 00            [12]  858 	subb	a,#0x00
      0044C0 50 17            [24]  859 	jnc	00107$
                                    860 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0044C2 74 04            [12]  861 	mov	a,#0x04
      0044C4 12 47 26         [24]  862 	lcall	_ak820_outline_0031
      0044C7 60 17            [24]  863 	jz	00108$
      0044C9 12 38 13         [24]  864 	lcall	_ak820_outline_0009
      0044CC 60 12            [24]  865 	jz	00108$
      0044CE BD FF 02         [24]  866 	cjne	r5,#0xff,00224$
      0044D1 80 06            [24]  867 	sjmp	00107$
      0044D3                        868 00224$:
      0044D3 ED               [12]  869 	mov	a,r5
      0044D4 B5 04 02         [24]  870 	cjne	a,ar4,00225$
      0044D7 80 07            [24]  871 	sjmp	00108$
      0044D9                        872 00225$:
      0044D9                        873 00107$:
      0044D9 C0 05            [24]  874 	push	ar5
      0044DB 12 44 19         [24]  875 	lcall	_commit_pending
      0044DE D0 05            [24]  876 	pop	ar5
      0044E0                        877 00108$:
                                    878 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044E0 90 06 29         [24]  879 	mov	dptr,#_ak820_tapping_before_event_10000_607
      0044E3 12 38 42         [24]  880 	lcall	_ak820_outline_0052
      0044E6 12 47 59         [24]  881 	lcall	_ak820_outline_0095
      0044E9 60 03            [24]  882 	jz	00114$
      0044EB BD FF 04         [24]  883 	cjne	r5,#0xff,00115$
      0044EE                        884 00114$:
      0044EE 75 82 01         [24]  885 	mov	dpl, #0x01
      0044F1 22               [24]  886 	ret
      0044F2                        887 00115$:
                                    888 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044F2 ED               [12]  889 	mov	a,r5
      0044F3 24 9C            [12]  890 	add	a, #_source_state
      0044F5 FC               [12]  891 	mov	r4,a
      0044F6 E4               [12]  892 	clr	a
      0044F7 34 05            [12]  893 	addc	a, #(_source_state >> 8)
      0044F9 FD               [12]  894 	mov	r5,a
      0044FA 12 43 38         [24]  895 	lcall	_ak820_outline_0091
      0044FD FB               [12]  896 	mov	r3,a
      0044FE 30 E1 12         [24]  897 	jnb	acc.1,00120$
                                    898 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004501 74 05            [12]  899 	mov	a,#0x05
      004503 2E               [12]  900 	add	a, r6
      004504 12 38 28         [24]  901 	lcall	_ak820_outline_0016
      004507 70 06            [24]  902 	jnz	00118$
      004509 74 FD            [12]  903 	mov	a,#0xfd
      00450B 5B               [12]  904 	anl	a,r3
      00450C 12 43 50         [24]  905 	lcall	_ak820_outline_0117
      00450F                        906 00118$:
                                    907 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00450F 75 82 00         [24]  908 	mov	dpl, #0x00
      004512 22               [24]  909 	ret
      004513                        910 00120$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004513 12 42 FC         [24]  912 	lcall	_ak820_outline_0011
      004516 E0               [24]  913 	movx	a,@dptr
      004517 FF               [12]  914 	mov	r7,a
      004518 8B 06            [24]  915 	mov	ar6,r3
      00451A 53 06 01         [24]  916 	anl	ar6,#0x01
      00451D EE               [12]  917 	mov	a,r6
      00451E B4 01 00         [24]  918 	cjne	a,#0x01,00231$
      004521                        919 00231$:
      004521 B3               [12]  920 	cpl	c
      004522 92 0E            [24]  921 	mov	_ak820_tapping_before_sloc0_1_0,c
      004524 8F F0            [24]  922 	mov	b,r7
      004526 E4               [12]  923 	clr	a
      004527 33               [12]  924 	rlc	a
      004528 B5 F0 04         [24]  925 	cjne	a,b,00122$
      00452B 75 82 00         [24]  926 	mov	dpl, #0x00
      00452E 22               [24]  927 	ret
      00452F                        928 00122$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00452F 63 03 01         [24]  930 	xrl	ar3,#0x01
      004532 12 38 92         [24]  931 	lcall	_ak820_outline_0121
      004535 EB               [12]  932 	mov	a,r3
      004536 F0               [24]  933 	movx	@dptr,a
                                    934 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004537 75 82 01         [24]  935 	mov	dpl, #0x01
                                    936 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      00453A 22               [24]  937 	ret
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    940 ;------------------------------------------------------------
                                    941 ;record        Allocated with name '_ak820_tapping_process_record_10000_618'
                                    942 ;id            Allocated with name '_ak820_tapping_process_id_10000_619'
                                    943 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_619'
                                    944 ;code          Allocated with name '_ak820_tapping_process_code_10000_619'
                                    945 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_619'
                                    946 ;------------------------------------------------------------
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    948 ;	-----------------------------------------
                                    949 ;	 function ak820_tapping_process
                                    950 ;	-----------------------------------------
      00453B                        951 _ak820_tapping_process:
      00453B 12 38 7D         [24]  952 	lcall	_ak820_outline_0112
      00453E 90 06 2B         [24]  953 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004541 12 38 82         [24]  954 	lcall	_ak820_outline_0113
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004544 90 06 2F         [24]  956 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004547 E4               [12]  957 	clr	a
      004548 F0               [24]  958 	movx	@dptr,a
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004549 90 06 2B         [24]  960 	mov	dptr,#_ak820_tapping_process_record_10000_618
      00454C 12 38 42         [24]  961 	lcall	_ak820_outline_0052
      00454F 74 04            [12]  962 	mov	a,#0x04
      004551 12 47 31         [24]  963 	lcall	_ak820_outline_0032
      004554 70 04            [24]  964 	jnz	00102$
      004556 75 82 01         [24]  965 	mov	dpl, #0x01
      004559 22               [24]  966 	ret
      00455A                        967 00102$:
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      00455A 8E 04            [24]  969 	mov	ar4,r6
      00455C 8F 05            [24]  970 	mov	ar5,r7
      00455E 12 47 0C         [24]  971 	lcall	_ak820_outline_0022
      004561 C0 07            [24]  972 	push	ar7
      004563 C0 06            [24]  973 	push	ar6
      004565 12 B5 CA         [24]  974 	lcall	___memcpy
      004568 12 43 87         [24]  975 	lcall	_source
      00456B AD 82            [24]  976 	mov	r5, dpl
      00456D D0 06            [24]  977 	pop	ar6
      00456F D0 07            [24]  978 	pop	ar7
                                    979 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      004571 BD FF 04         [24]  980 	cjne	r5,#0xff,00104$
      004574 75 82 01         [24]  981 	mov	dpl, #0x01
      004577 22               [24]  982 	ret
      004578                        983 00104$:
                                    984 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      004578 74 07            [12]  985 	mov	a,#0x07
      00457A 12 38 32         [24]  986 	lcall	_ak820_outline_0020
      00457D 12 38 42         [24]  987 	lcall	_ak820_outline_0052
      004580 90 06 2D         [24]  988 	mov	dptr,#_ak820_tapping_process_code_10000_619
      004583 12 47 4C         [24]  989 	lcall	_ak820_outline_0060
                                    990 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004586 BE 1A 15         [24]  991 	cjne	r6,#0x1a,00111$
      004589 BF 7C 12         [24]  992 	cjne	r7,#0x7c,00111$
      00458C 90 06 2D         [24]  993 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00458F 74 26            [12]  994 	mov	a,#0x26
      004591 F0               [24]  995 	movx	@dptr,a
      004592 74 22            [12]  996 	mov	a,#0x22
      004594 A3               [24]  997 	inc	dptr
      004595 F0               [24]  998 	movx	@dptr,a
      004596 90 06 2F         [24]  999 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004599 74 02            [12] 1000 	mov	a,#0x02
      00459B F0               [24] 1001 	movx	@dptr,a
      00459C 80 28            [24] 1002 	sjmp	00112$
      00459E                       1003 00111$:
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      00459E BE 1B 15         [24] 1005 	cjne	r6,#0x1b,00108$
      0045A1 BF 7C 12         [24] 1006 	cjne	r7,#0x7c,00108$
      0045A4 90 06 2D         [24] 1007 	mov	dptr,#_ak820_tapping_process_code_10000_619
      0045A7 74 27            [12] 1008 	mov	a,#0x27
      0045A9 F0               [24] 1009 	movx	@dptr,a
      0045AA 74 32            [12] 1010 	mov	a,#0x32
      0045AC A3               [24] 1011 	inc	dptr
      0045AD F0               [24] 1012 	movx	@dptr,a
      0045AE 90 06 2F         [24] 1013 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      0045B1 74 20            [12] 1014 	mov	a,#0x20
      0045B3 F0               [24] 1015 	movx	@dptr,a
      0045B4 80 10            [24] 1016 	sjmp	00112$
      0045B6                       1017 00108$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0045B6 BE 1E 0D         [24] 1019 	cjne	r6,#0x1e,00112$
      0045B9 BF 7C 0A         [24] 1020 	cjne	r7,#0x7c,00112$
      0045BC 90 06 2D         [24] 1021 	mov	dptr,#_ak820_tapping_process_code_10000_619
      0045BF 74 28            [12] 1022 	mov	a,#0x28
      0045C1 F0               [24] 1023 	movx	@dptr,a
      0045C2 74 32            [12] 1024 	mov	a,#0x32
      0045C4 A3               [24] 1025 	inc	dptr
      0045C5 F0               [24] 1026 	movx	@dptr,a
      0045C6                       1027 00112$:
                                   1028 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      0045C6 90 06 2D         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_619
      0045C9 E0               [24] 1030 	movx	a,@dptr
      0045CA A3               [24] 1031 	inc	dptr
      0045CB E0               [24] 1032 	movx	a,@dptr
      0045CC FF               [12] 1033 	mov	r7,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      0045CD BF 20 00         [24] 1035 	cjne	r7,#0x20,00242$
      0045D0                       1036 00242$:
      0045D0 40 05            [24] 1037 	jc	00113$
      0045D2 BF 50 00         [24] 1038 	cjne	r7,#0x50,00244$
      0045D5                       1039 00244$:
      0045D5 40 04            [24] 1040 	jc	00114$
      0045D7                       1041 00113$:
      0045D7 75 82 01         [24] 1042 	mov	dpl, #0x01
      0045DA 22               [24] 1043 	ret
      0045DB                       1044 00114$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0045DB BF 40 00         [24] 1046 	cjne	r7,#0x40,00246$
      0045DE                       1047 00246$:
      0045DE 40 0C            [24] 1048 	jc	00117$
      0045E0 53 07 0F         [24] 1049 	anl	ar7,#0x0f
      0045E3 BF 06 00         [24] 1050 	cjne	r7,#0x06,00248$
      0045E6                       1051 00248$:
      0045E6 40 04            [24] 1052 	jc	00117$
      0045E8 75 82 00         [24] 1053 	mov	dpl, #0x00
      0045EB 22               [24] 1054 	ret
      0045EC                       1055 00117$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      0045EC 90 06 2B         [24] 1057 	mov	dptr,#_ak820_tapping_process_record_10000_618
      0045EF 12 38 42         [24] 1058 	lcall	_ak820_outline_0052
      0045F2 12 47 00         [24] 1059 	lcall	_ak820_outline_0014
      0045F5 E0               [24] 1060 	movx	a,@dptr
      0045F6 60 1F            [24] 1061 	jz	00131$
                                   1062 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      0045F8 90 0D AB         [24] 1063 	mov	dptr,#_pending
      0045FB ED               [12] 1064 	mov	a,r5
      0045FC 12 43 06         [24] 1065 	lcall	_ak820_outline_0030
                                   1066 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      0045FF 12 38 42         [24] 1067 	lcall	_ak820_outline_0052
      004602 90 06 1E         [24] 1068 	mov	dptr,#_pending_time
      004605 12 47 4C         [24] 1069 	lcall	_ak820_outline_0060
                                   1070 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004608 90 06 2D         [24] 1071 	mov	dptr,#_ak820_tapping_process_code_10000_619
      00460B 12 38 42         [24] 1072 	lcall	_ak820_outline_0052
      00460E 90 06 20         [24] 1073 	mov	dptr,#_pending_code
      004611 12 47 4C         [24] 1074 	lcall	_ak820_outline_0060
      004614 02 46 CA         [24] 1075 	ljmp	00132$
      004617                       1076 00131$:
                                   1077 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004617 90 0D AB         [24] 1078 	mov	dptr,#_pending
      00461A E0               [24] 1079 	movx	a,@dptr
      00461B FF               [12] 1080 	mov	r7,a
      00461C ED               [12] 1081 	mov	a,r5
      00461D B5 07 02         [24] 1082 	cjne	a,ar7,00251$
      004620 80 03            [24] 1083 	sjmp	00252$
      004622                       1084 00251$:
      004622 02 46 A2         [24] 1085 	ljmp	00128$
      004625                       1086 00252$:
                                   1087 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004625 12 47 66         [24] 1088 	lcall	_ak820_outline_0151
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004628 90 06 2F         [24] 1090 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      00462B E0               [24] 1091 	movx	a,@dptr
      00462C FF               [12] 1092 	mov	r7,a
      00462D E0               [24] 1093 	movx	a,@dptr
      00462E 60 05            [24] 1094 	jz	00120$
      004630 8F 82            [24] 1095 	mov	dpl, r7
      004632 12 7A 7C         [24] 1096 	lcall	_add_owned_mods
      004635                       1097 00120$:
                                   1098 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004635 90 06 2B         [24] 1099 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004638 12 38 42         [24] 1100 	lcall	_ak820_outline_0052
      00463B 74 07            [12] 1101 	mov	a,#0x07
      00463D 2E               [12] 1102 	add	a, r6
      00463E FB               [12] 1103 	mov	r3,a
      00463F E4               [12] 1104 	clr	a
      004640 3F               [12] 1105 	addc	a, r7
      004641 FC               [12] 1106 	mov	r4,a
      004642 90 06 2D         [24] 1107 	mov	dptr,#_ak820_tapping_process_code_10000_619
      004645 E0               [24] 1108 	movx	a,@dptr
      004646 F9               [12] 1109 	mov	r1,a
      004647 7A 00            [12] 1110 	mov	r2,#0x00
      004649 12 33 FC         [24] 1111 	lcall	_ak820_outline_0120
      00464C E9               [12] 1112 	mov	a,r1
      00464D F0               [24] 1113 	movx	@dptr,a
      00464E EA               [12] 1114 	mov	a,r2
      00464F A3               [24] 1115 	inc	dptr
      004650 F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      004651 C3               [12] 1118 	clr	c
      004652 04               [12] 1119 	inc	a
      004653 99               [12] 1120 	subb	a,r1
      004654 50 3A            [24] 1121 	jnc	00122$
                                   1122 ;	free result
                                   1123 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      004656 74 06            [12] 1124 	mov	a,#0x06
      004658 12 38 32         [24] 1125 	lcall	_ak820_outline_0020
      00465B E0               [24] 1126 	movx	a,@dptr
      00465C 54 0F            [12] 1127 	anl	a,#0x0f
      00465E 44 10            [12] 1128 	orl	a,#0x10
      004660 F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      004661 12 47 00         [24] 1131 	lcall	_ak820_outline_0014
      004664 74 01            [12] 1132 	mov	a,#0x01
      004666 F0               [24] 1133 	movx	@dptr,a
                                   1134 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004667 12 47 52         [24] 1135 	lcall	_ak820_outline_0075
      00466A 12 38 AC         [24] 1136 	lcall	_ak820_outline_0144
      00466D 8A F0            [24] 1137 	mov	b, r2
      00466F C0 07            [24] 1138 	push	ar7
      004671 C0 06            [24] 1139 	push	ar6
      004673 C0 04            [24] 1140 	push	ar4
      004675 C0 03            [24] 1141 	push	ar3
      004677 12 6F 87         [24] 1142 	lcall	_process_record
      00467A D0 03            [24] 1143 	pop	ar3
      00467C D0 04            [24] 1144 	pop	ar4
      00467E D0 06            [24] 1145 	pop	ar6
      004680 D0 07            [24] 1146 	pop	ar7
                                   1147 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      004682 12 33 FC         [24] 1148 	lcall	_ak820_outline_0120
      004685 E4               [12] 1149 	clr	a
      004686 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      004687 FC               [12] 1152 	mov	r4,a
      004688 12 38 87         [24] 1153 	lcall	_ak820_outline_0114
      00468B 8C F0            [24] 1154 	mov	b, r4
      00468D 12 6F 87         [24] 1155 	lcall	_process_record
      004690                       1156 00122$:
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      004690 90 06 2F         [24] 1158 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_619
      004693 E0               [24] 1159 	movx	a,@dptr
      004694 FF               [12] 1160 	mov	r7,a
      004695 E0               [24] 1161 	movx	a,@dptr
      004696 60 32            [24] 1162 	jz	00132$
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      004698 8F 82            [24] 1164 	mov	dpl, r7
      00469A 12 7A 8C         [24] 1165 	lcall	_del_owned_mods
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      00469D 12 7D C0         [24] 1167 	lcall	_send_keyboard_report
      0046A0 80 28            [24] 1168 	sjmp	00132$
      0046A2                       1169 00128$:
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0046A2 ED               [12] 1171 	mov	a,r5
      0046A3 24 9C            [12] 1172 	add	a, #_source_state
      0046A5 FE               [12] 1173 	mov	r6,a
      0046A6 E4               [12] 1174 	clr	a
      0046A7 34 05            [12] 1175 	addc	a, #(_source_state >> 8)
      0046A9 FF               [12] 1176 	mov	r7,a
      0046AA 12 38 87         [24] 1177 	lcall	_ak820_outline_0114
      0046AD E0               [24] 1178 	movx	a,@dptr
      0046AE FD               [12] 1179 	mov	r5,a
      0046AF 30 E2 18         [24] 1180 	jnb	acc.2,00132$
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      0046B2 53 05 FB         [24] 1182 	anl	ar5,#0xfb
      0046B5 12 38 87         [24] 1183 	lcall	_ak820_outline_0114
      0046B8 ED               [12] 1184 	mov	a,r5
      0046B9 F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      0046BA 90 06 2D         [24] 1187 	mov	dptr,#_ak820_tapping_process_code_10000_619
      0046BD 12 38 42         [24] 1188 	lcall	_ak820_outline_0052
      0046C0 90 06 24         [24] 1189 	mov	dptr,#_hold_PARM_2
      0046C3 E4               [12] 1190 	clr	a
      0046C4 12 43 32         [24] 1191 	lcall	_ak820_outline_0077
      0046C7 12 43 C1         [24] 1192 	lcall	_hold
      0046CA                       1193 00132$:
                                   1194 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      0046CA 75 82 00         [24] 1195 	mov	dpl, #0x00
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      0046CD 22               [24] 1197 	ret
                                   1198 ;------------------------------------------------------------
                                   1199 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1200 ;------------------------------------------------------------
                                   1201 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_642'
                                   1202 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_643'
                                   1203 ;------------------------------------------------------------
                                   1204 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1205 ;	-----------------------------------------
                                   1206 ;	 function ak820_tapping_cancel
                                   1207 ;	-----------------------------------------
      0046CE                       1208 _ak820_tapping_cancel:
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      0046CE 12 47 66         [24] 1210 	lcall	_ak820_outline_0151
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046D1 7F 00            [12] 1212 	mov	r7,#0x00
      0046D3                       1213 00103$:
      0046D3 BF 82 00         [24] 1214 	cjne	r7,#0x82,00122$
      0046D6                       1215 00122$:
      0046D6 50 1D            [24] 1216 	jnc	00105$
                                   1217 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      0046D8 EF               [12] 1218 	mov	a,r7
      0046D9 24 9C            [12] 1219 	add	a, #_source_state
      0046DB FD               [12] 1220 	mov	r5,a
      0046DC E4               [12] 1221 	clr	a
      0046DD 34 05            [12] 1222 	addc	a, #(_source_state >> 8)
      0046DF 12 47 44         [24] 1223 	lcall	_ak820_outline_0058
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0046E2 74 02            [12] 1225 	mov	a,#0x02
      0046E4 5C               [12] 1226 	anl	a,r4
      0046E5 FB               [12] 1227 	mov	r3,a
      0046E6 53 04 01         [24] 1228 	anl	ar4,#0x01
      0046E9 EC               [12] 1229 	mov	a,r4
      0046EA 2C               [12] 1230 	add	a,r4
      0046EB 42 03            [12] 1231 	orl	ar3,a
      0046ED 12 38 9C         [24] 1232 	lcall	_ak820_outline_0130
      0046F0 EB               [12] 1233 	mov	a,r3
      0046F1 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046F2 0F               [12] 1236 	inc	r7
      0046F3 80 DE            [24] 1237 	sjmp	00103$
      0046F5                       1238 00105$:
                                   1239 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      0046F5 22               [24] 1240 	ret
                                   1241 	.area CSEG    (CODE)
                                   1242 	.area CONST   (CODE)
                                   1243 	.area XINIT   (CODE)
      00BE8A                       1244 __xinit__pending:
      00BE8A FF                    1245 	.db #0xff	; 255
                                   1246 	.area CABS    (ABS,CODE)
                                   1247 
                                   1248 ; Experimental exact instruction outlining.
                                   1249 	.globl _ak820_outline_0008
                                   1250 	.globl _ak820_outline_0009
                                   1251 	.globl _ak820_outline_0011
                                   1252 	.globl _ak820_outline_0014
                                   1253 	.globl _ak820_outline_0016
                                   1254 	.globl _ak820_outline_0020
                                   1255 	.globl _ak820_outline_0022
                                   1256 	.globl _ak820_outline_0030
                                   1257 	.globl _ak820_outline_0031
                                   1258 	.globl _ak820_outline_0032
                                   1259 	.globl _ak820_outline_0036
                                   1260 	.globl _ak820_outline_0052
                                   1261 	.globl _ak820_outline_0056
                                   1262 	.globl _ak820_outline_0058
                                   1263 	.globl _ak820_outline_0060
                                   1264 	.globl _ak820_outline_0075
                                   1265 	.globl _ak820_outline_0077
                                   1266 	.globl _ak820_outline_0091
                                   1267 	.globl _ak820_outline_0095
                                   1268 	.globl _ak820_outline_0100
                                   1269 	.globl _ak820_outline_0112
                                   1270 	.globl _ak820_outline_0113
                                   1271 	.globl _ak820_outline_0114
                                   1272 	.globl _ak820_outline_0117
                                   1273 	.globl _ak820_outline_0120
                                   1274 	.globl _ak820_outline_0121
                                   1275 	.globl _ak820_outline_0130
                                   1276 	.globl _ak820_outline_0144
                                   1277 	.globl _ak820_outline_0151
                                   1278 	.globl _ak820_outline_0154
                                   1279 	.globl _ak820_outline_0185
                                   1280 
                                   1281 	.area CSEG (CODE)
                                   1282 ; function ak820_outline_0008
      0046F6                       1283 _ak820_outline_0008:
      0046F6 E0               [24] 1284 	movx	a,@dptr
      0046F7 FE               [12] 1285 	mov	r6,a
      0046F8 A3               [24] 1286 	inc	dptr
      0046F9 E0               [24] 1287 	movx	a,@dptr
      0046FA FF               [12] 1288 	mov	r7,a
      0046FB 8E 04            [24] 1289 	mov	ar4,r6
      0046FD 8F 05            [24] 1290 	mov	ar5,r7
      0046FF 22               [24] 1291 	ret
                                   1292 
                                   1293 	.area CSEG (CODE)
                                   1294 ; function ak820_outline_0014
      004700                       1295 _ak820_outline_0014:
      004700 74 05            [12] 1296 	mov	a,#0x05
      004702 2E               [12] 1297 	add	a,r6
      004703 FB               [12] 1298 	mov	r3,a
      004704 E4               [12] 1299 	clr	a
      004705 3F               [12] 1300 	addc	a,r7
      004706 FC               [12] 1301 	mov	r4,a
      004707 8B 82            [24] 1302 	mov	dpl,r3
      004709 8C 83            [24] 1303 	mov	dph,r4
      00470B 22               [24] 1304 	ret
                                   1305 
                                   1306 	.area CSEG (CODE)
                                   1307 ; function ak820_outline_0022
      00470C                       1308 _ak820_outline_0022:
      00470C 90 0D 9B         [24] 1309 	mov	dptr,#___memcpy_PARM_2
      00470F EC               [12] 1310 	mov	a,r4
      004710 F0               [24] 1311 	movx	@dptr,a
      004711 ED               [12] 1312 	mov	a,r5
      004712 A3               [24] 1313 	inc	dptr
      004713 F0               [24] 1314 	movx	@dptr,a
      004714 E4               [12] 1315 	clr	a
      004715 A3               [24] 1316 	inc	dptr
      004716 F0               [24] 1317 	movx	@dptr,a
      004717 90 0D 9E         [24] 1318 	mov	dptr,#___memcpy_PARM_3
      00471A 74 02            [12] 1319 	mov	a,#0x02
      00471C F0               [24] 1320 	movx	@dptr,a
      00471D E4               [12] 1321 	clr	a
      00471E A3               [24] 1322 	inc	dptr
      00471F F0               [24] 1323 	movx	@dptr,a
      004720 90 06 22         [24] 1324 	mov	dptr,#_source_PARM_1
      004723 F5 F0            [12] 1325 	mov	b,a
      004725 22               [24] 1326 	ret
                                   1327 
                                   1328 	.area CSEG (CODE)
                                   1329 ; function ak820_outline_0031
      004726                       1330 _ak820_outline_0031:
      004726 2E               [12] 1331 	add	a,r6
      004727 FA               [12] 1332 	mov	r2,a
      004728 E4               [12] 1333 	clr	a
      004729 3F               [12] 1334 	addc	a,r7
      00472A FB               [12] 1335 	mov	r3,a
      00472B 8A 82            [24] 1336 	mov	dpl,r2
      00472D 8B 83            [24] 1337 	mov	dph,r3
      00472F E0               [24] 1338 	movx	a,@dptr
      004730 22               [24] 1339 	ret
                                   1340 
                                   1341 	.area CSEG (CODE)
                                   1342 ; function ak820_outline_0032
      004731                       1343 _ak820_outline_0032:
      004731 2E               [12] 1344 	add	a,r6
      004732 FC               [12] 1345 	mov	r4,a
      004733 E4               [12] 1346 	clr	a
      004734 3F               [12] 1347 	addc	a,r7
      004735 FD               [12] 1348 	mov	r5,a
      004736 8C 82            [24] 1349 	mov	dpl,r4
      004738 8D 83            [24] 1350 	mov	dph,r5
      00473A E0               [24] 1351 	movx	a,@dptr
      00473B 22               [24] 1352 	ret
                                   1353 
                                   1354 	.area CSEG (CODE)
                                   1355 ; function ak820_outline_0056
      00473C                       1356 _ak820_outline_0056:
      00473C FC               [12] 1357 	mov	r4,a
      00473D 8B 82            [24] 1358 	mov	dpl,r3
      00473F 8C 83            [24] 1359 	mov	dph,r4
      004741 E0               [24] 1360 	movx	a,@dptr
      004742 FA               [12] 1361 	mov	r2,a
      004743 22               [24] 1362 	ret
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0058
      004744                       1366 _ak820_outline_0058:
      004744 FE               [12] 1367 	mov	r6,a
      004745 8D 82            [24] 1368 	mov	dpl,r5
      004747 8E 83            [24] 1369 	mov	dph,r6
      004749 E0               [24] 1370 	movx	a,@dptr
      00474A FC               [12] 1371 	mov	r4,a
      00474B 22               [24] 1372 	ret
                                   1373 
                                   1374 	.area CSEG (CODE)
                                   1375 ; function ak820_outline_0060
      00474C                       1376 _ak820_outline_0060:
      00474C EE               [12] 1377 	mov	a,r6
      00474D F0               [24] 1378 	movx	@dptr,a
      00474E EF               [12] 1379 	mov	a,r7
      00474F A3               [24] 1380 	inc	dptr
      004750 F0               [24] 1381 	movx	@dptr,a
      004751 22               [24] 1382 	ret
                                   1383 
                                   1384 	.area CSEG (CODE)
                                   1385 ; function ak820_outline_0075
      004752                       1386 _ak820_outline_0075:
      004752 8E 00            [24] 1387 	mov	ar0,r6
      004754 8F 01            [24] 1388 	mov	ar1,r7
      004756 7A 00            [12] 1389 	mov	r2,#0x00
      004758 22               [24] 1390 	ret
                                   1391 
                                   1392 	.area CSEG (CODE)
                                   1393 ; function ak820_outline_0095
      004759                       1394 _ak820_outline_0095:
      004759 74 04            [12] 1395 	mov	a,#0x04
      00475B 2E               [12] 1396 	add	a,r6
      00475C FB               [12] 1397 	mov	r3,a
      00475D E4               [12] 1398 	clr	a
      00475E 3F               [12] 1399 	addc	a,r7
      00475F FC               [12] 1400 	mov	r4,a
      004760 8B 82            [24] 1401 	mov	dpl,r3
      004762 8C 83            [24] 1402 	mov	dph,r4
      004764 E0               [24] 1403 	movx	a,@dptr
      004765 22               [24] 1404 	ret
                                   1405 
                                   1406 	.area CSEG (CODE)
                                   1407 ; function ak820_outline_0151
      004766                       1408 _ak820_outline_0151:
      004766 90 0D AB         [24] 1409 	mov	dptr,#_pending
      004769 74 FF            [12] 1410 	mov	a,#0xff
      00476B F0               [24] 1411 	movx	@dptr,a
      00476C 22               [24] 1412 	ret
