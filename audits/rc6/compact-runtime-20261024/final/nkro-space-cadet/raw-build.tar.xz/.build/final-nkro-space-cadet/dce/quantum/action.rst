                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _ak820_resolve_key
                                     35 	.globl _layer_xor
                                     36 	.globl _layer_and
                                     37 	.globl _layer_or
                                     38 	.globl _layer_off
                                     39 	.globl _layer_on
                                     40 	.globl _layer_move
                                     41 	.globl _layer_clear
                                     42 	.globl _layer_state_set
                                     43 	.globl _default_layer_xor
                                     44 	.globl _default_layer_and
                                     45 	.globl _default_layer_or
                                     46 	.globl _default_layer_set
                                     47 	.globl _post_process_record_quantum
                                     48 	.globl _process_record_quantum
                                     49 	.globl _action_for_keycode
                                     50 	.globl _mDelaymS
                                     51 	.globl _host_consumer_send
                                     52 	.globl _host_system_send
                                     53 	.globl _host_keyboard_leds
                                     54 	.globl _led_set
                                     55 	.globl _clear_keys_from_report
                                     56 	.globl ___memcpy
                                     57 	.globl _ADC_START
                                     58 	.globl _S0_R_FIFO
                                     59 	.globl _S0_T_FIFO
                                     60 	.globl _S0_FREE
                                     61 	.globl _S0_IF_BYTE
                                     62 	.globl _S0_IF_FIRST
                                     63 	.globl _S0_IF_OV
                                     64 	.globl _S0_FST_ACT
                                     65 	.globl _CP_RL2
                                     66 	.globl _C_T2
                                     67 	.globl _TR2
                                     68 	.globl _EXEN2
                                     69 	.globl _TCLK
                                     70 	.globl _RCLK
                                     71 	.globl _EXF2
                                     72 	.globl _CAP1F
                                     73 	.globl _TF2
                                     74 	.globl _RI
                                     75 	.globl _TI
                                     76 	.globl _RB8
                                     77 	.globl _TB8
                                     78 	.globl _REN
                                     79 	.globl _SM2
                                     80 	.globl _SM1
                                     81 	.globl _SM0
                                     82 	.globl _IT0
                                     83 	.globl _IE0
                                     84 	.globl _IT1
                                     85 	.globl _IE1
                                     86 	.globl _TR0
                                     87 	.globl _TF0
                                     88 	.globl _TR1
                                     89 	.globl _TF1
                                     90 	.globl _P4_0
                                     91 	.globl _P4_1
                                     92 	.globl _P4_2
                                     93 	.globl _P4_3
                                     94 	.globl _P4_4
                                     95 	.globl _P4_5
                                     96 	.globl _P4_6
                                     97 	.globl _RXD
                                     98 	.globl _TXD
                                     99 	.globl _INT0
                                    100 	.globl _INT1
                                    101 	.globl _T0
                                    102 	.globl _T1
                                    103 	.globl _MOSI1
                                    104 	.globl _MISO1
                                    105 	.globl _SCK1
                                    106 	.globl _P3_0
                                    107 	.globl _P3_1
                                    108 	.globl _P3_2
                                    109 	.globl _P3_3
                                    110 	.globl _P3_4
                                    111 	.globl _P3_5
                                    112 	.globl _P3_6
                                    113 	.globl _P3_7
                                    114 	.globl _CAP1_
                                    115 	.globl _T2_
                                    116 	.globl _CAP2_
                                    117 	.globl _T2EX_
                                    118 	.globl _RXD1
                                    119 	.globl _TXD1
                                    120 	.globl _P2_0
                                    121 	.globl _P2_1
                                    122 	.globl _P2_2
                                    123 	.globl _P2_3
                                    124 	.globl _P2_4
                                    125 	.globl _P2_5
                                    126 	.globl _P2_6
                                    127 	.globl _P2_7
                                    128 	.globl _AIN0
                                    129 	.globl _AIN1
                                    130 	.globl _AIN2
                                    131 	.globl _AIN3
                                    132 	.globl _AIN4
                                    133 	.globl _AIN5
                                    134 	.globl _AIN6
                                    135 	.globl _AIN7
                                    136 	.globl _CAP1
                                    137 	.globl _T2
                                    138 	.globl _CAP2
                                    139 	.globl _T2EX
                                    140 	.globl _INT0_
                                    141 	.globl _SCS
                                    142 	.globl _MOSI
                                    143 	.globl _MISO
                                    144 	.globl _SCK
                                    145 	.globl _RXD1_
                                    146 	.globl _TXD1_
                                    147 	.globl _P1_0
                                    148 	.globl _P1_1
                                    149 	.globl _P1_2
                                    150 	.globl _P1_3
                                    151 	.globl _P1_4
                                    152 	.globl _P1_5
                                    153 	.globl _P1_6
                                    154 	.globl _P1_7
                                    155 	.globl _AIN8
                                    156 	.globl _AIN9
                                    157 	.globl _AIN10
                                    158 	.globl _AIN11
                                    159 	.globl _AIN12
                                    160 	.globl _AIN13
                                    161 	.globl _RXD_
                                    162 	.globl _TXD_
                                    163 	.globl _SCL0
                                    164 	.globl _SDA0
                                    165 	.globl _P0_0
                                    166 	.globl _P0_1
                                    167 	.globl _P0_2
                                    168 	.globl _P0_3
                                    169 	.globl _P0_4
                                    170 	.globl _P0_5
                                    171 	.globl _P0_6
                                    172 	.globl _P0_7
                                    173 	.globl _IE_SPI0
                                    174 	.globl _IE_USB
                                    175 	.globl _IE_ADC
                                    176 	.globl _IE_UART1
                                    177 	.globl _IE_PWM_I2C
                                    178 	.globl _IE_GPIO
                                    179 	.globl _IE_WDOG
                                    180 	.globl _PX0
                                    181 	.globl _PT0
                                    182 	.globl _PX1
                                    183 	.globl _PT1
                                    184 	.globl _PS
                                    185 	.globl _PT2
                                    186 	.globl _PL_FLAG
                                    187 	.globl _PH_FLAG
                                    188 	.globl _EX0
                                    189 	.globl _ET0
                                    190 	.globl _EX1
                                    191 	.globl _ET1
                                    192 	.globl _ES
                                    193 	.globl _ET2
                                    194 	.globl _E_DIS
                                    195 	.globl _EA
                                    196 	.globl _P
                                    197 	.globl _F1
                                    198 	.globl _OV
                                    199 	.globl _RS0
                                    200 	.globl _RS1
                                    201 	.globl _F0
                                    202 	.globl _AC
                                    203 	.globl _CY
                                    204 	.globl _I2CS_INT_ST
                                    205 	.globl _I2CX_INT
                                    206 	.globl _LED_STATUS
                                    207 	.globl _LED_DMA_H
                                    208 	.globl _LED_DMA_L
                                    209 	.globl _LED_DMA
                                    210 	.globl _LED_PWM_OE
                                    211 	.globl _LED_COMMON
                                    212 	.globl _ADC_CHAN
                                    213 	.globl _ADC_DAT_H
                                    214 	.globl _ADC_DAT_L
                                    215 	.globl _ADC_DAT
                                    216 	.globl _ADC_CTRL
                                    217 	.globl _SPI1_CK_SE
                                    218 	.globl _SPI1_CTRL
                                    219 	.globl _SPI1_DATA
                                    220 	.globl _SPI1_STAT
                                    221 	.globl _SIF1
                                    222 	.globl _SBAUD1
                                    223 	.globl _SBUF1
                                    224 	.globl _SCON1
                                    225 	.globl _SPI0_SETUP
                                    226 	.globl _SPI0_CK_SE
                                    227 	.globl _SPI0_CTRL
                                    228 	.globl _SPI0_DATA
                                    229 	.globl _SPI0_STAT
                                    230 	.globl _T2CAP1H
                                    231 	.globl _T2CAP1L
                                    232 	.globl _T2CAP1
                                    233 	.globl _TH2
                                    234 	.globl _TL2
                                    235 	.globl _T2COUNT
                                    236 	.globl _RCAP2H
                                    237 	.globl _RCAP2L
                                    238 	.globl _RCAP2
                                    239 	.globl _T2MOD
                                    240 	.globl _T2CON
                                    241 	.globl _SBUF
                                    242 	.globl _SCON
                                    243 	.globl _TH1
                                    244 	.globl _TH0
                                    245 	.globl _TL1
                                    246 	.globl _TL0
                                    247 	.globl _TMOD
                                    248 	.globl _TCON
                                    249 	.globl _XBUS_AUX
                                    250 	.globl _P7
                                    251 	.globl _P6_DIR
                                    252 	.globl _P6_OUT_PU
                                    253 	.globl _P6_IN
                                    254 	.globl _P5_DIR
                                    255 	.globl _P5_OUT_PU
                                    256 	.globl _P5_IN
                                    257 	.globl _P4_LED_KEY
                                    258 	.globl _P4_DIR_PU
                                    259 	.globl _P4_MOD_OC
                                    260 	.globl _P4
                                    261 	.globl _P3_DIR_PU
                                    262 	.globl _P3_MOD_OC
                                    263 	.globl _P3
                                    264 	.globl _P2_DIR_PU
                                    265 	.globl _P2_MOD_OC
                                    266 	.globl _P2
                                    267 	.globl _P1_DIR_PU
                                    268 	.globl _P1_MOD_OC
                                    269 	.globl _P1
                                    270 	.globl _P0_DIR_PU
                                    271 	.globl _P0_MOD_OC
                                    272 	.globl _P0
                                    273 	.globl _ROM_CTRL
                                    274 	.globl _ROM_DATA_HH
                                    275 	.globl _ROM_DATA_HL
                                    276 	.globl _ROM_DATA_HI
                                    277 	.globl _ROM_ADDR_H
                                    278 	.globl _ROM_ADDR_L
                                    279 	.globl _ROM_ADDR
                                    280 	.globl _GPIO_IE
                                    281 	.globl _IP_EX
                                    282 	.globl _IE_EX
                                    283 	.globl _IP
                                    284 	.globl _IE
                                    285 	.globl _WDOG_COUNT
                                    286 	.globl _RESET_KEEP
                                    287 	.globl _WAKE_CTRL
                                    288 	.globl _CLOCK_CFG
                                    289 	.globl _POWER_CFG
                                    290 	.globl _PCON
                                    291 	.globl _GLOBAL_CFG
                                    292 	.globl _SAFE_MOD
                                    293 	.globl _DPH
                                    294 	.globl _DPL
                                    295 	.globl _SP
                                    296 	.globl _A_INV
                                    297 	.globl _B
                                    298 	.globl _ACC
                                    299 	.globl _PSW
                                    300 	.globl _disable_action_cache
                                    301 	.globl _tap_code_delay_PARM_2
                                    302 	.globl _process_action_PARM_2
                                    303 	.globl _action_exec_PARM_1
                                    304 	.globl _tp_buttons
                                    305 	.globl _action_exec
                                    306 	.globl _ak820_action_exec
                                    307 	.globl _process_record
                                    308 	.globl _process_record_handler
                                    309 	.globl _process_action
                                    310 	.globl _register_code
                                    311 	.globl _unregister_code
                                    312 	.globl _tap_code_delay
                                    313 	.globl _tap_code
                                    314 	.globl _register_mods
                                    315 	.globl _unregister_mods
                                    316 	.globl _register_weak_mods
                                    317 	.globl _unregister_weak_mods
                                    318 	.globl _clear_keyboard
                                    319 	.globl _clear_keyboard_but_mods
                                    320 	.globl _clear_keyboard_but_mods_and_keys
                                    321 ;--------------------------------------------------------
                                    322 ; special function registers
                                    323 ;--------------------------------------------------------
                                    324 	.area RSEG    (ABS,DATA)
      000000                        325 	.org 0x0000
                           0000D0   326 _PSW	=	0x00d0
                           0000E0   327 _ACC	=	0x00e0
                           0000F0   328 _B	=	0x00f0
                           0000FD   329 _A_INV	=	0x00fd
                           000081   330 _SP	=	0x0081
                           000082   331 _DPL	=	0x0082
                           000083   332 _DPH	=	0x0083
                           0000A1   333 _SAFE_MOD	=	0x00a1
                           0000B1   334 _GLOBAL_CFG	=	0x00b1
                           000087   335 _PCON	=	0x0087
                           0000BA   336 _POWER_CFG	=	0x00ba
                           0000B9   337 _CLOCK_CFG	=	0x00b9
                           0000A9   338 _WAKE_CTRL	=	0x00a9
                           0000FE   339 _RESET_KEEP	=	0x00fe
                           0000FF   340 _WDOG_COUNT	=	0x00ff
                           0000A8   341 _IE	=	0x00a8
                           0000B8   342 _IP	=	0x00b8
                           0000E8   343 _IE_EX	=	0x00e8
                           0000E9   344 _IP_EX	=	0x00e9
                           0000B2   345 _GPIO_IE	=	0x00b2
                           008584   346 _ROM_ADDR	=	0x8584
                           000084   347 _ROM_ADDR_L	=	0x0084
                           000085   348 _ROM_ADDR_H	=	0x0085
                           008F8E   349 _ROM_DATA_HI	=	0x8f8e
                           00008E   350 _ROM_DATA_HL	=	0x008e
                           00008F   351 _ROM_DATA_HH	=	0x008f
                           000086   352 _ROM_CTRL	=	0x0086
                           000080   353 _P0	=	0x0080
                           0000C4   354 _P0_MOD_OC	=	0x00c4
                           0000C5   355 _P0_DIR_PU	=	0x00c5
                           000090   356 _P1	=	0x0090
                           000092   357 _P1_MOD_OC	=	0x0092
                           000093   358 _P1_DIR_PU	=	0x0093
                           0000A0   359 _P2	=	0x00a0
                           000094   360 _P2_MOD_OC	=	0x0094
                           000095   361 _P2_DIR_PU	=	0x0095
                           0000B0   362 _P3	=	0x00b0
                           000096   363 _P3_MOD_OC	=	0x0096
                           000097   364 _P3_DIR_PU	=	0x0097
                           0000C0   365 _P4	=	0x00c0
                           0000C2   366 _P4_MOD_OC	=	0x00c2
                           0000C3   367 _P4_DIR_PU	=	0x00c3
                           0000C1   368 _P4_LED_KEY	=	0x00c1
                           0000AA   369 _P5_IN	=	0x00aa
                           0000AB   370 _P5_OUT_PU	=	0x00ab
                           0000AC   371 _P5_DIR	=	0x00ac
                           0000AD   372 _P6_IN	=	0x00ad
                           0000AE   373 _P6_OUT_PU	=	0x00ae
                           0000AF   374 _P6_DIR	=	0x00af
                           0000F1   375 _P7	=	0x00f1
                           0000A2   376 _XBUS_AUX	=	0x00a2
                           000088   377 _TCON	=	0x0088
                           000089   378 _TMOD	=	0x0089
                           00008A   379 _TL0	=	0x008a
                           00008B   380 _TL1	=	0x008b
                           00008C   381 _TH0	=	0x008c
                           00008D   382 _TH1	=	0x008d
                           000098   383 _SCON	=	0x0098
                           000099   384 _SBUF	=	0x0099
                           0000C8   385 _T2CON	=	0x00c8
                           0000C9   386 _T2MOD	=	0x00c9
                           00CBCA   387 _RCAP2	=	0xcbca
                           0000CA   388 _RCAP2L	=	0x00ca
                           0000CB   389 _RCAP2H	=	0x00cb
                           00CDCC   390 _T2COUNT	=	0xcdcc
                           0000CC   391 _TL2	=	0x00cc
                           0000CD   392 _TH2	=	0x00cd
                           00CFCE   393 _T2CAP1	=	0xcfce
                           0000CE   394 _T2CAP1L	=	0x00ce
                           0000CF   395 _T2CAP1H	=	0x00cf
                           0000F8   396 _SPI0_STAT	=	0x00f8
                           0000F9   397 _SPI0_DATA	=	0x00f9
                           0000FA   398 _SPI0_CTRL	=	0x00fa
                           0000FB   399 _SPI0_CK_SE	=	0x00fb
                           0000FC   400 _SPI0_SETUP	=	0x00fc
                           0000BC   401 _SCON1	=	0x00bc
                           0000BD   402 _SBUF1	=	0x00bd
                           0000BE   403 _SBAUD1	=	0x00be
                           0000BF   404 _SIF1	=	0x00bf
                           0000B4   405 _SPI1_STAT	=	0x00b4
                           0000B5   406 _SPI1_DATA	=	0x00b5
                           0000B6   407 _SPI1_CTRL	=	0x00b6
                           0000B7   408 _SPI1_CK_SE	=	0x00b7
                           0000F3   409 _ADC_CTRL	=	0x00f3
                           00F5F4   410 _ADC_DAT	=	0xf5f4
                           0000F4   411 _ADC_DAT_L	=	0x00f4
                           0000F5   412 _ADC_DAT_H	=	0x00f5
                           0000F6   413 _ADC_CHAN	=	0x00f6
                           0000A6   414 _LED_COMMON	=	0x00a6
                           0000A7   415 _LED_PWM_OE	=	0x00a7
                           00C7C6   416 _LED_DMA	=	0xc7c6
                           0000C6   417 _LED_DMA_L	=	0x00c6
                           0000C7   418 _LED_DMA_H	=	0x00c7
                           0000F7   419 _LED_STATUS	=	0x00f7
                           0000B3   420 _I2CX_INT	=	0x00b3
                           0000BB   421 _I2CS_INT_ST	=	0x00bb
                                    422 ;--------------------------------------------------------
                                    423 ; special function bits
                                    424 ;--------------------------------------------------------
                                    425 	.area RSEG    (ABS,DATA)
      000000                        426 	.org 0x0000
                           0000D7   427 _CY	=	0x00d7
                           0000D6   428 _AC	=	0x00d6
                           0000D5   429 _F0	=	0x00d5
                           0000D4   430 _RS1	=	0x00d4
                           0000D3   431 _RS0	=	0x00d3
                           0000D2   432 _OV	=	0x00d2
                           0000D1   433 _F1	=	0x00d1
                           0000D0   434 _P	=	0x00d0
                           0000AF   435 _EA	=	0x00af
                           0000AE   436 _E_DIS	=	0x00ae
                           0000AD   437 _ET2	=	0x00ad
                           0000AC   438 _ES	=	0x00ac
                           0000AB   439 _ET1	=	0x00ab
                           0000AA   440 _EX1	=	0x00aa
                           0000A9   441 _ET0	=	0x00a9
                           0000A8   442 _EX0	=	0x00a8
                           0000BF   443 _PH_FLAG	=	0x00bf
                           0000BE   444 _PL_FLAG	=	0x00be
                           0000BD   445 _PT2	=	0x00bd
                           0000BC   446 _PS	=	0x00bc
                           0000BB   447 _PT1	=	0x00bb
                           0000BA   448 _PX1	=	0x00ba
                           0000B9   449 _PT0	=	0x00b9
                           0000B8   450 _PX0	=	0x00b8
                           0000EF   451 _IE_WDOG	=	0x00ef
                           0000EE   452 _IE_GPIO	=	0x00ee
                           0000ED   453 _IE_PWM_I2C	=	0x00ed
                           0000EC   454 _IE_UART1	=	0x00ec
                           0000EB   455 _IE_ADC	=	0x00eb
                           0000E9   456 _IE_USB	=	0x00e9
                           0000E8   457 _IE_SPI0	=	0x00e8
                           000087   458 _P0_7	=	0x0087
                           000086   459 _P0_6	=	0x0086
                           000085   460 _P0_5	=	0x0085
                           000084   461 _P0_4	=	0x0084
                           000083   462 _P0_3	=	0x0083
                           000082   463 _P0_2	=	0x0082
                           000081   464 _P0_1	=	0x0081
                           000080   465 _P0_0	=	0x0080
                           000081   466 _SDA0	=	0x0081
                           000080   467 _SCL0	=	0x0080
                           000083   468 _TXD_	=	0x0083
                           000082   469 _RXD_	=	0x0082
                           000085   470 _AIN13	=	0x0085
                           000084   471 _AIN12	=	0x0084
                           000083   472 _AIN11	=	0x0083
                           000082   473 _AIN10	=	0x0082
                           000081   474 _AIN9	=	0x0081
                           000080   475 _AIN8	=	0x0080
                           000097   476 _P1_7	=	0x0097
                           000096   477 _P1_6	=	0x0096
                           000095   478 _P1_5	=	0x0095
                           000094   479 _P1_4	=	0x0094
                           000093   480 _P1_3	=	0x0093
                           000092   481 _P1_2	=	0x0092
                           000091   482 _P1_1	=	0x0091
                           000090   483 _P1_0	=	0x0090
                           000097   484 _TXD1_	=	0x0097
                           000096   485 _RXD1_	=	0x0096
                           000097   486 _SCK	=	0x0097
                           000096   487 _MISO	=	0x0096
                           000095   488 _MOSI	=	0x0095
                           000094   489 _SCS	=	0x0094
                           000092   490 _INT0_	=	0x0092
                           000091   491 _T2EX	=	0x0091
                           000091   492 _CAP2	=	0x0091
                           000090   493 _T2	=	0x0090
                           000090   494 _CAP1	=	0x0090
                           000097   495 _AIN7	=	0x0097
                           000096   496 _AIN6	=	0x0096
                           000095   497 _AIN5	=	0x0095
                           000094   498 _AIN4	=	0x0094
                           000093   499 _AIN3	=	0x0093
                           000092   500 _AIN2	=	0x0092
                           000091   501 _AIN1	=	0x0091
                           000090   502 _AIN0	=	0x0090
                           0000A7   503 _P2_7	=	0x00a7
                           0000A6   504 _P2_6	=	0x00a6
                           0000A5   505 _P2_5	=	0x00a5
                           0000A4   506 _P2_4	=	0x00a4
                           0000A3   507 _P2_3	=	0x00a3
                           0000A2   508 _P2_2	=	0x00a2
                           0000A1   509 _P2_1	=	0x00a1
                           0000A0   510 _P2_0	=	0x00a0
                           0000A7   511 _TXD1	=	0x00a7
                           0000A6   512 _RXD1	=	0x00a6
                           0000A5   513 _T2EX_	=	0x00a5
                           0000A5   514 _CAP2_	=	0x00a5
                           0000A4   515 _T2_	=	0x00a4
                           0000A4   516 _CAP1_	=	0x00a4
                           0000B7   517 _P3_7	=	0x00b7
                           0000B6   518 _P3_6	=	0x00b6
                           0000B5   519 _P3_5	=	0x00b5
                           0000B4   520 _P3_4	=	0x00b4
                           0000B3   521 _P3_3	=	0x00b3
                           0000B2   522 _P3_2	=	0x00b2
                           0000B1   523 _P3_1	=	0x00b1
                           0000B0   524 _P3_0	=	0x00b0
                           0000B7   525 _SCK1	=	0x00b7
                           0000B6   526 _MISO1	=	0x00b6
                           0000B5   527 _MOSI1	=	0x00b5
                           0000B5   528 _T1	=	0x00b5
                           0000B4   529 _T0	=	0x00b4
                           0000B3   530 _INT1	=	0x00b3
                           0000B2   531 _INT0	=	0x00b2
                           0000B1   532 _TXD	=	0x00b1
                           0000B0   533 _RXD	=	0x00b0
                           0000C6   534 _P4_6	=	0x00c6
                           0000C5   535 _P4_5	=	0x00c5
                           0000C4   536 _P4_4	=	0x00c4
                           0000C3   537 _P4_3	=	0x00c3
                           0000C2   538 _P4_2	=	0x00c2
                           0000C1   539 _P4_1	=	0x00c1
                           0000C0   540 _P4_0	=	0x00c0
                           00008F   541 _TF1	=	0x008f
                           00008E   542 _TR1	=	0x008e
                           00008D   543 _TF0	=	0x008d
                           00008C   544 _TR0	=	0x008c
                           00008B   545 _IE1	=	0x008b
                           00008A   546 _IT1	=	0x008a
                           000089   547 _IE0	=	0x0089
                           000088   548 _IT0	=	0x0088
                           00009F   549 _SM0	=	0x009f
                           00009E   550 _SM1	=	0x009e
                           00009D   551 _SM2	=	0x009d
                           00009C   552 _REN	=	0x009c
                           00009B   553 _TB8	=	0x009b
                           00009A   554 _RB8	=	0x009a
                           000099   555 _TI	=	0x0099
                           000098   556 _RI	=	0x0098
                           0000CF   557 _TF2	=	0x00cf
                           0000CF   558 _CAP1F	=	0x00cf
                           0000CE   559 _EXF2	=	0x00ce
                           0000CD   560 _RCLK	=	0x00cd
                           0000CC   561 _TCLK	=	0x00cc
                           0000CB   562 _EXEN2	=	0x00cb
                           0000CA   563 _TR2	=	0x00ca
                           0000C9   564 _C_T2	=	0x00c9
                           0000C8   565 _CP_RL2	=	0x00c8
                           0000FF   566 _S0_FST_ACT	=	0x00ff
                           0000FE   567 _S0_IF_OV	=	0x00fe
                           0000FD   568 _S0_IF_FIRST	=	0x00fd
                           0000FC   569 _S0_IF_BYTE	=	0x00fc
                           0000FB   570 _S0_FREE	=	0x00fb
                           0000FA   571 _S0_T_FIFO	=	0x00fa
                           0000F8   572 _S0_R_FIFO	=	0x00f8
                           0000F7   573 _ADC_START	=	0x00f7
                                    574 ;--------------------------------------------------------
                                    575 ; overlayable register banks
                                    576 ;--------------------------------------------------------
                                    577 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        578 	.ds 8
                                    579 ;--------------------------------------------------------
                                    580 ; internal ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area DSEG    (DATA)
      000027                        583 _process_action_sloc0_1_0:
      000027                        584 	.ds 1
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable items in internal ram
                                    587 ;--------------------------------------------------------
                                    588 ;--------------------------------------------------------
                                    589 ; indirectly addressable internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area ISEG    (DATA)
                                    592 ;--------------------------------------------------------
                                    593 ; absolute internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area IABS    (ABS,DATA)
                                    596 	.area IABS    (ABS,DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; bit data
                                    599 ;--------------------------------------------------------
                                    600 	.area BSEG    (BIT)
      00001F                        601 _process_action_sloc1_1_0:
      00001F                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      00080C                        611 _tp_buttons::
      00080C                        612 	.ds 2
      00080E                        613 _action_exec_PARM_1:
      00080E                        614 	.ds 6
      000814                        615 _action_exec_record_10001_620:
      000814                        616 	.ds 9
      00081D                        617 _ak820_action_exec_event_10000_624:
      00081D                        618 	.ds 2
      00081F                        619 _ak820_action_exec_snapshot_10000_625:
      00081F                        620 	.ds 6
      000825                        621 _process_record_record_10000_628:
      000825                        622 	.ds 3
      000828                        623 _process_record_handler_record_argument_10000_634:
      000828                        624 	.ds 3
      00082B                        625 _process_record_handler_action_10000_635:
      00082B                        626 	.ds 2
      00082D                        627 _process_action_PARM_2:
      00082D                        628 	.ds 2
      00082F                        629 _process_action_record_argument_10000_646:
      00082F                        630 	.ds 3
      000832                        631 _process_action_on_40000_669:
      000832                        632 	.ds 1
      000833                        633 _register_code_code_10000_703:
      000833                        634 	.ds 1
      000834                        635 _unregister_code_code_10000_717:
      000834                        636 	.ds 1
      000835                        637 _tap_code_delay_PARM_2:
      000835                        638 	.ds 2
      000837                        639 _tap_code_delay_code_10000_730:
      000837                        640 	.ds 1
      000838                        641 _tap_code_code_10000_737:
      000838                        642 	.ds 1
      000839                        643 _register_mods_mods_10000_739:
      000839                        644 	.ds 1
      00083A                        645 _unregister_mods_mods_10000_743:
      00083A                        646 	.ds 1
      00083B                        647 _register_weak_mods_mods_10000_747:
      00083B                        648 	.ds 1
      00083C                        649 _unregister_weak_mods_mods_10000_751:
      00083C                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DBA                        659 _disable_action_cache::
      000DBA                        660 	.ds 1
                                    661 	.area HOME    (CODE)
                                    662 	.area GSINIT0 (CODE)
                                    663 	.area GSINIT1 (CODE)
                                    664 	.area GSINIT2 (CODE)
                                    665 	.area GSINIT3 (CODE)
                                    666 	.area GSINIT4 (CODE)
                                    667 	.area GSINIT5 (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area CSEG    (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; global & static initialisations
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; Home
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area HOME    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; code
                                    685 ;--------------------------------------------------------
                                    686 	.area CSEG    (CODE)
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    689 ;------------------------------------------------------------
                                    690 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    693 ;	-----------------------------------------
                           000007   694 	ar7 = 0x07
                           000006   695 	ar6 = 0x06
                           000005   696 	ar5 = 0x05
                           000004   697 	ar4 = 0x04
                           000003   698 	ar3 = 0x03
                           000002   699 	ar2 = 0x02
                           000001   700 	ar1 = 0x01
                           000000   701 	ar0 = 0x00
                                    702 ;	 function action_exec
                                    703 ;	-----------------------------------------
      006EE3                        704 _action_exec:
                                    705 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      006EE3 90 08 10         [24]  706 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006EE6 12 37 F5         [24]  707 	lcall	_ak820_outline_0005
      006EE9 12 36 04         [24]  708 	lcall	_ak820_combo_tick
                                    709 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      006EEC 90 08 0E         [24]  710 	mov	dptr,#_action_exec_PARM_1
      006EEF 12 44 4D         [24]  711 	lcall	_ak820_tapping_before
      006EF2 E5 82            [12]  712 	mov	a, dpl
      006EF4 70 01            [24]  713 	jnz	00102$
      006EF6 22               [24]  714 	ret
      006EF7                        715 00102$:
                                    716 ;	quantum/action.c:113: if (event.pressed) {
      006EF7 90 08 13         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006EFA E0               [24]  718 	movx	a,@dptr
      006EFB 60 03            [24]  719 	jz	00104$
                                    720 ;	quantum/action.c:115: clear_weak_mods();
      006EFD 12 7E 6F         [24]  721 	lcall	_clear_weak_mods
      006F00                        722 00104$:
                                    723 ;	quantum/action.c:127: record.event = event;
      006F00 90 0D 9B         [24]  724 	mov	dptr,#___memcpy_PARM_2
      006F03 74 0E            [12]  725 	mov	a,#_action_exec_PARM_1
      006F05 F0               [24]  726 	movx	@dptr,a
      006F06 74 08            [12]  727 	mov	a,#(_action_exec_PARM_1 >> 8)
      006F08 12 38 6B         [24]  728 	lcall	_ak820_outline_0090
      006F0B 12 74 E9         [24]  729 	lcall	_ak820_outline_0070
      006F0E 90 08 14         [24]  730 	mov	dptr,#_action_exec_record_10001_620
      006F11 F5 F0            [12]  731 	mov	b,a
      006F13 12 B5 CA         [24]  732 	lcall	___memcpy
                                    733 ;	quantum/action.c:129: record.tap.count = 0;
      006F16 90 08 1A         [24]  734 	mov	dptr,#(_action_exec_record_10001_620 + 0x0006)
      006F19 E0               [24]  735 	movx	a,@dptr
      006F1A 54 0F            [12]  736 	anl	a,#0x0f
      006F1C F0               [24]  737 	movx	@dptr,a
                                    738 ;	quantum/action.c:134: record.keycode = 0;
      006F1D 90 08 1B         [24]  739 	mov	dptr,#(_action_exec_record_10001_620 + 0x0007)
      006F20 12 4D E7         [24]  740 	lcall	_ak820_outline_0166
                                    741 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006F23 90 08 18         [24]  742 	mov	dptr,#(_action_exec_record_10001_620 + 0x0004)
      006F26 E0               [24]  743 	movx	a,@dptr
      006F27 60 0D            [24]  744 	jz	00107$
      006F29 90 08 14         [24]  745 	mov	dptr,#_action_exec_record_10001_620
      006F2C 75 F0 00         [24]  746 	mov	b, #0x00
      006F2F 12 9C 75         [24]  747 	lcall	_pre_process_record_quantum
      006F32 E5 82            [12]  748 	mov	a, dpl
      006F34 60 14            [24]  749 	jz	00110$
      006F36                        750 00107$:
                                    751 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      006F36 90 08 14         [24]  752 	mov	dptr,#_action_exec_record_10001_620
      006F39 12 45 3B         [24]  753 	lcall	_ak820_tapping_process
      006F3C E5 82            [12]  754 	mov	a, dpl
      006F3E 70 01            [24]  755 	jnz	00106$
      006F40 22               [24]  756 	ret
      006F41                        757 00106$:
                                    758 ;	quantum/action.c:172: process_record(&record);
      006F41 90 08 14         [24]  759 	mov	dptr,#_action_exec_record_10001_620
      006F44 75 F0 00         [24]  760 	mov	b, #0x00
                                    761 ;	quantum/action.c:182: }
      006F47 02 6F 87         [24]  762 	ljmp	_process_record
      006F4A                        763 00110$:
      006F4A 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'ak820_action_exec'
                                    767 ;------------------------------------------------------------
                                    768 ;event         Allocated with name '_ak820_action_exec_event_10000_624'
                                    769 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_625'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function ak820_action_exec
                                    774 ;	-----------------------------------------
      006F4B                        775 _ak820_action_exec:
      006F4B 12 38 7D         [24]  776 	lcall	_ak820_outline_0112
      006F4E 90 08 1D         [24]  777 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F51 12 38 82         [24]  778 	lcall	_ak820_outline_0113
                                    779 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      006F54 90 08 1D         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F57 12 38 71         [24]  781 	lcall	_ak820_outline_0093
      006F5A 7F 00            [12]  782 	mov	r7,#0x00
      006F5C 90 0D 9B         [24]  783 	mov	dptr,#___memcpy_PARM_2
      006F5F ED               [12]  784 	mov	a,r5
      006F60 12 38 20         [24]  785 	lcall	_ak820_outline_0015
      006F63 12 74 E9         [24]  786 	lcall	_ak820_outline_0070
      006F66 90 08 1F         [24]  787 	mov	dptr,#_ak820_action_exec_snapshot_10000_625
      006F69 F5 F0            [12]  788 	mov	b,a
      006F6B 12 B5 CA         [24]  789 	lcall	___memcpy
                                    790 ;	quantum/action.c:189: action_exec(snapshot);
      006F6E 90 0D 9B         [24]  791 	mov	dptr,#___memcpy_PARM_2
      006F71 74 1F            [12]  792 	mov	a,#_ak820_action_exec_snapshot_10000_625
      006F73 F0               [24]  793 	movx	@dptr,a
      006F74 74 08            [12]  794 	mov	a,#(_ak820_action_exec_snapshot_10000_625 >> 8)
      006F76 12 38 6B         [24]  795 	lcall	_ak820_outline_0090
      006F79 12 74 E9         [24]  796 	lcall	_ak820_outline_0070
      006F7C 90 08 0E         [24]  797 	mov	dptr,#_action_exec_PARM_1
      006F7F F5 F0            [12]  798 	mov	b,a
      006F81 12 B5 CA         [24]  799 	lcall	___memcpy
                                    800 ;	quantum/action.c:190: }
      006F84 02 6E E3         [24]  801 	ljmp	_action_exec
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'process_record_nocache'
                                    804 ;------------------------------------------------------------
                                    805 ;record        Allocated with name '_process_record_nocache_record_10000_626'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function process_record
                                    810 ;	-----------------------------------------
      006F87                        811 _process_record:
      006F87 12 43 0E         [24]  812 	lcall	_ak820_outline_0035
      006F8A 90 08 25         [24]  813 	mov	dptr,#_process_record_record_10000_628
      006F8D 12 38 20         [24]  814 	lcall	_ak820_outline_0015
                                    815 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      006F90 90 08 25         [24]  816 	mov	dptr,#_process_record_record_10000_628
      006F93 12 4D 9B         [24]  817 	lcall	_ak820_outline_0013
      006F96 74 04            [12]  818 	mov	a,#0x04
      006F98 12 74 BC         [24]  819 	lcall	_ak820_outline_0012
      006F9B 12 B6 A3         [24]  820 	lcall	__gptrget
      006F9E 70 01            [24]  821 	jnz	00102$
                                    822 ;	quantum/action.c:330: return;
      006FA0 22               [24]  823 	ret
      006FA1                        824 00102$:
                                    825 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      006FA1 12 6C 29         [24]  826 	lcall	_ak820_outline_0046
      006FA4 C0 07            [24]  827 	push	ar7
      006FA6 C0 06            [24]  828 	push	ar6
      006FA8 C0 05            [24]  829 	push	ar5
      006FAA 12 9C FD         [24]  830 	lcall	_process_record_quantum
      006FAD E5 82            [12]  831 	mov	a, dpl
      006FAF D0 05            [24]  832 	pop	ar5
      006FB1 D0 06            [24]  833 	pop	ar6
      006FB3 D0 07            [24]  834 	pop	ar7
      006FB5 70 01            [24]  835 	jnz	00104$
                                    836 ;	quantum/action.c:352: return;
      006FB7 22               [24]  837 	ret
      006FB8                        838 00104$:
                                    839 ;	quantum/action.c:358: process_record_handler(record);
      006FB8 12 6C 29         [24]  840 	lcall	_ak820_outline_0046
      006FBB 12 6F C7         [24]  841 	lcall	_process_record_handler
                                    842 ;	quantum/action.c:362: post_process_record_quantum(record);
      006FBE 90 08 25         [24]  843 	mov	dptr,#_process_record_record_10000_628
      006FC1 12 4D 75         [24]  844 	lcall	_ak820_outline_0001
                                    845 ;	quantum/action.c:366: }
      006FC4 02 9C D2         [24]  846 	ljmp	_post_process_record_quantum
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'process_record_handler'
                                    849 ;------------------------------------------------------------
                                    850 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_634'
                                    851 ;record        Allocated with name '_process_record_handler_record_10000_635'
                                    852 ;action        Allocated with name '_process_record_handler_action_10000_635'
                                    853 ;------------------------------------------------------------
                                    854 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    855 ;	-----------------------------------------
                                    856 ;	 function process_record_handler
                                    857 ;	-----------------------------------------
      006FC7                        858 _process_record_handler:
      006FC7 12 43 0E         [24]  859 	lcall	_ak820_outline_0035
      006FCA 90 08 28         [24]  860 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006FCD 12 38 20         [24]  861 	lcall	_ak820_outline_0015
                                    862 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006FD0 90 08 28         [24]  863 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006FD3 12 37 FF         [24]  864 	lcall	_ak820_outline_0007
                                    865 ;	quantum/action.c:379: if (record->keycode) {
      006FD6 4C               [12]  866 	orl	a,r4
      006FD7 60 19            [24]  867 	jz	00102$
                                    868 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      006FD9 12 38 92         [24]  869 	lcall	_ak820_outline_0121
      006FDC C0 07            [24]  870 	push	ar7
      006FDE C0 06            [24]  871 	push	ar6
      006FE0 12 92 63         [24]  872 	lcall	_action_for_keycode
      006FE3 12 43 67         [24]  873 	lcall	_ak820_outline_0145
      006FE6 D0 06            [24]  874 	pop	ar6
      006FE8 D0 07            [24]  875 	pop	ar7
      006FEA 90 08 2B         [24]  876 	mov	dptr,#_process_record_handler_action_10000_635
      006FED 12 38 5F         [24]  877 	lcall	_ak820_outline_0071
      006FF0 80 2B            [24]  878 	sjmp	00104$
      006FF2                        879 00102$:
                                    880 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      006FF2 12 74 CA         [24]  881 	lcall	_ak820_outline_0019
      006FF5 7A 00            [12]  882 	mov	r2,#0x00
      006FF7 12 43 61         [24]  883 	lcall	_ak820_outline_0138
      006FFA 12 42 FC         [24]  884 	lcall	_ak820_outline_0011
      006FFD E0               [24]  885 	movx	a,@dptr
      006FFE 90 09 67         [24]  886 	mov	dptr,#_ak820_resolve_key_PARM_2
      007001 F0               [24]  887 	movx	@dptr,a
      007002 8D 82            [24]  888 	mov	dpl, r5
      007004 8C 83            [24]  889 	mov	dph, r4
      007006 C0 07            [24]  890 	push	ar7
      007008 C0 06            [24]  891 	push	ar6
      00700A 12 78 62         [24]  892 	lcall	_ak820_resolve_key
      00700D 12 92 63         [24]  893 	lcall	_action_for_keycode
      007010 12 43 67         [24]  894 	lcall	_ak820_outline_0145
      007013 D0 06            [24]  895 	pop	ar6
      007015 D0 07            [24]  896 	pop	ar7
      007017 90 08 2B         [24]  897 	mov	dptr,#_process_record_handler_action_10000_635
      00701A 12 38 5F         [24]  898 	lcall	_ak820_outline_0071
                                    899 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      00701D                        900 00104$:
                                    901 ;	quantum/action.c:403: process_action(record, action);
      00701D 7D 00            [12]  902 	mov	r5,#0x00
      00701F 90 0D 9B         [24]  903 	mov	dptr,#___memcpy_PARM_2
      007022 74 2B            [12]  904 	mov	a,#_process_record_handler_action_10000_635
      007024 F0               [24]  905 	movx	@dptr,a
      007025 74 08            [12]  906 	mov	a,#(_process_record_handler_action_10000_635 >> 8)
      007027 12 38 6B         [24]  907 	lcall	_ak820_outline_0090
      00702A 90 0D 9E         [24]  908 	mov	dptr,#___memcpy_PARM_3
      00702D 74 02            [12]  909 	mov	a,#0x02
      00702F 12 38 97         [24]  910 	lcall	_ak820_outline_0122
      007032 90 08 2D         [24]  911 	mov	dptr,#_process_action_PARM_2
      007035 F5 F0            [12]  912 	mov	b,a
      007037 C0 07            [24]  913 	push	ar7
      007039 C0 06            [24]  914 	push	ar6
      00703B C0 05            [24]  915 	push	ar5
      00703D 12 B5 CA         [24]  916 	lcall	___memcpy
      007040 D0 05            [24]  917 	pop	ar5
      007042 D0 06            [24]  918 	pop	ar6
      007044 D0 07            [24]  919 	pop	ar7
      007046 12 6E 4E         [24]  920 	lcall	_ak820_outline_0050
                                    921 ;	quantum/action.c:404: }
      007049 02 70 4C         [24]  922 	ljmp	_process_action
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'register_mouse'
                                    925 ;------------------------------------------------------------
                                    926 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    927 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_643'
                                    928 ;------------------------------------------------------------
                                    929 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function process_action
                                    932 ;	-----------------------------------------
      00704C                        933 _process_action:
      00704C 12 43 0E         [24]  934 	lcall	_ak820_outline_0035
      00704F 90 08 2F         [24]  935 	mov	dptr,#_process_action_record_argument_10000_646
      007052 12 38 20         [24]  936 	lcall	_ak820_outline_0015
                                    937 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007055 90 08 2F         [24]  938 	mov	dptr,#_process_action_record_argument_10000_646
      007058 12 37 F5         [24]  939 	lcall	_ak820_outline_0005
                                    940 ;	quantum/action.c:475: pressed = record->event.pressed;
      00705B A3               [24]  941 	inc	dptr
      00705C A3               [24]  942 	inc	dptr
      00705D A3               [24]  943 	inc	dptr
      00705E A3               [24]  944 	inc	dptr
      00705F A3               [24]  945 	inc	dptr
      007060 E0               [24]  946 	movx	a,@dptr
      007061 F5 27            [12]  947 	mov	_process_action_sloc0_1_0,a
                                    948 ;	quantum/action.c:499: switch (action.kind.id) {
      007063 90 08 2E         [24]  949 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007066 E0               [24]  950 	movx	a,@dptr
      007067 C4               [12]  951 	swap	a
      007068 54 0F            [12]  952 	anl	a,#0x0f
      00706A FD               [12]  953 	mov  r5,a
      00706B 24 F4            [12]  954 	add	a,#0xff - 0x0b
      00706D 50 03            [24]  955 	jnc	00434$
      00706F 02 72 ED         [24]  956 	ljmp	00181$
      007072                        957 00434$:
                                    958 ;	free result
      007072 ED               [12]  959 	mov	a,r5
      007073 24 0A            [12]  960 	add	a,#(00435$-3-.)
      007075 83               [24]  961 	movc	a,@a+pc
      007076 F5 82            [12]  962 	mov	dpl,a
      007078 ED               [12]  963 	mov	a,r5
      007079 24 10            [12]  964 	add	a,#(00436$-3-.)
      00707B 83               [24]  965 	movc	a,@a+pc
      00707C F5 83            [12]  966 	mov	dph,a
      00707E E4               [12]  967 	clr	a
      00707F 73               [24]  968 	jmp	@a+dptr
      007080                        969 00435$:
      007080 98                     970 	.db	00102$
      007081 98                     971 	.db	00102$
      007082 ED                     972 	.db	00181$
      007083 ED                     973 	.db	00181$
      007084 22                     974 	.db	00123$
      007085 ED                     975 	.db	00181$
      007086 ED                     976 	.db	00181$
      007087 ED                     977 	.db	00181$
      007088 82                     978 	.db	00131$
      007089 54                     979 	.db	00147$
      00708A 7A                     980 	.db	00152$
      00708B 7A                     981 	.db	00152$
      00708C                        982 00436$:
      00708C 70                     983 	.db	00102$>>8
      00708D 70                     984 	.db	00102$>>8
      00708E 72                     985 	.db	00181$>>8
      00708F 72                     986 	.db	00181$>>8
      007090 71                     987 	.db	00123$>>8
      007091 72                     988 	.db	00181$>>8
      007092 72                     989 	.db	00181$>>8
      007093 72                     990 	.db	00181$>>8
      007094 71                     991 	.db	00131$>>8
      007095 72                     992 	.db	00147$>>8
      007096 72                     993 	.db	00152$>>8
      007097 72                     994 	.db	00152$>>8
                                    995 ;	quantum/action.c:502: case ACT_RMODS: {
      007098                        996 00102$:
                                    997 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007098 90 08 2E         [24]  998 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00709B E0               [24]  999 	movx	a,@dptr
      00709C 54 F0            [12] 1000 	anl	a,#0xf0
      00709E 70 06            [24] 1001 	jnz	00194$
      0070A0 12 75 03         [24] 1002 	lcall	_ak820_outline_0107
      0070A3 FD               [12] 1003 	mov	r5,a
      0070A4 80 07            [24] 1004 	sjmp	00195$
      0070A6                       1005 00194$:
      0070A6 12 75 03         [24] 1006 	lcall	_ak820_outline_0107
      0070A9 C4               [12] 1007 	swap	a
      0070AA 54 F0            [12] 1008 	anl	a,#0xf0
      0070AC FD               [12] 1009 	mov	r5,a
      0070AD                       1010 00195$:
                                   1011 ;	quantum/action.c:505: if (pressed) {
      0070AD E5 27            [12] 1012 	mov	a,_process_action_sloc0_1_0
      0070AF 60 35            [24] 1013 	jz	00119$
                                   1014 ;	quantum/action.c:506: if (mods) {
      0070B1 ED               [12] 1015 	mov	a,r5
      0070B2 60 29            [24] 1016 	jz	00110$
                                   1017 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0070B4 12 75 15         [24] 1018 	lcall	_ak820_outline_0155
      0070B7 FC               [12] 1019 	mov	r4,a
      0070B8 BC E0 00         [24] 1020 	cjne	r4,#0xe0,00440$
      0070BB                       1021 00440$:
      0070BB 40 07            [24] 1022 	jc	00108$
      0070BD 12 75 15         [24] 1023 	lcall	_ak820_outline_0155
      0070C0 24 18            [12] 1024 	add	a,#0xff - 0xe7
      0070C2 50 0A            [24] 1025 	jnc	00104$
                                   1026 ;	free result
      0070C4                       1027 00108$:
      0070C4 7B 2D            [12] 1028 	mov	r3,#_process_action_PARM_2
      0070C6 7C 08            [12] 1029 	mov	r4,#(_process_action_PARM_2 >> 8)
      0070C8 12 33 FC         [24] 1030 	lcall	_ak820_outline_0120
      0070CB E0               [24] 1031 	movx	a,@dptr
      0070CC 70 07            [24] 1032 	jnz	00105$
      0070CE                       1033 00104$:
                                   1034 ;	quantum/action.c:511: add_owned_mods(mods);
      0070CE 8D 82            [24] 1035 	mov	dpl, r5
      0070D0 12 7A 7C         [24] 1036 	lcall	_add_owned_mods
      0070D3 80 05            [24] 1037 	sjmp	00106$
      0070D5                       1038 00105$:
                                   1039 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      0070D5 8D 82            [24] 1040 	mov	dpl, r5
      0070D7 12 7A 9B         [24] 1041 	lcall	_add_owned_weak_mods
      0070DA                       1042 00106$:
                                   1043 ;	quantum/action.c:515: send_keyboard_report();
      0070DA 12 7D C0         [24] 1044 	lcall	_send_keyboard_report
      0070DD                       1045 00110$:
                                   1046 ;	quantum/action.c:517: register_code(action.key.code);
      0070DD 12 74 F3         [24] 1047 	lcall	_ak820_outline_0076
      0070E0 12 73 04         [24] 1048 	lcall	_register_code
      0070E3 02 72 ED         [24] 1049 	ljmp	00181$
      0070E6                       1050 00119$:
                                   1051 ;	quantum/action.c:519: unregister_code(action.key.code);
      0070E6 12 74 F3         [24] 1052 	lcall	_ak820_outline_0076
      0070E9 C0 05            [24] 1053 	push	ar5
      0070EB 12 73 71         [24] 1054 	lcall	_unregister_code
      0070EE D0 05            [24] 1055 	pop	ar5
                                   1056 ;	quantum/action.c:520: if (mods) {
      0070F0 ED               [12] 1057 	mov	a,r5
      0070F1 70 03            [24] 1058 	jnz	00444$
      0070F3 02 72 ED         [24] 1059 	ljmp	00181$
      0070F6                       1060 00444$:
                                   1061 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0070F6 12 75 15         [24] 1062 	lcall	_ak820_outline_0155
      0070F9 FC               [12] 1063 	mov	r4,a
      0070FA BC E0 00         [24] 1064 	cjne	r4,#0xe0,00445$
      0070FD                       1065 00445$:
      0070FD 40 07            [24] 1066 	jc	00115$
      0070FF 12 75 15         [24] 1067 	lcall	_ak820_outline_0155
      007102 24 18            [12] 1068 	add	a,#0xff - 0xe7
      007104 50 0A            [24] 1069 	jnc	00111$
                                   1070 ;	free result
      007106                       1071 00115$:
      007106 7B 2D            [12] 1072 	mov	r3,#_process_action_PARM_2
      007108 7C 08            [12] 1073 	mov	r4,#(_process_action_PARM_2 >> 8)
      00710A 12 33 FC         [24] 1074 	lcall	_ak820_outline_0120
      00710D E0               [24] 1075 	movx	a,@dptr
      00710E 70 07            [24] 1076 	jnz	00112$
      007110                       1077 00111$:
                                   1078 ;	quantum/action.c:522: del_owned_mods(mods);
      007110 8D 82            [24] 1079 	mov	dpl, r5
      007112 12 7A 8C         [24] 1080 	lcall	_del_owned_mods
      007115 80 05            [24] 1081 	sjmp	00113$
      007117                       1082 00112$:
                                   1083 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007117 8D 82            [24] 1084 	mov	dpl, r5
      007119 12 7A AB         [24] 1085 	lcall	_del_owned_weak_mods
      00711C                       1086 00113$:
                                   1087 ;	quantum/action.c:526: send_keyboard_report();
      00711C 12 7D C0         [24] 1088 	lcall	_send_keyboard_report
                                   1089 ;	quantum/action.c:529: } break;
      00711F 02 72 ED         [24] 1090 	ljmp	00181$
                                   1091 ;	quantum/action.c:606: case ACT_USAGE:
      007122                       1092 00123$:
                                   1093 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007122 74 07            [12] 1094 	mov	a,#0x07
      007124 12 38 32         [24] 1095 	lcall	_ak820_outline_0020
      007127 12 46 F6         [24] 1096 	lcall	_ak820_outline_0008
      00712A C3               [12] 1097 	clr	c
      00712B EC               [12] 1098 	mov	a,r4
      00712C 94 A5            [12] 1099 	subb	a,#0xa5
      00712E ED               [12] 1100 	mov	a,r5
      00712F 94 00            [12] 1101 	subb	a,#0x00
      007131 40 15            [24] 1102 	jc	00125$
      007133 74 C2            [12] 1103 	mov	a,#0xc2
      007135 9C               [12] 1104 	subb	a,r4
      007136 E4               [12] 1105 	clr	a
      007137 9D               [12] 1106 	subb	a,r5
      007138 40 0E            [24] 1107 	jc	00125$
                                   1108 ;	free result
                                   1109 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      00713A 90 0A 8E         [24] 1110 	mov	dptr,#_owned_usage_key_PARM_2
      00713D E5 27            [12] 1111 	mov	a,_process_action_sloc0_1_0
      00713F F0               [24] 1112 	movx	@dptr,a
      007140 8E 82            [24] 1113 	mov	dpl, r6
      007142 12 7C 6B         [24] 1114 	lcall	_owned_usage_key
                                   1115 ;	quantum/action.c:614: break;
      007145 02 72 ED         [24] 1116 	ljmp	00181$
      007148                       1117 00125$:
                                   1118 ;	quantum/action.c:617: switch (action.usage.page) {
      007148 12 74 FA         [24] 1119 	lcall	_ak820_outline_0086
      00714B FF               [12] 1120 	mov	r7,a
      00714C 60 08            [24] 1121 	jz	00127$
      00714E BF 01 02         [24] 1122 	cjne	r7,#0x01,00452$
      007151 80 19            [24] 1123 	sjmp	00128$
      007153                       1124 00452$:
      007153 02 72 ED         [24] 1125 	ljmp	00181$
                                   1126 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007156                       1127 00127$:
                                   1128 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007156 E5 27            [12] 1129 	mov	a,_process_action_sloc0_1_0
      007158 60 05            [24] 1130 	jz	00196$
      00715A 12 75 0A         [24] 1131 	lcall	_ak820_outline_0128
      00715D 80 04            [24] 1132 	sjmp	00197$
      00715F                       1133 00196$:
      00715F 7E 00            [12] 1134 	mov	r6,#0x00
      007161 7F 00            [12] 1135 	mov	r7,#0x00
      007163                       1136 00197$:
      007163 12 38 87         [24] 1137 	lcall	_ak820_outline_0114
      007166 12 6B B3         [24] 1138 	lcall	_host_system_send
                                   1139 ;	quantum/action.c:620: break;
      007169 02 72 ED         [24] 1140 	ljmp	00181$
                                   1141 ;	quantum/action.c:621: case PAGE_CONSUMER:
      00716C                       1142 00128$:
                                   1143 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      00716C E5 27            [12] 1144 	mov	a,_process_action_sloc0_1_0
      00716E 60 05            [24] 1145 	jz	00198$
      007170 12 75 0A         [24] 1146 	lcall	_ak820_outline_0128
      007173 80 04            [24] 1147 	sjmp	00199$
      007175                       1148 00198$:
      007175 7E 00            [12] 1149 	mov	r6,#0x00
      007177 7F 00            [12] 1150 	mov	r7,#0x00
      007179                       1151 00199$:
      007179 12 38 87         [24] 1152 	lcall	_ak820_outline_0114
      00717C 12 6B E3         [24] 1153 	lcall	_host_consumer_send
                                   1154 ;	quantum/action.c:625: break;
      00717F 02 72 ED         [24] 1155 	ljmp	00181$
                                   1156 ;	quantum/action.c:632: case ACT_LAYER: {
      007182                       1157 00131$:
                                   1158 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      007182 90 08 2E         [24] 1159 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007185 E0               [24] 1160 	movx	a,@dptr
      007186 54 03            [12] 1161 	anl	a,#0x03
      007188 90 08 32         [24] 1162 	mov	dptr,#_process_action_on_40000_669
      00718B F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00718C E0               [24] 1165 	movx	a,@dptr
      00718D FF               [12] 1166 	mov	r7,a
      00718E 60 11            [24] 1167 	jz	00200$
      007190 E5 27            [12] 1168 	mov	a,_process_action_sloc0_1_0
      007192 60 07            [24] 1169 	jz	00202$
      007194 8F 06            [24] 1170 	mov	ar6,r7
      007196 53 06 01         [24] 1171 	anl	ar6,#0x01
      007199 80 10            [24] 1172 	sjmp	00201$
      00719B                       1173 00202$:
      00719B 74 02            [12] 1174 	mov	a,#0x02
      00719D 5F               [12] 1175 	anl	a,r7
      00719E FE               [12] 1176 	mov	r6,a
      00719F 80 0A            [24] 1177 	sjmp	00201$
      0071A1                       1178 00200$:
      0071A1 E5 27            [12] 1179 	mov	a,_process_action_sloc0_1_0
      0071A3 B4 01 00         [24] 1180 	cjne	a,#0x01,00457$
      0071A6                       1181 00457$:
      0071A6 92 1F            [24] 1182 	mov  _process_action_sloc1_1_0,c
      0071A8 E4               [12] 1183 	clr	a
      0071A9 33               [12] 1184 	rlc	a
      0071AA FE               [12] 1185 	mov	r6,a
      0071AB                       1186 00201$:
      0071AB EE               [12] 1187 	mov	a,r6
      0071AC 70 03            [24] 1188 	jnz	00458$
      0071AE 02 72 ED         [24] 1189 	ljmp	00181$
      0071B1                       1190 00458$:
                                   1191 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      0071B1 12 75 15         [24] 1192 	lcall	_ak820_outline_0155
      0071B4 C4               [12] 1193 	swap	a
      0071B5 03               [12] 1194 	rr	a
      0071B6 54 07            [12] 1195 	anl	a,#0x07
      0071B8 25 E0            [12] 1196 	add	a,acc
      0071BA 25 E0            [12] 1197 	add	a,acc
      0071BC FF               [12] 1198 	mov	r7,a
                                   1199 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0071BD 12 75 15         [24] 1200 	lcall	_ak820_outline_0155
      0071C0 54 0F            [12] 1201 	anl	a,#0x0f
      0071C2 FE               [12] 1202 	mov	r6,a
      0071C3 8F F0            [24] 1203 	mov	b,r7
      0071C5 05 F0            [12] 1204 	inc	b
      0071C7 EE               [12] 1205 	mov	a,r6
      0071C8 80 02            [24] 1206 	sjmp	00460$
      0071CA                       1207 00459$:
      0071CA 25 E0            [12] 1208 	add	a,acc
      0071CC                       1209 00460$:
      0071CC D5 F0 FB         [24] 1210 	djnz	b,00459$
      0071CF FE               [12] 1211 	mov	r6,a
                                   1212 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0071D0 12 75 15         [24] 1213 	lcall	_ak820_outline_0155
      0071D3 30 E4 11         [24] 1214 	jnb	acc.4,00204$
      0071D6 8F F0            [24] 1215 	mov	b,r7
      0071D8 05 F0            [12] 1216 	inc	b
      0071DA 74 0F            [12] 1217 	mov	a,#0x0f
      0071DC 80 02            [24] 1218 	sjmp	00463$
      0071DE                       1219 00462$:
      0071DE 25 E0            [12] 1220 	add	a,acc
      0071E0                       1221 00463$:
      0071E0 D5 F0 FB         [24] 1222 	djnz	b,00462$
      0071E3 F4               [12] 1223 	cpl	a
      0071E4 FF               [12] 1224 	mov	r7,a
      0071E5 80 02            [24] 1225 	sjmp	00205$
      0071E7                       1226 00204$:
      0071E7 7F 00            [12] 1227 	mov	r7,#0x00
      0071E9                       1228 00205$:
                                   1229 ;	quantum/action.c:640: bits |= mask;
      0071E9 EE               [12] 1230 	mov	a,r6
      0071EA 42 07            [12] 1231 	orl	ar7,a
                                   1232 ;	quantum/action.c:641: if (!on) {
      0071EC 90 08 32         [24] 1233 	mov	dptr,#_process_action_on_40000_669
      0071EF E0               [24] 1234 	movx	a,@dptr
      0071F0 70 31            [24] 1235 	jnz	00143$
                                   1236 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      0071F2 12 74 FA         [24] 1237 	lcall	_ak820_outline_0086
      0071F5 FE               [12] 1238 	mov	r6,a
      0071F6 2E               [12] 1239 	add	a,r6
                                   1240 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      0071F7 90 71 FB         [24] 1241 	mov	dptr,#00465$
      0071FA 73               [24] 1242 	jmp	@a+dptr
      0071FB                       1243 00465$:
      0071FB 80 06            [24] 1244 	sjmp	00132$
      0071FD 80 0C            [24] 1245 	sjmp	00133$
      0071FF 80 12            [24] 1246 	sjmp	00134$
      007201 80 18            [24] 1247 	sjmp	00135$
      007203                       1248 00132$:
      007203 8F 82            [24] 1249 	mov	dpl, r7
      007205 12 75 70         [24] 1250 	lcall	_default_layer_and
      007208 02 72 ED         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      00720B                       1253 00133$:
      00720B 8F 82            [24] 1254 	mov	dpl, r7
      00720D 12 75 5F         [24] 1255 	lcall	_default_layer_or
      007210 02 72 ED         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007213                       1258 00134$:
      007213 8F 82            [24] 1259 	mov	dpl, r7
      007215 12 75 86         [24] 1260 	lcall	_default_layer_xor
      007218 02 72 ED         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00721B                       1263 00135$:
      00721B 8F 82            [24] 1264 	mov	dpl, r7
      00721D 12 75 54         [24] 1265 	lcall	_default_layer_set
                                   1266 ;	quantum/action.c:647: }
      007220 02 72 ED         [24] 1267 	ljmp	00181$
      007223                       1268 00143$:
                                   1269 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007223 12 74 FA         [24] 1270 	lcall	_ak820_outline_0086
      007226 FE               [12] 1271 	mov	r6,a
      007227 2E               [12] 1272 	add	a,r6
                                   1273 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007228 90 72 2C         [24] 1274 	mov	dptr,#00466$
      00722B 73               [24] 1275 	jmp	@a+dptr
      00722C                       1276 00466$:
      00722C 80 06            [24] 1277 	sjmp	00137$
      00722E 80 0C            [24] 1278 	sjmp	00138$
      007230 80 12            [24] 1279 	sjmp	00139$
      007232 80 18            [24] 1280 	sjmp	00140$
      007234                       1281 00137$:
      007234 8F 82            [24] 1282 	mov	dpl, r7
      007236 12 77 0A         [24] 1283 	lcall	_layer_and
      007239 02 72 ED         [24] 1284 	ljmp	00181$
                                   1285 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      00723C                       1286 00138$:
      00723C 8F 82            [24] 1287 	mov	dpl, r7
      00723E 12 76 F9         [24] 1288 	lcall	_layer_or
      007241 02 72 ED         [24] 1289 	ljmp	00181$
                                   1290 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007244                       1291 00139$:
      007244 8F 82            [24] 1292 	mov	dpl, r7
      007246 12 77 20         [24] 1293 	lcall	_layer_xor
      007249 02 72 ED         [24] 1294 	ljmp	00181$
                                   1295 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      00724C                       1296 00140$:
      00724C 8F 82            [24] 1297 	mov	dpl, r7
      00724E 12 76 96         [24] 1298 	lcall	_layer_state_set
                                   1299 ;	quantum/action.c:657: break;
      007251 02 72 ED         [24] 1300 	ljmp	00181$
                                   1301 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007254                       1302 00147$:
                                   1303 ;	quantum/action.c:660: if (pressed) {
      007254 E5 27            [12] 1304 	mov	a,_process_action_sloc0_1_0
      007256 60 11            [24] 1305 	jz	00149$
                                   1306 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007258 12 75 03         [24] 1307 	lcall	_ak820_outline_0107
      00725B F5 82            [12] 1308 	mov	dpl,a
      00725D 12 75 F6         [24] 1309 	lcall	_layer_hold_on
                                   1310 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      007260 12 74 F3         [24] 1311 	lcall	_ak820_outline_0076
      007263 12 74 27         [24] 1312 	lcall	_register_mods
      007266 02 72 ED         [24] 1313 	ljmp	00181$
      007269                       1314 00149$:
                                   1315 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007269 12 74 F3         [24] 1316 	lcall	_ak820_outline_0076
      00726C 12 74 3B         [24] 1317 	lcall	_unregister_mods
                                   1318 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      00726F 12 75 03         [24] 1319 	lcall	_ak820_outline_0107
      007272 F5 82            [12] 1320 	mov	dpl,a
      007274 12 76 2E         [24] 1321 	lcall	_layer_hold_off
                                   1322 ;	quantum/action.c:667: break;
      007277 02 72 ED         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      00727A                       1325 00152$:
                                   1326 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      00727A 12 75 15         [24] 1327 	lcall	_ak820_outline_0155
      00727D FF               [12] 1328 	mov	r7,a
      00727E BF F1 02         [24] 1329 	cjne	r7,#0xf1,00468$
      007281 80 0A            [24] 1330 	sjmp	00154$
      007283                       1331 00468$:
      007283 BF F2 02         [24] 1332 	cjne	r7,#0xf2,00469$
      007286 80 19            [24] 1333 	sjmp	00155$
      007288                       1334 00469$:
                                   1335 ;	quantum/action.c:686: momentary_layer_action:
      007288 BF F3 3B         [24] 1336 	cjne	r7,#0xf3,00160$
      00728B 80 28            [24] 1337 	sjmp	00156$
      00728D                       1338 00154$:
                                   1339 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00728D E5 27            [12] 1340 	mov	a,_process_action_sloc0_1_0
      00728F 60 08            [24] 1341 	jz	00206$
      007291 12 74 D9         [24] 1342 	lcall	_ak820_outline_0041
      007294 12 75 F6         [24] 1343 	lcall	_layer_hold_on
      007297 80 54            [24] 1344 	sjmp	00181$
      007299                       1345 00206$:
      007299 12 74 D9         [24] 1346 	lcall	_ak820_outline_0041
      00729C 12 76 2E         [24] 1347 	lcall	_layer_hold_off
                                   1348 ;	quantum/action.c:688: break;
                                   1349 ;	quantum/action.c:689: case OP_OFF_ON:
      00729F 80 4C            [24] 1350 	sjmp	00181$
      0072A1                       1351 00155$:
                                   1352 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0072A1 E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      0072A3 60 08            [24] 1354 	jz	00208$
      0072A5 12 74 D9         [24] 1355 	lcall	_ak820_outline_0041
      0072A8 12 76 DB         [24] 1356 	lcall	_layer_off
      0072AB 80 40            [24] 1357 	sjmp	00181$
      0072AD                       1358 00208$:
      0072AD 12 74 D9         [24] 1359 	lcall	_ak820_outline_0041
      0072B0 12 76 C0         [24] 1360 	lcall	_layer_on
                                   1361 ;	quantum/action.c:691: break;
                                   1362 ;	quantum/action.c:692: case OP_SET_CLEAR:
      0072B3 80 38            [24] 1363 	sjmp	00181$
      0072B5                       1364 00156$:
                                   1365 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0072B5 E5 27            [12] 1366 	mov	a,_process_action_sloc0_1_0
      0072B7 60 08            [24] 1367 	jz	00210$
      0072B9 12 74 D9         [24] 1368 	lcall	_ak820_outline_0041
      0072BC 12 76 AA         [24] 1369 	lcall	_layer_move
      0072BF 80 2C            [24] 1370 	sjmp	00181$
      0072C1                       1371 00210$:
      0072C1 12 76 A4         [24] 1372 	lcall	_layer_clear
                                   1373 ;	quantum/action.c:694: break;
                                   1374 ;	quantum/action.c:740: default:
      0072C4 80 27            [24] 1375 	sjmp	00181$
      0072C6                       1376 00160$:
                                   1377 ;	quantum/action.c:747: if (pressed) {
      0072C6 E5 27            [12] 1378 	mov	a,_process_action_sloc0_1_0
      0072C8 60 08            [24] 1379 	jz	00163$
                                   1380 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      0072CA 12 74 F3         [24] 1381 	lcall	_ak820_outline_0076
      0072CD 12 73 04         [24] 1382 	lcall	_register_code
                                   1383 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0072D0 80 1B            [24] 1384 	sjmp	00181$
      0072D2                       1385 00163$:
                                   1386 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      0072D2 12 75 15         [24] 1387 	lcall	_ak820_outline_0155
      0072D5 FF               [12] 1388 	mov	r7,a
      0072D6 BF 39 0E         [24] 1389 	cjne	r7,#0x39,00175$
                                   1390 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      0072D9 7F 50            [12] 1391 	mov	r7,#0x50
      0072DB                       1392 00187$:
      0072DB EF               [12] 1393 	mov	a,r7
      0072DC 60 09            [24] 1394 	jz	00175$
      0072DE 90 00 01         [24] 1395 	mov	dptr,#0x0001
      0072E1 12 57 61         [24] 1396 	lcall	_mDelaymS
      0072E4 1F               [12] 1397 	dec	r7
                                   1398 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      0072E5 80 F4            [24] 1399 	sjmp	00187$
      0072E7                       1400 00175$:
                                   1401 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      0072E7 12 74 F3         [24] 1402 	lcall	_ak820_outline_0076
      0072EA 12 73 71         [24] 1403 	lcall	_unregister_code
                                   1404 ;	quantum/action.c:840: }
      0072ED                       1405 00181$:
                                   1406 ;	quantum/action.c:861: switch (action.kind.id) {
      0072ED 90 08 2E         [24] 1407 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072F0 E0               [24] 1408 	movx	a,@dptr
      0072F1 C4               [12] 1409 	swap	a
      0072F2 54 0F            [12] 1410 	anl	a,#0x0f
      0072F4 FF               [12] 1411 	mov	r7,a
      0072F5 BF 08 02         [24] 1412 	cjne	r7,#0x08,00478$
      0072F8 80 03            [24] 1413 	sjmp	00183$
      0072FA                       1414 00478$:
      0072FA BF 09 06         [24] 1415 	cjne	r7,#0x09,00192$
                                   1416 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      0072FD                       1417 00183$:
                                   1418 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      0072FD 12 6B 18         [24] 1419 	lcall	_host_keyboard_leds
                                   1420 ;	quantum/action.c:872: }
                                   1421 ;	quantum/action.c:925: }
      007300 02 95 18         [24] 1422 	ljmp	_led_set
      007303                       1423 00192$:
      007303 22               [24] 1424 	ret
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'register_code'
                                   1427 ;------------------------------------------------------------
                                   1428 ;code          Allocated with name '_register_code_code_10000_703'
                                   1429 ;------------------------------------------------------------
                                   1430 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1431 ;	-----------------------------------------
                                   1432 ;	 function register_code
                                   1433 ;	-----------------------------------------
      007304                       1434 _register_code:
      007304 E5 82            [12] 1435 	mov	a,dpl
      007306 90 08 33         [24] 1436 	mov	dptr,#_register_code_code_10000_703
      007309 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/action.c:932: if (code == KC_NO) {
      00730A E0               [24] 1439 	movx	a,@dptr
      00730B FF               [12] 1440 	mov	r7,a
      00730C 70 01            [24] 1441 	jnz	00123$
                                   1442 ;	quantum/action.c:933: return;
      00730E 22               [24] 1443 	ret
      00730F                       1444 00123$:
                                   1445 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      00730F BF 04 00         [24] 1446 	cjne	r7,#0x04,00186$
      007312                       1447 00186$:
      007312 40 12            [24] 1448 	jc	00119$
      007314 EF               [12] 1449 	mov	a,r7
      007315 24 5B            [12] 1450 	add	a,#0xff - 0xa4
      007317 40 0D            [24] 1451 	jc	00119$
                                   1452 ;	free result
                                   1453 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007319 8F 82            [24] 1454 	mov	dpl, r7
      00731B 12 7B 20         [24] 1455 	lcall	_add_owned_key
      00731E E5 82            [12] 1456 	mov	a, dpl
      007320 70 01            [24] 1457 	jnz	00104$
      007322 22               [24] 1458 	ret
      007323                       1459 00104$:
                                   1460 ;	quantum/action.c:987: send_keyboard_report();
      007323 02 7D C0         [24] 1461 	ljmp	_send_keyboard_report
      007326                       1462 00119$:
                                   1463 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007326 12 75 1A         [24] 1464 	lcall	_ak820_outline_0163
      007329 BF E0 00         [24] 1465 	cjne	r7,#0xe0,00190$
      00732C                       1466 00190$:
      00732C 40 1A            [24] 1467 	jc	00115$
      00732E EF               [12] 1468 	mov	a,r7
      00732F 24 18            [12] 1469 	add	a,#0xff - 0xe7
      007331 40 15            [24] 1470 	jc	00115$
                                   1471 ;	free result
                                   1472 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007333 74 07            [12] 1473 	mov	a,#0x07
      007335 5F               [12] 1474 	anl	a,r7
      007336 12 74 E2         [24] 1475 	lcall	_ak820_outline_0063
      007339 80 02            [24] 1476 	sjmp	00194$
      00733B                       1477 00193$:
      00733B 25 E0            [12] 1478 	add	a,acc
      00733D                       1479 00194$:
      00733D D5 F0 FB         [24] 1480 	djnz	b,00193$
      007340 F5 82            [12] 1481 	mov	dpl,a
      007342 12 7A 7C         [24] 1482 	lcall	_add_owned_mods
                                   1483 ;	quantum/action.c:990: send_keyboard_report();
      007345 02 7D C0         [24] 1484 	ljmp	_send_keyboard_report
      007348                       1485 00115$:
                                   1486 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007348 12 75 1A         [24] 1487 	lcall	_ak820_outline_0163
      00734B BF A5 00         [24] 1488 	cjne	r7,#0xa5,00195$
      00734E                       1489 00195$:
      00734E 40 05            [24] 1490 	jc	00113$
      007350 EF               [12] 1491 	mov	a,r7
      007351 24 58            [12] 1492 	add	a,#0xff - 0xa7
      007353 50 0D            [24] 1493 	jnc	00108$
                                   1494 ;	free result
      007355                       1495 00113$:
      007355 12 75 1A         [24] 1496 	lcall	_ak820_outline_0163
      007358 BF A8 00         [24] 1497 	cjne	r7,#0xa8,00198$
      00735B                       1498 00198$:
      00735B 40 13            [24] 1499 	jc	00125$
      00735D EF               [12] 1500 	mov	a,r7
      00735E 24 3D            [12] 1501 	add	a,#0xff - 0xc2
      007360 40 0E            [24] 1502 	jc	00125$
                                   1503 ;	free result
      007362                       1504 00108$:
                                   1505 ;	quantum/action.c:995: owned_usage_key(code, true);
      007362 12 75 1A         [24] 1506 	lcall	_ak820_outline_0163
      007365 90 0A 8E         [24] 1507 	mov	dptr,#_owned_usage_key_PARM_2
      007368 74 01            [12] 1508 	mov	a,#0x01
      00736A F0               [24] 1509 	movx	@dptr,a
      00736B 8F 82            [24] 1510 	mov	dpl, r7
                                   1511 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1512 ;	quantum/action.c:1005: }
      00736D 02 7C 6B         [24] 1513 	ljmp	_owned_usage_key
      007370                       1514 00125$:
      007370 22               [24] 1515 	ret
                                   1516 ;------------------------------------------------------------
                                   1517 ;Allocation info for local variables in function 'unregister_code'
                                   1518 ;------------------------------------------------------------
                                   1519 ;code          Allocated with name '_unregister_code_code_10000_717'
                                   1520 ;------------------------------------------------------------
                                   1521 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1522 ;	-----------------------------------------
                                   1523 ;	 function unregister_code
                                   1524 ;	-----------------------------------------
      007371                       1525 _unregister_code:
      007371 E5 82            [12] 1526 	mov	a,dpl
      007373 90 08 34         [24] 1527 	mov	dptr,#_unregister_code_code_10000_717
      007376 F0               [24] 1528 	movx	@dptr,a
                                   1529 ;	quantum/action.c:1012: if (code == KC_NO) {
      007377 E0               [24] 1530 	movx	a,@dptr
      007378 FF               [12] 1531 	mov	r7,a
      007379 70 01            [24] 1532 	jnz	00121$
                                   1533 ;	quantum/action.c:1013: return;
      00737B 22               [24] 1534 	ret
      00737C                       1535 00121$:
                                   1536 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      00737C BF 04 00         [24] 1537 	cjne	r7,#0x04,00184$
      00737F                       1538 00184$:
      00737F 40 12            [24] 1539 	jc	00117$
      007381 EF               [12] 1540 	mov	a,r7
      007382 24 5B            [12] 1541 	add	a,#0xff - 0xa4
      007384 40 0D            [24] 1542 	jc	00117$
                                   1543 ;	free result
                                   1544 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007386 8F 82            [24] 1545 	mov	dpl, r7
      007388 12 7B 9D         [24] 1546 	lcall	_del_owned_key
      00738B E5 82            [12] 1547 	mov	a, dpl
      00738D 70 01            [24] 1548 	jnz	00102$
      00738F 22               [24] 1549 	ret
      007390                       1550 00102$:
                                   1551 ;	quantum/action.c:1054: send_keyboard_report();
      007390 02 7D C0         [24] 1552 	ljmp	_send_keyboard_report
      007393                       1553 00117$:
                                   1554 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007393 12 75 20         [24] 1555 	lcall	_ak820_outline_0164
      007396 BF E0 00         [24] 1556 	cjne	r7,#0xe0,00188$
      007399                       1557 00188$:
      007399 40 1A            [24] 1558 	jc	00113$
      00739B EF               [12] 1559 	mov	a,r7
      00739C 24 18            [12] 1560 	add	a,#0xff - 0xe7
      00739E 40 15            [24] 1561 	jc	00113$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      0073A0 74 07            [12] 1564 	mov	a,#0x07
      0073A2 5F               [12] 1565 	anl	a,r7
      0073A3 12 74 E2         [24] 1566 	lcall	_ak820_outline_0063
      0073A6 80 02            [24] 1567 	sjmp	00192$
      0073A8                       1568 00191$:
      0073A8 25 E0            [12] 1569 	add	a,acc
      0073AA                       1570 00192$:
      0073AA D5 F0 FB         [24] 1571 	djnz	b,00191$
      0073AD F5 82            [12] 1572 	mov	dpl,a
      0073AF 12 7A 8C         [24] 1573 	lcall	_del_owned_mods
                                   1574 ;	quantum/action.c:1057: send_keyboard_report();
      0073B2 02 7D C0         [24] 1575 	ljmp	_send_keyboard_report
      0073B5                       1576 00113$:
                                   1577 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0073B5 12 75 20         [24] 1578 	lcall	_ak820_outline_0164
      0073B8 BF A5 00         [24] 1579 	cjne	r7,#0xa5,00193$
      0073BB                       1580 00193$:
      0073BB 40 05            [24] 1581 	jc	00111$
      0073BD EF               [12] 1582 	mov	a,r7
      0073BE 24 58            [12] 1583 	add	a,#0xff - 0xa7
      0073C0 50 0D            [24] 1584 	jnc	00106$
                                   1585 ;	free result
      0073C2                       1586 00111$:
      0073C2 12 75 20         [24] 1587 	lcall	_ak820_outline_0164
      0073C5 BF A8 00         [24] 1588 	cjne	r7,#0xa8,00196$
      0073C8                       1589 00196$:
      0073C8 40 12            [24] 1590 	jc	00123$
      0073CA EF               [12] 1591 	mov	a,r7
      0073CB 24 3D            [12] 1592 	add	a,#0xff - 0xc2
      0073CD 40 0D            [24] 1593 	jc	00123$
                                   1594 ;	free result
      0073CF                       1595 00106$:
                                   1596 ;	quantum/action.c:1062: owned_usage_key(code, false);
      0073CF 12 75 20         [24] 1597 	lcall	_ak820_outline_0164
      0073D2 90 0A 8E         [24] 1598 	mov	dptr,#_owned_usage_key_PARM_2
      0073D5 E4               [12] 1599 	clr	a
      0073D6 F0               [24] 1600 	movx	@dptr,a
      0073D7 8F 82            [24] 1601 	mov	dpl, r7
                                   1602 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1603 ;	quantum/action.c:1072: }
      0073D9 02 7C 6B         [24] 1604 	ljmp	_owned_usage_key
      0073DC                       1605 00123$:
      0073DC 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'tap_code_delay'
                                   1609 ;------------------------------------------------------------
                                   1610 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1611 ;code          Allocated with name '_tap_code_delay_code_10000_730'
                                   1612 ;i             Allocated with name '_tap_code_delay_i_20000_732'
                                   1613 ;i             Allocated with name '_tap_code_delay_i_50000_735'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function tap_code_delay
                                   1618 ;	-----------------------------------------
      0073DD                       1619 _tap_code_delay:
      0073DD E5 82            [12] 1620 	mov	a,dpl
      0073DF 90 08 37         [24] 1621 	mov	dptr,#_tap_code_delay_code_10000_730
      0073E2 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:1080: register_code(code);
      0073E3 E0               [24] 1624 	movx	a,@dptr
      0073E4 FF               [12] 1625 	mov	r7,a
      0073E5 F5 82            [12] 1626 	mov	dpl,a
      0073E7 C0 07            [24] 1627 	push	ar7
      0073E9 12 73 04         [24] 1628 	lcall	_register_code
      0073EC D0 07            [24] 1629 	pop	ar7
                                   1630 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0073EE 90 08 35         [24] 1631 	mov	dptr,#_tap_code_delay_PARM_2
      0073F1 12 38 71         [24] 1632 	lcall	_ak820_outline_0093
      0073F4                       1633 00110$:
      0073F4 ED               [12] 1634 	mov	a,r5
      0073F5 4E               [12] 1635 	orl	a,r6
      0073F6 60 0D            [24] 1636 	jz	00105$
                                   1637 ;	quantum/action.c:1082: wait_ms(1);
      0073F8 90 00 01         [24] 1638 	mov	dptr,#0x0001
      0073FB 12 57 61         [24] 1639 	lcall	_mDelaymS
                                   1640 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0073FE 1D               [12] 1641 	dec	r5
      0073FF BD FF 01         [24] 1642 	cjne	r5,#0xff,00141$
      007402 1E               [12] 1643 	dec	r6
      007403                       1644 00141$:
      007403 80 EF            [24] 1645 	sjmp	00110$
      007405                       1646 00105$:
                                   1647 ;	quantum/action.c:1084: unregister_code(code);
      007405 8F 82            [24] 1648 	mov	dpl, r7
                                   1649 ;	quantum/action.c:1085: }
      007407 02 73 71         [24] 1650 	ljmp	_unregister_code
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'tap_code'
                                   1653 ;------------------------------------------------------------
                                   1654 ;code          Allocated with name '_tap_code_code_10000_737'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function tap_code
                                   1659 ;	-----------------------------------------
      00740A                       1660 _tap_code:
      00740A E5 82            [12] 1661 	mov	a,dpl
      00740C 90 08 38         [24] 1662 	mov	dptr,#_tap_code_code_10000_737
      00740F F0               [24] 1663 	movx	@dptr,a
                                   1664 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007410 E0               [24] 1665 	movx	a,@dptr
      007411 FF               [12] 1666 	mov	r7,a
      007412 BF 39 04         [24] 1667 	cjne	r7,#0x39,00103$
      007415 7E 50            [12] 1668 	mov	r6,#0x50
      007417 80 02            [24] 1669 	sjmp	00104$
      007419                       1670 00103$:
      007419 7E 00            [12] 1671 	mov	r6,#0x00
      00741B                       1672 00104$:
      00741B 90 08 35         [24] 1673 	mov	dptr,#_tap_code_delay_PARM_2
      00741E EE               [12] 1674 	mov	a,r6
      00741F 12 38 97         [24] 1675 	lcall	_ak820_outline_0122
      007422 8F 82            [24] 1676 	mov	dpl, r7
                                   1677 ;	quantum/action.c:1093: }
      007424 02 73 DD         [24] 1678 	ljmp	_tap_code_delay
                                   1679 ;------------------------------------------------------------
                                   1680 ;Allocation info for local variables in function 'register_mods'
                                   1681 ;------------------------------------------------------------
                                   1682 ;mods          Allocated with name '_register_mods_mods_10000_739'
                                   1683 ;------------------------------------------------------------
                                   1684 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1685 ;	-----------------------------------------
                                   1686 ;	 function register_mods
                                   1687 ;	-----------------------------------------
      007427                       1688 _register_mods:
      007427 E5 82            [12] 1689 	mov	a,dpl
      007429 90 08 39         [24] 1690 	mov	dptr,#_register_mods_mods_10000_739
      00742C F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action.c:1100: if (mods) {
      00742D E0               [24] 1693 	movx	a,@dptr
      00742E FF               [12] 1694 	mov	r7,a
      00742F E0               [24] 1695 	movx	a,@dptr
      007430 60 08            [24] 1696 	jz	00103$
                                   1697 ;	quantum/action.c:1101: add_owned_mods(mods);
      007432 8F 82            [24] 1698 	mov	dpl, r7
      007434 12 7A 7C         [24] 1699 	lcall	_add_owned_mods
                                   1700 ;	quantum/action.c:1102: send_keyboard_report();
                                   1701 ;	quantum/action.c:1104: }
      007437 02 7D C0         [24] 1702 	ljmp	_send_keyboard_report
      00743A                       1703 00103$:
      00743A 22               [24] 1704 	ret
                                   1705 ;------------------------------------------------------------
                                   1706 ;Allocation info for local variables in function 'unregister_mods'
                                   1707 ;------------------------------------------------------------
                                   1708 ;mods          Allocated with name '_unregister_mods_mods_10000_743'
                                   1709 ;------------------------------------------------------------
                                   1710 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1711 ;	-----------------------------------------
                                   1712 ;	 function unregister_mods
                                   1713 ;	-----------------------------------------
      00743B                       1714 _unregister_mods:
      00743B E5 82            [12] 1715 	mov	a,dpl
      00743D 90 08 3A         [24] 1716 	mov	dptr,#_unregister_mods_mods_10000_743
      007440 F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	quantum/action.c:1111: if (mods) {
      007441 E0               [24] 1719 	movx	a,@dptr
      007442 FF               [12] 1720 	mov	r7,a
      007443 E0               [24] 1721 	movx	a,@dptr
      007444 60 08            [24] 1722 	jz	00103$
                                   1723 ;	quantum/action.c:1112: del_owned_mods(mods);
      007446 8F 82            [24] 1724 	mov	dpl, r7
      007448 12 7A 8C         [24] 1725 	lcall	_del_owned_mods
                                   1726 ;	quantum/action.c:1113: send_keyboard_report();
                                   1727 ;	quantum/action.c:1115: }
      00744B 02 7D C0         [24] 1728 	ljmp	_send_keyboard_report
      00744E                       1729 00103$:
      00744E 22               [24] 1730 	ret
                                   1731 ;------------------------------------------------------------
                                   1732 ;Allocation info for local variables in function 'register_weak_mods'
                                   1733 ;------------------------------------------------------------
                                   1734 ;mods          Allocated with name '_register_weak_mods_mods_10000_747'
                                   1735 ;------------------------------------------------------------
                                   1736 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1737 ;	-----------------------------------------
                                   1738 ;	 function register_weak_mods
                                   1739 ;	-----------------------------------------
      00744F                       1740 _register_weak_mods:
      00744F E5 82            [12] 1741 	mov	a,dpl
      007451 90 08 3B         [24] 1742 	mov	dptr,#_register_weak_mods_mods_10000_747
      007454 F0               [24] 1743 	movx	@dptr,a
                                   1744 ;	quantum/action.c:1122: if (mods) {
      007455 E0               [24] 1745 	movx	a,@dptr
      007456 FF               [12] 1746 	mov	r7,a
      007457 E0               [24] 1747 	movx	a,@dptr
      007458 60 08            [24] 1748 	jz	00103$
                                   1749 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      00745A 8F 82            [24] 1750 	mov	dpl, r7
      00745C 12 7A 9B         [24] 1751 	lcall	_add_owned_weak_mods
                                   1752 ;	quantum/action.c:1124: send_keyboard_report();
                                   1753 ;	quantum/action.c:1126: }
      00745F 02 7D C0         [24] 1754 	ljmp	_send_keyboard_report
      007462                       1755 00103$:
      007462 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1759 ;------------------------------------------------------------
                                   1760 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_751'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function unregister_weak_mods
                                   1765 ;	-----------------------------------------
      007463                       1766 _unregister_weak_mods:
      007463 E5 82            [12] 1767 	mov	a,dpl
      007465 90 08 3C         [24] 1768 	mov	dptr,#_unregister_weak_mods_mods_10000_751
      007468 F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action.c:1133: if (mods) {
      007469 E0               [24] 1771 	movx	a,@dptr
      00746A FF               [12] 1772 	mov	r7,a
      00746B E0               [24] 1773 	movx	a,@dptr
      00746C 60 08            [24] 1774 	jz	00103$
                                   1775 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      00746E 8F 82            [24] 1776 	mov	dpl, r7
      007470 12 7A AB         [24] 1777 	lcall	_del_owned_weak_mods
                                   1778 ;	quantum/action.c:1135: send_keyboard_report();
                                   1779 ;	quantum/action.c:1137: }
      007473 02 7D C0         [24] 1780 	ljmp	_send_keyboard_report
      007476                       1781 00103$:
      007476 22               [24] 1782 	ret
                                   1783 ;------------------------------------------------------------
                                   1784 ;Allocation info for local variables in function 'clear_keyboard'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function clear_keyboard
                                   1789 ;	-----------------------------------------
      007477                       1790 _clear_keyboard:
                                   1791 ;	quantum/action.c:1144: clear_mods();
      007477 12 7E 3A         [24] 1792 	lcall	_clear_mods
                                   1793 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1794 ;	quantum/action.c:1146: }
      00747A 02 74 7D         [24] 1795 	ljmp	_clear_keyboard_but_mods
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function clear_keyboard_but_mods
                                   1802 ;	-----------------------------------------
      00747D                       1803 _clear_keyboard_but_mods:
                                   1804 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00747D 90 0D BF         [24] 1805 	mov	dptr,#_actual_keyboard_report
      007480 75 F0 00         [24] 1806 	mov	b, #0x00
      007483 12 6D EF         [24] 1807 	lcall	_clear_keys_from_report
                                   1808 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1809 ;	quantum/action.c:1155: }
      007486 02 74 89         [24] 1810 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1811 ;------------------------------------------------------------
                                   1812 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1813 ;------------------------------------------------------------
                                   1814 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1815 ;	-----------------------------------------
                                   1816 ;	 function clear_keyboard_but_mods_and_keys
                                   1817 ;	-----------------------------------------
      007489                       1818 _clear_keyboard_but_mods_and_keys:
                                   1819 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007489 12 46 CE         [24] 1820 	lcall	_ak820_tapping_cancel
                                   1821 ;	quantum/action.c:1174: ak820_combo_cancel();
      00748C 12 35 70         [24] 1822 	lcall	_ak820_combo_cancel
                                   1823 ;	quantum/action.c:1177: repeat_key_cancel();
      00748F 12 9F 1A         [24] 1824 	lcall	_repeat_key_cancel
                                   1825 ;	quantum/action.c:1179: clear_owned_mods();
      007492 12 7A BB         [24] 1826 	lcall	_clear_owned_mods
                                   1827 ;	quantum/action.c:1180: clear_owned_keys();
      007495 12 7A F3         [24] 1828 	lcall	_clear_owned_keys
                                   1829 ;	quantum/action.c:1181: clear_owned_usages();
      007498 12 7C 33         [24] 1830 	lcall	_clear_owned_usages
                                   1831 ;	quantum/action.c:1182: layer_hold_clear();
      00749B 12 76 67         [24] 1832 	lcall	_layer_hold_clear
                                   1833 ;	quantum/action.c:1184: clear_macro_tri_layer();
      00749E 12 99 DE         [24] 1834 	lcall	_clear_macro_tri_layer
                                   1835 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0074A1 90 0D BF         [24] 1836 	mov	dptr,#_actual_keyboard_report
      0074A4 75 F0 00         [24] 1837 	mov	b, #0x00
      0074A7 12 6D EF         [24] 1838 	lcall	_clear_keys_from_report
                                   1839 ;	quantum/action.c:1189: host_system_send(0);
      0074AA 90 00 00         [24] 1840 	mov	dptr,#0x0000
      0074AD 12 6B B3         [24] 1841 	lcall	_host_system_send
                                   1842 ;	quantum/action.c:1190: host_consumer_send(0);
      0074B0 90 00 00         [24] 1843 	mov	dptr,#0x0000
      0074B3 12 6B E3         [24] 1844 	lcall	_host_consumer_send
                                   1845 ;	quantum/action.c:1192: clear_weak_mods();
      0074B6 12 7E 6F         [24] 1846 	lcall	_clear_weak_mods
                                   1847 ;	quantum/action.c:1193: send_keyboard_report();
                                   1848 ;	quantum/action.c:1201: }
      0074B9 02 7D C0         [24] 1849 	ljmp	_send_keyboard_report
                                   1850 ;------------------------------------------------------------
                                   1851 ;Allocation info for local variables in function 'is_tap_record'
                                   1852 ;------------------------------------------------------------
                                   1853 ;record        Allocated with name '_is_tap_record_record_10000_767'
                                   1854 ;action        Allocated with name '_is_tap_record_action_10001_771'
                                   1855 ;------------------------------------------------------------
                                   1856 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1857 ;	-----------------------------------------
                                   1858 	.area CSEG    (CODE)
                                   1859 	.area CONST   (CODE)
                                   1860 	.area XINIT   (CODE)
      00BE99                       1861 __xinit__disable_action_cache:
      00BE99 00                    1862 	.db #0x00	;  0
                                   1863 	.area CABS    (ABS,CODE)
                                   1864 
                                   1865 ; Experimental exact instruction outlining.
                                   1866 	.globl _ak820_outline_0001
                                   1867 	.globl _ak820_outline_0005
                                   1868 	.globl _ak820_outline_0007
                                   1869 	.globl _ak820_outline_0008
                                   1870 	.globl _ak820_outline_0011
                                   1871 	.globl _ak820_outline_0012
                                   1872 	.globl _ak820_outline_0013
                                   1873 	.globl _ak820_outline_0015
                                   1874 	.globl _ak820_outline_0019
                                   1875 	.globl _ak820_outline_0020
                                   1876 	.globl _ak820_outline_0035
                                   1877 	.globl _ak820_outline_0041
                                   1878 	.globl _ak820_outline_0046
                                   1879 	.globl _ak820_outline_0050
                                   1880 	.globl _ak820_outline_0063
                                   1881 	.globl _ak820_outline_0070
                                   1882 	.globl _ak820_outline_0071
                                   1883 	.globl _ak820_outline_0076
                                   1884 	.globl _ak820_outline_0086
                                   1885 	.globl _ak820_outline_0090
                                   1886 	.globl _ak820_outline_0093
                                   1887 	.globl _ak820_outline_0107
                                   1888 	.globl _ak820_outline_0112
                                   1889 	.globl _ak820_outline_0113
                                   1890 	.globl _ak820_outline_0114
                                   1891 	.globl _ak820_outline_0120
                                   1892 	.globl _ak820_outline_0121
                                   1893 	.globl _ak820_outline_0122
                                   1894 	.globl _ak820_outline_0128
                                   1895 	.globl _ak820_outline_0138
                                   1896 	.globl _ak820_outline_0145
                                   1897 	.globl _ak820_outline_0155
                                   1898 	.globl _ak820_outline_0163
                                   1899 	.globl _ak820_outline_0164
                                   1900 	.globl _ak820_outline_0166
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0012
      0074BC                       1904 _ak820_outline_0012:
      0074BC 2D               [12] 1905 	add	a,r5
      0074BD FA               [12] 1906 	mov	r2,a
      0074BE E4               [12] 1907 	clr	a
      0074BF 3E               [12] 1908 	addc	a,r6
      0074C0 FB               [12] 1909 	mov	r3,a
      0074C1 8F 04            [24] 1910 	mov	ar4,r7
      0074C3 8A 82            [24] 1911 	mov	dpl,r2
      0074C5 8B 83            [24] 1912 	mov	dph,r3
      0074C7 8C F0            [24] 1913 	mov	b,r4
      0074C9 22               [24] 1914 	ret
                                   1915 
                                   1916 	.area CSEG (CODE)
                                   1917 ; function ak820_outline_0019
      0074CA                       1918 _ak820_outline_0019:
      0074CA 8E 82            [24] 1919 	mov	dpl,r6
      0074CC 8F 83            [24] 1920 	mov	dph,r7
      0074CE A3               [24] 1921 	inc	dptr
      0074CF E0               [24] 1922 	movx	a,@dptr
      0074D0 FC               [12] 1923 	mov	r4,a
      0074D1 7D 00            [12] 1924 	mov	r5,#0x00
      0074D3 8E 82            [24] 1925 	mov	dpl,r6
      0074D5 8F 83            [24] 1926 	mov	dph,r7
      0074D7 E0               [24] 1927 	movx	a,@dptr
      0074D8 22               [24] 1928 	ret
                                   1929 
                                   1930 	.area CSEG (CODE)
                                   1931 ; function ak820_outline_0041
      0074D9                       1932 _ak820_outline_0041:
      0074D9 90 08 2E         [24] 1933 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074DC E0               [24] 1934 	movx	a,@dptr
      0074DD 54 1F            [12] 1935 	anl	a,#0x1f
      0074DF F5 82            [12] 1936 	mov	dpl,a
      0074E1 22               [24] 1937 	ret
                                   1938 
                                   1939 	.area CSEG (CODE)
                                   1940 ; function ak820_outline_0063
      0074E2                       1941 _ak820_outline_0063:
      0074E2 F5 F0            [12] 1942 	mov	b,a
      0074E4 05 F0            [12] 1943 	inc	b
      0074E6 74 01            [12] 1944 	mov	a,#0x01
      0074E8 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0070
      0074E9                       1949 _ak820_outline_0070:
      0074E9 90 0D 9E         [24] 1950 	mov	dptr,#___memcpy_PARM_3
      0074EC 74 06            [12] 1951 	mov	a,#0x06
      0074EE F0               [24] 1952 	movx	@dptr,a
      0074EF E4               [12] 1953 	clr	a
      0074F0 A3               [24] 1954 	inc	dptr
      0074F1 F0               [24] 1955 	movx	@dptr,a
      0074F2 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0076
      0074F3                       1960 _ak820_outline_0076:
      0074F3 90 08 2D         [24] 1961 	mov	dptr,#_process_action_PARM_2
      0074F6 E0               [24] 1962 	movx	a,@dptr
      0074F7 F5 82            [12] 1963 	mov	dpl,a
      0074F9 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0086
      0074FA                       1968 _ak820_outline_0086:
      0074FA 90 08 2E         [24] 1969 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074FD E0               [24] 1970 	movx	a,@dptr
      0074FE 03               [12] 1971 	rr	a
      0074FF 03               [12] 1972 	rr	a
      007500 54 03            [12] 1973 	anl	a,#0x03
      007502 22               [24] 1974 	ret
                                   1975 
                                   1976 	.area CSEG (CODE)
                                   1977 ; function ak820_outline_0107
      007503                       1978 _ak820_outline_0107:
      007503 90 08 2E         [24] 1979 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007506 E0               [24] 1980 	movx	a,@dptr
      007507 54 0F            [12] 1981 	anl	a,#0x0f
      007509 22               [24] 1982 	ret
                                   1983 
                                   1984 	.area CSEG (CODE)
                                   1985 ; function ak820_outline_0128
      00750A                       1986 _ak820_outline_0128:
      00750A 90 08 2D         [24] 1987 	mov	dptr,#_process_action_PARM_2
      00750D E0               [24] 1988 	movx	a,@dptr
      00750E FE               [12] 1989 	mov	r6,a
      00750F A3               [24] 1990 	inc	dptr
      007510 E0               [24] 1991 	movx	a,@dptr
      007511 54 03            [12] 1992 	anl	a,#0x03
      007513 FF               [12] 1993 	mov	r7,a
      007514 22               [24] 1994 	ret
                                   1995 
                                   1996 	.area CSEG (CODE)
                                   1997 ; function ak820_outline_0155
      007515                       1998 _ak820_outline_0155:
      007515 90 08 2D         [24] 1999 	mov	dptr,#_process_action_PARM_2
      007518 E0               [24] 2000 	movx	a,@dptr
      007519 22               [24] 2001 	ret
                                   2002 
                                   2003 	.area CSEG (CODE)
                                   2004 ; function ak820_outline_0163
      00751A                       2005 _ak820_outline_0163:
      00751A 90 08 33         [24] 2006 	mov	dptr,#_register_code_code_10000_703
      00751D E0               [24] 2007 	movx	a,@dptr
      00751E FF               [12] 2008 	mov	r7,a
      00751F 22               [24] 2009 	ret
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0164
      007520                       2013 _ak820_outline_0164:
      007520 90 08 34         [24] 2014 	mov	dptr,#_unregister_code_code_10000_717
      007523 E0               [24] 2015 	movx	a,@dptr
      007524 FF               [12] 2016 	mov	r7,a
      007525 22               [24] 2017 	ret
