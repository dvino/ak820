                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      000847                        555 _KEYCODE2CONSUMER_key_10000_117:
      000847                        556 	.ds 1
      000848                        557 _add_key_byte_PARM_2:
      000848                        558 	.ds 1
      000849                        559 _add_key_byte_report_arg_10000_144:
      000849                        560 	.ds 3
      00084C                        561 _add_key_byte_empty_10000_145:
      00084C                        562 	.ds 1
      00084D                        563 _del_key_byte_PARM_2:
      00084D                        564 	.ds 1
      00084E                        565 _del_key_byte_report_arg_10000_156:
      00084E                        566 	.ds 3
      000851                        567 _add_key_bit_PARM_2:
      000851                        568 	.ds 1
      000852                        569 _add_key_bit_report_arg_10000_162:
      000852                        570 	.ds 3
      000855                        571 _del_key_bit_PARM_2:
      000855                        572 	.ds 1
      000856                        573 _del_key_bit_report_arg_10000_167:
      000856                        574 	.ds 3
      000859                        575 _add_key_to_report_PARM_2:
      000859                        576 	.ds 1
      00085A                        577 _add_key_to_report_report_arg_10000_172:
      00085A                        578 	.ds 3
      00085D                        579 _del_key_from_report_PARM_2:
      00085D                        580 	.ds 1
      00085E                        581 _del_key_from_report_report_arg_10000_176:
      00085E                        582 	.ds 3
      000861                        583 _clear_keys_from_report_report_arg_10000_180:
      000861                        584 	.ds 3
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      007121                        636 _KEYCODE2CONSUMER:
      007121 E5 82            [12]  637 	mov	a,dpl
      007123 90 08 47         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      007126 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      007127 E0               [24]  641 	movx	a,@dptr
      007128 FF               [12]  642 	mov	r7,a
      007129 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      00712C                        644 00113$:
      00712C 40 05            [24]  645 	jc	00101$
      00712E EF               [12]  646 	mov	a,r7
      00712F 24 3D            [12]  647 	add	a,#0xff - 0xc2
      007131 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      007133                        650 00101$:
      007133 90 00 00         [24]  651 	mov	dptr,#0x0000
      007136 22               [24]  652 	ret
      007137                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      007137 EF               [12]  655 	mov	a,r7
      007138 24 58            [12]  656 	add	a,#0x58
      00713A FF               [12]  657 	mov	r7,a
      00713B C2 D5            [12]  658 	clr	F0
      00713D 75 F0 02         [24]  659 	mov	b,#0x02
      007140 EF               [12]  660 	mov	a,r7
      007141 30 E7 04         [24]  661 	jnb	acc.7,00116$
      007144 B2 D5            [12]  662 	cpl	F0
      007146 F4               [12]  663 	cpl	a
      007147 04               [12]  664 	inc	a
      007148                        665 00116$:
      007148 A4               [48]  666 	mul	ab
      007149 30 D5 03         [24]  667 	jnb	F0,00117$
      00714C 12 73 4C         [24]  668 	lcall	_ak820_outline_0132
      00714F                        669 00117$:
      00714F 24 A5            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      007151 F5 82            [12]  671 	mov	dpl,a
      007153 74 BE            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      007155 12 5A 7B         [24]  673 	lcall	_ak820_outline_0112
      007158 FE               [12]  674 	mov	r6,a
      007159 A3               [24]  675 	inc	dptr
      00715A E4               [12]  676 	clr	a
      00715B 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:54: }
      00715C 8E 82            [24]  679 	mov	dpl,r6
      00715E F5 83            [12]  680 	mov	dph,a
      007160 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      007161                        695 _add_key_byte:
      007161 12 46 62         [24]  696 	lcall	_ak820_outline_0036
      007164 90 08 49         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      007167 12 38 1F         [24]  698 	lcall	_ak820_outline_0016
                                    699 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00716A 90 08 49         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      00716D 12 38 41         [24]  701 	lcall	_ak820_outline_0053
                                    702 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      007170 90 08 4C         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      007173 74 FF            [12]  704 	mov	a,#0xff
      007175 F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:209: }
      007176 7D 00            [12]  707 	mov	r5,#0x00
      007178                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007178 C3               [12]  710 	clr	c
      007179 ED               [12]  711 	mov	a,r5
      00717A 64 80            [12]  712 	xrl	a,#0x80
      00717C 94 86            [12]  713 	subb	a,#0x86
      00717E 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      007180 12 73 57         [24]  716 	lcall	_ak820_outline_0148
      007183 F5 82            [12]  717 	mov	dpl,a
      007185 E4               [12]  718 	clr	a
      007186 3C               [12]  719 	addc	a, r4
      007187 F5 83            [12]  720 	mov	dph,a
      007189 E0               [24]  721 	movx	a,@dptr
      00718A FC               [12]  722 	mov	r4,a
      00718B 90 08 48         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      00718E E0               [24]  724 	movx	a,@dptr
      00718F FB               [12]  725 	mov	r3,a
      007190 EC               [12]  726 	mov	a,r4
      007191 B5 03 02         [24]  727 	cjne	a,ar3,00167$
      007194 80 13            [24]  728 	sjmp	00106$
      007196                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      007196 90 08 4C         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      007199 E0               [24]  732 	movx	a,@dptr
      00719A FB               [12]  733 	mov	r3,a
      00719B BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      00719E EC               [12]  735 	mov	a,r4
      00719F 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:200: empty = i;
      0071A1 90 08 4C         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      0071A4 ED               [12]  739 	mov	a,r5
      0071A5 F0               [24]  740 	movx	@dptr,a
      0071A6                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      0071A6 0D               [12]  743 	inc	r5
      0071A7 80 CF            [24]  744 	sjmp	00112$
      0071A9                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      0071A9 BD 06 1D         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      0071AC 90 08 4C         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      0071AF E0               [24]  750 	movx	a,@dptr
      0071B0 FD               [12]  751 	mov	r5,a
      0071B1 BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      0071B4 22               [24]  753 	ret
      0071B5                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      0071B5 74 02            [12]  756 	mov	a,#0x02
      0071B7 12 46 A9         [24]  757 	lcall	_ak820_outline_0140
      0071BA ED               [12]  758 	mov	a,r5
      0071BB 2E               [12]  759 	add	a, r6
      0071BC FD               [12]  760 	mov	r5,a
      0071BD E4               [12]  761 	clr	a
      0071BE 3F               [12]  762 	addc	a, r7
      0071BF FC               [12]  763 	mov	r4,a
      0071C0 90 08 48         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      0071C3 E0               [24]  765 	movx	a,@dptr
      0071C4 8D 82            [24]  766 	mov	dpl,r5
      0071C6 8C 83            [24]  767 	mov	dph,r4
      0071C8 F0               [24]  768 	movx	@dptr,a
      0071C9                        769 00114$:
                                    770 ;	tmk_core/protocol/report.c:209: }
      0071C9 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'del_key_byte'
                                    774 ;------------------------------------------------------------
                                    775 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    776 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    777 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    778 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    779 ;------------------------------------------------------------
                                    780 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function del_key_byte
                                    783 ;	-----------------------------------------
      0071CA                        784 _del_key_byte:
      0071CA 12 46 62         [24]  785 	lcall	_ak820_outline_0036
      0071CD 90 08 4E         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0071D0 12 38 1F         [24]  787 	lcall	_ak820_outline_0016
                                    788 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0071D3 90 08 4E         [24]  789 	mov	dptr,#_del_key_byte_report_arg_10000_156
      0071D6 12 38 41         [24]  790 	lcall	_ak820_outline_0053
                                    791 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0071D9 7D 00            [12]  792 	mov	r5,#0x00
      0071DB                        793 00105$:
      0071DB BD 06 00         [24]  794 	cjne	r5,#0x06,00131$
      0071DE                        795 00131$:
      0071DE 50 1B            [24]  796 	jnc	00107$
                                    797 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      0071E0 12 73 57         [24]  798 	lcall	_ak820_outline_0148
      0071E3 FB               [12]  799 	mov	r3,a
      0071E4 E4               [12]  800 	clr	a
      0071E5 3C               [12]  801 	addc	a, r4
      0071E6 FC               [12]  802 	mov	r4,a
      0071E7 12 4B E8         [24]  803 	lcall	_ak820_outline_0065
      0071EA 90 08 4D         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      0071ED E0               [24]  805 	movx	a,@dptr
      0071EE F9               [12]  806 	mov	r1,a
      0071EF EA               [12]  807 	mov	a,r2
      0071F0 B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      0071F3 12 33 FC         [24]  810 	lcall	_ak820_outline_0125
      0071F6 E4               [12]  811 	clr	a
      0071F7 F0               [24]  812 	movx	@dptr,a
      0071F8                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0071F8 0D               [12]  815 	inc	r5
      0071F9 80 E0            [24]  816 	sjmp	00105$
      0071FB                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:249: }
      0071FB 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      0071FC                        831 _add_key_bit:
      0071FC 12 46 62         [24]  832 	lcall	_ak820_outline_0036
      0071FF 90 08 52         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      007202 12 38 1F         [24]  834 	lcall	_ak820_outline_0016
                                    835 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007205 90 08 52         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_162
      007208 12 38 41         [24]  837 	lcall	_ak820_outline_0053
                                    838 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00720B 90 08 51         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      00720E E0               [24]  840 	movx	a,@dptr
      00720F FD               [12]  841 	mov	r5,a
      007210 12 5A B1         [24]  842 	lcall	_ak820_outline_0189
      007213 FC               [12]  843 	mov	r4,a
      007214 BC 1E 00         [24]  844 	cjne	r4,#0x1e,00112$
      007217                        845 00112$:
      007217 50 16            [24]  846 	jnc	00103$
                                    847 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      007219 12 73 27         [24]  848 	lcall	_ak820_outline_0035
      00721C 80 02            [24]  849 	sjmp	00115$
      00721E                        850 00114$:
      00721E 25 E0            [12]  851 	add	a,acc
      007220                        852 00115$:
      007220 D5 F0 FB         [24]  853 	djnz	b,00114$
      007223 FF               [12]  854 	mov	r7,a
      007224 12 46 D0         [24]  855 	lcall	_ak820_outline_0185
      007227 E0               [24]  856 	movx	a,@dptr
      007228 42 07            [12]  857 	orl	ar7,a
      00722A 12 46 D0         [24]  858 	lcall	_ak820_outline_0185
      00722D EF               [12]  859 	mov	a,r7
      00722E F0               [24]  860 	movx	@dptr,a
      00722F                        861 00103$:
                                    862 ;	tmk_core/protocol/report.c:263: }
      00722F 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'del_key_bit'
                                    866 ;------------------------------------------------------------
                                    867 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    868 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    869 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    870 ;------------------------------------------------------------
                                    871 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function del_key_bit
                                    874 ;	-----------------------------------------
      007230                        875 _del_key_bit:
      007230 12 46 62         [24]  876 	lcall	_ak820_outline_0036
      007233 90 08 56         [24]  877 	mov	dptr,#_del_key_bit_report_arg_10000_167
      007236 12 38 1F         [24]  878 	lcall	_ak820_outline_0016
                                    879 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007239 90 08 56         [24]  880 	mov	dptr,#_del_key_bit_report_arg_10000_167
      00723C 12 38 41         [24]  881 	lcall	_ak820_outline_0053
                                    882 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      00723F 90 08 55         [24]  883 	mov	dptr,#_del_key_bit_PARM_2
      007242 E0               [24]  884 	movx	a,@dptr
      007243 FD               [12]  885 	mov	r5,a
      007244 12 5A B1         [24]  886 	lcall	_ak820_outline_0189
      007247 FC               [12]  887 	mov	r4,a
      007248 BC 1E 00         [24]  888 	cjne	r4,#0x1e,00112$
      00724B                        889 00112$:
      00724B 50 17            [24]  890 	jnc	00103$
                                    891 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      00724D 12 73 27         [24]  892 	lcall	_ak820_outline_0035
      007250 80 02            [24]  893 	sjmp	00115$
      007252                        894 00114$:
      007252 25 E0            [12]  895 	add	a,acc
      007254                        896 00115$:
      007254 D5 F0 FB         [24]  897 	djnz	b,00114$
      007257 F4               [12]  898 	cpl	a
      007258 FF               [12]  899 	mov	r7,a
      007259 12 46 D0         [24]  900 	lcall	_ak820_outline_0185
      00725C E0               [24]  901 	movx	a,@dptr
      00725D 52 07            [12]  902 	anl	ar7,a
      00725F 12 46 D0         [24]  903 	lcall	_ak820_outline_0185
      007262 EF               [12]  904 	mov	a,r7
      007263 F0               [24]  905 	movx	@dptr,a
      007264                        906 00103$:
                                    907 ;	tmk_core/protocol/report.c:276: }
      007264 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'add_key_to_report'
                                    911 ;------------------------------------------------------------
                                    912 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    913 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    914 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    915 ;------------------------------------------------------------
                                    916 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function add_key_to_report
                                    919 ;	-----------------------------------------
      007265                        920 _add_key_to_report:
      007265 12 46 62         [24]  921 	lcall	_ak820_outline_0036
      007268 90 08 5A         [24]  922 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      00726B 12 38 1F         [24]  923 	lcall	_ak820_outline_0016
                                    924 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00726E 90 08 5A         [24]  925 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      007271 12 38 41         [24]  926 	lcall	_ak820_outline_0053
                                    927 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      007274 90 0E 0F         [24]  928 	mov	dptr,#_keyboard_protocol
      007277 E0               [24]  929 	movx	a,@dptr
      007278 60 18            [24]  930 	jz	00102$
      00727A 90 0B 1B         [24]  931 	mov	dptr,#_keymap_config
      00727D E0               [24]  932 	movx	a,@dptr
      00727E 30 E7 11         [24]  933 	jnb	acc.7,00102$
                                    934 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      007281 12 73 61         [24]  935 	lcall	_ak820_outline_0153
      007284 90 08 59         [24]  936 	mov	dptr,#_add_key_to_report_PARM_2
      007287 E0               [24]  937 	movx	a,@dptr
      007288 90 08 51         [24]  938 	mov	dptr,#_add_key_bit_PARM_2
      00728B F0               [24]  939 	movx	@dptr,a
      00728C 12 73 45         [24]  940 	lcall	_ak820_outline_0097
                                    941 ;	tmk_core/protocol/report.c:288: return;
      00728F 02 71 FC         [24]  942 	ljmp	_add_key_bit
      007292                        943 00102$:
                                    944 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      007292 7D 00            [12]  945 	mov	r5,#0x00
      007294 90 08 59         [24]  946 	mov	dptr,#_add_key_to_report_PARM_2
      007297 E0               [24]  947 	movx	a,@dptr
      007298 90 08 48         [24]  948 	mov	dptr,#_add_key_byte_PARM_2
      00729B F0               [24]  949 	movx	@dptr,a
      00729C 12 73 3E         [24]  950 	lcall	_ak820_outline_0051
                                    951 ;	tmk_core/protocol/report.c:292: }
      00729F 02 71 61         [24]  952 	ljmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      0072A2                        964 _del_key_from_report:
      0072A2 12 46 62         [24]  965 	lcall	_ak820_outline_0036
      0072A5 90 08 5E         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      0072A8 12 38 1F         [24]  967 	lcall	_ak820_outline_0016
                                    968 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072AB 90 08 5E         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      0072AE 12 38 41         [24]  970 	lcall	_ak820_outline_0053
                                    971 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      0072B1 90 0E 0F         [24]  972 	mov	dptr,#_keyboard_protocol
      0072B4 E0               [24]  973 	movx	a,@dptr
      0072B5 60 18            [24]  974 	jz	00102$
      0072B7 90 0B 1B         [24]  975 	mov	dptr,#_keymap_config
      0072BA E0               [24]  976 	movx	a,@dptr
      0072BB 30 E7 11         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      0072BE 12 73 61         [24]  979 	lcall	_ak820_outline_0153
      0072C1 90 08 5D         [24]  980 	mov	dptr,#_del_key_from_report_PARM_2
      0072C4 E0               [24]  981 	movx	a,@dptr
      0072C5 90 08 55         [24]  982 	mov	dptr,#_del_key_bit_PARM_2
      0072C8 F0               [24]  983 	movx	@dptr,a
      0072C9 12 73 45         [24]  984 	lcall	_ak820_outline_0097
                                    985 ;	tmk_core/protocol/report.c:303: return;
      0072CC 02 72 30         [24]  986 	ljmp	_del_key_bit
      0072CF                        987 00102$:
                                    988 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      0072CF 7D 00            [12]  989 	mov	r5,#0x00
      0072D1 90 08 5D         [24]  990 	mov	dptr,#_del_key_from_report_PARM_2
      0072D4 E0               [24]  991 	movx	a,@dptr
      0072D5 90 08 4D         [24]  992 	mov	dptr,#_del_key_byte_PARM_2
      0072D8 F0               [24]  993 	movx	@dptr,a
      0072D9 12 73 3E         [24]  994 	lcall	_ak820_outline_0051
                                    995 ;	tmk_core/protocol/report.c:307: }
      0072DC 02 71 CA         [24]  996 	ljmp	_del_key_byte
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    999 ;------------------------------------------------------------
                                   1000 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                   1001 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function clear_keys_from_report
                                   1006 ;	-----------------------------------------
      0072DF                       1007 _clear_keys_from_report:
      0072DF 12 46 62         [24] 1008 	lcall	_ak820_outline_0036
      0072E2 90 08 61         [24] 1009 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0072E5 12 38 1F         [24] 1010 	lcall	_ak820_outline_0016
                                   1011 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072E8 90 08 61         [24] 1012 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      0072EB 12 38 41         [24] 1013 	lcall	_ak820_outline_0053
                                   1014 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      0072EE 90 0E 0F         [24] 1015 	mov	dptr,#_keyboard_protocol
      0072F1 E0               [24] 1016 	movx	a,@dptr
      0072F2 60 1E            [24] 1017 	jz	00102$
      0072F4 90 0B 1B         [24] 1018 	mov	dptr,#_keymap_config
      0072F7 E0               [24] 1019 	movx	a,@dptr
      0072F8 30 E7 17         [24] 1020 	jnb	acc.7,00102$
                                   1021 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      0072FB 74 02            [12] 1022 	mov	a,#0x02
      0072FD 12 46 BF         [24] 1023 	lcall	_ak820_outline_0163
      007300 7B 00            [12] 1024 	mov	r3,#0x00
      007302 12 73 68         [24] 1025 	lcall	_ak820_outline_0181
      007305 74 1E            [12] 1026 	mov	a,#0x1e
      007307 F0               [24] 1027 	movx	@dptr,a
      007308 E4               [12] 1028 	clr	a
      007309 A3               [24] 1029 	inc	dptr
      00730A 12 38 76         [24] 1030 	lcall	_ak820_outline_0103
      00730D 8B F0            [24] 1031 	mov	b, r3
                                   1032 ;	tmk_core/protocol/report.c:319: return;
      00730F 02 BD 96         [24] 1033 	ljmp	_memset
      007312                       1034 00102$:
                                   1035 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      007312 74 02            [12] 1036 	mov	a,#0x02
      007314 12 46 A9         [24] 1037 	lcall	_ak820_outline_0140
      007317 7D 00            [12] 1038 	mov	r5,#0x00
      007319 12 73 68         [24] 1039 	lcall	_ak820_outline_0181
      00731C 74 06            [12] 1040 	mov	a,#0x06
      00731E 12 38 A1         [24] 1041 	lcall	_ak820_outline_0137
      007321 12 73 3E         [24] 1042 	lcall	_ak820_outline_0051
                                   1043 ;	tmk_core/protocol/report.c:323: }
      007324 02 BD 96         [24] 1044 	ljmp	_memset
                                   1045 	.area CSEG    (CODE)
                                   1046 	.area CONST   (CODE)
                                   1047 	.area CONST   (CODE)
      00BEA5                       1048 _KEYCODE2CONSUMER_usages_10000_118:
      00BEA5 E2 00                 1049 	.byte #0xe2, #0x00	; 226
      00BEA7 E9 00                 1050 	.byte #0xe9, #0x00	; 233
      00BEA9 EA 00                 1051 	.byte #0xea, #0x00	; 234
      00BEAB B5 00                 1052 	.byte #0xb5, #0x00	; 181
      00BEAD B6 00                 1053 	.byte #0xb6, #0x00	; 182
      00BEAF B7 00                 1054 	.byte #0xb7, #0x00	; 183
      00BEB1 CD 00                 1055 	.byte #0xcd, #0x00	; 205
      00BEB3 83 01                 1056 	.byte #0x83, #0x01	; 387
      00BEB5 CC 00                 1057 	.byte #0xcc, #0x00	; 204
      00BEB7 8A 01                 1058 	.byte #0x8a, #0x01	; 394
      00BEB9 92 01                 1059 	.byte #0x92, #0x01	; 402
      00BEBB 94 01                 1060 	.byte #0x94, #0x01	; 404
      00BEBD 21 02                 1061 	.byte #0x21, #0x02	; 545
      00BEBF 23 02                 1062 	.byte #0x23, #0x02	; 547
      00BEC1 24 02                 1063 	.byte #0x24, #0x02	; 548
      00BEC3 25 02                 1064 	.byte #0x25, #0x02	; 549
      00BEC5 26 02                 1065 	.byte #0x26, #0x02	; 550
      00BEC7 27 02                 1066 	.byte #0x27, #0x02	; 551
      00BEC9 2A 02                 1067 	.byte #0x2a, #0x02	; 554
      00BECB B3 00                 1068 	.byte #0xb3, #0x00	; 179
      00BECD B4 00                 1069 	.byte #0xb4, #0x00	; 180
      00BECF 6F 00                 1070 	.byte #0x6f, #0x00	; 111
      00BED1 70 00                 1071 	.byte #0x70, #0x00	; 112
      00BED3 9F 01                 1072 	.byte #0x9f, #0x01	; 415
      00BED5 CB 01                 1073 	.byte #0xcb, #0x01	; 459
      00BED7 9F 02                 1074 	.byte #0x9f, #0x02	; 671
      00BED9 A0 02                 1075 	.byte #0xa0, #0x02	; 672
                                   1076 	.area CSEG    (CODE)
                                   1077 	.area XINIT   (CODE)
                                   1078 	.area CABS    (ABS,CODE)
                                   1079 
                                   1080 ; Experimental exact instruction outlining.
                                   1081 	.globl _ak820_outline_0016
                                   1082 	.globl _ak820_outline_0035
                                   1083 	.globl _ak820_outline_0036
                                   1084 	.globl _ak820_outline_0051
                                   1085 	.globl _ak820_outline_0053
                                   1086 	.globl _ak820_outline_0065
                                   1087 	.globl _ak820_outline_0097
                                   1088 	.globl _ak820_outline_0103
                                   1089 	.globl _ak820_outline_0112
                                   1090 	.globl _ak820_outline_0125
                                   1091 	.globl _ak820_outline_0132
                                   1092 	.globl _ak820_outline_0137
                                   1093 	.globl _ak820_outline_0140
                                   1094 	.globl _ak820_outline_0148
                                   1095 	.globl _ak820_outline_0153
                                   1096 	.globl _ak820_outline_0163
                                   1097 	.globl _ak820_outline_0181
                                   1098 	.globl _ak820_outline_0185
                                   1099 	.globl _ak820_outline_0189
                                   1100 
                                   1101 	.area CSEG (CODE)
                                   1102 ; function ak820_outline_0035
      007327                       1103 _ak820_outline_0035:
      007327 74 02            [12] 1104 	mov	a,#0x02
      007329 2E               [12] 1105 	add	a,r6
      00732A FE               [12] 1106 	mov	r6,a
      00732B E4               [12] 1107 	clr	a
      00732C 3F               [12] 1108 	addc	a,r7
      00732D FF               [12] 1109 	mov	r7,a
      00732E EC               [12] 1110 	mov	a,r4
      00732F 2E               [12] 1111 	add	a,r6
      007330 FC               [12] 1112 	mov	r4,a
      007331 E4               [12] 1113 	clr	a
      007332 3F               [12] 1114 	addc	a,r7
      007333 FB               [12] 1115 	mov	r3,a
      007334 74 07            [12] 1116 	mov	a,#0x07
      007336 5D               [12] 1117 	anl	a,r5
      007337 F5 F0            [12] 1118 	mov	b,a
      007339 05 F0            [12] 1119 	inc	b
      00733B 74 01            [12] 1120 	mov	a,#0x01
      00733D 22               [24] 1121 	ret
                                   1122 
                                   1123 	.area CSEG (CODE)
                                   1124 ; function ak820_outline_0051
      00733E                       1125 _ak820_outline_0051:
      00733E 8E 82            [24] 1126 	mov	dpl,r6
      007340 8F 83            [24] 1127 	mov	dph,r7
      007342 8D F0            [24] 1128 	mov	b,r5
      007344 22               [24] 1129 	ret
                                   1130 
                                   1131 	.area CSEG (CODE)
                                   1132 ; function ak820_outline_0097
      007345                       1133 _ak820_outline_0097:
      007345 8B 82            [24] 1134 	mov	dpl,r3
      007347 8C 83            [24] 1135 	mov	dph,r4
      007349 8D F0            [24] 1136 	mov	b,r5
      00734B 22               [24] 1137 	ret
                                   1138 
                                   1139 	.area CSEG (CODE)
                                   1140 ; function ak820_outline_0132
      00734C                       1141 _ak820_outline_0132:
      00734C F4               [12] 1142 	cpl	a
      00734D 24 01            [12] 1143 	add	a,#0x01
      00734F C5 F0            [12] 1144 	xch	a,b
      007351 F4               [12] 1145 	cpl	a
      007352 34 00            [12] 1146 	addc	a,#0x00
      007354 C5 F0            [12] 1147 	xch	a,b
      007356 22               [24] 1148 	ret
                                   1149 
                                   1150 	.area CSEG (CODE)
                                   1151 ; function ak820_outline_0148
      007357                       1152 _ak820_outline_0148:
      007357 74 02            [12] 1153 	mov	a,#0x02
      007359 2E               [12] 1154 	add	a,r6
      00735A FB               [12] 1155 	mov	r3,a
      00735B E4               [12] 1156 	clr	a
      00735C 3F               [12] 1157 	addc	a,r7
      00735D FC               [12] 1158 	mov	r4,a
      00735E ED               [12] 1159 	mov	a,r5
      00735F 2B               [12] 1160 	add	a,r3
      007360 22               [24] 1161 	ret
                                   1162 
                                   1163 	.area CSEG (CODE)
                                   1164 ; function ak820_outline_0153
      007361                       1165 _ak820_outline_0153:
      007361 8E 03            [24] 1166 	mov	ar3,r6
      007363 8F 04            [24] 1167 	mov	ar4,r7
      007365 7D 00            [12] 1168 	mov	r5,#0x00
      007367 22               [24] 1169 	ret
                                   1170 
                                   1171 	.area CSEG (CODE)
                                   1172 ; function ak820_outline_0181
      007368                       1173 _ak820_outline_0181:
      007368 90 0E 05         [24] 1174 	mov	dptr,#_memset_PARM_2
      00736B E4               [12] 1175 	clr	a
      00736C F0               [24] 1176 	movx	@dptr,a
      00736D 90 0E 06         [24] 1177 	mov	dptr,#_memset_PARM_3
      007370 22               [24] 1178 	ret
