                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_descriptor
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _SerialNumberString
                                     12 	.globl _ProductString
                                     13 	.globl _ManufacturerString
                                     14 	.globl _LanguageString
                                     15 	.globl _ConfigurationDescriptor
                                     16 	.globl _DeviceDescriptor
                                     17 	.globl _RawReport_size
                                     18 	.globl _RawReport
                                     19 	.globl _SharedReport_size
                                     20 	.globl _SharedReport
                                     21 	.globl _KeyboardReport_size
                                     22 	.globl _KeyboardReport
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 ;--------------------------------------------------------
                                    267 ; special function registers
                                    268 ;--------------------------------------------------------
                                    269 	.area RSEG    (ABS,DATA)
      000000                        270 	.org 0x0000
                           0000D0   271 _PSW	=	0x00d0
                           0000E0   272 _ACC	=	0x00e0
                           0000F0   273 _B	=	0x00f0
                           0000FD   274 _A_INV	=	0x00fd
                           000081   275 _SP	=	0x0081
                           000082   276 _DPL	=	0x0082
                           000083   277 _DPH	=	0x0083
                           0000A1   278 _SAFE_MOD	=	0x00a1
                           0000B1   279 _GLOBAL_CFG	=	0x00b1
                           000087   280 _PCON	=	0x0087
                           0000BA   281 _POWER_CFG	=	0x00ba
                           0000B9   282 _CLOCK_CFG	=	0x00b9
                           0000A9   283 _WAKE_CTRL	=	0x00a9
                           0000FE   284 _RESET_KEEP	=	0x00fe
                           0000FF   285 _WDOG_COUNT	=	0x00ff
                           0000A8   286 _IE	=	0x00a8
                           0000B8   287 _IP	=	0x00b8
                           0000E8   288 _IE_EX	=	0x00e8
                           0000E9   289 _IP_EX	=	0x00e9
                           0000B2   290 _GPIO_IE	=	0x00b2
                           008584   291 _ROM_ADDR	=	0x8584
                           000084   292 _ROM_ADDR_L	=	0x0084
                           000085   293 _ROM_ADDR_H	=	0x0085
                           008F8E   294 _ROM_DATA_HI	=	0x8f8e
                           00008E   295 _ROM_DATA_HL	=	0x008e
                           00008F   296 _ROM_DATA_HH	=	0x008f
                           000086   297 _ROM_CTRL	=	0x0086
                           000080   298 _P0	=	0x0080
                           0000C4   299 _P0_MOD_OC	=	0x00c4
                           0000C5   300 _P0_DIR_PU	=	0x00c5
                           000090   301 _P1	=	0x0090
                           000092   302 _P1_MOD_OC	=	0x0092
                           000093   303 _P1_DIR_PU	=	0x0093
                           0000A0   304 _P2	=	0x00a0
                           000094   305 _P2_MOD_OC	=	0x0094
                           000095   306 _P2_DIR_PU	=	0x0095
                           0000B0   307 _P3	=	0x00b0
                           000096   308 _P3_MOD_OC	=	0x0096
                           000097   309 _P3_DIR_PU	=	0x0097
                           0000C0   310 _P4	=	0x00c0
                           0000C2   311 _P4_MOD_OC	=	0x00c2
                           0000C3   312 _P4_DIR_PU	=	0x00c3
                           0000C1   313 _P4_LED_KEY	=	0x00c1
                           0000AA   314 _P5_IN	=	0x00aa
                           0000AB   315 _P5_OUT_PU	=	0x00ab
                           0000AC   316 _P5_DIR	=	0x00ac
                           0000AD   317 _P6_IN	=	0x00ad
                           0000AE   318 _P6_OUT_PU	=	0x00ae
                           0000AF   319 _P6_DIR	=	0x00af
                           0000F1   320 _P7	=	0x00f1
                           0000A2   321 _XBUS_AUX	=	0x00a2
                           000088   322 _TCON	=	0x0088
                           000089   323 _TMOD	=	0x0089
                           00008A   324 _TL0	=	0x008a
                           00008B   325 _TL1	=	0x008b
                           00008C   326 _TH0	=	0x008c
                           00008D   327 _TH1	=	0x008d
                           000098   328 _SCON	=	0x0098
                           000099   329 _SBUF	=	0x0099
                           0000C8   330 _T2CON	=	0x00c8
                           0000C9   331 _T2MOD	=	0x00c9
                           00CBCA   332 _RCAP2	=	0xcbca
                           0000CA   333 _RCAP2L	=	0x00ca
                           0000CB   334 _RCAP2H	=	0x00cb
                           00CDCC   335 _T2COUNT	=	0xcdcc
                           0000CC   336 _TL2	=	0x00cc
                           0000CD   337 _TH2	=	0x00cd
                           00CFCE   338 _T2CAP1	=	0xcfce
                           0000CE   339 _T2CAP1L	=	0x00ce
                           0000CF   340 _T2CAP1H	=	0x00cf
                           0000F8   341 _SPI0_STAT	=	0x00f8
                           0000F9   342 _SPI0_DATA	=	0x00f9
                           0000FA   343 _SPI0_CTRL	=	0x00fa
                           0000FB   344 _SPI0_CK_SE	=	0x00fb
                           0000FC   345 _SPI0_SETUP	=	0x00fc
                           0000BC   346 _SCON1	=	0x00bc
                           0000BD   347 _SBUF1	=	0x00bd
                           0000BE   348 _SBAUD1	=	0x00be
                           0000BF   349 _SIF1	=	0x00bf
                           0000B4   350 _SPI1_STAT	=	0x00b4
                           0000B5   351 _SPI1_DATA	=	0x00b5
                           0000B6   352 _SPI1_CTRL	=	0x00b6
                           0000B7   353 _SPI1_CK_SE	=	0x00b7
                           0000F3   354 _ADC_CTRL	=	0x00f3
                           00F5F4   355 _ADC_DAT	=	0xf5f4
                           0000F4   356 _ADC_DAT_L	=	0x00f4
                           0000F5   357 _ADC_DAT_H	=	0x00f5
                           0000F6   358 _ADC_CHAN	=	0x00f6
                           0000A6   359 _LED_COMMON	=	0x00a6
                           0000A7   360 _LED_PWM_OE	=	0x00a7
                           00C7C6   361 _LED_DMA	=	0xc7c6
                           0000C6   362 _LED_DMA_L	=	0x00c6
                           0000C7   363 _LED_DMA_H	=	0x00c7
                           0000F7   364 _LED_STATUS	=	0x00f7
                           0000B3   365 _I2CX_INT	=	0x00b3
                           0000BB   366 _I2CS_INT_ST	=	0x00bb
                                    367 ;--------------------------------------------------------
                                    368 ; special function bits
                                    369 ;--------------------------------------------------------
                                    370 	.area RSEG    (ABS,DATA)
      000000                        371 	.org 0x0000
                           0000D7   372 _CY	=	0x00d7
                           0000D6   373 _AC	=	0x00d6
                           0000D5   374 _F0	=	0x00d5
                           0000D4   375 _RS1	=	0x00d4
                           0000D3   376 _RS0	=	0x00d3
                           0000D2   377 _OV	=	0x00d2
                           0000D1   378 _F1	=	0x00d1
                           0000D0   379 _P	=	0x00d0
                           0000AF   380 _EA	=	0x00af
                           0000AE   381 _E_DIS	=	0x00ae
                           0000AD   382 _ET2	=	0x00ad
                           0000AC   383 _ES	=	0x00ac
                           0000AB   384 _ET1	=	0x00ab
                           0000AA   385 _EX1	=	0x00aa
                           0000A9   386 _ET0	=	0x00a9
                           0000A8   387 _EX0	=	0x00a8
                           0000BF   388 _PH_FLAG	=	0x00bf
                           0000BE   389 _PL_FLAG	=	0x00be
                           0000BD   390 _PT2	=	0x00bd
                           0000BC   391 _PS	=	0x00bc
                           0000BB   392 _PT1	=	0x00bb
                           0000BA   393 _PX1	=	0x00ba
                           0000B9   394 _PT0	=	0x00b9
                           0000B8   395 _PX0	=	0x00b8
                           0000EF   396 _IE_WDOG	=	0x00ef
                           0000EE   397 _IE_GPIO	=	0x00ee
                           0000ED   398 _IE_PWM_I2C	=	0x00ed
                           0000EC   399 _IE_UART1	=	0x00ec
                           0000EB   400 _IE_ADC	=	0x00eb
                           0000E9   401 _IE_USB	=	0x00e9
                           0000E8   402 _IE_SPI0	=	0x00e8
                           000087   403 _P0_7	=	0x0087
                           000086   404 _P0_6	=	0x0086
                           000085   405 _P0_5	=	0x0085
                           000084   406 _P0_4	=	0x0084
                           000083   407 _P0_3	=	0x0083
                           000082   408 _P0_2	=	0x0082
                           000081   409 _P0_1	=	0x0081
                           000080   410 _P0_0	=	0x0080
                           000081   411 _SDA0	=	0x0081
                           000080   412 _SCL0	=	0x0080
                           000083   413 _TXD_	=	0x0083
                           000082   414 _RXD_	=	0x0082
                           000085   415 _AIN13	=	0x0085
                           000084   416 _AIN12	=	0x0084
                           000083   417 _AIN11	=	0x0083
                           000082   418 _AIN10	=	0x0082
                           000081   419 _AIN9	=	0x0081
                           000080   420 _AIN8	=	0x0080
                           000097   421 _P1_7	=	0x0097
                           000096   422 _P1_6	=	0x0096
                           000095   423 _P1_5	=	0x0095
                           000094   424 _P1_4	=	0x0094
                           000093   425 _P1_3	=	0x0093
                           000092   426 _P1_2	=	0x0092
                           000091   427 _P1_1	=	0x0091
                           000090   428 _P1_0	=	0x0090
                           000097   429 _TXD1_	=	0x0097
                           000096   430 _RXD1_	=	0x0096
                           000097   431 _SCK	=	0x0097
                           000096   432 _MISO	=	0x0096
                           000095   433 _MOSI	=	0x0095
                           000094   434 _SCS	=	0x0094
                           000092   435 _INT0_	=	0x0092
                           000091   436 _T2EX	=	0x0091
                           000091   437 _CAP2	=	0x0091
                           000090   438 _T2	=	0x0090
                           000090   439 _CAP1	=	0x0090
                           000097   440 _AIN7	=	0x0097
                           000096   441 _AIN6	=	0x0096
                           000095   442 _AIN5	=	0x0095
                           000094   443 _AIN4	=	0x0094
                           000093   444 _AIN3	=	0x0093
                           000092   445 _AIN2	=	0x0092
                           000091   446 _AIN1	=	0x0091
                           000090   447 _AIN0	=	0x0090
                           0000A7   448 _P2_7	=	0x00a7
                           0000A6   449 _P2_6	=	0x00a6
                           0000A5   450 _P2_5	=	0x00a5
                           0000A4   451 _P2_4	=	0x00a4
                           0000A3   452 _P2_3	=	0x00a3
                           0000A2   453 _P2_2	=	0x00a2
                           0000A1   454 _P2_1	=	0x00a1
                           0000A0   455 _P2_0	=	0x00a0
                           0000A7   456 _TXD1	=	0x00a7
                           0000A6   457 _RXD1	=	0x00a6
                           0000A5   458 _T2EX_	=	0x00a5
                           0000A5   459 _CAP2_	=	0x00a5
                           0000A4   460 _T2_	=	0x00a4
                           0000A4   461 _CAP1_	=	0x00a4
                           0000B7   462 _P3_7	=	0x00b7
                           0000B6   463 _P3_6	=	0x00b6
                           0000B5   464 _P3_5	=	0x00b5
                           0000B4   465 _P3_4	=	0x00b4
                           0000B3   466 _P3_3	=	0x00b3
                           0000B2   467 _P3_2	=	0x00b2
                           0000B1   468 _P3_1	=	0x00b1
                           0000B0   469 _P3_0	=	0x00b0
                           0000B7   470 _SCK1	=	0x00b7
                           0000B6   471 _MISO1	=	0x00b6
                           0000B5   472 _MOSI1	=	0x00b5
                           0000B5   473 _T1	=	0x00b5
                           0000B4   474 _T0	=	0x00b4
                           0000B3   475 _INT1	=	0x00b3
                           0000B2   476 _INT0	=	0x00b2
                           0000B1   477 _TXD	=	0x00b1
                           0000B0   478 _RXD	=	0x00b0
                           0000C6   479 _P4_6	=	0x00c6
                           0000C5   480 _P4_5	=	0x00c5
                           0000C4   481 _P4_4	=	0x00c4
                           0000C3   482 _P4_3	=	0x00c3
                           0000C2   483 _P4_2	=	0x00c2
                           0000C1   484 _P4_1	=	0x00c1
                           0000C0   485 _P4_0	=	0x00c0
                           00008F   486 _TF1	=	0x008f
                           00008E   487 _TR1	=	0x008e
                           00008D   488 _TF0	=	0x008d
                           00008C   489 _TR0	=	0x008c
                           00008B   490 _IE1	=	0x008b
                           00008A   491 _IT1	=	0x008a
                           000089   492 _IE0	=	0x0089
                           000088   493 _IT0	=	0x0088
                           00009F   494 _SM0	=	0x009f
                           00009E   495 _SM1	=	0x009e
                           00009D   496 _SM2	=	0x009d
                           00009C   497 _REN	=	0x009c
                           00009B   498 _TB8	=	0x009b
                           00009A   499 _RB8	=	0x009a
                           000099   500 _TI	=	0x0099
                           000098   501 _RI	=	0x0098
                           0000CF   502 _TF2	=	0x00cf
                           0000CF   503 _CAP1F	=	0x00cf
                           0000CE   504 _EXF2	=	0x00ce
                           0000CD   505 _RCLK	=	0x00cd
                           0000CC   506 _TCLK	=	0x00cc
                           0000CB   507 _EXEN2	=	0x00cb
                           0000CA   508 _TR2	=	0x00ca
                           0000C9   509 _C_T2	=	0x00c9
                           0000C8   510 _CP_RL2	=	0x00c8
                           0000FF   511 _S0_FST_ACT	=	0x00ff
                           0000FE   512 _S0_IF_OV	=	0x00fe
                           0000FD   513 _S0_IF_FIRST	=	0x00fd
                           0000FC   514 _S0_IF_BYTE	=	0x00fc
                           0000FB   515 _S0_FREE	=	0x00fb
                           0000FA   516 _S0_T_FIFO	=	0x00fa
                           0000F8   517 _S0_R_FIFO	=	0x00f8
                           0000F7   518 _ADC_START	=	0x00f7
                                    519 ;--------------------------------------------------------
                                    520 ; overlayable register banks
                                    521 ;--------------------------------------------------------
                                    522 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        523 	.ds 8
                                    524 ;--------------------------------------------------------
                                    525 ; internal ram data
                                    526 ;--------------------------------------------------------
                                    527 	.area DSEG    (DATA)
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable items in internal ram
                                    530 ;--------------------------------------------------------
                                    531 ;--------------------------------------------------------
                                    532 ; indirectly addressable internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area ISEG    (DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; absolute internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area IABS    (ABS,DATA)
                                    539 	.area IABS    (ABS,DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; bit data
                                    542 ;--------------------------------------------------------
                                    543 	.area BSEG    (BIT)
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XABS    (ABS,XDATA)
                                    556 ;--------------------------------------------------------
                                    557 ; initialized external ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area XISEG   (XDATA)
                                    560 	.area HOME    (CODE)
                                    561 	.area GSINIT0 (CODE)
                                    562 	.area GSINIT1 (CODE)
                                    563 	.area GSINIT2 (CODE)
                                    564 	.area GSINIT3 (CODE)
                                    565 	.area GSINIT4 (CODE)
                                    566 	.area GSINIT5 (CODE)
                                    567 	.area GSINIT  (CODE)
                                    568 	.area GSFINAL (CODE)
                                    569 	.area CSEG    (CODE)
                                    570 ;--------------------------------------------------------
                                    571 ; global & static initialisations
                                    572 ;--------------------------------------------------------
                                    573 	.area HOME    (CODE)
                                    574 	.area GSINIT  (CODE)
                                    575 	.area GSFINAL (CODE)
                                    576 	.area GSINIT  (CODE)
                                    577 ;--------------------------------------------------------
                                    578 ; Home
                                    579 ;--------------------------------------------------------
                                    580 	.area HOME    (CODE)
                                    581 	.area HOME    (CODE)
                                    582 ;--------------------------------------------------------
                                    583 ; code
                                    584 ;--------------------------------------------------------
                                    585 	.area CSEG    (CODE)
                                    586 ;------------------------------------------------------------
                                    587 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    588 ;------------------------------------------------------------
                                    589 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_49'
                                    590 ;------------------------------------------------------------
                                    591 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    592 ;	-----------------------------------------
                           000007   593 	ar7 = 0x07
                           000006   594 	ar6 = 0x06
                           000005   595 	ar5 = 0x05
                           000004   596 	ar4 = 0x04
                           000003   597 	ar3 = 0x03
                           000002   598 	ar2 = 0x02
                           000001   599 	ar1 = 0x01
                           000000   600 	ar0 = 0x00
                                    601 	.area CSEG    (CODE)
                                    602 	.area CONST   (CODE)
                                    603 	.area CONST   (CODE)
      00C452                        604 __str_0:
      00C452 41 00                  605 	.byte 65,0
      00C454 00 00                  606 	.byte 0,0
                                    607 	.area CSEG    (CODE)
                                    608 	.area CONST   (CODE)
      00C456                        609 _KeyboardReport:
      00C456 05                     610 	.db #0x05	; 5
      00C457 01                     611 	.db #0x01	; 1
      00C458 09                     612 	.db #0x09	; 9
      00C459 06                     613 	.db #0x06	; 6
      00C45A A1                     614 	.db #0xa1	; 161
      00C45B 01                     615 	.db #0x01	; 1
      00C45C 05                     616 	.db #0x05	; 5
      00C45D 07                     617 	.db #0x07	; 7
      00C45E 19                     618 	.db #0x19	; 25
      00C45F E0                     619 	.db #0xe0	; 224
      00C460 29                     620 	.db #0x29	; 41
      00C461 E7                     621 	.db #0xe7	; 231
      00C462 15                     622 	.db #0x15	; 21
      00C463 00                     623 	.db #0x00	; 0
      00C464 25                     624 	.db #0x25	; 37
      00C465 01                     625 	.db #0x01	; 1
      00C466 95                     626 	.db #0x95	; 149
      00C467 08                     627 	.db #0x08	; 8
      00C468 75                     628 	.db #0x75	; 117	'u'
      00C469 01                     629 	.db #0x01	; 1
      00C46A 81                     630 	.db #0x81	; 129
      00C46B 02                     631 	.db #0x02	; 2
      00C46C 95                     632 	.db #0x95	; 149
      00C46D 01                     633 	.db #0x01	; 1
      00C46E 75                     634 	.db #0x75	; 117	'u'
      00C46F 08                     635 	.db #0x08	; 8
      00C470 81                     636 	.db #0x81	; 129
      00C471 01                     637 	.db #0x01	; 1
      00C472 05                     638 	.db #0x05	; 5
      00C473 07                     639 	.db #0x07	; 7
      00C474 19                     640 	.db #0x19	; 25
      00C475 00                     641 	.db #0x00	; 0
      00C476 29                     642 	.db #0x29	; 41
      00C477 FF                     643 	.db #0xff	; 255
      00C478 15                     644 	.db #0x15	; 21
      00C479 00                     645 	.db #0x00	; 0
      00C47A 26                     646 	.db #0x26	; 38
      00C47B FF                     647 	.db #0xff	; 255
      00C47C 00                     648 	.db #0x00	; 0
      00C47D 95                     649 	.db #0x95	; 149
      00C47E 06                     650 	.db #0x06	; 6
      00C47F 75                     651 	.db #0x75	; 117	'u'
      00C480 08                     652 	.db #0x08	; 8
      00C481 81                     653 	.db #0x81	; 129
      00C482 00                     654 	.db #0x00	; 0
      00C483 05                     655 	.db #0x05	; 5
      00C484 08                     656 	.db #0x08	; 8
      00C485 19                     657 	.db #0x19	; 25
      00C486 01                     658 	.db #0x01	; 1
      00C487 29                     659 	.db #0x29	; 41
      00C488 05                     660 	.db #0x05	; 5
      00C489 15                     661 	.db #0x15	; 21
      00C48A 00                     662 	.db #0x00	; 0
      00C48B 25                     663 	.db #0x25	; 37
      00C48C 01                     664 	.db #0x01	; 1
      00C48D 95                     665 	.db #0x95	; 149
      00C48E 05                     666 	.db #0x05	; 5
      00C48F 75                     667 	.db #0x75	; 117	'u'
      00C490 01                     668 	.db #0x01	; 1
      00C491 91                     669 	.db #0x91	; 145
      00C492 02                     670 	.db #0x02	; 2
      00C493 95                     671 	.db #0x95	; 149
      00C494 01                     672 	.db #0x01	; 1
      00C495 75                     673 	.db #0x75	; 117	'u'
      00C496 03                     674 	.db #0x03	; 3
      00C497 91                     675 	.db #0x91	; 145
      00C498 01                     676 	.db #0x01	; 1
      00C499 C0                     677 	.db #0xc0	; 192
                                    678 	.area CSEG    (CODE)
                                    679 	.area CONST   (CODE)
      00C49A                        680 _KeyboardReport_size:
      00C49A 44                     681 	.db #0x44	; 68	'D'
                                    682 	.area CSEG    (CODE)
                                    683 	.area CONST   (CODE)
      00C49B                        684 _SharedReport:
      00C49B 05                     685 	.db #0x05	; 5
      00C49C 01                     686 	.db #0x01	; 1
      00C49D 09                     687 	.db #0x09	; 9
      00C49E 02                     688 	.db #0x02	; 2
      00C49F A1                     689 	.db #0xa1	; 161
      00C4A0 01                     690 	.db #0x01	; 1
      00C4A1 85                     691 	.db #0x85	; 133
      00C4A2 02                     692 	.db #0x02	; 2
      00C4A3 09                     693 	.db #0x09	; 9
      00C4A4 01                     694 	.db #0x01	; 1
      00C4A5 A1                     695 	.db #0xa1	; 161
      00C4A6 00                     696 	.db #0x00	; 0
      00C4A7 05                     697 	.db #0x05	; 5
      00C4A8 09                     698 	.db #0x09	; 9
      00C4A9 19                     699 	.db #0x19	; 25
      00C4AA 01                     700 	.db #0x01	; 1
      00C4AB 29                     701 	.db #0x29	; 41
      00C4AC 08                     702 	.db #0x08	; 8
      00C4AD 15                     703 	.db #0x15	; 21
      00C4AE 00                     704 	.db #0x00	; 0
      00C4AF 25                     705 	.db #0x25	; 37
      00C4B0 01                     706 	.db #0x01	; 1
      00C4B1 95                     707 	.db #0x95	; 149
      00C4B2 08                     708 	.db #0x08	; 8
      00C4B3 75                     709 	.db #0x75	; 117	'u'
      00C4B4 01                     710 	.db #0x01	; 1
      00C4B5 81                     711 	.db #0x81	; 129
      00C4B6 02                     712 	.db #0x02	; 2
      00C4B7 05                     713 	.db #0x05	; 5
      00C4B8 01                     714 	.db #0x01	; 1
      00C4B9 09                     715 	.db #0x09	; 9
      00C4BA 30                     716 	.db #0x30	; 48	'0'
      00C4BB 09                     717 	.db #0x09	; 9
      00C4BC 31                     718 	.db #0x31	; 49	'1'
      00C4BD 15                     719 	.db #0x15	; 21
      00C4BE 81                     720 	.db #0x81	; 129
      00C4BF 25                     721 	.db #0x25	; 37
      00C4C0 7F                     722 	.db #0x7f	; 127
      00C4C1 95                     723 	.db #0x95	; 149
      00C4C2 02                     724 	.db #0x02	; 2
      00C4C3 75                     725 	.db #0x75	; 117	'u'
      00C4C4 08                     726 	.db #0x08	; 8
      00C4C5 81                     727 	.db #0x81	; 129
      00C4C6 06                     728 	.db #0x06	; 6
      00C4C7 09                     729 	.db #0x09	; 9
      00C4C8 38                     730 	.db #0x38	; 56	'8'
      00C4C9 15                     731 	.db #0x15	; 21
      00C4CA 81                     732 	.db #0x81	; 129
      00C4CB 25                     733 	.db #0x25	; 37
      00C4CC 7F                     734 	.db #0x7f	; 127
      00C4CD 95                     735 	.db #0x95	; 149
      00C4CE 01                     736 	.db #0x01	; 1
      00C4CF 75                     737 	.db #0x75	; 117	'u'
      00C4D0 08                     738 	.db #0x08	; 8
      00C4D1 81                     739 	.db #0x81	; 129
      00C4D2 06                     740 	.db #0x06	; 6
      00C4D3 05                     741 	.db #0x05	; 5
      00C4D4 0C                     742 	.db #0x0c	; 12
      00C4D5 0A                     743 	.db #0x0a	; 10
      00C4D6 38                     744 	.db #0x38	; 56	'8'
      00C4D7 02                     745 	.db #0x02	; 2
      00C4D8 15                     746 	.db #0x15	; 21
      00C4D9 81                     747 	.db #0x81	; 129
      00C4DA 25                     748 	.db #0x25	; 37
      00C4DB 7F                     749 	.db #0x7f	; 127
      00C4DC 95                     750 	.db #0x95	; 149
      00C4DD 01                     751 	.db #0x01	; 1
      00C4DE 75                     752 	.db #0x75	; 117	'u'
      00C4DF 08                     753 	.db #0x08	; 8
      00C4E0 81                     754 	.db #0x81	; 129
      00C4E1 06                     755 	.db #0x06	; 6
      00C4E2 C0                     756 	.db #0xc0	; 192
      00C4E3 C0                     757 	.db #0xc0	; 192
      00C4E4 05                     758 	.db #0x05	; 5
      00C4E5 01                     759 	.db #0x01	; 1
      00C4E6 09                     760 	.db #0x09	; 9
      00C4E7 80                     761 	.db #0x80	; 128
      00C4E8 A1                     762 	.db #0xa1	; 161
      00C4E9 01                     763 	.db #0x01	; 1
      00C4EA 85                     764 	.db #0x85	; 133
      00C4EB 03                     765 	.db #0x03	; 3
      00C4EC 19                     766 	.db #0x19	; 25
      00C4ED 01                     767 	.db #0x01	; 1
      00C4EE 2A                     768 	.db #0x2a	; 42
      00C4EF B7                     769 	.db #0xb7	; 183
      00C4F0 00                     770 	.db #0x00	; 0
      00C4F1 15                     771 	.db #0x15	; 21
      00C4F2 01                     772 	.db #0x01	; 1
      00C4F3 26                     773 	.db #0x26	; 38
      00C4F4 B7                     774 	.db #0xb7	; 183
      00C4F5 00                     775 	.db #0x00	; 0
      00C4F6 95                     776 	.db #0x95	; 149
      00C4F7 01                     777 	.db #0x01	; 1
      00C4F8 75                     778 	.db #0x75	; 117	'u'
      00C4F9 10                     779 	.db #0x10	; 16
      00C4FA 81                     780 	.db #0x81	; 129
      00C4FB 00                     781 	.db #0x00	; 0
      00C4FC C0                     782 	.db #0xc0	; 192
      00C4FD 05                     783 	.db #0x05	; 5
      00C4FE 0C                     784 	.db #0x0c	; 12
      00C4FF 09                     785 	.db #0x09	; 9
      00C500 01                     786 	.db #0x01	; 1
      00C501 A1                     787 	.db #0xa1	; 161
      00C502 01                     788 	.db #0x01	; 1
      00C503 85                     789 	.db #0x85	; 133
      00C504 04                     790 	.db #0x04	; 4
      00C505 19                     791 	.db #0x19	; 25
      00C506 01                     792 	.db #0x01	; 1
      00C507 2A                     793 	.db #0x2a	; 42
      00C508 A0                     794 	.db #0xa0	; 160
      00C509 02                     795 	.db #0x02	; 2
      00C50A 15                     796 	.db #0x15	; 21
      00C50B 01                     797 	.db #0x01	; 1
      00C50C 26                     798 	.db #0x26	; 38
      00C50D A0                     799 	.db #0xa0	; 160
      00C50E 02                     800 	.db #0x02	; 2
      00C50F 95                     801 	.db #0x95	; 149
      00C510 01                     802 	.db #0x01	; 1
      00C511 75                     803 	.db #0x75	; 117	'u'
      00C512 10                     804 	.db #0x10	; 16
      00C513 81                     805 	.db #0x81	; 129
      00C514 00                     806 	.db #0x00	; 0
      00C515 C0                     807 	.db #0xc0	; 192
      00C516 05                     808 	.db #0x05	; 5
      00C517 01                     809 	.db #0x01	; 1
      00C518 09                     810 	.db #0x09	; 9
      00C519 06                     811 	.db #0x06	; 6
      00C51A A1                     812 	.db #0xa1	; 161
      00C51B 01                     813 	.db #0x01	; 1
      00C51C 85                     814 	.db #0x85	; 133
      00C51D 06                     815 	.db #0x06	; 6
      00C51E 05                     816 	.db #0x05	; 5
      00C51F 07                     817 	.db #0x07	; 7
      00C520 19                     818 	.db #0x19	; 25
      00C521 E0                     819 	.db #0xe0	; 224
      00C522 29                     820 	.db #0x29	; 41
      00C523 E7                     821 	.db #0xe7	; 231
      00C524 15                     822 	.db #0x15	; 21
      00C525 00                     823 	.db #0x00	; 0
      00C526 25                     824 	.db #0x25	; 37
      00C527 01                     825 	.db #0x01	; 1
      00C528 95                     826 	.db #0x95	; 149
      00C529 08                     827 	.db #0x08	; 8
      00C52A 75                     828 	.db #0x75	; 117	'u'
      00C52B 01                     829 	.db #0x01	; 1
      00C52C 81                     830 	.db #0x81	; 129
      00C52D 02                     831 	.db #0x02	; 2
      00C52E 05                     832 	.db #0x05	; 5
      00C52F 07                     833 	.db #0x07	; 7
      00C530 19                     834 	.db #0x19	; 25
      00C531 00                     835 	.db #0x00	; 0
      00C532 29                     836 	.db #0x29	; 41
      00C533 EF                     837 	.db #0xef	; 239
      00C534 15                     838 	.db #0x15	; 21
      00C535 00                     839 	.db #0x00	; 0
      00C536 25                     840 	.db #0x25	; 37
      00C537 01                     841 	.db #0x01	; 1
      00C538 95                     842 	.db #0x95	; 149
      00C539 F0                     843 	.db #0xf0	; 240
      00C53A 75                     844 	.db #0x75	; 117	'u'
      00C53B 01                     845 	.db #0x01	; 1
      00C53C 81                     846 	.db #0x81	; 129
      00C53D 02                     847 	.db #0x02	; 2
      00C53E 05                     848 	.db #0x05	; 5
      00C53F 08                     849 	.db #0x08	; 8
      00C540 19                     850 	.db #0x19	; 25
      00C541 01                     851 	.db #0x01	; 1
      00C542 29                     852 	.db #0x29	; 41
      00C543 05                     853 	.db #0x05	; 5
      00C544 95                     854 	.db #0x95	; 149
      00C545 05                     855 	.db #0x05	; 5
      00C546 75                     856 	.db #0x75	; 117	'u'
      00C547 01                     857 	.db #0x01	; 1
      00C548 91                     858 	.db #0x91	; 145
      00C549 02                     859 	.db #0x02	; 2
      00C54A 95                     860 	.db #0x95	; 149
      00C54B 01                     861 	.db #0x01	; 1
      00C54C 75                     862 	.db #0x75	; 117	'u'
      00C54D 03                     863 	.db #0x03	; 3
      00C54E 91                     864 	.db #0x91	; 145
      00C54F 01                     865 	.db #0x01	; 1
      00C550 C0                     866 	.db #0xc0	; 192
                                    867 	.area CSEG    (CODE)
                                    868 	.area CONST   (CODE)
      00C551                        869 _SharedReport_size:
      00C551 B6                     870 	.db #0xb6	; 182
                                    871 	.area CSEG    (CODE)
                                    872 	.area CONST   (CODE)
      00C552                        873 _RawReport:
      00C552 06                     874 	.db #0x06	; 6
      00C553 60                     875 	.db #0x60	; 96
      00C554 FF                     876 	.db #0xff	; 255
      00C555 09                     877 	.db #0x09	; 9
      00C556 61                     878 	.db #0x61	; 97	'a'
      00C557 A1                     879 	.db #0xa1	; 161
      00C558 01                     880 	.db #0x01	; 1
      00C559 09                     881 	.db #0x09	; 9
      00C55A 62                     882 	.db #0x62	; 98	'b'
      00C55B 15                     883 	.db #0x15	; 21
      00C55C 00                     884 	.db #0x00	; 0
      00C55D 26                     885 	.db #0x26	; 38
      00C55E FF                     886 	.db #0xff	; 255
      00C55F 00                     887 	.db #0x00	; 0
      00C560 95                     888 	.db #0x95	; 149
      00C561 20                     889 	.db #0x20	; 32
      00C562 75                     890 	.db #0x75	; 117	'u'
      00C563 08                     891 	.db #0x08	; 8
      00C564 81                     892 	.db #0x81	; 129
      00C565 02                     893 	.db #0x02	; 2
      00C566 09                     894 	.db #0x09	; 9
      00C567 63                     895 	.db #0x63	; 99	'c'
      00C568 15                     896 	.db #0x15	; 21
      00C569 00                     897 	.db #0x00	; 0
      00C56A 26                     898 	.db #0x26	; 38
      00C56B FF                     899 	.db #0xff	; 255
      00C56C 00                     900 	.db #0x00	; 0
      00C56D 95                     901 	.db #0x95	; 149
      00C56E 20                     902 	.db #0x20	; 32
      00C56F 75                     903 	.db #0x75	; 117	'u'
      00C570 08                     904 	.db #0x08	; 8
      00C571 91                     905 	.db #0x91	; 145
      00C572 02                     906 	.db #0x02	; 2
      00C573 09                     907 	.db #0x09	; 9
      00C574 64                     908 	.db #0x64	; 100	'd'
      00C575 95                     909 	.db #0x95	; 149
      00C576 08                     910 	.db #0x08	; 8
      00C577 B1                     911 	.db #0xb1	; 177
      00C578 02                     912 	.db #0x02	; 2
      00C579 C0                     913 	.db #0xc0	; 192
                                    914 	.area CSEG    (CODE)
                                    915 	.area CONST   (CODE)
      00C57A                        916 _RawReport_size:
      00C57A 28                     917 	.db #0x28	; 40
                                    918 	.area CSEG    (CODE)
                                    919 	.area CONST   (CODE)
      00C57B                        920 _DeviceDescriptor:
      00C57B 12                     921 	.db #0x12	; 18
      00C57C 01                     922 	.db #0x01	; 1
      00C57D 00 02                  923 	.byte #0x00, #0x02	; 512
      00C57F 00                     924 	.db #0x00	; 0
      00C580 00                     925 	.db #0x00	; 0
      00C581 00                     926 	.db #0x00	; 0
      00C582 40                     927 	.db #0x40	; 64
      00C583 0F 32                  928 	.byte #0x0f, #0x32	; 12815
      00C585 5B 50                  929 	.byte #0x5b, #0x50	; 20571
      00C587 00 01                  930 	.byte #0x00, #0x01	; 256
      00C589 01                     931 	.db #0x01	; 1
      00C58A 02                     932 	.db #0x02	; 2
      00C58B 03                     933 	.db #0x03	; 3
      00C58C 01                     934 	.db #0x01	; 1
                                    935 	.area CSEG    (CODE)
                                    936 	.area CONST   (CODE)
      00C58D                        937 _ConfigurationDescriptor:
      00C58D 09                     938 	.db #0x09	; 9
      00C58E 02                     939 	.db #0x02	; 2
      00C58F 54 00                  940 	.byte #0x54, #0x00	; 84
      00C591 03                     941 	.db #0x03	; 3
      00C592 01                     942 	.db #0x01	; 1
      00C593 00                     943 	.db #0x00	; 0
      00C594 A0                     944 	.db #0xa0	; 160
      00C595 FA                     945 	.db #0xfa	; 250
      00C596 09                     946 	.db #0x09	; 9
      00C597 04                     947 	.db #0x04	; 4
      00C598 00                     948 	.db #0x00	; 0
      00C599 00                     949 	.db #0x00	; 0
      00C59A 01                     950 	.db #0x01	; 1
      00C59B 03                     951 	.db #0x03	; 3
      00C59C 01                     952 	.db #0x01	; 1
      00C59D 01                     953 	.db #0x01	; 1
      00C59E 00                     954 	.db #0x00	; 0
      00C59F 09                     955 	.db #0x09	; 9
      00C5A0 21                     956 	.db #0x21	; 33
      00C5A1 11 01                  957 	.byte #0x11, #0x01	; 273
      00C5A3 00                     958 	.db #0x00	; 0
      00C5A4 01                     959 	.db #0x01	; 1
      00C5A5 22                     960 	.db #0x22	; 34
      00C5A6 44 00                  961 	.byte #0x44, #0x00	; 68
      00C5A8 07                     962 	.db #0x07	; 7
      00C5A9 05                     963 	.db #0x05	; 5
      00C5AA 81                     964 	.db #0x81	; 129
      00C5AB 03                     965 	.db #0x03	; 3
      00C5AC 08 00                  966 	.byte #0x08, #0x00	; 8
      00C5AE 01                     967 	.db #0x01	; 1
      00C5AF 09                     968 	.db #0x09	; 9
      00C5B0 04                     969 	.db #0x04	; 4
      00C5B1 01                     970 	.db #0x01	; 1
      00C5B2 00                     971 	.db #0x00	; 0
      00C5B3 01                     972 	.db #0x01	; 1
      00C5B4 03                     973 	.db #0x03	; 3
      00C5B5 00                     974 	.db #0x00	; 0
      00C5B6 00                     975 	.db #0x00	; 0
      00C5B7 00                     976 	.db #0x00	; 0
      00C5B8 09                     977 	.db #0x09	; 9
      00C5B9 21                     978 	.db #0x21	; 33
      00C5BA 11 01                  979 	.byte #0x11, #0x01	; 273
      00C5BC 00                     980 	.db #0x00	; 0
      00C5BD 01                     981 	.db #0x01	; 1
      00C5BE 22                     982 	.db #0x22	; 34
      00C5BF 28 00                  983 	.byte #0x28, #0x00	; 40
      00C5C1 07                     984 	.db #0x07	; 7
      00C5C2 05                     985 	.db #0x05	; 5
      00C5C3 83                     986 	.db #0x83	; 131
      00C5C4 03                     987 	.db #0x03	; 3
      00C5C5 20 00                  988 	.byte #0x20, #0x00	; 32
      00C5C7 01                     989 	.db #0x01	; 1
      00C5C8 09                     990 	.db #0x09	; 9
      00C5C9 04                     991 	.db #0x04	; 4
      00C5CA 02                     992 	.db #0x02	; 2
      00C5CB 00                     993 	.db #0x00	; 0
      00C5CC 01                     994 	.db #0x01	; 1
      00C5CD 03                     995 	.db #0x03	; 3
      00C5CE 00                     996 	.db #0x00	; 0
      00C5CF 00                     997 	.db #0x00	; 0
      00C5D0 00                     998 	.db #0x00	; 0
      00C5D1 09                     999 	.db #0x09	; 9
      00C5D2 21                    1000 	.db #0x21	; 33
      00C5D3 11 01                 1001 	.byte #0x11, #0x01	; 273
      00C5D5 00                    1002 	.db #0x00	; 0
      00C5D6 01                    1003 	.db #0x01	; 1
      00C5D7 22                    1004 	.db #0x22	; 34
      00C5D8 B6 00                 1005 	.byte #0xb6, #0x00	; 182
      00C5DA 07                    1006 	.db #0x07	; 7
      00C5DB 05                    1007 	.db #0x05	; 5
      00C5DC 82                    1008 	.db #0x82	; 130
      00C5DD 03                    1009 	.db #0x03	; 3
      00C5DE 20 00                 1010 	.byte #0x20, #0x00	; 32
      00C5E0 01                    1011 	.db #0x01	; 1
                                   1012 	.area CSEG    (CODE)
                                   1013 	.area CONST   (CODE)
      00C5E1                       1014 _LanguageString:
      00C5E1 04                    1015 	.db #0x04	; 4
      00C5E2 03                    1016 	.db #0x03	; 3
      00C5E3 09 04                 1017 	.byte #0x09, #0x04	; 1033
                                   1018 	.area CSEG    (CODE)
                                   1019 	.area CONST   (CODE)
      00C5E5                       1020 _ManufacturerString:
      00C5E5 0C                    1021 	.db #0x0c	; 12
      00C5E6 03                    1022 	.db #0x03	; 3
      00C5E7 41 00                 1023 	.byte 65,0
      00C5E9 4A 00                 1024 	.byte 74,0
      00C5EB 41 00                 1025 	.byte 65,0
      00C5ED 5A 00                 1026 	.byte 90,0
      00C5EF 5A 00                 1027 	.byte 90,0
      00C5F1 00 00                 1028 	.byte 0,0
                                   1029 	.area CSEG    (CODE)
                                   1030 	.area CONST   (CODE)
      00C5F3                       1031 _ProductString:
      00C5F3 36                    1032 	.db #0x36	; 54	'6'
      00C5F4 03                    1033 	.db #0x03	; 3
      00C5F5 41 00                 1034 	.byte 65,0
      00C5F7 4B 00                 1035 	.byte 75,0
      00C5F9 38 00                 1036 	.byte 56,0
      00C5FB 32 00                 1037 	.byte 50,0
      00C5FD 30 00                 1038 	.byte 48,0
      00C5FF 20 00                 1039 	.byte 32,0
      00C601 77 00                 1040 	.byte 119,0
      00C603 69 00                 1041 	.byte 105,0
      00C605 72 00                 1042 	.byte 114,0
      00C607 65 00                 1043 	.byte 101,0
      00C609 64 00                 1044 	.byte 100,0
      00C60B 20 00                 1045 	.byte 32,0
      00C60D 52 00                 1046 	.byte 82,0
      00C60F 47 00                 1047 	.byte 71,0
      00C611 42 00                 1048 	.byte 66,0
      00C613 20 00                 1049 	.byte 32,0
      00C615 28 00                 1050 	.byte 40,0
      00C617 56 00                 1051 	.byte 86,0
      00C619 53 00                 1052 	.byte 83,0
      00C61B 31 00                 1053 	.byte 49,0
      00C61D 31 00                 1054 	.byte 49,0
      00C61F 4B 00                 1055 	.byte 75,0
      00C621 32 00                 1056 	.byte 50,0
      00C623 38 00                 1057 	.byte 56,0
      00C625 41 00                 1058 	.byte 65,0
      00C627 29 00                 1059 	.byte 41,0
      00C629 00 00                 1060 	.byte 0,0
                                   1061 	.area CSEG    (CODE)
                                   1062 	.area CONST   (CODE)
      00C62B                       1063 _SerialNumberString:
      00C62B 1C                    1064 	.db #0x1c	; 28
      00C62C 03                    1065 	.db #0x03	; 3
      00C62D 76 00                 1066 	.byte 118,0
      00C62F 69 00                 1067 	.byte 105,0
      00C631 61 00                 1068 	.byte 97,0
      00C633 6C 00                 1069 	.byte 108,0
      00C635 3A 00                 1070 	.byte 58,0
      00C637 66 00                 1071 	.byte 102,0
      00C639 36 00                 1072 	.byte 54,0
      00C63B 34 00                 1073 	.byte 52,0
      00C63D 63 00                 1074 	.byte 99,0
      00C63F 32 00                 1075 	.byte 50,0
      00C641 62 00                 1076 	.byte 98,0
      00C643 33 00                 1077 	.byte 51,0
      00C645 63 00                 1078 	.byte 99,0
      00C647 00 00                 1079 	.byte 0,0
                                   1080 	.area CSEG    (CODE)
                                   1081 	.area XINIT   (CODE)
                                   1082 	.area CABS    (ABS,CODE)
