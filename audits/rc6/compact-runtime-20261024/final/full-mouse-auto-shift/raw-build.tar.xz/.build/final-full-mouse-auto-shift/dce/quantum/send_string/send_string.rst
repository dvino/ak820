                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module send_string
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ascii_to_keycode_lut
                                     12 	.globl _ascii_to_dead_lut
                                     13 	.globl _ascii_to_altgr_lut
                                     14 	.globl _ascii_to_shift_lut
                                     15 	.globl _tap_code
                                     16 	.globl _unregister_code
                                     17 	.globl _register_code
                                     18 	.globl _mDelaymS
                                     19 	.globl _rand
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _send_char
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
      000035                        526 _send_char_sloc1_1_0:
      000035                        527 	.ds 1
      000036                        528 _send_char_sloc2_1_0:
      000036                        529 	.ds 1
      000037                        530 _send_char_sloc3_1_0:
      000037                        531 	.ds 1
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable items in internal ram
                                    534 ;--------------------------------------------------------
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
      000029                        548 _send_char_sloc0_1_0:
      000029                        549 	.ds 1
                                    550 ;--------------------------------------------------------
                                    551 ; paged external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area PSEG    (PAG,XDATA)
                                    554 ;--------------------------------------------------------
                                    555 ; uninitialized external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area XSEG    (XDATA)
      000C74                        558 _send_char_ascii_code_10000_241:
      000C74                        559 	.ds 1
                                    560 ;--------------------------------------------------------
                                    561 ; absolute external ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area XABS    (ABS,XDATA)
                                    564 ;--------------------------------------------------------
                                    565 ; initialized external ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area XISEG   (XDATA)
                                    568 	.area HOME    (CODE)
                                    569 	.area GSINIT0 (CODE)
                                    570 	.area GSINIT1 (CODE)
                                    571 	.area GSINIT2 (CODE)
                                    572 	.area GSINIT3 (CODE)
                                    573 	.area GSINIT4 (CODE)
                                    574 	.area GSINIT5 (CODE)
                                    575 	.area GSINIT  (CODE)
                                    576 	.area GSFINAL (CODE)
                                    577 	.area CSEG    (CODE)
                                    578 ;--------------------------------------------------------
                                    579 ; global & static initialisations
                                    580 ;--------------------------------------------------------
                                    581 	.area HOME    (CODE)
                                    582 	.area GSINIT  (CODE)
                                    583 	.area GSFINAL (CODE)
                                    584 	.area GSINIT  (CODE)
                                    585 ;--------------------------------------------------------
                                    586 ; Home
                                    587 ;--------------------------------------------------------
                                    588 	.area HOME    (CODE)
                                    589 	.area HOME    (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; code
                                    592 ;--------------------------------------------------------
                                    593 	.area CSEG    (CODE)
                                    594 ;------------------------------------------------------------
                                    595 ;Allocation info for local variables in function 'send_string'
                                    596 ;------------------------------------------------------------
                                    597 ;string        Allocated with name '_send_string_string_10000_213'
                                    598 ;------------------------------------------------------------
                                    599 ;	quantum/send_string/send_string.c:160: void send_string(const char *string) {
                                    600 ;	-----------------------------------------
                           000007   601 	ar7 = 0x07
                           000006   602 	ar6 = 0x06
                           000005   603 	ar5 = 0x05
                           000004   604 	ar4 = 0x04
                           000003   605 	ar3 = 0x03
                           000002   606 	ar2 = 0x02
                           000001   607 	ar1 = 0x01
                           000000   608 	ar0 = 0x00
                                    609 ;	 function send_char
                                    610 ;	-----------------------------------------
      00A9DD                        611 _send_char:
      00A9DD E5 82            [12]  612 	mov	a,dpl
      00A9DF 90 0C 74         [24]  613 	mov	dptr,#_send_char_ascii_code_10000_241
      00A9E2 F0               [24]  614 	movx	@dptr,a
                                    615 ;	quantum/send_string/send_string.c:216: uint8_t ascii_index = (uint8_t)ascii_code;
      00A9E3 E0               [24]  616 	movx	a,@dptr
                                    617 ;	quantum/send_string/send_string.c:217: uint8_t bit_mask    = pgm_read_byte(&ascii_bit_mask_lut[ascii_index & 7]);
      00A9E4 FF               [12]  618 	mov	r7,a
      00A9E5 FE               [12]  619 	mov	r6,a
      00A9E6 74 07            [12]  620 	mov	a,#0x07
      00A9E8 5E               [12]  621 	anl	a,r6
      00A9E9 90 C2 B8         [24]  622 	mov	dptr,#_ascii_bit_mask_lut
      00A9EC 93               [24]  623 	movc	a,@a+dptr
      00A9ED FE               [12]  624 	mov	r6,a
                                    625 ;	quantum/send_string/send_string.c:218: uint8_t bit_index   = ascii_index >> 3;
      00A9EE EF               [12]  626 	mov	a,r7
      00A9EF 12 5C 10         [24]  627 	lcall	_ak820_outline_0190
      00A9F2 FD               [12]  628 	mov	r5,a
                                    629 ;	quantum/send_string/send_string.c:219: uint8_t keycode     = pgm_read_byte(&ascii_to_keycode_lut[ascii_index]);
      00A9F3 EF               [12]  630 	mov	a,r7
      00A9F4 90 C2 38         [24]  631 	mov	dptr,#_ascii_to_keycode_lut
      00A9F7 93               [24]  632 	movc	a,@a+dptr
      00A9F8 FF               [12]  633 	mov	r7,a
                                    634 ;	quantum/send_string/send_string.c:220: bool    is_shifted  = (pgm_read_byte(&ascii_to_shift_lut[bit_index]) & bit_mask) != 0;
      00A9F9 ED               [12]  635 	mov	a,r5
      00A9FA 90 C2 08         [24]  636 	mov	dptr,#_ascii_to_shift_lut
      00A9FD 93               [24]  637 	movc	a,@a+dptr
      00A9FE FC               [12]  638 	mov	r4,a
      00A9FF EE               [12]  639 	mov	a,r6
      00AA00 52 04            [12]  640 	anl	ar4,a
      00AA02 EC               [12]  641 	mov	a,r4
      00AA03 B4 01 00         [24]  642 	cjne	a,#0x01,00148$
      00AA06                        643 00148$:
      00AA06 92 29            [24]  644 	mov  _send_char_sloc0_1_0,c
      00AA08 B3               [12]  645 	cpl	c
      00AA09 E4               [12]  646 	clr	a
      00AA0A 33               [12]  647 	rlc	a
      00AA0B F5 35            [12]  648 	mov	_send_char_sloc1_1_0,a
                                    649 ;	quantum/send_string/send_string.c:221: bool    is_altgred  = (pgm_read_byte(&ascii_to_altgr_lut[bit_index]) & bit_mask) != 0;
      00AA0D ED               [12]  650 	mov	a,r5
      00AA0E 90 C2 18         [24]  651 	mov	dptr,#_ascii_to_altgr_lut
      00AA11 93               [24]  652 	movc	a,@a+dptr
      00AA12 FC               [12]  653 	mov	r4,a
      00AA13 EE               [12]  654 	mov	a,r6
      00AA14 52 04            [12]  655 	anl	ar4,a
      00AA16 EC               [12]  656 	mov	a,r4
      00AA17 B4 01 00         [24]  657 	cjne	a,#0x01,00149$
      00AA1A                        658 00149$:
      00AA1A 92 29            [24]  659 	mov  _send_char_sloc0_1_0,c
      00AA1C B3               [12]  660 	cpl	c
      00AA1D E4               [12]  661 	clr	a
      00AA1E 33               [12]  662 	rlc	a
      00AA1F F5 36            [12]  663 	mov	_send_char_sloc2_1_0,a
                                    664 ;	quantum/send_string/send_string.c:222: bool    is_dead     = (pgm_read_byte(&ascii_to_dead_lut[bit_index]) & bit_mask) != 0;
      00AA21 ED               [12]  665 	mov	a,r5
      00AA22 90 C2 28         [24]  666 	mov	dptr,#_ascii_to_dead_lut
      00AA25 93               [24]  667 	movc	a,@a+dptr
      00AA26 52 06            [12]  668 	anl	ar6,a
      00AA28 EE               [12]  669 	mov	a,r6
      00AA29 B4 01 00         [24]  670 	cjne	a,#0x01,00150$
      00AA2C                        671 00150$:
      00AA2C 92 29            [24]  672 	mov  _send_char_sloc0_1_0,c
      00AA2E B3               [12]  673 	cpl	c
      00AA2F E4               [12]  674 	clr	a
      00AA30 33               [12]  675 	rlc	a
      00AA31 F5 37            [12]  676 	mov	_send_char_sloc3_1_0,a
                                    677 ;	quantum/send_string/send_string.c:230: if (is_shifted) {
      00AA33 E5 35            [12]  678 	mov	a,_send_char_sloc1_1_0
      00AA35 60 0A            [24]  679 	jz	00102$
                                    680 ;	quantum/send_string/send_string.c:231: register_code(KC_LEFT_SHIFT);
      00AA37 75 82 E1         [24]  681 	mov	dpl, #0xe1
      00AA3A C0 07            [24]  682 	push	ar7
      00AA3C 12 7A 42         [24]  683 	lcall	_register_code
      00AA3F D0 07            [24]  684 	pop	ar7
      00AA41                        685 00102$:
                                    686 ;	quantum/send_string/send_string.c:233: if (is_altgred) {
      00AA41 E5 36            [12]  687 	mov	a,_send_char_sloc2_1_0
      00AA43 60 0A            [24]  688 	jz	00104$
                                    689 ;	quantum/send_string/send_string.c:234: register_code(KC_RIGHT_ALT);
      00AA45 75 82 E6         [24]  690 	mov	dpl, #0xe6
      00AA48 C0 07            [24]  691 	push	ar7
      00AA4A 12 7A 42         [24]  692 	lcall	_register_code
      00AA4D D0 07            [24]  693 	pop	ar7
      00AA4F                        694 00104$:
                                    695 ;	quantum/send_string/send_string.c:236: tap_code(keycode);
      00AA4F 8F 82            [24]  696 	mov	dpl, r7
      00AA51 12 7B 75         [24]  697 	lcall	_tap_code
                                    698 ;	quantum/send_string/send_string.c:237: if (is_altgred) {
      00AA54 E5 36            [12]  699 	mov	a,_send_char_sloc2_1_0
      00AA56 60 06            [24]  700 	jz	00106$
                                    701 ;	quantum/send_string/send_string.c:238: unregister_code(KC_RIGHT_ALT);
      00AA58 75 82 E6         [24]  702 	mov	dpl, #0xe6
      00AA5B 12 7A C7         [24]  703 	lcall	_unregister_code
      00AA5E                        704 00106$:
                                    705 ;	quantum/send_string/send_string.c:240: if (is_shifted) {
      00AA5E E5 35            [12]  706 	mov	a,_send_char_sloc1_1_0
      00AA60 60 06            [24]  707 	jz	00108$
                                    708 ;	quantum/send_string/send_string.c:241: unregister_code(KC_LEFT_SHIFT);
      00AA62 75 82 E1         [24]  709 	mov	dpl, #0xe1
      00AA65 12 7A C7         [24]  710 	lcall	_unregister_code
      00AA68                        711 00108$:
                                    712 ;	quantum/send_string/send_string.c:243: if (is_dead) {
      00AA68 E5 37            [12]  713 	mov	a,_send_char_sloc3_1_0
      00AA6A 60 06            [24]  714 	jz	00111$
                                    715 ;	quantum/send_string/send_string.c:244: tap_code(KC_SPACE);
      00AA6C 75 82 2C         [24]  716 	mov	dpl, #0x2c
                                    717 ;	quantum/send_string/send_string.c:246: }
      00AA6F 02 7B 75         [24]  718 	ljmp	_tap_code
      00AA72                        719 00111$:
      00AA72 22               [24]  720 	ret
                                    721 ;------------------------------------------------------------
                                    722 ;Allocation info for local variables in function 'send_dword'
                                    723 ;------------------------------------------------------------
                                    724 ;number        Allocated with name '_send_dword_number_10000_253'
                                    725 ;------------------------------------------------------------
                                    726 ;	quantum/send_string/send_string.c:248: void send_dword(uint32_t number) {
                                    727 ;	-----------------------------------------
                                    728 	.area CSEG    (CODE)
                                    729 	.area CONST   (CODE)
                                    730 	.area CONST   (CODE)
      00C208                        731 _ascii_to_shift_lut:
      00C208 00                     732 	.db #0x00	; 0
      00C209 00                     733 	.db #0x00	; 0
      00C20A 00                     734 	.db #0x00	; 0
      00C20B 00                     735 	.db #0x00	; 0
      00C20C 7E                     736 	.db #0x7e	; 126
      00C20D 0F                     737 	.db #0x0f	; 15
      00C20E 00                     738 	.db #0x00	; 0
      00C20F D4                     739 	.db #0xd4	; 212
      00C210 FF                     740 	.db #0xff	; 255
      00C211 FF                     741 	.db #0xff	; 255
      00C212 FF                     742 	.db #0xff	; 255
      00C213 C7                     743 	.db #0xc7	; 199
      00C214 00                     744 	.db #0x00	; 0
      00C215 00                     745 	.db #0x00	; 0
      00C216 00                     746 	.db #0x00	; 0
      00C217 78                     747 	.db #0x78	; 120	'x'
                                    748 	.area CSEG    (CODE)
                                    749 	.area CONST   (CODE)
      00C218                        750 _ascii_to_altgr_lut:
      00C218 00                     751 	.db #0x00	; 0
      00C219 00                     752 	.db #0x00	; 0
      00C21A 00                     753 	.db #0x00	; 0
      00C21B 00                     754 	.db #0x00	; 0
      00C21C 00                     755 	.db #0x00	; 0
      00C21D 00                     756 	.db #0x00	; 0
      00C21E 00                     757 	.db #0x00	; 0
      00C21F 00                     758 	.db #0x00	; 0
      00C220 00                     759 	.db #0x00	; 0
      00C221 00                     760 	.db #0x00	; 0
      00C222 00                     761 	.db #0x00	; 0
      00C223 00                     762 	.db #0x00	; 0
      00C224 00                     763 	.db #0x00	; 0
      00C225 00                     764 	.db #0x00	; 0
      00C226 00                     765 	.db #0x00	; 0
      00C227 00                     766 	.db #0x00	; 0
                                    767 	.area CSEG    (CODE)
                                    768 	.area CONST   (CODE)
      00C228                        769 _ascii_to_dead_lut:
      00C228 00                     770 	.db #0x00	; 0
      00C229 00                     771 	.db #0x00	; 0
      00C22A 00                     772 	.db #0x00	; 0
      00C22B 00                     773 	.db #0x00	; 0
      00C22C 00                     774 	.db #0x00	; 0
      00C22D 00                     775 	.db #0x00	; 0
      00C22E 00                     776 	.db #0x00	; 0
      00C22F 00                     777 	.db #0x00	; 0
      00C230 00                     778 	.db #0x00	; 0
      00C231 00                     779 	.db #0x00	; 0
      00C232 00                     780 	.db #0x00	; 0
      00C233 00                     781 	.db #0x00	; 0
      00C234 00                     782 	.db #0x00	; 0
      00C235 00                     783 	.db #0x00	; 0
      00C236 00                     784 	.db #0x00	; 0
      00C237 00                     785 	.db #0x00	; 0
                                    786 	.area CSEG    (CODE)
                                    787 	.area CONST   (CODE)
      00C238                        788 _ascii_to_keycode_lut:
      00C238 00                     789 	.db #0x00	; 0
      00C239 00                     790 	.db #0x00	; 0
      00C23A 00                     791 	.db #0x00	; 0
      00C23B 00                     792 	.db #0x00	; 0
      00C23C 00                     793 	.db #0x00	; 0
      00C23D 00                     794 	.db #0x00	; 0
      00C23E 00                     795 	.db #0x00	; 0
      00C23F 00                     796 	.db #0x00	; 0
      00C240 2A                     797 	.db #0x2a	; 42
      00C241 2B                     798 	.db #0x2b	; 43
      00C242 28                     799 	.db #0x28	; 40
      00C243 00                     800 	.db #0x00	; 0
      00C244 00                     801 	.db #0x00	; 0
      00C245 00                     802 	.db #0x00	; 0
      00C246 00                     803 	.db #0x00	; 0
      00C247 00                     804 	.db #0x00	; 0
      00C248 00                     805 	.db #0x00	; 0
      00C249 00                     806 	.db #0x00	; 0
      00C24A 00                     807 	.db #0x00	; 0
      00C24B 00                     808 	.db #0x00	; 0
      00C24C 00                     809 	.db #0x00	; 0
      00C24D 00                     810 	.db #0x00	; 0
      00C24E 00                     811 	.db #0x00	; 0
      00C24F 00                     812 	.db #0x00	; 0
      00C250 00                     813 	.db #0x00	; 0
      00C251 00                     814 	.db #0x00	; 0
      00C252 00                     815 	.db #0x00	; 0
      00C253 29                     816 	.db #0x29	; 41
      00C254 00                     817 	.db #0x00	; 0
      00C255 00                     818 	.db #0x00	; 0
      00C256 00                     819 	.db #0x00	; 0
      00C257 00                     820 	.db #0x00	; 0
      00C258 2C                     821 	.db #0x2c	; 44
      00C259 1E                     822 	.db #0x1e	; 30
      00C25A 34                     823 	.db #0x34	; 52	'4'
      00C25B 20                     824 	.db #0x20	; 32
      00C25C 21                     825 	.db #0x21	; 33
      00C25D 22                     826 	.db #0x22	; 34
      00C25E 24                     827 	.db #0x24	; 36
      00C25F 34                     828 	.db #0x34	; 52	'4'
      00C260 26                     829 	.db #0x26	; 38
      00C261 27                     830 	.db #0x27	; 39
      00C262 25                     831 	.db #0x25	; 37
      00C263 2E                     832 	.db #0x2e	; 46
      00C264 36                     833 	.db #0x36	; 54	'6'
      00C265 2D                     834 	.db #0x2d	; 45
      00C266 37                     835 	.db #0x37	; 55	'7'
      00C267 38                     836 	.db #0x38	; 56	'8'
      00C268 27                     837 	.db #0x27	; 39
      00C269 1E                     838 	.db #0x1e	; 30
      00C26A 1F                     839 	.db #0x1f	; 31
      00C26B 20                     840 	.db #0x20	; 32
      00C26C 21                     841 	.db #0x21	; 33
      00C26D 22                     842 	.db #0x22	; 34
      00C26E 23                     843 	.db #0x23	; 35
      00C26F 24                     844 	.db #0x24	; 36
      00C270 25                     845 	.db #0x25	; 37
      00C271 26                     846 	.db #0x26	; 38
      00C272 33                     847 	.db #0x33	; 51	'3'
      00C273 33                     848 	.db #0x33	; 51	'3'
      00C274 36                     849 	.db #0x36	; 54	'6'
      00C275 2E                     850 	.db #0x2e	; 46
      00C276 37                     851 	.db #0x37	; 55	'7'
      00C277 38                     852 	.db #0x38	; 56	'8'
      00C278 1F                     853 	.db #0x1f	; 31
      00C279 04                     854 	.db #0x04	; 4
      00C27A 05                     855 	.db #0x05	; 5
      00C27B 06                     856 	.db #0x06	; 6
      00C27C 07                     857 	.db #0x07	; 7
      00C27D 08                     858 	.db #0x08	; 8
      00C27E 09                     859 	.db #0x09	; 9
      00C27F 0A                     860 	.db #0x0a	; 10
      00C280 0B                     861 	.db #0x0b	; 11
      00C281 0C                     862 	.db #0x0c	; 12
      00C282 0D                     863 	.db #0x0d	; 13
      00C283 0E                     864 	.db #0x0e	; 14
      00C284 0F                     865 	.db #0x0f	; 15
      00C285 10                     866 	.db #0x10	; 16
      00C286 11                     867 	.db #0x11	; 17
      00C287 12                     868 	.db #0x12	; 18
      00C288 13                     869 	.db #0x13	; 19
      00C289 14                     870 	.db #0x14	; 20
      00C28A 15                     871 	.db #0x15	; 21
      00C28B 16                     872 	.db #0x16	; 22
      00C28C 17                     873 	.db #0x17	; 23
      00C28D 18                     874 	.db #0x18	; 24
      00C28E 19                     875 	.db #0x19	; 25
      00C28F 1A                     876 	.db #0x1a	; 26
      00C290 1B                     877 	.db #0x1b	; 27
      00C291 1C                     878 	.db #0x1c	; 28
      00C292 1D                     879 	.db #0x1d	; 29
      00C293 2F                     880 	.db #0x2f	; 47
      00C294 31                     881 	.db #0x31	; 49	'1'
      00C295 30                     882 	.db #0x30	; 48	'0'
      00C296 23                     883 	.db #0x23	; 35
      00C297 2D                     884 	.db #0x2d	; 45
      00C298 35                     885 	.db #0x35	; 53	'5'
      00C299 04                     886 	.db #0x04	; 4
      00C29A 05                     887 	.db #0x05	; 5
      00C29B 06                     888 	.db #0x06	; 6
      00C29C 07                     889 	.db #0x07	; 7
      00C29D 08                     890 	.db #0x08	; 8
      00C29E 09                     891 	.db #0x09	; 9
      00C29F 0A                     892 	.db #0x0a	; 10
      00C2A0 0B                     893 	.db #0x0b	; 11
      00C2A1 0C                     894 	.db #0x0c	; 12
      00C2A2 0D                     895 	.db #0x0d	; 13
      00C2A3 0E                     896 	.db #0x0e	; 14
      00C2A4 0F                     897 	.db #0x0f	; 15
      00C2A5 10                     898 	.db #0x10	; 16
      00C2A6 11                     899 	.db #0x11	; 17
      00C2A7 12                     900 	.db #0x12	; 18
      00C2A8 13                     901 	.db #0x13	; 19
      00C2A9 14                     902 	.db #0x14	; 20
      00C2AA 15                     903 	.db #0x15	; 21
      00C2AB 16                     904 	.db #0x16	; 22
      00C2AC 17                     905 	.db #0x17	; 23
      00C2AD 18                     906 	.db #0x18	; 24
      00C2AE 19                     907 	.db #0x19	; 25
      00C2AF 1A                     908 	.db #0x1a	; 26
      00C2B0 1B                     909 	.db #0x1b	; 27
      00C2B1 1C                     910 	.db #0x1c	; 28
      00C2B2 1D                     911 	.db #0x1d	; 29
      00C2B3 2F                     912 	.db #0x2f	; 47
      00C2B4 31                     913 	.db #0x31	; 49	'1'
      00C2B5 30                     914 	.db #0x30	; 48	'0'
      00C2B6 35                     915 	.db #0x35	; 53	'5'
      00C2B7 4C                     916 	.db #0x4c	; 76	'L'
                                    917 	.area CSEG    (CODE)
                                    918 	.area CONST   (CODE)
      00C2B8                        919 _ascii_bit_mask_lut:
      00C2B8 01                     920 	.db #0x01	; 1
      00C2B9 02                     921 	.db #0x02	; 2
      00C2BA 04                     922 	.db #0x04	; 4
      00C2BB 08                     923 	.db #0x08	; 8
      00C2BC 10                     924 	.db #0x10	; 16
      00C2BD 20                     925 	.db #0x20	; 32
      00C2BE 40                     926 	.db #0x40	; 64
      00C2BF 80                     927 	.db #0x80	; 128
                                    928 	.area CSEG    (CODE)
                                    929 	.area XINIT   (CODE)
                                    930 	.area CABS    (ABS,CODE)
                                    931 
                                    932 ; Experimental exact instruction outlining.
                                    933 	.globl _ak820_outline_0190
