                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000682                         85 _eeprom_read_word_addr_10000_91:
      000682                         86 	.ds 3
      000685                         87 _eeprom_read_word_ret_10000_92:
      000685                         88 	.ds 2
      000687                         89 _eeprom_read_dword_addr_10000_93:
      000687                         90 	.ds 3
      00068A                         91 _eeprom_read_dword_ret_10000_94:
      00068A                         92 	.ds 4
      00068E                         93 _eeprom_write_byte_PARM_2:
      00068E                         94 	.ds 1
      00068F                         95 _eeprom_write_byte_addr_10000_95:
      00068F                         96 	.ds 3
      000692                         97 _eeprom_write_word_PARM_2:
      000692                         98 	.ds 2
      000694                         99 _eeprom_write_word_addr_10000_97:
      000694                        100 	.ds 3
      000697                        101 _eeprom_write_dword_PARM_2:
      000697                        102 	.ds 4
      00069B                        103 _eeprom_write_dword_addr_10000_99:
      00069B                        104 	.ds 3
      00069E                        105 _eeprom_update_byte_PARM_2:
      00069E                        106 	.ds 1
      00069F                        107 _eeprom_update_byte_addr_10000_107:
      00069F                        108 	.ds 3
      0006A2                        109 _eeprom_update_word_PARM_2:
      0006A2                        110 	.ds 2
      0006A4                        111 _eeprom_update_word_addr_10000_111:
      0006A4                        112 	.ds 3
      0006A7                        113 _eeprom_update_dword_PARM_2:
      0006A7                        114 	.ds 4
      0006AB                        115 _eeprom_update_dword_addr_10000_115:
      0006AB                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004D5C                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004D5C 12 43 13         [24]  170 	lcall	_ak820_outline_0036
      004D5F 90 06 82         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D62 12 38 1F         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004D65 90 06 85         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D68 12 4F 67         [24]  175 	lcall	_ak820_outline_0184
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004D6B 90 06 82         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D6E 12 4F 14         [24]  178 	lcall	_ak820_outline_0012
      004D71 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D74 ED               [12]  180 	mov	a,r5
      004D75 12 38 1F         [24]  181 	lcall	_ak820_outline_0016
      004D78 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D7B 12 4F 59         [24]  183 	lcall	_ak820_outline_0112
      004D7E 90 06 85         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D81 12 40 AF         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004D84 90 06 85         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D87 12 4F 50         [24]  188 	lcall	_ak820_outline_0093
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004D8A 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004D8B                        201 _eeprom_read_dword:
      004D8B 12 43 13         [24]  202 	lcall	_ak820_outline_0036
      004D8E 90 06 87         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D91 12 38 1F         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004D94 90 06 8A         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D97 12 4F 25         [24]  207 	lcall	_ak820_outline_0051
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004D9A 90 06 87         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D9D 12 4F 14         [24]  210 	lcall	_ak820_outline_0012
      004DA0 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DA3 ED               [12]  212 	mov	a,r5
      004DA4 12 38 1F         [24]  213 	lcall	_ak820_outline_0016
      004DA7 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DAA 74 04            [12]  215 	mov	a,#0x04
      004DAC 12 38 9C         [24]  216 	lcall	_ak820_outline_0136
      004DAF 90 06 8A         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DB2 12 40 AF         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004DB5 90 06 8A         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DB8 12 4F 2E         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004DBB 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004DBC                        234 _eeprom_write_byte:
      004DBC 12 43 13         [24]  235 	lcall	_ak820_outline_0036
      004DBF 90 06 8F         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004DC2 12 38 1F         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004DC5 90 06 8F         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004DC8 12 4E FD         [24]  240 	lcall	_ak820_outline_0004
      004DCB 74 01            [12]  241 	mov	a,#0x01
      004DCD 12 38 9C         [24]  242 	lcall	_ak820_outline_0136
      004DD0 90 06 8E         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004DD3 02 41 3B         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004DD6                        256 _eeprom_write_word:
      004DD6 12 43 13         [24]  257 	lcall	_ak820_outline_0036
      004DD9 90 06 94         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DDC 12 38 1F         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004DDF 90 06 94         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DE2 12 4E FD         [24]  262 	lcall	_ak820_outline_0004
      004DE5 12 4F 59         [24]  263 	lcall	_ak820_outline_0112
      004DE8 90 06 92         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004DEB 02 41 3B         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004DEE                        277 _eeprom_write_dword:
      004DEE 12 43 13         [24]  278 	lcall	_ak820_outline_0036
      004DF1 90 06 9B         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004DF4 12 38 1F         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004DF7 90 06 9B         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004DFA 12 4E FD         [24]  283 	lcall	_ak820_outline_0004
      004DFD 74 04            [12]  284 	mov	a,#0x04
      004DFF 12 38 9C         [24]  285 	lcall	_ak820_outline_0136
      004E02 90 06 97         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004E05 02 41 3B         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004E08                        307 _eeprom_update_byte:
      004E08 C0 07            [24]  308 	push	ar7
      004E0A C0 06            [24]  309 	push	ar6
      004E0C C0 05            [24]  310 	push	ar5
      004E0E C0 04            [24]  311 	push	ar4
      004E10 12 43 13         [24]  312 	lcall	_ak820_outline_0036
      004E13 90 06 9F         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E16 12 38 1F         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004E19 90 06 9F         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E1C 12 4E EE         [24]  317 	lcall	_ak820_outline_0001
      004E1F 12 40 74         [24]  318 	lcall	_eeprom_read_byte
      004E22 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004E24 90 06 9E         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004E27 E0               [24]  322 	movx	a,@dptr
      004E28 FE               [12]  323 	mov	r6,a
      004E29 EF               [12]  324 	mov	a,r7
      004E2A B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004E2D 80 35            [24]  326 	sjmp	00103$
      004E2F                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004E2F 90 06 9F         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E32 12 38 58         [24]  330 	lcall	_ak820_outline_0061
      004E35 A3               [24]  331 	inc	dptr
      004E36 E0               [24]  332 	movx	a,@dptr
      004E37 FF               [12]  333 	mov	r7,a
      004E38 90 06 8E         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004E3B EE               [12]  335 	mov	a,r6
      004E3C 12 38 76         [24]  336 	lcall	_ak820_outline_0103
      004E3F 8F F0            [24]  337 	mov	b, r7
      004E41 C0 07            [24]  338 	push	ar7
      004E43 C0 06            [24]  339 	push	ar6
      004E45 C0 05            [24]  340 	push	ar5
      004E47 C0 04            [24]  341 	push	ar4
      004E49 C0 03            [24]  342 	push	ar3
      004E4B C0 02            [24]  343 	push	ar2
      004E4D C0 01            [24]  344 	push	ar1
      004E4F C0 00            [24]  345 	push	ar0
      004E51 12 4D BC         [24]  346 	lcall	_eeprom_write_byte
      004E54 D0 00            [24]  347 	pop	ar0
      004E56 D0 01            [24]  348 	pop	ar1
      004E58 D0 02            [24]  349 	pop	ar2
      004E5A D0 03            [24]  350 	pop	ar3
      004E5C D0 04            [24]  351 	pop	ar4
      004E5E D0 05            [24]  352 	pop	ar5
      004E60 D0 06            [24]  353 	pop	ar6
      004E62 D0 07            [24]  354 	pop	ar7
      004E64                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004E64 D0 04            [24]  357 	pop	ar4
      004E66 D0 05            [24]  358 	pop	ar5
      004E68 D0 06            [24]  359 	pop	ar6
      004E6A D0 07            [24]  360 	pop	ar7
      004E6C 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004E6D                        373 _eeprom_update_word:
      004E6D 12 43 13         [24]  374 	lcall	_ak820_outline_0036
      004E70 90 06 A4         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E73 12 38 1F         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004E76 90 06 A4         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E79 12 4E EE         [24]  379 	lcall	_ak820_outline_0001
      004E7C 12 4D 5C         [24]  380 	lcall	_eeprom_read_word
      004E7F 12 43 5C         [24]  381 	lcall	_ak820_outline_0135
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004E82 90 06 A2         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004E85 12 38 58         [24]  384 	lcall	_ak820_outline_0061
      004E88 EE               [12]  385 	mov	a,r6
      004E89 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004E8C EF               [12]  387 	mov	a,r7
      004E8D B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004E90 22               [24]  389 	ret
      004E91                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004E91 90 06 A4         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E94 E0               [24]  393 	movx	a,@dptr
      004E95 FB               [12]  394 	mov	r3,a
      004E96 A3               [24]  395 	inc	dptr
      004E97 12 38 41         [24]  396 	lcall	_ak820_outline_0052
      004E9A 90 06 92         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004E9D 12 38 5E         [24]  398 	lcall	_ak820_outline_0072
      004EA0 8B 82            [24]  399 	mov	dpl, r3
      004EA2 8E 83            [24]  400 	mov	dph, r6
      004EA4 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004EA6 02 4D D6         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004EA9                        415 _eeprom_update_dword:
      004EA9 12 43 13         [24]  416 	lcall	_ak820_outline_0036
      004EAC 90 06 AB         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EAF 12 38 1F         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004EB2 90 06 AB         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EB5 12 4E EE         [24]  421 	lcall	_ak820_outline_0001
      004EB8 12 4D 8B         [24]  422 	lcall	_eeprom_read_dword
      004EBB 12 4F 3F         [24]  423 	lcall	_ak820_outline_0057
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004EBE 90 06 A7         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004EC1 E0               [24]  426 	movx	a,@dptr
      004EC2 F8               [12]  427 	mov	r0,a
      004EC3 A3               [24]  428 	inc	dptr
      004EC4 12 4F 47         [24]  429 	lcall	_ak820_outline_0092
      004EC7 EC               [12]  430 	mov	a,r4
      004EC8 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004ECB ED               [12]  432 	mov	a,r5
      004ECC B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004ECF EE               [12]  434 	mov	a,r6
      004ED0 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004ED3 EF               [12]  436 	mov	a,r7
      004ED4 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004ED7 22               [24]  438 	ret
      004ED8                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004ED8 90 06 AB         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EDB 12 4F 14         [24]  442 	lcall	_ak820_outline_0012
      004EDE 90 06 97         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004EE1 E8               [12]  444 	mov	a,r0
      004EE2 F0               [24]  445 	movx	@dptr,a
      004EE3 E9               [12]  446 	mov	a,r1
      004EE4 A3               [24]  447 	inc	dptr
      004EE5 12 4F 60         [24]  448 	lcall	_ak820_outline_0161
      004EE8 12 4F 1D         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004EEB 02 4D EE         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0051
                                    465 	.globl _ak820_outline_0052
                                    466 	.globl _ak820_outline_0055
                                    467 	.globl _ak820_outline_0057
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0092
                                    471 	.globl _ak820_outline_0093
                                    472 	.globl _ak820_outline_0103
                                    473 	.globl _ak820_outline_0112
                                    474 	.globl _ak820_outline_0135
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0161
                                    477 	.globl _ak820_outline_0184
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004EEE                        481 _ak820_outline_0001:
      004EEE E0               [24]  482 	movx	a,@dptr
      004EEF FD               [12]  483 	mov	r5,a
      004EF0 A3               [24]  484 	inc	dptr
      004EF1 E0               [24]  485 	movx	a,@dptr
      004EF2 FE               [12]  486 	mov	r6,a
      004EF3 A3               [24]  487 	inc	dptr
      004EF4 E0               [24]  488 	movx	a,@dptr
      004EF5 FF               [12]  489 	mov	r7,a
      004EF6 8D 82            [24]  490 	mov	dpl,r5
      004EF8 8E 83            [24]  491 	mov	dph,r6
      004EFA 8F F0            [24]  492 	mov	b,r7
      004EFC 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      004EFD                        497 _ak820_outline_0004:
      004EFD E0               [24]  498 	movx	a,@dptr
      004EFE FD               [12]  499 	mov	r5,a
      004EFF A3               [24]  500 	inc	dptr
      004F00 E0               [24]  501 	movx	a,@dptr
      004F01 FE               [12]  502 	mov	r6,a
      004F02 A3               [24]  503 	inc	dptr
      004F03 E0               [24]  504 	movx	a,@dptr
      004F04 FF               [12]  505 	mov	r7,a
      004F05 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004F08 ED               [12]  507 	mov	a,r5
      004F09 F0               [24]  508 	movx	@dptr,a
      004F0A EE               [12]  509 	mov	a,r6
      004F0B A3               [24]  510 	inc	dptr
      004F0C F0               [24]  511 	movx	@dptr,a
      004F0D EF               [12]  512 	mov	a,r7
      004F0E A3               [24]  513 	inc	dptr
      004F0F F0               [24]  514 	movx	@dptr,a
      004F10 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004F13 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      004F14                        520 _ak820_outline_0012:
      004F14 E0               [24]  521 	movx	a,@dptr
      004F15 FD               [12]  522 	mov	r5,a
      004F16 A3               [24]  523 	inc	dptr
      004F17 E0               [24]  524 	movx	a,@dptr
      004F18 FE               [12]  525 	mov	r6,a
      004F19 A3               [24]  526 	inc	dptr
      004F1A E0               [24]  527 	movx	a,@dptr
      004F1B FF               [12]  528 	mov	r7,a
      004F1C 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      004F1D                        533 _ak820_outline_0034:
      004F1D F0               [24]  534 	movx	@dptr,a
      004F1E 8D 82            [24]  535 	mov	dpl,r5
      004F20 8E 83            [24]  536 	mov	dph,r6
      004F22 8F F0            [24]  537 	mov	b,r7
      004F24 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0051
      004F25                        542 _ak820_outline_0051:
      004F25 E4               [12]  543 	clr	a
      004F26 F0               [24]  544 	movx	@dptr,a
      004F27 A3               [24]  545 	inc	dptr
      004F28 F0               [24]  546 	movx	@dptr,a
      004F29 A3               [24]  547 	inc	dptr
      004F2A F0               [24]  548 	movx	@dptr,a
      004F2B A3               [24]  549 	inc	dptr
      004F2C F0               [24]  550 	movx	@dptr,a
      004F2D 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      004F2E                        555 _ak820_outline_0055:
      004F2E E0               [24]  556 	movx	a,@dptr
      004F2F FC               [12]  557 	mov	r4,a
      004F30 A3               [24]  558 	inc	dptr
      004F31 E0               [24]  559 	movx	a,@dptr
      004F32 FD               [12]  560 	mov	r5,a
      004F33 A3               [24]  561 	inc	dptr
      004F34 E0               [24]  562 	movx	a,@dptr
      004F35 FE               [12]  563 	mov	r6,a
      004F36 A3               [24]  564 	inc	dptr
      004F37 E0               [24]  565 	movx	a,@dptr
      004F38 8C 82            [24]  566 	mov	dpl,r4
      004F3A 8D 83            [24]  567 	mov	dph,r5
      004F3C 8E F0            [24]  568 	mov	b,r6
      004F3E 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0057
      004F3F                        573 _ak820_outline_0057:
      004F3F AC 82            [24]  574 	mov	r4,dpl
      004F41 AD 83            [24]  575 	mov	r5,dph
      004F43 AE F0            [24]  576 	mov	r6,b
      004F45 FF               [12]  577 	mov	r7,a
      004F46 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0092
      004F47                        582 _ak820_outline_0092:
      004F47 E0               [24]  583 	movx	a,@dptr
      004F48 F9               [12]  584 	mov	r1,a
      004F49 A3               [24]  585 	inc	dptr
      004F4A E0               [24]  586 	movx	a,@dptr
      004F4B FA               [12]  587 	mov	r2,a
      004F4C A3               [24]  588 	inc	dptr
      004F4D E0               [24]  589 	movx	a,@dptr
      004F4E FB               [12]  590 	mov	r3,a
      004F4F 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0093
      004F50                        595 _ak820_outline_0093:
      004F50 E0               [24]  596 	movx	a,@dptr
      004F51 FE               [12]  597 	mov	r6,a
      004F52 A3               [24]  598 	inc	dptr
      004F53 E0               [24]  599 	movx	a,@dptr
      004F54 8E 82            [24]  600 	mov	dpl,r6
      004F56 F5 83            [12]  601 	mov	dph,a
      004F58 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0112
      004F59                        606 _ak820_outline_0112:
      004F59 74 02            [12]  607 	mov	a,#0x02
      004F5B F0               [24]  608 	movx	@dptr,a
      004F5C E4               [12]  609 	clr	a
      004F5D A3               [24]  610 	inc	dptr
      004F5E F0               [24]  611 	movx	@dptr,a
      004F5F 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0161
      004F60                        616 _ak820_outline_0161:
      004F60 F0               [24]  617 	movx	@dptr,a
      004F61 EA               [12]  618 	mov	a,r2
      004F62 A3               [24]  619 	inc	dptr
      004F63 F0               [24]  620 	movx	@dptr,a
      004F64 EB               [12]  621 	mov	a,r3
      004F65 A3               [24]  622 	inc	dptr
      004F66 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0184
      004F67                        627 _ak820_outline_0184:
      004F67 E4               [12]  628 	clr	a
      004F68 F0               [24]  629 	movx	@dptr,a
      004F69 A3               [24]  630 	inc	dptr
      004F6A F0               [24]  631 	movx	@dptr,a
      004F6B 22               [24]  632 	ret
