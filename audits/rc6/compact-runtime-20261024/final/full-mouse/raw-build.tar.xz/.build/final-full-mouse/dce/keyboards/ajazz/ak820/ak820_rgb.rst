                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000011                        595 _suspended:
      000011                        596 	.ds 1
      000012                        597 _dirty:
      000012                        598 	.ds 1
      000013                        599 _rendering:
      000013                        600 	.ds 1
      000014                        601 _rgb_matrix_task_sloc0_1_0:
      000014                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006C1                        611 _rgb_matrix_config::
      0006C1                        612 	.ds 8
      0006C9                        613 _changed_at:
      0006C9                        614 	.ds 2
      0006CB                        615 _frame_at:
      0006CB                        616 	.ds 2
      0006CD                        617 _phase:
      0006CD                        618 	.ds 2
      0006CF                        619 _led_index:
      0006CF                        620 	.ds 1
      0006D0                        621 _frame_mode:
      0006D0                        622 	.ds 1
      0006D1                        623 _frame_hue:
      0006D1                        624 	.ds 1
      0006D2                        625 _frame_sat:
      0006D2                        626 	.ds 1
      0006D3                        627 _frame_val:
      0006D3                        628 	.ds 1
      0006D4                        629 _frame_flags:
      0006D4                        630 	.ds 1
      0006D5                        631 _frame_phase:
      0006D5                        632 	.ds 1
      0006D6                        633 _reactive_age:
      0006D6                        634 	.ds 82
      000728                        635 _reactive_at:
      000728                        636 	.ds 2
      00072A                        637 _add_sat_PARM_2:
      00072A                        638 	.ds 1
      00072B                        639 _add_sat_x_10000_266:
      00072B                        640 	.ds 1
      00072C                        641 _sub_sat_PARM_2:
      00072C                        642 	.ds 1
      00072D                        643 _sub_sat_x_10000_268:
      00072D                        644 	.ds 1
      00072E                        645 _rgb_matrix_set_color_PARM_2:
      00072E                        646 	.ds 1
      00072F                        647 _rgb_matrix_set_color_PARM_3:
      00072F                        648 	.ds 1
      000730                        649 _rgb_matrix_set_color_PARM_4:
      000730                        650 	.ds 1
      000731                        651 _rgb_matrix_set_color_index_10000_284:
      000731                        652 	.ds 2
      000733                        653 _rgb_matrix_set_color_all_PARM_2:
      000733                        654 	.ds 1
      000734                        655 _rgb_matrix_set_color_all_PARM_3:
      000734                        656 	.ds 1
      000735                        657 _rgb_matrix_set_color_all_r_10000_287:
      000735                        658 	.ds 1
      000736                        659 _sine8_theta_10000_289:
      000736                        660 	.ds 1
      000737                        661 _sine8_offset_10000_290:
      000737                        662 	.ds 1
      000738                        663 _sine8_fraction_10000_290:
      000738                        664 	.ds 1
      000739                        665 _breathing_cie_value_10000_293:
      000739                        666 	.ds 1
      00073A                        667 _rgb_matrix_task_end_10000_298:
      00073A                        668 	.ds 1
      00073B                        669 _rgb_matrix_task_hsv_10000_298:
      00073B                        670 	.ds 3
      00073E                        671 _rgb_matrix_task_rgb_10000_298:
      00073E                        672 	.ds 3
      000741                        673 _process_rgb_matrix_PARM_2:
      000741                        674 	.ds 1
      000742                        675 _process_rgb_matrix_PARM_3:
      000742                        676 	.ds 1
      000743                        677 _process_rgb_matrix_row_10000_319:
      000743                        678 	.ds 1
      000744                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      000744                        680 	.ds 1
      000745                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      000745                        682 	.ds 1
      000746                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000746                        684 	.ds 1
      000747                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000747                        686 	.ds 1
      000748                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000748                        688 	.ds 2
      00074A                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      00074A                        690 	.ds 1
      00074B                        691 _rgb_matrix_mode_mode_10000_411:
      00074B                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      0051D0                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      0051D0 12 59 B7         [24]  746 	lcall	_ak820_outline_0181
      0051D3 74 52            [12]  747 	mov	a,#0x52
      0051D5 12 38 9C         [24]  748 	lcall	_ak820_outline_0136
      0051D8 90 06 D6         [24]  749 	mov	dptr,#_reactive_age
      0051DB F5 F0            [12]  750 	mov	b,a
      0051DD 12 BB 4C         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      0051E0 12 49 36         [24]  753 	lcall	_timer_read
      0051E3 12 38 A6         [24]  754 	lcall	_ak820_outline_0140
      0051E6 90 07 28         [24]  755 	mov	dptr,#_reactive_at
      0051E9 12 59 A3         [24]  756 	lcall	_ak820_outline_0172
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      0051EC 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      0051ED                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      0051ED 90 07 28         [24]  772 	mov	dptr,#_reactive_at
      0051F0 12 37 F4         [24]  773 	lcall	_ak820_outline_0005
      0051F3 12 49 39         [24]  774 	lcall	_timer_elapsed
      0051F6 AE 82            [24]  775 	mov	r6, dpl
      0051F8 E5 83            [12]  776 	mov	a,dph
      0051FA C4               [12]  777 	swap	a
      0051FB CE               [12]  778 	xch	a,r6
      0051FC C4               [12]  779 	swap	a
      0051FD 54 0F            [12]  780 	anl	a,#0x0f
      0051FF 6E               [12]  781 	xrl	a,r6
      005200 CE               [12]  782 	xch	a,r6
      005201 54 0F            [12]  783 	anl	a,#0x0f
      005203 CE               [12]  784 	xch	a,r6
      005204 6E               [12]  785 	xrl	a,r6
      005205 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      005206 FF               [12]  788 	mov	r7,a
      005207 4E               [12]  789 	orl	a,r6
      005208 70 01            [24]  790 	jnz	00102$
      00520A 22               [24]  791 	ret
      00520B                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      00520B 8E 04            [24]  794 	mov	ar4,r6
      00520D EF               [12]  795 	mov	a,r7
      00520E C4               [12]  796 	swap	a
      00520F 54 F0            [12]  797 	anl	a,#0xf0
      005211 CC               [12]  798 	xch	a,r4
      005212 C4               [12]  799 	swap	a
      005213 CC               [12]  800 	xch	a,r4
      005214 6C               [12]  801 	xrl	a,r4
      005215 CC               [12]  802 	xch	a,r4
      005216 54 F0            [12]  803 	anl	a,#0xf0
      005218 CC               [12]  804 	xch	a,r4
      005219 6C               [12]  805 	xrl	a,r4
      00521A FD               [12]  806 	mov	r5,a
      00521B 90 07 28         [24]  807 	mov	dptr,#_reactive_at
      00521E 12 43 4A         [24]  808 	lcall	_ak820_outline_0105
      005221 90 07 28         [24]  809 	mov	dptr,#_reactive_at
      005224 EC               [12]  810 	mov	a,r4
      005225 2A               [12]  811 	add	a, r2
      005226 F0               [24]  812 	movx	@dptr,a
      005227 ED               [12]  813 	mov	a,r5
      005228 3B               [12]  814 	addc	a, r3
      005229 A3               [24]  815 	inc	dptr
      00522A F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      00522B 8E 04            [24]  818 	mov	ar4,r6
      00522D 8F 05            [24]  819 	mov	ar5,r7
      00522F C3               [12]  820 	clr	c
      005230 74 FF            [12]  821 	mov	a,#0xff
      005232 9C               [12]  822 	subb	a,r4
      005233 E4               [12]  823 	clr	a
      005234 9D               [12]  824 	subb	a,r5
      005235 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      005237 7D FF            [12]  827 	mov	r5,#0xff
      005239 80 02            [24]  828 	sjmp	00109$
      00523B                        829 00108$:
      00523B 8E 05            [24]  830 	mov	ar5,r6
      00523D                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00523D 7F 00            [12]  833 	mov	r7,#0x00
      00523F                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      00523F EF               [12]  836 	mov	a,r7
      005240 24 D6            [12]  837 	add	a, #_reactive_age
      005242 FC               [12]  838 	mov	r4,a
      005243 E4               [12]  839 	clr	a
      005244 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      005246 FE               [12]  841 	mov	r6,a
      005247 8C 82            [24]  842 	mov	dpl,r4
      005249 8E 83            [24]  843 	mov	dph,r6
      00524B E0               [24]  844 	movx	a,@dptr
      00524C FB               [12]  845 	mov	r3,a
      00524D C3               [12]  846 	clr	c
      00524E ED               [12]  847 	mov	a,r5
      00524F 9B               [12]  848 	subb	a,r3
      005250 40 04            [24]  849 	jc	00110$
      005252 7B 00            [12]  850 	mov	r3,#0x00
      005254 80 08            [24]  851 	sjmp	00111$
      005256                        852 00110$:
      005256 8C 82            [24]  853 	mov	dpl,r4
      005258 8E 83            [24]  854 	mov	dph,r6
      00525A E0               [24]  855 	movx	a,@dptr
      00525B C3               [12]  856 	clr	c
      00525C 9D               [12]  857 	subb	a,r5
      00525D FB               [12]  858 	mov	r3,a
      00525E                        859 00111$:
      00525E 8C 82            [24]  860 	mov	dpl,r4
      005260 8E 83            [24]  861 	mov	dph,r6
      005262 EB               [12]  862 	mov	a,r3
      005263 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005264 0F               [12]  865 	inc	r7
      005265 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      005268                        867 00144$:
      005268 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      00526A 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      00526B                        881 _add_sat:
      00526B E5 82            [12]  882 	mov	a,dpl
      00526D 90 07 2B         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      005270 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      005271 90 07 2A         [24]  886 	mov	dptr,#_add_sat_PARM_2
      005274 E0               [24]  887 	movx	a,@dptr
      005275 FF               [12]  888 	mov	r7,a
      005276 FE               [12]  889 	mov	r6,a
      005277 74 FF            [12]  890 	mov	a,#0xff
      005279 C3               [12]  891 	clr	c
      00527A 9E               [12]  892 	subb	a,r6
      00527B FE               [12]  893 	mov	r6,a
      00527C 90 07 2B         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      00527F E0               [24]  895 	movx	a,@dptr
      005280 FD               [12]  896 	mov	r5,a
      005281 C3               [12]  897 	clr	c
      005282 EE               [12]  898 	mov	a,r6
      005283 9D               [12]  899 	subb	a,r5
      005284 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      005286 7E FF            [12]  902 	mov	r6,#0xff
      005288 80 03            [24]  903 	sjmp	00104$
      00528A                        904 00103$:
      00528A EF               [12]  905 	mov	a,r7
      00528B 2D               [12]  906 	add	a, r5
      00528C FE               [12]  907 	mov	r6,a
      00528D                        908 00104$:
      00528D 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      00528F 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      005290                        922 _sub_sat:
      005290 E5 82            [12]  923 	mov	a,dpl
      005292 90 07 2D         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      005295 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      005296 E0               [24]  927 	movx	a,@dptr
      005297 FF               [12]  928 	mov	r7,a
      005298 90 07 2C         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      00529B E0               [24]  930 	movx	a,@dptr
      00529C FE               [12]  931 	mov	r6,a
      00529D C3               [12]  932 	clr	c
      00529E EF               [12]  933 	mov	a,r7
      00529F 9E               [12]  934 	subb	a,r6
      0052A0 50 04            [24]  935 	jnc	00103$
      0052A2 7D 00            [12]  936 	mov	r5,#0x00
      0052A4 80 04            [24]  937 	sjmp	00104$
      0052A6                        938 00103$:
      0052A6 EF               [12]  939 	mov	a,r7
      0052A7 C3               [12]  940 	clr	c
      0052A8 9E               [12]  941 	subb	a,r6
      0052A9 FD               [12]  942 	mov	r5,a
      0052AA                        943 00104$:
      0052AA 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      0052AC 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      0052AD                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      0052AD D2 12            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      0052AF 12 49 36         [24]  959 	lcall	_timer_read
      0052B2 12 38 A6         [24]  960 	lcall	_ak820_outline_0140
      0052B5 90 06 C9         [24]  961 	mov	dptr,#_changed_at
      0052B8 12 59 A3         [24]  962 	lcall	_ak820_outline_0172
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      0052BB 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      0052BC                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      0052BC 90 06 C8         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      0052BF E4               [12]  978 	clr	a
      0052C0 F0               [24]  979 	movx	@dptr,a
      0052C1 90 06 C7         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      0052C4 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0052C5 90 05 95         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0052C8 12 59 86         [24]  984 	lcall	_ak820_outline_0087
      0052CB 90 05 98         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0052CE 12 59 6D         [24]  986 	lcall	_ak820_outline_0070
      0052D1 12 42 1E         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      0052D4 C2 12            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      0052D6 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      0052D7                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      0052D7 12 59 B7         [24] 1002 	lcall	_ak820_outline_0181
      0052DA 12 59 6D         [24] 1003 	lcall	_ak820_outline_0070
      0052DD F5 F0            [12] 1004 	mov	b,a
      0052DF 12 BB 4C         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      0052E2 12 59 96         [24] 1007 	lcall	_ak820_outline_0117
      0052E5 44 01            [12] 1008 	orl	a,#0x01
      0052E7 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      0052E8 12 59 66         [24] 1011 	lcall	_ak820_outline_0066
      0052EB 44 04            [12] 1012 	orl	a,#0x04
      0052ED F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      0052EE 90 06 C2         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0052F1 E4               [12] 1016 	clr	a
      0052F2 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      0052F3 90 06 C3         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0052F6 14               [12] 1020 	dec	a
      0052F7 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      0052F8 90 06 C4         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0052FB 74 50            [12] 1024 	mov	a,#0x50
      0052FD F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      0052FE 90 06 C5         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005301 74 60            [12] 1028 	mov	a,#0x60
      005303 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005304 90 06 C6         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005307 74 FF            [12] 1032 	mov	a,#0xff
      005309 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      00530A 02 52 BC         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00530D                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00530D 90 05 85         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005310 12 59 86         [24] 1047 	lcall	_ak820_outline_0087
      005313 90 05 88         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005316 12 59 6D         [24] 1049 	lcall	_ak820_outline_0070
      005319 12 40 AF         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00531C 12 59 96         [24] 1052 	lcall	_ak820_outline_0117
      00531F 60 11            [24] 1053 	jz	00101$
      005321 12 59 47         [24] 1054 	lcall	_ak820_outline_0019
      005324 C3               [12] 1055 	clr	c
      005325 64 80            [12] 1056 	xrl	a,#0x80
      005327 94 87            [12] 1057 	subb	a,#0x87
      005329 50 07            [24] 1058 	jnc	00101$
      00532B 12 59 66         [24] 1059 	lcall	_ak820_outline_0066
      00532E 24 FE            [12] 1060 	add	a,#0xff - 0x01
      005330 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      005332                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      005332 12 52 D7         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      005335                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      005335 90 06 C4         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005338 E0               [24] 1069 	movx	a,@dptr
      005339 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      00533B 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00533D 90 06 C4         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005340 74 A0            [12] 1075 	mov	a,#0xa0
      005342 F0               [24] 1076 	movx	@dptr,a
      005343                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      005343 C2 12            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      005345 C2 13            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      005347 02 51 D0         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      00534A                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      00534A 12 53 0D         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      00534D 12 49 36         [24] 1098 	lcall	_timer_read
      005350 12 43 5C         [24] 1099 	lcall	_ak820_outline_0135
      005353 EE               [12] 1100 	mov	a,r6
      005354 24 F0            [12] 1101 	add	a,#0xf0
      005356 FE               [12] 1102 	mov	r6,a
      005357 EF               [12] 1103 	mov	a,r7
      005358 34 FF            [12] 1104 	addc	a,#0xff
      00535A FF               [12] 1105 	mov	r7,a
      00535B 90 06 CB         [24] 1106 	mov	dptr,#_frame_at
      00535E 12 48 83         [24] 1107 	lcall	_ak820_outline_0060
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      005361 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      005362                       1122 _rgb_matrix_set_color:
      005362 12 38 82         [24] 1123 	lcall	_ak820_outline_0109
      005365 90 07 31         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005368 12 38 87         [24] 1125 	lcall	_ak820_outline_0110
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      00536B 90 07 31         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      00536E 12 38 41         [24] 1128 	lcall	_ak820_outline_0052
      005371 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      005374 C3               [12] 1130 	clr	c
      005375 EE               [12] 1131 	mov	a,r6
      005376 94 52            [12] 1132 	subb	a,#0x52
      005378 EF               [12] 1133 	mov	a,r7
      005379 64 80            [12] 1134 	xrl	a,#0x80
      00537B 94 80            [12] 1135 	subb	a,#0x80
      00537D 50 23            [24] 1136 	jnc	00104$
      00537F 90 07 2E         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005382 E0               [24] 1138 	movx	a,@dptr
      005383 FF               [12] 1139 	mov	r7,a
      005384 90 07 2F         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005387 E0               [24] 1141 	movx	a,@dptr
      005388 FD               [12] 1142 	mov	r5,a
      005389 90 07 30         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00538C E0               [24] 1144 	movx	a,@dptr
      00538D FC               [12] 1145 	mov	r4,a
      00538E 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005391 EF               [12] 1147 	mov	a,r7
      005392 F0               [24] 1148 	movx	@dptr,a
      005393 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      005396 ED               [12] 1150 	mov	a,r5
      005397 F0               [24] 1151 	movx	@dptr,a
      005398 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      00539B EC               [12] 1153 	mov	a,r4
      00539C F0               [24] 1154 	movx	@dptr,a
      00539D 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      00539F 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0053A2                       1158 00104$:
      0053A2 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0053A3                       1171 _rgb_matrix_set_color_all:
      0053A3 E5 82            [12] 1172 	mov	a,dpl
      0053A5 90 07 35         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0053A8 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0053A9 E0               [24] 1176 	movx	a,@dptr
      0053AA FF               [12] 1177 	mov	r7,a
      0053AB 90 07 33         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0053AE E0               [24] 1179 	movx	a,@dptr
      0053AF FE               [12] 1180 	mov	r6,a
      0053B0 90 07 34         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0053B3 E0               [24] 1182 	movx	a,@dptr
      0053B4 FD               [12] 1183 	mov	r5,a
      0053B5 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      0053B8 EE               [12] 1185 	mov	a,r6
      0053B9 F0               [24] 1186 	movx	@dptr,a
      0053BA 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      0053BD ED               [12] 1188 	mov	a,r5
      0053BE F0               [24] 1189 	movx	@dptr,a
      0053BF 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      0053C1 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      0053C4                       1206 _sine8:
      0053C4 E5 82            [12] 1207 	mov	a,dpl
      0053C6 90 07 36         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      0053C9 F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      0053CA E0               [24] 1211 	movx	a,@dptr
      0053CB FF               [12] 1212 	mov	r7,a
      0053CC 90 07 37         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      0053CF F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      0053D0 EF               [12] 1216 	mov	a,r7
      0053D1 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      0053D4 90 07 37         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      0053D7 74 FF            [12] 1219 	mov	a,#0xff
      0053D9 C3               [12] 1220 	clr	c
      0053DA 9F               [12] 1221 	subb	a,r7
      0053DB F0               [24] 1222 	movx	@dptr,a
      0053DC                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      0053DC 90 07 37         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      0053DF E0               [24] 1226 	movx	a,@dptr
      0053E0 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      0053E3 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      0053E4 90 07 37         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      0053E7 E0               [24] 1231 	movx	a,@dptr
      0053E8 54 0F            [12] 1232 	anl	a,#0x0f
      0053EA FF               [12] 1233 	mov	r7,a
      0053EB 90 07 38         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      0053EE F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      0053EF 90 07 36         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      0053F2 E0               [24] 1238 	movx	a,@dptr
      0053F3 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      0053F6 90 07 38         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      0053F9 EF               [12] 1241 	mov	a,r7
      0053FA 04               [12] 1242 	inc	a
      0053FB F0               [24] 1243 	movx	@dptr,a
      0053FC                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      0053FC 90 07 37         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      0053FF E0               [24] 1247 	movx	a,@dptr
      005400 C4               [12] 1248 	swap	a
      005401 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005403 25 E0            [12] 1251 	add	a,acc
      005405 FF               [12] 1252 	mov	r7,a
      005406 90 BC 31         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      005409 93               [24] 1254 	movc	a,@a+dptr
      00540A FE               [12] 1255 	mov	r6,a
      00540B 0F               [12] 1256 	inc	r7
      00540C EF               [12] 1257 	mov	a,r7
      00540D 90 BC 31         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005410 93               [24] 1259 	movc	a,@a+dptr
      005411 FF               [12] 1260 	mov	r7,a
      005412 90 07 38         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005415 E0               [24] 1262 	movx	a,@dptr
      005416 8F F0            [24] 1263 	mov	b,r7
      005418 A4               [48] 1264 	mul	ab
      005419 FF               [12] 1265 	mov	r7,a
      00541A E5 F0            [12] 1266 	mov	a,b
      00541C C4               [12] 1267 	swap	a
      00541D CF               [12] 1268 	xch	a,r7
      00541E C4               [12] 1269 	swap	a
      00541F 54 0F            [12] 1270 	anl	a,#0x0f
      005421 6F               [12] 1271 	xrl	a,r7
      005422 CF               [12] 1272 	xch	a,r7
      005423 54 0F            [12] 1273 	anl	a,#0x0f
      005425 CF               [12] 1274 	xch	a,r7
      005426 6F               [12] 1275 	xrl	a,r7
      005427 CF               [12] 1276 	xch	a,r7
      005428 EF               [12] 1277 	mov	a,r7
      005429 2E               [12] 1278 	add	a, r6
      00542A FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      00542B 90 07 36         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      00542E E0               [24] 1282 	movx	a,@dptr
      00542F 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005432 8F 06            [24] 1284 	mov	ar6,r7
      005434 74 80            [12] 1285 	mov	a,#0x80
      005436 C3               [12] 1286 	clr	c
      005437 9E               [12] 1287 	subb	a,r6
      005438 FE               [12] 1288 	mov	r6,a
      005439 80 04            [24] 1289 	sjmp	00108$
      00543B                       1290 00107$:
      00543B 74 80            [12] 1291 	mov	a,#0x80
      00543D 2F               [12] 1292 	add	a, r7
      00543E FE               [12] 1293 	mov	r6,a
      00543F                       1294 00108$:
      00543F 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005441 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005442                       1312 _breathing_cie:
      005442 E5 82            [12] 1313 	mov	a,dpl
      005444 90 07 39         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      005447 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      005448 E0               [24] 1317 	movx	a,@dptr
      005449 FF               [12] 1318 	mov	r7,a
      00544A 12 59 C5         [24] 1319 	lcall	_ak820_outline_0190
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      00544D FE               [12] 1321 	mov	r6,a
      00544E 90 BF 3D         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      005451 93               [24] 1323 	movc	a,@a+dptr
      005452 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      005453 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      005456 8D 82            [24] 1327 	mov	dpl, r5
      005458 22               [24] 1328 	ret
      005459                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      005459 EE               [12] 1331 	mov	a,r6
      00545A 04               [12] 1332 	inc	a
      00545B 90 BF 3D         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      00545E 93               [24] 1334 	movc	a,@a+dptr
      00545F C3               [12] 1335 	clr	c
      005460 9D               [12] 1336 	subb	a,r5
      005461 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005462 74 07            [12] 1339 	mov	a,#0x07
      005464 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      005465 F5 F0            [12] 1342 	mov	b,a
      005467 EE               [12] 1343 	mov	a,r6
      005468 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      005469 12 59 C5         [24] 1346 	lcall	_ak820_outline_0190
      00546C 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      00546D F5 82            [12] 1349 	mov	dpl,a
      00546F 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      005470                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      005470 12 51 ED         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005473 30 12 18         [24] 1369 	jnb	_dirty,00102$
      005476 90 06 C9         [24] 1370 	mov	dptr,#_changed_at
      005479 12 37 F4         [24] 1371 	lcall	_ak820_outline_0005
      00547C 12 49 39         [24] 1372 	lcall	_timer_elapsed
      00547F 12 43 5C         [24] 1373 	lcall	_ak820_outline_0135
      005482 C3               [12] 1374 	clr	c
      005483 EE               [12] 1375 	mov	a,r6
      005484 94 E8            [12] 1376 	subb	a,#0xe8
      005486 EF               [12] 1377 	mov	a,r7
      005487 94 03            [12] 1378 	subb	a,#0x03
      005489 40 03            [24] 1379 	jc	00102$
      00548B 12 52 BC         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      00548E                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      00548E 30 13 03         [24] 1383 	jnb	_rendering,00254$
      005491 02 55 49         [24] 1384 	ljmp	00109$
      005494                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005494 90 06 CB         [24] 1387 	mov	dptr,#_frame_at
      005497 12 37 F4         [24] 1388 	lcall	_ak820_outline_0005
      00549A 12 49 39         [24] 1389 	lcall	_timer_elapsed
      00549D 12 43 5C         [24] 1390 	lcall	_ak820_outline_0135
      0054A0 C3               [12] 1391 	clr	c
      0054A1 EE               [12] 1392 	mov	a,r6
      0054A2 94 10            [12] 1393 	subb	a,#0x10
      0054A4 EF               [12] 1394 	mov	a,r7
      0054A5 94 00            [12] 1395 	subb	a,#0x00
      0054A7 50 01            [24] 1396 	jnc	00105$
      0054A9 22               [24] 1397 	ret
      0054AA                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0054AA 12 49 36         [24] 1400 	lcall	_timer_read
      0054AD 12 38 A6         [24] 1401 	lcall	_ak820_outline_0140
      0054B0 90 06 CB         [24] 1402 	mov	dptr,#_frame_at
      0054B3 12 59 A3         [24] 1403 	lcall	_ak820_outline_0172
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      0054B6 90 06 C5         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054B9 E0               [24] 1406 	movx	a,@dptr
      0054BA FF               [12] 1407 	mov	r7,a
      0054BB 7E 00            [12] 1408 	mov	r6,#0x00
      0054BD 74 20            [12] 1409 	mov	a,#0x20
      0054BF 2F               [12] 1410 	add	a, r7
      0054C0 FF               [12] 1411 	mov	r7,a
      0054C1 E4               [12] 1412 	clr	a
      0054C2 3E               [12] 1413 	addc	a, r6
      0054C3 FE               [12] 1414 	mov	r6,a
      0054C4 90 06 CD         [24] 1415 	mov	dptr,#_phase
      0054C7 12 38 58         [24] 1416 	lcall	_ak820_outline_0061
      0054CA EF               [12] 1417 	mov	a,r7
      0054CB 2C               [12] 1418 	add	a, r4
      0054CC FF               [12] 1419 	mov	r7,a
      0054CD EE               [12] 1420 	mov	a,r6
      0054CE 3D               [12] 1421 	addc	a, r5
      0054CF FE               [12] 1422 	mov	r6,a
      0054D0 90 06 CD         [24] 1423 	mov	dptr,#_phase
      0054D3 EF               [12] 1424 	mov	a,r7
      0054D4 F0               [24] 1425 	movx	@dptr,a
      0054D5 EE               [12] 1426 	mov	a,r6
      0054D6 A3               [24] 1427 	inc	dptr
      0054D7 F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      0054D8 90 06 CD         [24] 1430 	mov	dptr,#_phase
      0054DB E0               [24] 1431 	movx	a,@dptr
      0054DC A3               [24] 1432 	inc	dptr
      0054DD E0               [24] 1433 	movx	a,@dptr
      0054DE FF               [12] 1434 	mov	r7,a
      0054DF 90 06 D5         [24] 1435 	mov	dptr,#_frame_phase
      0054E2 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      0054E3 20 11 05         [24] 1438 	jb	_suspended,00135$
      0054E6 12 59 66         [24] 1439 	lcall	_ak820_outline_0066
      0054E9 70 04            [24] 1440 	jnz	00132$
      0054EB                       1441 00135$:
      0054EB 7E 00            [12] 1442 	mov	r6,#0x00
      0054ED 80 04            [24] 1443 	sjmp	00133$
      0054EF                       1444 00132$:
      0054EF 12 59 47         [24] 1445 	lcall	_ak820_outline_0019
      0054F2 FE               [12] 1446 	mov	r6,a
      0054F3                       1447 00133$:
      0054F3 90 06 D0         [24] 1448 	mov	dptr,#_frame_mode
      0054F6 EE               [12] 1449 	mov	a,r6
      0054F7 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      0054F8 90 06 C2         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0054FB E0               [24] 1453 	movx	a,@dptr
      0054FC 90 06 D1         [24] 1454 	mov	dptr,#_frame_hue
      0054FF F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005500 90 06 C3         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005503 E0               [24] 1458 	movx	a,@dptr
      005504 90 06 D2         [24] 1459 	mov	dptr,#_frame_sat
      005507 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005508 90 06 C4         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00550B E0               [24] 1463 	movx	a,@dptr
      00550C FD               [12] 1464 	mov	r5,a
      00550D 90 06 D3         [24] 1465 	mov	dptr,#_frame_val
      005510 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005511 90 06 C6         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005514 E0               [24] 1469 	movx	a,@dptr
      005515 90 06 D4         [24] 1470 	mov	dptr,#_frame_flags
      005518 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      005519 BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00551C EF               [12] 1475 	mov	a,r7
      00551D 24 C0            [12] 1476 	add	a,#0xc0
      00551F F5 82            [12] 1477 	mov	dpl,a
      005521 C0 05            [24] 1478 	push	ar5
      005523 12 53 C4         [24] 1479 	lcall	_sine8
      005526 AF 82            [24] 1480 	mov	r7, dpl
      005528 D0 05            [24] 1481 	pop	ar5
      00552A 8D F0            [24] 1482 	mov	b,r5
      00552C EF               [12] 1483 	mov	a,r7
      00552D A4               [48] 1484 	mul	ab
      00552E AE F0            [24] 1485 	mov	r6,b
      005530 8E 05            [24] 1486 	mov	ar5,r6
      005532 90 06 D3         [24] 1487 	mov	dptr,#_frame_val
      005535 ED               [12] 1488 	mov	a,r5
      005536 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      005537 8D 82            [24] 1491 	mov	dpl, r5
      005539 12 54 42         [24] 1492 	lcall	_breathing_cie
      00553C E5 82            [12] 1493 	mov	a, dpl
      00553E 90 06 D3         [24] 1494 	mov	dptr,#_frame_val
      005541 F0               [24] 1495 	movx	@dptr,a
      005542                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005542 90 06 CF         [24] 1498 	mov	dptr,#_led_index
      005545 E4               [12] 1499 	clr	a
      005546 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005547 D2 13            [12] 1503 	setb	_rendering
      005549                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      005549 12 59 C0         [24] 1506 	lcall	_ak820_outline_0188
      00554C 24 08            [12] 1507 	add	a,#0x08
      00554E FF               [12] 1508 	mov	r7,a
      00554F 90 07 3A         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005552 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      005553 EF               [12] 1512 	mov	a,r7
      005554 24 AD            [12] 1513 	add	a,#0xff - 0x52
      005556 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      005558 90 07 3A         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00555B 74 52            [12] 1517 	mov	a,#0x52
      00555D F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      00555E                       1520 00125$:
      00555E 12 59 C0         [24] 1521 	lcall	_ak820_outline_0188
      005561 FF               [12] 1522 	mov	r7,a
      005562 90 07 3A         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005565 E0               [24] 1524 	movx	a,@dptr
      005566 FE               [12] 1525 	mov	r6,a
      005567 C3               [12] 1526 	clr	c
      005568 EF               [12] 1527 	mov	a,r7
      005569 9E               [12] 1528 	subb	a,r6
      00556A 40 03            [24] 1529 	jc	00261$
      00556C 02 56 CF         [24] 1530 	ljmp	00127$
      00556F                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      00556F 12 59 9D         [24] 1533 	lcall	_ak820_outline_0142
      005572 E0               [24] 1534 	movx	a,@dptr
      005573 60 07            [24] 1535 	jz	00121$
      005575 90 06 D4         [24] 1536 	mov	dptr,#_frame_flags
      005578 E0               [24] 1537 	movx	a,@dptr
      005579 20 E2 1B         [24] 1538 	jb	acc.2,00122$
      00557C                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      00557C 12 59 C0         [24] 1541 	lcall	_ak820_outline_0188
      00557F FC               [12] 1542 	mov	r4,a
      005580 7D 00            [12] 1543 	mov	r5,#0x00
      005582 90 07 2E         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005585 E4               [12] 1545 	clr	a
      005586 F0               [24] 1546 	movx	@dptr,a
      005587 90 07 2F         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00558A F0               [24] 1548 	movx	@dptr,a
      00558B 90 07 30         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00558E 12 38 76         [24] 1550 	lcall	_ak820_outline_0103
      005591 12 53 62         [24] 1551 	lcall	_rgb_matrix_set_color
      005594 02 56 C6         [24] 1552 	ljmp	00123$
      005597                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005597 BE 05 21         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00559A EF               [12] 1557 	mov	a,r7
      00559B 75 F0 03         [24] 1558 	mov	b,#0x03
      00559E A4               [48] 1559 	mul	ab
      00559F 24 AE            [12] 1560 	add	a, #_g_direct_mode_colors
      0055A1 FD               [12] 1561 	mov	r5,a
      0055A2 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      0055A4 35 F0            [12] 1563 	addc	a, b
      0055A6 FE               [12] 1564 	mov	r6,a
      0055A7 90 0D C2         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      0055AA ED               [12] 1566 	mov	a,r5
      0055AB F0               [24] 1567 	movx	@dptr,a
      0055AC EE               [12] 1568 	mov	a,r6
      0055AD 12 59 77         [24] 1569 	lcall	_ak820_outline_0073
      0055B0 90 07 3B         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0055B3 F5 F0            [12] 1571 	mov	b,a
      0055B5 12 BA D6         [24] 1572 	lcall	___memcpy
      0055B8 02 56 6A         [24] 1573 	ljmp	00120$
      0055BB                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      0055BB 90 06 D1         [24] 1576 	mov	dptr,#_frame_hue
      0055BE E0               [24] 1577 	movx	a,@dptr
      0055BF 90 07 3B         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0055C2 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      0055C3 90 06 D2         [24] 1581 	mov	dptr,#_frame_sat
      0055C6 E0               [24] 1582 	movx	a,@dptr
      0055C7 90 07 3C         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      0055CA F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      0055CB 90 06 D3         [24] 1586 	mov	dptr,#_frame_val
      0055CE E0               [24] 1587 	movx	a,@dptr
      0055CF 90 07 3D         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0055D2 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      0055D3 12 59 9D         [24] 1591 	lcall	_ak820_outline_0142
      0055D6 BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      0055D9 90 07 3B         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0055DC E0               [24] 1594 	movx	a,@dptr
      0055DD FE               [12] 1595 	mov	r6,a
      0055DE 90 06 D5         [24] 1596 	mov	dptr,#_frame_phase
      0055E1 E0               [24] 1597 	movx	a,@dptr
      0055E2 2E               [12] 1598 	add	a, r6
      0055E3 90 07 3B         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0055E6 F0               [24] 1600 	movx	@dptr,a
      0055E7                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      0055E7 12 59 9D         [24] 1603 	lcall	_ak820_outline_0142
      0055EA BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      0055ED 90 07 3B         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0055F0 E0               [24] 1606 	movx	a,@dptr
      0055F1 FE               [12] 1607 	mov	r6,a
      0055F2 12 59 C0         [24] 1608 	lcall	_ak820_outline_0188
      0055F5 75 F0 02         [24] 1609 	mov	b,#0x02
      0055F8 A4               [48] 1610 	mul	ab
      0055F9 24 99            [12] 1611 	add	a, #_ak820_led_points
      0055FB F5 82            [12] 1612 	mov	dpl,a
      0055FD 74 BE            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      0055FF 12 59 8F         [24] 1614 	lcall	_ak820_outline_0111
      005602 FD               [12] 1615 	mov	r5,a
      005603 90 06 D5         [24] 1616 	mov	dptr,#_frame_phase
      005606 E0               [24] 1617 	movx	a,@dptr
      005607 FC               [12] 1618 	mov	r4,a
      005608 ED               [12] 1619 	mov	a,r5
      005609 C3               [12] 1620 	clr	c
      00560A 9C               [12] 1621 	subb	a,r4
      00560B 2E               [12] 1622 	add	a, r6
      00560C 90 07 3B         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00560F F0               [24] 1624 	movx	@dptr,a
      005610                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005610 12 59 9D         [24] 1627 	lcall	_ak820_outline_0142
      005613 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005616 12 59 AE         [24] 1630 	lcall	_ak820_outline_0176
      005619 FE               [12] 1631 	mov	r6,a
      00561A 74 07            [12] 1632 	mov	a,#0x07
      00561C C3               [12] 1633 	clr	c
      00561D 9E               [12] 1634 	subb	a,r6
      00561E FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00561F 8E F0            [24] 1637 	mov	b,r6
      005621 05 F0            [12] 1638 	inc	b
      005623 74 01            [12] 1639 	mov	a,#0x01
      005625 80 02            [24] 1640 	sjmp	00273$
      005627                       1641 00272$:
      005627 25 E0            [12] 1642 	add	a,acc
      005629                       1643 00273$:
      005629 D5 F0 FB         [24] 1644 	djnz	b,00272$
      00562C FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00562D 12 59 C0         [24] 1647 	lcall	_ak820_outline_0188
      005630 24 D6            [12] 1648 	add	a, #_reactive_age
      005632 F5 82            [12] 1649 	mov	dpl,a
      005634 E4               [12] 1650 	clr	a
      005635 34 06            [12] 1651 	addc	a, #(_reactive_age >> 8)
      005637 F5 83            [12] 1652 	mov	dph,a
      005639 E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      00563A FC               [12] 1655 	mov	r4,a
      00563B C3               [12] 1656 	clr	c
      00563C 9D               [12] 1657 	subb	a,r5
      00563D 40 07            [24] 1658 	jc	00137$
      00563F 90 06 D3         [24] 1659 	mov	dptr,#_frame_val
      005642 E0               [24] 1660 	movx	a,@dptr
      005643 FB               [12] 1661 	mov	r3,a
      005644 80 1F            [24] 1662 	sjmp	00138$
      005646                       1663 00137$:
      005646 90 06 D3         [24] 1664 	mov	dptr,#_frame_val
      005649 E0               [24] 1665 	movx	a,@dptr
      00564A F5 F0            [12] 1666 	mov	b, a
      00564C EC               [12] 1667 	mov	a,r4
      00564D A4               [48] 1668 	mul	ab
      00564E FC               [12] 1669 	mov	r4,a
      00564F AA F0            [24] 1670 	mov	r2,b
      005651 8E F0            [24] 1671 	mov	b,r6
      005653 05 F0            [12] 1672 	inc	b
      005655 AB 04            [24] 1673 	mov	r3,ar4
      005657 AD 02            [24] 1674 	mov	r5,ar2
      005659 80 07            [24] 1675 	sjmp	00276$
      00565B                       1676 00275$:
      00565B C3               [12] 1677 	clr	c
      00565C ED               [12] 1678 	mov	a,r5
      00565D 13               [12] 1679 	rrc	a
      00565E FD               [12] 1680 	mov	r5,a
      00565F EB               [12] 1681 	mov	a,r3
      005660 13               [12] 1682 	rrc	a
      005661 FB               [12] 1683 	mov	r3,a
      005662                       1684 00276$:
      005662 D5 F0 F6         [24] 1685 	djnz	b,00275$
      005665                       1686 00138$:
      005665 90 07 3D         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005668 EB               [12] 1688 	mov	a,r3
      005669 F0               [24] 1689 	movx	@dptr,a
      00566A                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      00566A 12 59 9D         [24] 1692 	lcall	_ak820_outline_0142
      00566D BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      005670 D3               [12] 1694 	setb	c
      005671 80 01            [24] 1695 	sjmp	00278$
      005673                       1696 00277$:
      005673 C3               [12] 1697 	clr	c
      005674                       1698 00278$:
      005674 B3               [12] 1699 	cpl	c
      005675 92 14            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      005677 90 0D C2         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      00567A 74 3B            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      00567C F0               [24] 1703 	movx	@dptr,a
      00567D 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      00567F 12 59 77         [24] 1705 	lcall	_ak820_outline_0073
      005682 90 0A E5         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      005685 F5 F0            [12] 1707 	mov	b,a
      005687 12 BA D6         [24] 1708 	lcall	___memcpy
      00568A 90 0A E8         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      00568D 74 3E            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      00568F F0               [24] 1711 	movx	@dptr,a
      005690 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005692 A3               [24] 1713 	inc	dptr
      005693 F0               [24] 1714 	movx	@dptr,a
      005694 A2 14            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      005696 12 38 B1         [24] 1716 	lcall	_ak820_outline_0162
      005699 12 84 70         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00569C 12 59 C0         [24] 1719 	lcall	_ak820_outline_0188
      00569F FD               [12] 1720 	mov	r5,a
      0056A0 7E 00            [12] 1721 	mov	r6,#0x00
      0056A2 90 07 3F         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0056A5 E0               [24] 1723 	movx	a,@dptr
      0056A6 FC               [12] 1724 	mov	r4,a
      0056A7 90 07 3E         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0056AA E0               [24] 1726 	movx	a,@dptr
      0056AB FB               [12] 1727 	mov	r3,a
      0056AC 90 07 40         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      0056AF E0               [24] 1729 	movx	a,@dptr
      0056B0 FA               [12] 1730 	mov	r2,a
      0056B1 90 07 2E         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0056B4 EC               [12] 1732 	mov	a,r4
      0056B5 F0               [24] 1733 	movx	@dptr,a
      0056B6 90 07 2F         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0056B9 EB               [12] 1735 	mov	a,r3
      0056BA F0               [24] 1736 	movx	@dptr,a
      0056BB 90 07 30         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0056BE EA               [12] 1738 	mov	a,r2
      0056BF F0               [24] 1739 	movx	@dptr,a
      0056C0 12 38 A1         [24] 1740 	lcall	_ak820_outline_0137
      0056C3 12 53 62         [24] 1741 	lcall	_rgb_matrix_set_color
      0056C6                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      0056C6 12 59 C0         [24] 1744 	lcall	_ak820_outline_0188
      0056C9 24 01            [12] 1745 	add	a, #0x01
      0056CB F0               [24] 1746 	movx	@dptr,a
      0056CC 02 55 5E         [24] 1747 	ljmp	00125$
      0056CF                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      0056CF BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      0056D2 C2 13            [12] 1753 	clr	_rendering
      0056D4                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      0056D4 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      0056D5                       1770 _process_rgb_matrix:
      0056D5 E5 82            [12] 1771 	mov	a,dpl
      0056D7 90 07 43         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0056DA F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      0056DB 90 07 42         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      0056DE E0               [24] 1776 	movx	a,@dptr
      0056DF 60 23            [24] 1777 	jz	00101$
      0056E1 20 11 20         [24] 1778 	jb	_suspended,00101$
      0056E4 12 59 66         [24] 1779 	lcall	_ak820_outline_0066
      0056E7 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      0056E9 12 59 47         [24] 1782 	lcall	_ak820_outline_0019
      0056EC FF               [12] 1783 	mov	r7,a
      0056ED BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      0056F0 90 07 43         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      0056F3 E0               [24] 1786 	movx	a,@dptr
      0056F4 FF               [12] 1787 	mov	r7,a
      0056F5 BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      0056F8                       1789 00169$:
      0056F8 50 0A            [24] 1790 	jnc	00101$
      0056FA 90 07 41         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      0056FD E0               [24] 1792 	movx	a,@dptr
      0056FE FE               [12] 1793 	mov	r6,a
      0056FF BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      005702                       1795 00171$:
      005702 40 01            [24] 1796 	jc	00102$
      005704                       1797 00101$:
      005704 22               [24] 1798 	ret
      005705                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005705 C0 07            [24] 1801 	push	ar7
      005707 C0 06            [24] 1802 	push	ar6
      005709 12 51 ED         [24] 1803 	lcall	_age_reactive
      00570C D0 06            [24] 1804 	pop	ar6
      00570E D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005710 EF               [12] 1807 	mov	a,r7
      005711 12 38 C6         [24] 1808 	lcall	_ak820_outline_0193
      005714 2E               [12] 1809 	add	a,r6
      005715 FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005716 7E 00            [12] 1812 	mov	r6,#0x00
      005718                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005718 EE               [12] 1815 	mov	a,r6
      005719 90 BB DF         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      00571C 93               [24] 1817 	movc	a,@a+dptr
      00571D B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005720 EE               [12] 1820 	mov	a,r6
      005721 24 D6            [12] 1821 	add	a, #_reactive_age
      005723 FC               [12] 1822 	mov	r4,a
      005724 E4               [12] 1823 	clr	a
      005725 34 06            [12] 1824 	addc	a, #(_reactive_age >> 8)
      005727 FD               [12] 1825 	mov	r5,a
      005728 12 59 AE         [24] 1826 	lcall	_ak820_outline_0176
      00572B F5 F0            [12] 1827 	mov	b, a
      00572D 05 F0            [12] 1828 	inc	b
      00572F 7B 80            [12] 1829 	mov	r3,#0x80
      005731 E4               [12] 1830 	clr	a
      005732 FA               [12] 1831 	mov	r2,a
      005733 33               [12] 1832 	rlc	a
      005734 92 D2            [24] 1833 	mov	ov,c
      005736 80 08            [24] 1834 	sjmp	00176$
      005738                       1835 00175$:
      005738 A2 D2            [12] 1836 	mov	c,ov
      00573A EA               [12] 1837 	mov	a,r2
      00573B 13               [12] 1838 	rrc	a
      00573C FA               [12] 1839 	mov	r2,a
      00573D EB               [12] 1840 	mov	a,r3
      00573E 13               [12] 1841 	rrc	a
      00573F FB               [12] 1842 	mov	r3,a
      005740                       1843 00176$:
      005740 D5 F0 F5         [24] 1844 	djnz	b,00175$
      005743 12 38 97         [24] 1845 	lcall	_ak820_outline_0126
      005746 EB               [12] 1846 	mov	a,r3
      005747 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005748 22               [24] 1849 	ret
      005749                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005749 0E               [12] 1852 	inc	r6
      00574A BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      00574D                       1854 00177$:
      00574D 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      00574F 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      005750                       1868 _rgb_matrix_set_suspend_state:
      005750 E5 82            [12] 1869 	mov	a,dpl
      005752 90 07 44         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      005755 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      005756 E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      005757 F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      005759 13               [12] 1876 	rrc	a
      00575A 92 11            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      00575C C2 13            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      00575E 12 51 D0         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005761 E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005763 60 0F            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      005765 90 07 33         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005768 E4               [12] 1888 	clr	a
      005769 F0               [24] 1889 	movx	@dptr,a
      00576A 90 07 34         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      00576D F0               [24] 1891 	movx	@dptr,a
      00576E 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005771 02 53 A3         [24] 1894 	ljmp	_rgb_matrix_set_color_all
      005774                       1895 00103$:
      005774 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      005775                       1904 _rgb_matrix_is_enabled:
      005775 12 59 66         [24] 1905 	lcall	_ak820_outline_0066
      005778 F5 82            [12] 1906 	mov	dpl,a
      00577A 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      00577B                       1915 _rgb_matrix_get_mode:
      00577B 12 59 47         [24] 1916 	lcall	_ak820_outline_0019
      00577E F5 82            [12] 1917 	mov	dpl,a
      005780 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      005781                       1926 _rgb_matrix_get_hue:
      005781 90 06 C2         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005784 E0               [24] 1928 	movx	a,@dptr
      005785 F5 82            [12] 1929 	mov	dpl,a
      005787 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      005788                       1938 _rgb_matrix_get_sat:
      005788 90 06 C3         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00578B E0               [24] 1940 	movx	a,@dptr
      00578C F5 82            [12] 1941 	mov	dpl,a
      00578E 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      00578F                       1950 _rgb_matrix_get_val:
      00578F 90 06 C4         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005792 E0               [24] 1952 	movx	a,@dptr
      005793 F5 82            [12] 1953 	mov	dpl,a
      005795 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      005796                       1962 _rgb_matrix_get_speed:
      005796 90 06 C5         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005799 E0               [24] 1964 	movx	a,@dptr
      00579A F5 82            [12] 1965 	mov	dpl,a
      00579C 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      00579D                       1974 _rgb_matrix_toggle_noeeprom:
      00579D 12 59 66         [24] 1975 	lcall	_ak820_outline_0066
      0057A0 FF               [12] 1976 	mov	r7,a
      0057A1 63 07 01         [24] 1977 	xrl	ar7,#0x01
      0057A4 90 06 C1         [24] 1978 	mov	dptr,#_rgb_matrix_config
      0057A7 EF               [12] 1979 	mov	a,r7
      0057A8 54 03            [12] 1980 	anl	a,#0x03
      0057AA F5 F0            [12] 1981 	mov	b,a
      0057AC E0               [24] 1982 	movx	a,@dptr
      0057AD 54 FC            [12] 1983 	anl	a,#0xfc
      0057AF 45 F0            [12] 1984 	orl	a,b
      0057B1 F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      0057B2 C2 13            [12] 1987 	clr	_rendering
      0057B4 02 51 D0         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      0057B7                       1996 _rgb_matrix_enable_noeeprom:
      0057B7 12 59 66         [24] 1997 	lcall	_ak820_outline_0066
      0057BA 70 03            [24] 1998 	jnz	00102$
      0057BC 12 51 D0         [24] 1999 	lcall	_clear_reactive
      0057BF                       2000 00102$:
      0057BF 12 59 96         [24] 2001 	lcall	_ak820_outline_0117
      0057C2 44 01            [12] 2002 	orl	a,#0x01
      0057C4 F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      0057C5 C2 13            [12] 2005 	clr	_rendering
      0057C7 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      0057C8                       2014 _rgb_matrix_disable_noeeprom:
      0057C8 12 59 96         [24] 2015 	lcall	_ak820_outline_0117
      0057CB F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      0057CC C2 13            [12] 2018 	clr	_rendering
      0057CE 02 51 D0         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      0057D1                       2029 _rgb_matrix_mode_noeeprom:
      0057D1 E5 82            [12] 2030 	mov	a,dpl
      0057D3 90 07 45         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0057D6 F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      0057D7 E0               [24] 2034 	movx	a,@dptr
      0057D8 FF               [12] 2035 	mov	r7,a
      0057D9 60 05            [24] 2036 	jz	00101$
      0057DB BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      0057DE                       2038 00123$:
      0057DE 40 01            [24] 2039 	jc	00102$
      0057E0                       2040 00101$:
      0057E0 22               [24] 2041 	ret
      0057E1                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      0057E1 12 59 47         [24] 2044 	lcall	_ak820_outline_0019
      0057E4 FE               [12] 2045 	mov	r6,a
      0057E5 EF               [12] 2046 	mov	a,r7
      0057E6 B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      0057E9 80 03            [24] 2048 	sjmp	00105$
      0057EB                       2049 00125$:
      0057EB 12 51 D0         [24] 2050 	lcall	_clear_reactive
      0057EE                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      0057EE 90 07 45         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      0057F1 E0               [24] 2054 	movx	a,@dptr
      0057F2 90 06 C1         [24] 2055 	mov	dptr,#_rgb_matrix_config
      0057F5 25 E0            [12] 2056 	add	a,acc
      0057F7 25 E0            [12] 2057 	add	a,acc
      0057F9 54 FC            [12] 2058 	anl	a,#0xfc
      0057FB F5 F0            [12] 2059 	mov	b,a
      0057FD E0               [24] 2060 	movx	a,@dptr
      0057FE 54 03            [12] 2061 	anl	a,#0x03
      005800 45 F0            [12] 2062 	orl	a,b
      005802 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      005803 C2 13            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005805 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      005806                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005806 12 59 47         [24] 2078 	lcall	_ak820_outline_0019
      005809 FF               [12] 2079 	mov	r7,a
      00580A 0F               [12] 2080 	inc	r7
      00580B BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      00580E                       2082 00112$:
      00580E 40 04            [24] 2083 	jc	00103$
      005810 7F 01            [12] 2084 	mov	r7,#0x01
      005812 80 07            [24] 2085 	sjmp	00104$
      005814                       2086 00103$:
      005814 12 59 47         [24] 2087 	lcall	_ak820_outline_0019
      005817 FE               [12] 2088 	mov	r6,a
      005818 0E               [12] 2089 	inc	r6
      005819 8E 07            [24] 2090 	mov	ar7,r6
      00581B                       2091 00104$:
      00581B 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      00581D 02 57 D1         [24] 2094 	ljmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      005820                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005820 12 59 47         [24] 2104 	lcall	_ak820_outline_0019
      005823 24 FE            [12] 2105 	add	a,#0xff - 0x01
      005825 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      005827 7F 06            [12] 2108 	mov	r7,#0x06
      005829 80 05            [24] 2109 	sjmp	00104$
      00582B                       2110 00103$:
      00582B 12 59 47         [24] 2111 	lcall	_ak820_outline_0019
      00582E 14               [12] 2112 	dec	a
      00582F FF               [12] 2113 	mov	r7,a
      005830                       2114 00104$:
      005830 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      005832 02 57 D1         [24] 2117 	ljmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      005835                       2129 _rgb_matrix_sethsv_noeeprom:
      005835 12 38 82         [24] 2130 	lcall	_ak820_outline_0109
      005838 90 07 48         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      00583B 12 38 87         [24] 2132 	lcall	_ak820_outline_0110
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      00583E 90 07 48         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005841 E0               [24] 2135 	movx	a,@dptr
      005842 90 06 C2         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005845 F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      005846 90 07 46         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005849 E0               [24] 2140 	movx	a,@dptr
      00584A FF               [12] 2141 	mov	r7,a
      00584B 90 06 C3         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00584E F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00584F 90 07 47         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      005852 E0               [24] 2146 	movx	a,@dptr
      005853 FF               [12] 2147 	mov  r7,a
      005854 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      005856 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      005858 7E A0            [12] 2151 	mov	r6,#0xa0
      00585A 80 02            [24] 2152 	sjmp	00104$
      00585C                       2153 00103$:
      00585C 8F 06            [24] 2154 	mov	ar6,r7
      00585E                       2155 00104$:
      00585E 90 06 C4         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005861 EE               [12] 2157 	mov	a,r6
      005862 F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005863 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      005864                       2170 _rgb_matrix_set_speed_noeeprom:
      005864 E5 82            [12] 2171 	mov	a,dpl
      005866 90 07 4A         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      005869 F0               [24] 2173 	movx	@dptr,a
      00586A E0               [24] 2174 	movx	a,@dptr
      00586B 90 06 C5         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00586E F0               [24] 2176 	movx	@dptr,a
      00586F 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      005870                       2187 _rgb_matrix_increase_hue_noeeprom:
      005870 90 06 C2         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005873 E0               [24] 2189 	movx	a,@dptr
      005874 24 08            [12] 2190 	add	a,#0x08
      005876 90 06 C2         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005879 F0               [24] 2192 	movx	@dptr,a
      00587A 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      00587B                       2201 _rgb_matrix_decrease_hue_noeeprom:
      00587B 90 06 C2         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00587E E0               [24] 2203 	movx	a,@dptr
      00587F 24 F8            [12] 2204 	add	a,#0xf8
      005881 90 06 C2         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005884 F0               [24] 2206 	movx	@dptr,a
      005885 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      005886                       2215 _rgb_matrix_increase_sat_noeeprom:
      005886 90 06 C3         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005889 12 59 50         [24] 2217 	lcall	_ak820_outline_0048
      00588C 12 52 6B         [24] 2218 	lcall	_add_sat
      00588F AF 82            [24] 2219 	mov	r7, dpl
      005891 90 06 C3         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005894 EF               [12] 2221 	mov	a,r7
      005895 F0               [24] 2222 	movx	@dptr,a
      005896 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      005897                       2231 _rgb_matrix_decrease_sat_noeeprom:
      005897 90 06 C3         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00589A 12 59 5B         [24] 2233 	lcall	_ak820_outline_0049
      00589D 12 52 90         [24] 2234 	lcall	_sub_sat
      0058A0 AF 82            [24] 2235 	mov	r7, dpl
      0058A2 90 06 C3         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0058A5 EF               [12] 2237 	mov	a,r7
      0058A6 F0               [24] 2238 	movx	@dptr,a
      0058A7 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      0058A8                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      0058A8 90 06 C4         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058AB 12 59 50         [24] 2252 	lcall	_ak820_outline_0048
      0058AE 12 52 6B         [24] 2253 	lcall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0058B1 E5 82            [12] 2255 	mov	a,dpl
      0058B3 FF               [12] 2256 	mov	r7,a
      0058B4 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      0058B6 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      0058B8 7E A0            [12] 2260 	mov	r6,#0xa0
      0058BA 80 02            [24] 2261 	sjmp	00104$
      0058BC                       2262 00103$:
      0058BC 8F 06            [24] 2263 	mov	ar6,r7
      0058BE                       2264 00104$:
      0058BE 90 06 C4         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058C1 EE               [12] 2266 	mov	a,r6
      0058C2 F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      0058C3 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      0058C4                       2277 _rgb_matrix_decrease_val_noeeprom:
      0058C4 90 06 C4         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058C7 12 59 5B         [24] 2279 	lcall	_ak820_outline_0049
      0058CA 12 52 90         [24] 2280 	lcall	_sub_sat
      0058CD AF 82            [24] 2281 	mov	r7, dpl
      0058CF 90 06 C4         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0058D2 EF               [12] 2283 	mov	a,r7
      0058D3 F0               [24] 2284 	movx	@dptr,a
      0058D4 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      0058D5                       2293 _rgb_matrix_increase_speed_noeeprom:
      0058D5 90 06 C5         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0058D8 12 59 50         [24] 2295 	lcall	_ak820_outline_0048
      0058DB 12 52 6B         [24] 2296 	lcall	_add_sat
      0058DE AF 82            [24] 2297 	mov	r7, dpl
      0058E0 90 06 C5         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0058E3 EF               [12] 2299 	mov	a,r7
      0058E4 F0               [24] 2300 	movx	@dptr,a
      0058E5 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      0058E6                       2309 _rgb_matrix_decrease_speed_noeeprom:
      0058E6 90 06 C5         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0058E9 12 59 5B         [24] 2311 	lcall	_ak820_outline_0049
      0058EC 12 52 90         [24] 2312 	lcall	_sub_sat
      0058EF AF 82            [24] 2313 	mov	r7, dpl
      0058F1 90 06 C5         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0058F4 EF               [12] 2315 	mov	a,r7
      0058F5 F0               [24] 2316 	movx	@dptr,a
      0058F6 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      0058F7                       2325 _rgb_matrix_toggle:
      0058F7 12 57 9D         [24] 2326 	lcall	_rgb_matrix_toggle_noeeprom
      0058FA 02 52 AD         [24] 2327 	ljmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      0058FD                       2335 _rgb_matrix_step:
      0058FD 12 58 06         [24] 2336 	lcall	_rgb_matrix_step_noeeprom
      005900 02 52 AD         [24] 2337 	ljmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      005903                       2345 _rgb_matrix_step_reverse:
      005903 12 58 20         [24] 2346 	lcall	_rgb_matrix_step_reverse_noeeprom
      005906 02 52 AD         [24] 2347 	ljmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      005909                       2355 _rgb_matrix_increase_hue:
      005909 12 58 70         [24] 2356 	lcall	_rgb_matrix_increase_hue_noeeprom
      00590C 02 52 AD         [24] 2357 	ljmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      00590F                       2365 _rgb_matrix_decrease_hue:
      00590F 12 58 7B         [24] 2366 	lcall	_rgb_matrix_decrease_hue_noeeprom
      005912 02 52 AD         [24] 2367 	ljmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      005915                       2375 _rgb_matrix_increase_sat:
      005915 12 58 86         [24] 2376 	lcall	_rgb_matrix_increase_sat_noeeprom
      005918 02 52 AD         [24] 2377 	ljmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      00591B                       2385 _rgb_matrix_decrease_sat:
      00591B 12 58 97         [24] 2386 	lcall	_rgb_matrix_decrease_sat_noeeprom
      00591E 02 52 AD         [24] 2387 	ljmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      005921                       2395 _rgb_matrix_increase_val:
      005921 12 58 A8         [24] 2396 	lcall	_rgb_matrix_increase_val_noeeprom
      005924 02 52 AD         [24] 2397 	ljmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      005927                       2405 _rgb_matrix_decrease_val:
      005927 12 58 C4         [24] 2406 	lcall	_rgb_matrix_decrease_val_noeeprom
      00592A 02 52 AD         [24] 2407 	ljmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      00592D                       2415 _rgb_matrix_increase_speed:
      00592D 12 58 D5         [24] 2416 	lcall	_rgb_matrix_increase_speed_noeeprom
      005930 02 52 AD         [24] 2417 	ljmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      005933                       2425 _rgb_matrix_decrease_speed:
      005933 12 58 E6         [24] 2426 	lcall	_rgb_matrix_decrease_speed_noeeprom
      005936 02 52 AD         [24] 2427 	ljmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      005939                       2437 _rgb_matrix_mode:
      005939 E5 82            [12] 2438 	mov	a,dpl
      00593B 90 07 4B         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      00593E 12 59 A9         [24] 2440 	lcall	_ak820_outline_0173
      005941 12 57 D1         [24] 2441 	lcall	_rgb_matrix_mode_noeeprom
      005944 02 52 AD         [24] 2442 	ljmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00BC31                       2455 _sine8_coefficients_10000_290:
      00BC31 00                    2456 	.db #0x00	; 0
      00BC32 31                    2457 	.db #0x31	; 49	'1'
      00BC33 31                    2458 	.db #0x31	; 49	'1'
      00BC34 29                    2459 	.db #0x29	; 41
      00BC35 5A                    2460 	.db #0x5a	; 90	'Z'
      00BC36 1B                    2461 	.db #0x1b	; 27
      00BC37 75                    2462 	.db #0x75	; 117	'u'
      00BC38 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0052
                                   2474 	.globl _ak820_outline_0060
                                   2475 	.globl _ak820_outline_0061
                                   2476 	.globl _ak820_outline_0066
                                   2477 	.globl _ak820_outline_0070
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0087
                                   2480 	.globl _ak820_outline_0103
                                   2481 	.globl _ak820_outline_0105
                                   2482 	.globl _ak820_outline_0109
                                   2483 	.globl _ak820_outline_0110
                                   2484 	.globl _ak820_outline_0111
                                   2485 	.globl _ak820_outline_0117
                                   2486 	.globl _ak820_outline_0126
                                   2487 	.globl _ak820_outline_0135
                                   2488 	.globl _ak820_outline_0136
                                   2489 	.globl _ak820_outline_0137
                                   2490 	.globl _ak820_outline_0140
                                   2491 	.globl _ak820_outline_0142
                                   2492 	.globl _ak820_outline_0162
                                   2493 	.globl _ak820_outline_0172
                                   2494 	.globl _ak820_outline_0173
                                   2495 	.globl _ak820_outline_0176
                                   2496 	.globl _ak820_outline_0181
                                   2497 	.globl _ak820_outline_0188
                                   2498 	.globl _ak820_outline_0190
                                   2499 	.globl _ak820_outline_0193
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      005947                       2503 _ak820_outline_0019:
      005947 90 06 C1         [24] 2504 	mov	dptr,#_rgb_matrix_config
      00594A E0               [24] 2505 	movx	a,@dptr
      00594B 03               [12] 2506 	rr	a
      00594C 03               [12] 2507 	rr	a
      00594D 54 3F            [12] 2508 	anl	a,#0x3f
      00594F 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      005950                       2513 _ak820_outline_0048:
      005950 E0               [24] 2514 	movx	a,@dptr
      005951 FF               [12] 2515 	mov	r7,a
      005952 90 07 2A         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      005955 74 10            [12] 2517 	mov	a,#0x10
      005957 F0               [24] 2518 	movx	@dptr,a
      005958 8F 82            [24] 2519 	mov	dpl,r7
      00595A 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      00595B                       2524 _ak820_outline_0049:
      00595B E0               [24] 2525 	movx	a,@dptr
      00595C FF               [12] 2526 	mov	r7,a
      00595D 90 07 2C         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005960 74 10            [12] 2528 	mov	a,#0x10
      005962 F0               [24] 2529 	movx	@dptr,a
      005963 8F 82            [24] 2530 	mov	dpl,r7
      005965 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0066
      005966                       2535 _ak820_outline_0066:
      005966 90 06 C1         [24] 2536 	mov	dptr,#_rgb_matrix_config
      005969 E0               [24] 2537 	movx	a,@dptr
      00596A 54 03            [12] 2538 	anl	a,#0x03
      00596C 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0070
      00596D                       2543 _ak820_outline_0070:
      00596D 74 08            [12] 2544 	mov	a,#0x08
      00596F F0               [24] 2545 	movx	@dptr,a
      005970 E4               [12] 2546 	clr	a
      005971 A3               [24] 2547 	inc	dptr
      005972 F0               [24] 2548 	movx	@dptr,a
      005973 90 06 C1         [24] 2549 	mov	dptr,#_rgb_matrix_config
      005976 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      005977                       2554 _ak820_outline_0073:
      005977 A3               [24] 2555 	inc	dptr
      005978 F0               [24] 2556 	movx	@dptr,a
      005979 E4               [12] 2557 	clr	a
      00597A A3               [24] 2558 	inc	dptr
      00597B F0               [24] 2559 	movx	@dptr,a
      00597C 90 0D C5         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      00597F 74 03            [12] 2561 	mov	a,#0x03
      005981 F0               [24] 2562 	movx	@dptr,a
      005982 E4               [12] 2563 	clr	a
      005983 A3               [24] 2564 	inc	dptr
      005984 F0               [24] 2565 	movx	@dptr,a
      005985 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0087
      005986                       2570 _ak820_outline_0087:
      005986 74 18            [12] 2571 	mov	a,#0x18
      005988 F0               [24] 2572 	movx	@dptr,a
      005989 E4               [12] 2573 	clr	a
      00598A A3               [24] 2574 	inc	dptr
      00598B F0               [24] 2575 	movx	@dptr,a
      00598C A3               [24] 2576 	inc	dptr
      00598D F0               [24] 2577 	movx	@dptr,a
      00598E 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0111
      00598F                       2582 _ak820_outline_0111:
      00598F 35 F0            [12] 2583 	addc	a,b
      005991 F5 83            [12] 2584 	mov	dph,a
      005993 E4               [12] 2585 	clr	a
      005994 93               [24] 2586 	movc	a,@a+dptr
      005995 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0117
      005996                       2591 _ak820_outline_0117:
      005996 90 06 C1         [24] 2592 	mov	dptr,#_rgb_matrix_config
      005999 E0               [24] 2593 	movx	a,@dptr
      00599A 54 FC            [12] 2594 	anl	a,#0xfc
      00599C 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0142
      00599D                       2599 _ak820_outline_0142:
      00599D 90 06 D0         [24] 2600 	mov	dptr,#_frame_mode
      0059A0 E0               [24] 2601 	movx	a,@dptr
      0059A1 FE               [12] 2602 	mov	r6,a
      0059A2 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0172
      0059A3                       2607 _ak820_outline_0172:
      0059A3 F0               [24] 2608 	movx	@dptr,a
      0059A4 E5 F0            [12] 2609 	mov	a,b
      0059A6 A3               [24] 2610 	inc	dptr
      0059A7 F0               [24] 2611 	movx	@dptr,a
      0059A8 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0173
      0059A9                       2616 _ak820_outline_0173:
      0059A9 F0               [24] 2617 	movx	@dptr,a
      0059AA E0               [24] 2618 	movx	a,@dptr
      0059AB F5 82            [12] 2619 	mov	dpl,a
      0059AD 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0176
      0059AE                       2624 _ak820_outline_0176:
      0059AE 90 06 C5         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      0059B1 E0               [24] 2626 	movx	a,@dptr
      0059B2 23               [12] 2627 	rl	a
      0059B3 23               [12] 2628 	rl	a
      0059B4 54 03            [12] 2629 	anl	a,#0x03
      0059B6 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0181
      0059B7                       2634 _ak820_outline_0181:
      0059B7 90 0D CA         [24] 2635 	mov	dptr,#_memset_PARM_2
      0059BA E4               [12] 2636 	clr	a
      0059BB F0               [24] 2637 	movx	@dptr,a
      0059BC 90 0D CB         [24] 2638 	mov	dptr,#_memset_PARM_3
      0059BF 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0188
      0059C0                       2643 _ak820_outline_0188:
      0059C0 90 06 CF         [24] 2644 	mov	dptr,#_led_index
      0059C3 E0               [24] 2645 	movx	a,@dptr
      0059C4 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0190
      0059C5                       2650 _ak820_outline_0190:
      0059C5 C4               [12] 2651 	swap	a
      0059C6 23               [12] 2652 	rl	a
      0059C7 54 1F            [12] 2653 	anl	a,#0x1f
      0059C9 22               [24] 2654 	ret
