                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_287:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_287:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_287:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_287:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00077B                        602 _D0SetupReqCode::
      00077B                        603 	.ds 1
      00077C                        604 _D0SetupLen::
      00077C                        605 	.ds 2
      00077E                        606 _pD0Descr::
      00077E                        607 	.ds 3
      000781                        608 _D0UsbConfig::
      000781                        609 	.ds 1
      000782                        610 _USB_EnumStatus::
      000782                        611 	.ds 1
      000783                        612 _USB_SleepStatus::
      000783                        613 	.ds 1
      000784                        614 _MCU_Sleep_Operate::
      000784                        615 	.ds 1
      000785                        616 _KB_USB_UpStatus::
      000785                        617 	.ds 1
      000786                        618 _KB_USB_SetReport::
      000786                        619 	.ds 1
      000787                        620 _ak820_boot_stage::
      000787                        621 	.ds 1
      000788                        622 _ak820_main_heartbeat::
      000788                        623 	.ds 1
      000789                        624 _raw_state:
      000789                        625 	.ds 1
      00078A                        626 _raw_buffer:
      00078A                        627 	.ds 32
      0007AA                        628 _raw_reply_without_nvm:
      0007AA                        629 	.ds 1
      0007AB                        630 _keyboard_reset:
      0007AB                        631 	.ds 1
      0007AC                        632 _input_snapshot:
      0007AC                        633 	.ds 52
      0007E0                        634 _control_phase:
      0007E0                        635 	.ds 1
      0007E1                        636 _output_kind:
      0007E1                        637 	.ds 1
      0007E2                        638 _output_report_id:
      0007E2                        639 	.ds 1
      0007E3                        640 _control_zlp:
      0007E3                        641 	.ds 1
      0007E4                        642 _control_pointer:
      0007E4                        643 	.ds 2
      0007E6                        644 _descriptor_select_PARM_2:
      0007E6                        645 	.ds 1
      0007E7                        646 _descriptor_select_PARM_3:
      0007E7                        647 	.ds 2
      0007E9                        648 _descriptor_select_type_10000_269:
      0007E9                        649 	.ds 1
      0007EA                        650 _control_setup_length_10000_287:
      0007EA                        651 	.ds 2
      0007EC                        652 _control_setup_offset_10000_287:
      0007EC                        653 	.ds 1
      0007ED                        654 _ak820_usb_send_PARM_2:
      0007ED                        655 	.ds 2
      0007EF                        656 _ak820_usb_send_PARM_3:
      0007EF                        657 	.ds 1
      0007F0                        658 _ak820_usb_send_endpoint_10000_423:
      0007F0                        659 	.ds 1
      0007F1                        660 _ak820_usb_send_offset_10000_424:
      0007F1                        661 	.ds 1
      0007F2                        662 _ak820_usb_try_send_PARM_2:
      0007F2                        663 	.ds 2
      0007F4                        664 _ak820_usb_try_send_PARM_3:
      0007F4                        665 	.ds 1
      0007F5                        666 _ak820_usb_try_send_endpoint_10000_444:
      0007F5                        667 	.ds 1
      0007F6                        668 _ak820_usb_try_send_sent_10000_445:
      0007F6                        669 	.ds 1
      0007F7                        670 _ak820_usb_raw_send_PARM_2:
      0007F7                        671 	.ds 1
      0007F8                        672 _ak820_usb_raw_send_report_10000_460:
      0007F8                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005CC7                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005CC7 90 07 89         [24]  727 	mov	dptr,#_raw_state
      005CCA E0               [24]  728 	movx	a,@dptr
      005CCB FF               [12]  729 	mov	r7,a
      005CCC BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005CCF 80 1C            [24]  731 	sjmp	00101$
      005CD1                        732 00130$:
      005CD1 90 07 89         [24]  733 	mov	dptr,#_raw_state
      005CD4 E0               [24]  734 	movx	a,@dptr
      005CD5 FF               [12]  735 	mov	r7,a
      005CD6 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005CD9 80 12            [24]  737 	sjmp	00101$
      005CDB                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005CDB 90 07 89         [24]  740 	mov	dptr,#_raw_state
      005CDE E0               [24]  741 	movx	a,@dptr
      005CDF FF               [12]  742 	mov	r7,a
      005CE0 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005CE3 80 08            [24]  744 	sjmp	00101$
      005CE5                        745 00132$:
      005CE5 90 07 89         [24]  746 	mov	dptr,#_raw_state
      005CE8 E0               [24]  747 	movx	a,@dptr
      005CE9 FF               [12]  748 	mov	r7,a
      005CEA BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005CED                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005CED 90 07 89         [24]  752 	mov	dptr,#_raw_state
      005CF0 74 07            [12]  753 	mov	a,#0x07
      005CF2 F0               [24]  754 	movx	@dptr,a
      005CF3 80 05            [24]  755 	sjmp	00103$
      005CF5                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005CF5 90 07 89         [24]  758 	mov	dptr,#_raw_state
      005CF8 E4               [12]  759 	clr	a
      005CF9 F0               [24]  760 	movx	@dptr,a
      005CFA                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005CFA 90 07 E1         [24]  763 	mov	dptr,#_output_kind
      005CFD E4               [12]  764 	clr	a
      005CFE F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005CFF 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005D00                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005D00 90 07 89         [24]  777 	mov	dptr,#_raw_state
      005D03 E0               [24]  778 	movx	a,@dptr
      005D04 FF               [12]  779 	mov	r7,a
      005D05 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005D08 90 07 89         [24]  781 	mov	dptr,#_raw_state
      005D0B 74 06            [12]  782 	mov	a,#0x06
      005D0D F0               [24]  783 	movx	@dptr,a
      005D0E 22               [24]  784 	ret
      005D0F                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005D0F 90 07 89         [24]  787 	mov	dptr,#_raw_state
      005D12 E0               [24]  788 	movx	a,@dptr
      005D13 FF               [12]  789 	mov	r7,a
      005D14 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005D17 90 07 89         [24]  791 	mov	dptr,#_raw_state
      005D1A E4               [12]  792 	clr	a
      005D1B F0               [24]  793 	movx	@dptr,a
      005D1C                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005D1C 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005D1D                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005D1D 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005D20 74 01            [12]  809 	mov	a,#0x01
      005D22 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D23 F5 82            [12]  812 	mov	dpl,a
      005D25 74 12            [12]  813 	mov	a,#0x12
      005D27 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D28 A3               [24]  816 	inc	dptr
      005D29 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D2A A3               [24]  819 	inc	dptr
      005D2B F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005D2C 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005D2F E4               [12]  823 	clr	a
      005D30 F0               [24]  824 	movx	@dptr,a
      005D31 15 82            [12]  825 	dec	dpl
      005D33 F0               [24]  826 	movx	@dptr,a
      005D34 15 82            [12]  827 	dec	dpl
      005D36 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005D37 FF               [12]  830 	mov	r7,a
      005D38                        831 00103$:
      005D38 EF               [12]  832 	mov	a,r7
      005D39 24 AC            [12]  833 	add	a, #_input_snapshot
      005D3B F5 82            [12]  834 	mov	dpl,a
      005D3D E4               [12]  835 	clr	a
      005D3E 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005D40 F5 83            [12]  837 	mov	dph,a
      005D42 E4               [12]  838 	clr	a
      005D43 F0               [24]  839 	movx	@dptr,a
      005D44 0F               [12]  840 	inc	r7
      005D45 BF 34 00         [24]  841 	cjne	r7,#0x34,00139$
      005D48                        842 00139$:
      005D48 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005D4A 90 07 B4         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005D4D 74 06            [12]  846 	mov	a,#0x06
      005D4F F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:118: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005D50 90 07 D4         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005D53 74 02            [12]  850 	mov	a,#0x02
      005D55 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005D56 90 07 DA         [24]  853 	mov	dptr,#(_input_snapshot + 0x002e)
      005D59 04               [12]  854 	inc	a
      005D5A F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005D5B 90 07 DD         [24]  857 	mov	dptr,#(_input_snapshot + 0x0031)
      005D5E 04               [12]  858 	inc	a
      005D5F F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005D60 7F 00            [12]  861 	mov	r7,#0x00
      005D62                        862 00105$:
      005D62 8F 06            [24]  863 	mov	ar6,r7
      005D64 74 C0            [12]  864 	mov	a,#0xc0
      005D66 2E               [12]  865 	add	a, r6
      005D67 F5 82            [12]  866 	mov	dpl,a
      005D69 74 10            [12]  867 	mov	a,#0x10
      005D6B 24 00            [12]  868 	add	a, #0x00
      005D6D F5 83            [12]  869 	mov	dph,a
      005D6F E4               [12]  870 	clr	a
      005D70 F0               [24]  871 	movx	@dptr,a
      005D71 0F               [12]  872 	inc	r7
      005D72 BF 20 00         [24]  873 	cjne	r7,#0x20,00141$
      005D75                        874 00141$:
      005D75 40 EB            [24]  875 	jc	00105$
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    877 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005D77 02 5C C7         [24]  878 	ljmp	_raw_abort
                                    879 ;------------------------------------------------------------
                                    880 ;Allocation info for local variables in function 'control_stall'
                                    881 ;------------------------------------------------------------
                                    882 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function control_stall
                                    885 ;	-----------------------------------------
      005D7A                        886 _control_stall:
                                    887 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005D7A 90 07 89         [24]  888 	mov	dptr,#_raw_state
      005D7D E0               [24]  889 	movx	a,@dptr
      005D7E FF               [12]  890 	mov	r7,a
      005D7F BF 01 05         [24]  891 	cjne	r7,#0x01,00102$
      005D82 90 07 89         [24]  892 	mov	dptr,#_raw_state
      005D85 E4               [12]  893 	clr	a
      005D86 F0               [24]  894 	movx	@dptr,a
      005D87                        895 00102$:
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005D87 90 07 E1         [24]  897 	mov	dptr,#_output_kind
      005D8A E4               [12]  898 	clr	a
      005D8B F0               [24]  899 	movx	@dptr,a
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005D8C 90 07 E0         [24]  901 	mov	dptr,#_control_phase
      005D8F F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005D90 90 07 7B         [24]  904 	mov	dptr,#_D0SetupReqCode
      005D93 14               [12]  905 	dec	a
      005D94 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005D95 90 22 00         [24]  908 	mov	dptr,#0x2200
      005D98 74 CF            [12]  909 	mov	a,#0xcf
      005D9A F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005D9B 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'control_next'
                                    915 ;------------------------------------------------------------
                                    916 ;i             Allocated with name '_control_next_i_10000_266'
                                    917 ;length        Allocated with name '_control_next_length_10000_266'
                                    918 ;------------------------------------------------------------
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    920 ;	-----------------------------------------
                                    921 ;	 function control_next
                                    922 ;	-----------------------------------------
      005D9C                        923 _control_next:
                                    924 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005D9C 90 07 7C         [24]  925 	mov	dptr,#_D0SetupLen
      005D9F E0               [24]  926 	movx	a,@dptr
      005DA0 FE               [12]  927 	mov	r6,a
      005DA1 A3               [24]  928 	inc	dptr
      005DA2 E0               [24]  929 	movx	a,@dptr
      005DA3 FF               [12]  930 	mov	r7,a
      005DA4 C3               [12]  931 	clr	c
      005DA5 74 40            [12]  932 	mov	a,#0x40
      005DA7 9E               [12]  933 	subb	a,r6
      005DA8 E4               [12]  934 	clr	a
      005DA9 9F               [12]  935 	subb	a,r7
      005DAA 50 04            [24]  936 	jnc	00109$
                                    937 ;	free result
      005DAC 7E 40            [12]  938 	mov	r6,#0x40
      005DAE 80 07            [24]  939 	sjmp	00110$
      005DB0                        940 00109$:
      005DB0 90 07 7C         [24]  941 	mov	dptr,#_D0SetupLen
      005DB3 E0               [24]  942 	movx	a,@dptr
      005DB4 FE               [12]  943 	mov	r6,a
      005DB5 A3               [24]  944 	inc	dptr
      005DB6 E0               [24]  945 	movx	a,@dptr
      005DB7                        946 00110$:
                                    947 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005DB7 7F 00            [12]  948 	mov	r7,#0x00
      005DB9                        949 00105$:
      005DB9 C3               [12]  950 	clr	c
      005DBA EF               [12]  951 	mov	a,r7
      005DBB 9E               [12]  952 	subb	a,r6
      005DBC 50 2A            [24]  953 	jnc	00101$
      005DBE 8F 04            [24]  954 	mov	ar4,r7
      005DC0 74 10            [12]  955 	mov	a,#0x10
      005DC2 24 00            [12]  956 	add	a, #0x00
      005DC4 FD               [12]  957 	mov	r5,a
      005DC5 90 07 E4         [24]  958 	mov	dptr,#_control_pointer
      005DC8 E0               [24]  959 	movx	a,@dptr
      005DC9 FA               [12]  960 	mov	r2,a
      005DCA A3               [24]  961 	inc	dptr
      005DCB E0               [24]  962 	movx	a,@dptr
      005DCC FB               [12]  963 	mov	r3,a
      005DCD 8A 82            [24]  964 	mov	dpl,r2
      005DCF 8B 83            [24]  965 	mov	dph,r3
      005DD1 E4               [12]  966 	clr	a
      005DD2 93               [24]  967 	movc	a,@a+dptr
      005DD3 F9               [12]  968 	mov	r1,a
      005DD4 90 07 E4         [24]  969 	mov	dptr,#_control_pointer
      005DD7 74 01            [12]  970 	mov	a,#0x01
      005DD9 2A               [12]  971 	add	a, r2
      005DDA F0               [24]  972 	movx	@dptr,a
      005DDB E4               [12]  973 	clr	a
      005DDC 3B               [12]  974 	addc	a, r3
      005DDD A3               [24]  975 	inc	dptr
      005DDE F0               [24]  976 	movx	@dptr,a
      005DDF 8C 82            [24]  977 	mov	dpl,r4
      005DE1 8D 83            [24]  978 	mov	dph,r5
      005DE3 E9               [12]  979 	mov	a,r1
      005DE4 F0               [24]  980 	movx	@dptr,a
      005DE5 0F               [12]  981 	inc	r7
      005DE6 80 D1            [24]  982 	sjmp	00105$
      005DE8                        983 00101$:
                                    984 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005DE8 8E 05            [24]  985 	mov	ar5,r6
      005DEA 7F 00            [12]  986 	mov	r7,#0x00
      005DEC 90 07 7C         [24]  987 	mov	dptr,#_D0SetupLen
      005DEF E0               [24]  988 	movx	a,@dptr
      005DF0 FB               [12]  989 	mov	r3,a
      005DF1 A3               [24]  990 	inc	dptr
      005DF2 E0               [24]  991 	movx	a,@dptr
      005DF3 FC               [12]  992 	mov	r4,a
      005DF4 EB               [12]  993 	mov	a,r3
      005DF5 C3               [12]  994 	clr	c
      005DF6 9D               [12]  995 	subb	a,r5
      005DF7 FB               [12]  996 	mov	r3,a
      005DF8 EC               [12]  997 	mov	a,r4
      005DF9 9F               [12]  998 	subb	a,r7
      005DFA FC               [12]  999 	mov	r4,a
      005DFB 90 07 7C         [24] 1000 	mov	dptr,#_D0SetupLen
      005DFE EB               [12] 1001 	mov	a,r3
      005DFF F0               [24] 1002 	movx	@dptr,a
      005E00 EC               [12] 1003 	mov	a,r4
      005E01 A3               [24] 1004 	inc	dptr
      005E02 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005E03 EE               [12] 1007 	mov	a,r6
      005E04 70 05            [24] 1008 	jnz	00103$
      005E06 90 07 E3         [24] 1009 	mov	dptr,#_control_zlp
      005E09 E4               [12] 1010 	clr	a
      005E0A F0               [24] 1011 	movx	@dptr,a
      005E0B                       1012 00103$:
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005E0B 90 22 08         [24] 1014 	mov	dptr,#0x2208
      005E0E EE               [12] 1015 	mov	a,r6
      005E0F F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005E10 90 22 00         [24] 1018 	mov	dptr,#0x2200
      005E13 E0               [24] 1019 	movx	a,@dptr
      005E14 54 C0            [12] 1020 	anl	a,#0xc0
      005E16 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005E17 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'descriptor_select'
                                   1026 ;------------------------------------------------------------
                                   1027 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1028 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1029 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1030 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function descriptor_select
                                   1035 ;	-----------------------------------------
      005E18                       1036 _descriptor_select:
      005E18 E5 82            [12] 1037 	mov	a,dpl
      005E1A 90 07 E9         [24] 1038 	mov	dptr,#_descriptor_select_type_10000_269
      005E1D F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005E1E E0               [24] 1041 	movx	a,@dptr
      005E1F FF               [12] 1042 	mov	r7,a
      005E20 BF 01 20         [24] 1043 	cjne	r7,#0x01,00102$
      005E23 90 07 E6         [24] 1044 	mov	dptr,#_descriptor_select_PARM_2
      005E26 E0               [24] 1045 	movx	a,@dptr
      005E27 70 1A            [24] 1046 	jnz	00102$
      005E29 90 07 E7         [24] 1047 	mov	dptr,#_descriptor_select_PARM_3
      005E2C E0               [24] 1048 	movx	a,@dptr
      005E2D F5 F0            [12] 1049 	mov	b,a
      005E2F A3               [24] 1050 	inc	dptr
      005E30 E0               [24] 1051 	movx	a,@dptr
      005E31 45 F0            [12] 1052 	orl	a,b
      005E33 70 0E            [24] 1053 	jnz	00102$
                                   1054 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005E35 90 07 E4         [24] 1055 	mov	dptr,#_control_pointer
      005E38 74 17            [12] 1056 	mov	a,#_DeviceDescriptor
      005E3A F0               [24] 1057 	movx	@dptr,a
      005E3B 74 C3            [12] 1058 	mov	a,#(_DeviceDescriptor >> 8)
      005E3D A3               [24] 1059 	inc	dptr
      005E3E F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005E3F 90 00 12         [24] 1062 	mov	dptr,#0x0012
      005E42 22               [24] 1063 	ret
      005E43                       1064 00102$:
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005E43 90 07 E9         [24] 1066 	mov	dptr,#_descriptor_select_type_10000_269
      005E46 E0               [24] 1067 	movx	a,@dptr
      005E47 FF               [12] 1068 	mov	r7,a
      005E48 BF 02 20         [24] 1069 	cjne	r7,#0x02,00106$
      005E4B 90 07 E6         [24] 1070 	mov	dptr,#_descriptor_select_PARM_2
      005E4E E0               [24] 1071 	movx	a,@dptr
      005E4F 70 1A            [24] 1072 	jnz	00106$
      005E51 90 07 E7         [24] 1073 	mov	dptr,#_descriptor_select_PARM_3
      005E54 E0               [24] 1074 	movx	a,@dptr
      005E55 F5 F0            [12] 1075 	mov	b,a
      005E57 A3               [24] 1076 	inc	dptr
      005E58 E0               [24] 1077 	movx	a,@dptr
      005E59 45 F0            [12] 1078 	orl	a,b
      005E5B 70 0E            [24] 1079 	jnz	00106$
                                   1080 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005E5D 90 07 E4         [24] 1081 	mov	dptr,#_control_pointer
      005E60 74 29            [12] 1082 	mov	a,#_ConfigurationDescriptor
      005E62 F0               [24] 1083 	movx	@dptr,a
      005E63 74 C3            [12] 1084 	mov	a,#(_ConfigurationDescriptor >> 8)
      005E65 A3               [24] 1085 	inc	dptr
      005E66 F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005E67 90 00 54         [24] 1088 	mov	dptr,#0x0054
      005E6A 22               [24] 1089 	ret
      005E6B                       1090 00106$:
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005E6B 90 07 E9         [24] 1092 	mov	dptr,#_descriptor_select_type_10000_269
      005E6E E0               [24] 1093 	movx	a,@dptr
      005E6F FF               [12] 1094 	mov	r7,a
      005E70 BF 03 02         [24] 1095 	cjne	r7,#0x03,00238$
      005E73 80 03            [24] 1096 	sjmp	00239$
      005E75                       1097 00238$:
      005E75 02 5F 0F         [24] 1098 	ljmp	00119$
      005E78                       1099 00239$:
                                   1100 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005E78 90 07 E7         [24] 1101 	mov	dptr,#_descriptor_select_PARM_3
      005E7B E0               [24] 1102 	movx	a,@dptr
      005E7C FD               [12] 1103 	mov	r5,a
      005E7D A3               [24] 1104 	inc	dptr
      005E7E E0               [24] 1105 	movx	a,@dptr
      005E7F FE               [12] 1106 	mov	r6,a
      005E80 90 07 E7         [24] 1107 	mov	dptr,#_descriptor_select_PARM_3
      005E83 E0               [24] 1108 	movx	a,@dptr
      005E84 F5 F0            [12] 1109 	mov	b,a
      005E86 A3               [24] 1110 	inc	dptr
      005E87 E0               [24] 1111 	movx	a,@dptr
      005E88 45 F0            [12] 1112 	orl	a,b
      005E8A 60 0C            [24] 1113 	jz	00110$
      005E8C BD 09 05         [24] 1114 	cjne	r5,#0x09,00241$
      005E8F BE 04 02         [24] 1115 	cjne	r6,#0x04,00241$
      005E92 80 04            [24] 1116 	sjmp	00110$
      005E94                       1117 00241$:
      005E94 90 00 00         [24] 1118 	mov	dptr,#0x0000
      005E97 22               [24] 1119 	ret
      005E98                       1120 00110$:
                                   1121 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005E98 90 07 E6         [24] 1122 	mov	dptr,#_descriptor_select_PARM_2
      005E9B E0               [24] 1123 	movx	a,@dptr
      005E9C FE               [12] 1124 	mov  r6,a
      005E9D 24 FC            [12] 1125 	add	a,#0xff - 0x03
      005E9F 40 6A            [24] 1126 	jc	00116$
                                   1127 ;	free result
      005EA1 EE               [12] 1128 	mov	a,r6
      005EA2 2E               [12] 1129 	add	a,r6
                                   1130 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005EA3 90 5E A7         [24] 1131 	mov	dptr,#00243$
      005EA6 73               [24] 1132 	jmp	@a+dptr
      005EA7                       1133 00243$:
      005EA7 80 06            [24] 1134 	sjmp	00112$
      005EA9 80 1B            [24] 1135 	sjmp	00113$
      005EAB 80 30            [24] 1136 	sjmp	00114$
      005EAD 80 45            [24] 1137 	sjmp	00115$
      005EAF                       1138 00112$:
      005EAF 90 07 E4         [24] 1139 	mov	dptr,#_control_pointer
      005EB2 74 7D            [12] 1140 	mov	a,#_LanguageString
      005EB4 F0               [24] 1141 	movx	@dptr,a
      005EB5 74 C3            [12] 1142 	mov	a,#(_LanguageString >> 8)
      005EB7 A3               [24] 1143 	inc	dptr
      005EB8 F0               [24] 1144 	movx	@dptr,a
      005EB9 90 C3 7D         [24] 1145 	mov	dptr,#_LanguageString
      005EBC E4               [12] 1146 	clr	a
      005EBD 93               [24] 1147 	movc	a,@a+dptr
      005EBE FE               [12] 1148 	mov	r6,a
      005EBF 7D 00            [12] 1149 	mov	r5,#0x00
      005EC1 8E 82            [24] 1150 	mov	dpl, r6
      005EC3 8D 83            [24] 1151 	mov	dph, r5
      005EC5 22               [24] 1152 	ret
                                   1153 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005EC6                       1154 00113$:
      005EC6 90 07 E4         [24] 1155 	mov	dptr,#_control_pointer
      005EC9 74 81            [12] 1156 	mov	a,#_ManufacturerString
      005ECB F0               [24] 1157 	movx	@dptr,a
      005ECC 74 C3            [12] 1158 	mov	a,#(_ManufacturerString >> 8)
      005ECE A3               [24] 1159 	inc	dptr
      005ECF F0               [24] 1160 	movx	@dptr,a
      005ED0 90 C3 81         [24] 1161 	mov	dptr,#_ManufacturerString
      005ED3 E4               [12] 1162 	clr	a
      005ED4 93               [24] 1163 	movc	a,@a+dptr
      005ED5 FE               [12] 1164 	mov	r6,a
      005ED6 7D 00            [12] 1165 	mov	r5,#0x00
      005ED8 8E 82            [24] 1166 	mov	dpl, r6
      005EDA 8D 83            [24] 1167 	mov	dph, r5
      005EDC 22               [24] 1168 	ret
                                   1169 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005EDD                       1170 00114$:
      005EDD 90 07 E4         [24] 1171 	mov	dptr,#_control_pointer
      005EE0 74 8F            [12] 1172 	mov	a,#_ProductString
      005EE2 F0               [24] 1173 	movx	@dptr,a
      005EE3 74 C3            [12] 1174 	mov	a,#(_ProductString >> 8)
      005EE5 A3               [24] 1175 	inc	dptr
      005EE6 F0               [24] 1176 	movx	@dptr,a
      005EE7 90 C3 8F         [24] 1177 	mov	dptr,#_ProductString
      005EEA E4               [12] 1178 	clr	a
      005EEB 93               [24] 1179 	movc	a,@a+dptr
      005EEC FE               [12] 1180 	mov	r6,a
      005EED 7D 00            [12] 1181 	mov	r5,#0x00
      005EEF 8E 82            [24] 1182 	mov	dpl, r6
      005EF1 8D 83            [24] 1183 	mov	dph, r5
      005EF3 22               [24] 1184 	ret
                                   1185 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005EF4                       1186 00115$:
      005EF4 90 07 E4         [24] 1187 	mov	dptr,#_control_pointer
      005EF7 74 C7            [12] 1188 	mov	a,#_SerialNumberString
      005EF9 F0               [24] 1189 	movx	@dptr,a
      005EFA 74 C3            [12] 1190 	mov	a,#(_SerialNumberString >> 8)
      005EFC A3               [24] 1191 	inc	dptr
      005EFD F0               [24] 1192 	movx	@dptr,a
      005EFE 90 C3 C7         [24] 1193 	mov	dptr,#_SerialNumberString
      005F01 E4               [12] 1194 	clr	a
      005F02 93               [24] 1195 	movc	a,@a+dptr
      005F03 FE               [12] 1196 	mov	r6,a
      005F04 7D 00            [12] 1197 	mov	r5,#0x00
      005F06 8E 82            [24] 1198 	mov	dpl, r6
      005F08 8D 83            [24] 1199 	mov	dph, r5
      005F0A 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005F0B                       1202 00116$:
      005F0B 90 00 00         [24] 1203 	mov	dptr,#0x0000
      005F0E 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005F0F                       1206 00119$:
                                   1207 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005F0F 90 07 E6         [24] 1208 	mov	dptr,#_descriptor_select_PARM_2
      005F12 E0               [24] 1209 	movx	a,@dptr
      005F13 70 11            [24] 1210 	jnz	00120$
      005F15 90 07 E7         [24] 1211 	mov	dptr,#_descriptor_select_PARM_3
      005F18 E0               [24] 1212 	movx	a,@dptr
      005F19 FD               [12] 1213 	mov	r5,a
      005F1A A3               [24] 1214 	inc	dptr
      005F1B E0               [24] 1215 	movx	a,@dptr
      005F1C FE               [12] 1216 	mov	r6,a
      005F1D C3               [12] 1217 	clr	c
      005F1E ED               [12] 1218 	mov	a,r5
      005F1F 94 03            [12] 1219 	subb	a,#0x03
      005F21 EE               [12] 1220 	mov	a,r6
      005F22 94 00            [12] 1221 	subb	a,#0x00
      005F24 40 04            [24] 1222 	jc	00121$
      005F26                       1223 00120$:
      005F26 90 00 00         [24] 1224 	mov	dptr,#0x0000
      005F29 22               [24] 1225 	ret
      005F2A                       1226 00121$:
                                   1227 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005F2A BF 22 02         [24] 1228 	cjne	r7,#0x22,00246$
      005F2D 80 03            [24] 1229 	sjmp	00127$
      005F2F                       1230 00246$:
      005F2F BF 21 5D         [24] 1231 	cjne	r7,#0x21,00128$
      005F32                       1232 00127$:
                                   1233 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005F32 ED               [12] 1234 	mov	a,r5
      005F33 75 F0 04         [24] 1235 	mov	b,#0x04
      005F36 A4               [48] 1236 	mul	ab
      005F37 24 4F            [12] 1237 	add	a, #_interface_descriptors
      005F39 FE               [12] 1238 	mov	r6,a
      005F3A 74 BC            [12] 1239 	mov	a,#(_interface_descriptors >> 8)
      005F3C 35 F0            [12] 1240 	addc	a, b
      005F3E FF               [12] 1241 	mov	r7,a
      005F3F 8E 82            [24] 1242 	mov	dpl,r6
      005F41 8F 83            [24] 1243 	mov	dph,r7
      005F43 A3               [24] 1244 	inc	dptr
      005F44 A3               [24] 1245 	inc	dptr
      005F45 E4               [12] 1246 	clr	a
      005F46 93               [24] 1247 	movc	a,@a+dptr
      005F47 FC               [12] 1248 	mov	r4,a
      005F48 A3               [24] 1249 	inc	dptr
      005F49 E4               [12] 1250 	clr	a
      005F4A 93               [24] 1251 	movc	a,@a+dptr
                                   1252 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005F4B FD               [12] 1253 	mov	r5,a
      005F4C 4C               [12] 1254 	orl	a,r4
      005F4D 70 04            [24] 1255 	jnz	00124$
      005F4F 90 00 00         [24] 1256 	mov	dptr,#0x0000
      005F52 22               [24] 1257 	ret
      005F53                       1258 00124$:
                                   1259 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005F53 90 07 E9         [24] 1260 	mov	dptr,#_descriptor_select_type_10000_269
      005F56 E0               [24] 1261 	movx	a,@dptr
      005F57 FB               [12] 1262 	mov	r3,a
      005F58 BB 22 28         [24] 1263 	cjne	r3,#0x22,00126$
                                   1264 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005F5B 8E 82            [24] 1265 	mov	dpl,r6
      005F5D 8F 83            [24] 1266 	mov	dph,r7
      005F5F E4               [12] 1267 	clr	a
      005F60 93               [24] 1268 	movc	a,@a+dptr
      005F61 FE               [12] 1269 	mov	r6,a
      005F62 A3               [24] 1270 	inc	dptr
      005F63 E4               [12] 1271 	clr	a
      005F64 93               [24] 1272 	movc	a,@a+dptr
      005F65 FF               [12] 1273 	mov	r7,a
      005F66 90 07 E4         [24] 1274 	mov	dptr,#_control_pointer
      005F69 EE               [12] 1275 	mov	a,r6
      005F6A F0               [24] 1276 	movx	@dptr,a
      005F6B EF               [12] 1277 	mov	a,r7
      005F6C A3               [24] 1278 	inc	dptr
      005F6D F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005F6E 74 07            [12] 1281 	mov	a,#0x07
      005F70 2C               [12] 1282 	add	a, r4
      005F71 F5 82            [12] 1283 	mov	dpl,a
      005F73 E4               [12] 1284 	clr	a
      005F74 3D               [12] 1285 	addc	a, r5
      005F75 F5 83            [12] 1286 	mov	dph,a
      005F77 E4               [12] 1287 	clr	a
      005F78 93               [24] 1288 	movc	a,@a+dptr
      005F79 FE               [12] 1289 	mov	r6,a
      005F7A A3               [24] 1290 	inc	dptr
      005F7B E4               [12] 1291 	clr	a
      005F7C 93               [24] 1292 	movc	a,@a+dptr
      005F7D FF               [12] 1293 	mov	r7,a
      005F7E 8E 82            [24] 1294 	mov	dpl, r6
      005F80 8F 83            [24] 1295 	mov	dph, r7
      005F82 22               [24] 1296 	ret
      005F83                       1297 00126$:
                                   1298 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005F83 90 07 E4         [24] 1299 	mov	dptr,#_control_pointer
      005F86 EC               [12] 1300 	mov	a,r4
      005F87 F0               [24] 1301 	movx	@dptr,a
      005F88 ED               [12] 1302 	mov	a,r5
      005F89 A3               [24] 1303 	inc	dptr
      005F8A F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005F8B 90 00 09         [24] 1306 	mov	dptr,#0x0009
      005F8E 22               [24] 1307 	ret
      005F8F                       1308 00128$:
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005F8F 90 00 00         [24] 1310 	mov	dptr,#0x0000
                                   1311 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005F92 22               [24] 1312 	ret
                                   1313 ;------------------------------------------------------------
                                   1314 ;Allocation info for local variables in function 'control_setup'
                                   1315 ;------------------------------------------------------------
                                   1316 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1317 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1318 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1319 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1320 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1321 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1322 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1323 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1324 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1325 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1326 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1327 ;------------------------------------------------------------
                                   1328 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1329 ;	-----------------------------------------
                                   1330 ;	 function control_setup
                                   1331 ;	-----------------------------------------
      005F93                       1332 _control_setup:
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005F93 90 10 00         [24] 1334 	mov	dptr,#0x1000
      005F96 E0               [24] 1335 	movx	a,@dptr
      005F97 FF               [12] 1336 	mov	r7,a
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005F98 A3               [24] 1338 	inc	dptr
      005F99 A3               [24] 1339 	inc	dptr
      005F9A E0               [24] 1340 	movx	a,@dptr
      005F9B FE               [12] 1341 	mov	r6,a
      005F9C A3               [24] 1342 	inc	dptr
      005F9D E0               [24] 1343 	movx	a,@dptr
      005F9E FC               [12] 1344 	mov	r4,a
      005F9F 7D 00            [12] 1345 	mov	r5,#0x00
      005FA1 8E 03            [24] 1346 	mov	ar3,r6
      005FA3 7E 00            [12] 1347 	mov	r6,#0x00
      005FA5 ED               [12] 1348 	mov	a,r5
      005FA6 4B               [12] 1349 	orl	a,r3
      005FA7 FD               [12] 1350 	mov	r5,a
      005FA8 EC               [12] 1351 	mov	a,r4
      005FA9 4E               [12] 1352 	orl	a,r6
      005FAA FE               [12] 1353 	mov	r6,a
                                   1354 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005FAB A3               [24] 1355 	inc	dptr
      005FAC E0               [24] 1356 	movx	a,@dptr
      005FAD FC               [12] 1357 	mov	r4,a
      005FAE A3               [24] 1358 	inc	dptr
      005FAF E0               [24] 1359 	movx	a,@dptr
      005FB0 FA               [12] 1360 	mov	r2,a
      005FB1 7B 00            [12] 1361 	mov	r3,#0x00
      005FB3 8C 01            [24] 1362 	mov	ar1,r4
      005FB5 7C 00            [12] 1363 	mov	r4,#0x00
      005FB7 EB               [12] 1364 	mov	a,r3
      005FB8 49               [12] 1365 	orl	a,r1
      005FB9 FB               [12] 1366 	mov	r3,a
      005FBA EA               [12] 1367 	mov	a,r2
      005FBB 4C               [12] 1368 	orl	a,r4
      005FBC FC               [12] 1369 	mov	r4,a
                                   1370 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005FBD C3               [12] 1371 	clr	c
      005FBE EB               [12] 1372 	mov	a,r3
      005FBF 94 03            [12] 1373 	subb	a,#0x03
      005FC1 EC               [12] 1374 	mov	a,r4
      005FC2 94 00            [12] 1375 	subb	a,#0x00
      005FC4 92 16            [24] 1376 	mov	_control_setup_valid_interface_10000_287,c
                                   1377 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005FC6 EB               [12] 1378 	mov	a,r3
      005FC7 4C               [12] 1379 	orl	a,r4
      005FC8 B4 01 00         [24] 1380 	cjne	a,#0x01,01201$
      005FCB                       1381 01201$:
      005FCB 92 17            [24] 1382 	mov	_control_setup_zero_index_10000_287,c
                                   1383 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005FCD ED               [12] 1384 	mov	a,r5
      005FCE 4E               [12] 1385 	orl	a,r6
      005FCF B4 01 00         [24] 1386 	cjne	a,#0x01,01202$
      005FD2                       1387 01202$:
                                   1388 ;	assignBit
      005FD2 92 1A            [24] 1389 	mov  _control_setup_sloc0_1_0,c
      005FD4 92 18            [24] 1390 	mov	_control_setup_zero_value_10000_287,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005FD6 90 07 EC         [24] 1392 	mov	dptr,#_control_setup_offset_10000_287
      005FD9 E4               [12] 1393 	clr	a
      005FDA F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005FDB 90 07 89         [24] 1396 	mov	dptr,#_raw_state
      005FDE E0               [24] 1397 	movx	a,@dptr
      005FDF FA               [12] 1398 	mov	r2,a
      005FE0 BA 01 05         [24] 1399 	cjne	r2,#0x01,00102$
      005FE3 90 07 89         [24] 1400 	mov	dptr,#_raw_state
      005FE6 E4               [12] 1401 	clr	a
      005FE7 F0               [24] 1402 	movx	@dptr,a
      005FE8                       1403 00102$:
                                   1404 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005FE8 C0 07            [24] 1405 	push	ar7
      005FEA 90 07 E1         [24] 1406 	mov	dptr,#_output_kind
      005FED E4               [12] 1407 	clr	a
      005FEE F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005FEF 90 07 E0         [24] 1410 	mov	dptr,#_control_phase
      005FF2 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005FF3 90 07 E3         [24] 1413 	mov	dptr,#_control_zlp
      005FF6 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005FF7 90 10 01         [24] 1416 	mov	dptr,#0x1001
      005FFA E0               [24] 1417 	movx	a,@dptr
      005FFB 90 07 7B         [24] 1418 	mov	dptr,#_D0SetupReqCode
      005FFE F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005FFF 90 10 06         [24] 1421 	mov	dptr,#0x1006
      006002 E0               [24] 1422 	movx	a,@dptr
      006003 FA               [12] 1423 	mov	r2,a
      006004 A3               [24] 1424 	inc	dptr
      006005 E0               [24] 1425 	movx	a,@dptr
      006006 F9               [12] 1426 	mov	r1,a
      006007 78 00            [12] 1427 	mov	r0,#0x00
      006009 7F 00            [12] 1428 	mov	r7,#0x00
      00600B 90 07 7C         [24] 1429 	mov	dptr,#_D0SetupLen
      00600E E8               [12] 1430 	mov	a,r0
      00600F 4A               [12] 1431 	orl	a,r2
      006010 F0               [24] 1432 	movx	@dptr,a
      006011 E9               [12] 1433 	mov	a,r1
      006012 4F               [12] 1434 	orl	a,r7
      006013 A3               [24] 1435 	inc	dptr
      006014 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      006015 90 07 7C         [24] 1438 	mov	dptr,#_D0SetupLen
      006018 E0               [24] 1439 	movx	a,@dptr
      006019 FA               [12] 1440 	mov	r2,a
      00601A A3               [24] 1441 	inc	dptr
      00601B E0               [24] 1442 	movx	a,@dptr
      00601C 4A               [12] 1443 	orl	a,r2
      00601D B4 01 00         [24] 1444 	cjne	a,#0x01,01205$
      006020                       1445 01205$:
      006020 92 19            [24] 1446 	mov	_control_setup_zero_length_10000_287,c
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006022 90 22 00         [24] 1448 	mov	dptr,#0x2200
      006025 74 C2            [12] 1449 	mov	a,#0xc2
      006027 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      006028 90 22 08         [24] 1452 	mov	dptr,#0x2208
      00602B E4               [12] 1453 	clr	a
      00602C F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      00602D 90 07 7B         [24] 1456 	mov	dptr,#_D0SetupReqCode
      006030 E0               [24] 1457 	movx	a,@dptr
      006031 F5 16            [12] 1458 	mov	_control_setup_sloc1_1_0,a
      006033 C3               [12] 1459 	clr	c
      006034 74 0B            [12] 1460 	mov	a,#0x0b
      006036 95 16            [12] 1461 	subb	a,_control_setup_sloc1_1_0
      006038 D0 07            [24] 1462 	pop	ar7
      00603A 50 03            [24] 1463 	jnc	01206$
      00603C 02 5D 7A         [24] 1464 	ljmp	_control_stall
      00603F                       1465 01206$:
                                   1466 ;	free result
      00603F E5 16            [12] 1467 	mov	a,_control_setup_sloc1_1_0
      006041 F5 F0            [12] 1468 	mov	b,a
      006043 24 0B            [12] 1469 	add	a,#(01207$-3-.)
      006045 83               [24] 1470 	movc	a,@a+pc
      006046 F5 82            [12] 1471 	mov	dpl,a
      006048 E5 F0            [12] 1472 	mov	a,b
      00604A 24 10            [12] 1473 	add	a,#(01208$-3-.)
      00604C 83               [24] 1474 	movc	a,@a+pc
      00604D F5 83            [12] 1475 	mov	dph,a
      00604F E4               [12] 1476 	clr	a
      006050 73               [24] 1477 	jmp	@a+dptr
      006051                       1478 01207$:
      006051 F9                    1479 	.db	00188$
      006052 9F                    1480 	.db	00205$
      006053 E2                    1481 	.db	00282$
      006054 9F                    1482 	.db	00205$
      006055 26                    1483 	.db	00290$
      006056 23                    1484 	.db	00116$
      006057 69                    1485 	.db	00103$
      006058 26                    1486 	.db	00290$
      006059 28                    1487 	.db	00150$
      00605A 4C                    1488 	.db	00123$
      00605B 58                    1489 	.db	00157$
      00605C AB                    1490 	.db	00173$
      00605D                       1491 01208$:
      00605D 62                    1492 	.db	00188$>>8
      00605E 63                    1493 	.db	00205$>>8
      00605F 66                    1494 	.db	00282$>>8
      006060 63                    1495 	.db	00205$>>8
      006061 67                    1496 	.db	00290$>>8
      006062 61                    1497 	.db	00116$>>8
      006063 60                    1498 	.db	00103$>>8
      006064 67                    1499 	.db	00290$>>8
      006065 62                    1500 	.db	00150$>>8
      006066 61                    1501 	.db	00123$>>8
      006067 62                    1502 	.db	00157$>>8
      006068 62                    1503 	.db	00173$>>8
                                   1504 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      006069                       1505 00103$:
                                   1506 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      006069 BF 80 02         [24] 1507 	cjne	r7,#0x80,01209$
      00606C 80 08            [24] 1508 	sjmp	00112$
      00606E                       1509 01209$:
      00606E BF 81 02         [24] 1510 	cjne	r7,#0x81,01210$
      006071 80 03            [24] 1511 	sjmp	01211$
      006073                       1512 01210$:
      006073 02 5D 7A         [24] 1513 	ljmp	_control_stall
      006076                       1514 01211$:
      006076                       1515 00112$:
                                   1516 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006076 8E 01            [24] 1517 	mov	ar1,r6
      006078 B9 21 02         [24] 1518 	cjne	r1,#0x21,01212$
      00607B 80 09            [24] 1519 	sjmp	00301$
      00607D                       1520 01212$:
      00607D B9 22 02         [24] 1521 	cjne	r1,#0x22,01213$
      006080 80 04            [24] 1522 	sjmp	00301$
      006082                       1523 01213$:
                                   1524 ;	assignBit
      006082 C2 1B            [12] 1525 	clr	_control_setup_sloc2_1_0
      006084 80 02            [24] 1526 	sjmp	00302$
      006086                       1527 00301$:
                                   1528 ;	assignBit
      006086 D2 1B            [12] 1529 	setb	_control_setup_sloc2_1_0
      006088                       1530 00302$:
      006088 E4               [12] 1531 	clr	a
      006089 BF 81 01         [24] 1532 	cjne	r7,#0x81,01214$
      00608C 04               [12] 1533 	inc	a
      00608D                       1534 01214$:
      00608D FA               [12] 1535 	mov	r2,a
      00608E A2 1B            [12] 1536 	mov	c,_control_setup_sloc2_1_0
      006090 E4               [12] 1537 	clr	a
      006091 33               [12] 1538 	rlc	a
      006092 B5 02 02         [24] 1539 	cjne	a,ar2,01216$
      006095 80 03            [24] 1540 	sjmp	00105$
      006097                       1541 01216$:
                                   1542 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      006097 02 5D 7A         [24] 1543 	ljmp	_control_stall
      00609A                       1544 00105$:
                                   1545 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      00609A 8E 02            [24] 1546 	mov	ar2,r6
      00609C 90 07 E6         [24] 1547 	mov	dptr,#_descriptor_select_PARM_2
      00609F ED               [12] 1548 	mov	a,r5
      0060A0 F0               [24] 1549 	movx	@dptr,a
      0060A1 90 07 E7         [24] 1550 	mov	dptr,#_descriptor_select_PARM_3
      0060A4 EB               [12] 1551 	mov	a,r3
      0060A5 F0               [24] 1552 	movx	@dptr,a
      0060A6 EC               [12] 1553 	mov	a,r4
      0060A7 A3               [24] 1554 	inc	dptr
      0060A8 F0               [24] 1555 	movx	@dptr,a
      0060A9 8A 82            [24] 1556 	mov	dpl, r2
      0060AB 12 5E 18         [24] 1557 	lcall	_descriptor_select
      0060AE 85 82 17         [24] 1558 	mov	_control_setup_sloc3_1_0,dpl
      0060B1 85 83 18         [24] 1559 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1560 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      0060B4 E5 17            [12] 1561 	mov	a,_control_setup_sloc3_1_0
      0060B6 45 18            [12] 1562 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0060B8 70 03            [24] 1563 	jnz	00107$
      0060BA 02 5D 7A         [24] 1564 	ljmp	_control_stall
      0060BD                       1565 00107$:
                                   1566 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0060BD 90 07 7C         [24] 1567 	mov	dptr,#_D0SetupLen
      0060C0 E0               [24] 1568 	movx	a,@dptr
      0060C1 F8               [12] 1569 	mov	r0,a
      0060C2 A3               [24] 1570 	inc	dptr
      0060C3 E0               [24] 1571 	movx	a,@dptr
      0060C4 FA               [12] 1572 	mov	r2,a
      0060C5 C3               [12] 1573 	clr	c
      0060C6 E5 17            [12] 1574 	mov	a,_control_setup_sloc3_1_0
      0060C8 98               [12] 1575 	subb	a,r0
      0060C9 E5 18            [12] 1576 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0060CB 9A               [12] 1577 	subb	a,r2
      0060CC 50 06            [24] 1578 	jnc	00303$
      0060CE E5 17            [12] 1579 	mov	a,_control_setup_sloc3_1_0
      0060D0 54 3F            [12] 1580 	anl	a,#0x3f
      0060D2 60 04            [24] 1581 	jz	00304$
      0060D4                       1582 00303$:
                                   1583 ;	assignBit
      0060D4 C2 1B            [12] 1584 	clr	_control_setup_sloc2_1_0
      0060D6 80 02            [24] 1585 	sjmp	00305$
      0060D8                       1586 00304$:
                                   1587 ;	assignBit
      0060D8 D2 1B            [12] 1588 	setb	_control_setup_sloc2_1_0
      0060DA                       1589 00305$:
      0060DA 90 07 E3         [24] 1590 	mov	dptr,#_control_zlp
      0060DD A2 1B            [12] 1591 	mov	c,_control_setup_sloc2_1_0
      0060DF E4               [12] 1592 	clr	a
      0060E0 33               [12] 1593 	rlc	a
      0060E1 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      0060E2 90 07 7C         [24] 1596 	mov	dptr,#_D0SetupLen
      0060E5 E0               [24] 1597 	movx	a,@dptr
      0060E6 F9               [12] 1598 	mov	r1,a
      0060E7 A3               [24] 1599 	inc	dptr
      0060E8 E0               [24] 1600 	movx	a,@dptr
      0060E9 FA               [12] 1601 	mov	r2,a
      0060EA C3               [12] 1602 	clr	c
      0060EB E5 17            [12] 1603 	mov	a,_control_setup_sloc3_1_0
      0060ED 99               [12] 1604 	subb	a,r1
      0060EE E5 18            [12] 1605 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0060F0 9A               [12] 1606 	subb	a,r2
      0060F1 50 0A            [24] 1607 	jnc	00109$
                                   1608 ;	free result
      0060F3 90 07 7C         [24] 1609 	mov	dptr,#_D0SetupLen
      0060F6 E5 17            [12] 1610 	mov	a,_control_setup_sloc3_1_0
      0060F8 F0               [24] 1611 	movx	@dptr,a
      0060F9 E5 18            [12] 1612 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0060FB A3               [24] 1613 	inc	dptr
      0060FC F0               [24] 1614 	movx	@dptr,a
      0060FD                       1615 00109$:
                                   1616 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0060FD 90 07 7C         [24] 1617 	mov	dptr,#_D0SetupLen
      006100 E0               [24] 1618 	movx	a,@dptr
      006101 F9               [12] 1619 	mov	r1,a
      006102 A3               [24] 1620 	inc	dptr
      006103 E0               [24] 1621 	movx	a,@dptr
      006104 49               [12] 1622 	orl	a,r1
      006105 60 04            [24] 1623 	jz	00306$
      006107 7A 01            [12] 1624 	mov	r2,#0x01
      006109 80 02            [24] 1625 	sjmp	00307$
      00610B                       1626 00306$:
      00610B 7A 02            [12] 1627 	mov	r2,#0x02
      00610D                       1628 00307$:
      00610D 90 07 E0         [24] 1629 	mov	dptr,#_control_phase
      006110 EA               [12] 1630 	mov	a,r2
      006111 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      006112 90 07 7C         [24] 1633 	mov	dptr,#_D0SetupLen
      006115 E0               [24] 1634 	movx	a,@dptr
      006116 F9               [12] 1635 	mov	r1,a
      006117 A3               [24] 1636 	inc	dptr
      006118 E0               [24] 1637 	movx	a,@dptr
      006119 49               [12] 1638 	orl	a,r1
      00611A 60 03            [24] 1639 	jz	00111$
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      00611C 02 5D 9C         [24] 1641 	ljmp	_control_next
      00611F                       1642 00111$:
      00611F 22               [24] 1643 	ret
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      006120 02 5D 7A         [24] 1645 	ljmp	_control_stall
                                   1646 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      006123                       1647 00116$:
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006123 EF               [12] 1649 	mov	a,r7
      006124 70 23            [24] 1650 	jnz	00118$
      006126 30 17 20         [24] 1651 	jnb	_control_setup_zero_index_10000_287,00118$
      006129 30 19 1D         [24] 1652 	jnb	_control_setup_zero_length_10000_287,00118$
      00612C 8D 01            [24] 1653 	mov	ar1,r5
      00612E 8E 02            [24] 1654 	mov	ar2,r6
      006130 C3               [12] 1655 	clr	c
      006131 74 7F            [12] 1656 	mov	a,#0x7f
      006133 99               [12] 1657 	subb	a,r1
      006134 E4               [12] 1658 	clr	a
      006135 9A               [12] 1659 	subb	a,r2
      006136 40 11            [24] 1660 	jc	00118$
                                   1661 ;	free result
                                   1662 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      006138 90 07 7C         [24] 1663 	mov	dptr,#_D0SetupLen
      00613B ED               [12] 1664 	mov	a,r5
      00613C F0               [24] 1665 	movx	@dptr,a
      00613D EE               [12] 1666 	mov	a,r6
      00613E A3               [24] 1667 	inc	dptr
      00613F F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      006140 90 07 E0         [24] 1670 	mov	dptr,#_control_phase
      006143 74 03            [12] 1671 	mov	a,#0x03
      006145 F0               [24] 1672 	movx	@dptr,a
      006146 02 67 29         [24] 1673 	ljmp	00291$
      006149                       1674 00118$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006149 02 5D 7A         [24] 1676 	ljmp	_control_stall
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00614C                       1678 00123$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00614C EF               [12] 1680 	mov	a,r7
      00614D 70 3C            [24] 1681 	jnz	00145$
      00614F 30 17 39         [24] 1682 	jnb	_control_setup_zero_index_10000_287,00145$
      006152 30 19 36         [24] 1683 	jnb	_control_setup_zero_length_10000_287,00145$
      006155 8D 01            [24] 1684 	mov	ar1,r5
      006157 8E 02            [24] 1685 	mov	ar2,r6
      006159 C3               [12] 1686 	clr	c
      00615A 74 01            [12] 1687 	mov	a,#0x01
      00615C 99               [12] 1688 	subb	a,r1
      00615D E4               [12] 1689 	clr	a
      00615E 9A               [12] 1690 	subb	a,r2
      00615F 40 2A            [24] 1691 	jc	00145$
                                   1692 ;	free result
                                   1693 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      006161 C0 06            [24] 1694 	push	ar6
      006163 C0 05            [24] 1695 	push	ar5
      006165 12 5D 1D         [24] 1696 	lcall	_endpoints_reset
      006168 D0 05            [24] 1697 	pop	ar5
      00616A D0 06            [24] 1698 	pop	ar6
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      00616C 90 07 81         [24] 1700 	mov	dptr,#_D0UsbConfig
      00616F ED               [12] 1701 	mov	a,r5
      006170 F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      006171 A2 1A            [12] 1704 	mov	c,_control_setup_sloc0_1_0
      006173 B3               [12] 1705 	cpl	c
      006174 92 1B            [24] 1706 	mov	_control_setup_sloc2_1_0,c
      006176 90 07 82         [24] 1707 	mov	dptr,#_USB_EnumStatus
      006179 E4               [12] 1708 	clr	a
      00617A 33               [12] 1709 	rlc	a
      00617B F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      00617C 90 07 AB         [24] 1712 	mov	dptr,#_keyboard_reset
      00617F 74 01            [12] 1713 	mov	a,#0x01
      006181 F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      006182 90 07 E0         [24] 1716 	mov	dptr,#_control_phase
      006185 74 03            [12] 1717 	mov	a,#0x03
      006187 F0               [24] 1718 	movx	@dptr,a
      006188 02 67 29         [24] 1719 	ljmp	00291$
      00618B                       1720 00145$:
                                   1721 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      00618B BF 21 02         [24] 1722 	cjne	r7,#0x21,01231$
      00618E 80 03            [24] 1723 	sjmp	01232$
      006190                       1724 01231$:
      006190 02 5D 7A         [24] 1725 	ljmp	_control_stall
      006193                       1726 01232$:
      006193 90 07 81         [24] 1727 	mov	dptr,#_D0UsbConfig
      006196 E0               [24] 1728 	movx	a,@dptr
      006197 70 03            [24] 1729 	jnz	01233$
      006199 02 5D 7A         [24] 1730 	ljmp	_control_stall
      00619C                       1731 01233$:
                                   1732 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00619C BB 01 2D         [24] 1733 	cjne	r3,#0x01,00135$
      00619F BC 00 2A         [24] 1734 	cjne	r4,#0x00,00135$
      0061A2 8D 01            [24] 1735 	mov	ar1,r5
      0061A4 8E 02            [24] 1736 	mov	ar2,r6
      0061A6 B9 00 23         [24] 1737 	cjne	r1,#0x00,00135$
      0061A9 BA 02 20         [24] 1738 	cjne	r2,#0x02,00135$
      0061AC 90 07 7C         [24] 1739 	mov	dptr,#_D0SetupLen
      0061AF E0               [24] 1740 	movx	a,@dptr
      0061B0 F9               [12] 1741 	mov	r1,a
      0061B1 A3               [24] 1742 	inc	dptr
      0061B2 E0               [24] 1743 	movx	a,@dptr
      0061B3 FA               [12] 1744 	mov	r2,a
      0061B4 B9 20 15         [24] 1745 	cjne	r1,#0x20,00135$
      0061B7 BA 00 12         [24] 1746 	cjne	r2,#0x00,00135$
      0061BA 90 07 89         [24] 1747 	mov	dptr,#_raw_state
      0061BD E0               [24] 1748 	movx	a,@dptr
      0061BE 70 0C            [24] 1749 	jnz	00135$
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      0061C0 90 07 89         [24] 1751 	mov	dptr,#_raw_state
      0061C3 74 01            [12] 1752 	mov	a,#0x01
      0061C5 F0               [24] 1753 	movx	@dptr,a
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      0061C6 90 07 E1         [24] 1755 	mov	dptr,#_output_kind
      0061C9 F0               [24] 1756 	movx	@dptr,a
      0061CA 80 52            [24] 1757 	sjmp	00136$
      0061CC                       1758 00135$:
                                   1759 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0061CC EB               [12] 1760 	mov	a,r3
      0061CD 4C               [12] 1761 	orl	a,r4
      0061CE 70 20            [24] 1762 	jnz	00130$
      0061D0 8D 01            [24] 1763 	mov	ar1,r5
      0061D2 8E 02            [24] 1764 	mov	ar2,r6
      0061D4 B9 00 19         [24] 1765 	cjne	r1,#0x00,00130$
      0061D7 BA 02 16         [24] 1766 	cjne	r2,#0x02,00130$
      0061DA 90 07 7C         [24] 1767 	mov	dptr,#_D0SetupLen
      0061DD E0               [24] 1768 	movx	a,@dptr
      0061DE F9               [12] 1769 	mov	r1,a
      0061DF A3               [24] 1770 	inc	dptr
      0061E0 E0               [24] 1771 	movx	a,@dptr
      0061E1 FA               [12] 1772 	mov	r2,a
      0061E2 B9 01 0B         [24] 1773 	cjne	r1,#0x01,00130$
      0061E5 BA 00 08         [24] 1774 	cjne	r2,#0x00,00130$
                                   1775 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      0061E8 90 07 E1         [24] 1776 	mov	dptr,#_output_kind
      0061EB 74 02            [12] 1777 	mov	a,#0x02
      0061ED F0               [24] 1778 	movx	@dptr,a
      0061EE 80 2E            [24] 1779 	sjmp	00136$
      0061F0                       1780 00130$:
                                   1781 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0061F0 BB 02 28         [24] 1782 	cjne	r3,#0x02,00125$
      0061F3 BC 00 25         [24] 1783 	cjne	r4,#0x00,00125$
      0061F6 8D 01            [24] 1784 	mov	ar1,r5
      0061F8 8E 02            [24] 1785 	mov	ar2,r6
      0061FA B9 06 1E         [24] 1786 	cjne	r1,#0x06,00125$
      0061FD BA 02 1B         [24] 1787 	cjne	r2,#0x02,00125$
      006200 90 07 7C         [24] 1788 	mov	dptr,#_D0SetupLen
      006203 E0               [24] 1789 	movx	a,@dptr
      006204 F9               [12] 1790 	mov	r1,a
      006205 A3               [24] 1791 	inc	dptr
      006206 E0               [24] 1792 	movx	a,@dptr
      006207 FA               [12] 1793 	mov	r2,a
      006208 B9 02 10         [24] 1794 	cjne	r1,#0x02,00125$
      00620B BA 00 0D         [24] 1795 	cjne	r2,#0x00,00125$
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      00620E 90 07 E1         [24] 1797 	mov	dptr,#_output_kind
      006211 74 03            [12] 1798 	mov	a,#0x03
      006213 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      006214 90 07 E2         [24] 1801 	mov	dptr,#_output_report_id
      006217 23               [12] 1802 	rl	a
      006218 F0               [24] 1803 	movx	@dptr,a
      006219 80 03            [24] 1804 	sjmp	00136$
      00621B                       1805 00125$:
                                   1806 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      00621B 02 5D 7A         [24] 1807 	ljmp	_control_stall
      00621E                       1808 00136$:
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      00621E 90 07 E0         [24] 1810 	mov	dptr,#_control_phase
      006221 74 04            [12] 1811 	mov	a,#0x04
      006223 F0               [24] 1812 	movx	@dptr,a
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      006224 22               [24] 1814 	ret
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      006225 02 5D 7A         [24] 1816 	ljmp	_control_stall
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006228                       1818 00150$:
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006228 BF 80 2A         [24] 1820 	cjne	r7,#0x80,00152$
      00622B 30 17 27         [24] 1821 	jnb	_control_setup_zero_index_10000_287,00152$
      00622E 30 18 24         [24] 1822 	jnb	_control_setup_zero_value_10000_287,00152$
      006231 90 07 7C         [24] 1823 	mov	dptr,#_D0SetupLen
      006234 E0               [24] 1824 	movx	a,@dptr
      006235 F9               [12] 1825 	mov	r1,a
      006236 A3               [24] 1826 	inc	dptr
      006237 E0               [24] 1827 	movx	a,@dptr
      006238 FA               [12] 1828 	mov	r2,a
      006239 B9 01 19         [24] 1829 	cjne	r1,#0x01,00152$
      00623C BA 00 16         [24] 1830 	cjne	r2,#0x00,00152$
                                   1831 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      00623F 90 07 81         [24] 1832 	mov	dptr,#_D0UsbConfig
      006242 E0               [24] 1833 	movx	a,@dptr
      006243 90 10 00         [24] 1834 	mov	dptr,#0x1000
      006246 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      006247 90 22 08         [24] 1837 	mov	dptr,#0x2208
      00624A 74 01            [12] 1838 	mov	a,#0x01
      00624C F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      00624D 90 07 E0         [24] 1841 	mov	dptr,#_control_phase
      006250 04               [12] 1842 	inc	a
      006251 F0               [24] 1843 	movx	@dptr,a
      006252 02 67 29         [24] 1844 	ljmp	00291$
      006255                       1845 00152$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      006255 02 5D 7A         [24] 1847 	ljmp	_control_stall
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006258                       1849 00157$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006258 BF 81 2C         [24] 1851 	cjne	r7,#0x81,00167$
      00625B 30 16 29         [24] 1852 	jnb	_control_setup_valid_interface_10000_287,00167$
      00625E 30 18 26         [24] 1853 	jnb	_control_setup_zero_value_10000_287,00167$
      006261 90 07 7C         [24] 1854 	mov	dptr,#_D0SetupLen
      006264 E0               [24] 1855 	movx	a,@dptr
      006265 F9               [12] 1856 	mov	r1,a
      006266 A3               [24] 1857 	inc	dptr
      006267 E0               [24] 1858 	movx	a,@dptr
      006268 FA               [12] 1859 	mov	r2,a
      006269 B9 01 1B         [24] 1860 	cjne	r1,#0x01,00167$
      00626C BA 00 18         [24] 1861 	cjne	r2,#0x00,00167$
      00626F 90 07 81         [24] 1862 	mov	dptr,#_D0UsbConfig
      006272 E0               [24] 1863 	movx	a,@dptr
      006273 60 12            [24] 1864 	jz	00167$
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      006275 90 10 00         [24] 1866 	mov	dptr,#0x1000
      006278 E4               [12] 1867 	clr	a
      006279 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      00627A 90 22 08         [24] 1870 	mov	dptr,#0x2208
      00627D 04               [12] 1871 	inc	a
      00627E F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      00627F 90 07 E0         [24] 1874 	mov	dptr,#_control_phase
      006282 04               [12] 1875 	inc	a
      006283 F0               [24] 1876 	movx	@dptr,a
      006284 02 67 29         [24] 1877 	ljmp	00291$
      006287                       1878 00167$:
                                   1879 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006287 30 16 1E         [24] 1880 	jnb	_control_setup_valid_interface_10000_287,00161$
      00628A 90 07 81         [24] 1881 	mov	dptr,#_D0UsbConfig
      00628D E0               [24] 1882 	movx	a,@dptr
      00628E 60 18            [24] 1883 	jz	00161$
      006290 BF 21 15         [24] 1884 	cjne	r7,#0x21,00161$
      006293 30 19 12         [24] 1885 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1886 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006296 EB               [12] 1887 	mov	a,r3
      006297 4C               [12] 1888 	orl	a,r4
      006298 70 05            [24] 1889 	jnz	00159$
      00629A 90 06 43         [24] 1890 	mov	dptr,#_keyboard_idle
      00629D EE               [12] 1891 	mov	a,r6
      00629E F0               [24] 1892 	movx	@dptr,a
      00629F                       1893 00159$:
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      00629F 90 07 E0         [24] 1895 	mov	dptr,#_control_phase
      0062A2 74 03            [12] 1896 	mov	a,#0x03
      0062A4 F0               [24] 1897 	movx	@dptr,a
      0062A5 02 67 29         [24] 1898 	ljmp	00291$
      0062A8                       1899 00161$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      0062A8 02 5D 7A         [24] 1901 	ljmp	_control_stall
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0062AB                       1903 00173$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0062AB BF 01 18         [24] 1905 	cjne	r7,#0x01,00182$
      0062AE 30 16 15         [24] 1906 	jnb	_control_setup_valid_interface_10000_287,00182$
      0062B1 30 18 12         [24] 1907 	jnb	_control_setup_zero_value_10000_287,00182$
      0062B4 30 19 0F         [24] 1908 	jnb	_control_setup_zero_length_10000_287,00182$
      0062B7 90 07 81         [24] 1909 	mov	dptr,#_D0UsbConfig
      0062BA E0               [24] 1910 	movx	a,@dptr
      0062BB 60 09            [24] 1911 	jz	00182$
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      0062BD 90 07 E0         [24] 1913 	mov	dptr,#_control_phase
      0062C0 74 03            [12] 1914 	mov	a,#0x03
      0062C2 F0               [24] 1915 	movx	@dptr,a
      0062C3 02 67 29         [24] 1916 	ljmp	00291$
      0062C6                       1917 00182$:
                                   1918 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0062C6 EB               [12] 1919 	mov	a,r3
      0062C7 4C               [12] 1920 	orl	a,r4
      0062C8 70 2C            [24] 1921 	jnz	00175$
      0062CA 90 07 81         [24] 1922 	mov	dptr,#_D0UsbConfig
      0062CD E0               [24] 1923 	movx	a,@dptr
      0062CE 60 26            [24] 1924 	jz	00175$
      0062D0 BF 21 23         [24] 1925 	cjne	r7,#0x21,00175$
      0062D3 30 19 20         [24] 1926 	jnb	_control_setup_zero_length_10000_287,00175$
      0062D6 8D 01            [24] 1927 	mov	ar1,r5
      0062D8 8E 02            [24] 1928 	mov	ar2,r6
      0062DA C3               [12] 1929 	clr	c
      0062DB 74 01            [12] 1930 	mov	a,#0x01
      0062DD 99               [12] 1931 	subb	a,r1
      0062DE E4               [12] 1932 	clr	a
      0062DF 9A               [12] 1933 	subb	a,r2
      0062E0 40 14            [24] 1934 	jc	00175$
                                   1935 ;	free result
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      0062E2 90 0D D4         [24] 1937 	mov	dptr,#_keyboard_protocol
      0062E5 ED               [12] 1938 	mov	a,r5
      0062E6 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      0062E7 90 07 AB         [24] 1941 	mov	dptr,#_keyboard_reset
      0062EA 74 01            [12] 1942 	mov	a,#0x01
      0062EC F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      0062ED 90 07 E0         [24] 1945 	mov	dptr,#_control_phase
      0062F0 74 03            [12] 1946 	mov	a,#0x03
      0062F2 F0               [24] 1947 	movx	@dptr,a
      0062F3 02 67 29         [24] 1948 	ljmp	00291$
      0062F6                       1949 00175$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      0062F6 02 5D 7A         [24] 1951 	ljmp	_control_stall
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      0062F9                       1953 00188$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      0062F9 20 18 03         [24] 1955 	jb	_control_setup_zero_value_10000_287,01283$
      0062FC 02 5D 7A         [24] 1956 	ljmp	_control_stall
      0062FF                       1957 01283$:
      0062FF 90 07 7C         [24] 1958 	mov	dptr,#_D0SetupLen
      006302 E0               [24] 1959 	movx	a,@dptr
      006303 F9               [12] 1960 	mov	r1,a
      006304 A3               [24] 1961 	inc	dptr
      006305 E0               [24] 1962 	movx	a,@dptr
      006306 FA               [12] 1963 	mov	r2,a
      006307 B9 02 05         [24] 1964 	cjne	r1,#0x02,01284$
      00630A BA 00 02         [24] 1965 	cjne	r2,#0x00,01284$
      00630D 80 03            [24] 1966 	sjmp	01285$
      00630F                       1967 01284$:
      00630F 02 5D 7A         [24] 1968 	ljmp	_control_stall
      006312                       1969 01285$:
                                   1970 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006312 E4               [12] 1971 	clr	a
      006313 BF 80 01         [24] 1972 	cjne	r7,#0x80,01286$
      006316 04               [12] 1973 	inc	a
      006317                       1974 01286$:
      006317 FA               [12] 1975 	mov	r2,a
      006318 60 03            [24] 1976 	jz	00196$
      00631A 20 17 35         [24] 1977 	jb	_control_setup_zero_index_10000_287,00189$
      00631D                       1978 00196$:
      00631D BF 81 09         [24] 1979 	cjne	r7,#0x81,00202$
      006320 30 16 06         [24] 1980 	jnb	_control_setup_valid_interface_10000_287,00202$
      006323 90 07 81         [24] 1981 	mov	dptr,#_D0UsbConfig
      006326 E0               [24] 1982 	movx	a,@dptr
      006327 70 29            [24] 1983 	jnz	00189$
      006329                       1984 00202$:
                                   1985 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006329 BF 82 70         [24] 1986 	cjne	r7,#0x82,00190$
      00632C 90 07 81         [24] 1987 	mov	dptr,#_D0UsbConfig
      00632F E0               [24] 1988 	movx	a,@dptr
      006330 60 6A            [24] 1989 	jz	00190$
      006332 EB               [12] 1990 	mov	a,r3
      006333 4C               [12] 1991 	orl	a,r4
      006334 60 1C            [24] 1992 	jz	00189$
      006336 8B 00            [24] 1993 	mov	ar0,r3
      006338 8C 01            [24] 1994 	mov	ar1,r4
      00633A B8 80 05         [24] 1995 	cjne	r0,#0x80,01298$
      00633D B9 00 02         [24] 1996 	cjne	r1,#0x00,01298$
      006340 80 10            [24] 1997 	sjmp	00189$
      006342                       1998 01298$:
      006342 C3               [12] 1999 	clr	c
      006343 E8               [12] 2000 	mov	a,r0
      006344 94 81            [12] 2001 	subb	a,#0x81
      006346 E9               [12] 2002 	mov	a,r1
      006347 94 00            [12] 2003 	subb	a,#0x00
      006349 40 51            [24] 2004 	jc	00190$
      00634B 74 83            [12] 2005 	mov	a,#0x83
      00634D 98               [12] 2006 	subb	a,r0
      00634E E4               [12] 2007 	clr	a
      00634F 99               [12] 2008 	subb	a,r1
      006350 40 4A            [24] 2009 	jc	00190$
                                   2010 ;	free result
      006352                       2011 00189$:
                                   2012 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      006352 8B 01            [24] 2013 	mov	ar1,r3
      006354 53 01 07         [24] 2014 	anl	ar1,#0x07
                                   2015 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006357 EA               [12] 2016 	mov	a,r2
      006358 60 0B            [24] 2017 	jz	00308$
      00635A 90 07 83         [24] 2018 	mov	dptr,#_USB_SleepStatus
      00635D E0               [24] 2019 	movx	a,@dptr
      00635E 54 01            [12] 2020 	anl	a,#0x01
      006360 25 E0            [12] 2021 	add	a,acc
      006362 FA               [12] 2022 	mov	r2,a
      006363 80 22            [24] 2023 	sjmp	00309$
      006365                       2024 00308$:
                                   2025 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006365 BF 82 1B         [24] 2026 	cjne	r7,#0x82,00310$
      006368 E9               [12] 2027 	mov	a,r1
      006369 60 18            [24] 2028 	jz	00310$
      00636B 89 00            [24] 2029 	mov	ar0,r1
      00636D 79 00            [12] 2030 	mov	r1,#0x00
      00636F 74 22            [12] 2031 	mov	a,#0x22
      006371 29               [12] 2032 	add	a, r1
      006372 F9               [12] 2033 	mov	r1,a
      006373 88 82            [24] 2034 	mov	dpl,r0
      006375 89 83            [24] 2035 	mov	dph,r1
      006377 E0               [24] 2036 	movx	a,@dptr
      006378 F9               [12] 2037 	mov	r1,a
      006379 53 01 03         [24] 2038 	anl	ar1,#0x03
      00637C B9 03 04         [24] 2039 	cjne	r1,#0x03,00310$
      00637F 79 01            [12] 2040 	mov	r1,#0x01
      006381 80 02            [24] 2041 	sjmp	00311$
      006383                       2042 00310$:
      006383 79 00            [12] 2043 	mov	r1,#0x00
      006385                       2044 00311$:
      006385 89 02            [24] 2045 	mov	ar2,r1
      006387                       2046 00309$:
      006387 90 10 00         [24] 2047 	mov	dptr,#0x1000
      00638A EA               [12] 2048 	mov	a,r2
      00638B F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      00638C A3               [24] 2051 	inc	dptr
      00638D E4               [12] 2052 	clr	a
      00638E F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      00638F 90 22 08         [24] 2055 	mov	dptr,#0x2208
      006392 74 02            [12] 2056 	mov	a,#0x02
      006394 F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      006395 90 07 E0         [24] 2059 	mov	dptr,#_control_phase
      006398 F0               [24] 2060 	movx	@dptr,a
      006399 02 67 29         [24] 2061 	ljmp	00291$
      00639C                       2062 00190$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      00639C 02 5D 7A         [24] 2064 	ljmp	_control_stall
                                   2065 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00639F                       2066 00205$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      00639F 20 19 03         [24] 2068 	jb	_control_setup_zero_length_10000_287,01307$
      0063A2 02 64 32         [24] 2069 	ljmp	00279$
      0063A5                       2070 01307$:
      0063A5 90 07 81         [24] 2071 	mov	dptr,#_D0UsbConfig
      0063A8 E0               [24] 2072 	movx	a,@dptr
      0063A9 70 03            [24] 2073 	jnz	01308$
      0063AB 02 64 32         [24] 2074 	ljmp	00279$
      0063AE                       2075 01308$:
                                   2076 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      0063AE EF               [12] 2077 	mov	a,r7
      0063AF 70 29            [24] 2078 	jnz	00218$
      0063B1 8D 01            [24] 2079 	mov	ar1,r5
      0063B3 8E 02            [24] 2080 	mov	ar2,r6
      0063B5 B9 01 22         [24] 2081 	cjne	r1,#0x01,00218$
      0063B8 BA 00 1F         [24] 2082 	cjne	r2,#0x00,00218$
      0063BB 30 17 1C         [24] 2083 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0063BE 90 07 7B         [24] 2085 	mov	dptr,#_D0SetupReqCode
      0063C1 E0               [24] 2086 	movx	a,@dptr
      0063C2 FA               [12] 2087 	mov	r2,a
      0063C3 BA 03 0A         [24] 2088 	cjne	r2,#0x03,00207$
      0063C6 90 07 83         [24] 2089 	mov	dptr,#_USB_SleepStatus
      0063C9 E0               [24] 2090 	movx	a,@dptr
      0063CA 43 E0 01         [24] 2091 	orl	acc,#0x01
      0063CD F0               [24] 2092 	movx	@dptr,a
      0063CE 80 59            [24] 2093 	sjmp	00219$
      0063D0                       2094 00207$:
                                   2095 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      0063D0 90 07 83         [24] 2096 	mov	dptr,#_USB_SleepStatus
      0063D3 E0               [24] 2097 	movx	a,@dptr
      0063D4 53 E0 FE         [24] 2098 	anl	acc,#0xfe
      0063D7 F0               [24] 2099 	movx	@dptr,a
      0063D8 80 4F            [24] 2100 	sjmp	00219$
      0063DA                       2101 00218$:
                                   2102 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0063DA BF 02 49         [24] 2103 	cjne	r7,#0x02,00212$
      0063DD 30 18 46         [24] 2104 	jnb	_control_setup_zero_value_10000_287,00212$
      0063E0 8B 01            [24] 2105 	mov	ar1,r3
      0063E2 8C 02            [24] 2106 	mov	ar2,r4
      0063E4 C3               [12] 2107 	clr	c
      0063E5 E9               [12] 2108 	mov	a,r1
      0063E6 94 81            [12] 2109 	subb	a,#0x81
      0063E8 EA               [12] 2110 	mov	a,r2
      0063E9 94 00            [12] 2111 	subb	a,#0x00
      0063EB 40 39            [24] 2112 	jc	00212$
      0063ED 74 83            [12] 2113 	mov	a,#0x83
      0063EF 99               [12] 2114 	subb	a,r1
      0063F0 E4               [12] 2115 	clr	a
      0063F1 9A               [12] 2116 	subb	a,r2
      0063F2 40 32            [24] 2117 	jc	00212$
                                   2118 ;	free result
                                   2119 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      0063F4 8B 02            [24] 2120 	mov	ar2,r3
      0063F6 53 02 07         [24] 2121 	anl	ar2,#0x07
                                   2122 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0063F9 8A 00            [24] 2123 	mov	ar0,r2
      0063FB 79 00            [12] 2124 	mov	r1,#0x00
      0063FD 74 22            [12] 2125 	mov	a,#0x22
      0063FF 29               [12] 2126 	add	a, r1
      006400 F9               [12] 2127 	mov	r1,a
      006401 88 17            [24] 2128 	mov	_control_setup_sloc3_1_0,r0
      006403 89 18            [24] 2129 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006405 90 07 7B         [24] 2130 	mov	dptr,#_D0SetupReqCode
      006408 E0               [24] 2131 	movx	a,@dptr
      006409 F9               [12] 2132 	mov	r1,a
      00640A B9 03 04         [24] 2133 	cjne	r1,#0x03,00318$
      00640D 79 03            [12] 2134 	mov	r1,#0x03
      00640F 80 02            [24] 2135 	sjmp	00319$
      006411                       2136 00318$:
      006411 79 02            [12] 2137 	mov	r1,#0x02
      006413                       2138 00319$:
      006413 43 01 10         [24] 2139 	orl	ar1,#0x10
      006416 85 17 82         [24] 2140 	mov	dpl,_control_setup_sloc3_1_0
      006419 85 18 83         [24] 2141 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00641C E9               [12] 2142 	mov	a,r1
      00641D F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00641E BA 03 08         [24] 2145 	cjne	r2,#0x03,00219$
      006421 12 5D 00         [24] 2146 	lcall	_raw_complete
      006424 80 03            [24] 2147 	sjmp	00219$
      006426                       2148 00212$:
                                   2149 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006426 02 5D 7A         [24] 2150 	ljmp	_control_stall
      006429                       2151 00219$:
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006429 90 07 E0         [24] 2153 	mov	dptr,#_control_phase
      00642C 74 03            [12] 2154 	mov	a,#0x03
      00642E F0               [24] 2155 	movx	@dptr,a
      00642F 02 67 29         [24] 2156 	ljmp	00291$
      006432                       2157 00279$:
                                   2158 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006432 E4               [12] 2159 	clr	a
      006433 BF A1 01         [24] 2160 	cjne	r7,#0xa1,01324$
      006436 04               [12] 2161 	inc	a
      006437                       2162 01324$:
      006437 FA               [12] 2163 	mov	r2,a
      006438 70 03            [24] 2164 	jnz	01326$
      00643A 02 66 A4         [24] 2165 	ljmp	00273$
      00643D                       2166 01326$:
      00643D 90 07 7B         [24] 2167 	mov	dptr,#_D0SetupReqCode
      006440 E0               [24] 2168 	movx	a,@dptr
      006441 F9               [12] 2169 	mov	r1,a
      006442 B9 01 02         [24] 2170 	cjne	r1,#0x01,01327$
      006445 80 03            [24] 2171 	sjmp	01328$
      006447                       2172 01327$:
      006447 02 66 A4         [24] 2173 	ljmp	00273$
      00644A                       2174 01328$:
      00644A 90 07 81         [24] 2175 	mov	dptr,#_D0UsbConfig
      00644D E0               [24] 2176 	movx	a,@dptr
      00644E 70 03            [24] 2177 	jnz	01329$
      006450 02 66 A4         [24] 2178 	ljmp	00273$
      006453                       2179 01329$:
      006453 90 07 7C         [24] 2180 	mov	dptr,#_D0SetupLen
      006456 E0               [24] 2181 	movx	a,@dptr
      006457 F8               [12] 2182 	mov	r0,a
      006458 A3               [24] 2183 	inc	dptr
      006459 E0               [24] 2184 	movx	a,@dptr
      00645A 48               [12] 2185 	orl	a,r0
      00645B 70 03            [24] 2186 	jnz	01330$
      00645D 02 66 A4         [24] 2187 	ljmp	00273$
      006460                       2188 01330$:
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      006460 C0 03            [24] 2190 	push	ar3
      006462 C0 04            [24] 2191 	push	ar4
      006464 8D 01            [24] 2192 	mov	ar1,r5
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006466 8E 00            [24] 2194 	mov	ar0,r6
      006468 B8 01 03         [24] 2195 	cjne	r0,#0x01,01331$
      00646B E8               [12] 2196 	mov	a,r0
      00646C 80 01            [24] 2197 	sjmp	01332$
      00646E                       2198 01331$:
      00646E E4               [12] 2199 	clr	a
      00646F                       2200 01332$:
      00646F F5 17            [12] 2201 	mov	_control_setup_sloc3_1_0,a
      006471 D0 04            [24] 2202 	pop	ar4
      006473 D0 03            [24] 2203 	pop	ar3
      006475 E5 17            [12] 2204 	mov	a,_control_setup_sloc3_1_0
      006477 60 17            [24] 2205 	jz	00251$
      006479 EB               [12] 2206 	mov	a,r3
      00647A 4C               [12] 2207 	orl	a,r4
      00647B 70 13            [24] 2208 	jnz	00251$
      00647D E9               [12] 2209 	mov	a,r1
      00647E 70 10            [24] 2210 	jnz	00251$
                                   2211 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      006480 90 07 EA         [24] 2212 	mov	dptr,#_control_setup_length_10000_287
      006483 74 08            [12] 2213 	mov	a,#0x08
      006485 F0               [24] 2214 	movx	@dptr,a
      006486 E4               [12] 2215 	clr	a
      006487 A3               [24] 2216 	inc	dptr
      006488 F0               [24] 2217 	movx	@dptr,a
                                   2218 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      006489 90 07 EC         [24] 2219 	mov	dptr,#_control_setup_offset_10000_287
      00648C F0               [24] 2220 	movx	@dptr,a
      00648D 02 66 14         [24] 2221 	ljmp	00252$
      006490                       2222 00251$:
                                   2223 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006490 E5 17            [12] 2224 	mov	a,_control_setup_sloc3_1_0
      006492 60 27            [24] 2225 	jz	00245$
      006494 BB 02 24         [24] 2226 	cjne	r3,#0x02,00245$
      006497 BC 00 21         [24] 2227 	cjne	r4,#0x00,00245$
                                   2228 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00649A B9 07 00         [24] 2229 	cjne	r1,#0x07,01339$
      00649D                       2230 01339$:
      00649D 50 1C            [24] 2231 	jnc	00245$
      00649F E9               [12] 2232 	mov	a,r1
      0064A0 90 BC 48         [24] 2233 	mov	dptr,#_shared_lengths
      0064A3 93               [24] 2234 	movc	a,@a+dptr
      0064A4 F8               [12] 2235 	mov	r0,a
      0064A5 60 14            [24] 2236 	jz	00245$
                                   2237 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0064A7 90 07 EA         [24] 2238 	mov	dptr,#_control_setup_length_10000_287
      0064AA E8               [12] 2239 	mov	a,r0
      0064AB F0               [24] 2240 	movx	@dptr,a
      0064AC E4               [12] 2241 	clr	a
      0064AD A3               [24] 2242 	inc	dptr
      0064AE F0               [24] 2243 	movx	@dptr,a
                                   2244 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      0064AF E9               [12] 2245 	mov	a,r1
      0064B0 90 BC 41         [24] 2246 	mov	dptr,#_shared_offsets
      0064B3 93               [24] 2247 	movc	a,@a+dptr
      0064B4 90 07 EC         [24] 2248 	mov	dptr,#_control_setup_offset_10000_287
      0064B7 F0               [24] 2249 	movx	@dptr,a
      0064B8 02 66 14         [24] 2250 	ljmp	00252$
      0064BB                       2251 00245$:
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0064BB E5 17            [12] 2253 	mov	a,_control_setup_sloc3_1_0
      0064BD 60 7A            [24] 2254 	jz	00240$
      0064BF BB 01 77         [24] 2255 	cjne	r3,#0x01,00240$
      0064C2 BC 00 74         [24] 2256 	cjne	r4,#0x00,00240$
      0064C5 E9               [12] 2257 	mov	a,r1
      0064C6 70 71            [24] 2258 	jnz	00240$
                                   2259 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0064C8 90 07 7C         [24] 2260 	mov	dptr,#_D0SetupLen
      0064CB E0               [24] 2261 	movx	a,@dptr
      0064CC F8               [12] 2262 	mov	r0,a
      0064CD A3               [24] 2263 	inc	dptr
      0064CE E0               [24] 2264 	movx	a,@dptr
      0064CF F9               [12] 2265 	mov	r1,a
      0064D0 C3               [12] 2266 	clr	c
      0064D1 E8               [12] 2267 	mov	a,r0
      0064D2 94 20            [12] 2268 	subb	a,#0x20
      0064D4 E9               [12] 2269 	mov	a,r1
      0064D5 94 00            [12] 2270 	subb	a,#0x00
      0064D7 50 0A            [24] 2271 	jnc	00320$
      0064D9 90 07 7C         [24] 2272 	mov	dptr,#_D0SetupLen
      0064DC E0               [24] 2273 	movx	a,@dptr
      0064DD F8               [12] 2274 	mov	r0,a
      0064DE A3               [24] 2275 	inc	dptr
      0064DF E0               [24] 2276 	movx	a,@dptr
      0064E0 F9               [12] 2277 	mov	r1,a
      0064E1 80 04            [24] 2278 	sjmp	00321$
      0064E3                       2279 00320$:
      0064E3 78 20            [12] 2280 	mov	r0,#0x20
      0064E5 79 00            [12] 2281 	mov	r1,#0x00
      0064E7                       2282 00321$:
                                   2283 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0064E7 75 17 00         [24] 2284 	mov	_control_setup_sloc3_1_0,#0x00
      0064EA                       2285 00293$:
      0064EA C0 03            [24] 2286 	push	ar3
      0064EC C0 04            [24] 2287 	push	ar4
      0064EE AB 17            [24] 2288 	mov	r3,_control_setup_sloc3_1_0
      0064F0 7C 00            [12] 2289 	mov	r4,#0x00
      0064F2 C3               [12] 2290 	clr	c
      0064F3 EB               [12] 2291 	mov	a,r3
      0064F4 98               [12] 2292 	subb	a,r0
      0064F5 EC               [12] 2293 	mov	a,r4
      0064F6 99               [12] 2294 	subb	a,r1
      0064F7 D0 04            [24] 2295 	pop	ar4
      0064F9 D0 03            [24] 2296 	pop	ar3
      0064FB 50 32            [24] 2297 	jnc	00222$
      0064FD C0 00            [24] 2298 	push	ar0
      0064FF C0 01            [24] 2299 	push	ar1
      006501 85 17 19         [24] 2300 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006504 74 10            [12] 2301 	mov	a,#0x10
      006506 24 00            [12] 2302 	add	a, #0x00
      006508 F5 1A            [12] 2303 	mov	(_control_setup_sloc4_1_0 + 1),a
      00650A A8 17            [24] 2304 	mov	r0,_control_setup_sloc3_1_0
      00650C 79 00            [12] 2305 	mov	r1,#0x00
      00650E 74 C0            [12] 2306 	mov	a,#0xc0
      006510 28               [12] 2307 	add	a, r0
      006511 F8               [12] 2308 	mov	r0,a
      006512 E4               [12] 2309 	clr	a
      006513 39               [12] 2310 	addc	a, r1
      006514 F9               [12] 2311 	mov	r1,a
      006515 88 82            [24] 2312 	mov	dpl,r0
      006517 74 10            [12] 2313 	mov	a,#0x10
      006519 29               [12] 2314 	add	a, r1
      00651A F5 83            [12] 2315 	mov	dph,a
      00651C E0               [24] 2316 	movx	a,@dptr
      00651D 85 19 82         [24] 2317 	mov	dpl,_control_setup_sloc4_1_0
      006520 85 1A 83         [24] 2318 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006523 F0               [24] 2319 	movx	@dptr,a
      006524 E5 17            [12] 2320 	mov	a,_control_setup_sloc3_1_0
      006526 04               [12] 2321 	inc	a
      006527 F5 17            [12] 2322 	mov	_control_setup_sloc3_1_0,a
      006529 D0 01            [24] 2323 	pop	ar1
      00652B D0 00            [24] 2324 	pop	ar0
      00652D 80 BB            [24] 2325 	sjmp	00293$
      00652F                       2326 00222$:
                                   2327 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      00652F 90 07 EA         [24] 2328 	mov	dptr,#_control_setup_length_10000_287
      006532 E4               [12] 2329 	clr	a
      006533 F0               [24] 2330 	movx	@dptr,a
      006534 A3               [24] 2331 	inc	dptr
      006535 F0               [24] 2332 	movx	@dptr,a
      006536 02 66 14         [24] 2333 	ljmp	00252$
      006539                       2334 00240$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006539 8D 00            [24] 2336 	mov	ar0,r5
      00653B 8E 01            [24] 2337 	mov	ar1,r6
      00653D B8 00 21         [24] 2338 	cjne	r0,#0x00,00236$
      006540 B9 02 1E         [24] 2339 	cjne	r1,#0x02,00236$
      006543 EB               [12] 2340 	mov	a,r3
      006544 4C               [12] 2341 	orl	a,r4
      006545 70 1A            [24] 2342 	jnz	00236$
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006547 90 07 86         [24] 2344 	mov	dptr,#_KB_USB_SetReport
      00654A E0               [24] 2345 	movx	a,@dptr
      00654B 90 10 00         [24] 2346 	mov	dptr,#0x1000
      00654E F0               [24] 2347 	movx	@dptr,a
                                   2348 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00654F 90 07 EA         [24] 2349 	mov	dptr,#_control_setup_length_10000_287
      006552 E4               [12] 2350 	clr	a
      006553 F0               [24] 2351 	movx	@dptr,a
      006554 A3               [24] 2352 	inc	dptr
      006555 F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006556 90 07 7C         [24] 2355 	mov	dptr,#_D0SetupLen
      006559 04               [12] 2356 	inc	a
      00655A F0               [24] 2357 	movx	@dptr,a
      00655B E4               [12] 2358 	clr	a
      00655C A3               [24] 2359 	inc	dptr
      00655D F0               [24] 2360 	movx	@dptr,a
      00655E 02 66 14         [24] 2361 	ljmp	00252$
      006561                       2362 00236$:
                                   2363 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006561 B8 06 41         [24] 2364 	cjne	r0,#0x06,00232$
      006564 B9 02 3E         [24] 2365 	cjne	r1,#0x02,00232$
      006567 BB 02 3B         [24] 2366 	cjne	r3,#0x02,00232$
      00656A BC 00 38         [24] 2367 	cjne	r4,#0x00,00232$
                                   2368 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00656D C0 03            [24] 2369 	push	ar3
      00656F C0 04            [24] 2370 	push	ar4
      006571 90 10 00         [24] 2371 	mov	dptr,#0x1000
      006574 74 06            [12] 2372 	mov	a,#0x06
      006576 F0               [24] 2373 	movx	@dptr,a
                                   2374 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006577 90 07 86         [24] 2375 	mov	dptr,#_KB_USB_SetReport
      00657A E0               [24] 2376 	movx	a,@dptr
      00657B 90 10 01         [24] 2377 	mov	dptr,#0x1001
      00657E F0               [24] 2378 	movx	@dptr,a
                                   2379 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      00657F 90 07 EA         [24] 2380 	mov	dptr,#_control_setup_length_10000_287
      006582 E4               [12] 2381 	clr	a
      006583 F0               [24] 2382 	movx	@dptr,a
      006584 A3               [24] 2383 	inc	dptr
      006585 F0               [24] 2384 	movx	@dptr,a
                                   2385 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006586 90 07 7C         [24] 2386 	mov	dptr,#_D0SetupLen
      006589 E0               [24] 2387 	movx	a,@dptr
      00658A FB               [12] 2388 	mov	r3,a
      00658B A3               [24] 2389 	inc	dptr
      00658C E0               [24] 2390 	movx	a,@dptr
      00658D FC               [12] 2391 	mov	r4,a
      00658E C3               [12] 2392 	clr	c
      00658F 74 02            [12] 2393 	mov	a,#0x02
      006591 9B               [12] 2394 	subb	a,r3
      006592 E4               [12] 2395 	clr	a
      006593 9C               [12] 2396 	subb	a,r4
      006594 D0 04            [24] 2397 	pop	ar4
      006596 D0 03            [24] 2398 	pop	ar3
      006598 50 7A            [24] 2399 	jnc	00252$
                                   2400 ;	free result
      00659A 90 07 7C         [24] 2401 	mov	dptr,#_D0SetupLen
      00659D 74 02            [12] 2402 	mov	a,#0x02
      00659F F0               [24] 2403 	movx	@dptr,a
      0065A0 E4               [12] 2404 	clr	a
      0065A1 A3               [24] 2405 	inc	dptr
      0065A2 F0               [24] 2406 	movx	@dptr,a
      0065A3 80 6F            [24] 2407 	sjmp	00252$
      0065A5                       2408 00232$:
                                   2409 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0065A5 B8 00 69         [24] 2410 	cjne	r0,#0x00,00228$
      0065A8 B9 03 66         [24] 2411 	cjne	r1,#0x03,00228$
      0065AB BB 01 63         [24] 2412 	cjne	r3,#0x01,00228$
      0065AE BC 00 60         [24] 2413 	cjne	r4,#0x00,00228$
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      0065B1 90 10 00         [24] 2415 	mov	dptr,#0x1000
      0065B4 74 41            [12] 2416 	mov	a,#0x41
      0065B6 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      0065B7 A3               [24] 2419 	inc	dptr
      0065B8 74 4B            [12] 2420 	mov	a,#0x4b
      0065BA F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      0065BB A3               [24] 2423 	inc	dptr
      0065BC 74 42            [12] 2424 	mov	a,#0x42
      0065BE F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      0065BF A3               [24] 2427 	inc	dptr
      0065C0 74 54            [12] 2428 	mov	a,#0x54
      0065C2 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      0065C3 A3               [24] 2431 	inc	dptr
      0065C4 74 01            [12] 2432 	mov	a,#0x01
      0065C6 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      0065C7 90 07 87         [24] 2435 	mov	dptr,#_ak820_boot_stage
      0065CA E0               [24] 2436 	movx	a,@dptr
      0065CB 90 10 05         [24] 2437 	mov	dptr,#0x1005
      0065CE F0               [24] 2438 	movx	@dptr,a
                                   2439 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0065CF 90 07 88         [24] 2440 	mov	dptr,#_ak820_main_heartbeat
      0065D2 E0               [24] 2441 	movx	a,@dptr
      0065D3 90 10 06         [24] 2442 	mov	dptr,#0x1006
      0065D6 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0065D7 90 07 82         [24] 2445 	mov	dptr,#_USB_EnumStatus
      0065DA E0               [24] 2446 	movx	a,@dptr
      0065DB 60 02            [24] 2447 	jz	00322$
      0065DD 74 01            [12] 2448 	mov	a,#0x01
      0065DF                       2449 00322$:
      0065DF F9               [12] 2450 	mov	r1,a
      0065E0 90 07 83         [24] 2451 	mov	dptr,#_USB_SleepStatus
      0065E3 E0               [24] 2452 	movx	a,@dptr
      0065E4 54 02            [12] 2453 	anl	a,#0x02
      0065E6 F8               [12] 2454 	mov	r0,a
      0065E7 E9               [12] 2455 	mov	a,r1
      0065E8 42 00            [12] 2456 	orl	ar0,a
      0065EA 90 10 07         [24] 2457 	mov	dptr,#0x1007
      0065ED E8               [12] 2458 	mov	a,r0
      0065EE F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      0065EF 90 07 EA         [24] 2461 	mov	dptr,#_control_setup_length_10000_287
      0065F2 E4               [12] 2462 	clr	a
      0065F3 F0               [24] 2463 	movx	@dptr,a
      0065F4 A3               [24] 2464 	inc	dptr
      0065F5 F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      0065F6 90 07 7C         [24] 2467 	mov	dptr,#_D0SetupLen
      0065F9 E0               [24] 2468 	movx	a,@dptr
      0065FA F8               [12] 2469 	mov	r0,a
      0065FB A3               [24] 2470 	inc	dptr
      0065FC E0               [24] 2471 	movx	a,@dptr
      0065FD F9               [12] 2472 	mov	r1,a
      0065FE C3               [12] 2473 	clr	c
      0065FF 74 08            [12] 2474 	mov	a,#0x08
      006601 98               [12] 2475 	subb	a,r0
      006602 E4               [12] 2476 	clr	a
      006603 99               [12] 2477 	subb	a,r1
      006604 50 0E            [24] 2478 	jnc	00252$
                                   2479 ;	free result
      006606 90 07 7C         [24] 2480 	mov	dptr,#_D0SetupLen
      006609 74 08            [12] 2481 	mov	a,#0x08
      00660B F0               [24] 2482 	movx	@dptr,a
      00660C E4               [12] 2483 	clr	a
      00660D A3               [24] 2484 	inc	dptr
      00660E F0               [24] 2485 	movx	@dptr,a
      00660F 80 03            [24] 2486 	sjmp	00252$
      006611                       2487 00228$:
                                   2488 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006611 02 5D 7A         [24] 2489 	ljmp	_control_stall
      006614                       2490 00252$:
                                   2491 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006614 90 07 EA         [24] 2492 	mov	dptr,#_control_setup_length_10000_287
      006617 E0               [24] 2493 	movx	a,@dptr
      006618 F5 19            [12] 2494 	mov	_control_setup_sloc4_1_0,a
      00661A A3               [24] 2495 	inc	dptr
      00661B E0               [24] 2496 	movx	a,@dptr
      00661C F5 1A            [12] 2497 	mov	(_control_setup_sloc4_1_0 + 1),a
      00661E E5 19            [12] 2498 	mov	a,_control_setup_sloc4_1_0
      006620 45 1A            [12] 2499 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006622 60 50            [24] 2500 	jz	00262$
                                   2501 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006624 90 07 7C         [24] 2502 	mov	dptr,#_D0SetupLen
      006627 E0               [24] 2503 	movx	a,@dptr
      006628 F8               [12] 2504 	mov	r0,a
      006629 A3               [24] 2505 	inc	dptr
      00662A E0               [24] 2506 	movx	a,@dptr
      00662B F9               [12] 2507 	mov	r1,a
      00662C C3               [12] 2508 	clr	c
      00662D E5 19            [12] 2509 	mov	a,_control_setup_sloc4_1_0
      00662F 98               [12] 2510 	subb	a,r0
      006630 E5 1A            [12] 2511 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006632 99               [12] 2512 	subb	a,r1
      006633 50 0A            [24] 2513 	jnc	00559$
                                   2514 ;	free result
      006635 90 07 7C         [24] 2515 	mov	dptr,#_D0SetupLen
      006638 E5 19            [12] 2516 	mov	a,_control_setup_sloc4_1_0
      00663A F0               [24] 2517 	movx	@dptr,a
      00663B E5 1A            [12] 2518 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00663D A3               [24] 2519 	inc	dptr
      00663E F0               [24] 2520 	movx	@dptr,a
                                   2521 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00663F                       2522 00559$:
      00663F 75 19 00         [24] 2523 	mov	_control_setup_sloc4_1_0,#0x00
      006642                       2524 00296$:
      006642 90 07 7C         [24] 2525 	mov	dptr,#_D0SetupLen
      006645 E0               [24] 2526 	movx	a,@dptr
      006646 F8               [12] 2527 	mov	r0,a
      006647 C3               [12] 2528 	clr	c
      006648 E5 19            [12] 2529 	mov	a,_control_setup_sloc4_1_0
      00664A 98               [12] 2530 	subb	a,r0
      00664B 50 46            [24] 2531 	jnc	00263$
      00664D 85 19 17         [24] 2532 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006650 74 10            [12] 2533 	mov	a,#0x10
      006652 24 00            [12] 2534 	add	a, #0x00
      006654 F5 18            [12] 2535 	mov	(_control_setup_sloc3_1_0 + 1),a
      006656 90 07 EC         [24] 2536 	mov	dptr,#_control_setup_offset_10000_287
      006659 E0               [24] 2537 	movx	a,@dptr
      00665A 25 19            [12] 2538 	add	a, _control_setup_sloc4_1_0
      00665C 24 AC            [12] 2539 	add	a, #_input_snapshot
      00665E F5 82            [12] 2540 	mov	dpl,a
      006660 E4               [12] 2541 	clr	a
      006661 34 07            [12] 2542 	addc	a,#(_input_snapshot >> 8)
      006663 F5 83            [12] 2543 	mov	dph,a
      006665 E0               [24] 2544 	movx	a,@dptr
      006666 85 17 82         [24] 2545 	mov	dpl,_control_setup_sloc3_1_0
      006669 85 18 83         [24] 2546 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00666C F0               [24] 2547 	movx	@dptr,a
      00666D E5 19            [12] 2548 	mov	a,_control_setup_sloc4_1_0
      00666F 04               [12] 2549 	inc	a
      006670 F5 19            [12] 2550 	mov	_control_setup_sloc4_1_0,a
      006672 80 CE            [24] 2551 	sjmp	00296$
      006674                       2552 00262$:
                                   2553 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006674 BB 01 1C         [24] 2554 	cjne	r3,#0x01,00263$
      006677 BC 00 19         [24] 2555 	cjne	r4,#0x00,00263$
      00667A 90 07 7C         [24] 2556 	mov	dptr,#_D0SetupLen
      00667D E0               [24] 2557 	movx	a,@dptr
      00667E F8               [12] 2558 	mov	r0,a
      00667F A3               [24] 2559 	inc	dptr
      006680 E0               [24] 2560 	movx	a,@dptr
      006681 F9               [12] 2561 	mov	r1,a
      006682 C3               [12] 2562 	clr	c
      006683 74 20            [12] 2563 	mov	a,#0x20
      006685 98               [12] 2564 	subb	a,r0
      006686 E4               [12] 2565 	clr	a
      006687 99               [12] 2566 	subb	a,r1
      006688 50 09            [24] 2567 	jnc	00263$
                                   2568 ;	free result
      00668A 90 07 7C         [24] 2569 	mov	dptr,#_D0SetupLen
      00668D 74 20            [12] 2570 	mov	a,#0x20
      00668F F0               [24] 2571 	movx	@dptr,a
      006690 E4               [12] 2572 	clr	a
      006691 A3               [24] 2573 	inc	dptr
      006692 F0               [24] 2574 	movx	@dptr,a
      006693                       2575 00263$:
                                   2576 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006693 90 07 7C         [24] 2577 	mov	dptr,#_D0SetupLen
      006696 E0               [24] 2578 	movx	a,@dptr
      006697 90 22 08         [24] 2579 	mov	dptr,#0x2208
      00669A F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      00669B 90 07 E0         [24] 2582 	mov	dptr,#_control_phase
      00669E 74 02            [12] 2583 	mov	a,#0x02
      0066A0 F0               [24] 2584 	movx	@dptr,a
      0066A1 02 67 29         [24] 2585 	ljmp	00291$
      0066A4                       2586 00273$:
                                   2587 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0066A4 EB               [12] 2588 	mov	a,r3
      0066A5 4C               [12] 2589 	orl	a,r4
      0066A6 70 37            [24] 2590 	jnz	00265$
      0066A8 90 07 81         [24] 2591 	mov	dptr,#_D0UsbConfig
      0066AB E0               [24] 2592 	movx	a,@dptr
      0066AC 60 31            [24] 2593 	jz	00265$
      0066AE EA               [12] 2594 	mov	a,r2
      0066AF 60 2E            [24] 2595 	jz	00265$
      0066B1 90 07 7B         [24] 2596 	mov	dptr,#_D0SetupReqCode
      0066B4 E0               [24] 2597 	movx	a,@dptr
      0066B5 FA               [12] 2598 	mov	r2,a
      0066B6 BA 03 26         [24] 2599 	cjne	r2,#0x03,00265$
      0066B9 30 18 23         [24] 2600 	jnb	_control_setup_zero_value_10000_287,00265$
      0066BC 90 07 7C         [24] 2601 	mov	dptr,#_D0SetupLen
      0066BF E0               [24] 2602 	movx	a,@dptr
      0066C0 F9               [12] 2603 	mov	r1,a
      0066C1 A3               [24] 2604 	inc	dptr
      0066C2 E0               [24] 2605 	movx	a,@dptr
      0066C3 FA               [12] 2606 	mov	r2,a
      0066C4 B9 01 18         [24] 2607 	cjne	r1,#0x01,00265$
      0066C7 BA 00 15         [24] 2608 	cjne	r2,#0x00,00265$
                                   2609 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      0066CA 90 0D D4         [24] 2610 	mov	dptr,#_keyboard_protocol
      0066CD E0               [24] 2611 	movx	a,@dptr
      0066CE 90 10 00         [24] 2612 	mov	dptr,#0x1000
      0066D1 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      0066D2 90 22 08         [24] 2615 	mov	dptr,#0x2208
      0066D5 74 01            [12] 2616 	mov	a,#0x01
      0066D7 F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      0066D8 90 07 E0         [24] 2619 	mov	dptr,#_control_phase
      0066DB 04               [12] 2620 	inc	a
      0066DC F0               [24] 2621 	movx	@dptr,a
      0066DD 80 4A            [24] 2622 	sjmp	00291$
      0066DF                       2623 00265$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2625 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      0066DF 02 5D 7A         [24] 2626 	ljmp	_control_stall
      0066E2                       2627 00282$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0066E2 30 16 3E         [24] 2629 	jnb	_control_setup_valid_interface_10000_287,00284$
      0066E5 90 07 81         [24] 2630 	mov	dptr,#_D0UsbConfig
      0066E8 E0               [24] 2631 	movx	a,@dptr
      0066E9 60 38            [24] 2632 	jz	00284$
      0066EB BF A1 35         [24] 2633 	cjne	r7,#0xa1,00284$
      0066EE 8E 05            [24] 2634 	mov	ar5,r6
      0066F0 7E 00            [12] 2635 	mov	r6,#0x00
      0066F2 ED               [12] 2636 	mov	a,r5
      0066F3 4E               [12] 2637 	orl	a,r6
      0066F4 70 2D            [24] 2638 	jnz	00284$
      0066F6 90 07 7C         [24] 2639 	mov	dptr,#_D0SetupLen
      0066F9 E0               [24] 2640 	movx	a,@dptr
      0066FA FE               [12] 2641 	mov	r6,a
      0066FB A3               [24] 2642 	inc	dptr
      0066FC E0               [24] 2643 	movx	a,@dptr
      0066FD FF               [12] 2644 	mov	r7,a
      0066FE BE 01 22         [24] 2645 	cjne	r6,#0x01,00284$
      006701 BF 00 1F         [24] 2646 	cjne	r7,#0x00,00284$
                                   2647 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006704 EB               [12] 2648 	mov	a,r3
      006705 4C               [12] 2649 	orl	a,r4
      006706 70 07            [24] 2650 	jnz	00324$
      006708 90 06 43         [24] 2651 	mov	dptr,#_keyboard_idle
      00670B E0               [24] 2652 	movx	a,@dptr
      00670C FF               [12] 2653 	mov	r7,a
      00670D 80 02            [24] 2654 	sjmp	00325$
      00670F                       2655 00324$:
      00670F 7F 00            [12] 2656 	mov	r7,#0x00
      006711                       2657 00325$:
      006711 90 10 00         [24] 2658 	mov	dptr,#0x1000
      006714 EF               [12] 2659 	mov	a,r7
      006715 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006716 90 22 08         [24] 2662 	mov	dptr,#0x2208
      006719 74 01            [12] 2663 	mov	a,#0x01
      00671B F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      00671C 90 07 E0         [24] 2666 	mov	dptr,#_control_phase
      00671F 04               [12] 2667 	inc	a
      006720 F0               [24] 2668 	movx	@dptr,a
      006721 80 06            [24] 2669 	sjmp	00291$
      006723                       2670 00284$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2672 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006723 02 5D 7A         [24] 2673 	ljmp	_control_stall
      006726                       2674 00290$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006726 02 5D 7A         [24] 2676 	ljmp	_control_stall
      006729                       2677 00291$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006729 90 22 00         [24] 2679 	mov	dptr,#0x2200
      00672C 74 C0            [12] 2680 	mov	a,#0xc0
      00672E F0               [24] 2681 	movx	@dptr,a
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      00672F 22               [24] 2683 	ret
                                   2684 ;------------------------------------------------------------
                                   2685 ;Allocation info for local variables in function 'control_out'
                                   2686 ;------------------------------------------------------------
                                   2687 ;i             Allocated with name '_control_out_i_10000_371'
                                   2688 ;------------------------------------------------------------
                                   2689 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2690 ;	-----------------------------------------
                                   2691 ;	 function control_out
                                   2692 ;	-----------------------------------------
      006730                       2693 _control_out:
                                   2694 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006730 90 22 0F         [24] 2695 	mov	dptr,#0x220f
      006733 E0               [24] 2696 	movx	a,@dptr
      006734 20 E6 01         [24] 2697 	jb	acc.6,00102$
      006737 22               [24] 2698 	ret
      006738                       2699 00102$:
                                   2700 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006738 90 07 E0         [24] 2701 	mov	dptr,#_control_phase
      00673B E0               [24] 2702 	movx	a,@dptr
      00673C FF               [12] 2703 	mov	r7,a
      00673D BF 02 12         [24] 2704 	cjne	r7,#0x02,00104$
      006740 90 22 0E         [24] 2705 	mov	dptr,#0x220e
      006743 E0               [24] 2706 	movx	a,@dptr
      006744 70 0C            [24] 2707 	jnz	00104$
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006746 90 07 E0         [24] 2709 	mov	dptr,#_control_phase
      006749 E4               [12] 2710 	clr	a
      00674A F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00674B 90 22 00         [24] 2713 	mov	dptr,#0x2200
      00674E 74 02            [12] 2714 	mov	a,#0x02
      006750 F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006751 22               [24] 2717 	ret
      006752                       2718 00104$:
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006752 BF 04 19         [24] 2720 	cjne	r7,#0x04,00106$
      006755 90 22 0E         [24] 2721 	mov	dptr,#0x220e
      006758 E0               [24] 2722 	movx	a,@dptr
      006759 FF               [12] 2723 	mov	r7,a
      00675A 90 07 7C         [24] 2724 	mov	dptr,#_D0SetupLen
      00675D E0               [24] 2725 	movx	a,@dptr
      00675E FD               [12] 2726 	mov	r5,a
      00675F A3               [24] 2727 	inc	dptr
      006760 E0               [24] 2728 	movx	a,@dptr
      006761 FE               [12] 2729 	mov	r6,a
      006762 7C 00            [12] 2730 	mov	r4,#0x00
      006764 EF               [12] 2731 	mov	a,r7
      006765 B5 05 06         [24] 2732 	cjne	a,ar5,00209$
      006768 EC               [12] 2733 	mov	a,r4
      006769 B5 06 02         [24] 2734 	cjne	a,ar6,00209$
      00676C 80 03            [24] 2735 	sjmp	00107$
      00676E                       2736 00209$:
      00676E                       2737 00106$:
      00676E 02 5D 7A         [24] 2738 	ljmp	_control_stall
      006771                       2739 00107$:
                                   2740 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006771 90 07 E1         [24] 2741 	mov	dptr,#_output_kind
      006774 E0               [24] 2742 	movx	a,@dptr
      006775 FF               [12] 2743 	mov	r7,a
      006776 BF 01 2E         [24] 2744 	cjne	r7,#0x01,00118$
      006779 90 07 89         [24] 2745 	mov	dptr,#_raw_state
      00677C E0               [24] 2746 	movx	a,@dptr
      00677D FE               [12] 2747 	mov	r6,a
      00677E BE 01 26         [24] 2748 	cjne	r6,#0x01,00118$
                                   2749 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006781 7E 00            [12] 2750 	mov	r6,#0x00
      006783                       2751 00121$:
      006783 EE               [12] 2752 	mov	a,r6
      006784 24 8A            [12] 2753 	add	a, #_raw_buffer
      006786 FC               [12] 2754 	mov	r4,a
      006787 E4               [12] 2755 	clr	a
      006788 34 07            [12] 2756 	addc	a, #(_raw_buffer >> 8)
      00678A FD               [12] 2757 	mov	r5,a
      00678B 8E 82            [24] 2758 	mov	dpl,r6
      00678D 74 10            [12] 2759 	mov	a,#0x10
      00678F 24 00            [12] 2760 	add	a, #0x00
      006791 F5 83            [12] 2761 	mov	dph,a
      006793 E0               [24] 2762 	movx	a,@dptr
      006794 8C 82            [24] 2763 	mov	dpl,r4
      006796 8D 83            [24] 2764 	mov	dph,r5
      006798 F0               [24] 2765 	movx	@dptr,a
      006799 0E               [12] 2766 	inc	r6
      00679A BE 20 00         [24] 2767 	cjne	r6,#0x20,00214$
      00679D                       2768 00214$:
      00679D 40 E4            [24] 2769 	jc	00121$
                                   2770 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00679F 90 07 89         [24] 2771 	mov	dptr,#_raw_state
      0067A2 74 02            [12] 2772 	mov	a,#0x02
      0067A4 F0               [24] 2773 	movx	@dptr,a
      0067A5 80 2B            [24] 2774 	sjmp	00119$
      0067A7                       2775 00118$:
                                   2776 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0067A7 BF 02 0A         [24] 2777 	cjne	r7,#0x02,00115$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0067AA 90 10 00         [24] 2779 	mov	dptr,#0x1000
      0067AD E0               [24] 2780 	movx	a,@dptr
      0067AE 90 07 86         [24] 2781 	mov	dptr,#_KB_USB_SetReport
      0067B1 F0               [24] 2782 	movx	@dptr,a
      0067B2 80 1E            [24] 2783 	sjmp	00119$
      0067B4                       2784 00115$:
                                   2785 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0067B4 BF 03 18         [24] 2786 	cjne	r7,#0x03,00111$
      0067B7 90 10 00         [24] 2787 	mov	dptr,#0x1000
      0067BA E0               [24] 2788 	movx	a,@dptr
      0067BB FF               [12] 2789 	mov	r7,a
      0067BC 90 07 E2         [24] 2790 	mov	dptr,#_output_report_id
      0067BF E0               [24] 2791 	movx	a,@dptr
      0067C0 FE               [12] 2792 	mov	r6,a
      0067C1 EF               [12] 2793 	mov	a,r7
      0067C2 B5 06 0A         [24] 2794 	cjne	a,ar6,00111$
                                   2795 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      0067C5 90 10 01         [24] 2796 	mov	dptr,#0x1001
      0067C8 E0               [24] 2797 	movx	a,@dptr
      0067C9 90 07 86         [24] 2798 	mov	dptr,#_KB_USB_SetReport
      0067CC F0               [24] 2799 	movx	@dptr,a
      0067CD 80 03            [24] 2800 	sjmp	00119$
      0067CF                       2801 00111$:
                                   2802 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      0067CF 02 5D 7A         [24] 2803 	ljmp	_control_stall
      0067D2                       2804 00119$:
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      0067D2 90 07 E1         [24] 2806 	mov	dptr,#_output_kind
      0067D5 E4               [12] 2807 	clr	a
      0067D6 F0               [24] 2808 	movx	@dptr,a
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      0067D7 90 07 7C         [24] 2810 	mov	dptr,#_D0SetupLen
      0067DA F0               [24] 2811 	movx	@dptr,a
      0067DB A3               [24] 2812 	inc	dptr
      0067DC F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      0067DD 90 07 E0         [24] 2815 	mov	dptr,#_control_phase
      0067E0 74 03            [12] 2816 	mov	a,#0x03
      0067E2 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      0067E3 90 22 08         [24] 2819 	mov	dptr,#0x2208
      0067E6 E4               [12] 2820 	clr	a
      0067E7 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0067E8 F5 82            [12] 2823 	mov	dpl,a
      0067EA 74 48            [12] 2824 	mov	a,#0x48
      0067EC F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      0067ED 22               [24] 2827 	ret
                                   2828 ;------------------------------------------------------------
                                   2829 ;Allocation info for local variables in function 'control_in'
                                   2830 ;------------------------------------------------------------
                                   2831 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2832 ;	-----------------------------------------
                                   2833 ;	 function control_in
                                   2834 ;	-----------------------------------------
      0067EE                       2835 _control_in:
                                   2836 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      0067EE 90 07 E0         [24] 2837 	mov	dptr,#_control_phase
      0067F1 E0               [24] 2838 	movx	a,@dptr
      0067F2 FF               [12] 2839 	mov	r7,a
      0067F3 BF 01 22         [24] 2840 	cjne	r7,#0x01,00109$
                                   2841 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      0067F6 90 07 7C         [24] 2842 	mov	dptr,#_D0SetupLen
      0067F9 E0               [24] 2843 	movx	a,@dptr
      0067FA FD               [12] 2844 	mov	r5,a
      0067FB A3               [24] 2845 	inc	dptr
      0067FC E0               [24] 2846 	movx	a,@dptr
      0067FD 4D               [12] 2847 	orl	a,r5
      0067FE 70 06            [24] 2848 	jnz	00101$
      006800 90 07 E3         [24] 2849 	mov	dptr,#_control_zlp
      006803 E0               [24] 2850 	movx	a,@dptr
      006804 60 0A            [24] 2851 	jz	00102$
      006806                       2852 00101$:
                                   2853 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006806 90 22 00         [24] 2854 	mov	dptr,#0x2200
      006809 E0               [24] 2855 	movx	a,@dptr
      00680A 64 40            [12] 2856 	xrl	a,#0x40
      00680C F0               [24] 2857 	movx	@dptr,a
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2859 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      00680D 02 5D 9C         [24] 2860 	ljmp	_control_next
      006810                       2861 00102$:
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006810 90 07 E0         [24] 2863 	mov	dptr,#_control_phase
      006813 74 02            [12] 2864 	mov	a,#0x02
      006815 F0               [24] 2865 	movx	@dptr,a
      006816 80 18            [24] 2866 	sjmp	00110$
      006818                       2867 00109$:
                                   2868 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006818 BF 03 15         [24] 2869 	cjne	r7,#0x03,00110$
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00681B 90 07 7B         [24] 2871 	mov	dptr,#_D0SetupReqCode
      00681E E0               [24] 2872 	movx	a,@dptr
      00681F FF               [12] 2873 	mov	r7,a
      006820 BF 05 08         [24] 2874 	cjne	r7,#0x05,00105$
      006823 90 07 7C         [24] 2875 	mov	dptr,#_D0SetupLen
      006826 E0               [24] 2876 	movx	a,@dptr
      006827 90 22 07         [24] 2877 	mov	dptr,#0x2207
      00682A F0               [24] 2878 	movx	@dptr,a
      00682B                       2879 00105$:
                                   2880 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      00682B 90 07 E0         [24] 2881 	mov	dptr,#_control_phase
      00682E E4               [12] 2882 	clr	a
      00682F F0               [24] 2883 	movx	@dptr,a
      006830                       2884 00110$:
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006830 90 22 00         [24] 2886 	mov	dptr,#0x2200
      006833 74 82            [12] 2887 	mov	a,#0x82
      006835 F0               [24] 2888 	movx	@dptr,a
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006836 22               [24] 2890 	ret
                                   2891 ;------------------------------------------------------------
                                   2892 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2893 ;------------------------------------------------------------
                                   2894 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2895 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2896 ;------------------------------------------------------------
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2898 ;	-----------------------------------------
                                   2899 ;	 function USB_DeviceInterrupt
                                   2900 ;	-----------------------------------------
      006837                       2901 _USB_DeviceInterrupt:
                                   2902 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006837                       2903 00129$:
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006837 90 22 3D         [24] 2905 	mov	dptr,#0x223d
      00683A E0               [24] 2906 	movx	a,@dptr
      00683B 30 E0 4B         [24] 2907 	jnb	acc.0,00127$
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      00683E 12 5D 1D         [24] 2909 	lcall	_endpoints_reset
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006841 90 22 07         [24] 2911 	mov	dptr,#0x2207
      006844 E4               [12] 2912 	clr	a
      006845 F0               [24] 2913 	movx	@dptr,a
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006846 90 07 83         [24] 2915 	mov	dptr,#_USB_SleepStatus
      006849 F0               [24] 2916 	movx	@dptr,a
      00684A 90 07 82         [24] 2917 	mov	dptr,#_USB_EnumStatus
      00684D F0               [24] 2918 	movx	@dptr,a
      00684E 90 07 81         [24] 2919 	mov	dptr,#_D0UsbConfig
      006851 F0               [24] 2920 	movx	@dptr,a
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006852 90 07 86         [24] 2922 	mov	dptr,#_KB_USB_SetReport
      006855 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006856 90 0D D4         [24] 2925 	mov	dptr,#_keyboard_protocol
      006859 04               [12] 2926 	inc	a
      00685A F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      00685B 90 06 43         [24] 2929 	mov	dptr,#_keyboard_idle
      00685E E4               [12] 2930 	clr	a
      00685F F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006860 90 07 AB         [24] 2933 	mov	dptr,#_keyboard_reset
      006863 04               [12] 2934 	inc	a
      006864 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006865 90 07 7B         [24] 2937 	mov	dptr,#_D0SetupReqCode
      006868 74 FF            [12] 2938 	mov	a,#0xff
      00686A F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      00686B 90 07 7C         [24] 2941 	mov	dptr,#_D0SetupLen
      00686E E4               [12] 2942 	clr	a
      00686F F0               [24] 2943 	movx	@dptr,a
      006870 A3               [24] 2944 	inc	dptr
      006871 F0               [24] 2945 	movx	@dptr,a
                                   2946 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006872 90 07 E0         [24] 2947 	mov	dptr,#_control_phase
      006875 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006876 90 22 00         [24] 2950 	mov	dptr,#0x2200
      006879 74 02            [12] 2951 	mov	a,#0x02
      00687B F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      00687C 90 22 0F         [24] 2954 	mov	dptr,#0x220f
      00687F E4               [12] 2955 	clr	a
      006880 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006881 90 22 3D         [24] 2958 	mov	dptr,#0x223d
      006884 04               [12] 2959 	inc	a
      006885 F0               [24] 2960 	movx	@dptr,a
      006886 02 69 1C         [24] 2961 	ljmp	00130$
      006889                       2962 00127$:
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006889 90 22 3D         [24] 2964 	mov	dptr,#0x223d
      00688C E0               [24] 2965 	movx	a,@dptr
      00688D 30 E5 60         [24] 2966 	jnb	acc.5,00124$
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006890 90 22 0F         [24] 2968 	mov	dptr,#0x220f
      006893 E0               [24] 2969 	movx	a,@dptr
      006894 FF               [12] 2970 	mov	r7,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006895 74 07            [12] 2972 	mov	a,#0x07
      006897 5F               [12] 2973 	anl	a,r7
      006898 FE               [12] 2974 	mov	r6,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006899 EF               [12] 2976 	mov	a,r7
      00689A 54 18            [12] 2977 	anl	a,#0x18
      00689C 70 08            [24] 2978 	jnz	00115$
      00689E EE               [12] 2979 	mov	a,r6
      00689F 70 05            [24] 2980 	jnz	00115$
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      0068A1 12 67 30         [24] 2982 	lcall	_control_out
      0068A4 80 43            [24] 2983 	sjmp	00116$
      0068A6                       2984 00115$:
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0068A6 8F 05            [24] 2986 	mov	ar5,r7
      0068A8 74 18            [12] 2987 	mov	a,#0x18
      0068AA 5D               [12] 2988 	anl	a,r5
      0068AB FC               [12] 2989 	mov	r4,a
      0068AC BC 10 2D         [24] 2990 	cjne	r4,#0x10,00112$
                                   2991 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      0068AF EE               [12] 2992 	mov	a,r6
      0068B0 70 05            [24] 2993 	jnz	00106$
      0068B2 12 67 EE         [24] 2994 	lcall	_control_in
      0068B5 80 32            [24] 2995 	sjmp	00116$
      0068B7                       2996 00106$:
                                   2997 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      0068B7 EE               [12] 2998 	mov	a,r6
      0068B8 24 FC            [12] 2999 	add	a,#0xff - 0x03
      0068BA 40 2D            [24] 3000 	jc	00116$
                                   3001 ;	free result
                                   3002 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      0068BC 8E 04            [24] 3003 	mov	ar4,r6
      0068BE 7B 00            [12] 3004 	mov	r3,#0x00
      0068C0 74 22            [12] 3005 	mov	a,#0x22
      0068C2 2B               [12] 3006 	add	a, r3
      0068C3 FB               [12] 3007 	mov	r3,a
      0068C4 8C 82            [24] 3008 	mov	dpl,r4
      0068C6 8B 83            [24] 3009 	mov	dph,r3
      0068C8 E0               [24] 3010 	movx	a,@dptr
      0068C9 FA               [12] 3011 	mov	r2,a
      0068CA 74 FC            [12] 3012 	mov	a,#0xfc
      0068CC 5A               [12] 3013 	anl	a,r2
      0068CD 44 02            [12] 3014 	orl	a,#0x02
      0068CF 8C 82            [24] 3015 	mov	dpl,r4
      0068D1 8B 83            [24] 3016 	mov	dph,r3
      0068D3 F0               [24] 3017 	movx	@dptr,a
                                   3018 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0068D4 BE 03 12         [24] 3019 	cjne	r6,#0x03,00116$
      0068D7 12 5D 00         [24] 3020 	lcall	_raw_complete
      0068DA 80 0D            [24] 3021 	sjmp	00116$
      0068DC                       3022 00112$:
                                   3023 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      0068DC 53 05 18         [24] 3024 	anl	ar5,#0x18
      0068DF BD 18 07         [24] 3025 	cjne	r5,#0x18,00116$
      0068E2 EF               [12] 3026 	mov	a,r7
      0068E3 30 E5 03         [24] 3027 	jnb	acc.5,00116$
                                   3028 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      0068E6 12 5F 93         [24] 3029 	lcall	_control_setup
      0068E9                       3030 00116$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      0068E9 90 22 0F         [24] 3032 	mov	dptr,#0x220f
      0068EC E4               [12] 3033 	clr	a
      0068ED F0               [24] 3034 	movx	@dptr,a
      0068EE 80 2C            [24] 3035 	sjmp	00130$
      0068F0                       3036 00124$:
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      0068F0 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      0068F3 E0               [24] 3039 	movx	a,@dptr
      0068F4 30 E2 25         [24] 3040 	jnb	acc.2,00130$
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0068F7 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      0068FA E0               [24] 3043 	movx	a,@dptr
      0068FB 30 E3 0A         [24] 3044 	jnb	acc.3,00119$
      0068FE 90 07 83         [24] 3045 	mov	dptr,#_USB_SleepStatus
      006901 E0               [24] 3046 	movx	a,@dptr
      006902 43 E0 02         [24] 3047 	orl	acc,#0x02
      006905 F0               [24] 3048 	movx	@dptr,a
      006906 80 0E            [24] 3049 	sjmp	00120$
      006908                       3050 00119$:
                                   3051 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006908 90 07 83         [24] 3052 	mov	dptr,#_USB_SleepStatus
      00690B E0               [24] 3053 	movx	a,@dptr
      00690C 53 E0 FD         [24] 3054 	anl	acc,#0xfd
      00690F F0               [24] 3055 	movx	@dptr,a
                                   3056 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006910 90 07 AB         [24] 3057 	mov	dptr,#_keyboard_reset
      006913 74 01            [12] 3058 	mov	a,#0x01
      006915 F0               [24] 3059 	movx	@dptr,a
      006916                       3060 00120$:
                                   3061 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006916 90 22 3D         [24] 3062 	mov	dptr,#0x223d
      006919 74 04            [12] 3063 	mov	a,#0x04
      00691B F0               [24] 3064 	movx	@dptr,a
      00691C                       3065 00130$:
                                   3066 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      00691C 90 22 3D         [24] 3067 	mov	dptr,#0x223d
      00691F E0               [24] 3068 	movx	a,@dptr
      006920 54 25            [12] 3069 	anl	a,#0x25
      006922 60 03            [24] 3070 	jz	00242$
      006924 02 68 37         [24] 3071 	ljmp	00129$
      006927                       3072 00242$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006927 22               [24] 3074 	ret
                                   3075 ;------------------------------------------------------------
                                   3076 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3077 ;------------------------------------------------------------
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3079 ;	-----------------------------------------
                                   3080 ;	 function USB_Device_Init
                                   3081 ;	-----------------------------------------
      006928                       3082 _USB_Device_Init:
                                   3083 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3084 ;	assignBit
      006928 C2 E9            [12] 3085 	clr	_IE_USB
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      00692A 90 22 3C         [24] 3087 	mov	dptr,#0x223c
      00692D E4               [12] 3088 	clr	a
      00692E F0               [24] 3089 	movx	@dptr,a
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      00692F 90 07 89         [24] 3091 	mov	dptr,#_raw_state
      006932 F0               [24] 3092 	movx	@dptr,a
                                   3093 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006933 12 5D 1D         [24] 3094 	lcall	_endpoints_reset
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006936 90 07 83         [24] 3096 	mov	dptr,#_USB_SleepStatus
      006939 E4               [12] 3097 	clr	a
      00693A F0               [24] 3098 	movx	@dptr,a
      00693B 90 07 82         [24] 3099 	mov	dptr,#_USB_EnumStatus
      00693E F0               [24] 3100 	movx	@dptr,a
      00693F 90 07 81         [24] 3101 	mov	dptr,#_D0UsbConfig
      006942 F0               [24] 3102 	movx	@dptr,a
      006943 90 22 07         [24] 3103 	mov	dptr,#0x2207
      006946 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006947 90 07 84         [24] 3106 	mov	dptr,#_MCU_Sleep_Operate
      00694A F0               [24] 3107 	movx	@dptr,a
      00694B 90 07 85         [24] 3108 	mov	dptr,#_KB_USB_UpStatus
      00694E F0               [24] 3109 	movx	@dptr,a
      00694F 90 07 86         [24] 3110 	mov	dptr,#_KB_USB_SetReport
      006952 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006953 90 0D D4         [24] 3113 	mov	dptr,#_keyboard_protocol
      006956 04               [12] 3114 	inc	a
      006957 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006958 90 06 43         [24] 3117 	mov	dptr,#_keyboard_idle
      00695B E4               [12] 3118 	clr	a
      00695C F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      00695D 90 07 AB         [24] 3121 	mov	dptr,#_keyboard_reset
      006960 F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006961 90 07 E0         [24] 3124 	mov	dptr,#_control_phase
      006964 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006965 90 07 7B         [24] 3127 	mov	dptr,#_D0SetupReqCode
      006968 14               [12] 3128 	dec	a
      006969 F0               [24] 3129 	movx	@dptr,a
                                   3130 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      00696A 90 07 7C         [24] 3131 	mov	dptr,#_D0SetupLen
      00696D E4               [12] 3132 	clr	a
      00696E F0               [24] 3133 	movx	@dptr,a
      00696F A3               [24] 3134 	inc	dptr
      006970 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006971 90 22 00         [24] 3137 	mov	dptr,#0x2200
      006974 74 02            [12] 3138 	mov	a,#0x02
      006976 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006977 90 22 37         [24] 3141 	mov	dptr,#0x2237
      00697A 74 7F            [12] 3142 	mov	a,#0x7f
      00697C F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      00697D 90 22 3D         [24] 3145 	mov	dptr,#0x223d
      006980 74 FF            [12] 3146 	mov	a,#0xff
      006982 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006983 90 22 3B         [24] 3149 	mov	dptr,#0x223b
      006986 74 07            [12] 3150 	mov	a,#0x07
      006988 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006989 A3               [24] 3153 	inc	dptr
      00698A 74 80            [12] 3154 	mov	a,#0x80
      00698C F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3157 ;	assignBit
      00698D D2 E9            [12] 3158 	setb	_IE_USB
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      00698F 22               [24] 3160 	ret
                                   3161 ;------------------------------------------------------------
                                   3162 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3163 ;------------------------------------------------------------
                                   3164 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3165 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3166 ;------------------------------------------------------------
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3168 ;	-----------------------------------------
                                   3169 ;	 function USB_WakeUp_PC
                                   3170 ;	-----------------------------------------
      006990                       3171 _USB_WakeUp_PC:
                                   3172 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006990 90 07 83         [24] 3173 	mov	dptr,#_USB_SleepStatus
      006993 E0               [24] 3174 	movx	a,@dptr
      006994 FF               [12] 3175 	mov	r7,a
      006995 BF 03 22         [24] 3176 	cjne	r7,#0x03,00110$
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006998 90 22 3C         [24] 3178 	mov	dptr,#0x223c
      00699B E0               [24] 3179 	movx	a,@dptr
      00699C FF               [12] 3180 	mov	r7,a
                                   3181 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      00699D E0               [24] 3182 	movx	a,@dptr
      00699E FE               [12] 3183 	mov	r6,a
      00699F 63 06 C0         [24] 3184 	xrl	ar6,#0xc0
      0069A2 90 22 3C         [24] 3185 	mov	dptr,#0x223c
      0069A5 EE               [12] 3186 	mov	a,r6
      0069A6 F0               [24] 3187 	movx	@dptr,a
                                   3188 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      0069A7 7E 0A            [12] 3189 	mov	r6,#0x0a
      0069A9                       3190 00108$:
      0069A9 EE               [12] 3191 	mov	a,r6
      0069AA 60 09            [24] 3192 	jz	00105$
      0069AC 90 00 01         [24] 3193 	mov	dptr,#0x0001
      0069AF 12 5B 44         [24] 3194 	lcall	_mDelaymS
      0069B2 1E               [12] 3195 	dec	r6
      0069B3 80 F4            [24] 3196 	sjmp	00108$
      0069B5                       3197 00105$:
                                   3198 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      0069B5 90 22 3C         [24] 3199 	mov	dptr,#0x223c
      0069B8 EF               [12] 3200 	mov	a,r7
      0069B9 F0               [24] 3201 	movx	@dptr,a
      0069BA                       3202 00110$:
                                   3203 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      0069BA 22               [24] 3204 	ret
                                   3205 ;------------------------------------------------------------
                                   3206 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3207 ;------------------------------------------------------------
                                   3208 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3209 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3210 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3211 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3212 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3213 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3215 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3216 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3217 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3218 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3219 ;------------------------------------------------------------
                                   3220 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3221 ;	-----------------------------------------
                                   3222 ;	 function ak820_usb_send
                                   3223 ;	-----------------------------------------
      0069BB                       3224 _ak820_usb_send:
      0069BB E5 82            [12] 3225 	mov	a,dpl
      0069BD 90 07 F0         [24] 3226 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      0069C0 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      0069C1 90 07 F1         [24] 3229 	mov	dptr,#_ak820_usb_send_offset_10000_424
      0069C4 74 34            [12] 3230 	mov	a,#0x34
      0069C6 F0               [24] 3231 	movx	@dptr,a
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      0069C7 90 07 F0         [24] 3233 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      0069CA E0               [24] 3234 	movx	a,@dptr
      0069CB FF               [12] 3235 	mov	r7,a
      0069CC BF 01 00         [24] 3236 	cjne	r7,#0x01,00306$
      0069CF                       3237 00306$:
      0069CF 40 14            [24] 3238 	jc	00101$
      0069D1 EF               [12] 3239 	mov	a,r7
      0069D2 24 FC            [12] 3240 	add	a,#0xff - 0x03
      0069D4 40 0F            [24] 3241 	jc	00101$
                                   3242 ;	free result
      0069D6 90 07 EF         [24] 3243 	mov	dptr,#_ak820_usb_send_PARM_3
      0069D9 E0               [24] 3244 	movx	a,@dptr
      0069DA FE               [12] 3245 	mov  r6,a
      0069DB 24 BF            [12] 3246 	add	a,#0xff - 0x40
      0069DD 40 06            [24] 3247 	jc	00101$
                                   3248 ;	free result
      0069DF 90 07 82         [24] 3249 	mov	dptr,#_USB_EnumStatus
      0069E2 E0               [24] 3250 	movx	a,@dptr
      0069E3 70 04            [24] 3251 	jnz	00102$
      0069E5                       3252 00101$:
      0069E5 75 82 00         [24] 3253 	mov	dpl, #0x00
      0069E8 22               [24] 3254 	ret
      0069E9                       3255 00102$:
                                   3256 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      0069E9 BF 01 10         [24] 3257 	cjne	r7,#0x01,00118$
                                   3258 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      0069EC BE 08 02         [24] 3259 	cjne	r6,#0x08,00313$
      0069EF 80 04            [24] 3260 	sjmp	00107$
      0069F1                       3261 00313$:
      0069F1 75 82 00         [24] 3262 	mov	dpl, #0x00
      0069F4 22               [24] 3263 	ret
      0069F5                       3264 00107$:
                                   3265 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      0069F5 90 07 F1         [24] 3266 	mov	dptr,#_ak820_usb_send_offset_10000_424
      0069F8 E4               [12] 3267 	clr	a
      0069F9 F0               [24] 3268 	movx	@dptr,a
      0069FA 80 3C            [24] 3269 	sjmp	00119$
      0069FC                       3270 00118$:
                                   3271 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      0069FC BF 02 30         [24] 3272 	cjne	r7,#0x02,00115$
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      0069FF 90 07 ED         [24] 3274 	mov	dptr,#_ak820_usb_send_PARM_2
      006A02 E0               [24] 3275 	movx	a,@dptr
      006A03 FD               [12] 3276 	mov	r5,a
      006A04 A3               [24] 3277 	inc	dptr
      006A05 E0               [24] 3278 	movx	a,@dptr
      006A06 FF               [12] 3279 	mov	r7,a
      006A07 8D 82            [24] 3280 	mov	dpl,r5
      006A09 8F 83            [24] 3281 	mov	dph,r7
      006A0B E0               [24] 3282 	movx	a,@dptr
      006A0C FF               [12] 3283 	mov	r7,a
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006A0D BF 07 00         [24] 3285 	cjne	r7,#0x07,00316$
      006A10                       3286 00316$:
      006A10 50 0E            [24] 3287 	jnc	00108$
      006A12 EF               [12] 3288 	mov	a,r7
      006A13 90 BC 48         [24] 3289 	mov	dptr,#_shared_lengths
      006A16 93               [24] 3290 	movc	a,@a+dptr
      006A17 FD               [12] 3291 	mov	r5,a
      006A18 60 06            [24] 3292 	jz	00108$
      006A1A EE               [12] 3293 	mov	a,r6
      006A1B B5 05 02         [24] 3294 	cjne	a,ar5,00319$
      006A1E 80 04            [24] 3295 	sjmp	00109$
      006A20                       3296 00319$:
      006A20                       3297 00108$:
      006A20 75 82 00         [24] 3298 	mov	dpl, #0x00
      006A23 22               [24] 3299 	ret
      006A24                       3300 00109$:
                                   3301 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006A24 EF               [12] 3302 	mov	a,r7
      006A25 90 BC 41         [24] 3303 	mov	dptr,#_shared_offsets
      006A28 93               [24] 3304 	movc	a,@a+dptr
      006A29 90 07 F1         [24] 3305 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A2C F0               [24] 3306 	movx	@dptr,a
      006A2D 80 09            [24] 3307 	sjmp	00119$
      006A2F                       3308 00115$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006A2F BE 20 02         [24] 3310 	cjne	r6,#0x20,00320$
      006A32 80 04            [24] 3311 	sjmp	00119$
      006A34                       3312 00320$:
      006A34 75 82 00         [24] 3313 	mov	dpl, #0x00
      006A37 22               [24] 3314 	ret
      006A38                       3315 00119$:
                                   3316 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006A38 90 07 83         [24] 3317 	mov	dptr,#_USB_SleepStatus
      006A3B E0               [24] 3318 	movx	a,@dptr
      006A3C 30 E1 07         [24] 3319 	jnb	acc.1,00184$
      006A3F 12 69 90         [24] 3320 	lcall	_USB_WakeUp_PC
      006A42 75 82 00         [24] 3321 	mov	dpl, #0x00
      006A45 22               [24] 3322 	ret
                                   3323 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006A46                       3324 00184$:
      006A46 7F FA            [12] 3325 	mov	r7,#0xfa
      006A48                       3326 00127$:
      006A48 90 07 F0         [24] 3327 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A4B E0               [24] 3328 	movx	a,@dptr
      006A4C FC               [12] 3329 	mov	r4,a
      006A4D 7D 00            [12] 3330 	mov	r5,#0x00
      006A4F 8C 02            [24] 3331 	mov	ar2,r4
      006A51 74 22            [12] 3332 	mov	a,#0x22
      006A53 2D               [12] 3333 	add	a, r5
      006A54 FB               [12] 3334 	mov	r3,a
      006A55 8A 82            [24] 3335 	mov	dpl,r2
      006A57 8B 83            [24] 3336 	mov	dph,r3
      006A59 E0               [24] 3337 	movx	a,@dptr
      006A5A 54 03            [12] 3338 	anl	a,#0x03
      006A5C 70 20            [24] 3339 	jnz	00129$
      006A5E 8F 03            [24] 3340 	mov	ar3,r7
      006A60 1F               [12] 3341 	dec	r7
      006A61 EB               [12] 3342 	mov	a,r3
      006A62 60 1A            [24] 3343 	jz	00129$
      006A64 7B 28            [12] 3344 	mov	r3,#0x28
      006A66                       3345 00141$:
      006A66 EB               [12] 3346 	mov	a,r3
      006A67 60 DF            [24] 3347 	jz	00127$
      006A69 90 00 01         [24] 3348 	mov	dptr,#0x0001
      006A6C C0 07            [24] 3349 	push	ar7
      006A6E C0 06            [24] 3350 	push	ar6
      006A70 C0 03            [24] 3351 	push	ar3
      006A72 12 5B 08         [24] 3352 	lcall	_mDelayuS
      006A75 D0 03            [24] 3353 	pop	ar3
      006A77 D0 06            [24] 3354 	pop	ar6
      006A79 D0 07            [24] 3355 	pop	ar7
      006A7B 1B               [12] 3356 	dec	r3
      006A7C 80 E8            [24] 3357 	sjmp	00141$
      006A7E                       3358 00129$:
                                   3359 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006A7E A2 AF            [12] 3360 	mov	c,_EA
      006A80 E4               [12] 3361 	clr	a
      006A81 33               [12] 3362 	rlc	a
      006A82 FF               [12] 3363 	mov	r7,a
                                   3364 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3365 ;	assignBit
      006A83 C2 AF            [12] 3366 	clr	_EA
                                   3367 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006A85 90 07 82         [24] 3368 	mov	dptr,#_USB_EnumStatus
      006A88 E0               [24] 3369 	movx	a,@dptr
      006A89 60 25            [24] 3370 	jz	00130$
      006A8B 90 07 F0         [24] 3371 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A8E E0               [24] 3372 	movx	a,@dptr
      006A8F FB               [12] 3373 	mov	r3,a
      006A90 F9               [12] 3374 	mov	r1,a
      006A91 7A 00            [12] 3375 	mov	r2,#0x00
      006A93 74 22            [12] 3376 	mov	a,#0x22
      006A95 2A               [12] 3377 	add	a, r2
      006A96 FA               [12] 3378 	mov	r2,a
      006A97 89 82            [24] 3379 	mov	dpl,r1
      006A99 8A 83            [24] 3380 	mov	dph,r2
      006A9B E0               [24] 3381 	movx	a,@dptr
      006A9C FA               [12] 3382 	mov	r2,a
      006A9D 53 02 03         [24] 3383 	anl	ar2,#0x03
      006AA0 BA 02 0D         [24] 3384 	cjne	r2,#0x02,00130$
                                   3385 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006AA3 BB 03 13         [24] 3386 	cjne	r3,#0x03,00192$
      006AA6 90 07 89         [24] 3387 	mov	dptr,#_raw_state
      006AA9 E0               [24] 3388 	movx	a,@dptr
      006AAA FB               [12] 3389 	mov	r3,a
      006AAB BB 03 02         [24] 3390 	cjne	r3,#0x03,00331$
      006AAE 80 09            [24] 3391 	sjmp	00192$
      006AB0                       3392 00331$:
      006AB0                       3393 00130$:
                                   3394 ;	assignBit
      006AB0 EF               [12] 3395 	mov	a,r7
      006AB1 24 FF            [12] 3396 	add	a,#0xff
      006AB3 92 AF            [24] 3397 	mov	_EA,c
      006AB5 75 82 00         [24] 3398 	mov	dpl, #0x00
      006AB8 22               [24] 3399 	ret
                                   3400 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006AB9                       3401 00192$:
      006AB9 7B 00            [12] 3402 	mov	r3,#0x00
      006ABB                       3403 00144$:
      006ABB C3               [12] 3404 	clr	c
      006ABC EB               [12] 3405 	mov	a,r3
      006ABD 9E               [12] 3406 	subb	a,r6
      006ABE 50 67            [24] 3407 	jnc	00137$
                                   3408 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006AC0 C0 07            [24] 3409 	push	ar7
      006AC2 90 07 F0         [24] 3410 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006AC5 E0               [24] 3411 	movx	a,@dptr
      006AC6 F9               [12] 3412 	mov	r1,a
      006AC7 E4               [12] 3413 	clr	a
      006AC8 C3               [12] 3414 	clr	c
      006AC9 C9               [12] 3415 	xch	a,r1
      006ACA 13               [12] 3416 	rrc	a
      006ACB C9               [12] 3417 	xch	a,r1
      006ACC 13               [12] 3418 	rrc	a
      006ACD A2 E0            [12] 3419 	mov	c,acc.0
      006ACF C9               [12] 3420 	xch	a,r1
      006AD0 13               [12] 3421 	rrc	a
      006AD1 C9               [12] 3422 	xch	a,r1
      006AD2 13               [12] 3423 	rrc	a
      006AD3 C9               [12] 3424 	xch	a,r1
      006AD4 FA               [12] 3425 	mov	r2,a
      006AD5 8B 00            [24] 3426 	mov	ar0,r3
      006AD7 7F 00            [12] 3427 	mov	r7,#0x00
      006AD9 E8               [12] 3428 	mov	a,r0
      006ADA 29               [12] 3429 	add	a, r1
      006ADB F9               [12] 3430 	mov	r1,a
      006ADC EF               [12] 3431 	mov	a,r7
      006ADD 3A               [12] 3432 	addc	a, r2
      006ADE 24 10            [12] 3433 	add	a,#0x10
      006AE0 FA               [12] 3434 	mov	r2,a
      006AE1 90 07 ED         [24] 3435 	mov	dptr,#_ak820_usb_send_PARM_2
      006AE4 E0               [24] 3436 	movx	a,@dptr
      006AE5 F8               [12] 3437 	mov	r0,a
      006AE6 A3               [24] 3438 	inc	dptr
      006AE7 E0               [24] 3439 	movx	a,@dptr
      006AE8 FF               [12] 3440 	mov	r7,a
      006AE9 EB               [12] 3441 	mov	a,r3
      006AEA 28               [12] 3442 	add	a, r0
      006AEB F5 1B            [12] 3443 	mov	_ak820_usb_send_sloc0_1_0,a
      006AED E4               [12] 3444 	clr	a
      006AEE 3F               [12] 3445 	addc	a, r7
      006AEF F5 1C            [12] 3446 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006AF1 85 1B 82         [24] 3447 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006AF4 85 1C 83         [24] 3448 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006AF7 E0               [24] 3449 	movx	a,@dptr
      006AF8 89 82            [24] 3450 	mov	dpl,r1
      006AFA 8A 83            [24] 3451 	mov	dph,r2
      006AFC F0               [24] 3452 	movx	@dptr,a
                                   3453 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006AFD 90 07 F1         [24] 3454 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006B00 E0               [24] 3455 	movx	a,@dptr
      006B01 F5 1D            [12] 3456 	mov	_ak820_usb_send_sloc1_1_0,a
      006B03 74 34            [12] 3457 	mov	a,#0x34
      006B05 B5 1D 04         [24] 3458 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006B08 D0 07            [24] 3459 	pop	ar7
      006B0A 80 18            [24] 3460 	sjmp	00145$
      006B0C                       3461 00333$:
      006B0C D0 07            [24] 3462 	pop	ar7
      006B0E EB               [12] 3463 	mov	a,r3
      006B0F 25 1D            [12] 3464 	add	a, _ak820_usb_send_sloc1_1_0
      006B11 24 AC            [12] 3465 	add	a, #_input_snapshot
      006B13 F9               [12] 3466 	mov	r1,a
      006B14 E4               [12] 3467 	clr	a
      006B15 34 07            [12] 3468 	addc	a,#(_input_snapshot >> 8)
      006B17 FA               [12] 3469 	mov	r2,a
      006B18 85 1B 82         [24] 3470 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B1B 85 1C 83         [24] 3471 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B1E E0               [24] 3472 	movx	a,@dptr
      006B1F 89 82            [24] 3473 	mov	dpl,r1
      006B21 8A 83            [24] 3474 	mov	dph,r2
      006B23 F0               [24] 3475 	movx	@dptr,a
      006B24                       3476 00145$:
                                   3477 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006B24 0B               [12] 3478 	inc	r3
      006B25 80 94            [24] 3479 	sjmp	00144$
      006B27                       3480 00137$:
                                   3481 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006B27 90 07 F0         [24] 3482 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B2A E0               [24] 3483 	movx	a,@dptr
      006B2B FB               [12] 3484 	mov	r3,a
      006B2C F9               [12] 3485 	mov	r1,a
      006B2D 7A 00            [12] 3486 	mov	r2,#0x00
      006B2F 74 08            [12] 3487 	mov	a,#0x08
      006B31 29               [12] 3488 	add	a, r1
      006B32 F9               [12] 3489 	mov	r1,a
      006B33 74 22            [12] 3490 	mov	a,#0x22
      006B35 3A               [12] 3491 	addc	a, r2
      006B36 FA               [12] 3492 	mov	r2,a
      006B37 89 82            [24] 3493 	mov	dpl,r1
      006B39 8A 83            [24] 3494 	mov	dph,r2
      006B3B EE               [12] 3495 	mov	a,r6
      006B3C F0               [24] 3496 	movx	@dptr,a
                                   3497 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006B3D BB 03 06         [24] 3498 	cjne	r3,#0x03,00139$
      006B40 90 07 89         [24] 3499 	mov	dptr,#_raw_state
      006B43 74 04            [12] 3500 	mov	a,#0x04
      006B45 F0               [24] 3501 	movx	@dptr,a
      006B46                       3502 00139$:
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006B46 74 22            [12] 3504 	mov	a,#0x22
      006B48 2D               [12] 3505 	add	a, r5
      006B49 FD               [12] 3506 	mov	r5,a
      006B4A 8C 82            [24] 3507 	mov	dpl,r4
      006B4C 8D 83            [24] 3508 	mov	dph,r5
      006B4E E0               [24] 3509 	movx	a,@dptr
      006B4F FE               [12] 3510 	mov	r6,a
      006B50 53 06 FC         [24] 3511 	anl	ar6,#0xfc
      006B53 8C 82            [24] 3512 	mov	dpl,r4
      006B55 8D 83            [24] 3513 	mov	dph,r5
      006B57 EE               [12] 3514 	mov	a,r6
      006B58 F0               [24] 3515 	movx	@dptr,a
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3517 ;	assignBit
      006B59 EF               [12] 3518 	mov	a,r7
      006B5A 24 FF            [12] 3519 	add	a,#0xff
      006B5C 92 AF            [24] 3520 	mov	_EA,c
                                   3521 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006B5E 75 82 01         [24] 3522 	mov	dpl, #0x01
                                   3523 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006B61 22               [24] 3524 	ret
                                   3525 ;------------------------------------------------------------
                                   3526 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3527 ;------------------------------------------------------------
                                   3528 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3529 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3530 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3531 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3532 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3533 ;------------------------------------------------------------
                                   3534 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3535 ;	-----------------------------------------
                                   3536 ;	 function ak820_usb_try_send
                                   3537 ;	-----------------------------------------
      006B62                       3538 _ak820_usb_try_send:
      006B62 E5 82            [12] 3539 	mov	a,dpl
      006B64 90 07 F5         [24] 3540 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006B67 F0               [24] 3541 	movx	@dptr,a
                                   3542 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3543 ;	assignBit
      006B68 A2 AF            [12] 3544 	mov	c,_EA
      006B6A 92 1C            [24] 3545 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006B6C 90 07 F6         [24] 3547 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006B6F E4               [12] 3548 	clr	a
      006B70 F0               [24] 3549 	movx	@dptr,a
                                   3550 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3551 ;	assignBit
      006B71 C2 AF            [12] 3552 	clr	_EA
                                   3553 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006B73 90 07 F5         [24] 3554 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006B76 E0               [24] 3555 	movx	a,@dptr
      006B77 FF               [12] 3556 	mov	r7,a
      006B78 BF 01 00         [24] 3557 	cjne	r7,#0x01,00152$
      006B7B                       3558 00152$:
      006B7B 40 4E            [24] 3559 	jc	00102$
      006B7D EF               [12] 3560 	mov	a,r7
      006B7E 24 FD            [12] 3561 	add	a,#0xff - 0x02
      006B80 40 49            [24] 3562 	jc	00102$
                                   3563 ;	free result
      006B82 90 07 82         [24] 3564 	mov	dptr,#_USB_EnumStatus
      006B85 E0               [24] 3565 	movx	a,@dptr
      006B86 60 43            [24] 3566 	jz	00102$
                                   3567 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006B88 90 07 83         [24] 3568 	mov	dptr,#_USB_SleepStatus
      006B8B E0               [24] 3569 	movx	a,@dptr
      006B8C 20 E1 3C         [24] 3570 	jb	acc.1,00102$
      006B8F 90 07 AB         [24] 3571 	mov	dptr,#_keyboard_reset
      006B92 E0               [24] 3572 	movx	a,@dptr
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006B93 70 36            [24] 3574 	jnz	00102$
      006B95 8F 06            [24] 3575 	mov	ar6,r7
      006B97 24 22            [12] 3576 	add	a,#0x22
      006B99 FD               [12] 3577 	mov	r5,a
      006B9A 8E 82            [24] 3578 	mov	dpl,r6
      006B9C 8D 83            [24] 3579 	mov	dph,r5
      006B9E E0               [24] 3580 	movx	a,@dptr
      006B9F FE               [12] 3581 	mov	r6,a
      006BA0 53 06 03         [24] 3582 	anl	ar6,#0x03
      006BA3 BE 02 25         [24] 3583 	cjne	r6,#0x02,00102$
                                   3584 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006BA6 90 07 F2         [24] 3585 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006BA9 E0               [24] 3586 	movx	a,@dptr
      006BAA FD               [12] 3587 	mov	r5,a
      006BAB A3               [24] 3588 	inc	dptr
      006BAC E0               [24] 3589 	movx	a,@dptr
      006BAD FE               [12] 3590 	mov	r6,a
      006BAE 90 07 F4         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006BB1 E0               [24] 3592 	movx	a,@dptr
      006BB2 FC               [12] 3593 	mov	r4,a
      006BB3 90 07 ED         [24] 3594 	mov	dptr,#_ak820_usb_send_PARM_2
      006BB6 ED               [12] 3595 	mov	a,r5
      006BB7 F0               [24] 3596 	movx	@dptr,a
      006BB8 EE               [12] 3597 	mov	a,r6
      006BB9 A3               [24] 3598 	inc	dptr
      006BBA F0               [24] 3599 	movx	@dptr,a
      006BBB 90 07 EF         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_3
      006BBE EC               [12] 3601 	mov	a,r4
      006BBF F0               [24] 3602 	movx	@dptr,a
      006BC0 8F 82            [24] 3603 	mov	dpl, r7
      006BC2 12 69 BB         [24] 3604 	lcall	_ak820_usb_send
      006BC5 E5 82            [12] 3605 	mov	a, dpl
      006BC7 90 07 F6         [24] 3606 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006BCA F0               [24] 3607 	movx	@dptr,a
      006BCB                       3608 00102$:
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3610 ;	assignBit
      006BCB A2 1C            [12] 3611 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006BCD 92 AF            [24] 3612 	mov	_EA,c
                                   3613 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006BCF 90 07 F6         [24] 3614 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006BD2 E0               [24] 3615 	movx	a,@dptr
                                   3616 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006BD3 F5 82            [12] 3617 	mov	dpl,a
      006BD5 22               [24] 3618 	ret
                                   3619 ;------------------------------------------------------------
                                   3620 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3621 ;------------------------------------------------------------
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3623 ;	-----------------------------------------
                                   3624 ;	 function raw_request_is_nonpersistent
                                   3625 ;	-----------------------------------------
      006BD6                       3626 _raw_request_is_nonpersistent:
                                   3627 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006BD6 90 07 8A         [24] 3628 	mov	dptr,#_raw_buffer
      006BD9 E0               [24] 3629 	movx	a,@dptr
      006BDA FF               [12] 3630 	mov	r7,a
      006BDB BF 01 02         [24] 3631 	cjne	r7,#0x01,00302$
      006BDE 80 35            [24] 3632 	sjmp	00108$
      006BE0                       3633 00302$:
      006BE0 BF 02 02         [24] 3634 	cjne	r7,#0x02,00303$
      006BE3 80 34            [24] 3635 	sjmp	00109$
      006BE5                       3636 00303$:
      006BE5 BF 04 02         [24] 3637 	cjne	r7,#0x04,00304$
      006BE8 80 2B            [24] 3638 	sjmp	00108$
      006BEA                       3639 00304$:
      006BEA BF 08 02         [24] 3640 	cjne	r7,#0x08,00305$
      006BED 80 47            [24] 3641 	sjmp	00116$
      006BEF                       3642 00305$:
      006BEF BF 0B 02         [24] 3643 	cjne	r7,#0x0b,00306$
      006BF2 80 21            [24] 3644 	sjmp	00108$
      006BF4                       3645 00306$:
      006BF4 BF 0C 02         [24] 3646 	cjne	r7,#0x0c,00307$
      006BF7 80 1C            [24] 3647 	sjmp	00108$
      006BF9                       3648 00307$:
      006BF9 BF 0D 02         [24] 3649 	cjne	r7,#0x0d,00308$
      006BFC 80 17            [24] 3650 	sjmp	00108$
      006BFE                       3651 00308$:
      006BFE BF 0E 02         [24] 3652 	cjne	r7,#0x0e,00309$
      006C01 80 12            [24] 3653 	sjmp	00108$
      006C03                       3654 00309$:
      006C03 BF 11 02         [24] 3655 	cjne	r7,#0x11,00310$
      006C06 80 0D            [24] 3656 	sjmp	00108$
      006C08                       3657 00310$:
      006C08 BF 12 02         [24] 3658 	cjne	r7,#0x12,00311$
      006C0B 80 08            [24] 3659 	sjmp	00108$
      006C0D                       3660 00311$:
      006C0D BF FE 02         [24] 3661 	cjne	r7,#0xfe,00312$
      006C10 80 46            [24] 3662 	sjmp	00124$
      006C12                       3663 00312$:
      006C12 02 6C AD         [24] 3664 	ljmp	00144$
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006C15                       3666 00108$:
                                   3667 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006C15 75 82 01         [24] 3668 	mov	dpl, #0x01
      006C18 22               [24] 3669 	ret
                                   3670 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006C19                       3671 00109$:
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006C19 12 6E DF         [24] 3673 	lcall	_ak820_outline_0169
      006C1C BF 01 02         [24] 3674 	cjne	r7,#0x01,00313$
      006C1F 80 0D            [24] 3675 	sjmp	00113$
      006C21                       3676 00313$:
      006C21 BF 02 02         [24] 3677 	cjne	r7,#0x02,00314$
      006C24 80 08            [24] 3678 	sjmp	00113$
      006C26                       3679 00314$:
      006C26 BF 03 02         [24] 3680 	cjne	r7,#0x03,00315$
      006C29 80 03            [24] 3681 	sjmp	00113$
      006C2B                       3682 00315$:
      006C2B BF 04 04         [24] 3683 	cjne	r7,#0x04,00114$
                                   3684 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006C2E                       3685 00113$:
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006C2E 75 82 01         [24] 3687 	mov	dpl, #0x01
      006C31 22               [24] 3688 	ret
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006C32                       3690 00114$:
      006C32 75 82 00         [24] 3691 	mov	dpl, #0x00
      006C35 22               [24] 3692 	ret
                                   3693 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006C36                       3694 00116$:
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006C36 12 6E DF         [24] 3696 	lcall	_ak820_outline_0169
      006C39 BF 40 02         [24] 3697 	cjne	r7,#0x40,00318$
      006C3C 80 12            [24] 3698 	sjmp	00121$
      006C3E                       3699 00318$:
      006C3E BF 41 02         [24] 3700 	cjne	r7,#0x41,00319$
      006C41 80 0D            [24] 3701 	sjmp	00121$
      006C43                       3702 00319$:
      006C43 BF 42 02         [24] 3703 	cjne	r7,#0x42,00320$
      006C46 80 08            [24] 3704 	sjmp	00121$
      006C48                       3705 00320$:
      006C48 BF 43 02         [24] 3706 	cjne	r7,#0x43,00321$
      006C4B 80 03            [24] 3707 	sjmp	00121$
      006C4D                       3708 00321$:
      006C4D BF 44 04         [24] 3709 	cjne	r7,#0x44,00122$
                                   3710 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006C50                       3711 00121$:
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006C50 75 82 01         [24] 3713 	mov	dpl, #0x01
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006C53 22               [24] 3715 	ret
      006C54                       3716 00122$:
      006C54 75 82 00         [24] 3717 	mov	dpl, #0x00
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006C57 22               [24] 3719 	ret
      006C58                       3720 00124$:
                                   3721 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006C58 12 6E DF         [24] 3722 	lcall	_ak820_outline_0169
      006C5B 24 F2            [12] 3723 	add	a,#0xff - 0x0d
      006C5D 40 4A            [24] 3724 	jc	00142$
                                   3725 ;	free result
      006C5F EF               [12] 3726 	mov	a,r7
      006C60 24 0A            [12] 3727 	add	a,#(00325$-3-.)
      006C62 83               [24] 3728 	movc	a,@a+pc
      006C63 F5 82            [12] 3729 	mov	dpl,a
      006C65 EF               [12] 3730 	mov	a,r7
      006C66 24 12            [12] 3731 	add	a,#(00326$-3-.)
      006C68 83               [24] 3732 	movc	a,@a+pc
      006C69 F5 83            [12] 3733 	mov	dph,a
      006C6B E4               [12] 3734 	clr	a
      006C6C 73               [24] 3735 	jmp	@a+dptr
      006C6D                       3736 00325$:
      006C6D 89                    3737 	.db	00134$
      006C6E 89                    3738 	.db	00134$
      006C6F 89                    3739 	.db	00134$
      006C70 89                    3740 	.db	00134$
      006C71 A9                    3741 	.db	00142$
      006C72 89                    3742 	.db	00134$
      006C73 89                    3743 	.db	00134$
      006C74 89                    3744 	.db	00134$
      006C75 89                    3745 	.db	00134$
      006C76 89                    3746 	.db	00134$
      006C77 89                    3747 	.db	00134$
      006C78 A9                    3748 	.db	00142$
      006C79 A9                    3749 	.db	00142$
      006C7A 8D                    3750 	.db	00135$
      006C7B                       3751 00326$:
      006C7B 6C                    3752 	.db	00134$>>8
      006C7C 6C                    3753 	.db	00134$>>8
      006C7D 6C                    3754 	.db	00134$>>8
      006C7E 6C                    3755 	.db	00134$>>8
      006C7F 6C                    3756 	.db	00142$>>8
      006C80 6C                    3757 	.db	00134$>>8
      006C81 6C                    3758 	.db	00134$>>8
      006C82 6C                    3759 	.db	00134$>>8
      006C83 6C                    3760 	.db	00134$>>8
      006C84 6C                    3761 	.db	00134$>>8
      006C85 6C                    3762 	.db	00134$>>8
      006C86 6C                    3763 	.db	00142$>>8
      006C87 6C                    3764 	.db	00142$>>8
      006C88 6C                    3765 	.db	00135$>>8
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006C89                       3767 00134$:
                                   3768 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006C89 75 82 01         [24] 3769 	mov	dpl, #0x01
                                   3770 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006C8C 22               [24] 3771 	ret
      006C8D                       3772 00135$:
                                   3773 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006C8D 90 07 8C         [24] 3774 	mov	dptr,#(_raw_buffer + 0x0002)
      006C90 E0               [24] 3775 	movx	a,@dptr
      006C91 FF               [12] 3776 	mov	r7,a
      006C92 60 0D            [24] 3777 	jz	00139$
      006C94 BF 01 02         [24] 3778 	cjne	r7,#0x01,00328$
      006C97 80 08            [24] 3779 	sjmp	00139$
      006C99                       3780 00328$:
      006C99 BF 03 02         [24] 3781 	cjne	r7,#0x03,00329$
      006C9C 80 03            [24] 3782 	sjmp	00139$
      006C9E                       3783 00329$:
      006C9E BF 05 04         [24] 3784 	cjne	r7,#0x05,00140$
                                   3785 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006CA1                       3786 00139$:
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006CA1 75 82 01         [24] 3788 	mov	dpl, #0x01
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006CA4 22               [24] 3790 	ret
      006CA5                       3791 00140$:
      006CA5 75 82 00         [24] 3792 	mov	dpl, #0x00
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006CA8 22               [24] 3794 	ret
      006CA9                       3795 00142$:
      006CA9 75 82 00         [24] 3796 	mov	dpl, #0x00
                                   3797 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006CAC 22               [24] 3798 	ret
      006CAD                       3799 00144$:
      006CAD 75 82 00         [24] 3800 	mov	dpl, #0x00
                                   3801 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3802 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006CB0 22               [24] 3803 	ret
                                   3804 ;------------------------------------------------------------
                                   3805 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3806 ;------------------------------------------------------------
                                   3807 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3808 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3809 ;------------------------------------------------------------
                                   3810 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3811 ;	-----------------------------------------
                                   3812 ;	 function ak820_usb_raw_send
                                   3813 ;	-----------------------------------------
      006CB1                       3814 _ak820_usb_raw_send:
      006CB1 12 43 13         [24] 3815 	lcall	_ak820_outline_0036
      006CB4 90 07 F8         [24] 3816 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006CB7 12 38 1F         [24] 3817 	lcall	_ak820_outline_0016
                                   3818 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006CBA 90 07 F7         [24] 3819 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006CBD E0               [24] 3820 	movx	a,@dptr
      006CBE FF               [12] 3821 	mov	r7,a
      006CBF BF 20 2B         [24] 3822 	cjne	r7,#0x20,00106$
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006CC2 C0 07            [24] 3824 	push	ar7
      006CC4 12 3E 29         [24] 3825 	lcall	_ak820_nvm_flush
      006CC7 D0 07            [24] 3826 	pop	ar7
                                   3827 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006CC9 90 07 AA         [24] 3828 	mov	dptr,#_raw_reply_without_nvm
      006CCC E0               [24] 3829 	movx	a,@dptr
      006CCD 70 07            [24] 3830 	jnz	00103$
      006CCF 12 3E 1A         [24] 3831 	lcall	_ak820_nvm_ok
      006CD2 E5 82            [12] 3832 	mov	a, dpl
      006CD4 60 17            [24] 3833 	jz	00106$
      006CD6                       3834 00103$:
      006CD6 90 07 F8         [24] 3835 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006CD9 12 38 64         [24] 3836 	lcall	_ak820_outline_0080
      006CDC 90 07 ED         [24] 3837 	mov	dptr,#_ak820_usb_send_PARM_2
      006CDF 12 43 7D         [24] 3838 	lcall	_ak820_outline_0167
      006CE2 90 07 EF         [24] 3839 	mov	dptr,#_ak820_usb_send_PARM_3
      006CE5 EF               [12] 3840 	mov	a,r7
      006CE6 F0               [24] 3841 	movx	@dptr,a
      006CE7 75 82 03         [24] 3842 	mov	dpl, #0x03
                                   3843 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006CEA 02 69 BB         [24] 3844 	ljmp	_ak820_usb_send
      006CED                       3845 00106$:
      006CED 22               [24] 3846 	ret
                                   3847 ;------------------------------------------------------------
                                   3848 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3849 ;------------------------------------------------------------
                                   3850 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3851 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3852 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3853 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3854 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3855 ;------------------------------------------------------------
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3857 ;	-----------------------------------------
                                   3858 ;	 function ak820_usb_raw_task
                                   3859 ;	-----------------------------------------
      006CEE                       3860 _ak820_usb_raw_task:
                                   3861 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006CEE A2 AF            [12] 3862 	mov	c,_EA
      006CF0 E4               [12] 3863 	clr	a
      006CF1 33               [12] 3864 	rlc	a
      006CF2 FF               [12] 3865 	mov	r7,a
                                   3866 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3867 ;	assignBit
      006CF3 C2 AF            [12] 3868 	clr	_EA
                                   3869 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006CF5 90 07 82         [24] 3870 	mov	dptr,#_USB_EnumStatus
      006CF8 E0               [24] 3871 	movx	a,@dptr
      006CF9 60 0A            [24] 3872 	jz	00101$
      006CFB 90 07 89         [24] 3873 	mov	dptr,#_raw_state
      006CFE E0               [24] 3874 	movx	a,@dptr
      006CFF FE               [12] 3875 	mov	r6,a
      006D00 BE 02 02         [24] 3876 	cjne	r6,#0x02,00270$
      006D03 80 06            [24] 3877 	sjmp	00102$
      006D05                       3878 00270$:
      006D05                       3879 00101$:
                                   3880 ;	assignBit
      006D05 EF               [12] 3881 	mov	a,r7
      006D06 24 FF            [12] 3882 	add	a,#0xff
      006D08 92 AF            [24] 3883 	mov	_EA,c
      006D0A 22               [24] 3884 	ret
      006D0B                       3885 00102$:
                                   3886 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006D0B 90 07 89         [24] 3887 	mov	dptr,#_raw_state
      006D0E 74 03            [12] 3888 	mov	a,#0x03
      006D10 F0               [24] 3889 	movx	@dptr,a
                                   3890 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3891 ;	assignBit
      006D11 EF               [12] 3892 	mov	a,r7
      006D12 24 FF            [12] 3893 	add	a,#0xff
      006D14 92 AF            [24] 3894 	mov	_EA,c
                                   3895 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006D16 90 07 8A         [24] 3896 	mov	dptr,#_raw_buffer
      006D19 E0               [24] 3897 	movx	a,@dptr
      006D1A FF               [12] 3898 	mov	r7,a
      006D1B E4               [12] 3899 	clr	a
      006D1C BF FD 01         [24] 3900 	cjne	r7,#0xfd,00271$
      006D1F 04               [12] 3901 	inc	a
      006D20                       3902 00271$:
      006D20 FF               [12] 3903 	mov	r7,a
      006D21 70 03            [24] 3904 	jnz	00273$
      006D23 02 6D C3         [24] 3905 	ljmp	00118$
      006D26                       3906 00273$:
      006D26 90 07 8B         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0001)
      006D29 E0               [24] 3908 	movx	a,@dptr
      006D2A 60 03            [24] 3909 	jz	00274$
      006D2C 02 6D C3         [24] 3910 	ljmp	00118$
      006D2F                       3911 00274$:
                                   3912 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006D2F 90 07 8C         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0002)
      006D32 E0               [24] 3914 	movx	a,@dptr
      006D33 FD               [12] 3915 	mov	r5,a
      006D34 7E 00            [12] 3916 	mov	r6,#0x00
      006D36 90 07 8D         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0003)
      006D39 E0               [24] 3918 	movx	a,@dptr
      006D3A 7B 00            [12] 3919 	mov	r3,#0x00
      006D3C 42 06            [12] 3920 	orl	ar6,a
      006D3E EB               [12] 3921 	mov	a,r3
      006D3F 42 05            [12] 3922 	orl	ar5,a
                                   3923 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006D41 90 07 8E         [24] 3924 	mov	dptr,#(_raw_buffer + 0x0004)
      006D44 E0               [24] 3925 	movx	a,@dptr
      006D45 FC               [12] 3926 	mov	r4,a
                                   3927 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006D46 7B 05            [12] 3928 	mov	r3,#0x05
      006D48                       3929 00128$:
      006D48 EB               [12] 3930 	mov	a,r3
      006D49 12 6E CD         [24] 3931 	lcall	_ak820_outline_0106
      006D4C 0B               [12] 3932 	inc	r3
      006D4D BB 20 00         [24] 3933 	cjne	r3,#0x20,00275$
      006D50                       3934 00275$:
      006D50 40 F6            [24] 3935 	jc	00128$
                                   3936 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006D52 EC               [12] 3937 	mov	a,r4
      006D53 24 E4            [12] 3938 	add	a,#0xff - 0x1b
      006D55 40 1C            [24] 3939 	jc	00106$
                                   3940 ;	free result
      006D57 EC               [12] 3941 	mov	a,r4
      006D58 60 26            [24] 3942 	jz	00165$
      006D5A 8C 03            [24] 3943 	mov	ar3,r4
      006D5C 1B               [12] 3944 	dec	r3
      006D5D 7A 00            [12] 3945 	mov	r2,#0x00
      006D5F 74 FF            [12] 3946 	mov	a,#0xff
      006D61 C3               [12] 3947 	clr	c
      006D62 9B               [12] 3948 	subb	a,r3
      006D63 FB               [12] 3949 	mov	r3,a
      006D64 74 FF            [12] 3950 	mov	a,#0xff
      006D66 9A               [12] 3951 	subb	a,r2
      006D67 FA               [12] 3952 	mov	r2,a
      006D68 8E 00            [24] 3953 	mov	ar0,r6
      006D6A 8D 01            [24] 3954 	mov	ar1,r5
      006D6C C3               [12] 3955 	clr	c
      006D6D EB               [12] 3956 	mov	a,r3
      006D6E 98               [12] 3957 	subb	a,r0
      006D6F EA               [12] 3958 	mov	a,r2
      006D70 99               [12] 3959 	subb	a,r1
      006D71 50 0D            [24] 3960 	jnc	00165$
                                   3961 ;	free result
      006D73                       3962 00106$:
                                   3963 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006D73 90 07 8B         [24] 3964 	mov	dptr,#(_raw_buffer + 0x0001)
      006D76 74 FF            [12] 3965 	mov	a,#0xff
      006D78 F0               [24] 3966 	movx	@dptr,a
                                   3967 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006D79 90 07 8E         [24] 3968 	mov	dptr,#(_raw_buffer + 0x0004)
      006D7C E4               [12] 3969 	clr	a
      006D7D F0               [24] 3970 	movx	@dptr,a
                                   3971 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006D7E 80 3A            [24] 3972 	sjmp	00108$
      006D80                       3973 00165$:
      006D80 7B 00            [12] 3974 	mov	r3,#0x00
      006D82                       3975 00131$:
      006D82 C3               [12] 3976 	clr	c
      006D83 EB               [12] 3977 	mov	a,r3
      006D84 9C               [12] 3978 	subb	a,r4
      006D85 50 33            [24] 3979 	jnc	00108$
      006D87 C0 04            [24] 3980 	push	ar4
      006D89 8B 02            [24] 3981 	mov	ar2,r3
      006D8B 74 05            [12] 3982 	mov	a,#0x05
      006D8D 2A               [12] 3983 	add	a, r2
      006D8E F9               [12] 3984 	mov	r1,a
      006D8F 33               [12] 3985 	rlc	a
      006D90 95 E0            [12] 3986 	subb	a,acc
      006D92 FA               [12] 3987 	mov	r2,a
      006D93 E9               [12] 3988 	mov	a,r1
      006D94 24 8A            [12] 3989 	add	a, #_raw_buffer
      006D96 F9               [12] 3990 	mov	r1,a
      006D97 EA               [12] 3991 	mov	a,r2
      006D98 34 07            [12] 3992 	addc	a, #(_raw_buffer >> 8)
      006D9A FA               [12] 3993 	mov	r2,a
      006D9B 8B 1E            [24] 3994 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006D9D 75 1F 00         [24] 3995 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006DA0 8E 00            [24] 3996 	mov	ar0,r6
      006DA2 8D 04            [24] 3997 	mov	ar4,r5
      006DA4 E5 1E            [12] 3998 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006DA6 28               [12] 3999 	add	a, r0
      006DA7 F8               [12] 4000 	mov	r0,a
      006DA8 E5 1F            [12] 4001 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006DAA 3C               [12] 4002 	addc	a, r4
      006DAB FC               [12] 4003 	mov	r4,a
      006DAC 88 82            [24] 4004 	mov	dpl,r0
      006DAE 8C 83            [24] 4005 	mov	dph,r4
      006DB0 E4               [12] 4006 	clr	a
      006DB1 93               [24] 4007 	movc	a,@a+dptr
      006DB2 12 6E D9         [24] 4008 	lcall	_ak820_outline_0141
      006DB5 0B               [12] 4009 	inc	r3
      006DB6 D0 04            [24] 4010 	pop	ar4
      006DB8 80 C8            [24] 4011 	sjmp	00131$
      006DBA                       4012 00108$:
                                   4013 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006DBA 12 6E B9         [24] 4014 	lcall	_ak820_outline_0045
      006DBD 12 69 BB         [24] 4015 	lcall	_ak820_usb_send
      006DC0 02 6E 69         [24] 4016 	ljmp	00119$
      006DC3                       4017 00118$:
                                   4018 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006DC3 EF               [12] 4019 	mov	a,r7
      006DC4 70 03            [24] 4020 	jnz	00281$
      006DC6 02 6E 46         [24] 4021 	ljmp	00114$
      006DC9                       4022 00281$:
      006DC9 12 6E DF         [24] 4023 	lcall	_ak820_outline_0169
      006DCC BF 01 02         [24] 4024 	cjne	r7,#0x01,00282$
      006DCF 80 03            [24] 4025 	sjmp	00283$
      006DD1                       4026 00282$:
      006DD1 02 6E 46         [24] 4027 	ljmp	00114$
      006DD4                       4028 00283$:
                                   4029 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006DD4 7F 02            [12] 4030 	mov	r7,#0x02
      006DD6                       4031 00133$:
      006DD6 EF               [12] 4032 	mov	a,r7
      006DD7 12 6E CD         [24] 4033 	lcall	_ak820_outline_0106
      006DDA 0F               [12] 4034 	inc	r7
      006DDB BF 20 00         [24] 4035 	cjne	r7,#0x20,00284$
      006DDE                       4036 00284$:
      006DDE 40 F6            [24] 4037 	jc	00133$
                                   4038 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006DE0 90 07 8C         [24] 4039 	mov	dptr,#(_raw_buffer + 0x0002)
      006DE3 74 01            [12] 4040 	mov	a,#0x01
      006DE5 F0               [24] 4041 	movx	@dptr,a
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006DE6 90 07 8D         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0003)
      006DE9 74 A8            [12] 4044 	mov	a,#0xa8
      006DEB F0               [24] 4045 	movx	@dptr,a
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006DEC 90 07 8E         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0004)
      006DEF 12 3B 97         [24] 4048 	lcall	_ak820_nvm_diagnostic
                                   4049 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006DF2 7F 00            [12] 4050 	mov	r7,#0x00
      006DF4                       4051 00135$:
      006DF4 8F 06            [24] 4052 	mov	ar6,r7
      006DF6 74 0B            [12] 4053 	mov	a,#0x0b
      006DF8 2E               [12] 4054 	add	a, r6
      006DF9 24 8A            [12] 4055 	add	a,#_raw_buffer
      006DFB FE               [12] 4056 	mov	r6,a
      006DFC E4               [12] 4057 	clr	a
      006DFD 34 07            [12] 4058 	addc	a, #(_raw_buffer >> 8)
      006DFF FD               [12] 4059 	mov	r5,a
      006E00 EF               [12] 4060 	mov	a,r7
      006E01 24 64            [12] 4061 	add	a, #_ak820_flash_diagnostic
      006E03 F5 82            [12] 4062 	mov	dpl,a
      006E05 E4               [12] 4063 	clr	a
      006E06 34 04            [12] 4064 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006E08 F5 83            [12] 4065 	mov	dph,a
      006E0A E0               [24] 4066 	movx	a,@dptr
      006E0B 8E 82            [24] 4067 	mov	dpl,r6
      006E0D 8D 83            [24] 4068 	mov	dph,r5
      006E0F F0               [24] 4069 	movx	@dptr,a
      006E10 0F               [12] 4070 	inc	r7
      006E11 BF 06 00         [24] 4071 	cjne	r7,#0x06,00286$
      006E14                       4072 00286$:
      006E14 40 DE            [24] 4073 	jc	00135$
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006E16 90 0E 42         [24] 4075 	mov	dptr,#_vial_unlocked
      006E19 E0               [24] 4076 	movx	a,@dptr
      006E1A 90 07 9B         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0011)
      006E1D F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006E1E 90 0E 43         [24] 4080 	mov	dptr,#_vial_unlock_in_progress
      006E21 E0               [24] 4081 	movx	a,@dptr
      006E22 90 07 9C         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0012)
      006E25 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006E26 90 07 82         [24] 4085 	mov	dptr,#_USB_EnumStatus
      006E29 E0               [24] 4086 	movx	a,@dptr
      006E2A 90 07 9D         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0013)
      006E2D F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006E2E 90 07 83         [24] 4090 	mov	dptr,#_USB_SleepStatus
      006E31 E0               [24] 4091 	movx	a,@dptr
      006E32 90 07 9E         [24] 4092 	mov	dptr,#(_raw_buffer + 0x0014)
      006E35 F0               [24] 4093 	movx	@dptr,a
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006E36 90 07 89         [24] 4095 	mov	dptr,#_raw_state
      006E39 E0               [24] 4096 	movx	a,@dptr
      006E3A 90 07 9F         [24] 4097 	mov	dptr,#(_raw_buffer + 0x0015)
      006E3D F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E3E 12 6E B9         [24] 4100 	lcall	_ak820_outline_0045
      006E41 12 69 BB         [24] 4101 	lcall	_ak820_usb_send
      006E44 80 23            [24] 4102 	sjmp	00119$
      006E46                       4103 00114$:
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006E46 12 6B D6         [24] 4105 	lcall	_raw_request_is_nonpersistent
      006E49 E5 82            [12] 4106 	mov	a, dpl
      006E4B 90 07 AA         [24] 4107 	mov	dptr,#_raw_reply_without_nvm
      006E4E F0               [24] 4108 	movx	@dptr,a
                                   4109 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006E4F 12 3F 7C         [24] 4110 	lcall	_ak820_nvm_begin
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006E52 90 0C 74         [24] 4112 	mov	dptr,#_raw_hid_receive_PARM_2
      006E55 74 20            [12] 4113 	mov	a,#0x20
      006E57 F0               [24] 4114 	movx	@dptr,a
      006E58 90 07 8A         [24] 4115 	mov	dptr,#_raw_buffer
      006E5B 75 F0 00         [24] 4116 	mov	b, #0x00
      006E5E 12 A9 72         [24] 4117 	lcall	_raw_hid_receive
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006E61 12 3F 91         [24] 4119 	lcall	_ak820_nvm_end
                                   4120 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006E64 90 07 AA         [24] 4121 	mov	dptr,#_raw_reply_without_nvm
      006E67 E4               [12] 4122 	clr	a
      006E68 F0               [24] 4123 	movx	@dptr,a
      006E69                       4124 00119$:
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4126 ;	assignBit
      006E69 A2 AF            [12] 4127 	mov	c,_EA
      006E6B 92 1D            [24] 4128 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4129 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4130 ;	assignBit
      006E6D C2 AF            [12] 4131 	clr	_EA
                                   4132 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006E6F 12 6E E5         [24] 4133 	lcall	_ak820_outline_0171
      006E72 BF 04 08         [24] 4134 	cjne	r7,#0x04,00126$
      006E75 90 07 89         [24] 4135 	mov	dptr,#_raw_state
      006E78 74 05            [12] 4136 	mov	a,#0x05
      006E7A F0               [24] 4137 	movx	@dptr,a
      006E7B 80 1B            [24] 4138 	sjmp	00127$
      006E7D                       4139 00126$:
                                   4140 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006E7D 12 6E E5         [24] 4141 	lcall	_ak820_outline_0171
      006E80 BF 03 02         [24] 4142 	cjne	r7,#0x03,00290$
      006E83 80 0E            [24] 4143 	sjmp	00121$
      006E85                       4144 00290$:
      006E85 12 6E E5         [24] 4145 	lcall	_ak820_outline_0171
      006E88 BF 06 02         [24] 4146 	cjne	r7,#0x06,00291$
      006E8B 80 06            [24] 4147 	sjmp	00121$
      006E8D                       4148 00291$:
      006E8D 12 6E E5         [24] 4149 	lcall	_ak820_outline_0171
      006E90 BF 07 05         [24] 4150 	cjne	r7,#0x07,00127$
      006E93                       4151 00121$:
      006E93 90 07 89         [24] 4152 	mov	dptr,#_raw_state
      006E96 E4               [12] 4153 	clr	a
      006E97 F0               [24] 4154 	movx	@dptr,a
      006E98                       4155 00127$:
                                   4156 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4157 ;	assignBit
      006E98 A2 1D            [12] 4158 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006E9A 92 AF            [24] 4159 	mov	_EA,c
                                   4160 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006E9C 22               [24] 4161 	ret
                                   4162 ;------------------------------------------------------------
                                   4163 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4164 ;------------------------------------------------------------
                                   4165 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_483'
                                   4166 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_483'
                                   4167 ;------------------------------------------------------------
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4169 ;	-----------------------------------------
                                   4170 ;	 function ak820_usb_take_keyboard_reset
                                   4171 ;	-----------------------------------------
      006E9D                       4172 _ak820_usb_take_keyboard_reset:
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4174 ;	assignBit
      006E9D A2 AF            [12] 4175 	mov	c,_EA
      006E9F 92 1E            [24] 4176 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4178 ;	assignBit
      006EA1 C2 AF            [12] 4179 	clr	_EA
                                   4180 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006EA3 90 07 AB         [24] 4181 	mov	dptr,#_keyboard_reset
      006EA6 E0               [24] 4182 	movx	a,@dptr
      006EA7 FF               [12] 4183 	mov	r7,a
                                   4184 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006EA8 E4               [12] 4185 	clr	a
      006EA9 F0               [24] 4186 	movx	@dptr,a
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4188 ;	assignBit
      006EAA A2 1E            [12] 4189 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006EAC 92 AF            [24] 4190 	mov	_EA,c
                                   4191 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006EAE EF               [12] 4192 	mov	a,r7
      006EAF B4 01 00         [24] 4193 	cjne	a,#0x01,00103$
      006EB2                       4194 00103$:
      006EB2 B3               [12] 4195 	cpl	c
      006EB3 92 1E            [24] 4196 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006EB5 12 38 B1         [24] 4197 	lcall	_ak820_outline_0162
                                   4198 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006EB8 22               [24] 4199 	ret
                                   4200 	.area CSEG    (CODE)
                                   4201 	.area CONST   (CODE)
                                   4202 	.area CONST   (CODE)
      00BC41                       4203 _shared_offsets:
      00BC41 00                    4204 	.db #0x00	; 0
      00BC42 00                    4205 	.db #0x00	; 0
      00BC43 28                    4206 	.db #0x28	; 40
      00BC44 2E                    4207 	.db #0x2e	; 46
      00BC45 31                    4208 	.db #0x31	; 49	'1'
      00BC46 00                    4209 	.db #0x00	; 0
      00BC47 08                    4210 	.db #0x08	; 8
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00BC48                       4213 _shared_lengths:
      00BC48 00                    4214 	.db #0x00	; 0
      00BC49 00                    4215 	.db #0x00	; 0
      00BC4A 06                    4216 	.db #0x06	; 6
      00BC4B 03                    4217 	.db #0x03	; 3
      00BC4C 03                    4218 	.db #0x03	; 3
      00BC4D 00                    4219 	.db #0x00	; 0
      00BC4E 20                    4220 	.db #0x20	; 32
                                   4221 	.area CSEG    (CODE)
                                   4222 	.area CONST   (CODE)
      00BC4F                       4223 _interface_descriptors:
      00BC4F F2 C1                 4224 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BC51 3B C3                 4225 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BC53 EE C2                 4226 	.byte _RawReport, (_RawReport >> 8)
      00BC55 54 C3                 4227 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BC57 37 C2                 4228 	.byte _SharedReport, (_SharedReport >> 8)
      00BC59 6D C3                 4229 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4230 	.area CSEG    (CODE)
                                   4231 	.area XINIT   (CODE)
                                   4232 	.area CABS    (ABS,CODE)
                                   4233 
                                   4234 ; Experimental exact instruction outlining.
                                   4235 	.globl _ak820_outline_0016
                                   4236 	.globl _ak820_outline_0036
                                   4237 	.globl _ak820_outline_0045
                                   4238 	.globl _ak820_outline_0080
                                   4239 	.globl _ak820_outline_0106
                                   4240 	.globl _ak820_outline_0141
                                   4241 	.globl _ak820_outline_0162
                                   4242 	.globl _ak820_outline_0167
                                   4243 	.globl _ak820_outline_0169
                                   4244 	.globl _ak820_outline_0171
                                   4245 
                                   4246 	.area CSEG (CODE)
                                   4247 ; function ak820_outline_0045
      006EB9                       4248 _ak820_outline_0045:
      006EB9 90 07 ED         [24] 4249 	mov	dptr,#_ak820_usb_send_PARM_2
      006EBC 74 8A            [12] 4250 	mov	a,#_raw_buffer
      006EBE F0               [24] 4251 	movx	@dptr,a
      006EBF 74 07            [12] 4252 	mov	a,#(_raw_buffer>>8)
      006EC1 A3               [24] 4253 	inc	dptr
      006EC2 F0               [24] 4254 	movx	@dptr,a
      006EC3 90 07 EF         [24] 4255 	mov	dptr,#_ak820_usb_send_PARM_3
      006EC6 74 20            [12] 4256 	mov	a,#0x20
      006EC8 F0               [24] 4257 	movx	@dptr,a
      006EC9 75 82 03         [24] 4258 	mov	dpl,#0x03
      006ECC 22               [24] 4259 	ret
                                   4260 
                                   4261 	.area CSEG (CODE)
                                   4262 ; function ak820_outline_0106
      006ECD                       4263 _ak820_outline_0106:
      006ECD 24 8A            [12] 4264 	add	a,#_raw_buffer
      006ECF F5 82            [12] 4265 	mov	dpl,a
      006ED1 E4               [12] 4266 	clr	a
      006ED2 34 07            [12] 4267 	addc	a,#(_raw_buffer>>8)
      006ED4 F5 83            [12] 4268 	mov	dph,a
      006ED6 E4               [12] 4269 	clr	a
      006ED7 F0               [24] 4270 	movx	@dptr,a
      006ED8 22               [24] 4271 	ret
                                   4272 
                                   4273 	.area CSEG (CODE)
                                   4274 ; function ak820_outline_0141
      006ED9                       4275 _ak820_outline_0141:
      006ED9 89 82            [24] 4276 	mov	dpl,r1
      006EDB 8A 83            [24] 4277 	mov	dph,r2
      006EDD F0               [24] 4278 	movx	@dptr,a
      006EDE 22               [24] 4279 	ret
                                   4280 
                                   4281 	.area CSEG (CODE)
                                   4282 ; function ak820_outline_0169
      006EDF                       4283 _ak820_outline_0169:
      006EDF 90 07 8B         [24] 4284 	mov	dptr,#(_raw_buffer+0x0001)
      006EE2 E0               [24] 4285 	movx	a,@dptr
      006EE3 FF               [12] 4286 	mov	r7,a
      006EE4 22               [24] 4287 	ret
                                   4288 
                                   4289 	.area CSEG (CODE)
                                   4290 ; function ak820_outline_0171
      006EE5                       4291 _ak820_outline_0171:
      006EE5 90 07 89         [24] 4292 	mov	dptr,#_raw_state
      006EE8 E0               [24] 4293 	movx	a,@dptr
      006EE9 FF               [12] 4294 	mov	r7,a
      006EEA 22               [24] 4295 	ret
