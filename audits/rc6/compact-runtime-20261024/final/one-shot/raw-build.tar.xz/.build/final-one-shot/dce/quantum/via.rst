                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003C                        553 _raw_hid_receive_sloc0_1_0:
      00003C                        554 	.ds 4
      000040                        555 _raw_hid_receive_sloc1_1_0:
      000040                        556 	.ds 1
      000041                        557 _raw_hid_receive_sloc2_1_0:
      000041                        558 	.ds 1
      000042                        559 _raw_hid_receive_sloc3_1_0:
      000042                        560 	.ds 2
      000044                        561 _raw_hid_receive_sloc4_1_0:
      000044                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000028                        579 _via_eeprom_is_valid_sloc0_1_0:
      000028                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C40                        589 _via_eeprom_set_valid_valid_10000_609:
      000C40                        590 	.ds 1
      000C41                        591 _via_set_layout_options_value_10000_625:
      000C41                        592 	.ds 4
      000C45                        593 _process_record_via_PARM_2:
      000C45                        594 	.ds 3
      000C48                        595 _process_record_via_keycode_10000_627:
      000C48                        596 	.ds 2
      000C4A                        597 _raw_hid_receive_kb_PARM_2:
      000C4A                        598 	.ds 1
      000C4B                        599 _raw_hid_receive_kb_data_10000_633:
      000C4B                        600 	.ds 3
      000C4E                        601 _raw_hid_receive_PARM_2:
      000C4E                        602 	.ds 1
      000C4F                        603 _raw_hid_receive_packet_10000_635:
      000C4F                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A434                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A434 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A437 75 F0 00         [24]  659 	mov	b, #0x00
      00A43A 12 40 74         [24]  660 	lcall	_eeprom_read_byte
      00A43D AF 82            [24]  661 	mov	r7, dpl
      00A43F BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A442 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A445 75 F0 00         [24]  664 	mov	b, #0x00
      00A448 12 40 74         [24]  665 	lcall	_eeprom_read_byte
      00A44B AF 82            [24]  666 	mov	r7, dpl
      00A44D BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A450 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A453 75 F0 00         [24]  669 	mov	b, #0x00
      00A456 12 40 74         [24]  670 	lcall	_eeprom_read_byte
      00A459 AF 82            [24]  671 	mov	r7, dpl
      00A45B BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A45E 80 04            [24]  673 	sjmp	00104$
      00A460                        674 00126$:
      00A460                        675 00103$:
                                    676 ;	assignBit
      00A460 C2 28            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A462 80 02            [24]  678 	sjmp	00105$
      00A464                        679 00104$:
                                    680 ;	assignBit
      00A464 D2 28            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A466                        682 00105$:
      00A466 A2 28            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A468 12 38 B6         [24]  684 	lcall	_ak820_outline_0159
                                    685 ;	quantum/via.c:104: }
      00A46B 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A46C                        699 _via_eeprom_set_valid:
      00A46C E5 82            [12]  700 	mov	a,dpl
      00A46E 90 0C 40         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A471 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A472 E0               [24]  704 	movx	a,@dptr
      00A473 60 04            [24]  705 	jz	00103$
      00A475 7F 02            [12]  706 	mov	r7,#0x02
      00A477 80 02            [24]  707 	sjmp	00104$
      00A479                        708 00103$:
      00A479 7F FF            [12]  709 	mov	r7,#0xff
      00A47B                        710 00104$:
      00A47B 90 06 98         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A47E EF               [12]  712 	mov	a,r7
      00A47F F0               [24]  713 	movx	@dptr,a
      00A480 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A483 75 F0 00         [24]  715 	mov	b, #0x00
      00A486 12 4D 64         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A489 90 0C 40         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A48C E0               [24]  719 	movx	a,@dptr
      00A48D 60 04            [24]  720 	jz	00105$
      00A48F 7F 20            [12]  721 	mov	r7,#0x20
      00A491 80 02            [24]  722 	sjmp	00106$
      00A493                        723 00105$:
      00A493 7F FF            [12]  724 	mov	r7,#0xff
      00A495                        725 00106$:
      00A495 90 06 98         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A498 EF               [12]  727 	mov	a,r7
      00A499 F0               [24]  728 	movx	@dptr,a
      00A49A 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A49D 75 F0 00         [24]  730 	mov	b, #0x00
      00A4A0 12 4D 64         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A4A3 90 0C 40         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A4A6 E0               [24]  734 	movx	a,@dptr
      00A4A7 60 04            [24]  735 	jz	00107$
      00A4A9 7F 08            [12]  736 	mov	r7,#0x08
      00A4AB 80 02            [24]  737 	sjmp	00108$
      00A4AD                        738 00107$:
      00A4AD 7F FF            [12]  739 	mov	r7,#0xff
      00A4AF                        740 00108$:
      00A4AF 90 06 98         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A4B2 EF               [12]  742 	mov	a,r7
      00A4B3 F0               [24]  743 	movx	@dptr,a
      00A4B4 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A4B7 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A4BA 02 4D 64         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A4BD                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A4BD 12 A4 E6         [24]  757 	lcall	_via_get_layout_options
      00A4C0 12 A4 FE         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A4C3 12 A4 34         [24]  760 	lcall	_via_eeprom_is_valid
      00A4C6 E5 82            [12]  761 	mov	a, dpl
      00A4C8 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A4CA 02 3E 23         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A4CD                        766 00103$:
      00A4CD 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A4CE                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A4CE 75 82 00         [24]  777 	mov	dpl, #0x00
      00A4D1 12 A4 6C         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A4D4 12 8F A0         [24]  780 	lcall	_ak820_outline_0155
      00A4D7 12 A4 FF         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A4DA 12 86 26         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A4DD 12 8A 99         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A4E0 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A4E3 02 A4 6C         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A4E6                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A4E6 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A4E9 75 F0 00         [24]  800 	mov	b, #0x00
      00A4EC 12 40 74         [24]  801 	lcall	_eeprom_read_byte
      00A4EF AF 82            [24]  802 	mov	r7, dpl
      00A4F1 7E 00            [12]  803 	mov	r6,#0x00
      00A4F3 7D 00            [12]  804 	mov	r5,#0x00
      00A4F5 7C 00            [12]  805 	mov	r4,#0x00
      00A4F7 12 43 77         [24]  806 	lcall	_ak820_outline_0160
      00A4FA 8D F0            [24]  807 	mov	b, r5
      00A4FC EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A4FD 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A4FE                        820 _via_set_layout_options_kb:
      00A4FE 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A4FF                        831 _via_set_layout_options:
      00A4FF 12 8F 98         [24]  832 	lcall	_ak820_outline_0122
      00A502 90 0C 41         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A505 12 8F 86         [24]  834 	lcall	_ak820_outline_0044
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A508 90 0C 41         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A50B E0               [24]  837 	movx	a,@dptr
      00A50C 90 06 98         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A50F F0               [24]  839 	movx	@dptr,a
      00A510 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A513 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A516 02 4D 64         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A519                        855 _process_record_via:
      00A519 12 38 8D         [24]  856 	lcall	_ak820_outline_0118
      00A51C 90 0C 48         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A51F 12 38 88         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A522 90 0C 45         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A525 12 4E 70         [24]  861 	lcall	_ak820_outline_0011
      00A528 74 05            [12]  862 	mov	a,#0x05
      00A52A 12 38 BB         [24]  863 	lcall	_ak820_outline_0162
      00A52D 12 6D 04         [24]  864 	lcall	_ak820_outline_0059
      00A530 12 B7 B0         [24]  865 	lcall	__gptrget
      00A533 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A535 90 0C 48         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A538 12 47 BB         [24]  869 	lcall	_ak820_outline_0008
      00A53B 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A53D 2D               [12]  871 	add	a,r5
      00A53E 50 12            [24]  872 	jnc	00105$
      00A540 C3               [12]  873 	clr	c
      00A541 74 7F            [12]  874 	mov	a,#0x7f
      00A543 9C               [12]  875 	subb	a,r4
      00A544 74 77            [12]  876 	mov	a,#0x77
      00A546 9D               [12]  877 	subb	a,r5
      00A547 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A549 8E 82            [24]  882 	mov	dpl, r6
      00A54B 12 8A BF         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A54E 75 82 00         [24]  885 	mov	dpl, #0x00
      00A551 22               [24]  886 	ret
      00A552                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A552 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A555 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A556                        903 _raw_hid_receive_kb:
      00A556 12 43 13         [24]  904 	lcall	_ak820_outline_0036
      00A559 90 0C 4B         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A55C 12 38 1F         [24]  906 	lcall	_ak820_outline_0015
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A55F 90 0C 4B         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A562 12 4E 4A         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A565 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A567 02 B7 75         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A56A                        950 _raw_hid_receive:
      00A56A 12 43 13         [24]  951 	lcall	_ak820_outline_0036
      00A56D 90 0C 4F         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A570 12 38 1F         [24]  953 	lcall	_ak820_outline_0015
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A573 90 0C 4F         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A576 12 38 41         [24]  956 	lcall	_ak820_outline_0052
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A579 74 01            [12]  958 	mov	a,#0x01
      00A57B 12 43 7C         [24]  959 	lcall	_ak820_outline_0163
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A57E 90 0C 4E         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A581 E0               [24]  962 	movx	a,@dptr
      00A582 FB               [12]  963 	mov	r3,a
      00A583 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A586 80 01            [24]  965 	sjmp	00102$
      00A588                        966 00520$:
      00A588 22               [24]  967 	ret
      00A589                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A589 90 0E 1D         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A58C E0               [24]  971 	movx	a,@dptr
      00A58D 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A58F 12 38 92         [24]  974 	lcall	_ak820_outline_0119
      00A592 E0               [24]  975 	movx	a,@dptr
      00A593 FA               [12]  976 	mov	r2,a
      00A594 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00A597 80 01            [24]  978 	sjmp	00104$
      00A599                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00A599 22               [24]  981 	ret
      00A59A                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A59A 12 43 44         [24]  984 	lcall	_ak820_outline_0096
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A59D FA               [12]  986 	mov	r2,a
      00A59E 60 21            [24]  987 	jz	00114$
      00A5A0 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00A5A3 80 1C            [24]  989 	sjmp	00114$
      00A5A5                        990 00524$:
      00A5A5 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00A5A8 80 17            [24]  992 	sjmp	00114$
      00A5AA                        993 00525$:
      00A5AA BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00A5AD 80 12            [24]  995 	sjmp	00114$
      00A5AF                        996 00526$:
      00A5AF BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00A5B2 80 0D            [24]  998 	sjmp	00114$
      00A5B4                        999 00527$:
      00A5B4 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00A5B7 80 08            [24] 1001 	sjmp	00114$
      00A5B9                       1002 00528$:
      00A5B9 BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00A5BC 80 03            [24] 1004 	sjmp	00530$
      00A5BE                       1005 00529$:
      00A5BE 02 AA F8         [24] 1006 	ljmp	00171$
      00A5C1                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00A5C1                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00A5C1 12 38 92         [24] 1011 	lcall	_ak820_outline_0119
      00A5C4 E0               [24] 1012 	movx	a,@dptr
      00A5C5 FA               [12] 1013 	mov	r2,a
      00A5C6 BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00A5C9 80 6E            [24] 1015 	sjmp	00115$
      00A5CB                       1016 00531$:
      00A5CB BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00A5CE 80 76            [24] 1018 	sjmp	00116$
      00A5D0                       1019 00532$:
      00A5D0 BA 03 03         [24] 1020 	cjne	r2,#0x03,00533$
      00A5D3 02 A7 08         [24] 1021 	ljmp	00125$
      00A5D6                       1022 00533$:
      00A5D6 BA 04 03         [24] 1023 	cjne	r2,#0x04,00534$
      00A5D9 02 A7 9F         [24] 1024 	ljmp	00129$
      00A5DC                       1025 00534$:
      00A5DC BA 05 03         [24] 1026 	cjne	r2,#0x05,00535$
      00A5DF 02 A7 D9         [24] 1027 	ljmp	00130$
      00A5E2                       1028 00535$:
      00A5E2 BA 06 03         [24] 1029 	cjne	r2,#0x06,00536$
      00A5E5 02 A8 45         [24] 1030 	ljmp	00135$
      00A5E8                       1031 00536$:
      00A5E8 BA 07 03         [24] 1032 	cjne	r2,#0x07,00537$
      00A5EB 02 A8 57         [24] 1033 	ljmp	00136$
      00A5EE                       1034 00537$:
      00A5EE BA 08 03         [24] 1035 	cjne	r2,#0x08,00538$
      00A5F1 02 A8 72         [24] 1036 	ljmp	00137$
      00A5F4                       1037 00538$:
      00A5F4 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00A5F7 02 A8 8D         [24] 1039 	ljmp	00138$
      00A5FA                       1040 00539$:
      00A5FA BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00A5FD 02 AA 86         [24] 1042 	ljmp	00161$
      00A600                       1043 00540$:
      00A600 BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00A603 02 A8 A8         [24] 1045 	ljmp	00139$
      00A606                       1046 00541$:
      00A606 BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00A609 02 A8 C9         [24] 1048 	ljmp	00140$
      00A60C                       1049 00542$:
      00A60C BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00A60F 02 A8 F2         [24] 1051 	ljmp	00141$
      00A612                       1052 00543$:
      00A612 BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00A615 02 A9 3A         [24] 1054 	ljmp	00144$
      00A618                       1055 00544$:
      00A618 BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00A61B 02 A9 A9         [24] 1057 	ljmp	00151$
      00A61E                       1058 00545$:
      00A61E BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00A621 02 A9 C2         [24] 1060 	ljmp	00154$
      00A624                       1061 00546$:
      00A624 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00A627 02 A9 E3         [24] 1063 	ljmp	00155$
      00A62A                       1064 00547$:
      00A62A BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00A62D 02 AA 2B         [24] 1066 	ljmp	00158$
      00A630                       1067 00548$:
      00A630 BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00A633 02 AA C6         [24] 1069 	ljmp	00168$
      00A636                       1070 00549$:
      00A636 02 AA E0         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A639                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A639 12 38 97         [24] 1075 	lcall	_ak820_outline_0125
      00A63C E4               [12] 1076 	clr	a
      00A63D 12 43 0B         [24] 1077 	lcall	_ak820_outline_0034
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A640 74 09            [12] 1079 	mov	a,#0x09
      00A642 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00A643 02 AA F8         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A646                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00A646 12 43 44         [24] 1086 	lcall	_ak820_outline_0096
      00A649 FA               [12] 1087 	mov	r2,a
      00A64A BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00A64D 80 0E            [24] 1089 	sjmp	00117$
      00A64F                       1090 00550$:
      00A64F BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00A652 80 34            [24] 1092 	sjmp	00118$
      00A654                       1093 00551$:
      00A654 BA 03 03         [24] 1094 	cjne	r2,#0x03,00552$
      00A657 02 A6 C3         [24] 1095 	ljmp	00119$
      00A65A                       1096 00552$:
      00A65A 02 A6 ED         [24] 1097 	ljmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00A65D                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A65D 12 48 8C         [24] 1101 	lcall	_timer_read32
      00A660 85 82 3C         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A663 85 83 3D         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A666 85 F0 3E         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A669 F5 3F            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A66B 12 38 92         [24] 1107 	lcall	_ak820_outline_0119
      00A66E A3               [24] 1108 	inc	dptr
      00A66F A3               [24] 1109 	inc	dptr
      00A670 E5 3F            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A672 12 43 0B         [24] 1111 	lcall	_ak820_outline_0034
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A675 A3               [24] 1113 	inc	dptr
      00A676 E5 3E            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A678 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00A679 12 AB 25         [24] 1117 	lcall	_ak820_outline_0022
      00A67C E5 3D            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A67E F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00A67F 12 43 01         [24] 1121 	lcall	_ak820_outline_0010
      00A682 E5 3C            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00A684 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00A685 02 AA F8         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00A688                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00A688 C0 03            [24] 1129 	push	ar3
      00A68A C0 07            [24] 1130 	push	ar7
      00A68C C0 06            [24] 1131 	push	ar6
      00A68E C0 03            [24] 1132 	push	ar3
      00A690 12 A4 E6         [24] 1133 	lcall	_via_get_layout_options
      00A693 85 82 3C         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A696 85 83 3D         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A699 85 F0 3E         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A69C F5 3F            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A69E D0 03            [24] 1138 	pop	ar3
      00A6A0 D0 06            [24] 1139 	pop	ar6
      00A6A2 D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00A6A4 12 38 92         [24] 1142 	lcall	_ak820_outline_0119
      00A6A7 A3               [24] 1143 	inc	dptr
      00A6A8 A3               [24] 1144 	inc	dptr
      00A6A9 E5 3F            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A6AB 12 43 0B         [24] 1146 	lcall	_ak820_outline_0034
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00A6AE A3               [24] 1148 	inc	dptr
      00A6AF E5 3E            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A6B1 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00A6B2 12 AB 25         [24] 1152 	lcall	_ak820_outline_0022
      00A6B5 E5 3D            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A6B7 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00A6B8 12 43 01         [24] 1156 	lcall	_ak820_outline_0010
      00A6BB E5 3C            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00A6BD F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00A6BE D0 03            [24] 1160 	pop	ar3
      00A6C0 02 AA F8         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00A6C3                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00A6C3 90 0E 1C         [24] 1165 	mov	dptr,#_vial_unlocked
      00A6C6 E0               [24] 1166 	movx	a,@dptr
      00A6C7 70 03            [24] 1167 	jnz	00553$
      00A6C9 02 AA F8         [24] 1168 	ljmp	00171$
      00A6CC                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A6CC 7A 01            [12] 1171 	mov	r2,#0x01
      00A6CE 79 00            [12] 1172 	mov	r1,#0x00
      00A6D0                       1173 00173$:
      00A6D0 B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00A6D3                       1175 00554$:
      00A6D3 40 03            [24] 1176 	jc	00555$
      00A6D5 02 AA F8         [24] 1177 	ljmp	00171$
      00A6D8                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00A6D8 89 82            [24] 1180 	mov	dpl, r1
      00A6DA 12 59 1D         [24] 1181 	lcall	_matrix_get_row
      00A6DD A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00A6DF EA               [12] 1184 	mov	a,r2
      00A6E0 2C               [12] 1185 	add	a, r4
      00A6E1 F5 82            [12] 1186 	mov	dpl,a
      00A6E3 E4               [12] 1187 	clr	a
      00A6E4 3D               [12] 1188 	addc	a, r5
      00A6E5 F5 83            [12] 1189 	mov	dph,a
      00A6E7 0A               [12] 1190 	inc	r2
      00A6E8 E8               [12] 1191 	mov	a,r0
      00A6E9 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A6EA 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00A6EB 80 E3            [24] 1196 	sjmp	00173$
      00A6ED                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00A6ED 12 AB 53         [24] 1199 	lcall	_ak820_outline_0095
      00A6F0 90 0C 4A         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A6F3 12 AB 2E         [24] 1201 	lcall	_ak820_outline_0041
      00A6F6 C0 07            [24] 1202 	push	ar7
      00A6F8 C0 06            [24] 1203 	push	ar6
      00A6FA C0 03            [24] 1204 	push	ar3
      00A6FC 12 A5 56         [24] 1205 	lcall	_raw_hid_receive_kb
      00A6FF D0 03            [24] 1206 	pop	ar3
      00A701 D0 06            [24] 1207 	pop	ar6
      00A703 D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00A705 02 AA F8         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00A708                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00A708 12 43 44         [24] 1214 	lcall	_ak820_outline_0096
      00A70B FA               [12] 1215 	mov	r2,a
      00A70C BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00A70F 80 03            [24] 1217 	sjmp	00557$
      00A711                       1218 00556$:
      00A711 02 A7 84         [24] 1219 	ljmp	00127$
      00A714                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00A714 C0 03            [24] 1222 	push	ar3
      00A716 12 38 39         [24] 1223 	lcall	_ak820_outline_0037
      00A719 F8               [12] 1224 	mov	r0,a
      00A71A 79 00            [12] 1225 	mov	r1,#0x00
      00A71C 7B 00            [12] 1226 	mov	r3,#0x00
      00A71E 88 3F            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00A720 8B 3C            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00A722 8B 3D            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00A724 8B 3E            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00A726 12 AB 1C         [24] 1231 	lcall	_ak820_outline_0017
      00A729 F8               [12] 1232 	mov	r0,a
      00A72A 89 03            [24] 1233 	mov	ar3,r1
      00A72C 88 02            [24] 1234 	mov	ar2,r0
      00A72E E4               [12] 1235 	clr	a
      00A72F 42 3C            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00A731 E9               [12] 1237 	mov	a,r1
      00A732 42 3D            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A734 EA               [12] 1239 	mov	a,r2
      00A735 42 3E            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A737 EB               [12] 1241 	mov	a,r3
      00A738 42 3F            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A73A 12 AB 25         [24] 1243 	lcall	_ak820_outline_0022
      00A73D E0               [24] 1244 	movx	a,@dptr
      00A73E F8               [12] 1245 	mov	r0,a
      00A73F 79 00            [12] 1246 	mov	r1,#0x00
      00A741 7A 00            [12] 1247 	mov	r2,#0x00
      00A743 8A 03            [24] 1248 	mov	ar3,r2
      00A745 89 02            [24] 1249 	mov	ar2,r1
      00A747 88 01            [24] 1250 	mov	ar1,r0
      00A749 E4               [12] 1251 	clr	a
      00A74A 42 3C            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00A74C E9               [12] 1253 	mov	a,r1
      00A74D 42 3D            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A74F EA               [12] 1255 	mov	a,r2
      00A750 42 3E            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A752 EB               [12] 1257 	mov	a,r3
      00A753 42 3F            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A755 12 43 01         [24] 1259 	lcall	_ak820_outline_0010
      00A758 E0               [24] 1260 	movx	a,@dptr
      00A759 F8               [12] 1261 	mov	r0,a
      00A75A E4               [12] 1262 	clr	a
      00A75B F9               [12] 1263 	mov	r1,a
      00A75C FA               [12] 1264 	mov	r2,a
      00A75D FB               [12] 1265 	mov	r3,a
      00A75E E5 3D            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A760 42 01            [12] 1267 	orl	ar1,a
      00A762 E5 3E            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A764 42 02            [12] 1269 	orl	ar2,a
      00A766 E5 3F            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A768 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00A76A 12 38 B1         [24] 1273 	lcall	_ak820_outline_0145
      00A76D 8A F0            [24] 1274 	mov	b, r2
      00A76F EB               [12] 1275 	mov	a, r3
      00A770 C0 07            [24] 1276 	push	ar7
      00A772 C0 06            [24] 1277 	push	ar6
      00A774 C0 03            [24] 1278 	push	ar3
      00A776 12 A4 FF         [24] 1279 	lcall	_via_set_layout_options
      00A779 D0 03            [24] 1280 	pop	ar3
      00A77B D0 06            [24] 1281 	pop	ar6
      00A77D D0 07            [24] 1282 	pop	ar7
                                   1283 ;	quantum/via.c:324: break;
      00A77F D0 03            [24] 1284 	pop	ar3
      00A781 02 AA F8         [24] 1285 	ljmp	00171$
                                   1286 ;	quantum/via.c:326: default: {
      00A784                       1287 00127$:
                                   1288 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00A784 12 AB 53         [24] 1289 	lcall	_ak820_outline_0095
      00A787 90 0C 4A         [24] 1290 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A78A 12 AB 2E         [24] 1291 	lcall	_ak820_outline_0041
      00A78D C0 07            [24] 1292 	push	ar7
      00A78F C0 06            [24] 1293 	push	ar6
      00A791 C0 03            [24] 1294 	push	ar3
      00A793 12 A5 56         [24] 1295 	lcall	_raw_hid_receive_kb
      00A796 D0 03            [24] 1296 	pop	ar3
      00A798 D0 06            [24] 1297 	pop	ar6
      00A79A D0 07            [24] 1298 	pop	ar7
                                   1299 ;	quantum/via.c:331: break;
      00A79C 02 AA F8         [24] 1300 	ljmp	00171$
                                   1301 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00A79F                       1302 00129$:
                                   1303 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00A79F 12 43 44         [24] 1304 	lcall	_ak820_outline_0096
      00A7A2 FA               [12] 1305 	mov	r2,a
      00A7A3 12 38 39         [24] 1306 	lcall	_ak820_outline_0037
      00A7A6 F9               [12] 1307 	mov	r1,a
      00A7A7 12 AB 1C         [24] 1308 	lcall	_ak820_outline_0017
      00A7AA F8               [12] 1309 	mov	r0,a
      00A7AB 90 0A DC         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00A7AE E9               [12] 1311 	mov	a,r1
      00A7AF F0               [24] 1312 	movx	@dptr,a
      00A7B0 90 0A DD         [24] 1313 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00A7B3 E8               [12] 1314 	mov	a,r0
      00A7B4 F0               [24] 1315 	movx	@dptr,a
      00A7B5 8A 82            [24] 1316 	mov	dpl, r2
      00A7B7 C0 07            [24] 1317 	push	ar7
      00A7B9 C0 06            [24] 1318 	push	ar6
      00A7BB C0 03            [24] 1319 	push	ar3
      00A7BD 12 83 51         [24] 1320 	lcall	_dynamic_keymap_get_keycode
      00A7C0 A9 82            [24] 1321 	mov	r1, dpl
      00A7C2 AA 83            [24] 1322 	mov	r2, dph
      00A7C4 D0 03            [24] 1323 	pop	ar3
      00A7C6 D0 06            [24] 1324 	pop	ar6
      00A7C8 D0 07            [24] 1325 	pop	ar7
                                   1326 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00A7CA 12 AB 25         [24] 1327 	lcall	_ak820_outline_0022
      00A7CD 8A 00            [24] 1328 	mov	ar0,r2
      00A7CF E8               [12] 1329 	mov	a,r0
      00A7D0 F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00A7D1 12 43 01         [24] 1332 	lcall	_ak820_outline_0010
      00A7D4 E9               [12] 1333 	mov	a,r1
      00A7D5 F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00A7D6 02 AA F8         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00A7D9                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00A7D9 90 0E 1C         [24] 1340 	mov	dptr,#_vial_unlocked
      00A7DC E0               [24] 1341 	movx	a,@dptr
      00A7DD 70 19            [24] 1342 	jnz	00132$
      00A7DF 12 AB 25         [24] 1343 	lcall	_ak820_outline_0022
      00A7E2 E0               [24] 1344 	movx	a,@dptr
      00A7E3 FA               [12] 1345 	mov	r2,a
      00A7E4 BA 7C 11         [24] 1346 	cjne	r2,#0x7c,00132$
      00A7E7 74 05            [12] 1347 	mov	a,#0x05
      00A7E9 2E               [12] 1348 	add	a, r6
      00A7EA 12 38 27         [24] 1349 	lcall	_ak820_outline_0016
      00A7ED 70 09            [24] 1350 	jnz	00132$
                                   1351 ;	quantum/via.c:344: *command_id = id_unhandled;
      00A7EF 12 38 92         [24] 1352 	lcall	_ak820_outline_0119
      00A7F2 74 FF            [12] 1353 	mov	a,#0xff
      00A7F4 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/via.c:345: break;
      00A7F5 02 AA F8         [24] 1356 	ljmp	00171$
      00A7F8                       1357 00132$:
                                   1358 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00A7F8 C0 03            [24] 1359 	push	ar3
      00A7FA 12 43 44         [24] 1360 	lcall	_ak820_outline_0096
      00A7FD F5 41            [12] 1361 	mov	_raw_hid_receive_sloc2_1_0,a
      00A7FF 12 38 39         [24] 1362 	lcall	_ak820_outline_0037
      00A802 F5 40            [12] 1363 	mov	_raw_hid_receive_sloc1_1_0,a
      00A804 12 AB 1C         [24] 1364 	lcall	_ak820_outline_0017
      00A807 F5 3C            [12] 1365 	mov	_raw_hid_receive_sloc0_1_0,a
      00A809 12 AB 25         [24] 1366 	lcall	_ak820_outline_0022
      00A80C E0               [24] 1367 	movx	a,@dptr
      00A80D FB               [12] 1368 	mov	r3,a
      00A80E 78 00            [12] 1369 	mov	r0,#0x00
      00A810 12 43 01         [24] 1370 	lcall	_ak820_outline_0010
      00A813 E0               [24] 1371 	movx	a,@dptr
      00A814 7A 00            [12] 1372 	mov	r2,#0x00
      00A816 42 00            [12] 1373 	orl	ar0,a
      00A818 EA               [12] 1374 	mov	a,r2
      00A819 42 03            [12] 1375 	orl	ar3,a
      00A81B 90 0A DF         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00A81E E5 40            [12] 1377 	mov	a,_raw_hid_receive_sloc1_1_0
      00A820 F0               [24] 1378 	movx	@dptr,a
      00A821 90 0A E0         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00A824 E5 3C            [12] 1380 	mov	a,_raw_hid_receive_sloc0_1_0
      00A826 F0               [24] 1381 	movx	@dptr,a
      00A827 90 0A E1         [24] 1382 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00A82A E8               [12] 1383 	mov	a,r0
      00A82B 12 76 D6         [24] 1384 	lcall	_ak820_outline_0188
      00A82E 85 41 82         [24] 1385 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00A831 C0 07            [24] 1386 	push	ar7
      00A833 C0 06            [24] 1387 	push	ar6
      00A835 C0 03            [24] 1388 	push	ar3
      00A837 12 83 9F         [24] 1389 	lcall	_dynamic_keymap_set_keycode
      00A83A D0 03            [24] 1390 	pop	ar3
      00A83C D0 06            [24] 1391 	pop	ar6
      00A83E D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/via.c:349: break;
      00A840 D0 03            [24] 1394 	pop	ar3
      00A842 02 AA F8         [24] 1395 	ljmp	00171$
                                   1396 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00A845                       1397 00135$:
                                   1398 ;	quantum/via.c:352: dynamic_keymap_reset();
      00A845 C0 07            [24] 1399 	push	ar7
      00A847 C0 06            [24] 1400 	push	ar6
      00A849 C0 03            [24] 1401 	push	ar3
      00A84B 12 86 26         [24] 1402 	lcall	_dynamic_keymap_reset
      00A84E D0 03            [24] 1403 	pop	ar3
      00A850 D0 06            [24] 1404 	pop	ar6
      00A852 D0 07            [24] 1405 	pop	ar7
                                   1406 ;	quantum/via.c:353: break;
      00A854 02 AA F8         [24] 1407 	ljmp	00171$
                                   1408 ;	quantum/via.c:355: case id_lighting_set_value: {
      00A857                       1409 00136$:
                                   1410 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00A857 12 AB 53         [24] 1411 	lcall	_ak820_outline_0095
      00A85A 90 0D 95         [24] 1412 	mov	dptr,#_vialrgb_set_value_PARM_2
      00A85D 12 AB 2E         [24] 1413 	lcall	_ak820_outline_0041
      00A860 C0 07            [24] 1414 	push	ar7
      00A862 C0 06            [24] 1415 	push	ar6
      00A864 C0 03            [24] 1416 	push	ar3
      00A866 12 B5 4B         [24] 1417 	lcall	_vialrgb_set_value
      00A869 D0 03            [24] 1418 	pop	ar3
      00A86B D0 06            [24] 1419 	pop	ar6
      00A86D D0 07            [24] 1420 	pop	ar7
                                   1421 ;	quantum/via.c:375: break;
      00A86F 02 AA F8         [24] 1422 	ljmp	00171$
                                   1423 ;	quantum/via.c:377: case id_lighting_get_value: {
      00A872                       1424 00137$:
                                   1425 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00A872 12 AB 53         [24] 1426 	lcall	_ak820_outline_0095
      00A875 90 0D 91         [24] 1427 	mov	dptr,#_vialrgb_get_value_PARM_2
      00A878 12 AB 2E         [24] 1428 	lcall	_ak820_outline_0041
      00A87B C0 07            [24] 1429 	push	ar7
      00A87D C0 06            [24] 1430 	push	ar6
      00A87F C0 03            [24] 1431 	push	ar3
      00A881 12 B3 E0         [24] 1432 	lcall	_vialrgb_get_value
      00A884 D0 03            [24] 1433 	pop	ar3
      00A886 D0 06            [24] 1434 	pop	ar6
      00A888 D0 07            [24] 1435 	pop	ar7
                                   1436 ;	quantum/via.c:397: break;
      00A88A 02 AA F8         [24] 1437 	ljmp	00171$
                                   1438 ;	quantum/via.c:399: case id_lighting_save: {
      00A88D                       1439 00138$:
                                   1440 ;	quantum/via.c:407: vialrgb_save(data, length);
      00A88D 12 AB 53         [24] 1441 	lcall	_ak820_outline_0095
      00A890 90 0D 99         [24] 1442 	mov	dptr,#_vialrgb_save_PARM_2
      00A893 12 AB 2E         [24] 1443 	lcall	_ak820_outline_0041
      00A896 C0 07            [24] 1444 	push	ar7
      00A898 C0 06            [24] 1445 	push	ar6
      00A89A C0 03            [24] 1446 	push	ar3
      00A89C 12 B5 D9         [24] 1447 	lcall	_vialrgb_save
      00A89F D0 03            [24] 1448 	pop	ar3
      00A8A1 D0 06            [24] 1449 	pop	ar6
      00A8A3 D0 07            [24] 1450 	pop	ar7
                                   1451 ;	quantum/via.c:419: break;
      00A8A5 02 AA F8         [24] 1452 	ljmp	00171$
                                   1453 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00A8A8                       1454 00139$:
                                   1455 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00A8A8 C0 07            [24] 1456 	push	ar7
      00A8AA C0 06            [24] 1457 	push	ar6
      00A8AC C0 05            [24] 1458 	push	ar5
      00A8AE C0 04            [24] 1459 	push	ar4
      00A8B0 C0 03            [24] 1460 	push	ar3
      00A8B2 12 8A 15         [24] 1461 	lcall	_dynamic_keymap_macro_get_count
      00A8B5 AA 82            [24] 1462 	mov	r2, dpl
      00A8B7 D0 03            [24] 1463 	pop	ar3
      00A8B9 D0 04            [24] 1464 	pop	ar4
      00A8BB D0 05            [24] 1465 	pop	ar5
      00A8BD D0 06            [24] 1466 	pop	ar6
      00A8BF D0 07            [24] 1467 	pop	ar7
      00A8C1 12 38 97         [24] 1468 	lcall	_ak820_outline_0125
      00A8C4 EA               [12] 1469 	mov	a,r2
      00A8C5 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	quantum/via.c:430: break;
      00A8C6 02 AA F8         [24] 1472 	ljmp	00171$
                                   1473 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00A8C9                       1474 00140$:
                                   1475 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00A8C9 C0 07            [24] 1476 	push	ar7
      00A8CB C0 06            [24] 1477 	push	ar6
      00A8CD C0 05            [24] 1478 	push	ar5
      00A8CF C0 04            [24] 1479 	push	ar4
      00A8D1 C0 03            [24] 1480 	push	ar3
      00A8D3 12 8A 19         [24] 1481 	lcall	_dynamic_keymap_macro_get_buffer_size
      00A8D6 A9 82            [24] 1482 	mov	r1, dpl
      00A8D8 AA 83            [24] 1483 	mov	r2, dph
      00A8DA D0 03            [24] 1484 	pop	ar3
      00A8DC D0 04            [24] 1485 	pop	ar4
      00A8DE D0 05            [24] 1486 	pop	ar5
      00A8E0 D0 06            [24] 1487 	pop	ar6
      00A8E2 D0 07            [24] 1488 	pop	ar7
                                   1489 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00A8E4 8A 00            [24] 1490 	mov	ar0,r2
      00A8E6 12 38 97         [24] 1491 	lcall	_ak820_outline_0125
      00A8E9 E8               [12] 1492 	mov	a,r0
      00A8EA 12 43 0B         [24] 1493 	lcall	_ak820_outline_0034
                                   1494 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00A8ED E9               [12] 1495 	mov	a,r1
      00A8EE F0               [24] 1496 	movx	@dptr,a
                                   1497 ;	quantum/via.c:436: break;
      00A8EF 02 AA F8         [24] 1498 	ljmp	00171$
                                   1499 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00A8F2                       1500 00141$:
                                   1501 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A8F2 C0 03            [24] 1502 	push	ar3
      00A8F4 12 AB 05         [24] 1503 	lcall	_ak820_outline_0003
      00A8F7 89 3C            [24] 1504 	mov	_raw_hid_receive_sloc0_1_0,r1
      00A8F9 8A 3D            [24] 1505 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1506 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00A8FB 12 AB 1C         [24] 1507 	lcall	_ak820_outline_0017
      00A8FE FB               [12] 1508 	mov	r3,a
                                   1509 ;	quantum/via.c:441: if (size <= 28)
      00A8FF 8B 42            [24] 1510 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A901 75 43 00         [24] 1511 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A904 C3               [12] 1512 	clr	c
      00A905 74 1C            [12] 1513 	mov	a,#0x1c
      00A907 9B               [12] 1514 	subb	a,r3
      00A908 D0 03            [24] 1515 	pop	ar3
      00A90A 50 03            [24] 1516 	jnc	00562$
      00A90C 02 AA F8         [24] 1517 	ljmp	00171$
      00A90F                       1518 00562$:
                                   1519 ;	free result
                                   1520 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00A90F 12 AB 37         [24] 1521 	lcall	_ak820_outline_0069
      00A912 90 0B 2E         [24] 1522 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00A915 E5 42            [12] 1523 	mov	a,_raw_hid_receive_sloc3_1_0
      00A917 F0               [24] 1524 	movx	@dptr,a
      00A918 E5 43            [12] 1525 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00A91A A3               [24] 1526 	inc	dptr
      00A91B F0               [24] 1527 	movx	@dptr,a
      00A91C 90 0B 30         [24] 1528 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00A91F 12 AB 41         [24] 1529 	lcall	_ak820_outline_0087
      00A922 85 3C 82         [24] 1530 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00A925 85 3D 83         [24] 1531 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00A928 C0 07            [24] 1532 	push	ar7
      00A92A C0 06            [24] 1533 	push	ar6
      00A92C C0 03            [24] 1534 	push	ar3
      00A92E 12 8A 1D         [24] 1535 	lcall	_dynamic_keymap_macro_get_buffer
      00A931 D0 03            [24] 1536 	pop	ar3
      00A933 D0 06            [24] 1537 	pop	ar6
      00A935 D0 07            [24] 1538 	pop	ar7
                                   1539 ;	quantum/via.c:443: break;
      00A937 02 AA F8         [24] 1540 	ljmp	00171$
                                   1541 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00A93A                       1542 00144$:
                                   1543 ;	quantum/via.c:448: if (!vial_unlocked) {
      00A93A 90 0E 1C         [24] 1544 	mov	dptr,#_vial_unlocked
      00A93D E0               [24] 1545 	movx	a,@dptr
      00A93E 70 01            [24] 1546 	jnz	00146$
                                   1547 ;	quantum/via.c:450: return;
      00A940 22               [24] 1548 	ret
      00A941                       1549 00146$:
                                   1550 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A941 C0 03            [24] 1551 	push	ar3
      00A943 12 AB 05         [24] 1552 	lcall	_ak820_outline_0003
      00A946 89 42            [24] 1553 	mov	_raw_hid_receive_sloc3_1_0,r1
      00A948 8A 43            [24] 1554 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1555 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00A94A 12 AB 1C         [24] 1556 	lcall	_ak820_outline_0017
      00A94D F5 3C            [12] 1557 	mov	_raw_hid_receive_sloc0_1_0, a
      00A94F 75 3D 00         [24] 1558 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1559 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00A952 85 3C 44         [24] 1560 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00A955 85 3D 45         [24] 1561 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00A958 C3               [12] 1562 	clr	c
      00A959 74 1C            [12] 1563 	mov	a,#0x1c
      00A95B 95 44            [12] 1564 	subb	a,_raw_hid_receive_sloc4_1_0
      00A95D E4               [12] 1565 	clr	a
      00A95E 95 45            [12] 1566 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A960 D0 03            [24] 1567 	pop	ar3
      00A962 40 44            [24] 1568 	jc	00147$
                                   1569 ;	free result
      00A964 8B 01            [24] 1570 	mov	ar1,r3
      00A966 7A 00            [12] 1571 	mov	r2,#0x00
      00A968 E9               [12] 1572 	mov	a,r1
      00A969 24 FC            [12] 1573 	add	a,#0xfc
      00A96B F9               [12] 1574 	mov	r1,a
      00A96C EA               [12] 1575 	mov	a,r2
      00A96D 34 FF            [12] 1576 	addc	a,#0xff
      00A96F FA               [12] 1577 	mov	r2,a
      00A970 C3               [12] 1578 	clr	c
      00A971 E9               [12] 1579 	mov	a,r1
      00A972 95 44            [12] 1580 	subb	a,_raw_hid_receive_sloc4_1_0
      00A974 EA               [12] 1581 	mov	a,r2
      00A975 95 45            [12] 1582 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A977 40 2F            [24] 1583 	jc	00147$
                                   1584 ;	free result
      00A979 12 AB 37         [24] 1585 	lcall	_ak820_outline_0069
      00A97C 90 0B 35         [24] 1586 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00A97F E5 3C            [12] 1587 	mov	a,_raw_hid_receive_sloc0_1_0
      00A981 F0               [24] 1588 	movx	@dptr,a
      00A982 E5 3D            [12] 1589 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A984 A3               [24] 1590 	inc	dptr
      00A985 F0               [24] 1591 	movx	@dptr,a
      00A986 90 0B 37         [24] 1592 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00A989 12 AB 41         [24] 1593 	lcall	_ak820_outline_0087
      00A98C 85 42 82         [24] 1594 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00A98F 85 43 83         [24] 1595 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00A992 C0 07            [24] 1596 	push	ar7
      00A994 C0 06            [24] 1597 	push	ar6
      00A996 C0 03            [24] 1598 	push	ar3
      00A998 12 8A 6B         [24] 1599 	lcall	_dynamic_keymap_macro_set_buffer
      00A99B E5 82            [12] 1600 	mov	a, dpl
      00A99D D0 03            [24] 1601 	pop	ar3
      00A99F D0 06            [24] 1602 	pop	ar6
      00A9A1 D0 07            [24] 1603 	pop	ar7
      00A9A3 60 03            [24] 1604 	jz	00566$
      00A9A5 02 AA F8         [24] 1605 	ljmp	00171$
      00A9A8                       1606 00566$:
      00A9A8                       1607 00147$:
      00A9A8 22               [24] 1608 	ret
                                   1609 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00A9A9                       1610 00151$:
                                   1611 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00A9A9 90 0E 1C         [24] 1612 	mov	dptr,#_vial_unlocked
      00A9AC E0               [24] 1613 	movx	a,@dptr
      00A9AD 70 01            [24] 1614 	jnz	00153$
      00A9AF 22               [24] 1615 	ret
      00A9B0                       1616 00153$:
                                   1617 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00A9B0 C0 07            [24] 1618 	push	ar7
      00A9B2 C0 06            [24] 1619 	push	ar6
      00A9B4 C0 03            [24] 1620 	push	ar3
      00A9B6 12 8A 99         [24] 1621 	lcall	_dynamic_keymap_macro_reset
      00A9B9 D0 03            [24] 1622 	pop	ar3
      00A9BB D0 06            [24] 1623 	pop	ar6
      00A9BD D0 07            [24] 1624 	pop	ar7
                                   1625 ;	quantum/via.c:473: break;
      00A9BF 02 AA F8         [24] 1626 	ljmp	00171$
                                   1627 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00A9C2                       1628 00154$:
                                   1629 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00A9C2 C0 07            [24] 1630 	push	ar7
      00A9C4 C0 06            [24] 1631 	push	ar6
      00A9C6 C0 05            [24] 1632 	push	ar5
      00A9C8 C0 04            [24] 1633 	push	ar4
      00A9CA C0 03            [24] 1634 	push	ar3
      00A9CC 12 83 18         [24] 1635 	lcall	_dynamic_keymap_get_layer_count
      00A9CF AA 82            [24] 1636 	mov	r2, dpl
      00A9D1 D0 03            [24] 1637 	pop	ar3
      00A9D3 D0 04            [24] 1638 	pop	ar4
      00A9D5 D0 05            [24] 1639 	pop	ar5
      00A9D7 D0 06            [24] 1640 	pop	ar6
      00A9D9 D0 07            [24] 1641 	pop	ar7
      00A9DB 12 38 97         [24] 1642 	lcall	_ak820_outline_0125
      00A9DE EA               [12] 1643 	mov	a,r2
      00A9DF F0               [24] 1644 	movx	@dptr,a
                                   1645 ;	quantum/via.c:477: break;
      00A9E0 02 AA F8         [24] 1646 	ljmp	00171$
                                   1647 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00A9E3                       1648 00155$:
                                   1649 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A9E3 C0 03            [24] 1650 	push	ar3
      00A9E5 12 AB 05         [24] 1651 	lcall	_ak820_outline_0003
      00A9E8 89 44            [24] 1652 	mov	_raw_hid_receive_sloc4_1_0,r1
      00A9EA 8A 45            [24] 1653 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1654 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00A9EC 12 AB 1C         [24] 1655 	lcall	_ak820_outline_0017
      00A9EF FB               [12] 1656 	mov	r3,a
                                   1657 ;	quantum/via.c:482: if (size <= 28)
      00A9F0 8B 42            [24] 1658 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A9F2 75 43 00         [24] 1659 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A9F5 C3               [12] 1660 	clr	c
      00A9F6 74 1C            [12] 1661 	mov	a,#0x1c
      00A9F8 9B               [12] 1662 	subb	a,r3
      00A9F9 D0 03            [24] 1663 	pop	ar3
      00A9FB 50 03            [24] 1664 	jnc	00568$
      00A9FD 02 AA F8         [24] 1665 	ljmp	00171$
      00AA00                       1666 00568$:
                                   1667 ;	free result
                                   1668 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AA00 12 AB 37         [24] 1669 	lcall	_ak820_outline_0069
      00AA03 90 0B 17         [24] 1670 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AA06 E5 42            [12] 1671 	mov	a,_raw_hid_receive_sloc3_1_0
      00AA08 F0               [24] 1672 	movx	@dptr,a
      00AA09 E5 43            [12] 1673 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AA0B A3               [24] 1674 	inc	dptr
      00AA0C F0               [24] 1675 	movx	@dptr,a
      00AA0D 90 0B 19         [24] 1676 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AA10 12 AB 41         [24] 1677 	lcall	_ak820_outline_0087
      00AA13 85 44 82         [24] 1678 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AA16 85 45 83         [24] 1679 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AA19 C0 07            [24] 1680 	push	ar7
      00AA1B C0 06            [24] 1681 	push	ar6
      00AA1D C0 03            [24] 1682 	push	ar3
      00AA1F 12 87 E5         [24] 1683 	lcall	_dynamic_keymap_get_buffer
      00AA22 D0 03            [24] 1684 	pop	ar3
      00AA24 D0 06            [24] 1685 	pop	ar6
      00AA26 D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/via.c:484: break;
      00AA28 02 AA F8         [24] 1688 	ljmp	00171$
                                   1689 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AA2B                       1690 00158$:
                                   1691 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AA2B 12 43 44         [24] 1692 	lcall	_ak820_outline_0096
      00AA2E FD               [12] 1693 	mov	r5,a
      00AA2F 7C 00            [12] 1694 	mov	r4,#0x00
      00AA31 12 38 39         [24] 1695 	lcall	_ak820_outline_0037
      00AA34 7A 00            [12] 1696 	mov	r2,#0x00
      00AA36 42 04            [12] 1697 	orl	ar4,a
      00AA38 EA               [12] 1698 	mov	a,r2
      00AA39 42 05            [12] 1699 	orl	ar5,a
      00AA3B 8C 44            [24] 1700 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AA3D 8D 45            [24] 1701 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1702 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AA3F 12 AB 1C         [24] 1703 	lcall	_ak820_outline_0017
      00AA42 F9               [12] 1704 	mov	r1,a
      00AA43 7A 00            [12] 1705 	mov	r2,#0x00
                                   1706 ;	quantum/via.c:489: if (size <= 28)
      00AA45 89 00            [24] 1707 	mov	ar0,r1
      00AA47 E8               [12] 1708 	mov	a,r0
      00AA48 24 E3            [12] 1709 	add	a,#0xff - 0x1c
      00AA4A 50 03            [24] 1710 	jnc	00569$
      00AA4C 02 AA F8         [24] 1711 	ljmp	00171$
      00AA4F                       1712 00569$:
                                   1713 ;	free result
                                   1714 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AA4F C0 03            [24] 1715 	push	ar3
      00AA51 74 04            [12] 1716 	mov	a,#0x04
      00AA53 2E               [12] 1717 	add	a, r6
      00AA54 F8               [12] 1718 	mov	r0,a
      00AA55 E4               [12] 1719 	clr	a
      00AA56 3F               [12] 1720 	addc	a, r7
      00AA57 FB               [12] 1721 	mov	r3,a
      00AA58 7D 00            [12] 1722 	mov	r5,#0x00
      00AA5A 90 0B 1E         [24] 1723 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AA5D E9               [12] 1724 	mov	a,r1
      00AA5E F0               [24] 1725 	movx	@dptr,a
      00AA5F EA               [12] 1726 	mov	a,r2
      00AA60 A3               [24] 1727 	inc	dptr
      00AA61 F0               [24] 1728 	movx	@dptr,a
      00AA62 90 0B 20         [24] 1729 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AA65 E8               [12] 1730 	mov	a,r0
      00AA66 12 76 D6         [24] 1731 	lcall	_ak820_outline_0188
      00AA69 ED               [12] 1732 	mov	a,r5
      00AA6A A3               [24] 1733 	inc	dptr
      00AA6B F0               [24] 1734 	movx	@dptr,a
      00AA6C 85 44 82         [24] 1735 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AA6F 85 45 83         [24] 1736 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AA72 C0 07            [24] 1737 	push	ar7
      00AA74 C0 06            [24] 1738 	push	ar6
      00AA76 C0 03            [24] 1739 	push	ar3
      00AA78 12 88 23         [24] 1740 	lcall	_dynamic_keymap_set_buffer
      00AA7B D0 03            [24] 1741 	pop	ar3
      00AA7D D0 06            [24] 1742 	pop	ar6
      00AA7F D0 07            [24] 1743 	pop	ar7
                                   1744 ;	quantum/via.c:491: break;
      00AA81 D0 03            [24] 1745 	pop	ar3
      00AA83 02 AA F8         [24] 1746 	ljmp	00171$
                                   1747 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AA86                       1748 00161$:
                                   1749 ;	quantum/via.c:497: if (!vial_unlocked)
      00AA86 90 0E 1C         [24] 1750 	mov	dptr,#_vial_unlocked
      00AA89 E0               [24] 1751 	movx	a,@dptr
      00AA8A 70 03            [24] 1752 	jnz	00570$
      00AA8C 02 AA F8         [24] 1753 	ljmp	00171$
      00AA8F                       1754 00570$:
                                   1755 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AA8F 12 AB 5A         [24] 1756 	lcall	_ak820_outline_0152
      00AA92 90 06 72         [24] 1757 	mov	dptr,#_raw_hid_send_PARM_2
      00AA95 12 AB 4A         [24] 1758 	lcall	_ak820_outline_0088
      00AA98 C0 07            [24] 1759 	push	ar7
      00AA9A C0 06            [24] 1760 	push	ar6
      00AA9C C0 03            [24] 1761 	push	ar3
      00AA9E 12 4A 78         [24] 1762 	lcall	_raw_hid_send
      00AAA1 D0 03            [24] 1763 	pop	ar3
      00AAA3 D0 06            [24] 1764 	pop	ar6
      00AAA5 D0 07            [24] 1765 	pop	ar7
                                   1766 ;	quantum/via.c:503: wait_ms(100);
      00AAA7 7D 64            [12] 1767 	mov	r5,#0x64
      00AAA9                       1768 00176$:
      00AAA9 ED               [12] 1769 	mov	a,r5
      00AAAA 60 09            [24] 1770 	jz	00166$
      00AAAC 90 00 01         [24] 1771 	mov	dptr,#0x0001
      00AAAF 12 58 3C         [24] 1772 	lcall	_mDelaymS
      00AAB2 1D               [12] 1773 	dec	r5
      00AAB3 80 F4            [24] 1774 	sjmp	00176$
      00AAB5                       1775 00166$:
                                   1776 ;	quantum/via.c:504: bootloader_jump();
      00AAB5 C0 07            [24] 1777 	push	ar7
      00AAB7 C0 06            [24] 1778 	push	ar6
      00AAB9 C0 03            [24] 1779 	push	ar3
      00AABB 12 34 0E         [24] 1780 	lcall	_bootloader_jump
      00AABE D0 03            [24] 1781 	pop	ar3
      00AAC0 D0 06            [24] 1782 	pop	ar6
      00AAC2 D0 07            [24] 1783 	pop	ar7
                                   1784 ;	quantum/via.c:505: break;
                                   1785 ;	quantum/via.c:509: case id_vial_prefix: {
      00AAC4 80 32            [24] 1786 	sjmp	00171$
      00AAC6                       1787 00168$:
                                   1788 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AAC6 12 AB 5A         [24] 1789 	lcall	_ak820_outline_0152
      00AAC9 90 0C 5C         [24] 1790 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AACC 12 AB 4A         [24] 1791 	lcall	_ak820_outline_0088
      00AACF C0 07            [24] 1792 	push	ar7
      00AAD1 C0 06            [24] 1793 	push	ar6
      00AAD3 C0 03            [24] 1794 	push	ar3
      00AAD5 12 AC 47         [24] 1795 	lcall	_vial_handle_cmd
      00AAD8 D0 03            [24] 1796 	pop	ar3
      00AADA D0 06            [24] 1797 	pop	ar6
      00AADC D0 07            [24] 1798 	pop	ar7
                                   1799 ;	quantum/via.c:511: break;
                                   1800 ;	quantum/via.c:514: default: {
      00AADE 80 18            [24] 1801 	sjmp	00171$
      00AAE0                       1802 00169$:
                                   1803 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AAE0 12 AB 5A         [24] 1804 	lcall	_ak820_outline_0152
      00AAE3 90 0C 4A         [24] 1805 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AAE6 12 AB 4A         [24] 1806 	lcall	_ak820_outline_0088
      00AAE9 C0 07            [24] 1807 	push	ar7
      00AAEB C0 06            [24] 1808 	push	ar6
      00AAED C0 03            [24] 1809 	push	ar3
      00AAEF 12 A5 56         [24] 1810 	lcall	_raw_hid_receive_kb
      00AAF2 D0 03            [24] 1811 	pop	ar3
      00AAF4 D0 06            [24] 1812 	pop	ar6
      00AAF6 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/via.c:521: skip:
      00AAF8                       1815 00171$:
                                   1816 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AAF8 7D 00            [12] 1817 	mov	r5,#0x00
      00AAFA 90 06 72         [24] 1818 	mov	dptr,#_raw_hid_send_PARM_2
      00AAFD EB               [12] 1819 	mov	a,r3
      00AAFE F0               [24] 1820 	movx	@dptr,a
      00AAFF 12 6F 27         [24] 1821 	lcall	_ak820_outline_0050
                                   1822 ;	quantum/via.c:526: }
      00AB02 02 4A 78         [24] 1823 	ljmp	_raw_hid_send
                                   1824 	.area CSEG    (CODE)
                                   1825 	.area CONST   (CODE)
                                   1826 	.area XINIT   (CODE)
                                   1827 	.area CABS    (ABS,CODE)
                                   1828 
                                   1829 ; Experimental exact instruction outlining.
                                   1830 	.globl _ak820_outline_0001
                                   1831 	.globl _ak820_outline_0003
                                   1832 	.globl _ak820_outline_0008
                                   1833 	.globl _ak820_outline_0010
                                   1834 	.globl _ak820_outline_0011
                                   1835 	.globl _ak820_outline_0015
                                   1836 	.globl _ak820_outline_0016
                                   1837 	.globl _ak820_outline_0017
                                   1838 	.globl _ak820_outline_0022
                                   1839 	.globl _ak820_outline_0034
                                   1840 	.globl _ak820_outline_0036
                                   1841 	.globl _ak820_outline_0037
                                   1842 	.globl _ak820_outline_0041
                                   1843 	.globl _ak820_outline_0044
                                   1844 	.globl _ak820_outline_0050
                                   1845 	.globl _ak820_outline_0052
                                   1846 	.globl _ak820_outline_0059
                                   1847 	.globl _ak820_outline_0069
                                   1848 	.globl _ak820_outline_0087
                                   1849 	.globl _ak820_outline_0088
                                   1850 	.globl _ak820_outline_0095
                                   1851 	.globl _ak820_outline_0096
                                   1852 	.globl _ak820_outline_0109
                                   1853 	.globl _ak820_outline_0118
                                   1854 	.globl _ak820_outline_0119
                                   1855 	.globl _ak820_outline_0122
                                   1856 	.globl _ak820_outline_0125
                                   1857 	.globl _ak820_outline_0145
                                   1858 	.globl _ak820_outline_0152
                                   1859 	.globl _ak820_outline_0155
                                   1860 	.globl _ak820_outline_0159
                                   1861 	.globl _ak820_outline_0160
                                   1862 	.globl _ak820_outline_0162
                                   1863 	.globl _ak820_outline_0163
                                   1864 	.globl _ak820_outline_0188
                                   1865 
                                   1866 	.area CSEG (CODE)
                                   1867 ; function ak820_outline_0003
      00AB05                       1868 _ak820_outline_0003:
      00AB05 8C 82            [24] 1869 	mov	dpl,r4
      00AB07 8D 83            [24] 1870 	mov	dph,r5
      00AB09 E0               [24] 1871 	movx	a,@dptr
      00AB0A FA               [12] 1872 	mov	r2,a
      00AB0B 79 00            [12] 1873 	mov	r1,#0x00
      00AB0D 8E 82            [24] 1874 	mov	dpl,r6
      00AB0F 8F 83            [24] 1875 	mov	dph,r7
      00AB11 A3               [24] 1876 	inc	dptr
      00AB12 A3               [24] 1877 	inc	dptr
      00AB13 E0               [24] 1878 	movx	a,@dptr
      00AB14 7B 00            [12] 1879 	mov	r3,#0x00
      00AB16 42 01            [12] 1880 	orl	ar1,a
      00AB18 EB               [12] 1881 	mov	a,r3
      00AB19 42 02            [12] 1882 	orl	ar2,a
      00AB1B 22               [24] 1883 	ret
                                   1884 
                                   1885 	.area CSEG (CODE)
                                   1886 ; function ak820_outline_0017
      00AB1C                       1887 _ak820_outline_0017:
      00AB1C 8E 82            [24] 1888 	mov	dpl,r6
      00AB1E 8F 83            [24] 1889 	mov	dph,r7
      00AB20 A3               [24] 1890 	inc	dptr
      00AB21 A3               [24] 1891 	inc	dptr
      00AB22 A3               [24] 1892 	inc	dptr
      00AB23 E0               [24] 1893 	movx	a,@dptr
      00AB24 22               [24] 1894 	ret
                                   1895 
                                   1896 	.area CSEG (CODE)
                                   1897 ; function ak820_outline_0022
      00AB25                       1898 _ak820_outline_0022:
      00AB25 8E 82            [24] 1899 	mov	dpl,r6
      00AB27 8F 83            [24] 1900 	mov	dph,r7
      00AB29 A3               [24] 1901 	inc	dptr
      00AB2A A3               [24] 1902 	inc	dptr
      00AB2B A3               [24] 1903 	inc	dptr
      00AB2C A3               [24] 1904 	inc	dptr
      00AB2D 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0041
      00AB2E                       1909 _ak820_outline_0041:
      00AB2E EB               [12] 1910 	mov	a,r3
      00AB2F F0               [24] 1911 	movx	@dptr,a
      00AB30 88 82            [24] 1912 	mov	dpl,r0
      00AB32 89 83            [24] 1913 	mov	dph,r1
      00AB34 8A F0            [24] 1914 	mov	b,r2
      00AB36 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0069
      00AB37                       1919 _ak820_outline_0069:
      00AB37 74 04            [12] 1920 	mov	a,#0x04
      00AB39 2E               [12] 1921 	add	a,r6
      00AB3A F9               [12] 1922 	mov	r1,a
      00AB3B E4               [12] 1923 	clr	a
      00AB3C 3F               [12] 1924 	addc	a,r7
      00AB3D F8               [12] 1925 	mov	r0,a
      00AB3E 7A 00            [12] 1926 	mov	r2,#0x00
      00AB40 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0087
      00AB41                       1931 _ak820_outline_0087:
      00AB41 E9               [12] 1932 	mov	a,r1
      00AB42 F0               [24] 1933 	movx	@dptr,a
      00AB43 E8               [12] 1934 	mov	a,r0
      00AB44 A3               [24] 1935 	inc	dptr
      00AB45 F0               [24] 1936 	movx	@dptr,a
      00AB46 EA               [12] 1937 	mov	a,r2
      00AB47 A3               [24] 1938 	inc	dptr
      00AB48 F0               [24] 1939 	movx	@dptr,a
      00AB49 22               [24] 1940 	ret
                                   1941 
                                   1942 	.area CSEG (CODE)
                                   1943 ; function ak820_outline_0088
      00AB4A                       1944 _ak820_outline_0088:
      00AB4A EB               [12] 1945 	mov	a,r3
      00AB4B F0               [24] 1946 	movx	@dptr,a
      00AB4C 8A 82            [24] 1947 	mov	dpl,r2
      00AB4E 8C 83            [24] 1948 	mov	dph,r4
      00AB50 8D F0            [24] 1949 	mov	b,r5
      00AB52 22               [24] 1950 	ret
                                   1951 
                                   1952 	.area CSEG (CODE)
                                   1953 ; function ak820_outline_0095
      00AB53                       1954 _ak820_outline_0095:
      00AB53 8E 00            [24] 1955 	mov	ar0,r6
      00AB55 8F 01            [24] 1956 	mov	ar1,r7
      00AB57 7A 00            [12] 1957 	mov	r2,#0x00
      00AB59 22               [24] 1958 	ret
                                   1959 
                                   1960 	.area CSEG (CODE)
                                   1961 ; function ak820_outline_0152
      00AB5A                       1962 _ak820_outline_0152:
      00AB5A 8E 02            [24] 1963 	mov	ar2,r6
      00AB5C 8F 04            [24] 1964 	mov	ar4,r7
      00AB5E 7D 00            [12] 1965 	mov	r5,#0x00
      00AB60 22               [24] 1966 	ret
