debug.o: quantum/logging/debug.c keyboards/ajazz/ak820/config.h \
 .build/final-one-shot/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h quantum/logging/debug.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 quantum/logging/print.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 quantum/util.h quantum/bitwise.h quantum/logging/sendchar.h \
 platforms/progmem.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h
