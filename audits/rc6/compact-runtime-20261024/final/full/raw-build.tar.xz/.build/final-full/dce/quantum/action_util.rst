                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000976                        580 _owned_mod_refs:
      000976                        581 	.ds 8
      00097E                        582 _owned_weak_refs:
      00097E                        583 	.ds 8
      000986                        584 _owned_mods:
      000986                        585 	.ds 1
      000987                        586 _owned_weak_mods:
      000987                        587 	.ds 1
      000988                        588 _macro_mods:
      000988                        589 	.ds 2
      00098A                        590 _ak820_macro_primitive::
      00098A                        591 	.ds 1
      00098B                        592 _ak820_macro_cancelled::
      00098B                        593 	.ds 1
      00098C                        594 _ak820_macro_change_PARM_2:
      00098C                        595 	.ds 1
      00098D                        596 _ak820_macro_change_PARM_3:
      00098D                        597 	.ds 1
      00098E                        598 _ak820_macro_change_bits_10000_293:
      00098E                        599 	.ds 2
      000990                        600 _change_owned_PARM_2:
      000990                        601 	.ds 1
      000991                        602 _change_owned_mods_10000_298:
      000991                        603 	.ds 1
      000992                        604 _change_owned_result_10001_302:
      000992                        605 	.ds 1
      000993                        606 _change_owned_bit_20001_303:
      000993                        607 	.ds 1
      000994                        608 _add_owned_mods_mods_10000_311:
      000994                        609 	.ds 1
      000995                        610 _del_owned_mods_mods_10000_313:
      000995                        611 	.ds 1
      000996                        612 _add_owned_weak_mods_mods_10000_315:
      000996                        613 	.ds 1
      000997                        614 _del_owned_weak_mods_mods_10000_317:
      000997                        615 	.ds 1
      000998                        616 _key_refs:
      000998                        617 	.ds 165
      000A3D                        618 _distinct_keys:
      000A3D                        619 	.ds 1
      000A3E                        620 _macro_keys:
      000A3E                        621 	.ds 21
      000A53                        622 _add_owned_key_code_10000_326:
      000A53                        623 	.ds 1
      000A54                        624 _del_owned_key_code_10000_341:
      000A54                        625 	.ds 1
      000A55                        626 _usage_refs:
      000A55                        627 	.ds 30
      000A73                        628 _usage_order:
      000A73                        629 	.ds 30
      000A91                        630 _usage_lengths:
      000A91                        631 	.ds 2
      000A93                        632 _macro_usages:
      000A93                        633 	.ds 4
      000A97                        634 _owned_usage_key_PARM_2:
      000A97                        635 	.ds 1
      000A98                        636 _owned_usage_key_code_10000_368:
      000A98                        637 	.ds 1
      000A99                        638 _owned_usage_key___200000085_20000_369:
      000A99                        639 	.ds 2
      000A9B                        640 _owned_usage_key_which_10000_369:
      000A9B                        641 	.ds 1
      000A9C                        642 _owned_usage_key_count_10000_369:
      000A9C                        643 	.ds 1
      000A9D                        644 _owned_usage_key_pos_30001_376:
      000A9D                        645 	.ds 1
      000A9E                        646 _owned_usage_key_key_40000_381:
      000A9E                        647 	.ds 1
      000A9F                        648 _send_keyboard_report_last_report_10001_388:
      000A9F                        649 	.ds 32
      000ABF                        650 _send_keyboard_report_changed_10001_388:
      000ABF                        651 	.ds 1
      000AC0                        652 _add_weak_mods_mods_10000_406:
      000AC0                        653 	.ds 1
      000AC1                        654 _del_weak_mods_mods_10000_408:
      000AC1                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC7                        664 _real_mods:
      000DC7                        665 	.ds 1
      000DC8                        666 _weak_mods:
      000DC8                        667 	.ds 1
      000DC9                        668 _actual_keyboard_report::
      000DC9                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007B74                        713 _ak820_macro_change:
      007B74 12 38 82         [24]  714 	lcall	_ak820_outline_0109
      007B77 90 09 8E         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B7A 12 38 87         [24]  716 	lcall	_ak820_outline_0110
                                    717 ;	quantum/action_util.c:57: if (!ak820_macro_primitive) return true;
      007B7D 90 09 8A         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007B80 E0               [24]  719 	movx	a,@dptr
      007B81 70 04            [24]  720 	jnz	00102$
      007B83 75 82 01         [24]  721 	mov	dpl, #0x01
      007B86 22               [24]  722 	ret
      007B87                        723 00102$:
                                    724 ;	quantum/action_util.c:58: uint8_t mask = 1u << (index & 7);
      007B87 90 09 8C         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007B8A E0               [24]  726 	movx	a,@dptr
      007B8B FF               [12]  727 	mov	r7,a
      007B8C 74 07            [12]  728 	mov	a,#0x07
      007B8E 5F               [12]  729 	anl	a,r7
      007B8F 12 77 06         [24]  730 	lcall	_ak820_outline_0063
      007B92 80 02            [24]  731 	sjmp	00123$
      007B94                        732 00122$:
      007B94 25 E0            [12]  733 	add	a,acc
      007B96                        734 00123$:
      007B96 D5 F0 FB         [24]  735 	djnz	b,00122$
      007B99 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:59: bits += index >> 3;
      007B9A EF               [12]  738 	mov	a,r7
      007B9B 12 57 36         [24]  739 	lcall	_ak820_outline_0190
      007B9E FF               [12]  740 	mov	r7,a
      007B9F 90 09 8E         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007BA2 12 38 58         [24]  742 	lcall	_ak820_outline_0061
      007BA5 90 09 8E         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007BA8 EF               [12]  744 	mov	a,r7
      007BA9 2C               [12]  745 	add	a, r4
      007BAA F0               [24]  746 	movx	@dptr,a
      007BAB E4               [12]  747 	clr	a
      007BAC 3D               [12]  748 	addc	a, r5
      007BAD A3               [24]  749 	inc	dptr
      007BAE F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:60: if (((*bits & mask) != 0) == pressed) return false;
      007BAF 90 09 8E         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007BB2 E0               [24]  753 	movx	a,@dptr
      007BB3 FD               [12]  754 	mov	r5,a
      007BB4 A3               [24]  755 	inc	dptr
      007BB5 E0               [24]  756 	movx	a,@dptr
      007BB6 FF               [12]  757 	mov	r7,a
      007BB7 12 81 00         [24]  758 	lcall	_ak820_outline_0191
      007BBA E0               [24]  759 	movx	a,@dptr
      007BBB FC               [12]  760 	mov	r4,a
      007BBC EE               [12]  761 	mov	a,r6
      007BBD 5C               [12]  762 	anl	a,r4
      007BBE B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007BC1                        764 00124$:
      007BC1 B3               [12]  765 	cpl	c
      007BC2 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007BC4 90 09 8D         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007BC7 E0               [24]  768 	movx	a,@dptr
      007BC8 FB               [12]  769 	mov	r3,a
      007BC9 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007BCB E4               [12]  771 	clr	a
      007BCC 33               [12]  772 	rlc	a
      007BCD B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007BD0 75 82 00         [24]  774 	mov	dpl, #0x00
      007BD3 22               [24]  775 	ret
      007BD4                        776 00104$:
                                    777 ;	quantum/action_util.c:61: *bits ^= mask;
      007BD4 EC               [12]  778 	mov	a,r4
      007BD5 62 06            [12]  779 	xrl	ar6,a
      007BD7 12 81 00         [24]  780 	lcall	_ak820_outline_0191
      007BDA EE               [12]  781 	mov	a,r6
      007BDB F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:62: return true;
      007BDC 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:63: }
      007BDF 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:64: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007BE0                        805 _change_owned:
      007BE0 E5 82            [12]  806 	mov	a,dpl
      007BE2 90 09 91         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007BE5 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:65: uint8_t kind = mode >> 1;
      007BE6 90 09 90         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007BE9 E0               [24]  811 	movx	a,@dptr
      007BEA FF               [12]  812 	mov	r7,a
      007BEB C3               [12]  813 	clr	c
      007BEC 13               [12]  814 	rrc	a
      007BED FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:66: bool pressed = (mode & 1) != 0;
      007BEE 53 07 01         [24]  817 	anl	ar7,#0x01
      007BF1 EF               [12]  818 	mov	a,r7
      007BF2 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007BF5                        820 00205$:
      007BF5 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007BF7 B3               [12]  822 	cpl	c
      007BF8 E4               [12]  823 	clr	a
      007BF9 33               [12]  824 	rlc	a
      007BFA F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:67: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007BFC EE               [12]  827 	mov	a,r6
      007BFD 60 06            [24]  828 	jz	00121$
      007BFF 7D 7E            [12]  829 	mov	r5,#_owned_weak_refs
      007C01 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007C03 80 04            [24]  831 	sjmp	00122$
      007C05                        832 00121$:
      007C05 7D 76            [12]  833 	mov	r5,#_owned_mod_refs
      007C07 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007C09                        835 00122$:
                                    836 ;	quantum/action_util.c:68: if (ak820_macro_primitive) {
      007C09 90 09 8A         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007C0C E0               [24]  838 	movx	a,@dptr
      007C0D 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:69: uint8_t old = macro_mods[kind];
      007C0F EE               [12]  841 	mov	a,r6
      007C10 24 88            [12]  842 	add	a, #_macro_mods
      007C12 FB               [12]  843 	mov	r3,a
      007C13 E4               [12]  844 	clr	a
      007C14 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007C16 12 48 7B         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:70: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007C19 E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007C1B 60 0A            [24]  849 	jz	00123$
      007C1D 90 09 91         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007C20 E0               [24]  851 	movx	a,@dptr
      007C21 F9               [12]  852 	mov	r1,a
      007C22 EA               [12]  853 	mov	a,r2
      007C23 42 01            [12]  854 	orl	ar1,a
      007C25 80 07            [24]  855 	sjmp	00124$
      007C27                        856 00123$:
      007C27 90 09 91         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007C2A E0               [24]  858 	movx	a,@dptr
      007C2B F4               [12]  859 	cpl	a
      007C2C 5A               [12]  860 	anl	a,r2
      007C2D F9               [12]  861 	mov	r1,a
      007C2E                        862 00124$:
      007C2E 12 33 FC         [24]  863 	lcall	_ak820_outline_0125
      007C31 E9               [12]  864 	mov	a,r1
      007C32 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:71: mods &= pressed ? ~old : old;
      007C33 E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007C35 60 06            [24]  868 	jz	00125$
      007C37 74 FF            [12]  869 	mov	a,#0xff
      007C39 6A               [12]  870 	xrl	a,r2
      007C3A FC               [12]  871 	mov	r4,a
      007C3B 80 02            [24]  872 	sjmp	00126$
      007C3D                        873 00125$:
      007C3D 8A 04            [24]  874 	mov	ar4,r2
      007C3F                        875 00126$:
      007C3F 90 09 91         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007C42 E0               [24]  877 	movx	a,@dptr
      007C43 5C               [12]  878 	anl	a,r4
      007C44 F0               [24]  879 	movx	@dptr,a
      007C45                        880 00102$:
                                    881 ;	quantum/action_util.c:73: uint8_t result = 0;
      007C45 90 09 92         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007C48 E4               [12]  883 	clr	a
      007C49 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C4A 90 09 93         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007C4D 04               [12]  887 	inc	a
      007C4E F0               [24]  888 	movx	@dptr,a
      007C4F 90 09 91         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007C52 E0               [24]  890 	movx	a,@dptr
      007C53 FC               [12]  891 	mov	r4,a
      007C54 7B 00            [12]  892 	mov	r3,#0x00
      007C56                        893 00117$:
      007C56 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007C59                        895 00210$:
      007C59 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:75: if (mods & bit) {
      007C5B 90 09 93         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007C5E E0               [24]  899 	movx	a,@dptr
      007C5F 5C               [12]  900 	anl	a,r4
      007C60 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:76: if (pressed) ++refs[i];
      007C62 E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007C64 60 0C            [24]  904 	jz	00106$
      007C66 EB               [12]  905 	mov	a,r3
      007C67 2D               [12]  906 	add	a, r5
      007C68 12 38 27         [24]  907 	lcall	_ak820_outline_0017
      007C6B F8               [12]  908 	mov	r0,a
      007C6C 08               [12]  909 	inc	r0
      007C6D 12 80 BD         [24]  910 	lcall	_ak820_outline_0064
      007C70 80 0C            [24]  911 	sjmp	00109$
      007C72                        912 00106$:
                                    913 ;	quantum/action_util.c:77: else if (refs[i]) --refs[i];
      007C72 EB               [12]  914 	mov	a,r3
      007C73 2D               [12]  915 	add	a, r5
      007C74 12 38 27         [24]  916 	lcall	_ak820_outline_0017
      007C77 F8               [12]  917 	mov	r0,a
      007C78 60 04            [24]  918 	jz	00109$
      007C7A 18               [12]  919 	dec	r0
      007C7B 12 80 BD         [24]  920 	lcall	_ak820_outline_0064
      007C7E                        921 00109$:
                                    922 ;	quantum/action_util.c:79: if (refs[i]) result |= bit;
      007C7E EB               [12]  923 	mov	a,r3
      007C7F 2D               [12]  924 	add	a, r5
      007C80 12 38 27         [24]  925 	lcall	_ak820_outline_0017
      007C83 60 0B            [24]  926 	jz	00118$
      007C85 90 09 93         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007C88 E0               [24]  928 	movx	a,@dptr
      007C89 FA               [12]  929 	mov	r2,a
      007C8A 90 09 92         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007C8D E0               [24]  931 	movx	a,@dptr
      007C8E 4A               [12]  932 	orl	a,r2
      007C8F F0               [24]  933 	movx	@dptr,a
      007C90                        934 00118$:
                                    935 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C90 0B               [12]  936 	inc	r3
      007C91 90 09 93         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007C94 E0               [24]  938 	movx	a,@dptr
      007C95 25 E0            [12]  939 	add	a,acc
      007C97 F0               [24]  940 	movx	@dptr,a
      007C98 80 BC            [24]  941 	sjmp	00117$
      007C9A                        942 00112$:
                                    943 ;	quantum/action_util.c:81: if (kind) owned_weak_mods = result;
      007C9A EE               [12]  944 	mov	a,r6
      007C9B 60 09            [24]  945 	jz	00114$
      007C9D 90 09 92         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007CA0 E0               [24]  947 	movx	a,@dptr
      007CA1 90 09 87         [24]  948 	mov	dptr,#_owned_weak_mods
      007CA4 F0               [24]  949 	movx	@dptr,a
      007CA5 22               [24]  950 	ret
      007CA6                        951 00114$:
                                    952 ;	quantum/action_util.c:82: else owned_mods = result;
      007CA6 90 09 92         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007CA9 E0               [24]  954 	movx	a,@dptr
      007CAA 90 09 86         [24]  955 	mov	dptr,#_owned_mods
      007CAD F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:83: }
      007CAE 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:84: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007CAF                        968 _add_owned_mods:
      007CAF E5 82            [12]  969 	mov	a,dpl
      007CB1 90 09 94         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007CB4 12 80 DD         [24]  971 	lcall	_ak820_outline_0119
      007CB7 74 01            [12]  972 	mov	a,#0x01
      007CB9 F0               [24]  973 	movx	@dptr,a
      007CBA 8F 82            [24]  974 	mov	dpl, r7
      007CBC 02 7B E0         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:85: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007CBF                        985 _del_owned_mods:
      007CBF E5 82            [12]  986 	mov	a,dpl
      007CC1 90 09 95         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007CC4 12 80 DD         [24]  988 	lcall	_ak820_outline_0119
      007CC7 E4               [12]  989 	clr	a
      007CC8 F0               [24]  990 	movx	@dptr,a
      007CC9 8F 82            [24]  991 	mov	dpl, r7
      007CCB 02 7B E0         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:86: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007CCE                       1002 _add_owned_weak_mods:
      007CCE E5 82            [12] 1003 	mov	a,dpl
      007CD0 90 09 96         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007CD3 12 80 DD         [24] 1005 	lcall	_ak820_outline_0119
      007CD6 74 03            [12] 1006 	mov	a,#0x03
      007CD8 F0               [24] 1007 	movx	@dptr,a
      007CD9 8F 82            [24] 1008 	mov	dpl, r7
      007CDB 02 7B E0         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:87: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007CDE                       1019 _del_owned_weak_mods:
      007CDE E5 82            [12] 1020 	mov	a,dpl
      007CE0 90 09 97         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007CE3 12 80 DD         [24] 1022 	lcall	_ak820_outline_0119
      007CE6 74 02            [12] 1023 	mov	a,#0x02
      007CE8 F0               [24] 1024 	movx	@dptr,a
      007CE9 8F 82            [24] 1025 	mov	dpl, r7
      007CEB 02 7B E0         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:88: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007CEE                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:89: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007CEE 7F 00            [12] 1038 	mov	r7,#0x00
      007CF0                       1039 00103$:
      007CF0 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007CF3                       1041 00122$:
      007CF3 50 1A            [24] 1042 	jnc	00101$
      007CF5 EF               [12] 1043 	mov	a,r7
      007CF6 24 76            [12] 1044 	add	a, #_owned_mod_refs
      007CF8 FD               [12] 1045 	mov	r5,a
      007CF9 E4               [12] 1046 	clr	a
      007CFA 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007CFC FE               [12] 1048 	mov	r6,a
      007CFD EF               [12] 1049 	mov	a,r7
      007CFE 24 7E            [12] 1050 	add	a, #_owned_weak_refs
      007D00 F5 82            [12] 1051 	mov	dpl,a
      007D02 E4               [12] 1052 	clr	a
      007D03 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007D05 F5 83            [12] 1054 	mov	dph,a
      007D07 E4               [12] 1055 	clr	a
      007D08 F0               [24] 1056 	movx	@dptr,a
      007D09 12 80 E4         [24] 1057 	lcall	_ak820_outline_0123
      007D0C 0F               [12] 1058 	inc	r7
      007D0D 80 E1            [24] 1059 	sjmp	00103$
      007D0F                       1060 00101$:
                                   1061 ;	quantum/action_util.c:90: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007D0F 90 09 89         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007D12 E4               [12] 1063 	clr	a
      007D13 F0               [24] 1064 	movx	@dptr,a
      007D14 90 09 88         [24] 1065 	mov	dptr,#_macro_mods
      007D17 F0               [24] 1066 	movx	@dptr,a
      007D18 90 09 87         [24] 1067 	mov	dptr,#_owned_weak_mods
      007D1B F0               [24] 1068 	movx	@dptr,a
      007D1C 90 09 86         [24] 1069 	mov	dptr,#_owned_mods
      007D1F F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:91: ak820_macro_cancelled = true;
      007D20 90 09 8B         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007D23 04               [12] 1073 	inc	a
      007D24 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:92: }
      007D25 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:98: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007D26                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:99: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007D26 7F 00            [12] 1089 	mov	r7,#0x00
      007D28                       1090 00104$:
      007D28 EF               [12] 1091 	mov	a,r7
      007D29 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007D2B 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007D2D EF               [12] 1095 	mov	a,r7
      007D2E 24 98            [12] 1096 	add	a, #_key_refs
      007D30 F5 82            [12] 1097 	mov	dpl,a
      007D32 E4               [12] 1098 	clr	a
      007D33 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007D35 12 7B 65         [24] 1100 	lcall	_ak820_outline_0166
      007D38 80 EE            [24] 1101 	sjmp	00104$
      007D3A                       1102 00101$:
                                   1103 ;	quantum/action_util.c:100: distinct_keys = 0;
      007D3A 90 0A 3D         [24] 1104 	mov	dptr,#_distinct_keys
      007D3D E4               [12] 1105 	clr	a
      007D3E F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:101: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007D3F FF               [12] 1108 	mov	r7,a
      007D40                       1109 00107$:
      007D40 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007D43                       1111 00142$:
      007D43 50 0D            [24] 1112 	jnc	00109$
      007D45 EF               [12] 1113 	mov	a,r7
      007D46 24 3E            [12] 1114 	add	a, #_macro_keys
      007D48 F5 82            [12] 1115 	mov	dpl,a
      007D4A E4               [12] 1116 	clr	a
      007D4B 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007D4D 12 7B 65         [24] 1118 	lcall	_ak820_outline_0166
      007D50 80 EE            [24] 1119 	sjmp	00107$
      007D52                       1120 00109$:
                                   1121 ;	quantum/action_util.c:102: }
      007D52 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:103: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007D53                       1137 _add_owned_key:
      007D53 E5 82            [12] 1138 	mov	a,dpl
      007D55 90 0A 53         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007D58 12 80 F5         [24] 1140 	lcall	_ak820_outline_0134
                                   1141 ;	quantum/action_util.c:104: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007D5B 74 01            [12] 1142 	mov	a,#0x01
      007D5D F0               [24] 1143 	movx	@dptr,a
      007D5E 90 0A 3E         [24] 1144 	mov	dptr,#_macro_keys
      007D61 C0 07            [24] 1145 	push	ar7
      007D63 12 7B 74         [24] 1146 	lcall	_ak820_macro_change
      007D66 E5 82            [12] 1147 	mov	a, dpl
      007D68 D0 07            [24] 1148 	pop	ar7
      007D6A 70 03            [24] 1149 	jnz	00102$
      007D6C F5 82            [12] 1150 	mov	dpl,a
      007D6E 22               [24] 1151 	ret
      007D6F                       1152 00102$:
                                   1153 ;	quantum/action_util.c:105: if (key_refs[code]++) return false;
      007D6F 12 80 A7         [24] 1154 	lcall	_ak820_outline_0030
      007D72 FC               [12] 1155 	mov	r4,a
      007D73 04               [12] 1156 	inc	a
      007D74 12 80 E4         [24] 1157 	lcall	_ak820_outline_0123
      007D77 EC               [12] 1158 	mov	a,r4
      007D78 60 04            [24] 1159 	jz	00104$
      007D7A 75 82 00         [24] 1160 	mov	dpl, #0x00
      007D7D 22               [24] 1161 	ret
      007D7E                       1162 00104$:
                                   1163 ;	quantum/action_util.c:106: ++distinct_keys;
      007D7E 90 0A 3D         [24] 1164 	mov	dptr,#_distinct_keys
      007D81 E0               [24] 1165 	movx	a,@dptr
      007D82 24 01            [12] 1166 	add	a, #0x01
      007D84 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D85 90 0D B6         [24] 1169 	mov	dptr,#_keyboard_protocol
      007D88 E0               [24] 1170 	movx	a,@dptr
      007D89 60 15            [24] 1171 	jz	00106$
      007D8B 90 0A C2         [24] 1172 	mov	dptr,#_keymap_config
      007D8E E0               [24] 1173 	movx	a,@dptr
      007D8F 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D92 90 08 03         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007D95 EF               [12] 1177 	mov	a,r7
      007D96 12 80 B5         [24] 1178 	lcall	_ak820_outline_0058
      007D99 12 6E C7         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007D9C 75 82 01         [24] 1181 	mov	dpl, #0x01
      007D9F 22               [24] 1182 	ret
      007DA0                       1183 00106$:
                                   1184 ;	quantum/action_util.c:110: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007DA0 90 0A 3D         [24] 1185 	mov	dptr,#_distinct_keys
      007DA3 E0               [24] 1186 	movx	a,@dptr
      007DA4 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007DA6 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007DA8 7F 00            [12] 1191 	mov	r7,#0x00
      007DAA                       1192 00115$:
      007DAA BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007DAD                       1194 00174$:
      007DAD 50 1D            [24] 1195 	jnc	00111$
      007DAF EF               [12] 1196 	mov	a,r7
      007DB0 24 CB            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007DB2 F5 82            [12] 1198 	mov	dpl,a
      007DB4 E4               [12] 1199 	clr	a
      007DB5 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007DB7 F5 83            [12] 1201 	mov	dph,a
      007DB9 74 01            [12] 1202 	mov	a,#0x01
      007DBB F0               [24] 1203 	movx	@dptr,a
      007DBC 0F               [12] 1204 	inc	r7
      007DBD 80 EB            [24] 1205 	sjmp	00115$
      007DBF                       1206 00110$:
                                   1207 ;	quantum/action_util.c:112: } else add_key(code);
      007DBF 90 0A 53         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_326
      007DC2 E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DC3 90 08 03         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007DC6 12 80 B5         [24] 1212 	lcall	_ak820_outline_0058
      007DC9 12 6E C7         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:112: } else add_key(code);
      007DCC                       1215 00111$:
                                   1216 ;	quantum/action_util.c:113: return true;
      007DCC 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:114: }
      007DCF 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:115: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007DD0                       1236 _del_owned_key:
      007DD0 E5 82            [12] 1237 	mov	a,dpl
      007DD2 90 0A 54         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_341
      007DD5 12 80 F5         [24] 1239 	lcall	_ak820_outline_0134
                                   1240 ;	quantum/action_util.c:116: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007DD8 E4               [12] 1241 	clr	a
      007DD9 F0               [24] 1242 	movx	@dptr,a
      007DDA 90 0A 3E         [24] 1243 	mov	dptr,#_macro_keys
      007DDD C0 07            [24] 1244 	push	ar7
      007DDF 12 7B 74         [24] 1245 	lcall	_ak820_macro_change
      007DE2 E5 82            [12] 1246 	mov	a, dpl
      007DE4 D0 07            [24] 1247 	pop	ar7
      007DE6 70 03            [24] 1248 	jnz	00102$
      007DE8 F5 82            [12] 1249 	mov	dpl,a
      007DEA 22               [24] 1250 	ret
      007DEB                       1251 00102$:
                                   1252 ;	quantum/action_util.c:117: if (!key_refs[code] || --key_refs[code]) return false;
      007DEB 12 80 A7         [24] 1253 	lcall	_ak820_outline_0030
      007DEE FC               [12] 1254 	mov	r4,a
      007DEF 60 07            [24] 1255 	jz	00103$
      007DF1 1C               [12] 1256 	dec	r4
      007DF2 12 43 37         [24] 1257 	lcall	_ak820_outline_0065
      007DF5 EC               [12] 1258 	mov	a,r4
      007DF6 60 04            [24] 1259 	jz	00104$
      007DF8                       1260 00103$:
      007DF8 75 82 00         [24] 1261 	mov	dpl, #0x00
      007DFB 22               [24] 1262 	ret
      007DFC                       1263 00104$:
                                   1264 ;	quantum/action_util.c:118: --distinct_keys;
      007DFC 90 0A 3D         [24] 1265 	mov	dptr,#_distinct_keys
      007DFF E0               [24] 1266 	movx	a,@dptr
      007E00 14               [12] 1267 	dec	a
      007E01 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E02 90 0D B6         [24] 1270 	mov	dptr,#_keyboard_protocol
      007E05 E0               [24] 1271 	movx	a,@dptr
      007E06 60 15            [24] 1272 	jz	00107$
      007E08 90 0A C2         [24] 1273 	mov	dptr,#_keymap_config
      007E0B E0               [24] 1274 	movx	a,@dptr
      007E0C 30 E7 0E         [24] 1275 	jnb	acc.7,00107$
                                   1276 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E0F 90 08 07         [24] 1277 	mov	dptr,#_del_key_from_report_PARM_2
      007E12 EF               [12] 1278 	mov	a,r7
      007E13 12 80 B5         [24] 1279 	lcall	_ak820_outline_0058
      007E16 12 6F 05         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E19 75 82 01         [24] 1282 	mov	dpl, #0x01
      007E1C 22               [24] 1283 	ret
      007E1D                       1284 00107$:
                                   1285 ;	quantum/action_util.c:122: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007E1D 90 0A 3D         [24] 1286 	mov	dptr,#_distinct_keys
      007E20 E0               [24] 1287 	movx	a,@dptr
      007E21 FF               [12] 1288 	mov  r7,a
      007E22 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007E24 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007E26 75 82 01         [24] 1292 	mov	dpl, #0x01
      007E29 22               [24] 1293 	ret
      007E2A                       1294 00110$:
                                   1295 ;	quantum/action_util.c:123: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007E2A BF 06 26         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007E2D 90 0D C9         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007E30 75 F0 00         [24] 1299 	mov	b, #0x00
      007E33 12 6F 43         [24] 1300 	lcall	_clear_keys_from_report
                                   1301 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E36 7F 04            [12] 1302 	mov	r7,#0x04
      007E38                       1303 00122$:
      007E38 EF               [12] 1304 	mov	a,r7
      007E39 24 5B            [12] 1305 	add	a,#0xff - 0xa4
      007E3B 40 23            [24] 1306 	jc	00116$
                                   1307 ;	free result
      007E3D 12 80 A7         [24] 1308 	lcall	_ak820_outline_0030
      007E40 60 0E            [24] 1309 	jz	00123$
                                   1310 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E42 90 08 03         [24] 1311 	mov	dptr,#_add_key_to_report_PARM_2
      007E45 EF               [12] 1312 	mov	a,r7
      007E46 12 80 B5         [24] 1313 	lcall	_ak820_outline_0058
      007E49 C0 07            [24] 1314 	push	ar7
      007E4B 12 6E C7         [24] 1315 	lcall	_add_key_to_report
      007E4E D0 07            [24] 1316 	pop	ar7
                                   1317 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E50                       1318 00123$:
      007E50 0F               [12] 1319 	inc	r7
      007E51 80 E5            [24] 1320 	sjmp	00122$
      007E53                       1321 00115$:
                                   1322 ;	quantum/action_util.c:127: } else del_key(code);
      007E53 90 0A 54         [24] 1323 	mov	dptr,#_del_owned_key_code_10000_341
      007E56 E0               [24] 1324 	movx	a,@dptr
                                   1325 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E57 90 08 07         [24] 1326 	mov	dptr,#_del_key_from_report_PARM_2
      007E5A 12 80 B5         [24] 1327 	lcall	_ak820_outline_0058
      007E5D 12 6F 05         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:127: } else del_key(code);
      007E60                       1330 00116$:
                                   1331 ;	quantum/action_util.c:128: return true;
      007E60 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:129: }
      007E63 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:139: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007E64                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007E64 7F 00            [12] 1347 	mov	r7,#0x00
      007E66                       1348 00104$:
      007E66 BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007E69                       1350 00141$:
      007E69 50 14            [24] 1351 	jnc	00101$
      007E6B EF               [12] 1352 	mov	a,r7
      007E6C 24 55            [12] 1353 	add	a, #_usage_refs
      007E6E FD               [12] 1354 	mov	r5,a
      007E6F E4               [12] 1355 	clr	a
      007E70 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007E72 FE               [12] 1357 	mov	r6,a
      007E73 EF               [12] 1358 	mov	a,r7
      007E74 12 80 C4         [24] 1359 	lcall	_ak820_outline_0068
      007E77 E4               [12] 1360 	clr	a
      007E78 F0               [24] 1361 	movx	@dptr,a
      007E79 12 80 E4         [24] 1362 	lcall	_ak820_outline_0123
      007E7C 0F               [12] 1363 	inc	r7
      007E7D 80 E7            [24] 1364 	sjmp	00104$
      007E7F                       1365 00101$:
                                   1366 ;	quantum/action_util.c:141: usage_lengths[0] = usage_lengths[1] = 0;
      007E7F 90 0A 92         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007E82 E4               [12] 1368 	clr	a
      007E83 F0               [24] 1369 	movx	@dptr,a
      007E84 90 0A 91         [24] 1370 	mov	dptr,#_usage_lengths
      007E87 F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:142: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007E88 FF               [12] 1373 	mov	r7,a
      007E89                       1374 00107$:
      007E89 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007E8C                       1376 00143$:
      007E8C 50 0D            [24] 1377 	jnc	00109$
      007E8E EF               [12] 1378 	mov	a,r7
      007E8F 24 93            [12] 1379 	add	a, #_macro_usages
      007E91 F5 82            [12] 1380 	mov	dpl,a
      007E93 E4               [12] 1381 	clr	a
      007E94 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007E96 12 7B 65         [24] 1383 	lcall	_ak820_outline_0166
      007E99 80 EE            [24] 1384 	sjmp	00107$
      007E9B                       1385 00109$:
                                   1386 ;	quantum/action_util.c:143: }
      007E9B 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:144: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007E9C                       1407 _owned_usage_key:
      007E9C E5 82            [12] 1408 	mov	a,dpl
      007E9E 90 0A 98         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_368
      007EA1 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:145: uint8_t which = code >= KC_AUDIO_MUTE;
      007EA2 E0               [24] 1412 	movx	a,@dptr
      007EA3 FF               [12] 1413 	mov	r7,a
      007EA4 BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007EA7                       1415 00244$:
      007EA7 B3               [12] 1416 	cpl	c
      007EA8 92 22            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007EAA E4               [12] 1418 	clr	a
      007EAB 33               [12] 1419 	rlc	a
      007EAC FF               [12] 1420 	mov	r7,a
      007EAD 90 0A 9B         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_369
      007EB0 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:146: uint8_t base = which ? SYSTEM_COUNT : 0;
      007EB1 EF               [12] 1424 	mov	a,r7
      007EB2 60 02            [24] 1425 	jz	00129$
      007EB4 74 03            [12] 1426 	mov	a,#0x03
      007EB6                       1427 00129$:
      007EB6 FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:147: uint8_t count = usage_lengths[which];
      007EB7 EF               [12] 1430 	mov	a,r7
      007EB8 24 91            [12] 1431 	add	a, #_usage_lengths
      007EBA FD               [12] 1432 	mov	r5,a
      007EBB E4               [12] 1433 	clr	a
      007EBC 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      007EBE FF               [12] 1435 	mov	r7,a
      007EBF 12 81 00         [24] 1436 	lcall	_ak820_outline_0191
      007EC2 E0               [24] 1437 	movx	a,@dptr
      007EC3 FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:148: uint8_t index = code - KC_SYSTEM_POWER;
      007EC4 90 0A 98         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_368
      007EC7 E0               [24] 1441 	movx	a,@dptr
      007EC8 24 5B            [12] 1442 	add	a,#0x5b
      007ECA FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:149: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007ECB 90 0A 97         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      007ECE E0               [24] 1446 	movx	a,@dptr
      007ECF FA               [12] 1447 	mov	r2,a
      007ED0 90 09 8C         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      007ED3 EB               [12] 1449 	mov	a,r3
      007ED4 F0               [24] 1450 	movx	@dptr,a
      007ED5 90 09 8D         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      007ED8 EA               [12] 1452 	mov	a,r2
      007ED9 F0               [24] 1453 	movx	@dptr,a
      007EDA 90 0A 93         [24] 1454 	mov	dptr,#_macro_usages
      007EDD C0 07            [24] 1455 	push	ar7
      007EDF C0 06            [24] 1456 	push	ar6
      007EE1 C0 05            [24] 1457 	push	ar5
      007EE3 C0 04            [24] 1458 	push	ar4
      007EE5 C0 03            [24] 1459 	push	ar3
      007EE7 C0 02            [24] 1460 	push	ar2
      007EE9 12 7B 74         [24] 1461 	lcall	_ak820_macro_change
      007EEC E5 82            [12] 1462 	mov	a, dpl
      007EEE D0 02            [24] 1463 	pop	ar2
      007EF0 D0 03            [24] 1464 	pop	ar3
      007EF2 D0 04            [24] 1465 	pop	ar4
      007EF4 D0 05            [24] 1466 	pop	ar5
      007EF6 D0 06            [24] 1467 	pop	ar6
      007EF8 D0 07            [24] 1468 	pop	ar7
      007EFA 70 01            [24] 1469 	jnz	00102$
      007EFC 22               [24] 1470 	ret
      007EFD                       1471 00102$:
                                   1472 ;	quantum/action_util.c:150: if (pressed) {
      007EFD EA               [12] 1473 	mov	a,r2
      007EFE 60 1B            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:151: if (usage_refs[index]++) return;
      007F00 12 80 CE         [24] 1476 	lcall	_ak820_outline_0075
      007F03 04               [12] 1477 	inc	a
      007F04 12 6C 44         [24] 1478 	lcall	_ak820_outline_0141
      007F07 E8               [12] 1479 	mov	a,r0
      007F08 60 01            [24] 1480 	jz	00104$
      007F0A 22               [24] 1481 	ret
      007F0B                       1482 00104$:
                                   1483 ;	quantum/action_util.c:152: usage_order[base + count++] = index;
      007F0B 90 0A 9C         [24] 1484 	mov	dptr,#_owned_usage_key_count_10000_369
      007F0E EC               [12] 1485 	mov	a,r4
      007F0F 04               [12] 1486 	inc	a
      007F10 F0               [24] 1487 	movx	@dptr,a
      007F11 EC               [12] 1488 	mov	a,r4
      007F12 2E               [12] 1489 	add	a, r6
      007F13 12 80 C4         [24] 1490 	lcall	_ak820_outline_0068
      007F16 EB               [12] 1491 	mov	a,r3
      007F17 F0               [24] 1492 	movx	@dptr,a
      007F18 02 7F 7C         [24] 1493 	ljmp	00116$
      007F1B                       1494 00115$:
                                   1495 ;	quantum/action_util.c:154: if (!usage_refs[index] || --usage_refs[index]) return;
      007F1B 12 80 CE         [24] 1496 	lcall	_ak820_outline_0075
      007F1E 60 07            [24] 1497 	jz	00105$
      007F20 18               [12] 1498 	dec	r0
      007F21 12 80 BD         [24] 1499 	lcall	_ak820_outline_0064
      007F24 E8               [12] 1500 	mov	a,r0
      007F25 60 01            [24] 1501 	jz	00106$
      007F27                       1502 00105$:
      007F27 22               [24] 1503 	ret
      007F28                       1504 00106$:
                                   1505 ;	quantum/action_util.c:156: while (usage_order[base + pos] != index) ++pos;
      007F28 7A 00            [12] 1506 	mov	r2,#0x00
      007F2A                       1507 00108$:
      007F2A EA               [12] 1508 	mov	a,r2
      007F2B 2E               [12] 1509 	add	a, r6
      007F2C 12 80 C4         [24] 1510 	lcall	_ak820_outline_0068
      007F2F E0               [24] 1511 	movx	a,@dptr
      007F30 B5 03 02         [24] 1512 	cjne	a,ar3,00251$
      007F33 80 03            [24] 1513 	sjmp	00167$
      007F35                       1514 00251$:
      007F35 0A               [12] 1515 	inc	r2
      007F36 80 F2            [24] 1516 	sjmp	00108$
      007F38                       1517 00167$:
      007F38 90 0A 9D         [24] 1518 	mov	dptr,#_owned_usage_key_pos_30001_376
      007F3B EA               [12] 1519 	mov	a,r2
      007F3C F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action_util.c:157: --count;
      007F3D 1C               [12] 1522 	dec	r4
      007F3E 90 0A 9C         [24] 1523 	mov	dptr,#_owned_usage_key_count_10000_369
      007F41 EC               [12] 1524 	mov	a,r4
      007F42 F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:158: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007F43 8A 03            [24] 1527 	mov	ar3,r2
      007F45                       1528 00125$:
      007F45 C3               [12] 1529 	clr	c
      007F46 EB               [12] 1530 	mov	a,r3
      007F47 9C               [12] 1531 	subb	a,r4
      007F48 50 23            [24] 1532 	jnc	00111$
      007F4A C0 05            [24] 1533 	push	ar5
      007F4C C0 07            [24] 1534 	push	ar7
      007F4E EB               [12] 1535 	mov	a,r3
      007F4F 2E               [12] 1536 	add	a, r6
      007F50 FA               [12] 1537 	mov	r2,a
      007F51 24 73            [12] 1538 	add	a, #_usage_order
      007F53 F8               [12] 1539 	mov	r0,a
      007F54 E4               [12] 1540 	clr	a
      007F55 34 0A            [12] 1541 	addc	a, #(_usage_order >> 8)
      007F57 F9               [12] 1542 	mov	r1,a
      007F58 0A               [12] 1543 	inc	r2
      007F59 EA               [12] 1544 	mov	a,r2
      007F5A 33               [12] 1545 	rlc	a
      007F5B 95 E0            [12] 1546 	subb	a,acc
      007F5D FF               [12] 1547 	mov	r7,a
      007F5E EA               [12] 1548 	mov	a,r2
      007F5F 12 80 EA         [24] 1549 	lcall	_ak820_outline_0127
      007F62 12 38 B6         [24] 1550 	lcall	_ak820_outline_0160
      007F65 F0               [24] 1551 	movx	@dptr,a
      007F66 0B               [12] 1552 	inc	r3
      007F67 D0 07            [24] 1553 	pop	ar7
      007F69 D0 05            [24] 1554 	pop	ar5
      007F6B 80 D8            [24] 1555 	sjmp	00125$
      007F6D                       1556 00111$:
                                   1557 ;	quantum/action_util.c:159: usage_lengths[which] = count;
      007F6D 12 81 00         [24] 1558 	lcall	_ak820_outline_0191
      007F70 EC               [12] 1559 	mov	a,r4
      007F71 F0               [24] 1560 	movx	@dptr,a
                                   1561 ;	quantum/action_util.c:160: if (pos != count) return; /* A non-winning owner changed only storage. */
      007F72 90 0A 9D         [24] 1562 	mov	dptr,#_owned_usage_key_pos_30001_376
      007F75 E0               [24] 1563 	movx	a,@dptr
      007F76 B5 04 02         [24] 1564 	cjne	a,ar4,00253$
      007F79 80 01            [24] 1565 	sjmp	00116$
      007F7B                       1566 00253$:
      007F7B 22               [24] 1567 	ret
      007F7C                       1568 00116$:
                                   1569 ;	quantum/action_util.c:162: usage_lengths[which] = count;
      007F7C 90 0A 9C         [24] 1570 	mov	dptr,#_owned_usage_key_count_10000_369
      007F7F E0               [24] 1571 	movx	a,@dptr
      007F80 FC               [12] 1572 	mov	r4,a
      007F81 12 81 00         [24] 1573 	lcall	_ak820_outline_0191
      007F84 F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/action_util.c:163: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007F85 EC               [12] 1576 	mov	a,r4
      007F86 60 15            [24] 1577 	jz	00131$
      007F88 EC               [12] 1578 	mov	a,r4
      007F89 2E               [12] 1579 	add	a, r6
      007F8A FE               [12] 1580 	mov	r6,a
      007F8B 1E               [12] 1581 	dec	r6
      007F8C EE               [12] 1582 	mov	a,r6
      007F8D 33               [12] 1583 	rlc	a
      007F8E 95 E0            [12] 1584 	subb	a,acc
      007F90 FF               [12] 1585 	mov	r7,a
      007F91 EE               [12] 1586 	mov	a,r6
      007F92 12 80 EA         [24] 1587 	lcall	_ak820_outline_0127
      007F95 24 A5            [12] 1588 	add	a,#0xa5
      007F97 FE               [12] 1589 	mov	r6,a
      007F98 33               [12] 1590 	rlc	a
      007F99 95 E0            [12] 1591 	subb	a,acc
      007F9B 80 02            [24] 1592 	sjmp	00132$
      007F9D                       1593 00131$:
      007F9D 7E 00            [12] 1594 	mov	r6,#0x00
      007F9F                       1595 00132$:
      007F9F 90 0A 98         [24] 1596 	mov	dptr,#_owned_usage_key_code_10000_368
      007FA2 EE               [12] 1597 	mov	a,r6
      007FA3 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/action_util.c:164: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007FA4 90 0A 9B         [24] 1600 	mov	dptr,#_owned_usage_key_which_10000_369
      007FA7 E0               [24] 1601 	movx	a,@dptr
      007FA8 60 18            [24] 1602 	jz	00118$
      007FAA EE               [12] 1603 	mov	a,r6
      007FAB 60 0B            [24] 1604 	jz	00133$
      007FAD 8E 82            [24] 1605 	mov	dpl, r6
      007FAF 12 6D 84         [24] 1606 	lcall	_KEYCODE2CONSUMER
      007FB2 AD 82            [24] 1607 	mov	r5, dpl
      007FB4 AF 83            [24] 1608 	mov	r7, dph
      007FB6 80 04            [24] 1609 	sjmp	00134$
      007FB8                       1610 00133$:
      007FB8 7D 00            [12] 1611 	mov	r5,#0x00
      007FBA 7F 00            [12] 1612 	mov	r7,#0x00
      007FBC                       1613 00134$:
      007FBC 12 81 00         [24] 1614 	lcall	_ak820_outline_0191
      007FBF 02 6D 37         [24] 1615 	ljmp	_host_consumer_send
      007FC2                       1616 00118$:
                                   1617 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007FC2 EE               [12] 1618 	mov	a,r6
      007FC3 60 22            [24] 1619 	jz	00135$
                                   1620 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007FC5 BE A5 00         [24] 1621 	cjne	r6,#0xa5,00258$
      007FC8                       1622 00258$:
      007FC8 40 05            [24] 1623 	jc	00121$
      007FCA EE               [12] 1624 	mov	a,r6
      007FCB 24 58            [12] 1625 	add	a,#0xff - 0xa7
      007FCD 50 08            [24] 1626 	jnc	00122$
                                   1627 ;	free result
      007FCF                       1628 00121$:
      007FCF 90 0A 99         [24] 1629 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007FD2 12 4F 3C         [24] 1630 	lcall	_ak820_outline_0184
      007FD5 80 09            [24] 1631 	sjmp	00123$
      007FD7                       1632 00122$:
                                   1633 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007FD7 74 DC            [12] 1634 	mov	a,#0xdc
      007FD9 2E               [12] 1635 	add	a, r6
      007FDA 90 0A 99         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007FDD 12 38 9C         [24] 1637 	lcall	_ak820_outline_0136
                                   1638 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007FE0                       1639 00123$:
      007FE0 90 0A 99         [24] 1640 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007FE3 E0               [24] 1641 	movx	a,@dptr
      007FE4 FF               [12] 1642 	mov	r7,a
      007FE5 80 02            [24] 1643 	sjmp	00136$
      007FE7                       1644 00135$:
      007FE7 7F 00            [12] 1645 	mov	r7,#0x00
      007FE9                       1646 00136$:
      007FE9 7E 00            [12] 1647 	mov	r6,#0x00
      007FEB 12 43 72         [24] 1648 	lcall	_ak820_outline_0161
                                   1649 ;	quantum/action_util.c:166: }
      007FEE 02 6D 07         [24] 1650 	ljmp	_host_system_send
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1653 ;------------------------------------------------------------
                                   1654 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1655 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1656 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1657 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1658 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1659 ;------------------------------------------------------------
                                   1660 ;	quantum/action_util.c:388: void send_keyboard_report(void) {
                                   1661 ;	-----------------------------------------
                                   1662 ;	 function send_keyboard_report
                                   1663 ;	-----------------------------------------
      007FF1                       1664 _send_keyboard_report:
                                   1665 ;	quantum/action_util.c:389: keyboard_report->mods = real_mods;
      007FF1 90 0D C7         [24] 1666 	mov	dptr,#_real_mods
      007FF4 E0               [24] 1667 	movx	a,@dptr
      007FF5 FF               [12] 1668 	mov	r7,a
      007FF6 90 0D C9         [24] 1669 	mov	dptr,#_actual_keyboard_report
      007FF9 F0               [24] 1670 	movx	@dptr,a
                                   1671 ;	quantum/action_util.c:390: keyboard_report->mods |= weak_mods;
      007FFA 90 0D C8         [24] 1672 	mov	dptr,#_weak_mods
      007FFD E0               [24] 1673 	movx	a,@dptr
      007FFE 42 07            [12] 1674 	orl	ar7,a
      008000 90 0D C9         [24] 1675 	mov	dptr,#_actual_keyboard_report
      008003 EF               [12] 1676 	mov	a,r7
      008004 F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:392: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008005 90 09 87         [24] 1679 	mov	dptr,#_owned_weak_mods
      008008 E0               [24] 1680 	movx	a,@dptr
      008009 FE               [12] 1681 	mov	r6,a
      00800A 90 09 86         [24] 1682 	mov	dptr,#_owned_mods
      00800D E0               [24] 1683 	movx	a,@dptr
      00800E 4E               [12] 1684 	orl	a,r6
      00800F 42 07            [12] 1685 	orl	ar7,a
      008011 90 0D C9         [24] 1686 	mov	dptr,#_actual_keyboard_report
      008014 EF               [12] 1687 	mov	a,r7
      008015 F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:427: bool changed = false;
      008016 90 0A BF         [24] 1690 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008019 E4               [12] 1691 	clr	a
      00801A F0               [24] 1692 	movx	@dptr,a
                                   1693 ;	quantum/action_util.c:429: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1694 ;	quantum/action_util.c:430: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1695 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00801B FF               [12] 1696 	mov	r7,a
      00801C                       1697 00107$:
      00801C BF 20 00         [24] 1698 	cjne	r7,#0x20,00140$
      00801F                       1699 00140$:
      00801F 50 2B            [24] 1700 	jnc	00103$
                                   1701 ;	quantum/action_util.c:436: if (dest[i] != src[i]) {
      008021 EF               [12] 1702 	mov	a,r7
      008022 24 9F            [12] 1703 	add	a, #_send_keyboard_report_last_report_10001_388
      008024 FD               [12] 1704 	mov	r5,a
      008025 E4               [12] 1705 	clr	a
      008026 34 0A            [12] 1706 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      008028 FE               [12] 1707 	mov	r6,a
      008029 12 48 90         [24] 1708 	lcall	_ak820_outline_0077
      00802C EF               [12] 1709 	mov	a,r7
      00802D 24 C9            [12] 1710 	add	a, #_actual_keyboard_report
      00802F F5 82            [12] 1711 	mov	dpl,a
      008031 E4               [12] 1712 	clr	a
      008032 34 0D            [12] 1713 	addc	a, #(_actual_keyboard_report >> 8)
      008034 F5 83            [12] 1714 	mov	dph,a
      008036 E0               [24] 1715 	movx	a,@dptr
      008037 FB               [12] 1716 	mov	r3,a
      008038 EC               [12] 1717 	mov	a,r4
      008039 B5 03 02         [24] 1718 	cjne	a,ar3,00142$
      00803C 80 0B            [24] 1719 	sjmp	00108$
      00803E                       1720 00142$:
                                   1721 ;	quantum/action_util.c:437: dest[i] = src[i];
      00803E 12 38 A1         [24] 1722 	lcall	_ak820_outline_0137
      008041 EB               [12] 1723 	mov	a,r3
      008042 F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action_util.c:438: changed = true;
      008043 90 0A BF         [24] 1726 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008046 74 01            [12] 1727 	mov	a,#0x01
      008048 F0               [24] 1728 	movx	@dptr,a
      008049                       1729 00108$:
                                   1730 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008049 0F               [12] 1731 	inc	r7
      00804A 80 D0            [24] 1732 	sjmp	00107$
      00804C                       1733 00103$:
                                   1734 ;	quantum/action_util.c:441: if (changed) host_keyboard_send(keyboard_report);
      00804C 90 0A BF         [24] 1735 	mov	dptr,#_send_keyboard_report_changed_10001_388
      00804F E0               [24] 1736 	movx	a,@dptr
      008050 60 09            [24] 1737 	jz	00109$
      008052 90 0D C9         [24] 1738 	mov	dptr,#_actual_keyboard_report
      008055 75 F0 00         [24] 1739 	mov	b, #0x00
                                   1740 ;	quantum/action_util.c:449: }
      008058 02 6C 7C         [24] 1741 	ljmp	_host_keyboard_send
      00805B                       1742 00109$:
      00805B 22               [24] 1743 	ret
                                   1744 ;------------------------------------------------------------
                                   1745 ;Allocation info for local variables in function 'get_mods'
                                   1746 ;------------------------------------------------------------
                                   1747 ;	quantum/action_util.c:455: uint8_t get_mods(void) {
                                   1748 ;	-----------------------------------------
                                   1749 ;	 function get_mods
                                   1750 ;	-----------------------------------------
      00805C                       1751 _get_mods:
      00805C C0 07            [24] 1752 	push	ar7
                                   1753 ;	quantum/action_util.c:460: ;
      00805E 90 09 86         [24] 1754 	mov	dptr,#_owned_mods
      008061 E0               [24] 1755 	movx	a,@dptr
      008062 FF               [12] 1756 	mov	r7,a
      008063 90 0D C7         [24] 1757 	mov	dptr,#_real_mods
      008066 12 7B 5F         [24] 1758 	lcall	_ak820_outline_0143
                                   1759 ;	quantum/action_util.c:461: }
      008069 D0 07            [24] 1760 	pop	ar7
      00806B 22               [24] 1761 	ret
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'add_mods'
                                   1764 ;------------------------------------------------------------
                                   1765 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	quantum/action_util.c:466: void add_mods(uint8_t mods) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function clear_mods
                                   1770 ;	-----------------------------------------
      00806C                       1771 _clear_mods:
                                   1772 ;	quantum/action_util.c:488: real_mods = 0;
      00806C 90 0D C7         [24] 1773 	mov	dptr,#_real_mods
      00806F E4               [12] 1774 	clr	a
      008070 F0               [24] 1775 	movx	@dptr,a
                                   1776 ;	quantum/action_util.c:489: }
      008071 22               [24] 1777 	ret
                                   1778 ;------------------------------------------------------------
                                   1779 ;Allocation info for local variables in function 'get_weak_mods'
                                   1780 ;------------------------------------------------------------
                                   1781 ;	quantum/action_util.c:495: uint8_t get_weak_mods(void) {
                                   1782 ;	-----------------------------------------
                                   1783 ;	 function get_weak_mods
                                   1784 ;	-----------------------------------------
      008072                       1785 _get_weak_mods:
      008072 C0 07            [24] 1786 	push	ar7
                                   1787 ;	quantum/action_util.c:500: ;
      008074 90 09 87         [24] 1788 	mov	dptr,#_owned_weak_mods
      008077 E0               [24] 1789 	movx	a,@dptr
      008078 FF               [12] 1790 	mov	r7,a
      008079 90 0D C8         [24] 1791 	mov	dptr,#_weak_mods
      00807C 12 7B 5F         [24] 1792 	lcall	_ak820_outline_0143
                                   1793 ;	quantum/action_util.c:501: }
      00807F D0 07            [24] 1794 	pop	ar7
      008081 22               [24] 1795 	ret
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'add_weak_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1800 ;------------------------------------------------------------
                                   1801 ;	quantum/action_util.c:506: void add_weak_mods(uint8_t mods) {
                                   1802 ;	-----------------------------------------
                                   1803 ;	 function add_weak_mods
                                   1804 ;	-----------------------------------------
      008082                       1805 _add_weak_mods:
      008082 E5 82            [12] 1806 	mov	a,dpl
      008084 90 0A C0         [24] 1807 	mov	dptr,#_add_weak_mods_mods_10000_406
      008087 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	quantum/action_util.c:507: weak_mods |= mods;
      008088 E0               [24] 1810 	movx	a,@dptr
      008089 FF               [12] 1811 	mov	r7,a
      00808A 90 0D C8         [24] 1812 	mov	dptr,#_weak_mods
      00808D E0               [24] 1813 	movx	a,@dptr
      00808E 4F               [12] 1814 	orl	a,r7
      00808F F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	quantum/action_util.c:508: }
      008090 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'del_weak_mods'
                                   1820 ;------------------------------------------------------------
                                   1821 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/action_util.c:513: void del_weak_mods(uint8_t mods) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function del_weak_mods
                                   1826 ;	-----------------------------------------
      008091                       1827 _del_weak_mods:
      008091 E5 82            [12] 1828 	mov	a,dpl
      008093 90 0A C1         [24] 1829 	mov	dptr,#_del_weak_mods_mods_10000_408
      008096 F0               [24] 1830 	movx	@dptr,a
                                   1831 ;	quantum/action_util.c:514: weak_mods &= ~mods;
      008097 E0               [24] 1832 	movx	a,@dptr
      008098 F4               [12] 1833 	cpl	a
      008099 FF               [12] 1834 	mov	r7,a
      00809A 90 0D C8         [24] 1835 	mov	dptr,#_weak_mods
      00809D E0               [24] 1836 	movx	a,@dptr
      00809E 5F               [12] 1837 	anl	a,r7
      00809F F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	quantum/action_util.c:515: }
      0080A0 22               [24] 1840 	ret
                                   1841 ;------------------------------------------------------------
                                   1842 ;Allocation info for local variables in function 'set_weak_mods'
                                   1843 ;------------------------------------------------------------
                                   1844 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1845 ;------------------------------------------------------------
                                   1846 ;	quantum/action_util.c:520: void set_weak_mods(uint8_t mods) {
                                   1847 ;	-----------------------------------------
                                   1848 ;	 function clear_weak_mods
                                   1849 ;	-----------------------------------------
      0080A1                       1850 _clear_weak_mods:
                                   1851 ;	quantum/action_util.c:528: weak_mods = 0;
      0080A1 90 0D C8         [24] 1852 	mov	dptr,#_weak_mods
      0080A4 E4               [12] 1853 	clr	a
      0080A5 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/action_util.c:529: }
      0080A6 22               [24] 1856 	ret
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1859 ;------------------------------------------------------------
                                   1860 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1861 ;------------------------------------------------------------
                                   1862 ;	quantum/action_util.c:611: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1863 ;	-----------------------------------------
                                   1864 	.area CSEG    (CODE)
                                   1865 	.area CONST   (CODE)
                                   1866 	.area XINIT   (CODE)
      00C0A8                       1867 __xinit__real_mods:
      00C0A8 00                    1868 	.db #0x00	; 0
      00C0A9                       1869 __xinit__weak_mods:
      00C0A9 00                    1870 	.db #0x00	; 0
      00C0AA                       1871 __xinit__actual_keyboard_report:
      00C0AA 00                    1872 	.db #0x00	; 0
      00C0AB 00                    1873 	.db #0x00	; 0
      00C0AC 00                    1874 	.db #0x00	; 0
      00C0AD 00                    1875 	.db #0x00	; 0
      00C0AE 00                    1876 	.db #0x00	; 0
      00C0AF 00                    1877 	.db #0x00	; 0
      00C0B0 00                    1878 	.db #0x00	; 0
      00C0B1 00                    1879 	.db #0x00	; 0
      00C0B2 00                    1880 	.db 0x00
      00C0B3 00                    1881 	.db 0x00
      00C0B4 00                    1882 	.db 0x00
      00C0B5 00                    1883 	.db 0x00
      00C0B6 00                    1884 	.db 0x00
      00C0B7 00                    1885 	.db 0x00
      00C0B8 00                    1886 	.db 0x00
      00C0B9 00                    1887 	.db 0x00
      00C0BA 00                    1888 	.db 0x00
      00C0BB 00                    1889 	.db 0x00
      00C0BC 00                    1890 	.db 0x00
      00C0BD 00                    1891 	.db 0x00
      00C0BE 00                    1892 	.db 0x00
      00C0BF 00                    1893 	.db 0x00
      00C0C0 00                    1894 	.db 0x00
      00C0C1 00                    1895 	.db 0x00
      00C0C2 00                    1896 	.db 0x00
      00C0C3 00                    1897 	.db 0x00
      00C0C4 00                    1898 	.db 0x00
      00C0C5 00                    1899 	.db 0x00
      00C0C6 00                    1900 	.db 0x00
      00C0C7 00                    1901 	.db 0x00
      00C0C8 00                    1902 	.db 0x00
      00C0C9 00                    1903 	.db 0x00
                                   1904 	.area CABS    (ABS,CODE)
                                   1905 
                                   1906 ; Experimental exact instruction outlining.
                                   1907 	.globl _ak820_outline_0017
                                   1908 	.globl _ak820_outline_0030
                                   1909 	.globl _ak820_outline_0056
                                   1910 	.globl _ak820_outline_0058
                                   1911 	.globl _ak820_outline_0061
                                   1912 	.globl _ak820_outline_0063
                                   1913 	.globl _ak820_outline_0064
                                   1914 	.globl _ak820_outline_0065
                                   1915 	.globl _ak820_outline_0068
                                   1916 	.globl _ak820_outline_0075
                                   1917 	.globl _ak820_outline_0077
                                   1918 	.globl _ak820_outline_0109
                                   1919 	.globl _ak820_outline_0110
                                   1920 	.globl _ak820_outline_0119
                                   1921 	.globl _ak820_outline_0123
                                   1922 	.globl _ak820_outline_0125
                                   1923 	.globl _ak820_outline_0127
                                   1924 	.globl _ak820_outline_0134
                                   1925 	.globl _ak820_outline_0136
                                   1926 	.globl _ak820_outline_0137
                                   1927 	.globl _ak820_outline_0141
                                   1928 	.globl _ak820_outline_0143
                                   1929 	.globl _ak820_outline_0160
                                   1930 	.globl _ak820_outline_0161
                                   1931 	.globl _ak820_outline_0166
                                   1932 	.globl _ak820_outline_0184
                                   1933 	.globl _ak820_outline_0190
                                   1934 	.globl _ak820_outline_0191
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0030
      0080A7                       1938 _ak820_outline_0030:
      0080A7 EF               [12] 1939 	mov	a,r7
      0080A8 24 98            [12] 1940 	add	a,#_key_refs
      0080AA FD               [12] 1941 	mov	r5,a
      0080AB E4               [12] 1942 	clr	a
      0080AC 34 09            [12] 1943 	addc	a,#(_key_refs>>8)
      0080AE FE               [12] 1944 	mov	r6,a
      0080AF 8D 82            [24] 1945 	mov	dpl,r5
      0080B1 8E 83            [24] 1946 	mov	dph,r6
      0080B3 E0               [24] 1947 	movx	a,@dptr
      0080B4 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0058
      0080B5                       1952 _ak820_outline_0058:
      0080B5 F0               [24] 1953 	movx	@dptr,a
      0080B6 90 0D C9         [24] 1954 	mov	dptr,#_actual_keyboard_report
      0080B9 75 F0 00         [24] 1955 	mov	b,#0x00
      0080BC 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0064
      0080BD                       1960 _ak820_outline_0064:
      0080BD 89 82            [24] 1961 	mov	dpl,r1
      0080BF 8A 83            [24] 1962 	mov	dph,r2
      0080C1 E8               [12] 1963 	mov	a,r0
      0080C2 F0               [24] 1964 	movx	@dptr,a
      0080C3 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0068
      0080C4                       1969 _ak820_outline_0068:
      0080C4 24 73            [12] 1970 	add	a,#_usage_order
      0080C6 F5 82            [12] 1971 	mov	dpl,a
      0080C8 E4               [12] 1972 	clr	a
      0080C9 34 0A            [12] 1973 	addc	a,#(_usage_order>>8)
      0080CB F5 83            [12] 1974 	mov	dph,a
      0080CD 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0075
      0080CE                       1979 _ak820_outline_0075:
      0080CE EB               [12] 1980 	mov	a,r3
      0080CF 24 55            [12] 1981 	add	a,#_usage_refs
      0080D1 F9               [12] 1982 	mov	r1,a
      0080D2 E4               [12] 1983 	clr	a
      0080D3 34 0A            [12] 1984 	addc	a,#(_usage_refs>>8)
      0080D5 FA               [12] 1985 	mov	r2,a
      0080D6 89 82            [24] 1986 	mov	dpl,r1
      0080D8 8A 83            [24] 1987 	mov	dph,r2
      0080DA E0               [24] 1988 	movx	a,@dptr
      0080DB F8               [12] 1989 	mov	r0,a
      0080DC 22               [24] 1990 	ret
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0119
      0080DD                       1994 _ak820_outline_0119:
      0080DD F0               [24] 1995 	movx	@dptr,a
      0080DE E0               [24] 1996 	movx	a,@dptr
      0080DF FF               [12] 1997 	mov	r7,a
      0080E0 90 09 90         [24] 1998 	mov	dptr,#_change_owned_PARM_2
      0080E3 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0123
      0080E4                       2003 _ak820_outline_0123:
      0080E4 8D 82            [24] 2004 	mov	dpl,r5
      0080E6 8E 83            [24] 2005 	mov	dph,r6
      0080E8 F0               [24] 2006 	movx	@dptr,a
      0080E9 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0127
      0080EA                       2011 _ak820_outline_0127:
      0080EA 24 73            [12] 2012 	add	a,#_usage_order
      0080EC F5 82            [12] 2013 	mov	dpl,a
      0080EE EF               [12] 2014 	mov	a,r7
      0080EF 34 0A            [12] 2015 	addc	a,#(_usage_order>>8)
      0080F1 F5 83            [12] 2016 	mov	dph,a
      0080F3 E0               [24] 2017 	movx	a,@dptr
      0080F4 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0134
      0080F5                       2022 _ak820_outline_0134:
      0080F5 F0               [24] 2023 	movx	@dptr,a
      0080F6 E0               [24] 2024 	movx	a,@dptr
      0080F7 FF               [12] 2025 	mov	r7,a
      0080F8 90 09 8C         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_2
      0080FB F0               [24] 2027 	movx	@dptr,a
      0080FC 90 09 8D         [24] 2028 	mov	dptr,#_ak820_macro_change_PARM_3
      0080FF 22               [24] 2029 	ret
                                   2030 
                                   2031 	.area CSEG (CODE)
                                   2032 ; function ak820_outline_0191
      008100                       2033 _ak820_outline_0191:
      008100 8D 82            [24] 2034 	mov	dpl,r5
      008102 8F 83            [24] 2035 	mov	dph,r7
      008104 22               [24] 2036 	ret
