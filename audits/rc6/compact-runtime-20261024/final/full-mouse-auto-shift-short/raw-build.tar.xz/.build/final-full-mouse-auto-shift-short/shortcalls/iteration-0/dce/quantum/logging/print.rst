                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module print
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _putchar_
                                     12 	.globl _print_set_sendchar
                                     13 ;--------------------------------------------------------
                                     14 ; special function registers
                                     15 ;--------------------------------------------------------
                                     16 	.area RSEG    (ABS,DATA)
      000000                         17 	.org 0x0000
                                     18 ;--------------------------------------------------------
                                     19 ; special function bits
                                     20 ;--------------------------------------------------------
                                     21 	.area RSEG    (ABS,DATA)
      000000                         22 	.org 0x0000
                                     23 ;--------------------------------------------------------
                                     24 ; overlayable register banks
                                     25 ;--------------------------------------------------------
                                     26 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         27 	.ds 8
                                     28 ;--------------------------------------------------------
                                     29 ; internal ram data
                                     30 ;--------------------------------------------------------
                                     31 	.area DSEG    (DATA)
                                     32 ;--------------------------------------------------------
                                     33 ; overlayable items in internal ram
                                     34 ;--------------------------------------------------------
                                     35 ;--------------------------------------------------------
                                     36 ; indirectly addressable internal ram data
                                     37 ;--------------------------------------------------------
                                     38 	.area ISEG    (DATA)
                                     39 ;--------------------------------------------------------
                                     40 ; absolute internal ram data
                                     41 ;--------------------------------------------------------
                                     42 	.area IABS    (ABS,DATA)
                                     43 	.area IABS    (ABS,DATA)
                                     44 ;--------------------------------------------------------
                                     45 ; bit data
                                     46 ;--------------------------------------------------------
                                     47 	.area BSEG    (BIT)
                                     48 ;--------------------------------------------------------
                                     49 ; paged external ram data
                                     50 ;--------------------------------------------------------
                                     51 	.area PSEG    (PAG,XDATA)
                                     52 ;--------------------------------------------------------
                                     53 ; uninitialized external ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area XSEG    (XDATA)
      000BD9                         56 _print_set_sendchar_send_10000_6:
      000BD9                         57 	.ds 2
      000BDB                         58 _putchar__character_10000_8:
      000BDB                         59 	.ds 1
                                     60 ;--------------------------------------------------------
                                     61 ; absolute external ram data
                                     62 ;--------------------------------------------------------
                                     63 	.area XABS    (ABS,XDATA)
                                     64 ;--------------------------------------------------------
                                     65 ; initialized external ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area XISEG   (XDATA)
      000E46                         68 _func:
      000E46                         69 	.ds 2
                                     70 	.area HOME    (CODE)
                                     71 	.area GSINIT0 (CODE)
                                     72 	.area GSINIT1 (CODE)
                                     73 	.area GSINIT2 (CODE)
                                     74 	.area GSINIT3 (CODE)
                                     75 	.area GSINIT4 (CODE)
                                     76 	.area GSINIT5 (CODE)
                                     77 	.area GSINIT  (CODE)
                                     78 	.area GSFINAL (CODE)
                                     79 	.area CSEG    (CODE)
                                     80 ;--------------------------------------------------------
                                     81 ; global & static initialisations
                                     82 ;--------------------------------------------------------
                                     83 	.area HOME    (CODE)
                                     84 	.area GSINIT  (CODE)
                                     85 	.area GSFINAL (CODE)
                                     86 	.area GSINIT  (CODE)
                                     87 ;--------------------------------------------------------
                                     88 ; Home
                                     89 ;--------------------------------------------------------
                                     90 	.area HOME    (CODE)
                                     91 	.area HOME    (CODE)
                                     92 ;--------------------------------------------------------
                                     93 ; code
                                     94 ;--------------------------------------------------------
                                     95 	.area CSEG    (CODE)
                                     96 ;------------------------------------------------------------
                                     97 ;Allocation info for local variables in function 'null_sendchar_func'
                                     98 ;------------------------------------------------------------
                                     99 ;c             Allocated with name '_null_sendchar_func_c_10000_4'
                                    100 ;------------------------------------------------------------
                                    101 ;	quantum/logging/print.c:22: static int8_t null_sendchar_func(uint8_t c) {
                                    102 ;	-----------------------------------------
                                    103 ;	 function null_sendchar_func
                                    104 ;	-----------------------------------------
      009C6B                        105 _null_sendchar_func:
                           000007   106 	ar7 = 0x07
                           000006   107 	ar6 = 0x06
                           000005   108 	ar5 = 0x05
                           000004   109 	ar4 = 0x04
                           000003   110 	ar3 = 0x03
                           000002   111 	ar2 = 0x02
                           000001   112 	ar1 = 0x01
                           000000   113 	ar0 = 0x00
                                    114 ;	quantum/logging/print.c:23: return 0;
      009C6B 75 82 00         [24]  115 	mov	dpl, #0x00
                                    116 ;	quantum/logging/print.c:24: }
      009C6E 22               [24]  117 	ret
                                    118 ;------------------------------------------------------------
                                    119 ;Allocation info for local variables in function 'print_set_sendchar'
                                    120 ;------------------------------------------------------------
                                    121 ;send          Allocated with name '_print_set_sendchar_send_10000_6'
                                    122 ;------------------------------------------------------------
                                    123 ;	quantum/logging/print.c:27: void print_set_sendchar(sendchar_func_t send) {
                                    124 ;	-----------------------------------------
                                    125 ;	 function print_set_sendchar
                                    126 ;	-----------------------------------------
      009C6F                        127 _print_set_sendchar:
      009C6F 12 3A C2         [24]  128 	lcall	_ak820_outline_0109
      009C72 90 0B D9         [24]  129 	mov	dptr,#_print_set_sendchar_send_10000_6
      009C75 12 3A C7         [24]  130 	lcall	_ak820_outline_0110
                                    131 ;	quantum/logging/print.c:28: func = send;
      009C78 90 0B D9         [24]  132 	mov	dptr,#_print_set_sendchar_send_10000_6
      009C7B 12 3A 81         [24]  133 	lcall	_ak820_outline_0052
      009C7E 90 0E 46         [24]  134 	mov	dptr,#_func
      009C81 12 4A BB         [24]  135 	lcall	_ak820_outline_0060
                                    136 ;	quantum/logging/print.c:29: }
      009C84 22               [24]  137 	ret
                                    138 ;------------------------------------------------------------
                                    139 ;Allocation info for local variables in function 'putchar_'
                                    140 ;------------------------------------------------------------
                                    141 ;character     Allocated with name '_putchar__character_10000_8'
                                    142 ;------------------------------------------------------------
                                    143 ;	quantum/logging/print.c:31: void putchar_(char character) {
                                    144 ;	-----------------------------------------
                                    145 ;	 function putchar_
                                    146 ;	-----------------------------------------
      009C85                        147 _putchar_:
      009C85 E5 82            [12]  148 	mov	a,dpl
      009C87 90 0B DB         [24]  149 	mov	dptr,#_putchar__character_10000_8
      009C8A F0               [24]  150 	movx	@dptr,a
                                    151 ;	quantum/logging/print.c:32: func(character);
      009C8B E0               [24]  152 	movx	a,@dptr
      009C8C FF               [12]  153 	mov	r7,a
      009C8D 90 0E 46         [24]  154 	mov	dptr,#_func
      009C90 E0               [24]  155 	movx	a,@dptr
      009C91 C0 E0            [24]  156 	push	acc
      009C93 A3               [24]  157 	inc	dptr
      009C94 E0               [24]  158 	movx	a,@dptr
      009C95 C0 E0            [24]  159 	push	acc
      009C97 8F 82            [24]  160 	mov	dpl, r7
      009C99 22               [24]  161 	ret
                                    162 ;	quantum/logging/print.c:33: }
      009C9A 22               [24]  163 	ret
                                    164 	.area CSEG    (CODE)
                                    165 	.area CONST   (CODE)
                                    166 	.area XINIT   (CODE)
      00C5BC                        167 __xinit__func:
      00C5BC 6B 9C                  168 	.byte _null_sendchar_func, (_null_sendchar_func >> 8)
                                    169 	.area CABS    (ABS,CODE)
                                    170 
                                    171 ; Experimental exact instruction outlining.
                                    172 	.globl _ak820_outline_0052
                                    173 	.globl _ak820_outline_0060
                                    174 	.globl _ak820_outline_0109
                                    175 	.globl _ak820_outline_0110
