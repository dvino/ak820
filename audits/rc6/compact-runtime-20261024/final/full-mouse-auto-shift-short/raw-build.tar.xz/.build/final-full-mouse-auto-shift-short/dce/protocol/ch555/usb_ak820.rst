                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_287:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_287:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_287:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_287:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00078B                        602 _D0SetupReqCode::
      00078B                        603 	.ds 1
      00078C                        604 _D0SetupLen::
      00078C                        605 	.ds 2
      00078E                        606 _pD0Descr::
      00078E                        607 	.ds 3
      000791                        608 _D0UsbConfig::
      000791                        609 	.ds 1
      000792                        610 _USB_EnumStatus::
      000792                        611 	.ds 1
      000793                        612 _USB_SleepStatus::
      000793                        613 	.ds 1
      000794                        614 _MCU_Sleep_Operate::
      000794                        615 	.ds 1
      000795                        616 _KB_USB_UpStatus::
      000795                        617 	.ds 1
      000796                        618 _KB_USB_SetReport::
      000796                        619 	.ds 1
      000797                        620 _ak820_boot_stage::
      000797                        621 	.ds 1
      000798                        622 _ak820_main_heartbeat::
      000798                        623 	.ds 1
      000799                        624 _raw_state:
      000799                        625 	.ds 1
      00079A                        626 _raw_buffer:
      00079A                        627 	.ds 32
      0007BA                        628 _raw_reply_without_nvm:
      0007BA                        629 	.ds 1
      0007BB                        630 _keyboard_reset:
      0007BB                        631 	.ds 1
      0007BC                        632 _input_snapshot:
      0007BC                        633 	.ds 52
      0007F0                        634 _control_phase:
      0007F0                        635 	.ds 1
      0007F1                        636 _output_kind:
      0007F1                        637 	.ds 1
      0007F2                        638 _output_report_id:
      0007F2                        639 	.ds 1
      0007F3                        640 _control_zlp:
      0007F3                        641 	.ds 1
      0007F4                        642 _control_pointer:
      0007F4                        643 	.ds 2
      0007F6                        644 _descriptor_select_PARM_2:
      0007F6                        645 	.ds 1
      0007F7                        646 _descriptor_select_PARM_3:
      0007F7                        647 	.ds 2
      0007F9                        648 _descriptor_select_type_10000_269:
      0007F9                        649 	.ds 1
      0007FA                        650 _control_setup_length_10000_287:
      0007FA                        651 	.ds 2
      0007FC                        652 _control_setup_offset_10000_287:
      0007FC                        653 	.ds 1
      0007FD                        654 _ak820_usb_send_PARM_2:
      0007FD                        655 	.ds 2
      0007FF                        656 _ak820_usb_send_PARM_3:
      0007FF                        657 	.ds 1
      000800                        658 _ak820_usb_send_endpoint_10000_423:
      000800                        659 	.ds 1
      000801                        660 _ak820_usb_send_offset_10000_424:
      000801                        661 	.ds 1
      000802                        662 _ak820_usb_try_send_PARM_2:
      000802                        663 	.ds 2
      000804                        664 _ak820_usb_try_send_PARM_3:
      000804                        665 	.ds 1
      000805                        666 _ak820_usb_try_send_endpoint_10000_444:
      000805                        667 	.ds 1
      000806                        668 _ak820_usb_try_send_sent_10000_445:
      000806                        669 	.ds 1
      000807                        670 _ak820_usb_raw_send_PARM_2:
      000807                        671 	.ds 1
      000808                        672 _ak820_usb_raw_send_report_10000_460:
      000808                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005EE7                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005EE7 90 07 99         [24]  727 	mov	dptr,#_raw_state
      005EEA E0               [24]  728 	movx	a,@dptr
      005EEB FF               [12]  729 	mov	r7,a
      005EEC BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005EEF 80 1C            [24]  731 	sjmp	00101$
      005EF1                        732 00130$:
      005EF1 90 07 99         [24]  733 	mov	dptr,#_raw_state
      005EF4 E0               [24]  734 	movx	a,@dptr
      005EF5 FF               [12]  735 	mov	r7,a
      005EF6 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005EF9 80 12            [24]  737 	sjmp	00101$
      005EFB                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005EFB 90 07 99         [24]  740 	mov	dptr,#_raw_state
      005EFE E0               [24]  741 	movx	a,@dptr
      005EFF FF               [12]  742 	mov	r7,a
      005F00 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005F03 80 08            [24]  744 	sjmp	00101$
      005F05                        745 00132$:
      005F05 90 07 99         [24]  746 	mov	dptr,#_raw_state
      005F08 E0               [24]  747 	movx	a,@dptr
      005F09 FF               [12]  748 	mov	r7,a
      005F0A BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005F0D                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005F0D 90 07 99         [24]  752 	mov	dptr,#_raw_state
      005F10 74 07            [12]  753 	mov	a,#0x07
      005F12 F0               [24]  754 	movx	@dptr,a
      005F13 80 05            [24]  755 	sjmp	00103$
      005F15                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005F15 90 07 99         [24]  758 	mov	dptr,#_raw_state
      005F18 E4               [12]  759 	clr	a
      005F19 F0               [24]  760 	movx	@dptr,a
      005F1A                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005F1A 90 07 F1         [24]  763 	mov	dptr,#_output_kind
      005F1D E4               [12]  764 	clr	a
      005F1E F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005F1F 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005F20                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005F20 90 07 99         [24]  777 	mov	dptr,#_raw_state
      005F23 E0               [24]  778 	movx	a,@dptr
      005F24 FF               [12]  779 	mov	r7,a
      005F25 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005F28 90 07 99         [24]  781 	mov	dptr,#_raw_state
      005F2B 74 06            [12]  782 	mov	a,#0x06
      005F2D F0               [24]  783 	movx	@dptr,a
      005F2E 22               [24]  784 	ret
      005F2F                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005F2F 90 07 99         [24]  787 	mov	dptr,#_raw_state
      005F32 E0               [24]  788 	movx	a,@dptr
      005F33 FF               [12]  789 	mov	r7,a
      005F34 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005F37 90 07 99         [24]  791 	mov	dptr,#_raw_state
      005F3A E4               [12]  792 	clr	a
      005F3B F0               [24]  793 	movx	@dptr,a
      005F3C                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005F3C 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005F3D                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005F3D 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005F40 74 01            [12]  809 	mov	a,#0x01
      005F42 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F43 F5 82            [12]  812 	mov	dpl,a
      005F45 74 12            [12]  813 	mov	a,#0x12
      005F47 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F48 A3               [24]  816 	inc	dptr
      005F49 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F4A A3               [24]  819 	inc	dptr
      005F4B F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005F4C 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005F4F E4               [12]  823 	clr	a
      005F50 F0               [24]  824 	movx	@dptr,a
      005F51 15 82            [12]  825 	dec	dpl
      005F53 F0               [24]  826 	movx	@dptr,a
      005F54 15 82            [12]  827 	dec	dpl
      005F56 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005F57 FF               [12]  830 	mov	r7,a
      005F58                        831 00103$:
      005F58 EF               [12]  832 	mov	a,r7
      005F59 24 BC            [12]  833 	add	a, #_input_snapshot
      005F5B F5 82            [12]  834 	mov	dpl,a
      005F5D E4               [12]  835 	clr	a
      005F5E 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005F60 F5 83            [12]  837 	mov	dph,a
      005F62 E4               [12]  838 	clr	a
      005F63 F0               [24]  839 	movx	@dptr,a
      005F64 0F               [12]  840 	inc	r7
      005F65 BF 34 00         [24]  841 	cjne	r7,#0x34,00139$
      005F68                        842 00139$:
      005F68 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005F6A 90 07 C4         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005F6D 74 06            [12]  846 	mov	a,#0x06
      005F6F F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:118: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005F70 90 07 E4         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005F73 74 02            [12]  850 	mov	a,#0x02
      005F75 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005F76 90 07 EA         [24]  853 	mov	dptr,#(_input_snapshot + 0x002e)
      005F79 04               [12]  854 	inc	a
      005F7A F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005F7B 90 07 ED         [24]  857 	mov	dptr,#(_input_snapshot + 0x0031)
      005F7E 04               [12]  858 	inc	a
      005F7F F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005F80 7F 00            [12]  861 	mov	r7,#0x00
      005F82                        862 00105$:
      005F82 8F 06            [24]  863 	mov	ar6,r7
      005F84 74 C0            [12]  864 	mov	a,#0xc0
      005F86 2E               [12]  865 	add	a, r6
      005F87 F5 82            [12]  866 	mov	dpl,a
      005F89 74 10            [12]  867 	mov	a,#0x10
      005F8B 24 00            [12]  868 	add	a, #0x00
      005F8D F5 83            [12]  869 	mov	dph,a
      005F8F E4               [12]  870 	clr	a
      005F90 F0               [24]  871 	movx	@dptr,a
      005F91 0F               [12]  872 	inc	r7
      005F92 BF 20 00         [24]  873 	cjne	r7,#0x20,00141$
      005F95                        874 00141$:
      005F95 40 EB            [24]  875 	jc	00105$
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    877 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005F97 02 5E E7         [24]  878 	ljmp	_raw_abort
                                    879 ;------------------------------------------------------------
                                    880 ;Allocation info for local variables in function 'control_stall'
                                    881 ;------------------------------------------------------------
                                    882 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function control_stall
                                    885 ;	-----------------------------------------
      005F9A                        886 _control_stall:
                                    887 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005F9A 90 07 99         [24]  888 	mov	dptr,#_raw_state
      005F9D E0               [24]  889 	movx	a,@dptr
      005F9E FF               [12]  890 	mov	r7,a
      005F9F BF 01 05         [24]  891 	cjne	r7,#0x01,00102$
      005FA2 90 07 99         [24]  892 	mov	dptr,#_raw_state
      005FA5 E4               [12]  893 	clr	a
      005FA6 F0               [24]  894 	movx	@dptr,a
      005FA7                        895 00102$:
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005FA7 90 07 F1         [24]  897 	mov	dptr,#_output_kind
      005FAA E4               [12]  898 	clr	a
      005FAB F0               [24]  899 	movx	@dptr,a
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005FAC 90 07 F0         [24]  901 	mov	dptr,#_control_phase
      005FAF F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005FB0 90 07 8B         [24]  904 	mov	dptr,#_D0SetupReqCode
      005FB3 14               [12]  905 	dec	a
      005FB4 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005FB5 90 22 00         [24]  908 	mov	dptr,#0x2200
      005FB8 74 CF            [12]  909 	mov	a,#0xcf
      005FBA F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005FBB 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'control_next'
                                    915 ;------------------------------------------------------------
                                    916 ;i             Allocated with name '_control_next_i_10000_266'
                                    917 ;length        Allocated with name '_control_next_length_10000_266'
                                    918 ;------------------------------------------------------------
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    920 ;	-----------------------------------------
                                    921 ;	 function control_next
                                    922 ;	-----------------------------------------
      005FBC                        923 _control_next:
                                    924 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005FBC 90 07 8C         [24]  925 	mov	dptr,#_D0SetupLen
      005FBF E0               [24]  926 	movx	a,@dptr
      005FC0 FE               [12]  927 	mov	r6,a
      005FC1 A3               [24]  928 	inc	dptr
      005FC2 E0               [24]  929 	movx	a,@dptr
      005FC3 FF               [12]  930 	mov	r7,a
      005FC4 C3               [12]  931 	clr	c
      005FC5 74 40            [12]  932 	mov	a,#0x40
      005FC7 9E               [12]  933 	subb	a,r6
      005FC8 E4               [12]  934 	clr	a
      005FC9 9F               [12]  935 	subb	a,r7
      005FCA 50 04            [24]  936 	jnc	00109$
                                    937 ;	free result
      005FCC 7E 40            [12]  938 	mov	r6,#0x40
      005FCE 80 07            [24]  939 	sjmp	00110$
      005FD0                        940 00109$:
      005FD0 90 07 8C         [24]  941 	mov	dptr,#_D0SetupLen
      005FD3 E0               [24]  942 	movx	a,@dptr
      005FD4 FE               [12]  943 	mov	r6,a
      005FD5 A3               [24]  944 	inc	dptr
      005FD6 E0               [24]  945 	movx	a,@dptr
      005FD7                        946 00110$:
                                    947 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005FD7 7F 00            [12]  948 	mov	r7,#0x00
      005FD9                        949 00105$:
      005FD9 C3               [12]  950 	clr	c
      005FDA EF               [12]  951 	mov	a,r7
      005FDB 9E               [12]  952 	subb	a,r6
      005FDC 50 2A            [24]  953 	jnc	00101$
      005FDE 8F 04            [24]  954 	mov	ar4,r7
      005FE0 74 10            [12]  955 	mov	a,#0x10
      005FE2 24 00            [12]  956 	add	a, #0x00
      005FE4 FD               [12]  957 	mov	r5,a
      005FE5 90 07 F4         [24]  958 	mov	dptr,#_control_pointer
      005FE8 E0               [24]  959 	movx	a,@dptr
      005FE9 FA               [12]  960 	mov	r2,a
      005FEA A3               [24]  961 	inc	dptr
      005FEB E0               [24]  962 	movx	a,@dptr
      005FEC FB               [12]  963 	mov	r3,a
      005FED 8A 82            [24]  964 	mov	dpl,r2
      005FEF 8B 83            [24]  965 	mov	dph,r3
      005FF1 E4               [12]  966 	clr	a
      005FF2 93               [24]  967 	movc	a,@a+dptr
      005FF3 F9               [12]  968 	mov	r1,a
      005FF4 90 07 F4         [24]  969 	mov	dptr,#_control_pointer
      005FF7 74 01            [12]  970 	mov	a,#0x01
      005FF9 2A               [12]  971 	add	a, r2
      005FFA F0               [24]  972 	movx	@dptr,a
      005FFB E4               [12]  973 	clr	a
      005FFC 3B               [12]  974 	addc	a, r3
      005FFD A3               [24]  975 	inc	dptr
      005FFE F0               [24]  976 	movx	@dptr,a
      005FFF 8C 82            [24]  977 	mov	dpl,r4
      006001 8D 83            [24]  978 	mov	dph,r5
      006003 E9               [12]  979 	mov	a,r1
      006004 F0               [24]  980 	movx	@dptr,a
      006005 0F               [12]  981 	inc	r7
      006006 80 D1            [24]  982 	sjmp	00105$
      006008                        983 00101$:
                                    984 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      006008 8E 05            [24]  985 	mov	ar5,r6
      00600A 7F 00            [12]  986 	mov	r7,#0x00
      00600C 90 07 8C         [24]  987 	mov	dptr,#_D0SetupLen
      00600F E0               [24]  988 	movx	a,@dptr
      006010 FB               [12]  989 	mov	r3,a
      006011 A3               [24]  990 	inc	dptr
      006012 E0               [24]  991 	movx	a,@dptr
      006013 FC               [12]  992 	mov	r4,a
      006014 EB               [12]  993 	mov	a,r3
      006015 C3               [12]  994 	clr	c
      006016 9D               [12]  995 	subb	a,r5
      006017 FB               [12]  996 	mov	r3,a
      006018 EC               [12]  997 	mov	a,r4
      006019 9F               [12]  998 	subb	a,r7
      00601A FC               [12]  999 	mov	r4,a
      00601B 90 07 8C         [24] 1000 	mov	dptr,#_D0SetupLen
      00601E EB               [12] 1001 	mov	a,r3
      00601F F0               [24] 1002 	movx	@dptr,a
      006020 EC               [12] 1003 	mov	a,r4
      006021 A3               [24] 1004 	inc	dptr
      006022 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      006023 EE               [12] 1007 	mov	a,r6
      006024 70 05            [24] 1008 	jnz	00103$
      006026 90 07 F3         [24] 1009 	mov	dptr,#_control_zlp
      006029 E4               [12] 1010 	clr	a
      00602A F0               [24] 1011 	movx	@dptr,a
      00602B                       1012 00103$:
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      00602B 90 22 08         [24] 1014 	mov	dptr,#0x2208
      00602E EE               [12] 1015 	mov	a,r6
      00602F F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      006030 90 22 00         [24] 1018 	mov	dptr,#0x2200
      006033 E0               [24] 1019 	movx	a,@dptr
      006034 54 C0            [12] 1020 	anl	a,#0xc0
      006036 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      006037 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'descriptor_select'
                                   1026 ;------------------------------------------------------------
                                   1027 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1028 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1029 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1030 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function descriptor_select
                                   1035 ;	-----------------------------------------
      006038                       1036 _descriptor_select:
      006038 E5 82            [12] 1037 	mov	a,dpl
      00603A 90 07 F9         [24] 1038 	mov	dptr,#_descriptor_select_type_10000_269
      00603D F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      00603E E0               [24] 1041 	movx	a,@dptr
      00603F FF               [12] 1042 	mov	r7,a
      006040 BF 01 20         [24] 1043 	cjne	r7,#0x01,00102$
      006043 90 07 F6         [24] 1044 	mov	dptr,#_descriptor_select_PARM_2
      006046 E0               [24] 1045 	movx	a,@dptr
      006047 70 1A            [24] 1046 	jnz	00102$
      006049 90 07 F7         [24] 1047 	mov	dptr,#_descriptor_select_PARM_3
      00604C E0               [24] 1048 	movx	a,@dptr
      00604D F5 F0            [12] 1049 	mov	b,a
      00604F A3               [24] 1050 	inc	dptr
      006050 E0               [24] 1051 	movx	a,@dptr
      006051 45 F0            [12] 1052 	orl	a,b
      006053 70 0E            [24] 1053 	jnz	00102$
                                   1054 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      006055 90 07 F4         [24] 1055 	mov	dptr,#_control_pointer
      006058 74 9B            [12] 1056 	mov	a,#_DeviceDescriptor
      00605A F0               [24] 1057 	movx	@dptr,a
      00605B 74 C4            [12] 1058 	mov	a,#(_DeviceDescriptor >> 8)
      00605D A3               [24] 1059 	inc	dptr
      00605E F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      00605F 90 00 12         [24] 1062 	mov	dptr,#0x0012
      006062 22               [24] 1063 	ret
      006063                       1064 00102$:
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      006063 90 07 F9         [24] 1066 	mov	dptr,#_descriptor_select_type_10000_269
      006066 E0               [24] 1067 	movx	a,@dptr
      006067 FF               [12] 1068 	mov	r7,a
      006068 BF 02 20         [24] 1069 	cjne	r7,#0x02,00106$
      00606B 90 07 F6         [24] 1070 	mov	dptr,#_descriptor_select_PARM_2
      00606E E0               [24] 1071 	movx	a,@dptr
      00606F 70 1A            [24] 1072 	jnz	00106$
      006071 90 07 F7         [24] 1073 	mov	dptr,#_descriptor_select_PARM_3
      006074 E0               [24] 1074 	movx	a,@dptr
      006075 F5 F0            [12] 1075 	mov	b,a
      006077 A3               [24] 1076 	inc	dptr
      006078 E0               [24] 1077 	movx	a,@dptr
      006079 45 F0            [12] 1078 	orl	a,b
      00607B 70 0E            [24] 1079 	jnz	00106$
                                   1080 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      00607D 90 07 F4         [24] 1081 	mov	dptr,#_control_pointer
      006080 74 AD            [12] 1082 	mov	a,#_ConfigurationDescriptor
      006082 F0               [24] 1083 	movx	@dptr,a
      006083 74 C4            [12] 1084 	mov	a,#(_ConfigurationDescriptor >> 8)
      006085 A3               [24] 1085 	inc	dptr
      006086 F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      006087 90 00 54         [24] 1088 	mov	dptr,#0x0054
      00608A 22               [24] 1089 	ret
      00608B                       1090 00106$:
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      00608B 90 07 F9         [24] 1092 	mov	dptr,#_descriptor_select_type_10000_269
      00608E E0               [24] 1093 	movx	a,@dptr
      00608F FF               [12] 1094 	mov	r7,a
      006090 BF 03 02         [24] 1095 	cjne	r7,#0x03,00238$
      006093 80 03            [24] 1096 	sjmp	00239$
      006095                       1097 00238$:
      006095 02 61 2F         [24] 1098 	ljmp	00119$
      006098                       1099 00239$:
                                   1100 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      006098 90 07 F7         [24] 1101 	mov	dptr,#_descriptor_select_PARM_3
      00609B E0               [24] 1102 	movx	a,@dptr
      00609C FD               [12] 1103 	mov	r5,a
      00609D A3               [24] 1104 	inc	dptr
      00609E E0               [24] 1105 	movx	a,@dptr
      00609F FE               [12] 1106 	mov	r6,a
      0060A0 90 07 F7         [24] 1107 	mov	dptr,#_descriptor_select_PARM_3
      0060A3 E0               [24] 1108 	movx	a,@dptr
      0060A4 F5 F0            [12] 1109 	mov	b,a
      0060A6 A3               [24] 1110 	inc	dptr
      0060A7 E0               [24] 1111 	movx	a,@dptr
      0060A8 45 F0            [12] 1112 	orl	a,b
      0060AA 60 0C            [24] 1113 	jz	00110$
      0060AC BD 09 05         [24] 1114 	cjne	r5,#0x09,00241$
      0060AF BE 04 02         [24] 1115 	cjne	r6,#0x04,00241$
      0060B2 80 04            [24] 1116 	sjmp	00110$
      0060B4                       1117 00241$:
      0060B4 90 00 00         [24] 1118 	mov	dptr,#0x0000
      0060B7 22               [24] 1119 	ret
      0060B8                       1120 00110$:
                                   1121 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      0060B8 90 07 F6         [24] 1122 	mov	dptr,#_descriptor_select_PARM_2
      0060BB E0               [24] 1123 	movx	a,@dptr
      0060BC FE               [12] 1124 	mov  r6,a
      0060BD 24 FC            [12] 1125 	add	a,#0xff - 0x03
      0060BF 40 6A            [24] 1126 	jc	00116$
                                   1127 ;	free result
      0060C1 EE               [12] 1128 	mov	a,r6
      0060C2 2E               [12] 1129 	add	a,r6
                                   1130 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      0060C3 90 60 C7         [24] 1131 	mov	dptr,#00243$
      0060C6 73               [24] 1132 	jmp	@a+dptr
      0060C7                       1133 00243$:
      0060C7 80 06            [24] 1134 	sjmp	00112$
      0060C9 80 1B            [24] 1135 	sjmp	00113$
      0060CB 80 30            [24] 1136 	sjmp	00114$
      0060CD 80 45            [24] 1137 	sjmp	00115$
      0060CF                       1138 00112$:
      0060CF 90 07 F4         [24] 1139 	mov	dptr,#_control_pointer
      0060D2 74 01            [12] 1140 	mov	a,#_LanguageString
      0060D4 F0               [24] 1141 	movx	@dptr,a
      0060D5 74 C5            [12] 1142 	mov	a,#(_LanguageString >> 8)
      0060D7 A3               [24] 1143 	inc	dptr
      0060D8 F0               [24] 1144 	movx	@dptr,a
      0060D9 90 C5 01         [24] 1145 	mov	dptr,#_LanguageString
      0060DC E4               [12] 1146 	clr	a
      0060DD 93               [24] 1147 	movc	a,@a+dptr
      0060DE FE               [12] 1148 	mov	r6,a
      0060DF 7D 00            [12] 1149 	mov	r5,#0x00
      0060E1 8E 82            [24] 1150 	mov	dpl, r6
      0060E3 8D 83            [24] 1151 	mov	dph, r5
      0060E5 22               [24] 1152 	ret
                                   1153 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0060E6                       1154 00113$:
      0060E6 90 07 F4         [24] 1155 	mov	dptr,#_control_pointer
      0060E9 74 05            [12] 1156 	mov	a,#_ManufacturerString
      0060EB F0               [24] 1157 	movx	@dptr,a
      0060EC 74 C5            [12] 1158 	mov	a,#(_ManufacturerString >> 8)
      0060EE A3               [24] 1159 	inc	dptr
      0060EF F0               [24] 1160 	movx	@dptr,a
      0060F0 90 C5 05         [24] 1161 	mov	dptr,#_ManufacturerString
      0060F3 E4               [12] 1162 	clr	a
      0060F4 93               [24] 1163 	movc	a,@a+dptr
      0060F5 FE               [12] 1164 	mov	r6,a
      0060F6 7D 00            [12] 1165 	mov	r5,#0x00
      0060F8 8E 82            [24] 1166 	mov	dpl, r6
      0060FA 8D 83            [24] 1167 	mov	dph, r5
      0060FC 22               [24] 1168 	ret
                                   1169 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0060FD                       1170 00114$:
      0060FD 90 07 F4         [24] 1171 	mov	dptr,#_control_pointer
      006100 74 13            [12] 1172 	mov	a,#_ProductString
      006102 F0               [24] 1173 	movx	@dptr,a
      006103 74 C5            [12] 1174 	mov	a,#(_ProductString >> 8)
      006105 A3               [24] 1175 	inc	dptr
      006106 F0               [24] 1176 	movx	@dptr,a
      006107 90 C5 13         [24] 1177 	mov	dptr,#_ProductString
      00610A E4               [12] 1178 	clr	a
      00610B 93               [24] 1179 	movc	a,@a+dptr
      00610C FE               [12] 1180 	mov	r6,a
      00610D 7D 00            [12] 1181 	mov	r5,#0x00
      00610F 8E 82            [24] 1182 	mov	dpl, r6
      006111 8D 83            [24] 1183 	mov	dph, r5
      006113 22               [24] 1184 	ret
                                   1185 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      006114                       1186 00115$:
      006114 90 07 F4         [24] 1187 	mov	dptr,#_control_pointer
      006117 74 4B            [12] 1188 	mov	a,#_SerialNumberString
      006119 F0               [24] 1189 	movx	@dptr,a
      00611A 74 C5            [12] 1190 	mov	a,#(_SerialNumberString >> 8)
      00611C A3               [24] 1191 	inc	dptr
      00611D F0               [24] 1192 	movx	@dptr,a
      00611E 90 C5 4B         [24] 1193 	mov	dptr,#_SerialNumberString
      006121 E4               [12] 1194 	clr	a
      006122 93               [24] 1195 	movc	a,@a+dptr
      006123 FE               [12] 1196 	mov	r6,a
      006124 7D 00            [12] 1197 	mov	r5,#0x00
      006126 8E 82            [24] 1198 	mov	dpl, r6
      006128 8D 83            [24] 1199 	mov	dph, r5
      00612A 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      00612B                       1202 00116$:
      00612B 90 00 00         [24] 1203 	mov	dptr,#0x0000
      00612E 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      00612F                       1206 00119$:
                                   1207 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      00612F 90 07 F6         [24] 1208 	mov	dptr,#_descriptor_select_PARM_2
      006132 E0               [24] 1209 	movx	a,@dptr
      006133 70 11            [24] 1210 	jnz	00120$
      006135 90 07 F7         [24] 1211 	mov	dptr,#_descriptor_select_PARM_3
      006138 E0               [24] 1212 	movx	a,@dptr
      006139 FD               [12] 1213 	mov	r5,a
      00613A A3               [24] 1214 	inc	dptr
      00613B E0               [24] 1215 	movx	a,@dptr
      00613C FE               [12] 1216 	mov	r6,a
      00613D C3               [12] 1217 	clr	c
      00613E ED               [12] 1218 	mov	a,r5
      00613F 94 03            [12] 1219 	subb	a,#0x03
      006141 EE               [12] 1220 	mov	a,r6
      006142 94 00            [12] 1221 	subb	a,#0x00
      006144 40 04            [24] 1222 	jc	00121$
      006146                       1223 00120$:
      006146 90 00 00         [24] 1224 	mov	dptr,#0x0000
      006149 22               [24] 1225 	ret
      00614A                       1226 00121$:
                                   1227 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      00614A BF 22 02         [24] 1228 	cjne	r7,#0x22,00246$
      00614D 80 03            [24] 1229 	sjmp	00127$
      00614F                       1230 00246$:
      00614F BF 21 5D         [24] 1231 	cjne	r7,#0x21,00128$
      006152                       1232 00127$:
                                   1233 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      006152 ED               [12] 1234 	mov	a,r5
      006153 75 F0 04         [24] 1235 	mov	b,#0x04
      006156 A4               [48] 1236 	mul	ab
      006157 24 D3            [12] 1237 	add	a, #_interface_descriptors
      006159 FE               [12] 1238 	mov	r6,a
      00615A 74 BD            [12] 1239 	mov	a,#(_interface_descriptors >> 8)
      00615C 35 F0            [12] 1240 	addc	a, b
      00615E FF               [12] 1241 	mov	r7,a
      00615F 8E 82            [24] 1242 	mov	dpl,r6
      006161 8F 83            [24] 1243 	mov	dph,r7
      006163 A3               [24] 1244 	inc	dptr
      006164 A3               [24] 1245 	inc	dptr
      006165 E4               [12] 1246 	clr	a
      006166 93               [24] 1247 	movc	a,@a+dptr
      006167 FC               [12] 1248 	mov	r4,a
      006168 A3               [24] 1249 	inc	dptr
      006169 E4               [12] 1250 	clr	a
      00616A 93               [24] 1251 	movc	a,@a+dptr
                                   1252 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      00616B FD               [12] 1253 	mov	r5,a
      00616C 4C               [12] 1254 	orl	a,r4
      00616D 70 04            [24] 1255 	jnz	00124$
      00616F 90 00 00         [24] 1256 	mov	dptr,#0x0000
      006172 22               [24] 1257 	ret
      006173                       1258 00124$:
                                   1259 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      006173 90 07 F9         [24] 1260 	mov	dptr,#_descriptor_select_type_10000_269
      006176 E0               [24] 1261 	movx	a,@dptr
      006177 FB               [12] 1262 	mov	r3,a
      006178 BB 22 28         [24] 1263 	cjne	r3,#0x22,00126$
                                   1264 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      00617B 8E 82            [24] 1265 	mov	dpl,r6
      00617D 8F 83            [24] 1266 	mov	dph,r7
      00617F E4               [12] 1267 	clr	a
      006180 93               [24] 1268 	movc	a,@a+dptr
      006181 FE               [12] 1269 	mov	r6,a
      006182 A3               [24] 1270 	inc	dptr
      006183 E4               [12] 1271 	clr	a
      006184 93               [24] 1272 	movc	a,@a+dptr
      006185 FF               [12] 1273 	mov	r7,a
      006186 90 07 F4         [24] 1274 	mov	dptr,#_control_pointer
      006189 EE               [12] 1275 	mov	a,r6
      00618A F0               [24] 1276 	movx	@dptr,a
      00618B EF               [12] 1277 	mov	a,r7
      00618C A3               [24] 1278 	inc	dptr
      00618D F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      00618E 74 07            [12] 1281 	mov	a,#0x07
      006190 2C               [12] 1282 	add	a, r4
      006191 F5 82            [12] 1283 	mov	dpl,a
      006193 E4               [12] 1284 	clr	a
      006194 3D               [12] 1285 	addc	a, r5
      006195 F5 83            [12] 1286 	mov	dph,a
      006197 E4               [12] 1287 	clr	a
      006198 93               [24] 1288 	movc	a,@a+dptr
      006199 FE               [12] 1289 	mov	r6,a
      00619A A3               [24] 1290 	inc	dptr
      00619B E4               [12] 1291 	clr	a
      00619C 93               [24] 1292 	movc	a,@a+dptr
      00619D FF               [12] 1293 	mov	r7,a
      00619E 8E 82            [24] 1294 	mov	dpl, r6
      0061A0 8F 83            [24] 1295 	mov	dph, r7
      0061A2 22               [24] 1296 	ret
      0061A3                       1297 00126$:
                                   1298 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      0061A3 90 07 F4         [24] 1299 	mov	dptr,#_control_pointer
      0061A6 EC               [12] 1300 	mov	a,r4
      0061A7 F0               [24] 1301 	movx	@dptr,a
      0061A8 ED               [12] 1302 	mov	a,r5
      0061A9 A3               [24] 1303 	inc	dptr
      0061AA F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      0061AB 90 00 09         [24] 1306 	mov	dptr,#0x0009
      0061AE 22               [24] 1307 	ret
      0061AF                       1308 00128$:
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      0061AF 90 00 00         [24] 1310 	mov	dptr,#0x0000
                                   1311 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      0061B2 22               [24] 1312 	ret
                                   1313 ;------------------------------------------------------------
                                   1314 ;Allocation info for local variables in function 'control_setup'
                                   1315 ;------------------------------------------------------------
                                   1316 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1317 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1318 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1319 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1320 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1321 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1322 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1323 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1324 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1325 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1326 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1327 ;------------------------------------------------------------
                                   1328 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1329 ;	-----------------------------------------
                                   1330 ;	 function control_setup
                                   1331 ;	-----------------------------------------
      0061B3                       1332 _control_setup:
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      0061B3 90 10 00         [24] 1334 	mov	dptr,#0x1000
      0061B6 E0               [24] 1335 	movx	a,@dptr
      0061B7 FF               [12] 1336 	mov	r7,a
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      0061B8 A3               [24] 1338 	inc	dptr
      0061B9 A3               [24] 1339 	inc	dptr
      0061BA E0               [24] 1340 	movx	a,@dptr
      0061BB FE               [12] 1341 	mov	r6,a
      0061BC A3               [24] 1342 	inc	dptr
      0061BD E0               [24] 1343 	movx	a,@dptr
      0061BE FC               [12] 1344 	mov	r4,a
      0061BF 7D 00            [12] 1345 	mov	r5,#0x00
      0061C1 8E 03            [24] 1346 	mov	ar3,r6
      0061C3 7E 00            [12] 1347 	mov	r6,#0x00
      0061C5 ED               [12] 1348 	mov	a,r5
      0061C6 4B               [12] 1349 	orl	a,r3
      0061C7 FD               [12] 1350 	mov	r5,a
      0061C8 EC               [12] 1351 	mov	a,r4
      0061C9 4E               [12] 1352 	orl	a,r6
      0061CA FE               [12] 1353 	mov	r6,a
                                   1354 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0061CB A3               [24] 1355 	inc	dptr
      0061CC E0               [24] 1356 	movx	a,@dptr
      0061CD FC               [12] 1357 	mov	r4,a
      0061CE A3               [24] 1358 	inc	dptr
      0061CF E0               [24] 1359 	movx	a,@dptr
      0061D0 FA               [12] 1360 	mov	r2,a
      0061D1 7B 00            [12] 1361 	mov	r3,#0x00
      0061D3 8C 01            [24] 1362 	mov	ar1,r4
      0061D5 7C 00            [12] 1363 	mov	r4,#0x00
      0061D7 EB               [12] 1364 	mov	a,r3
      0061D8 49               [12] 1365 	orl	a,r1
      0061D9 FB               [12] 1366 	mov	r3,a
      0061DA EA               [12] 1367 	mov	a,r2
      0061DB 4C               [12] 1368 	orl	a,r4
      0061DC FC               [12] 1369 	mov	r4,a
                                   1370 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      0061DD C3               [12] 1371 	clr	c
      0061DE EB               [12] 1372 	mov	a,r3
      0061DF 94 03            [12] 1373 	subb	a,#0x03
      0061E1 EC               [12] 1374 	mov	a,r4
      0061E2 94 00            [12] 1375 	subb	a,#0x00
      0061E4 92 17            [24] 1376 	mov	_control_setup_valid_interface_10000_287,c
                                   1377 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      0061E6 EB               [12] 1378 	mov	a,r3
      0061E7 4C               [12] 1379 	orl	a,r4
      0061E8 B4 01 00         [24] 1380 	cjne	a,#0x01,01201$
      0061EB                       1381 01201$:
      0061EB 92 18            [24] 1382 	mov	_control_setup_zero_index_10000_287,c
                                   1383 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      0061ED ED               [12] 1384 	mov	a,r5
      0061EE 4E               [12] 1385 	orl	a,r6
      0061EF B4 01 00         [24] 1386 	cjne	a,#0x01,01202$
      0061F2                       1387 01202$:
                                   1388 ;	assignBit
      0061F2 92 1B            [24] 1389 	mov  _control_setup_sloc0_1_0,c
      0061F4 92 19            [24] 1390 	mov	_control_setup_zero_value_10000_287,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      0061F6 90 07 FC         [24] 1392 	mov	dptr,#_control_setup_offset_10000_287
      0061F9 E4               [12] 1393 	clr	a
      0061FA F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0061FB 90 07 99         [24] 1396 	mov	dptr,#_raw_state
      0061FE E0               [24] 1397 	movx	a,@dptr
      0061FF FA               [12] 1398 	mov	r2,a
      006200 BA 01 05         [24] 1399 	cjne	r2,#0x01,00102$
      006203 90 07 99         [24] 1400 	mov	dptr,#_raw_state
      006206 E4               [12] 1401 	clr	a
      006207 F0               [24] 1402 	movx	@dptr,a
      006208                       1403 00102$:
                                   1404 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      006208 C0 07            [24] 1405 	push	ar7
      00620A 90 07 F1         [24] 1406 	mov	dptr,#_output_kind
      00620D E4               [12] 1407 	clr	a
      00620E F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      00620F 90 07 F0         [24] 1410 	mov	dptr,#_control_phase
      006212 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      006213 90 07 F3         [24] 1413 	mov	dptr,#_control_zlp
      006216 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006217 90 10 01         [24] 1416 	mov	dptr,#0x1001
      00621A E0               [24] 1417 	movx	a,@dptr
      00621B 90 07 8B         [24] 1418 	mov	dptr,#_D0SetupReqCode
      00621E F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00621F 90 10 06         [24] 1421 	mov	dptr,#0x1006
      006222 E0               [24] 1422 	movx	a,@dptr
      006223 FA               [12] 1423 	mov	r2,a
      006224 A3               [24] 1424 	inc	dptr
      006225 E0               [24] 1425 	movx	a,@dptr
      006226 F9               [12] 1426 	mov	r1,a
      006227 78 00            [12] 1427 	mov	r0,#0x00
      006229 7F 00            [12] 1428 	mov	r7,#0x00
      00622B 90 07 8C         [24] 1429 	mov	dptr,#_D0SetupLen
      00622E E8               [12] 1430 	mov	a,r0
      00622F 4A               [12] 1431 	orl	a,r2
      006230 F0               [24] 1432 	movx	@dptr,a
      006231 E9               [12] 1433 	mov	a,r1
      006232 4F               [12] 1434 	orl	a,r7
      006233 A3               [24] 1435 	inc	dptr
      006234 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      006235 90 07 8C         [24] 1438 	mov	dptr,#_D0SetupLen
      006238 E0               [24] 1439 	movx	a,@dptr
      006239 FA               [12] 1440 	mov	r2,a
      00623A A3               [24] 1441 	inc	dptr
      00623B E0               [24] 1442 	movx	a,@dptr
      00623C 4A               [12] 1443 	orl	a,r2
      00623D B4 01 00         [24] 1444 	cjne	a,#0x01,01205$
      006240                       1445 01205$:
      006240 92 1A            [24] 1446 	mov	_control_setup_zero_length_10000_287,c
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006242 90 22 00         [24] 1448 	mov	dptr,#0x2200
      006245 74 C2            [12] 1449 	mov	a,#0xc2
      006247 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      006248 90 22 08         [24] 1452 	mov	dptr,#0x2208
      00624B E4               [12] 1453 	clr	a
      00624C F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      00624D 90 07 8B         [24] 1456 	mov	dptr,#_D0SetupReqCode
      006250 E0               [24] 1457 	movx	a,@dptr
      006251 F5 16            [12] 1458 	mov	_control_setup_sloc1_1_0,a
      006253 C3               [12] 1459 	clr	c
      006254 74 0B            [12] 1460 	mov	a,#0x0b
      006256 95 16            [12] 1461 	subb	a,_control_setup_sloc1_1_0
      006258 D0 07            [24] 1462 	pop	ar7
      00625A 50 03            [24] 1463 	jnc	01206$
      00625C 02 5F 9A         [24] 1464 	ljmp	_control_stall
      00625F                       1465 01206$:
                                   1466 ;	free result
      00625F E5 16            [12] 1467 	mov	a,_control_setup_sloc1_1_0
      006261 F5 F0            [12] 1468 	mov	b,a
      006263 24 0B            [12] 1469 	add	a,#(01207$-3-.)
      006265 83               [24] 1470 	movc	a,@a+pc
      006266 F5 82            [12] 1471 	mov	dpl,a
      006268 E5 F0            [12] 1472 	mov	a,b
      00626A 24 10            [12] 1473 	add	a,#(01208$-3-.)
      00626C 83               [24] 1474 	movc	a,@a+pc
      00626D F5 83            [12] 1475 	mov	dph,a
      00626F E4               [12] 1476 	clr	a
      006270 73               [24] 1477 	jmp	@a+dptr
      006271                       1478 01207$:
      006271 19                    1479 	.db	00188$
      006272 BF                    1480 	.db	00205$
      006273 02                    1481 	.db	00282$
      006274 BF                    1482 	.db	00205$
      006275 46                    1483 	.db	00290$
      006276 43                    1484 	.db	00116$
      006277 89                    1485 	.db	00103$
      006278 46                    1486 	.db	00290$
      006279 48                    1487 	.db	00150$
      00627A 6C                    1488 	.db	00123$
      00627B 78                    1489 	.db	00157$
      00627C CB                    1490 	.db	00173$
      00627D                       1491 01208$:
      00627D 65                    1492 	.db	00188$>>8
      00627E 65                    1493 	.db	00205$>>8
      00627F 69                    1494 	.db	00282$>>8
      006280 65                    1495 	.db	00205$>>8
      006281 69                    1496 	.db	00290$>>8
      006282 63                    1497 	.db	00116$>>8
      006283 62                    1498 	.db	00103$>>8
      006284 69                    1499 	.db	00290$>>8
      006285 64                    1500 	.db	00150$>>8
      006286 63                    1501 	.db	00123$>>8
      006287 64                    1502 	.db	00157$>>8
      006288 64                    1503 	.db	00173$>>8
                                   1504 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      006289                       1505 00103$:
                                   1506 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      006289 BF 80 02         [24] 1507 	cjne	r7,#0x80,01209$
      00628C 80 08            [24] 1508 	sjmp	00112$
      00628E                       1509 01209$:
      00628E BF 81 02         [24] 1510 	cjne	r7,#0x81,01210$
      006291 80 03            [24] 1511 	sjmp	01211$
      006293                       1512 01210$:
      006293 02 5F 9A         [24] 1513 	ljmp	_control_stall
      006296                       1514 01211$:
      006296                       1515 00112$:
                                   1516 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006296 8E 01            [24] 1517 	mov	ar1,r6
      006298 B9 21 02         [24] 1518 	cjne	r1,#0x21,01212$
      00629B 80 09            [24] 1519 	sjmp	00301$
      00629D                       1520 01212$:
      00629D B9 22 02         [24] 1521 	cjne	r1,#0x22,01213$
      0062A0 80 04            [24] 1522 	sjmp	00301$
      0062A2                       1523 01213$:
                                   1524 ;	assignBit
      0062A2 C2 1C            [12] 1525 	clr	_control_setup_sloc2_1_0
      0062A4 80 02            [24] 1526 	sjmp	00302$
      0062A6                       1527 00301$:
                                   1528 ;	assignBit
      0062A6 D2 1C            [12] 1529 	setb	_control_setup_sloc2_1_0
      0062A8                       1530 00302$:
      0062A8 E4               [12] 1531 	clr	a
      0062A9 BF 81 01         [24] 1532 	cjne	r7,#0x81,01214$
      0062AC 04               [12] 1533 	inc	a
      0062AD                       1534 01214$:
      0062AD FA               [12] 1535 	mov	r2,a
      0062AE A2 1C            [12] 1536 	mov	c,_control_setup_sloc2_1_0
      0062B0 E4               [12] 1537 	clr	a
      0062B1 33               [12] 1538 	rlc	a
      0062B2 B5 02 02         [24] 1539 	cjne	a,ar2,01216$
      0062B5 80 03            [24] 1540 	sjmp	00105$
      0062B7                       1541 01216$:
                                   1542 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      0062B7 02 5F 9A         [24] 1543 	ljmp	_control_stall
      0062BA                       1544 00105$:
                                   1545 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      0062BA 8E 02            [24] 1546 	mov	ar2,r6
      0062BC 90 07 F6         [24] 1547 	mov	dptr,#_descriptor_select_PARM_2
      0062BF ED               [12] 1548 	mov	a,r5
      0062C0 F0               [24] 1549 	movx	@dptr,a
      0062C1 90 07 F7         [24] 1550 	mov	dptr,#_descriptor_select_PARM_3
      0062C4 EB               [12] 1551 	mov	a,r3
      0062C5 F0               [24] 1552 	movx	@dptr,a
      0062C6 EC               [12] 1553 	mov	a,r4
      0062C7 A3               [24] 1554 	inc	dptr
      0062C8 F0               [24] 1555 	movx	@dptr,a
      0062C9 8A 82            [24] 1556 	mov	dpl, r2
      0062CB 12 60 38         [24] 1557 	lcall	_descriptor_select
      0062CE 85 82 17         [24] 1558 	mov	_control_setup_sloc3_1_0,dpl
      0062D1 85 83 18         [24] 1559 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1560 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      0062D4 E5 17            [12] 1561 	mov	a,_control_setup_sloc3_1_0
      0062D6 45 18            [12] 1562 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0062D8 70 03            [24] 1563 	jnz	00107$
      0062DA 02 5F 9A         [24] 1564 	ljmp	_control_stall
      0062DD                       1565 00107$:
                                   1566 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0062DD 90 07 8C         [24] 1567 	mov	dptr,#_D0SetupLen
      0062E0 E0               [24] 1568 	movx	a,@dptr
      0062E1 F8               [12] 1569 	mov	r0,a
      0062E2 A3               [24] 1570 	inc	dptr
      0062E3 E0               [24] 1571 	movx	a,@dptr
      0062E4 FA               [12] 1572 	mov	r2,a
      0062E5 C3               [12] 1573 	clr	c
      0062E6 E5 17            [12] 1574 	mov	a,_control_setup_sloc3_1_0
      0062E8 98               [12] 1575 	subb	a,r0
      0062E9 E5 18            [12] 1576 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062EB 9A               [12] 1577 	subb	a,r2
      0062EC 50 06            [24] 1578 	jnc	00303$
      0062EE E5 17            [12] 1579 	mov	a,_control_setup_sloc3_1_0
      0062F0 54 3F            [12] 1580 	anl	a,#0x3f
      0062F2 60 04            [24] 1581 	jz	00304$
      0062F4                       1582 00303$:
                                   1583 ;	assignBit
      0062F4 C2 1C            [12] 1584 	clr	_control_setup_sloc2_1_0
      0062F6 80 02            [24] 1585 	sjmp	00305$
      0062F8                       1586 00304$:
                                   1587 ;	assignBit
      0062F8 D2 1C            [12] 1588 	setb	_control_setup_sloc2_1_0
      0062FA                       1589 00305$:
      0062FA 90 07 F3         [24] 1590 	mov	dptr,#_control_zlp
      0062FD A2 1C            [12] 1591 	mov	c,_control_setup_sloc2_1_0
      0062FF E4               [12] 1592 	clr	a
      006300 33               [12] 1593 	rlc	a
      006301 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      006302 90 07 8C         [24] 1596 	mov	dptr,#_D0SetupLen
      006305 E0               [24] 1597 	movx	a,@dptr
      006306 F9               [12] 1598 	mov	r1,a
      006307 A3               [24] 1599 	inc	dptr
      006308 E0               [24] 1600 	movx	a,@dptr
      006309 FA               [12] 1601 	mov	r2,a
      00630A C3               [12] 1602 	clr	c
      00630B E5 17            [12] 1603 	mov	a,_control_setup_sloc3_1_0
      00630D 99               [12] 1604 	subb	a,r1
      00630E E5 18            [12] 1605 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006310 9A               [12] 1606 	subb	a,r2
      006311 50 0A            [24] 1607 	jnc	00109$
                                   1608 ;	free result
      006313 90 07 8C         [24] 1609 	mov	dptr,#_D0SetupLen
      006316 E5 17            [12] 1610 	mov	a,_control_setup_sloc3_1_0
      006318 F0               [24] 1611 	movx	@dptr,a
      006319 E5 18            [12] 1612 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00631B A3               [24] 1613 	inc	dptr
      00631C F0               [24] 1614 	movx	@dptr,a
      00631D                       1615 00109$:
                                   1616 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00631D 90 07 8C         [24] 1617 	mov	dptr,#_D0SetupLen
      006320 E0               [24] 1618 	movx	a,@dptr
      006321 F9               [12] 1619 	mov	r1,a
      006322 A3               [24] 1620 	inc	dptr
      006323 E0               [24] 1621 	movx	a,@dptr
      006324 49               [12] 1622 	orl	a,r1
      006325 60 04            [24] 1623 	jz	00306$
      006327 7A 01            [12] 1624 	mov	r2,#0x01
      006329 80 02            [24] 1625 	sjmp	00307$
      00632B                       1626 00306$:
      00632B 7A 02            [12] 1627 	mov	r2,#0x02
      00632D                       1628 00307$:
      00632D 90 07 F0         [24] 1629 	mov	dptr,#_control_phase
      006330 EA               [12] 1630 	mov	a,r2
      006331 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      006332 90 07 8C         [24] 1633 	mov	dptr,#_D0SetupLen
      006335 E0               [24] 1634 	movx	a,@dptr
      006336 F9               [12] 1635 	mov	r1,a
      006337 A3               [24] 1636 	inc	dptr
      006338 E0               [24] 1637 	movx	a,@dptr
      006339 49               [12] 1638 	orl	a,r1
      00633A 60 03            [24] 1639 	jz	00111$
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      00633C 02 5F BC         [24] 1641 	ljmp	_control_next
      00633F                       1642 00111$:
      00633F 22               [24] 1643 	ret
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      006340 02 5F 9A         [24] 1645 	ljmp	_control_stall
                                   1646 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      006343                       1647 00116$:
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006343 EF               [12] 1649 	mov	a,r7
      006344 70 23            [24] 1650 	jnz	00118$
      006346 30 18 20         [24] 1651 	jnb	_control_setup_zero_index_10000_287,00118$
      006349 30 1A 1D         [24] 1652 	jnb	_control_setup_zero_length_10000_287,00118$
      00634C 8D 01            [24] 1653 	mov	ar1,r5
      00634E 8E 02            [24] 1654 	mov	ar2,r6
      006350 C3               [12] 1655 	clr	c
      006351 74 7F            [12] 1656 	mov	a,#0x7f
      006353 99               [12] 1657 	subb	a,r1
      006354 E4               [12] 1658 	clr	a
      006355 9A               [12] 1659 	subb	a,r2
      006356 40 11            [24] 1660 	jc	00118$
                                   1661 ;	free result
                                   1662 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      006358 90 07 8C         [24] 1663 	mov	dptr,#_D0SetupLen
      00635B ED               [12] 1664 	mov	a,r5
      00635C F0               [24] 1665 	movx	@dptr,a
      00635D EE               [12] 1666 	mov	a,r6
      00635E A3               [24] 1667 	inc	dptr
      00635F F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      006360 90 07 F0         [24] 1670 	mov	dptr,#_control_phase
      006363 74 03            [12] 1671 	mov	a,#0x03
      006365 F0               [24] 1672 	movx	@dptr,a
      006366 02 69 49         [24] 1673 	ljmp	00291$
      006369                       1674 00118$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006369 02 5F 9A         [24] 1676 	ljmp	_control_stall
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00636C                       1678 00123$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00636C EF               [12] 1680 	mov	a,r7
      00636D 70 3C            [24] 1681 	jnz	00145$
      00636F 30 18 39         [24] 1682 	jnb	_control_setup_zero_index_10000_287,00145$
      006372 30 1A 36         [24] 1683 	jnb	_control_setup_zero_length_10000_287,00145$
      006375 8D 01            [24] 1684 	mov	ar1,r5
      006377 8E 02            [24] 1685 	mov	ar2,r6
      006379 C3               [12] 1686 	clr	c
      00637A 74 01            [12] 1687 	mov	a,#0x01
      00637C 99               [12] 1688 	subb	a,r1
      00637D E4               [12] 1689 	clr	a
      00637E 9A               [12] 1690 	subb	a,r2
      00637F 40 2A            [24] 1691 	jc	00145$
                                   1692 ;	free result
                                   1693 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      006381 C0 06            [24] 1694 	push	ar6
      006383 C0 05            [24] 1695 	push	ar5
      006385 12 5F 3D         [24] 1696 	lcall	_endpoints_reset
      006388 D0 05            [24] 1697 	pop	ar5
      00638A D0 06            [24] 1698 	pop	ar6
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      00638C 90 07 91         [24] 1700 	mov	dptr,#_D0UsbConfig
      00638F ED               [12] 1701 	mov	a,r5
      006390 F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      006391 A2 1B            [12] 1704 	mov	c,_control_setup_sloc0_1_0
      006393 B3               [12] 1705 	cpl	c
      006394 92 1C            [24] 1706 	mov	_control_setup_sloc2_1_0,c
      006396 90 07 92         [24] 1707 	mov	dptr,#_USB_EnumStatus
      006399 E4               [12] 1708 	clr	a
      00639A 33               [12] 1709 	rlc	a
      00639B F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      00639C 90 07 BB         [24] 1712 	mov	dptr,#_keyboard_reset
      00639F 74 01            [12] 1713 	mov	a,#0x01
      0063A1 F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      0063A2 90 07 F0         [24] 1716 	mov	dptr,#_control_phase
      0063A5 74 03            [12] 1717 	mov	a,#0x03
      0063A7 F0               [24] 1718 	movx	@dptr,a
      0063A8 02 69 49         [24] 1719 	ljmp	00291$
      0063AB                       1720 00145$:
                                   1721 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      0063AB BF 21 02         [24] 1722 	cjne	r7,#0x21,01231$
      0063AE 80 03            [24] 1723 	sjmp	01232$
      0063B0                       1724 01231$:
      0063B0 02 5F 9A         [24] 1725 	ljmp	_control_stall
      0063B3                       1726 01232$:
      0063B3 90 07 91         [24] 1727 	mov	dptr,#_D0UsbConfig
      0063B6 E0               [24] 1728 	movx	a,@dptr
      0063B7 70 03            [24] 1729 	jnz	01233$
      0063B9 02 5F 9A         [24] 1730 	ljmp	_control_stall
      0063BC                       1731 01233$:
                                   1732 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0063BC BB 01 2D         [24] 1733 	cjne	r3,#0x01,00135$
      0063BF BC 00 2A         [24] 1734 	cjne	r4,#0x00,00135$
      0063C2 8D 01            [24] 1735 	mov	ar1,r5
      0063C4 8E 02            [24] 1736 	mov	ar2,r6
      0063C6 B9 00 23         [24] 1737 	cjne	r1,#0x00,00135$
      0063C9 BA 02 20         [24] 1738 	cjne	r2,#0x02,00135$
      0063CC 90 07 8C         [24] 1739 	mov	dptr,#_D0SetupLen
      0063CF E0               [24] 1740 	movx	a,@dptr
      0063D0 F9               [12] 1741 	mov	r1,a
      0063D1 A3               [24] 1742 	inc	dptr
      0063D2 E0               [24] 1743 	movx	a,@dptr
      0063D3 FA               [12] 1744 	mov	r2,a
      0063D4 B9 20 15         [24] 1745 	cjne	r1,#0x20,00135$
      0063D7 BA 00 12         [24] 1746 	cjne	r2,#0x00,00135$
      0063DA 90 07 99         [24] 1747 	mov	dptr,#_raw_state
      0063DD E0               [24] 1748 	movx	a,@dptr
      0063DE 70 0C            [24] 1749 	jnz	00135$
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      0063E0 90 07 99         [24] 1751 	mov	dptr,#_raw_state
      0063E3 74 01            [12] 1752 	mov	a,#0x01
      0063E5 F0               [24] 1753 	movx	@dptr,a
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      0063E6 90 07 F1         [24] 1755 	mov	dptr,#_output_kind
      0063E9 F0               [24] 1756 	movx	@dptr,a
      0063EA 80 52            [24] 1757 	sjmp	00136$
      0063EC                       1758 00135$:
                                   1759 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0063EC EB               [12] 1760 	mov	a,r3
      0063ED 4C               [12] 1761 	orl	a,r4
      0063EE 70 20            [24] 1762 	jnz	00130$
      0063F0 8D 01            [24] 1763 	mov	ar1,r5
      0063F2 8E 02            [24] 1764 	mov	ar2,r6
      0063F4 B9 00 19         [24] 1765 	cjne	r1,#0x00,00130$
      0063F7 BA 02 16         [24] 1766 	cjne	r2,#0x02,00130$
      0063FA 90 07 8C         [24] 1767 	mov	dptr,#_D0SetupLen
      0063FD E0               [24] 1768 	movx	a,@dptr
      0063FE F9               [12] 1769 	mov	r1,a
      0063FF A3               [24] 1770 	inc	dptr
      006400 E0               [24] 1771 	movx	a,@dptr
      006401 FA               [12] 1772 	mov	r2,a
      006402 B9 01 0B         [24] 1773 	cjne	r1,#0x01,00130$
      006405 BA 00 08         [24] 1774 	cjne	r2,#0x00,00130$
                                   1775 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      006408 90 07 F1         [24] 1776 	mov	dptr,#_output_kind
      00640B 74 02            [12] 1777 	mov	a,#0x02
      00640D F0               [24] 1778 	movx	@dptr,a
      00640E 80 2E            [24] 1779 	sjmp	00136$
      006410                       1780 00130$:
                                   1781 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006410 BB 02 28         [24] 1782 	cjne	r3,#0x02,00125$
      006413 BC 00 25         [24] 1783 	cjne	r4,#0x00,00125$
      006416 8D 01            [24] 1784 	mov	ar1,r5
      006418 8E 02            [24] 1785 	mov	ar2,r6
      00641A B9 06 1E         [24] 1786 	cjne	r1,#0x06,00125$
      00641D BA 02 1B         [24] 1787 	cjne	r2,#0x02,00125$
      006420 90 07 8C         [24] 1788 	mov	dptr,#_D0SetupLen
      006423 E0               [24] 1789 	movx	a,@dptr
      006424 F9               [12] 1790 	mov	r1,a
      006425 A3               [24] 1791 	inc	dptr
      006426 E0               [24] 1792 	movx	a,@dptr
      006427 FA               [12] 1793 	mov	r2,a
      006428 B9 02 10         [24] 1794 	cjne	r1,#0x02,00125$
      00642B BA 00 0D         [24] 1795 	cjne	r2,#0x00,00125$
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      00642E 90 07 F1         [24] 1797 	mov	dptr,#_output_kind
      006431 74 03            [12] 1798 	mov	a,#0x03
      006433 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      006434 90 07 F2         [24] 1801 	mov	dptr,#_output_report_id
      006437 23               [12] 1802 	rl	a
      006438 F0               [24] 1803 	movx	@dptr,a
      006439 80 03            [24] 1804 	sjmp	00136$
      00643B                       1805 00125$:
                                   1806 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      00643B 02 5F 9A         [24] 1807 	ljmp	_control_stall
      00643E                       1808 00136$:
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      00643E 90 07 F0         [24] 1810 	mov	dptr,#_control_phase
      006441 74 04            [12] 1811 	mov	a,#0x04
      006443 F0               [24] 1812 	movx	@dptr,a
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      006444 22               [24] 1814 	ret
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      006445 02 5F 9A         [24] 1816 	ljmp	_control_stall
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006448                       1818 00150$:
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006448 BF 80 2A         [24] 1820 	cjne	r7,#0x80,00152$
      00644B 30 18 27         [24] 1821 	jnb	_control_setup_zero_index_10000_287,00152$
      00644E 30 19 24         [24] 1822 	jnb	_control_setup_zero_value_10000_287,00152$
      006451 90 07 8C         [24] 1823 	mov	dptr,#_D0SetupLen
      006454 E0               [24] 1824 	movx	a,@dptr
      006455 F9               [12] 1825 	mov	r1,a
      006456 A3               [24] 1826 	inc	dptr
      006457 E0               [24] 1827 	movx	a,@dptr
      006458 FA               [12] 1828 	mov	r2,a
      006459 B9 01 19         [24] 1829 	cjne	r1,#0x01,00152$
      00645C BA 00 16         [24] 1830 	cjne	r2,#0x00,00152$
                                   1831 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      00645F 90 07 91         [24] 1832 	mov	dptr,#_D0UsbConfig
      006462 E0               [24] 1833 	movx	a,@dptr
      006463 90 10 00         [24] 1834 	mov	dptr,#0x1000
      006466 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      006467 90 22 08         [24] 1837 	mov	dptr,#0x2208
      00646A 74 01            [12] 1838 	mov	a,#0x01
      00646C F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      00646D 90 07 F0         [24] 1841 	mov	dptr,#_control_phase
      006470 04               [12] 1842 	inc	a
      006471 F0               [24] 1843 	movx	@dptr,a
      006472 02 69 49         [24] 1844 	ljmp	00291$
      006475                       1845 00152$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      006475 02 5F 9A         [24] 1847 	ljmp	_control_stall
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006478                       1849 00157$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006478 BF 81 2C         [24] 1851 	cjne	r7,#0x81,00167$
      00647B 30 17 29         [24] 1852 	jnb	_control_setup_valid_interface_10000_287,00167$
      00647E 30 19 26         [24] 1853 	jnb	_control_setup_zero_value_10000_287,00167$
      006481 90 07 8C         [24] 1854 	mov	dptr,#_D0SetupLen
      006484 E0               [24] 1855 	movx	a,@dptr
      006485 F9               [12] 1856 	mov	r1,a
      006486 A3               [24] 1857 	inc	dptr
      006487 E0               [24] 1858 	movx	a,@dptr
      006488 FA               [12] 1859 	mov	r2,a
      006489 B9 01 1B         [24] 1860 	cjne	r1,#0x01,00167$
      00648C BA 00 18         [24] 1861 	cjne	r2,#0x00,00167$
      00648F 90 07 91         [24] 1862 	mov	dptr,#_D0UsbConfig
      006492 E0               [24] 1863 	movx	a,@dptr
      006493 60 12            [24] 1864 	jz	00167$
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      006495 90 10 00         [24] 1866 	mov	dptr,#0x1000
      006498 E4               [12] 1867 	clr	a
      006499 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      00649A 90 22 08         [24] 1870 	mov	dptr,#0x2208
      00649D 04               [12] 1871 	inc	a
      00649E F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      00649F 90 07 F0         [24] 1874 	mov	dptr,#_control_phase
      0064A2 04               [12] 1875 	inc	a
      0064A3 F0               [24] 1876 	movx	@dptr,a
      0064A4 02 69 49         [24] 1877 	ljmp	00291$
      0064A7                       1878 00167$:
                                   1879 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0064A7 30 17 1E         [24] 1880 	jnb	_control_setup_valid_interface_10000_287,00161$
      0064AA 90 07 91         [24] 1881 	mov	dptr,#_D0UsbConfig
      0064AD E0               [24] 1882 	movx	a,@dptr
      0064AE 60 18            [24] 1883 	jz	00161$
      0064B0 BF 21 15         [24] 1884 	cjne	r7,#0x21,00161$
      0064B3 30 1A 12         [24] 1885 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1886 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0064B6 EB               [12] 1887 	mov	a,r3
      0064B7 4C               [12] 1888 	orl	a,r4
      0064B8 70 05            [24] 1889 	jnz	00159$
      0064BA 90 06 53         [24] 1890 	mov	dptr,#_keyboard_idle
      0064BD EE               [12] 1891 	mov	a,r6
      0064BE F0               [24] 1892 	movx	@dptr,a
      0064BF                       1893 00159$:
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      0064BF 90 07 F0         [24] 1895 	mov	dptr,#_control_phase
      0064C2 74 03            [12] 1896 	mov	a,#0x03
      0064C4 F0               [24] 1897 	movx	@dptr,a
      0064C5 02 69 49         [24] 1898 	ljmp	00291$
      0064C8                       1899 00161$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      0064C8 02 5F 9A         [24] 1901 	ljmp	_control_stall
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0064CB                       1903 00173$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0064CB BF 01 18         [24] 1905 	cjne	r7,#0x01,00182$
      0064CE 30 17 15         [24] 1906 	jnb	_control_setup_valid_interface_10000_287,00182$
      0064D1 30 19 12         [24] 1907 	jnb	_control_setup_zero_value_10000_287,00182$
      0064D4 30 1A 0F         [24] 1908 	jnb	_control_setup_zero_length_10000_287,00182$
      0064D7 90 07 91         [24] 1909 	mov	dptr,#_D0UsbConfig
      0064DA E0               [24] 1910 	movx	a,@dptr
      0064DB 60 09            [24] 1911 	jz	00182$
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      0064DD 90 07 F0         [24] 1913 	mov	dptr,#_control_phase
      0064E0 74 03            [12] 1914 	mov	a,#0x03
      0064E2 F0               [24] 1915 	movx	@dptr,a
      0064E3 02 69 49         [24] 1916 	ljmp	00291$
      0064E6                       1917 00182$:
                                   1918 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0064E6 EB               [12] 1919 	mov	a,r3
      0064E7 4C               [12] 1920 	orl	a,r4
      0064E8 70 2C            [24] 1921 	jnz	00175$
      0064EA 90 07 91         [24] 1922 	mov	dptr,#_D0UsbConfig
      0064ED E0               [24] 1923 	movx	a,@dptr
      0064EE 60 26            [24] 1924 	jz	00175$
      0064F0 BF 21 23         [24] 1925 	cjne	r7,#0x21,00175$
      0064F3 30 1A 20         [24] 1926 	jnb	_control_setup_zero_length_10000_287,00175$
      0064F6 8D 01            [24] 1927 	mov	ar1,r5
      0064F8 8E 02            [24] 1928 	mov	ar2,r6
      0064FA C3               [12] 1929 	clr	c
      0064FB 74 01            [12] 1930 	mov	a,#0x01
      0064FD 99               [12] 1931 	subb	a,r1
      0064FE E4               [12] 1932 	clr	a
      0064FF 9A               [12] 1933 	subb	a,r2
      006500 40 14            [24] 1934 	jc	00175$
                                   1935 ;	free result
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      006502 90 0D E5         [24] 1937 	mov	dptr,#_keyboard_protocol
      006505 ED               [12] 1938 	mov	a,r5
      006506 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      006507 90 07 BB         [24] 1941 	mov	dptr,#_keyboard_reset
      00650A 74 01            [12] 1942 	mov	a,#0x01
      00650C F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      00650D 90 07 F0         [24] 1945 	mov	dptr,#_control_phase
      006510 74 03            [12] 1946 	mov	a,#0x03
      006512 F0               [24] 1947 	movx	@dptr,a
      006513 02 69 49         [24] 1948 	ljmp	00291$
      006516                       1949 00175$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006516 02 5F 9A         [24] 1951 	ljmp	_control_stall
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      006519                       1953 00188$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      006519 20 19 03         [24] 1955 	jb	_control_setup_zero_value_10000_287,01283$
      00651C 02 5F 9A         [24] 1956 	ljmp	_control_stall
      00651F                       1957 01283$:
      00651F 90 07 8C         [24] 1958 	mov	dptr,#_D0SetupLen
      006522 E0               [24] 1959 	movx	a,@dptr
      006523 F9               [12] 1960 	mov	r1,a
      006524 A3               [24] 1961 	inc	dptr
      006525 E0               [24] 1962 	movx	a,@dptr
      006526 FA               [12] 1963 	mov	r2,a
      006527 B9 02 05         [24] 1964 	cjne	r1,#0x02,01284$
      00652A BA 00 02         [24] 1965 	cjne	r2,#0x00,01284$
      00652D 80 03            [24] 1966 	sjmp	01285$
      00652F                       1967 01284$:
      00652F 02 5F 9A         [24] 1968 	ljmp	_control_stall
      006532                       1969 01285$:
                                   1970 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006532 E4               [12] 1971 	clr	a
      006533 BF 80 01         [24] 1972 	cjne	r7,#0x80,01286$
      006536 04               [12] 1973 	inc	a
      006537                       1974 01286$:
      006537 FA               [12] 1975 	mov	r2,a
      006538 60 03            [24] 1976 	jz	00196$
      00653A 20 18 35         [24] 1977 	jb	_control_setup_zero_index_10000_287,00189$
      00653D                       1978 00196$:
      00653D BF 81 09         [24] 1979 	cjne	r7,#0x81,00202$
      006540 30 17 06         [24] 1980 	jnb	_control_setup_valid_interface_10000_287,00202$
      006543 90 07 91         [24] 1981 	mov	dptr,#_D0UsbConfig
      006546 E0               [24] 1982 	movx	a,@dptr
      006547 70 29            [24] 1983 	jnz	00189$
      006549                       1984 00202$:
                                   1985 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006549 BF 82 70         [24] 1986 	cjne	r7,#0x82,00190$
      00654C 90 07 91         [24] 1987 	mov	dptr,#_D0UsbConfig
      00654F E0               [24] 1988 	movx	a,@dptr
      006550 60 6A            [24] 1989 	jz	00190$
      006552 EB               [12] 1990 	mov	a,r3
      006553 4C               [12] 1991 	orl	a,r4
      006554 60 1C            [24] 1992 	jz	00189$
      006556 8B 00            [24] 1993 	mov	ar0,r3
      006558 8C 01            [24] 1994 	mov	ar1,r4
      00655A B8 80 05         [24] 1995 	cjne	r0,#0x80,01298$
      00655D B9 00 02         [24] 1996 	cjne	r1,#0x00,01298$
      006560 80 10            [24] 1997 	sjmp	00189$
      006562                       1998 01298$:
      006562 C3               [12] 1999 	clr	c
      006563 E8               [12] 2000 	mov	a,r0
      006564 94 81            [12] 2001 	subb	a,#0x81
      006566 E9               [12] 2002 	mov	a,r1
      006567 94 00            [12] 2003 	subb	a,#0x00
      006569 40 51            [24] 2004 	jc	00190$
      00656B 74 83            [12] 2005 	mov	a,#0x83
      00656D 98               [12] 2006 	subb	a,r0
      00656E E4               [12] 2007 	clr	a
      00656F 99               [12] 2008 	subb	a,r1
      006570 40 4A            [24] 2009 	jc	00190$
                                   2010 ;	free result
      006572                       2011 00189$:
                                   2012 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      006572 8B 01            [24] 2013 	mov	ar1,r3
      006574 53 01 07         [24] 2014 	anl	ar1,#0x07
                                   2015 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006577 EA               [12] 2016 	mov	a,r2
      006578 60 0B            [24] 2017 	jz	00308$
      00657A 90 07 93         [24] 2018 	mov	dptr,#_USB_SleepStatus
      00657D E0               [24] 2019 	movx	a,@dptr
      00657E 54 01            [12] 2020 	anl	a,#0x01
      006580 25 E0            [12] 2021 	add	a,acc
      006582 FA               [12] 2022 	mov	r2,a
      006583 80 22            [24] 2023 	sjmp	00309$
      006585                       2024 00308$:
                                   2025 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006585 BF 82 1B         [24] 2026 	cjne	r7,#0x82,00310$
      006588 E9               [12] 2027 	mov	a,r1
      006589 60 18            [24] 2028 	jz	00310$
      00658B 89 00            [24] 2029 	mov	ar0,r1
      00658D 79 00            [12] 2030 	mov	r1,#0x00
      00658F 74 22            [12] 2031 	mov	a,#0x22
      006591 29               [12] 2032 	add	a, r1
      006592 F9               [12] 2033 	mov	r1,a
      006593 88 82            [24] 2034 	mov	dpl,r0
      006595 89 83            [24] 2035 	mov	dph,r1
      006597 E0               [24] 2036 	movx	a,@dptr
      006598 F9               [12] 2037 	mov	r1,a
      006599 53 01 03         [24] 2038 	anl	ar1,#0x03
      00659C B9 03 04         [24] 2039 	cjne	r1,#0x03,00310$
      00659F 79 01            [12] 2040 	mov	r1,#0x01
      0065A1 80 02            [24] 2041 	sjmp	00311$
      0065A3                       2042 00310$:
      0065A3 79 00            [12] 2043 	mov	r1,#0x00
      0065A5                       2044 00311$:
      0065A5 89 02            [24] 2045 	mov	ar2,r1
      0065A7                       2046 00309$:
      0065A7 90 10 00         [24] 2047 	mov	dptr,#0x1000
      0065AA EA               [12] 2048 	mov	a,r2
      0065AB F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      0065AC A3               [24] 2051 	inc	dptr
      0065AD E4               [12] 2052 	clr	a
      0065AE F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      0065AF 90 22 08         [24] 2055 	mov	dptr,#0x2208
      0065B2 74 02            [12] 2056 	mov	a,#0x02
      0065B4 F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      0065B5 90 07 F0         [24] 2059 	mov	dptr,#_control_phase
      0065B8 F0               [24] 2060 	movx	@dptr,a
      0065B9 02 69 49         [24] 2061 	ljmp	00291$
      0065BC                       2062 00190$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      0065BC 02 5F 9A         [24] 2064 	ljmp	_control_stall
                                   2065 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0065BF                       2066 00205$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      0065BF 20 1A 03         [24] 2068 	jb	_control_setup_zero_length_10000_287,01307$
      0065C2 02 66 52         [24] 2069 	ljmp	00279$
      0065C5                       2070 01307$:
      0065C5 90 07 91         [24] 2071 	mov	dptr,#_D0UsbConfig
      0065C8 E0               [24] 2072 	movx	a,@dptr
      0065C9 70 03            [24] 2073 	jnz	01308$
      0065CB 02 66 52         [24] 2074 	ljmp	00279$
      0065CE                       2075 01308$:
                                   2076 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      0065CE EF               [12] 2077 	mov	a,r7
      0065CF 70 29            [24] 2078 	jnz	00218$
      0065D1 8D 01            [24] 2079 	mov	ar1,r5
      0065D3 8E 02            [24] 2080 	mov	ar2,r6
      0065D5 B9 01 22         [24] 2081 	cjne	r1,#0x01,00218$
      0065D8 BA 00 1F         [24] 2082 	cjne	r2,#0x00,00218$
      0065DB 30 18 1C         [24] 2083 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0065DE 90 07 8B         [24] 2085 	mov	dptr,#_D0SetupReqCode
      0065E1 E0               [24] 2086 	movx	a,@dptr
      0065E2 FA               [12] 2087 	mov	r2,a
      0065E3 BA 03 0A         [24] 2088 	cjne	r2,#0x03,00207$
      0065E6 90 07 93         [24] 2089 	mov	dptr,#_USB_SleepStatus
      0065E9 E0               [24] 2090 	movx	a,@dptr
      0065EA 43 E0 01         [24] 2091 	orl	acc,#0x01
      0065ED F0               [24] 2092 	movx	@dptr,a
      0065EE 80 59            [24] 2093 	sjmp	00219$
      0065F0                       2094 00207$:
                                   2095 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      0065F0 90 07 93         [24] 2096 	mov	dptr,#_USB_SleepStatus
      0065F3 E0               [24] 2097 	movx	a,@dptr
      0065F4 53 E0 FE         [24] 2098 	anl	acc,#0xfe
      0065F7 F0               [24] 2099 	movx	@dptr,a
      0065F8 80 4F            [24] 2100 	sjmp	00219$
      0065FA                       2101 00218$:
                                   2102 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0065FA BF 02 49         [24] 2103 	cjne	r7,#0x02,00212$
      0065FD 30 19 46         [24] 2104 	jnb	_control_setup_zero_value_10000_287,00212$
      006600 8B 01            [24] 2105 	mov	ar1,r3
      006602 8C 02            [24] 2106 	mov	ar2,r4
      006604 C3               [12] 2107 	clr	c
      006605 E9               [12] 2108 	mov	a,r1
      006606 94 81            [12] 2109 	subb	a,#0x81
      006608 EA               [12] 2110 	mov	a,r2
      006609 94 00            [12] 2111 	subb	a,#0x00
      00660B 40 39            [24] 2112 	jc	00212$
      00660D 74 83            [12] 2113 	mov	a,#0x83
      00660F 99               [12] 2114 	subb	a,r1
      006610 E4               [12] 2115 	clr	a
      006611 9A               [12] 2116 	subb	a,r2
      006612 40 32            [24] 2117 	jc	00212$
                                   2118 ;	free result
                                   2119 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      006614 8B 02            [24] 2120 	mov	ar2,r3
      006616 53 02 07         [24] 2121 	anl	ar2,#0x07
                                   2122 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006619 8A 00            [24] 2123 	mov	ar0,r2
      00661B 79 00            [12] 2124 	mov	r1,#0x00
      00661D 74 22            [12] 2125 	mov	a,#0x22
      00661F 29               [12] 2126 	add	a, r1
      006620 F9               [12] 2127 	mov	r1,a
      006621 88 17            [24] 2128 	mov	_control_setup_sloc3_1_0,r0
      006623 89 18            [24] 2129 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006625 90 07 8B         [24] 2130 	mov	dptr,#_D0SetupReqCode
      006628 E0               [24] 2131 	movx	a,@dptr
      006629 F9               [12] 2132 	mov	r1,a
      00662A B9 03 04         [24] 2133 	cjne	r1,#0x03,00318$
      00662D 79 03            [12] 2134 	mov	r1,#0x03
      00662F 80 02            [24] 2135 	sjmp	00319$
      006631                       2136 00318$:
      006631 79 02            [12] 2137 	mov	r1,#0x02
      006633                       2138 00319$:
      006633 43 01 10         [24] 2139 	orl	ar1,#0x10
      006636 85 17 82         [24] 2140 	mov	dpl,_control_setup_sloc3_1_0
      006639 85 18 83         [24] 2141 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00663C E9               [12] 2142 	mov	a,r1
      00663D F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00663E BA 03 08         [24] 2145 	cjne	r2,#0x03,00219$
      006641 12 5F 20         [24] 2146 	lcall	_raw_complete
      006644 80 03            [24] 2147 	sjmp	00219$
      006646                       2148 00212$:
                                   2149 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006646 02 5F 9A         [24] 2150 	ljmp	_control_stall
      006649                       2151 00219$:
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006649 90 07 F0         [24] 2153 	mov	dptr,#_control_phase
      00664C 74 03            [12] 2154 	mov	a,#0x03
      00664E F0               [24] 2155 	movx	@dptr,a
      00664F 02 69 49         [24] 2156 	ljmp	00291$
      006652                       2157 00279$:
                                   2158 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006652 E4               [12] 2159 	clr	a
      006653 BF A1 01         [24] 2160 	cjne	r7,#0xa1,01324$
      006656 04               [12] 2161 	inc	a
      006657                       2162 01324$:
      006657 FA               [12] 2163 	mov	r2,a
      006658 70 03            [24] 2164 	jnz	01326$
      00665A 02 68 C4         [24] 2165 	ljmp	00273$
      00665D                       2166 01326$:
      00665D 90 07 8B         [24] 2167 	mov	dptr,#_D0SetupReqCode
      006660 E0               [24] 2168 	movx	a,@dptr
      006661 F9               [12] 2169 	mov	r1,a
      006662 B9 01 02         [24] 2170 	cjne	r1,#0x01,01327$
      006665 80 03            [24] 2171 	sjmp	01328$
      006667                       2172 01327$:
      006667 02 68 C4         [24] 2173 	ljmp	00273$
      00666A                       2174 01328$:
      00666A 90 07 91         [24] 2175 	mov	dptr,#_D0UsbConfig
      00666D E0               [24] 2176 	movx	a,@dptr
      00666E 70 03            [24] 2177 	jnz	01329$
      006670 02 68 C4         [24] 2178 	ljmp	00273$
      006673                       2179 01329$:
      006673 90 07 8C         [24] 2180 	mov	dptr,#_D0SetupLen
      006676 E0               [24] 2181 	movx	a,@dptr
      006677 F8               [12] 2182 	mov	r0,a
      006678 A3               [24] 2183 	inc	dptr
      006679 E0               [24] 2184 	movx	a,@dptr
      00667A 48               [12] 2185 	orl	a,r0
      00667B 70 03            [24] 2186 	jnz	01330$
      00667D 02 68 C4         [24] 2187 	ljmp	00273$
      006680                       2188 01330$:
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      006680 C0 03            [24] 2190 	push	ar3
      006682 C0 04            [24] 2191 	push	ar4
      006684 8D 01            [24] 2192 	mov	ar1,r5
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006686 8E 00            [24] 2194 	mov	ar0,r6
      006688 B8 01 03         [24] 2195 	cjne	r0,#0x01,01331$
      00668B E8               [12] 2196 	mov	a,r0
      00668C 80 01            [24] 2197 	sjmp	01332$
      00668E                       2198 01331$:
      00668E E4               [12] 2199 	clr	a
      00668F                       2200 01332$:
      00668F F5 17            [12] 2201 	mov	_control_setup_sloc3_1_0,a
      006691 D0 04            [24] 2202 	pop	ar4
      006693 D0 03            [24] 2203 	pop	ar3
      006695 E5 17            [12] 2204 	mov	a,_control_setup_sloc3_1_0
      006697 60 17            [24] 2205 	jz	00251$
      006699 EB               [12] 2206 	mov	a,r3
      00669A 4C               [12] 2207 	orl	a,r4
      00669B 70 13            [24] 2208 	jnz	00251$
      00669D E9               [12] 2209 	mov	a,r1
      00669E 70 10            [24] 2210 	jnz	00251$
                                   2211 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      0066A0 90 07 FA         [24] 2212 	mov	dptr,#_control_setup_length_10000_287
      0066A3 74 08            [12] 2213 	mov	a,#0x08
      0066A5 F0               [24] 2214 	movx	@dptr,a
      0066A6 E4               [12] 2215 	clr	a
      0066A7 A3               [24] 2216 	inc	dptr
      0066A8 F0               [24] 2217 	movx	@dptr,a
                                   2218 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      0066A9 90 07 FC         [24] 2219 	mov	dptr,#_control_setup_offset_10000_287
      0066AC F0               [24] 2220 	movx	@dptr,a
      0066AD 02 68 34         [24] 2221 	ljmp	00252$
      0066B0                       2222 00251$:
                                   2223 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0066B0 E5 17            [12] 2224 	mov	a,_control_setup_sloc3_1_0
      0066B2 60 27            [24] 2225 	jz	00245$
      0066B4 BB 02 24         [24] 2226 	cjne	r3,#0x02,00245$
      0066B7 BC 00 21         [24] 2227 	cjne	r4,#0x00,00245$
                                   2228 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0066BA B9 07 00         [24] 2229 	cjne	r1,#0x07,01339$
      0066BD                       2230 01339$:
      0066BD 50 1C            [24] 2231 	jnc	00245$
      0066BF E9               [12] 2232 	mov	a,r1
      0066C0 90 BD CC         [24] 2233 	mov	dptr,#_shared_lengths
      0066C3 93               [24] 2234 	movc	a,@a+dptr
      0066C4 F8               [12] 2235 	mov	r0,a
      0066C5 60 14            [24] 2236 	jz	00245$
                                   2237 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0066C7 90 07 FA         [24] 2238 	mov	dptr,#_control_setup_length_10000_287
      0066CA E8               [12] 2239 	mov	a,r0
      0066CB F0               [24] 2240 	movx	@dptr,a
      0066CC E4               [12] 2241 	clr	a
      0066CD A3               [24] 2242 	inc	dptr
      0066CE F0               [24] 2243 	movx	@dptr,a
                                   2244 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      0066CF E9               [12] 2245 	mov	a,r1
      0066D0 90 BD C5         [24] 2246 	mov	dptr,#_shared_offsets
      0066D3 93               [24] 2247 	movc	a,@a+dptr
      0066D4 90 07 FC         [24] 2248 	mov	dptr,#_control_setup_offset_10000_287
      0066D7 F0               [24] 2249 	movx	@dptr,a
      0066D8 02 68 34         [24] 2250 	ljmp	00252$
      0066DB                       2251 00245$:
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0066DB E5 17            [12] 2253 	mov	a,_control_setup_sloc3_1_0
      0066DD 60 7A            [24] 2254 	jz	00240$
      0066DF BB 01 77         [24] 2255 	cjne	r3,#0x01,00240$
      0066E2 BC 00 74         [24] 2256 	cjne	r4,#0x00,00240$
      0066E5 E9               [12] 2257 	mov	a,r1
      0066E6 70 71            [24] 2258 	jnz	00240$
                                   2259 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0066E8 90 07 8C         [24] 2260 	mov	dptr,#_D0SetupLen
      0066EB E0               [24] 2261 	movx	a,@dptr
      0066EC F8               [12] 2262 	mov	r0,a
      0066ED A3               [24] 2263 	inc	dptr
      0066EE E0               [24] 2264 	movx	a,@dptr
      0066EF F9               [12] 2265 	mov	r1,a
      0066F0 C3               [12] 2266 	clr	c
      0066F1 E8               [12] 2267 	mov	a,r0
      0066F2 94 20            [12] 2268 	subb	a,#0x20
      0066F4 E9               [12] 2269 	mov	a,r1
      0066F5 94 00            [12] 2270 	subb	a,#0x00
      0066F7 50 0A            [24] 2271 	jnc	00320$
      0066F9 90 07 8C         [24] 2272 	mov	dptr,#_D0SetupLen
      0066FC E0               [24] 2273 	movx	a,@dptr
      0066FD F8               [12] 2274 	mov	r0,a
      0066FE A3               [24] 2275 	inc	dptr
      0066FF E0               [24] 2276 	movx	a,@dptr
      006700 F9               [12] 2277 	mov	r1,a
      006701 80 04            [24] 2278 	sjmp	00321$
      006703                       2279 00320$:
      006703 78 20            [12] 2280 	mov	r0,#0x20
      006705 79 00            [12] 2281 	mov	r1,#0x00
      006707                       2282 00321$:
                                   2283 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006707 75 17 00         [24] 2284 	mov	_control_setup_sloc3_1_0,#0x00
      00670A                       2285 00293$:
      00670A C0 03            [24] 2286 	push	ar3
      00670C C0 04            [24] 2287 	push	ar4
      00670E AB 17            [24] 2288 	mov	r3,_control_setup_sloc3_1_0
      006710 7C 00            [12] 2289 	mov	r4,#0x00
      006712 C3               [12] 2290 	clr	c
      006713 EB               [12] 2291 	mov	a,r3
      006714 98               [12] 2292 	subb	a,r0
      006715 EC               [12] 2293 	mov	a,r4
      006716 99               [12] 2294 	subb	a,r1
      006717 D0 04            [24] 2295 	pop	ar4
      006719 D0 03            [24] 2296 	pop	ar3
      00671B 50 32            [24] 2297 	jnc	00222$
      00671D C0 00            [24] 2298 	push	ar0
      00671F C0 01            [24] 2299 	push	ar1
      006721 85 17 19         [24] 2300 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006724 74 10            [12] 2301 	mov	a,#0x10
      006726 24 00            [12] 2302 	add	a, #0x00
      006728 F5 1A            [12] 2303 	mov	(_control_setup_sloc4_1_0 + 1),a
      00672A A8 17            [24] 2304 	mov	r0,_control_setup_sloc3_1_0
      00672C 79 00            [12] 2305 	mov	r1,#0x00
      00672E 74 C0            [12] 2306 	mov	a,#0xc0
      006730 28               [12] 2307 	add	a, r0
      006731 F8               [12] 2308 	mov	r0,a
      006732 E4               [12] 2309 	clr	a
      006733 39               [12] 2310 	addc	a, r1
      006734 F9               [12] 2311 	mov	r1,a
      006735 88 82            [24] 2312 	mov	dpl,r0
      006737 74 10            [12] 2313 	mov	a,#0x10
      006739 29               [12] 2314 	add	a, r1
      00673A F5 83            [12] 2315 	mov	dph,a
      00673C E0               [24] 2316 	movx	a,@dptr
      00673D 85 19 82         [24] 2317 	mov	dpl,_control_setup_sloc4_1_0
      006740 85 1A 83         [24] 2318 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006743 F0               [24] 2319 	movx	@dptr,a
      006744 E5 17            [12] 2320 	mov	a,_control_setup_sloc3_1_0
      006746 04               [12] 2321 	inc	a
      006747 F5 17            [12] 2322 	mov	_control_setup_sloc3_1_0,a
      006749 D0 01            [24] 2323 	pop	ar1
      00674B D0 00            [24] 2324 	pop	ar0
      00674D 80 BB            [24] 2325 	sjmp	00293$
      00674F                       2326 00222$:
                                   2327 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      00674F 90 07 FA         [24] 2328 	mov	dptr,#_control_setup_length_10000_287
      006752 E4               [12] 2329 	clr	a
      006753 F0               [24] 2330 	movx	@dptr,a
      006754 A3               [24] 2331 	inc	dptr
      006755 F0               [24] 2332 	movx	@dptr,a
      006756 02 68 34         [24] 2333 	ljmp	00252$
      006759                       2334 00240$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006759 8D 00            [24] 2336 	mov	ar0,r5
      00675B 8E 01            [24] 2337 	mov	ar1,r6
      00675D B8 00 21         [24] 2338 	cjne	r0,#0x00,00236$
      006760 B9 02 1E         [24] 2339 	cjne	r1,#0x02,00236$
      006763 EB               [12] 2340 	mov	a,r3
      006764 4C               [12] 2341 	orl	a,r4
      006765 70 1A            [24] 2342 	jnz	00236$
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006767 90 07 96         [24] 2344 	mov	dptr,#_KB_USB_SetReport
      00676A E0               [24] 2345 	movx	a,@dptr
      00676B 90 10 00         [24] 2346 	mov	dptr,#0x1000
      00676E F0               [24] 2347 	movx	@dptr,a
                                   2348 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00676F 90 07 FA         [24] 2349 	mov	dptr,#_control_setup_length_10000_287
      006772 E4               [12] 2350 	clr	a
      006773 F0               [24] 2351 	movx	@dptr,a
      006774 A3               [24] 2352 	inc	dptr
      006775 F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006776 90 07 8C         [24] 2355 	mov	dptr,#_D0SetupLen
      006779 04               [12] 2356 	inc	a
      00677A F0               [24] 2357 	movx	@dptr,a
      00677B E4               [12] 2358 	clr	a
      00677C A3               [24] 2359 	inc	dptr
      00677D F0               [24] 2360 	movx	@dptr,a
      00677E 02 68 34         [24] 2361 	ljmp	00252$
      006781                       2362 00236$:
                                   2363 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006781 B8 06 41         [24] 2364 	cjne	r0,#0x06,00232$
      006784 B9 02 3E         [24] 2365 	cjne	r1,#0x02,00232$
      006787 BB 02 3B         [24] 2366 	cjne	r3,#0x02,00232$
      00678A BC 00 38         [24] 2367 	cjne	r4,#0x00,00232$
                                   2368 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00678D C0 03            [24] 2369 	push	ar3
      00678F C0 04            [24] 2370 	push	ar4
      006791 90 10 00         [24] 2371 	mov	dptr,#0x1000
      006794 74 06            [12] 2372 	mov	a,#0x06
      006796 F0               [24] 2373 	movx	@dptr,a
                                   2374 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006797 90 07 96         [24] 2375 	mov	dptr,#_KB_USB_SetReport
      00679A E0               [24] 2376 	movx	a,@dptr
      00679B 90 10 01         [24] 2377 	mov	dptr,#0x1001
      00679E F0               [24] 2378 	movx	@dptr,a
                                   2379 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      00679F 90 07 FA         [24] 2380 	mov	dptr,#_control_setup_length_10000_287
      0067A2 E4               [12] 2381 	clr	a
      0067A3 F0               [24] 2382 	movx	@dptr,a
      0067A4 A3               [24] 2383 	inc	dptr
      0067A5 F0               [24] 2384 	movx	@dptr,a
                                   2385 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      0067A6 90 07 8C         [24] 2386 	mov	dptr,#_D0SetupLen
      0067A9 E0               [24] 2387 	movx	a,@dptr
      0067AA FB               [12] 2388 	mov	r3,a
      0067AB A3               [24] 2389 	inc	dptr
      0067AC E0               [24] 2390 	movx	a,@dptr
      0067AD FC               [12] 2391 	mov	r4,a
      0067AE C3               [12] 2392 	clr	c
      0067AF 74 02            [12] 2393 	mov	a,#0x02
      0067B1 9B               [12] 2394 	subb	a,r3
      0067B2 E4               [12] 2395 	clr	a
      0067B3 9C               [12] 2396 	subb	a,r4
      0067B4 D0 04            [24] 2397 	pop	ar4
      0067B6 D0 03            [24] 2398 	pop	ar3
      0067B8 50 7A            [24] 2399 	jnc	00252$
                                   2400 ;	free result
      0067BA 90 07 8C         [24] 2401 	mov	dptr,#_D0SetupLen
      0067BD 74 02            [12] 2402 	mov	a,#0x02
      0067BF F0               [24] 2403 	movx	@dptr,a
      0067C0 E4               [12] 2404 	clr	a
      0067C1 A3               [24] 2405 	inc	dptr
      0067C2 F0               [24] 2406 	movx	@dptr,a
      0067C3 80 6F            [24] 2407 	sjmp	00252$
      0067C5                       2408 00232$:
                                   2409 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0067C5 B8 00 69         [24] 2410 	cjne	r0,#0x00,00228$
      0067C8 B9 03 66         [24] 2411 	cjne	r1,#0x03,00228$
      0067CB BB 01 63         [24] 2412 	cjne	r3,#0x01,00228$
      0067CE BC 00 60         [24] 2413 	cjne	r4,#0x00,00228$
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      0067D1 90 10 00         [24] 2415 	mov	dptr,#0x1000
      0067D4 74 41            [12] 2416 	mov	a,#0x41
      0067D6 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      0067D7 A3               [24] 2419 	inc	dptr
      0067D8 74 4B            [12] 2420 	mov	a,#0x4b
      0067DA F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      0067DB A3               [24] 2423 	inc	dptr
      0067DC 74 42            [12] 2424 	mov	a,#0x42
      0067DE F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      0067DF A3               [24] 2427 	inc	dptr
      0067E0 74 54            [12] 2428 	mov	a,#0x54
      0067E2 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      0067E3 A3               [24] 2431 	inc	dptr
      0067E4 74 01            [12] 2432 	mov	a,#0x01
      0067E6 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      0067E7 90 07 97         [24] 2435 	mov	dptr,#_ak820_boot_stage
      0067EA E0               [24] 2436 	movx	a,@dptr
      0067EB 90 10 05         [24] 2437 	mov	dptr,#0x1005
      0067EE F0               [24] 2438 	movx	@dptr,a
                                   2439 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0067EF 90 07 98         [24] 2440 	mov	dptr,#_ak820_main_heartbeat
      0067F2 E0               [24] 2441 	movx	a,@dptr
      0067F3 90 10 06         [24] 2442 	mov	dptr,#0x1006
      0067F6 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0067F7 90 07 92         [24] 2445 	mov	dptr,#_USB_EnumStatus
      0067FA E0               [24] 2446 	movx	a,@dptr
      0067FB 60 02            [24] 2447 	jz	00322$
      0067FD 74 01            [12] 2448 	mov	a,#0x01
      0067FF                       2449 00322$:
      0067FF F9               [12] 2450 	mov	r1,a
      006800 90 07 93         [24] 2451 	mov	dptr,#_USB_SleepStatus
      006803 E0               [24] 2452 	movx	a,@dptr
      006804 54 02            [12] 2453 	anl	a,#0x02
      006806 F8               [12] 2454 	mov	r0,a
      006807 E9               [12] 2455 	mov	a,r1
      006808 42 00            [12] 2456 	orl	ar0,a
      00680A 90 10 07         [24] 2457 	mov	dptr,#0x1007
      00680D E8               [12] 2458 	mov	a,r0
      00680E F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      00680F 90 07 FA         [24] 2461 	mov	dptr,#_control_setup_length_10000_287
      006812 E4               [12] 2462 	clr	a
      006813 F0               [24] 2463 	movx	@dptr,a
      006814 A3               [24] 2464 	inc	dptr
      006815 F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006816 90 07 8C         [24] 2467 	mov	dptr,#_D0SetupLen
      006819 E0               [24] 2468 	movx	a,@dptr
      00681A F8               [12] 2469 	mov	r0,a
      00681B A3               [24] 2470 	inc	dptr
      00681C E0               [24] 2471 	movx	a,@dptr
      00681D F9               [12] 2472 	mov	r1,a
      00681E C3               [12] 2473 	clr	c
      00681F 74 08            [12] 2474 	mov	a,#0x08
      006821 98               [12] 2475 	subb	a,r0
      006822 E4               [12] 2476 	clr	a
      006823 99               [12] 2477 	subb	a,r1
      006824 50 0E            [24] 2478 	jnc	00252$
                                   2479 ;	free result
      006826 90 07 8C         [24] 2480 	mov	dptr,#_D0SetupLen
      006829 74 08            [12] 2481 	mov	a,#0x08
      00682B F0               [24] 2482 	movx	@dptr,a
      00682C E4               [12] 2483 	clr	a
      00682D A3               [24] 2484 	inc	dptr
      00682E F0               [24] 2485 	movx	@dptr,a
      00682F 80 03            [24] 2486 	sjmp	00252$
      006831                       2487 00228$:
                                   2488 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006831 02 5F 9A         [24] 2489 	ljmp	_control_stall
      006834                       2490 00252$:
                                   2491 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006834 90 07 FA         [24] 2492 	mov	dptr,#_control_setup_length_10000_287
      006837 E0               [24] 2493 	movx	a,@dptr
      006838 F5 19            [12] 2494 	mov	_control_setup_sloc4_1_0,a
      00683A A3               [24] 2495 	inc	dptr
      00683B E0               [24] 2496 	movx	a,@dptr
      00683C F5 1A            [12] 2497 	mov	(_control_setup_sloc4_1_0 + 1),a
      00683E E5 19            [12] 2498 	mov	a,_control_setup_sloc4_1_0
      006840 45 1A            [12] 2499 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006842 60 50            [24] 2500 	jz	00262$
                                   2501 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006844 90 07 8C         [24] 2502 	mov	dptr,#_D0SetupLen
      006847 E0               [24] 2503 	movx	a,@dptr
      006848 F8               [12] 2504 	mov	r0,a
      006849 A3               [24] 2505 	inc	dptr
      00684A E0               [24] 2506 	movx	a,@dptr
      00684B F9               [12] 2507 	mov	r1,a
      00684C C3               [12] 2508 	clr	c
      00684D E5 19            [12] 2509 	mov	a,_control_setup_sloc4_1_0
      00684F 98               [12] 2510 	subb	a,r0
      006850 E5 1A            [12] 2511 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006852 99               [12] 2512 	subb	a,r1
      006853 50 0A            [24] 2513 	jnc	00559$
                                   2514 ;	free result
      006855 90 07 8C         [24] 2515 	mov	dptr,#_D0SetupLen
      006858 E5 19            [12] 2516 	mov	a,_control_setup_sloc4_1_0
      00685A F0               [24] 2517 	movx	@dptr,a
      00685B E5 1A            [12] 2518 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00685D A3               [24] 2519 	inc	dptr
      00685E F0               [24] 2520 	movx	@dptr,a
                                   2521 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00685F                       2522 00559$:
      00685F 75 19 00         [24] 2523 	mov	_control_setup_sloc4_1_0,#0x00
      006862                       2524 00296$:
      006862 90 07 8C         [24] 2525 	mov	dptr,#_D0SetupLen
      006865 E0               [24] 2526 	movx	a,@dptr
      006866 F8               [12] 2527 	mov	r0,a
      006867 C3               [12] 2528 	clr	c
      006868 E5 19            [12] 2529 	mov	a,_control_setup_sloc4_1_0
      00686A 98               [12] 2530 	subb	a,r0
      00686B 50 46            [24] 2531 	jnc	00263$
      00686D 85 19 17         [24] 2532 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      006870 74 10            [12] 2533 	mov	a,#0x10
      006872 24 00            [12] 2534 	add	a, #0x00
      006874 F5 18            [12] 2535 	mov	(_control_setup_sloc3_1_0 + 1),a
      006876 90 07 FC         [24] 2536 	mov	dptr,#_control_setup_offset_10000_287
      006879 E0               [24] 2537 	movx	a,@dptr
      00687A 25 19            [12] 2538 	add	a, _control_setup_sloc4_1_0
      00687C 24 BC            [12] 2539 	add	a, #_input_snapshot
      00687E F5 82            [12] 2540 	mov	dpl,a
      006880 E4               [12] 2541 	clr	a
      006881 34 07            [12] 2542 	addc	a,#(_input_snapshot >> 8)
      006883 F5 83            [12] 2543 	mov	dph,a
      006885 E0               [24] 2544 	movx	a,@dptr
      006886 85 17 82         [24] 2545 	mov	dpl,_control_setup_sloc3_1_0
      006889 85 18 83         [24] 2546 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00688C F0               [24] 2547 	movx	@dptr,a
      00688D E5 19            [12] 2548 	mov	a,_control_setup_sloc4_1_0
      00688F 04               [12] 2549 	inc	a
      006890 F5 19            [12] 2550 	mov	_control_setup_sloc4_1_0,a
      006892 80 CE            [24] 2551 	sjmp	00296$
      006894                       2552 00262$:
                                   2553 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006894 BB 01 1C         [24] 2554 	cjne	r3,#0x01,00263$
      006897 BC 00 19         [24] 2555 	cjne	r4,#0x00,00263$
      00689A 90 07 8C         [24] 2556 	mov	dptr,#_D0SetupLen
      00689D E0               [24] 2557 	movx	a,@dptr
      00689E F8               [12] 2558 	mov	r0,a
      00689F A3               [24] 2559 	inc	dptr
      0068A0 E0               [24] 2560 	movx	a,@dptr
      0068A1 F9               [12] 2561 	mov	r1,a
      0068A2 C3               [12] 2562 	clr	c
      0068A3 74 20            [12] 2563 	mov	a,#0x20
      0068A5 98               [12] 2564 	subb	a,r0
      0068A6 E4               [12] 2565 	clr	a
      0068A7 99               [12] 2566 	subb	a,r1
      0068A8 50 09            [24] 2567 	jnc	00263$
                                   2568 ;	free result
      0068AA 90 07 8C         [24] 2569 	mov	dptr,#_D0SetupLen
      0068AD 74 20            [12] 2570 	mov	a,#0x20
      0068AF F0               [24] 2571 	movx	@dptr,a
      0068B0 E4               [12] 2572 	clr	a
      0068B1 A3               [24] 2573 	inc	dptr
      0068B2 F0               [24] 2574 	movx	@dptr,a
      0068B3                       2575 00263$:
                                   2576 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      0068B3 90 07 8C         [24] 2577 	mov	dptr,#_D0SetupLen
      0068B6 E0               [24] 2578 	movx	a,@dptr
      0068B7 90 22 08         [24] 2579 	mov	dptr,#0x2208
      0068BA F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      0068BB 90 07 F0         [24] 2582 	mov	dptr,#_control_phase
      0068BE 74 02            [12] 2583 	mov	a,#0x02
      0068C0 F0               [24] 2584 	movx	@dptr,a
      0068C1 02 69 49         [24] 2585 	ljmp	00291$
      0068C4                       2586 00273$:
                                   2587 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0068C4 EB               [12] 2588 	mov	a,r3
      0068C5 4C               [12] 2589 	orl	a,r4
      0068C6 70 37            [24] 2590 	jnz	00265$
      0068C8 90 07 91         [24] 2591 	mov	dptr,#_D0UsbConfig
      0068CB E0               [24] 2592 	movx	a,@dptr
      0068CC 60 31            [24] 2593 	jz	00265$
      0068CE EA               [12] 2594 	mov	a,r2
      0068CF 60 2E            [24] 2595 	jz	00265$
      0068D1 90 07 8B         [24] 2596 	mov	dptr,#_D0SetupReqCode
      0068D4 E0               [24] 2597 	movx	a,@dptr
      0068D5 FA               [12] 2598 	mov	r2,a
      0068D6 BA 03 26         [24] 2599 	cjne	r2,#0x03,00265$
      0068D9 30 19 23         [24] 2600 	jnb	_control_setup_zero_value_10000_287,00265$
      0068DC 90 07 8C         [24] 2601 	mov	dptr,#_D0SetupLen
      0068DF E0               [24] 2602 	movx	a,@dptr
      0068E0 F9               [12] 2603 	mov	r1,a
      0068E1 A3               [24] 2604 	inc	dptr
      0068E2 E0               [24] 2605 	movx	a,@dptr
      0068E3 FA               [12] 2606 	mov	r2,a
      0068E4 B9 01 18         [24] 2607 	cjne	r1,#0x01,00265$
      0068E7 BA 00 15         [24] 2608 	cjne	r2,#0x00,00265$
                                   2609 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      0068EA 90 0D E5         [24] 2610 	mov	dptr,#_keyboard_protocol
      0068ED E0               [24] 2611 	movx	a,@dptr
      0068EE 90 10 00         [24] 2612 	mov	dptr,#0x1000
      0068F1 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      0068F2 90 22 08         [24] 2615 	mov	dptr,#0x2208
      0068F5 74 01            [12] 2616 	mov	a,#0x01
      0068F7 F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      0068F8 90 07 F0         [24] 2619 	mov	dptr,#_control_phase
      0068FB 04               [12] 2620 	inc	a
      0068FC F0               [24] 2621 	movx	@dptr,a
      0068FD 80 4A            [24] 2622 	sjmp	00291$
      0068FF                       2623 00265$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2625 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      0068FF 02 5F 9A         [24] 2626 	ljmp	_control_stall
      006902                       2627 00282$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006902 30 17 3E         [24] 2629 	jnb	_control_setup_valid_interface_10000_287,00284$
      006905 90 07 91         [24] 2630 	mov	dptr,#_D0UsbConfig
      006908 E0               [24] 2631 	movx	a,@dptr
      006909 60 38            [24] 2632 	jz	00284$
      00690B BF A1 35         [24] 2633 	cjne	r7,#0xa1,00284$
      00690E 8E 05            [24] 2634 	mov	ar5,r6
      006910 7E 00            [12] 2635 	mov	r6,#0x00
      006912 ED               [12] 2636 	mov	a,r5
      006913 4E               [12] 2637 	orl	a,r6
      006914 70 2D            [24] 2638 	jnz	00284$
      006916 90 07 8C         [24] 2639 	mov	dptr,#_D0SetupLen
      006919 E0               [24] 2640 	movx	a,@dptr
      00691A FE               [12] 2641 	mov	r6,a
      00691B A3               [24] 2642 	inc	dptr
      00691C E0               [24] 2643 	movx	a,@dptr
      00691D FF               [12] 2644 	mov	r7,a
      00691E BE 01 22         [24] 2645 	cjne	r6,#0x01,00284$
      006921 BF 00 1F         [24] 2646 	cjne	r7,#0x00,00284$
                                   2647 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006924 EB               [12] 2648 	mov	a,r3
      006925 4C               [12] 2649 	orl	a,r4
      006926 70 07            [24] 2650 	jnz	00324$
      006928 90 06 53         [24] 2651 	mov	dptr,#_keyboard_idle
      00692B E0               [24] 2652 	movx	a,@dptr
      00692C FF               [12] 2653 	mov	r7,a
      00692D 80 02            [24] 2654 	sjmp	00325$
      00692F                       2655 00324$:
      00692F 7F 00            [12] 2656 	mov	r7,#0x00
      006931                       2657 00325$:
      006931 90 10 00         [24] 2658 	mov	dptr,#0x1000
      006934 EF               [12] 2659 	mov	a,r7
      006935 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006936 90 22 08         [24] 2662 	mov	dptr,#0x2208
      006939 74 01            [12] 2663 	mov	a,#0x01
      00693B F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      00693C 90 07 F0         [24] 2666 	mov	dptr,#_control_phase
      00693F 04               [12] 2667 	inc	a
      006940 F0               [24] 2668 	movx	@dptr,a
      006941 80 06            [24] 2669 	sjmp	00291$
      006943                       2670 00284$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2672 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006943 02 5F 9A         [24] 2673 	ljmp	_control_stall
      006946                       2674 00290$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006946 02 5F 9A         [24] 2676 	ljmp	_control_stall
      006949                       2677 00291$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006949 90 22 00         [24] 2679 	mov	dptr,#0x2200
      00694C 74 C0            [12] 2680 	mov	a,#0xc0
      00694E F0               [24] 2681 	movx	@dptr,a
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      00694F 22               [24] 2683 	ret
                                   2684 ;------------------------------------------------------------
                                   2685 ;Allocation info for local variables in function 'control_out'
                                   2686 ;------------------------------------------------------------
                                   2687 ;i             Allocated with name '_control_out_i_10000_371'
                                   2688 ;------------------------------------------------------------
                                   2689 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2690 ;	-----------------------------------------
                                   2691 ;	 function control_out
                                   2692 ;	-----------------------------------------
      006950                       2693 _control_out:
                                   2694 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006950 90 22 0F         [24] 2695 	mov	dptr,#0x220f
      006953 E0               [24] 2696 	movx	a,@dptr
      006954 20 E6 01         [24] 2697 	jb	acc.6,00102$
      006957 22               [24] 2698 	ret
      006958                       2699 00102$:
                                   2700 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006958 90 07 F0         [24] 2701 	mov	dptr,#_control_phase
      00695B E0               [24] 2702 	movx	a,@dptr
      00695C FF               [12] 2703 	mov	r7,a
      00695D BF 02 12         [24] 2704 	cjne	r7,#0x02,00104$
      006960 90 22 0E         [24] 2705 	mov	dptr,#0x220e
      006963 E0               [24] 2706 	movx	a,@dptr
      006964 70 0C            [24] 2707 	jnz	00104$
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006966 90 07 F0         [24] 2709 	mov	dptr,#_control_phase
      006969 E4               [12] 2710 	clr	a
      00696A F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00696B 90 22 00         [24] 2713 	mov	dptr,#0x2200
      00696E 74 02            [12] 2714 	mov	a,#0x02
      006970 F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006971 22               [24] 2717 	ret
      006972                       2718 00104$:
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006972 BF 04 19         [24] 2720 	cjne	r7,#0x04,00106$
      006975 90 22 0E         [24] 2721 	mov	dptr,#0x220e
      006978 E0               [24] 2722 	movx	a,@dptr
      006979 FF               [12] 2723 	mov	r7,a
      00697A 90 07 8C         [24] 2724 	mov	dptr,#_D0SetupLen
      00697D E0               [24] 2725 	movx	a,@dptr
      00697E FD               [12] 2726 	mov	r5,a
      00697F A3               [24] 2727 	inc	dptr
      006980 E0               [24] 2728 	movx	a,@dptr
      006981 FE               [12] 2729 	mov	r6,a
      006982 7C 00            [12] 2730 	mov	r4,#0x00
      006984 EF               [12] 2731 	mov	a,r7
      006985 B5 05 06         [24] 2732 	cjne	a,ar5,00209$
      006988 EC               [12] 2733 	mov	a,r4
      006989 B5 06 02         [24] 2734 	cjne	a,ar6,00209$
      00698C 80 03            [24] 2735 	sjmp	00107$
      00698E                       2736 00209$:
      00698E                       2737 00106$:
      00698E 02 5F 9A         [24] 2738 	ljmp	_control_stall
      006991                       2739 00107$:
                                   2740 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006991 90 07 F1         [24] 2741 	mov	dptr,#_output_kind
      006994 E0               [24] 2742 	movx	a,@dptr
      006995 FF               [12] 2743 	mov	r7,a
      006996 BF 01 2E         [24] 2744 	cjne	r7,#0x01,00118$
      006999 90 07 99         [24] 2745 	mov	dptr,#_raw_state
      00699C E0               [24] 2746 	movx	a,@dptr
      00699D FE               [12] 2747 	mov	r6,a
      00699E BE 01 26         [24] 2748 	cjne	r6,#0x01,00118$
                                   2749 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0069A1 7E 00            [12] 2750 	mov	r6,#0x00
      0069A3                       2751 00121$:
      0069A3 EE               [12] 2752 	mov	a,r6
      0069A4 24 9A            [12] 2753 	add	a, #_raw_buffer
      0069A6 FC               [12] 2754 	mov	r4,a
      0069A7 E4               [12] 2755 	clr	a
      0069A8 34 07            [12] 2756 	addc	a, #(_raw_buffer >> 8)
      0069AA FD               [12] 2757 	mov	r5,a
      0069AB 8E 82            [24] 2758 	mov	dpl,r6
      0069AD 74 10            [12] 2759 	mov	a,#0x10
      0069AF 24 00            [12] 2760 	add	a, #0x00
      0069B1 F5 83            [12] 2761 	mov	dph,a
      0069B3 E0               [24] 2762 	movx	a,@dptr
      0069B4 8C 82            [24] 2763 	mov	dpl,r4
      0069B6 8D 83            [24] 2764 	mov	dph,r5
      0069B8 F0               [24] 2765 	movx	@dptr,a
      0069B9 0E               [12] 2766 	inc	r6
      0069BA BE 20 00         [24] 2767 	cjne	r6,#0x20,00214$
      0069BD                       2768 00214$:
      0069BD 40 E4            [24] 2769 	jc	00121$
                                   2770 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0069BF 90 07 99         [24] 2771 	mov	dptr,#_raw_state
      0069C2 74 02            [12] 2772 	mov	a,#0x02
      0069C4 F0               [24] 2773 	movx	@dptr,a
      0069C5 80 2B            [24] 2774 	sjmp	00119$
      0069C7                       2775 00118$:
                                   2776 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0069C7 BF 02 0A         [24] 2777 	cjne	r7,#0x02,00115$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0069CA 90 10 00         [24] 2779 	mov	dptr,#0x1000
      0069CD E0               [24] 2780 	movx	a,@dptr
      0069CE 90 07 96         [24] 2781 	mov	dptr,#_KB_USB_SetReport
      0069D1 F0               [24] 2782 	movx	@dptr,a
      0069D2 80 1E            [24] 2783 	sjmp	00119$
      0069D4                       2784 00115$:
                                   2785 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0069D4 BF 03 18         [24] 2786 	cjne	r7,#0x03,00111$
      0069D7 90 10 00         [24] 2787 	mov	dptr,#0x1000
      0069DA E0               [24] 2788 	movx	a,@dptr
      0069DB FF               [12] 2789 	mov	r7,a
      0069DC 90 07 F2         [24] 2790 	mov	dptr,#_output_report_id
      0069DF E0               [24] 2791 	movx	a,@dptr
      0069E0 FE               [12] 2792 	mov	r6,a
      0069E1 EF               [12] 2793 	mov	a,r7
      0069E2 B5 06 0A         [24] 2794 	cjne	a,ar6,00111$
                                   2795 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      0069E5 90 10 01         [24] 2796 	mov	dptr,#0x1001
      0069E8 E0               [24] 2797 	movx	a,@dptr
      0069E9 90 07 96         [24] 2798 	mov	dptr,#_KB_USB_SetReport
      0069EC F0               [24] 2799 	movx	@dptr,a
      0069ED 80 03            [24] 2800 	sjmp	00119$
      0069EF                       2801 00111$:
                                   2802 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      0069EF 02 5F 9A         [24] 2803 	ljmp	_control_stall
      0069F2                       2804 00119$:
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      0069F2 90 07 F1         [24] 2806 	mov	dptr,#_output_kind
      0069F5 E4               [12] 2807 	clr	a
      0069F6 F0               [24] 2808 	movx	@dptr,a
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      0069F7 90 07 8C         [24] 2810 	mov	dptr,#_D0SetupLen
      0069FA F0               [24] 2811 	movx	@dptr,a
      0069FB A3               [24] 2812 	inc	dptr
      0069FC F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      0069FD 90 07 F0         [24] 2815 	mov	dptr,#_control_phase
      006A00 74 03            [12] 2816 	mov	a,#0x03
      006A02 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006A03 90 22 08         [24] 2819 	mov	dptr,#0x2208
      006A06 E4               [12] 2820 	clr	a
      006A07 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006A08 F5 82            [12] 2823 	mov	dpl,a
      006A0A 74 48            [12] 2824 	mov	a,#0x48
      006A0C F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006A0D 22               [24] 2827 	ret
                                   2828 ;------------------------------------------------------------
                                   2829 ;Allocation info for local variables in function 'control_in'
                                   2830 ;------------------------------------------------------------
                                   2831 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2832 ;	-----------------------------------------
                                   2833 ;	 function control_in
                                   2834 ;	-----------------------------------------
      006A0E                       2835 _control_in:
                                   2836 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006A0E 90 07 F0         [24] 2837 	mov	dptr,#_control_phase
      006A11 E0               [24] 2838 	movx	a,@dptr
      006A12 FF               [12] 2839 	mov	r7,a
      006A13 BF 01 22         [24] 2840 	cjne	r7,#0x01,00109$
                                   2841 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006A16 90 07 8C         [24] 2842 	mov	dptr,#_D0SetupLen
      006A19 E0               [24] 2843 	movx	a,@dptr
      006A1A FD               [12] 2844 	mov	r5,a
      006A1B A3               [24] 2845 	inc	dptr
      006A1C E0               [24] 2846 	movx	a,@dptr
      006A1D 4D               [12] 2847 	orl	a,r5
      006A1E 70 06            [24] 2848 	jnz	00101$
      006A20 90 07 F3         [24] 2849 	mov	dptr,#_control_zlp
      006A23 E0               [24] 2850 	movx	a,@dptr
      006A24 60 0A            [24] 2851 	jz	00102$
      006A26                       2852 00101$:
                                   2853 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006A26 90 22 00         [24] 2854 	mov	dptr,#0x2200
      006A29 E0               [24] 2855 	movx	a,@dptr
      006A2A 64 40            [12] 2856 	xrl	a,#0x40
      006A2C F0               [24] 2857 	movx	@dptr,a
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2859 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006A2D 02 5F BC         [24] 2860 	ljmp	_control_next
      006A30                       2861 00102$:
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006A30 90 07 F0         [24] 2863 	mov	dptr,#_control_phase
      006A33 74 02            [12] 2864 	mov	a,#0x02
      006A35 F0               [24] 2865 	movx	@dptr,a
      006A36 80 18            [24] 2866 	sjmp	00110$
      006A38                       2867 00109$:
                                   2868 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006A38 BF 03 15         [24] 2869 	cjne	r7,#0x03,00110$
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006A3B 90 07 8B         [24] 2871 	mov	dptr,#_D0SetupReqCode
      006A3E E0               [24] 2872 	movx	a,@dptr
      006A3F FF               [12] 2873 	mov	r7,a
      006A40 BF 05 08         [24] 2874 	cjne	r7,#0x05,00105$
      006A43 90 07 8C         [24] 2875 	mov	dptr,#_D0SetupLen
      006A46 E0               [24] 2876 	movx	a,@dptr
      006A47 90 22 07         [24] 2877 	mov	dptr,#0x2207
      006A4A F0               [24] 2878 	movx	@dptr,a
      006A4B                       2879 00105$:
                                   2880 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006A4B 90 07 F0         [24] 2881 	mov	dptr,#_control_phase
      006A4E E4               [12] 2882 	clr	a
      006A4F F0               [24] 2883 	movx	@dptr,a
      006A50                       2884 00110$:
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A50 90 22 00         [24] 2886 	mov	dptr,#0x2200
      006A53 74 82            [12] 2887 	mov	a,#0x82
      006A55 F0               [24] 2888 	movx	@dptr,a
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006A56 22               [24] 2890 	ret
                                   2891 ;------------------------------------------------------------
                                   2892 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2893 ;------------------------------------------------------------
                                   2894 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2895 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2896 ;------------------------------------------------------------
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2898 ;	-----------------------------------------
                                   2899 ;	 function USB_DeviceInterrupt
                                   2900 ;	-----------------------------------------
      006A57                       2901 _USB_DeviceInterrupt:
                                   2902 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006A57                       2903 00129$:
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006A57 90 22 3D         [24] 2905 	mov	dptr,#0x223d
      006A5A E0               [24] 2906 	movx	a,@dptr
      006A5B 30 E0 4B         [24] 2907 	jnb	acc.0,00127$
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      006A5E 12 5F 3D         [24] 2909 	lcall	_endpoints_reset
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006A61 90 22 07         [24] 2911 	mov	dptr,#0x2207
      006A64 E4               [12] 2912 	clr	a
      006A65 F0               [24] 2913 	movx	@dptr,a
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A66 90 07 93         [24] 2915 	mov	dptr,#_USB_SleepStatus
      006A69 F0               [24] 2916 	movx	@dptr,a
      006A6A 90 07 92         [24] 2917 	mov	dptr,#_USB_EnumStatus
      006A6D F0               [24] 2918 	movx	@dptr,a
      006A6E 90 07 91         [24] 2919 	mov	dptr,#_D0UsbConfig
      006A71 F0               [24] 2920 	movx	@dptr,a
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006A72 90 07 96         [24] 2922 	mov	dptr,#_KB_USB_SetReport
      006A75 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006A76 90 0D E5         [24] 2925 	mov	dptr,#_keyboard_protocol
      006A79 04               [12] 2926 	inc	a
      006A7A F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      006A7B 90 06 53         [24] 2929 	mov	dptr,#_keyboard_idle
      006A7E E4               [12] 2930 	clr	a
      006A7F F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006A80 90 07 BB         [24] 2933 	mov	dptr,#_keyboard_reset
      006A83 04               [12] 2934 	inc	a
      006A84 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006A85 90 07 8B         [24] 2937 	mov	dptr,#_D0SetupReqCode
      006A88 74 FF            [12] 2938 	mov	a,#0xff
      006A8A F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      006A8B 90 07 8C         [24] 2941 	mov	dptr,#_D0SetupLen
      006A8E E4               [12] 2942 	clr	a
      006A8F F0               [24] 2943 	movx	@dptr,a
      006A90 A3               [24] 2944 	inc	dptr
      006A91 F0               [24] 2945 	movx	@dptr,a
                                   2946 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006A92 90 07 F0         [24] 2947 	mov	dptr,#_control_phase
      006A95 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A96 90 22 00         [24] 2950 	mov	dptr,#0x2200
      006A99 74 02            [12] 2951 	mov	a,#0x02
      006A9B F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      006A9C 90 22 0F         [24] 2954 	mov	dptr,#0x220f
      006A9F E4               [12] 2955 	clr	a
      006AA0 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006AA1 90 22 3D         [24] 2958 	mov	dptr,#0x223d
      006AA4 04               [12] 2959 	inc	a
      006AA5 F0               [24] 2960 	movx	@dptr,a
      006AA6 02 6B 3C         [24] 2961 	ljmp	00130$
      006AA9                       2962 00127$:
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006AA9 90 22 3D         [24] 2964 	mov	dptr,#0x223d
      006AAC E0               [24] 2965 	movx	a,@dptr
      006AAD 30 E5 60         [24] 2966 	jnb	acc.5,00124$
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006AB0 90 22 0F         [24] 2968 	mov	dptr,#0x220f
      006AB3 E0               [24] 2969 	movx	a,@dptr
      006AB4 FF               [12] 2970 	mov	r7,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006AB5 74 07            [12] 2972 	mov	a,#0x07
      006AB7 5F               [12] 2973 	anl	a,r7
      006AB8 FE               [12] 2974 	mov	r6,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006AB9 EF               [12] 2976 	mov	a,r7
      006ABA 54 18            [12] 2977 	anl	a,#0x18
      006ABC 70 08            [24] 2978 	jnz	00115$
      006ABE EE               [12] 2979 	mov	a,r6
      006ABF 70 05            [24] 2980 	jnz	00115$
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006AC1 12 69 50         [24] 2982 	lcall	_control_out
      006AC4 80 43            [24] 2983 	sjmp	00116$
      006AC6                       2984 00115$:
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006AC6 8F 05            [24] 2986 	mov	ar5,r7
      006AC8 74 18            [12] 2987 	mov	a,#0x18
      006ACA 5D               [12] 2988 	anl	a,r5
      006ACB FC               [12] 2989 	mov	r4,a
      006ACC BC 10 2D         [24] 2990 	cjne	r4,#0x10,00112$
                                   2991 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006ACF EE               [12] 2992 	mov	a,r6
      006AD0 70 05            [24] 2993 	jnz	00106$
      006AD2 12 6A 0E         [24] 2994 	lcall	_control_in
      006AD5 80 32            [24] 2995 	sjmp	00116$
      006AD7                       2996 00106$:
                                   2997 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006AD7 EE               [12] 2998 	mov	a,r6
      006AD8 24 FC            [12] 2999 	add	a,#0xff - 0x03
      006ADA 40 2D            [24] 3000 	jc	00116$
                                   3001 ;	free result
                                   3002 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006ADC 8E 04            [24] 3003 	mov	ar4,r6
      006ADE 7B 00            [12] 3004 	mov	r3,#0x00
      006AE0 74 22            [12] 3005 	mov	a,#0x22
      006AE2 2B               [12] 3006 	add	a, r3
      006AE3 FB               [12] 3007 	mov	r3,a
      006AE4 8C 82            [24] 3008 	mov	dpl,r4
      006AE6 8B 83            [24] 3009 	mov	dph,r3
      006AE8 E0               [24] 3010 	movx	a,@dptr
      006AE9 FA               [12] 3011 	mov	r2,a
      006AEA 74 FC            [12] 3012 	mov	a,#0xfc
      006AEC 5A               [12] 3013 	anl	a,r2
      006AED 44 02            [12] 3014 	orl	a,#0x02
      006AEF 8C 82            [24] 3015 	mov	dpl,r4
      006AF1 8B 83            [24] 3016 	mov	dph,r3
      006AF3 F0               [24] 3017 	movx	@dptr,a
                                   3018 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006AF4 BE 03 12         [24] 3019 	cjne	r6,#0x03,00116$
      006AF7 12 5F 20         [24] 3020 	lcall	_raw_complete
      006AFA 80 0D            [24] 3021 	sjmp	00116$
      006AFC                       3022 00112$:
                                   3023 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006AFC 53 05 18         [24] 3024 	anl	ar5,#0x18
      006AFF BD 18 07         [24] 3025 	cjne	r5,#0x18,00116$
      006B02 EF               [12] 3026 	mov	a,r7
      006B03 30 E5 03         [24] 3027 	jnb	acc.5,00116$
                                   3028 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006B06 12 61 B3         [24] 3029 	lcall	_control_setup
      006B09                       3030 00116$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006B09 90 22 0F         [24] 3032 	mov	dptr,#0x220f
      006B0C E4               [12] 3033 	clr	a
      006B0D F0               [24] 3034 	movx	@dptr,a
      006B0E 80 2C            [24] 3035 	sjmp	00130$
      006B10                       3036 00124$:
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006B10 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006B13 E0               [24] 3039 	movx	a,@dptr
      006B14 30 E2 25         [24] 3040 	jnb	acc.2,00130$
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006B17 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      006B1A E0               [24] 3043 	movx	a,@dptr
      006B1B 30 E3 0A         [24] 3044 	jnb	acc.3,00119$
      006B1E 90 07 93         [24] 3045 	mov	dptr,#_USB_SleepStatus
      006B21 E0               [24] 3046 	movx	a,@dptr
      006B22 43 E0 02         [24] 3047 	orl	acc,#0x02
      006B25 F0               [24] 3048 	movx	@dptr,a
      006B26 80 0E            [24] 3049 	sjmp	00120$
      006B28                       3050 00119$:
                                   3051 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006B28 90 07 93         [24] 3052 	mov	dptr,#_USB_SleepStatus
      006B2B E0               [24] 3053 	movx	a,@dptr
      006B2C 53 E0 FD         [24] 3054 	anl	acc,#0xfd
      006B2F F0               [24] 3055 	movx	@dptr,a
                                   3056 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006B30 90 07 BB         [24] 3057 	mov	dptr,#_keyboard_reset
      006B33 74 01            [12] 3058 	mov	a,#0x01
      006B35 F0               [24] 3059 	movx	@dptr,a
      006B36                       3060 00120$:
                                   3061 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006B36 90 22 3D         [24] 3062 	mov	dptr,#0x223d
      006B39 74 04            [12] 3063 	mov	a,#0x04
      006B3B F0               [24] 3064 	movx	@dptr,a
      006B3C                       3065 00130$:
                                   3066 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006B3C 90 22 3D         [24] 3067 	mov	dptr,#0x223d
      006B3F E0               [24] 3068 	movx	a,@dptr
      006B40 54 25            [12] 3069 	anl	a,#0x25
      006B42 60 03            [24] 3070 	jz	00242$
      006B44 02 6A 57         [24] 3071 	ljmp	00129$
      006B47                       3072 00242$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006B47 22               [24] 3074 	ret
                                   3075 ;------------------------------------------------------------
                                   3076 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3077 ;------------------------------------------------------------
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3079 ;	-----------------------------------------
                                   3080 ;	 function USB_Device_Init
                                   3081 ;	-----------------------------------------
      006B48                       3082 _USB_Device_Init:
                                   3083 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3084 ;	assignBit
      006B48 C2 E9            [12] 3085 	clr	_IE_USB
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006B4A 90 22 3C         [24] 3087 	mov	dptr,#0x223c
      006B4D E4               [12] 3088 	clr	a
      006B4E F0               [24] 3089 	movx	@dptr,a
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006B4F 90 07 99         [24] 3091 	mov	dptr,#_raw_state
      006B52 F0               [24] 3092 	movx	@dptr,a
                                   3093 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006B53 12 5F 3D         [24] 3094 	lcall	_endpoints_reset
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B56 90 07 93         [24] 3096 	mov	dptr,#_USB_SleepStatus
      006B59 E4               [12] 3097 	clr	a
      006B5A F0               [24] 3098 	movx	@dptr,a
      006B5B 90 07 92         [24] 3099 	mov	dptr,#_USB_EnumStatus
      006B5E F0               [24] 3100 	movx	@dptr,a
      006B5F 90 07 91         [24] 3101 	mov	dptr,#_D0UsbConfig
      006B62 F0               [24] 3102 	movx	@dptr,a
      006B63 90 22 07         [24] 3103 	mov	dptr,#0x2207
      006B66 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006B67 90 07 94         [24] 3106 	mov	dptr,#_MCU_Sleep_Operate
      006B6A F0               [24] 3107 	movx	@dptr,a
      006B6B 90 07 95         [24] 3108 	mov	dptr,#_KB_USB_UpStatus
      006B6E F0               [24] 3109 	movx	@dptr,a
      006B6F 90 07 96         [24] 3110 	mov	dptr,#_KB_USB_SetReport
      006B72 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006B73 90 0D E5         [24] 3113 	mov	dptr,#_keyboard_protocol
      006B76 04               [12] 3114 	inc	a
      006B77 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006B78 90 06 53         [24] 3117 	mov	dptr,#_keyboard_idle
      006B7B E4               [12] 3118 	clr	a
      006B7C F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006B7D 90 07 BB         [24] 3121 	mov	dptr,#_keyboard_reset
      006B80 F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006B81 90 07 F0         [24] 3124 	mov	dptr,#_control_phase
      006B84 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006B85 90 07 8B         [24] 3127 	mov	dptr,#_D0SetupReqCode
      006B88 14               [12] 3128 	dec	a
      006B89 F0               [24] 3129 	movx	@dptr,a
                                   3130 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006B8A 90 07 8C         [24] 3131 	mov	dptr,#_D0SetupLen
      006B8D E4               [12] 3132 	clr	a
      006B8E F0               [24] 3133 	movx	@dptr,a
      006B8F A3               [24] 3134 	inc	dptr
      006B90 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B91 90 22 00         [24] 3137 	mov	dptr,#0x2200
      006B94 74 02            [12] 3138 	mov	a,#0x02
      006B96 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006B97 90 22 37         [24] 3141 	mov	dptr,#0x2237
      006B9A 74 7F            [12] 3142 	mov	a,#0x7f
      006B9C F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006B9D 90 22 3D         [24] 3145 	mov	dptr,#0x223d
      006BA0 74 FF            [12] 3146 	mov	a,#0xff
      006BA2 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006BA3 90 22 3B         [24] 3149 	mov	dptr,#0x223b
      006BA6 74 07            [12] 3150 	mov	a,#0x07
      006BA8 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006BA9 A3               [24] 3153 	inc	dptr
      006BAA 74 80            [12] 3154 	mov	a,#0x80
      006BAC F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3157 ;	assignBit
      006BAD D2 E9            [12] 3158 	setb	_IE_USB
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006BAF 22               [24] 3160 	ret
                                   3161 ;------------------------------------------------------------
                                   3162 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3163 ;------------------------------------------------------------
                                   3164 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3165 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3166 ;------------------------------------------------------------
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3168 ;	-----------------------------------------
                                   3169 ;	 function USB_WakeUp_PC
                                   3170 ;	-----------------------------------------
      006BB0                       3171 _USB_WakeUp_PC:
                                   3172 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006BB0 90 07 93         [24] 3173 	mov	dptr,#_USB_SleepStatus
      006BB3 E0               [24] 3174 	movx	a,@dptr
      006BB4 FF               [12] 3175 	mov	r7,a
      006BB5 BF 03 22         [24] 3176 	cjne	r7,#0x03,00110$
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006BB8 90 22 3C         [24] 3178 	mov	dptr,#0x223c
      006BBB E0               [24] 3179 	movx	a,@dptr
      006BBC FF               [12] 3180 	mov	r7,a
                                   3181 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006BBD E0               [24] 3182 	movx	a,@dptr
      006BBE FE               [12] 3183 	mov	r6,a
      006BBF 63 06 C0         [24] 3184 	xrl	ar6,#0xc0
      006BC2 90 22 3C         [24] 3185 	mov	dptr,#0x223c
      006BC5 EE               [12] 3186 	mov	a,r6
      006BC6 F0               [24] 3187 	movx	@dptr,a
                                   3188 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006BC7 7E 0A            [12] 3189 	mov	r6,#0x0a
      006BC9                       3190 00108$:
      006BC9 EE               [12] 3191 	mov	a,r6
      006BCA 60 09            [24] 3192 	jz	00105$
      006BCC 90 00 01         [24] 3193 	mov	dptr,#0x0001
      006BCF 12 5D 64         [24] 3194 	lcall	_mDelaymS
      006BD2 1E               [12] 3195 	dec	r6
      006BD3 80 F4            [24] 3196 	sjmp	00108$
      006BD5                       3197 00105$:
                                   3198 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006BD5 90 22 3C         [24] 3199 	mov	dptr,#0x223c
      006BD8 EF               [12] 3200 	mov	a,r7
      006BD9 F0               [24] 3201 	movx	@dptr,a
      006BDA                       3202 00110$:
                                   3203 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006BDA 22               [24] 3204 	ret
                                   3205 ;------------------------------------------------------------
                                   3206 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3207 ;------------------------------------------------------------
                                   3208 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3209 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3210 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3211 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3212 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3213 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3215 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3216 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3217 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3218 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3219 ;------------------------------------------------------------
                                   3220 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3221 ;	-----------------------------------------
                                   3222 ;	 function ak820_usb_send
                                   3223 ;	-----------------------------------------
      006BDB                       3224 _ak820_usb_send:
      006BDB E5 82            [12] 3225 	mov	a,dpl
      006BDD 90 08 00         [24] 3226 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BE0 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006BE1 90 08 01         [24] 3229 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006BE4 74 34            [12] 3230 	mov	a,#0x34
      006BE6 F0               [24] 3231 	movx	@dptr,a
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006BE7 90 08 00         [24] 3233 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BEA E0               [24] 3234 	movx	a,@dptr
      006BEB FF               [12] 3235 	mov	r7,a
      006BEC BF 01 00         [24] 3236 	cjne	r7,#0x01,00306$
      006BEF                       3237 00306$:
      006BEF 40 14            [24] 3238 	jc	00101$
      006BF1 EF               [12] 3239 	mov	a,r7
      006BF2 24 FC            [12] 3240 	add	a,#0xff - 0x03
      006BF4 40 0F            [24] 3241 	jc	00101$
                                   3242 ;	free result
      006BF6 90 07 FF         [24] 3243 	mov	dptr,#_ak820_usb_send_PARM_3
      006BF9 E0               [24] 3244 	movx	a,@dptr
      006BFA FE               [12] 3245 	mov  r6,a
      006BFB 24 BF            [12] 3246 	add	a,#0xff - 0x40
      006BFD 40 06            [24] 3247 	jc	00101$
                                   3248 ;	free result
      006BFF 90 07 92         [24] 3249 	mov	dptr,#_USB_EnumStatus
      006C02 E0               [24] 3250 	movx	a,@dptr
      006C03 70 04            [24] 3251 	jnz	00102$
      006C05                       3252 00101$:
      006C05 75 82 00         [24] 3253 	mov	dpl, #0x00
      006C08 22               [24] 3254 	ret
      006C09                       3255 00102$:
                                   3256 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006C09 BF 01 10         [24] 3257 	cjne	r7,#0x01,00118$
                                   3258 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006C0C BE 08 02         [24] 3259 	cjne	r6,#0x08,00313$
      006C0F 80 04            [24] 3260 	sjmp	00107$
      006C11                       3261 00313$:
      006C11 75 82 00         [24] 3262 	mov	dpl, #0x00
      006C14 22               [24] 3263 	ret
      006C15                       3264 00107$:
                                   3265 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006C15 90 08 01         [24] 3266 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C18 E4               [12] 3267 	clr	a
      006C19 F0               [24] 3268 	movx	@dptr,a
      006C1A 80 3C            [24] 3269 	sjmp	00119$
      006C1C                       3270 00118$:
                                   3271 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006C1C BF 02 30         [24] 3272 	cjne	r7,#0x02,00115$
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006C1F 90 07 FD         [24] 3274 	mov	dptr,#_ak820_usb_send_PARM_2
      006C22 E0               [24] 3275 	movx	a,@dptr
      006C23 FD               [12] 3276 	mov	r5,a
      006C24 A3               [24] 3277 	inc	dptr
      006C25 E0               [24] 3278 	movx	a,@dptr
      006C26 FF               [12] 3279 	mov	r7,a
      006C27 8D 82            [24] 3280 	mov	dpl,r5
      006C29 8F 83            [24] 3281 	mov	dph,r7
      006C2B E0               [24] 3282 	movx	a,@dptr
      006C2C FF               [12] 3283 	mov	r7,a
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006C2D BF 07 00         [24] 3285 	cjne	r7,#0x07,00316$
      006C30                       3286 00316$:
      006C30 50 0E            [24] 3287 	jnc	00108$
      006C32 EF               [12] 3288 	mov	a,r7
      006C33 90 BD CC         [24] 3289 	mov	dptr,#_shared_lengths
      006C36 93               [24] 3290 	movc	a,@a+dptr
      006C37 FD               [12] 3291 	mov	r5,a
      006C38 60 06            [24] 3292 	jz	00108$
      006C3A EE               [12] 3293 	mov	a,r6
      006C3B B5 05 02         [24] 3294 	cjne	a,ar5,00319$
      006C3E 80 04            [24] 3295 	sjmp	00109$
      006C40                       3296 00319$:
      006C40                       3297 00108$:
      006C40 75 82 00         [24] 3298 	mov	dpl, #0x00
      006C43 22               [24] 3299 	ret
      006C44                       3300 00109$:
                                   3301 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006C44 EF               [12] 3302 	mov	a,r7
      006C45 90 BD C5         [24] 3303 	mov	dptr,#_shared_offsets
      006C48 93               [24] 3304 	movc	a,@a+dptr
      006C49 90 08 01         [24] 3305 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C4C F0               [24] 3306 	movx	@dptr,a
      006C4D 80 09            [24] 3307 	sjmp	00119$
      006C4F                       3308 00115$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006C4F BE 20 02         [24] 3310 	cjne	r6,#0x20,00320$
      006C52 80 04            [24] 3311 	sjmp	00119$
      006C54                       3312 00320$:
      006C54 75 82 00         [24] 3313 	mov	dpl, #0x00
      006C57 22               [24] 3314 	ret
      006C58                       3315 00119$:
                                   3316 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006C58 90 07 93         [24] 3317 	mov	dptr,#_USB_SleepStatus
      006C5B E0               [24] 3318 	movx	a,@dptr
      006C5C 30 E1 07         [24] 3319 	jnb	acc.1,00184$
      006C5F 12 6B B0         [24] 3320 	lcall	_USB_WakeUp_PC
      006C62 75 82 00         [24] 3321 	mov	dpl, #0x00
      006C65 22               [24] 3322 	ret
                                   3323 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006C66                       3324 00184$:
      006C66 7F FA            [12] 3325 	mov	r7,#0xfa
      006C68                       3326 00127$:
      006C68 90 08 00         [24] 3327 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C6B E0               [24] 3328 	movx	a,@dptr
      006C6C FC               [12] 3329 	mov	r4,a
      006C6D 7D 00            [12] 3330 	mov	r5,#0x00
      006C6F 8C 02            [24] 3331 	mov	ar2,r4
      006C71 74 22            [12] 3332 	mov	a,#0x22
      006C73 2D               [12] 3333 	add	a, r5
      006C74 FB               [12] 3334 	mov	r3,a
      006C75 8A 82            [24] 3335 	mov	dpl,r2
      006C77 8B 83            [24] 3336 	mov	dph,r3
      006C79 E0               [24] 3337 	movx	a,@dptr
      006C7A 54 03            [12] 3338 	anl	a,#0x03
      006C7C 70 20            [24] 3339 	jnz	00129$
      006C7E 8F 03            [24] 3340 	mov	ar3,r7
      006C80 1F               [12] 3341 	dec	r7
      006C81 EB               [12] 3342 	mov	a,r3
      006C82 60 1A            [24] 3343 	jz	00129$
      006C84 7B 28            [12] 3344 	mov	r3,#0x28
      006C86                       3345 00141$:
      006C86 EB               [12] 3346 	mov	a,r3
      006C87 60 DF            [24] 3347 	jz	00127$
      006C89 90 00 01         [24] 3348 	mov	dptr,#0x0001
      006C8C C0 07            [24] 3349 	push	ar7
      006C8E C0 06            [24] 3350 	push	ar6
      006C90 C0 03            [24] 3351 	push	ar3
      006C92 12 5D 28         [24] 3352 	lcall	_mDelayuS
      006C95 D0 03            [24] 3353 	pop	ar3
      006C97 D0 06            [24] 3354 	pop	ar6
      006C99 D0 07            [24] 3355 	pop	ar7
      006C9B 1B               [12] 3356 	dec	r3
      006C9C 80 E8            [24] 3357 	sjmp	00141$
      006C9E                       3358 00129$:
                                   3359 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006C9E A2 AF            [12] 3360 	mov	c,_EA
      006CA0 E4               [12] 3361 	clr	a
      006CA1 33               [12] 3362 	rlc	a
      006CA2 FF               [12] 3363 	mov	r7,a
                                   3364 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3365 ;	assignBit
      006CA3 C2 AF            [12] 3366 	clr	_EA
                                   3367 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006CA5 90 07 92         [24] 3368 	mov	dptr,#_USB_EnumStatus
      006CA8 E0               [24] 3369 	movx	a,@dptr
      006CA9 60 25            [24] 3370 	jz	00130$
      006CAB 90 08 00         [24] 3371 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CAE E0               [24] 3372 	movx	a,@dptr
      006CAF FB               [12] 3373 	mov	r3,a
      006CB0 F9               [12] 3374 	mov	r1,a
      006CB1 7A 00            [12] 3375 	mov	r2,#0x00
      006CB3 74 22            [12] 3376 	mov	a,#0x22
      006CB5 2A               [12] 3377 	add	a, r2
      006CB6 FA               [12] 3378 	mov	r2,a
      006CB7 89 82            [24] 3379 	mov	dpl,r1
      006CB9 8A 83            [24] 3380 	mov	dph,r2
      006CBB E0               [24] 3381 	movx	a,@dptr
      006CBC FA               [12] 3382 	mov	r2,a
      006CBD 53 02 03         [24] 3383 	anl	ar2,#0x03
      006CC0 BA 02 0D         [24] 3384 	cjne	r2,#0x02,00130$
                                   3385 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006CC3 BB 03 13         [24] 3386 	cjne	r3,#0x03,00192$
      006CC6 90 07 99         [24] 3387 	mov	dptr,#_raw_state
      006CC9 E0               [24] 3388 	movx	a,@dptr
      006CCA FB               [12] 3389 	mov	r3,a
      006CCB BB 03 02         [24] 3390 	cjne	r3,#0x03,00331$
      006CCE 80 09            [24] 3391 	sjmp	00192$
      006CD0                       3392 00331$:
      006CD0                       3393 00130$:
                                   3394 ;	assignBit
      006CD0 EF               [12] 3395 	mov	a,r7
      006CD1 24 FF            [12] 3396 	add	a,#0xff
      006CD3 92 AF            [24] 3397 	mov	_EA,c
      006CD5 75 82 00         [24] 3398 	mov	dpl, #0x00
      006CD8 22               [24] 3399 	ret
                                   3400 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006CD9                       3401 00192$:
      006CD9 7B 00            [12] 3402 	mov	r3,#0x00
      006CDB                       3403 00144$:
      006CDB C3               [12] 3404 	clr	c
      006CDC EB               [12] 3405 	mov	a,r3
      006CDD 9E               [12] 3406 	subb	a,r6
      006CDE 50 67            [24] 3407 	jnc	00137$
                                   3408 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006CE0 C0 07            [24] 3409 	push	ar7
      006CE2 90 08 00         [24] 3410 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CE5 E0               [24] 3411 	movx	a,@dptr
      006CE6 F9               [12] 3412 	mov	r1,a
      006CE7 E4               [12] 3413 	clr	a
      006CE8 C3               [12] 3414 	clr	c
      006CE9 C9               [12] 3415 	xch	a,r1
      006CEA 13               [12] 3416 	rrc	a
      006CEB C9               [12] 3417 	xch	a,r1
      006CEC 13               [12] 3418 	rrc	a
      006CED A2 E0            [12] 3419 	mov	c,acc.0
      006CEF C9               [12] 3420 	xch	a,r1
      006CF0 13               [12] 3421 	rrc	a
      006CF1 C9               [12] 3422 	xch	a,r1
      006CF2 13               [12] 3423 	rrc	a
      006CF3 C9               [12] 3424 	xch	a,r1
      006CF4 FA               [12] 3425 	mov	r2,a
      006CF5 8B 00            [24] 3426 	mov	ar0,r3
      006CF7 7F 00            [12] 3427 	mov	r7,#0x00
      006CF9 E8               [12] 3428 	mov	a,r0
      006CFA 29               [12] 3429 	add	a, r1
      006CFB F9               [12] 3430 	mov	r1,a
      006CFC EF               [12] 3431 	mov	a,r7
      006CFD 3A               [12] 3432 	addc	a, r2
      006CFE 24 10            [12] 3433 	add	a,#0x10
      006D00 FA               [12] 3434 	mov	r2,a
      006D01 90 07 FD         [24] 3435 	mov	dptr,#_ak820_usb_send_PARM_2
      006D04 E0               [24] 3436 	movx	a,@dptr
      006D05 F8               [12] 3437 	mov	r0,a
      006D06 A3               [24] 3438 	inc	dptr
      006D07 E0               [24] 3439 	movx	a,@dptr
      006D08 FF               [12] 3440 	mov	r7,a
      006D09 EB               [12] 3441 	mov	a,r3
      006D0A 28               [12] 3442 	add	a, r0
      006D0B F5 1B            [12] 3443 	mov	_ak820_usb_send_sloc0_1_0,a
      006D0D E4               [12] 3444 	clr	a
      006D0E 3F               [12] 3445 	addc	a, r7
      006D0F F5 1C            [12] 3446 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006D11 85 1B 82         [24] 3447 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D14 85 1C 83         [24] 3448 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D17 E0               [24] 3449 	movx	a,@dptr
      006D18 89 82            [24] 3450 	mov	dpl,r1
      006D1A 8A 83            [24] 3451 	mov	dph,r2
      006D1C F0               [24] 3452 	movx	@dptr,a
                                   3453 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006D1D 90 08 01         [24] 3454 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006D20 E0               [24] 3455 	movx	a,@dptr
      006D21 F5 1D            [12] 3456 	mov	_ak820_usb_send_sloc1_1_0,a
      006D23 74 34            [12] 3457 	mov	a,#0x34
      006D25 B5 1D 04         [24] 3458 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006D28 D0 07            [24] 3459 	pop	ar7
      006D2A 80 18            [24] 3460 	sjmp	00145$
      006D2C                       3461 00333$:
      006D2C D0 07            [24] 3462 	pop	ar7
      006D2E EB               [12] 3463 	mov	a,r3
      006D2F 25 1D            [12] 3464 	add	a, _ak820_usb_send_sloc1_1_0
      006D31 24 BC            [12] 3465 	add	a, #_input_snapshot
      006D33 F9               [12] 3466 	mov	r1,a
      006D34 E4               [12] 3467 	clr	a
      006D35 34 07            [12] 3468 	addc	a,#(_input_snapshot >> 8)
      006D37 FA               [12] 3469 	mov	r2,a
      006D38 85 1B 82         [24] 3470 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D3B 85 1C 83         [24] 3471 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D3E E0               [24] 3472 	movx	a,@dptr
      006D3F 89 82            [24] 3473 	mov	dpl,r1
      006D41 8A 83            [24] 3474 	mov	dph,r2
      006D43 F0               [24] 3475 	movx	@dptr,a
      006D44                       3476 00145$:
                                   3477 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006D44 0B               [12] 3478 	inc	r3
      006D45 80 94            [24] 3479 	sjmp	00144$
      006D47                       3480 00137$:
                                   3481 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006D47 90 08 00         [24] 3482 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D4A E0               [24] 3483 	movx	a,@dptr
      006D4B FB               [12] 3484 	mov	r3,a
      006D4C F9               [12] 3485 	mov	r1,a
      006D4D 7A 00            [12] 3486 	mov	r2,#0x00
      006D4F 74 08            [12] 3487 	mov	a,#0x08
      006D51 29               [12] 3488 	add	a, r1
      006D52 F9               [12] 3489 	mov	r1,a
      006D53 74 22            [12] 3490 	mov	a,#0x22
      006D55 3A               [12] 3491 	addc	a, r2
      006D56 FA               [12] 3492 	mov	r2,a
      006D57 89 82            [24] 3493 	mov	dpl,r1
      006D59 8A 83            [24] 3494 	mov	dph,r2
      006D5B EE               [12] 3495 	mov	a,r6
      006D5C F0               [24] 3496 	movx	@dptr,a
                                   3497 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006D5D BB 03 06         [24] 3498 	cjne	r3,#0x03,00139$
      006D60 90 07 99         [24] 3499 	mov	dptr,#_raw_state
      006D63 74 04            [12] 3500 	mov	a,#0x04
      006D65 F0               [24] 3501 	movx	@dptr,a
      006D66                       3502 00139$:
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006D66 74 22            [12] 3504 	mov	a,#0x22
      006D68 2D               [12] 3505 	add	a, r5
      006D69 FD               [12] 3506 	mov	r5,a
      006D6A 8C 82            [24] 3507 	mov	dpl,r4
      006D6C 8D 83            [24] 3508 	mov	dph,r5
      006D6E E0               [24] 3509 	movx	a,@dptr
      006D6F FE               [12] 3510 	mov	r6,a
      006D70 53 06 FC         [24] 3511 	anl	ar6,#0xfc
      006D73 8C 82            [24] 3512 	mov	dpl,r4
      006D75 8D 83            [24] 3513 	mov	dph,r5
      006D77 EE               [12] 3514 	mov	a,r6
      006D78 F0               [24] 3515 	movx	@dptr,a
                                   3516 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3517 ;	assignBit
      006D79 EF               [12] 3518 	mov	a,r7
      006D7A 24 FF            [12] 3519 	add	a,#0xff
      006D7C 92 AF            [24] 3520 	mov	_EA,c
                                   3521 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006D7E 75 82 01         [24] 3522 	mov	dpl, #0x01
                                   3523 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006D81 22               [24] 3524 	ret
                                   3525 ;------------------------------------------------------------
                                   3526 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3527 ;------------------------------------------------------------
                                   3528 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3529 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3530 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3531 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3532 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3533 ;------------------------------------------------------------
                                   3534 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3535 ;	-----------------------------------------
                                   3536 ;	 function ak820_usb_try_send
                                   3537 ;	-----------------------------------------
      006D82                       3538 _ak820_usb_try_send:
      006D82 E5 82            [12] 3539 	mov	a,dpl
      006D84 90 08 05         [24] 3540 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006D87 F0               [24] 3541 	movx	@dptr,a
                                   3542 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3543 ;	assignBit
      006D88 A2 AF            [12] 3544 	mov	c,_EA
      006D8A 92 1D            [24] 3545 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006D8C 90 08 06         [24] 3547 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006D8F E4               [12] 3548 	clr	a
      006D90 F0               [24] 3549 	movx	@dptr,a
                                   3550 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3551 ;	assignBit
      006D91 C2 AF            [12] 3552 	clr	_EA
                                   3553 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006D93 90 08 05         [24] 3554 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006D96 E0               [24] 3555 	movx	a,@dptr
      006D97 FF               [12] 3556 	mov	r7,a
      006D98 BF 01 00         [24] 3557 	cjne	r7,#0x01,00152$
      006D9B                       3558 00152$:
      006D9B 40 4E            [24] 3559 	jc	00102$
      006D9D EF               [12] 3560 	mov	a,r7
      006D9E 24 FD            [12] 3561 	add	a,#0xff - 0x02
      006DA0 40 49            [24] 3562 	jc	00102$
                                   3563 ;	free result
      006DA2 90 07 92         [24] 3564 	mov	dptr,#_USB_EnumStatus
      006DA5 E0               [24] 3565 	movx	a,@dptr
      006DA6 60 43            [24] 3566 	jz	00102$
                                   3567 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006DA8 90 07 93         [24] 3568 	mov	dptr,#_USB_SleepStatus
      006DAB E0               [24] 3569 	movx	a,@dptr
      006DAC 20 E1 3C         [24] 3570 	jb	acc.1,00102$
      006DAF 90 07 BB         [24] 3571 	mov	dptr,#_keyboard_reset
      006DB2 E0               [24] 3572 	movx	a,@dptr
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006DB3 70 36            [24] 3574 	jnz	00102$
      006DB5 8F 06            [24] 3575 	mov	ar6,r7
      006DB7 24 22            [12] 3576 	add	a,#0x22
      006DB9 FD               [12] 3577 	mov	r5,a
      006DBA 8E 82            [24] 3578 	mov	dpl,r6
      006DBC 8D 83            [24] 3579 	mov	dph,r5
      006DBE E0               [24] 3580 	movx	a,@dptr
      006DBF FE               [12] 3581 	mov	r6,a
      006DC0 53 06 03         [24] 3582 	anl	ar6,#0x03
      006DC3 BE 02 25         [24] 3583 	cjne	r6,#0x02,00102$
                                   3584 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006DC6 90 08 02         [24] 3585 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006DC9 E0               [24] 3586 	movx	a,@dptr
      006DCA FD               [12] 3587 	mov	r5,a
      006DCB A3               [24] 3588 	inc	dptr
      006DCC E0               [24] 3589 	movx	a,@dptr
      006DCD FE               [12] 3590 	mov	r6,a
      006DCE 90 08 04         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006DD1 E0               [24] 3592 	movx	a,@dptr
      006DD2 FC               [12] 3593 	mov	r4,a
      006DD3 90 07 FD         [24] 3594 	mov	dptr,#_ak820_usb_send_PARM_2
      006DD6 ED               [12] 3595 	mov	a,r5
      006DD7 F0               [24] 3596 	movx	@dptr,a
      006DD8 EE               [12] 3597 	mov	a,r6
      006DD9 A3               [24] 3598 	inc	dptr
      006DDA F0               [24] 3599 	movx	@dptr,a
      006DDB 90 07 FF         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_3
      006DDE EC               [12] 3601 	mov	a,r4
      006DDF F0               [24] 3602 	movx	@dptr,a
      006DE0 8F 82            [24] 3603 	mov	dpl, r7
      006DE2 12 6B DB         [24] 3604 	lcall	_ak820_usb_send
      006DE5 E5 82            [12] 3605 	mov	a, dpl
      006DE7 90 08 06         [24] 3606 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DEA F0               [24] 3607 	movx	@dptr,a
      006DEB                       3608 00102$:
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3610 ;	assignBit
      006DEB A2 1D            [12] 3611 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006DED 92 AF            [24] 3612 	mov	_EA,c
                                   3613 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006DEF 90 08 06         [24] 3614 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DF2 E0               [24] 3615 	movx	a,@dptr
                                   3616 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006DF3 F5 82            [12] 3617 	mov	dpl,a
      006DF5 22               [24] 3618 	ret
                                   3619 ;------------------------------------------------------------
                                   3620 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3621 ;------------------------------------------------------------
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3623 ;	-----------------------------------------
                                   3624 ;	 function raw_request_is_nonpersistent
                                   3625 ;	-----------------------------------------
      006DF6                       3626 _raw_request_is_nonpersistent:
                                   3627 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006DF6 90 07 9A         [24] 3628 	mov	dptr,#_raw_buffer
      006DF9 E0               [24] 3629 	movx	a,@dptr
      006DFA FF               [12] 3630 	mov	r7,a
      006DFB BF 01 02         [24] 3631 	cjne	r7,#0x01,00302$
      006DFE 80 35            [24] 3632 	sjmp	00108$
      006E00                       3633 00302$:
      006E00 BF 02 02         [24] 3634 	cjne	r7,#0x02,00303$
      006E03 80 34            [24] 3635 	sjmp	00109$
      006E05                       3636 00303$:
      006E05 BF 04 02         [24] 3637 	cjne	r7,#0x04,00304$
      006E08 80 2B            [24] 3638 	sjmp	00108$
      006E0A                       3639 00304$:
      006E0A BF 08 02         [24] 3640 	cjne	r7,#0x08,00305$
      006E0D 80 47            [24] 3641 	sjmp	00116$
      006E0F                       3642 00305$:
      006E0F BF 0B 02         [24] 3643 	cjne	r7,#0x0b,00306$
      006E12 80 21            [24] 3644 	sjmp	00108$
      006E14                       3645 00306$:
      006E14 BF 0C 02         [24] 3646 	cjne	r7,#0x0c,00307$
      006E17 80 1C            [24] 3647 	sjmp	00108$
      006E19                       3648 00307$:
      006E19 BF 0D 02         [24] 3649 	cjne	r7,#0x0d,00308$
      006E1C 80 17            [24] 3650 	sjmp	00108$
      006E1E                       3651 00308$:
      006E1E BF 0E 02         [24] 3652 	cjne	r7,#0x0e,00309$
      006E21 80 12            [24] 3653 	sjmp	00108$
      006E23                       3654 00309$:
      006E23 BF 11 02         [24] 3655 	cjne	r7,#0x11,00310$
      006E26 80 0D            [24] 3656 	sjmp	00108$
      006E28                       3657 00310$:
      006E28 BF 12 02         [24] 3658 	cjne	r7,#0x12,00311$
      006E2B 80 08            [24] 3659 	sjmp	00108$
      006E2D                       3660 00311$:
      006E2D BF FE 02         [24] 3661 	cjne	r7,#0xfe,00312$
      006E30 80 46            [24] 3662 	sjmp	00124$
      006E32                       3663 00312$:
      006E32 02 6E CD         [24] 3664 	ljmp	00144$
                                   3665 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006E35                       3666 00108$:
                                   3667 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006E35 75 82 01         [24] 3668 	mov	dpl, #0x01
      006E38 22               [24] 3669 	ret
                                   3670 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006E39                       3671 00109$:
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006E39 12 70 FF         [24] 3673 	lcall	_ak820_outline_0169
      006E3C BF 01 02         [24] 3674 	cjne	r7,#0x01,00313$
      006E3F 80 0D            [24] 3675 	sjmp	00113$
      006E41                       3676 00313$:
      006E41 BF 02 02         [24] 3677 	cjne	r7,#0x02,00314$
      006E44 80 08            [24] 3678 	sjmp	00113$
      006E46                       3679 00314$:
      006E46 BF 03 02         [24] 3680 	cjne	r7,#0x03,00315$
      006E49 80 03            [24] 3681 	sjmp	00113$
      006E4B                       3682 00315$:
      006E4B BF 04 04         [24] 3683 	cjne	r7,#0x04,00114$
                                   3684 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006E4E                       3685 00113$:
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006E4E 75 82 01         [24] 3687 	mov	dpl, #0x01
      006E51 22               [24] 3688 	ret
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006E52                       3690 00114$:
      006E52 75 82 00         [24] 3691 	mov	dpl, #0x00
      006E55 22               [24] 3692 	ret
                                   3693 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006E56                       3694 00116$:
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006E56 12 70 FF         [24] 3696 	lcall	_ak820_outline_0169
      006E59 BF 40 02         [24] 3697 	cjne	r7,#0x40,00318$
      006E5C 80 12            [24] 3698 	sjmp	00121$
      006E5E                       3699 00318$:
      006E5E BF 41 02         [24] 3700 	cjne	r7,#0x41,00319$
      006E61 80 0D            [24] 3701 	sjmp	00121$
      006E63                       3702 00319$:
      006E63 BF 42 02         [24] 3703 	cjne	r7,#0x42,00320$
      006E66 80 08            [24] 3704 	sjmp	00121$
      006E68                       3705 00320$:
      006E68 BF 43 02         [24] 3706 	cjne	r7,#0x43,00321$
      006E6B 80 03            [24] 3707 	sjmp	00121$
      006E6D                       3708 00321$:
      006E6D BF 44 04         [24] 3709 	cjne	r7,#0x44,00122$
                                   3710 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006E70                       3711 00121$:
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006E70 75 82 01         [24] 3713 	mov	dpl, #0x01
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006E73 22               [24] 3715 	ret
      006E74                       3716 00122$:
      006E74 75 82 00         [24] 3717 	mov	dpl, #0x00
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006E77 22               [24] 3719 	ret
      006E78                       3720 00124$:
                                   3721 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006E78 12 70 FF         [24] 3722 	lcall	_ak820_outline_0169
      006E7B 24 F2            [12] 3723 	add	a,#0xff - 0x0d
      006E7D 40 4A            [24] 3724 	jc	00142$
                                   3725 ;	free result
      006E7F EF               [12] 3726 	mov	a,r7
      006E80 24 0A            [12] 3727 	add	a,#(00325$-3-.)
      006E82 83               [24] 3728 	movc	a,@a+pc
      006E83 F5 82            [12] 3729 	mov	dpl,a
      006E85 EF               [12] 3730 	mov	a,r7
      006E86 24 12            [12] 3731 	add	a,#(00326$-3-.)
      006E88 83               [24] 3732 	movc	a,@a+pc
      006E89 F5 83            [12] 3733 	mov	dph,a
      006E8B E4               [12] 3734 	clr	a
      006E8C 73               [24] 3735 	jmp	@a+dptr
      006E8D                       3736 00325$:
      006E8D A9                    3737 	.db	00134$
      006E8E A9                    3738 	.db	00134$
      006E8F A9                    3739 	.db	00134$
      006E90 A9                    3740 	.db	00134$
      006E91 C9                    3741 	.db	00142$
      006E92 A9                    3742 	.db	00134$
      006E93 A9                    3743 	.db	00134$
      006E94 A9                    3744 	.db	00134$
      006E95 A9                    3745 	.db	00134$
      006E96 A9                    3746 	.db	00134$
      006E97 A9                    3747 	.db	00134$
      006E98 C9                    3748 	.db	00142$
      006E99 C9                    3749 	.db	00142$
      006E9A AD                    3750 	.db	00135$
      006E9B                       3751 00326$:
      006E9B 6E                    3752 	.db	00134$>>8
      006E9C 6E                    3753 	.db	00134$>>8
      006E9D 6E                    3754 	.db	00134$>>8
      006E9E 6E                    3755 	.db	00134$>>8
      006E9F 6E                    3756 	.db	00142$>>8
      006EA0 6E                    3757 	.db	00134$>>8
      006EA1 6E                    3758 	.db	00134$>>8
      006EA2 6E                    3759 	.db	00134$>>8
      006EA3 6E                    3760 	.db	00134$>>8
      006EA4 6E                    3761 	.db	00134$>>8
      006EA5 6E                    3762 	.db	00134$>>8
      006EA6 6E                    3763 	.db	00142$>>8
      006EA7 6E                    3764 	.db	00142$>>8
      006EA8 6E                    3765 	.db	00135$>>8
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006EA9                       3767 00134$:
                                   3768 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006EA9 75 82 01         [24] 3769 	mov	dpl, #0x01
                                   3770 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006EAC 22               [24] 3771 	ret
      006EAD                       3772 00135$:
                                   3773 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006EAD 90 07 9C         [24] 3774 	mov	dptr,#(_raw_buffer + 0x0002)
      006EB0 E0               [24] 3775 	movx	a,@dptr
      006EB1 FF               [12] 3776 	mov	r7,a
      006EB2 60 0D            [24] 3777 	jz	00139$
      006EB4 BF 01 02         [24] 3778 	cjne	r7,#0x01,00328$
      006EB7 80 08            [24] 3779 	sjmp	00139$
      006EB9                       3780 00328$:
      006EB9 BF 03 02         [24] 3781 	cjne	r7,#0x03,00329$
      006EBC 80 03            [24] 3782 	sjmp	00139$
      006EBE                       3783 00329$:
      006EBE BF 05 04         [24] 3784 	cjne	r7,#0x05,00140$
                                   3785 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006EC1                       3786 00139$:
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006EC1 75 82 01         [24] 3788 	mov	dpl, #0x01
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006EC4 22               [24] 3790 	ret
      006EC5                       3791 00140$:
      006EC5 75 82 00         [24] 3792 	mov	dpl, #0x00
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006EC8 22               [24] 3794 	ret
      006EC9                       3795 00142$:
      006EC9 75 82 00         [24] 3796 	mov	dpl, #0x00
                                   3797 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006ECC 22               [24] 3798 	ret
      006ECD                       3799 00144$:
      006ECD 75 82 00         [24] 3800 	mov	dpl, #0x00
                                   3801 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3802 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006ED0 22               [24] 3803 	ret
                                   3804 ;------------------------------------------------------------
                                   3805 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3806 ;------------------------------------------------------------
                                   3807 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3808 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3809 ;------------------------------------------------------------
                                   3810 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3811 ;	-----------------------------------------
                                   3812 ;	 function ak820_usb_raw_send
                                   3813 ;	-----------------------------------------
      006ED1                       3814 _ak820_usb_raw_send:
      006ED1 12 45 53         [24] 3815 	lcall	_ak820_outline_0036
      006ED4 90 08 08         [24] 3816 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006ED7 12 3A 5F         [24] 3817 	lcall	_ak820_outline_0016
                                   3818 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006EDA 90 08 07         [24] 3819 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006EDD E0               [24] 3820 	movx	a,@dptr
      006EDE FF               [12] 3821 	mov	r7,a
      006EDF BF 20 2B         [24] 3822 	cjne	r7,#0x20,00106$
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006EE2 C0 07            [24] 3824 	push	ar7
      006EE4 12 40 69         [24] 3825 	lcall	_ak820_nvm_flush
      006EE7 D0 07            [24] 3826 	pop	ar7
                                   3827 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006EE9 90 07 BA         [24] 3828 	mov	dptr,#_raw_reply_without_nvm
      006EEC E0               [24] 3829 	movx	a,@dptr
      006EED 70 07            [24] 3830 	jnz	00103$
      006EEF 12 40 5A         [24] 3831 	lcall	_ak820_nvm_ok
      006EF2 E5 82            [12] 3832 	mov	a, dpl
      006EF4 60 17            [24] 3833 	jz	00106$
      006EF6                       3834 00103$:
      006EF6 90 08 08         [24] 3835 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006EF9 12 3A A4         [24] 3836 	lcall	_ak820_outline_0080
      006EFC 90 07 FD         [24] 3837 	mov	dptr,#_ak820_usb_send_PARM_2
      006EFF 12 45 BD         [24] 3838 	lcall	_ak820_outline_0167
      006F02 90 07 FF         [24] 3839 	mov	dptr,#_ak820_usb_send_PARM_3
      006F05 EF               [12] 3840 	mov	a,r7
      006F06 F0               [24] 3841 	movx	@dptr,a
      006F07 75 82 03         [24] 3842 	mov	dpl, #0x03
                                   3843 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006F0A 02 6B DB         [24] 3844 	ljmp	_ak820_usb_send
      006F0D                       3845 00106$:
      006F0D 22               [24] 3846 	ret
                                   3847 ;------------------------------------------------------------
                                   3848 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3849 ;------------------------------------------------------------
                                   3850 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3851 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3852 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3853 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3854 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3855 ;------------------------------------------------------------
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3857 ;	-----------------------------------------
                                   3858 ;	 function ak820_usb_raw_task
                                   3859 ;	-----------------------------------------
      006F0E                       3860 _ak820_usb_raw_task:
                                   3861 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006F0E A2 AF            [12] 3862 	mov	c,_EA
      006F10 E4               [12] 3863 	clr	a
      006F11 33               [12] 3864 	rlc	a
      006F12 FF               [12] 3865 	mov	r7,a
                                   3866 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3867 ;	assignBit
      006F13 C2 AF            [12] 3868 	clr	_EA
                                   3869 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006F15 90 07 92         [24] 3870 	mov	dptr,#_USB_EnumStatus
      006F18 E0               [24] 3871 	movx	a,@dptr
      006F19 60 0A            [24] 3872 	jz	00101$
      006F1B 90 07 99         [24] 3873 	mov	dptr,#_raw_state
      006F1E E0               [24] 3874 	movx	a,@dptr
      006F1F FE               [12] 3875 	mov	r6,a
      006F20 BE 02 02         [24] 3876 	cjne	r6,#0x02,00270$
      006F23 80 06            [24] 3877 	sjmp	00102$
      006F25                       3878 00270$:
      006F25                       3879 00101$:
                                   3880 ;	assignBit
      006F25 EF               [12] 3881 	mov	a,r7
      006F26 24 FF            [12] 3882 	add	a,#0xff
      006F28 92 AF            [24] 3883 	mov	_EA,c
      006F2A 22               [24] 3884 	ret
      006F2B                       3885 00102$:
                                   3886 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006F2B 90 07 99         [24] 3887 	mov	dptr,#_raw_state
      006F2E 74 03            [12] 3888 	mov	a,#0x03
      006F30 F0               [24] 3889 	movx	@dptr,a
                                   3890 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3891 ;	assignBit
      006F31 EF               [12] 3892 	mov	a,r7
      006F32 24 FF            [12] 3893 	add	a,#0xff
      006F34 92 AF            [24] 3894 	mov	_EA,c
                                   3895 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006F36 90 07 9A         [24] 3896 	mov	dptr,#_raw_buffer
      006F39 E0               [24] 3897 	movx	a,@dptr
      006F3A FF               [12] 3898 	mov	r7,a
      006F3B E4               [12] 3899 	clr	a
      006F3C BF FD 01         [24] 3900 	cjne	r7,#0xfd,00271$
      006F3F 04               [12] 3901 	inc	a
      006F40                       3902 00271$:
      006F40 FF               [12] 3903 	mov	r7,a
      006F41 70 03            [24] 3904 	jnz	00273$
      006F43 02 6F E3         [24] 3905 	ljmp	00118$
      006F46                       3906 00273$:
      006F46 90 07 9B         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0001)
      006F49 E0               [24] 3908 	movx	a,@dptr
      006F4A 60 03            [24] 3909 	jz	00274$
      006F4C 02 6F E3         [24] 3910 	ljmp	00118$
      006F4F                       3911 00274$:
                                   3912 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006F4F 90 07 9C         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0002)
      006F52 E0               [24] 3914 	movx	a,@dptr
      006F53 FD               [12] 3915 	mov	r5,a
      006F54 7E 00            [12] 3916 	mov	r6,#0x00
      006F56 90 07 9D         [24] 3917 	mov	dptr,#(_raw_buffer + 0x0003)
      006F59 E0               [24] 3918 	movx	a,@dptr
      006F5A 7B 00            [12] 3919 	mov	r3,#0x00
      006F5C 42 06            [12] 3920 	orl	ar6,a
      006F5E EB               [12] 3921 	mov	a,r3
      006F5F 42 05            [12] 3922 	orl	ar5,a
                                   3923 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006F61 90 07 9E         [24] 3924 	mov	dptr,#(_raw_buffer + 0x0004)
      006F64 E0               [24] 3925 	movx	a,@dptr
      006F65 FC               [12] 3926 	mov	r4,a
                                   3927 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F66 7B 05            [12] 3928 	mov	r3,#0x05
      006F68                       3929 00128$:
      006F68 EB               [12] 3930 	mov	a,r3
      006F69 12 70 ED         [24] 3931 	lcall	_ak820_outline_0106
      006F6C 0B               [12] 3932 	inc	r3
      006F6D BB 20 00         [24] 3933 	cjne	r3,#0x20,00275$
      006F70                       3934 00275$:
      006F70 40 F6            [24] 3935 	jc	00128$
                                   3936 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006F72 EC               [12] 3937 	mov	a,r4
      006F73 24 E4            [12] 3938 	add	a,#0xff - 0x1b
      006F75 40 1C            [24] 3939 	jc	00106$
                                   3940 ;	free result
      006F77 EC               [12] 3941 	mov	a,r4
      006F78 60 26            [24] 3942 	jz	00165$
      006F7A 8C 03            [24] 3943 	mov	ar3,r4
      006F7C 1B               [12] 3944 	dec	r3
      006F7D 7A 00            [12] 3945 	mov	r2,#0x00
      006F7F 74 FF            [12] 3946 	mov	a,#0xff
      006F81 C3               [12] 3947 	clr	c
      006F82 9B               [12] 3948 	subb	a,r3
      006F83 FB               [12] 3949 	mov	r3,a
      006F84 74 FF            [12] 3950 	mov	a,#0xff
      006F86 9A               [12] 3951 	subb	a,r2
      006F87 FA               [12] 3952 	mov	r2,a
      006F88 8E 00            [24] 3953 	mov	ar0,r6
      006F8A 8D 01            [24] 3954 	mov	ar1,r5
      006F8C C3               [12] 3955 	clr	c
      006F8D EB               [12] 3956 	mov	a,r3
      006F8E 98               [12] 3957 	subb	a,r0
      006F8F EA               [12] 3958 	mov	a,r2
      006F90 99               [12] 3959 	subb	a,r1
      006F91 50 0D            [24] 3960 	jnc	00165$
                                   3961 ;	free result
      006F93                       3962 00106$:
                                   3963 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006F93 90 07 9B         [24] 3964 	mov	dptr,#(_raw_buffer + 0x0001)
      006F96 74 FF            [12] 3965 	mov	a,#0xff
      006F98 F0               [24] 3966 	movx	@dptr,a
                                   3967 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006F99 90 07 9E         [24] 3968 	mov	dptr,#(_raw_buffer + 0x0004)
      006F9C E4               [12] 3969 	clr	a
      006F9D F0               [24] 3970 	movx	@dptr,a
                                   3971 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006F9E 80 3A            [24] 3972 	sjmp	00108$
      006FA0                       3973 00165$:
      006FA0 7B 00            [12] 3974 	mov	r3,#0x00
      006FA2                       3975 00131$:
      006FA2 C3               [12] 3976 	clr	c
      006FA3 EB               [12] 3977 	mov	a,r3
      006FA4 9C               [12] 3978 	subb	a,r4
      006FA5 50 33            [24] 3979 	jnc	00108$
      006FA7 C0 04            [24] 3980 	push	ar4
      006FA9 8B 02            [24] 3981 	mov	ar2,r3
      006FAB 74 05            [12] 3982 	mov	a,#0x05
      006FAD 2A               [12] 3983 	add	a, r2
      006FAE F9               [12] 3984 	mov	r1,a
      006FAF 33               [12] 3985 	rlc	a
      006FB0 95 E0            [12] 3986 	subb	a,acc
      006FB2 FA               [12] 3987 	mov	r2,a
      006FB3 E9               [12] 3988 	mov	a,r1
      006FB4 24 9A            [12] 3989 	add	a, #_raw_buffer
      006FB6 F9               [12] 3990 	mov	r1,a
      006FB7 EA               [12] 3991 	mov	a,r2
      006FB8 34 07            [12] 3992 	addc	a, #(_raw_buffer >> 8)
      006FBA FA               [12] 3993 	mov	r2,a
      006FBB 8B 1E            [24] 3994 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006FBD 75 1F 00         [24] 3995 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006FC0 8E 00            [24] 3996 	mov	ar0,r6
      006FC2 8D 04            [24] 3997 	mov	ar4,r5
      006FC4 E5 1E            [12] 3998 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006FC6 28               [12] 3999 	add	a, r0
      006FC7 F8               [12] 4000 	mov	r0,a
      006FC8 E5 1F            [12] 4001 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006FCA 3C               [12] 4002 	addc	a, r4
      006FCB FC               [12] 4003 	mov	r4,a
      006FCC 88 82            [24] 4004 	mov	dpl,r0
      006FCE 8C 83            [24] 4005 	mov	dph,r4
      006FD0 E4               [12] 4006 	clr	a
      006FD1 93               [24] 4007 	movc	a,@a+dptr
      006FD2 12 70 F9         [24] 4008 	lcall	_ak820_outline_0141
      006FD5 0B               [12] 4009 	inc	r3
      006FD6 D0 04            [24] 4010 	pop	ar4
      006FD8 80 C8            [24] 4011 	sjmp	00131$
      006FDA                       4012 00108$:
                                   4013 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FDA 12 70 D9         [24] 4014 	lcall	_ak820_outline_0045
      006FDD 12 6B DB         [24] 4015 	lcall	_ak820_usb_send
      006FE0 02 70 89         [24] 4016 	ljmp	00119$
      006FE3                       4017 00118$:
                                   4018 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006FE3 EF               [12] 4019 	mov	a,r7
      006FE4 70 03            [24] 4020 	jnz	00281$
      006FE6 02 70 66         [24] 4021 	ljmp	00114$
      006FE9                       4022 00281$:
      006FE9 12 70 FF         [24] 4023 	lcall	_ak820_outline_0169
      006FEC BF 01 02         [24] 4024 	cjne	r7,#0x01,00282$
      006FEF 80 03            [24] 4025 	sjmp	00283$
      006FF1                       4026 00282$:
      006FF1 02 70 66         [24] 4027 	ljmp	00114$
      006FF4                       4028 00283$:
                                   4029 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006FF4 7F 02            [12] 4030 	mov	r7,#0x02
      006FF6                       4031 00133$:
      006FF6 EF               [12] 4032 	mov	a,r7
      006FF7 12 70 ED         [24] 4033 	lcall	_ak820_outline_0106
      006FFA 0F               [12] 4034 	inc	r7
      006FFB BF 20 00         [24] 4035 	cjne	r7,#0x20,00284$
      006FFE                       4036 00284$:
      006FFE 40 F6            [24] 4037 	jc	00133$
                                   4038 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      007000 90 07 9C         [24] 4039 	mov	dptr,#(_raw_buffer + 0x0002)
      007003 74 01            [12] 4040 	mov	a,#0x01
      007005 F0               [24] 4041 	movx	@dptr,a
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      007006 90 07 9D         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0003)
      007009 74 A8            [12] 4044 	mov	a,#0xa8
      00700B F0               [24] 4045 	movx	@dptr,a
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      00700C 90 07 9E         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0004)
      00700F 12 3D D7         [24] 4048 	lcall	_ak820_nvm_diagnostic
                                   4049 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007012 7F 00            [12] 4050 	mov	r7,#0x00
      007014                       4051 00135$:
      007014 8F 06            [24] 4052 	mov	ar6,r7
      007016 74 0B            [12] 4053 	mov	a,#0x0b
      007018 2E               [12] 4054 	add	a, r6
      007019 24 9A            [12] 4055 	add	a,#_raw_buffer
      00701B FE               [12] 4056 	mov	r6,a
      00701C E4               [12] 4057 	clr	a
      00701D 34 07            [12] 4058 	addc	a, #(_raw_buffer >> 8)
      00701F FD               [12] 4059 	mov	r5,a
      007020 EF               [12] 4060 	mov	a,r7
      007021 24 74            [12] 4061 	add	a, #_ak820_flash_diagnostic
      007023 F5 82            [12] 4062 	mov	dpl,a
      007025 E4               [12] 4063 	clr	a
      007026 34 04            [12] 4064 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007028 F5 83            [12] 4065 	mov	dph,a
      00702A E0               [24] 4066 	movx	a,@dptr
      00702B 8E 82            [24] 4067 	mov	dpl,r6
      00702D 8D 83            [24] 4068 	mov	dph,r5
      00702F F0               [24] 4069 	movx	@dptr,a
      007030 0F               [12] 4070 	inc	r7
      007031 BF 06 00         [24] 4071 	cjne	r7,#0x06,00286$
      007034                       4072 00286$:
      007034 40 DE            [24] 4073 	jc	00135$
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      007036 90 0E 53         [24] 4075 	mov	dptr,#_vial_unlocked
      007039 E0               [24] 4076 	movx	a,@dptr
      00703A 90 07 AB         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0011)
      00703D F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      00703E 90 0E 54         [24] 4080 	mov	dptr,#_vial_unlock_in_progress
      007041 E0               [24] 4081 	movx	a,@dptr
      007042 90 07 AC         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0012)
      007045 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      007046 90 07 92         [24] 4085 	mov	dptr,#_USB_EnumStatus
      007049 E0               [24] 4086 	movx	a,@dptr
      00704A 90 07 AD         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0013)
      00704D F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      00704E 90 07 93         [24] 4090 	mov	dptr,#_USB_SleepStatus
      007051 E0               [24] 4091 	movx	a,@dptr
      007052 90 07 AE         [24] 4092 	mov	dptr,#(_raw_buffer + 0x0014)
      007055 F0               [24] 4093 	movx	@dptr,a
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      007056 90 07 99         [24] 4095 	mov	dptr,#_raw_state
      007059 E0               [24] 4096 	movx	a,@dptr
      00705A 90 07 AF         [24] 4097 	mov	dptr,#(_raw_buffer + 0x0015)
      00705D F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00705E 12 70 D9         [24] 4100 	lcall	_ak820_outline_0045
      007061 12 6B DB         [24] 4101 	lcall	_ak820_usb_send
      007064 80 23            [24] 4102 	sjmp	00119$
      007066                       4103 00114$:
                                   4104 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007066 12 6D F6         [24] 4105 	lcall	_raw_request_is_nonpersistent
      007069 E5 82            [12] 4106 	mov	a, dpl
      00706B 90 07 BA         [24] 4107 	mov	dptr,#_raw_reply_without_nvm
      00706E F0               [24] 4108 	movx	@dptr,a
                                   4109 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      00706F 12 41 BC         [24] 4110 	lcall	_ak820_nvm_begin
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      007072 90 0C 84         [24] 4112 	mov	dptr,#_raw_hid_receive_PARM_2
      007075 74 20            [12] 4113 	mov	a,#0x20
      007077 F0               [24] 4114 	movx	@dptr,a
      007078 90 07 9A         [24] 4115 	mov	dptr,#_raw_buffer
      00707B 75 F0 00         [24] 4116 	mov	b, #0x00
      00707E 12 AB 15         [24] 4117 	lcall	_raw_hid_receive
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      007081 12 41 D1         [24] 4119 	lcall	_ak820_nvm_end
                                   4120 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      007084 90 07 BA         [24] 4121 	mov	dptr,#_raw_reply_without_nvm
      007087 E4               [12] 4122 	clr	a
      007088 F0               [24] 4123 	movx	@dptr,a
      007089                       4124 00119$:
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4126 ;	assignBit
      007089 A2 AF            [12] 4127 	mov	c,_EA
      00708B 92 1E            [24] 4128 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4129 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4130 ;	assignBit
      00708D C2 AF            [12] 4131 	clr	_EA
                                   4132 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      00708F 12 71 05         [24] 4133 	lcall	_ak820_outline_0171
      007092 BF 04 08         [24] 4134 	cjne	r7,#0x04,00126$
      007095 90 07 99         [24] 4135 	mov	dptr,#_raw_state
      007098 74 05            [12] 4136 	mov	a,#0x05
      00709A F0               [24] 4137 	movx	@dptr,a
      00709B 80 1B            [24] 4138 	sjmp	00127$
      00709D                       4139 00126$:
                                   4140 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      00709D 12 71 05         [24] 4141 	lcall	_ak820_outline_0171
      0070A0 BF 03 02         [24] 4142 	cjne	r7,#0x03,00290$
      0070A3 80 0E            [24] 4143 	sjmp	00121$
      0070A5                       4144 00290$:
      0070A5 12 71 05         [24] 4145 	lcall	_ak820_outline_0171
      0070A8 BF 06 02         [24] 4146 	cjne	r7,#0x06,00291$
      0070AB 80 06            [24] 4147 	sjmp	00121$
      0070AD                       4148 00291$:
      0070AD 12 71 05         [24] 4149 	lcall	_ak820_outline_0171
      0070B0 BF 07 05         [24] 4150 	cjne	r7,#0x07,00127$
      0070B3                       4151 00121$:
      0070B3 90 07 99         [24] 4152 	mov	dptr,#_raw_state
      0070B6 E4               [12] 4153 	clr	a
      0070B7 F0               [24] 4154 	movx	@dptr,a
      0070B8                       4155 00127$:
                                   4156 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4157 ;	assignBit
      0070B8 A2 1E            [12] 4158 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0070BA 92 AF            [24] 4159 	mov	_EA,c
                                   4160 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      0070BC 22               [24] 4161 	ret
                                   4162 ;------------------------------------------------------------
                                   4163 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4164 ;------------------------------------------------------------
                                   4165 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_483'
                                   4166 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_483'
                                   4167 ;------------------------------------------------------------
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4169 ;	-----------------------------------------
                                   4170 ;	 function ak820_usb_take_keyboard_reset
                                   4171 ;	-----------------------------------------
      0070BD                       4172 _ak820_usb_take_keyboard_reset:
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4174 ;	assignBit
      0070BD A2 AF            [12] 4175 	mov	c,_EA
      0070BF 92 1F            [24] 4176 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4178 ;	assignBit
      0070C1 C2 AF            [12] 4179 	clr	_EA
                                   4180 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      0070C3 90 07 BB         [24] 4181 	mov	dptr,#_keyboard_reset
      0070C6 E0               [24] 4182 	movx	a,@dptr
      0070C7 FF               [12] 4183 	mov	r7,a
                                   4184 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      0070C8 E4               [12] 4185 	clr	a
      0070C9 F0               [24] 4186 	movx	@dptr,a
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4188 ;	assignBit
      0070CA A2 1F            [12] 4189 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      0070CC 92 AF            [24] 4190 	mov	_EA,c
                                   4191 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      0070CE EF               [12] 4192 	mov	a,r7
      0070CF B4 01 00         [24] 4193 	cjne	a,#0x01,00103$
      0070D2                       4194 00103$:
      0070D2 B3               [12] 4195 	cpl	c
      0070D3 92 1F            [24] 4196 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0070D5 12 3A F1         [24] 4197 	lcall	_ak820_outline_0162
                                   4198 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      0070D8 22               [24] 4199 	ret
                                   4200 	.area CSEG    (CODE)
                                   4201 	.area CONST   (CODE)
                                   4202 	.area CONST   (CODE)
      00BDC5                       4203 _shared_offsets:
      00BDC5 00                    4204 	.db #0x00	; 0
      00BDC6 00                    4205 	.db #0x00	; 0
      00BDC7 28                    4206 	.db #0x28	; 40
      00BDC8 2E                    4207 	.db #0x2e	; 46
      00BDC9 31                    4208 	.db #0x31	; 49	'1'
      00BDCA 00                    4209 	.db #0x00	; 0
      00BDCB 08                    4210 	.db #0x08	; 8
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00BDCC                       4213 _shared_lengths:
      00BDCC 00                    4214 	.db #0x00	; 0
      00BDCD 00                    4215 	.db #0x00	; 0
      00BDCE 06                    4216 	.db #0x06	; 6
      00BDCF 03                    4217 	.db #0x03	; 3
      00BDD0 03                    4218 	.db #0x03	; 3
      00BDD1 00                    4219 	.db #0x00	; 0
      00BDD2 20                    4220 	.db #0x20	; 32
                                   4221 	.area CSEG    (CODE)
                                   4222 	.area CONST   (CODE)
      00BDD3                       4223 _interface_descriptors:
      00BDD3 76 C3                 4224 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BDD5 BF C4                 4225 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BDD7 72 C4                 4226 	.byte _RawReport, (_RawReport >> 8)
      00BDD9 D8 C4                 4227 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BDDB BB C3                 4228 	.byte _SharedReport, (_SharedReport >> 8)
      00BDDD F1 C4                 4229 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4230 	.area CSEG    (CODE)
                                   4231 	.area XINIT   (CODE)
                                   4232 	.area CABS    (ABS,CODE)
                                   4233 
                                   4234 ; Experimental exact instruction outlining.
                                   4235 	.globl _ak820_outline_0016
                                   4236 	.globl _ak820_outline_0036
                                   4237 	.globl _ak820_outline_0045
                                   4238 	.globl _ak820_outline_0080
                                   4239 	.globl _ak820_outline_0106
                                   4240 	.globl _ak820_outline_0141
                                   4241 	.globl _ak820_outline_0162
                                   4242 	.globl _ak820_outline_0167
                                   4243 	.globl _ak820_outline_0169
                                   4244 	.globl _ak820_outline_0171
                                   4245 
                                   4246 	.area CSEG (CODE)
                                   4247 ; function ak820_outline_0045
      0070D9                       4248 _ak820_outline_0045:
      0070D9 90 07 FD         [24] 4249 	mov	dptr,#_ak820_usb_send_PARM_2
      0070DC 74 9A            [12] 4250 	mov	a,#_raw_buffer
      0070DE F0               [24] 4251 	movx	@dptr,a
      0070DF 74 07            [12] 4252 	mov	a,#(_raw_buffer>>8)
      0070E1 A3               [24] 4253 	inc	dptr
      0070E2 F0               [24] 4254 	movx	@dptr,a
      0070E3 90 07 FF         [24] 4255 	mov	dptr,#_ak820_usb_send_PARM_3
      0070E6 74 20            [12] 4256 	mov	a,#0x20
      0070E8 F0               [24] 4257 	movx	@dptr,a
      0070E9 75 82 03         [24] 4258 	mov	dpl,#0x03
      0070EC 22               [24] 4259 	ret
                                   4260 
                                   4261 	.area CSEG (CODE)
                                   4262 ; function ak820_outline_0106
      0070ED                       4263 _ak820_outline_0106:
      0070ED 24 9A            [12] 4264 	add	a,#_raw_buffer
      0070EF F5 82            [12] 4265 	mov	dpl,a
      0070F1 E4               [12] 4266 	clr	a
      0070F2 34 07            [12] 4267 	addc	a,#(_raw_buffer>>8)
      0070F4 F5 83            [12] 4268 	mov	dph,a
      0070F6 E4               [12] 4269 	clr	a
      0070F7 F0               [24] 4270 	movx	@dptr,a
      0070F8 22               [24] 4271 	ret
                                   4272 
                                   4273 	.area CSEG (CODE)
                                   4274 ; function ak820_outline_0141
      0070F9                       4275 _ak820_outline_0141:
      0070F9 89 82            [24] 4276 	mov	dpl,r1
      0070FB 8A 83            [24] 4277 	mov	dph,r2
      0070FD F0               [24] 4278 	movx	@dptr,a
      0070FE 22               [24] 4279 	ret
                                   4280 
                                   4281 	.area CSEG (CODE)
                                   4282 ; function ak820_outline_0169
      0070FF                       4283 _ak820_outline_0169:
      0070FF 90 07 9B         [24] 4284 	mov	dptr,#(_raw_buffer+0x0001)
      007102 E0               [24] 4285 	movx	a,@dptr
      007103 FF               [12] 4286 	mov	r7,a
      007104 22               [24] 4287 	ret
                                   4288 
                                   4289 	.area CSEG (CODE)
                                   4290 ; function ak820_outline_0171
      007105                       4291 _ak820_outline_0171:
      007105 90 07 99         [24] 4292 	mov	dptr,#_raw_state
      007108 E0               [24] 4293 	movx	a,@dptr
      007109 FF               [12] 4294 	mov	r7,a
      00710A 22               [24] 4295 	ret
