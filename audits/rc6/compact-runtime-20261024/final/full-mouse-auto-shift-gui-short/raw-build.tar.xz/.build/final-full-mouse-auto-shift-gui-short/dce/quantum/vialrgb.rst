                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CC1                        569 _g_direct_mode_colors::
      000CC1                        570 	.ds 246
      000DB7                        571 _get_supported_PARM_2:
      000DB7                        572 	.ds 1
      000DB8                        573 _get_supported_args_10000_255:
      000DB8                        574 	.ds 2
      000DBA                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DBA                        576 	.ds 2
      000DBC                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DBC                        578 	.ds 2
      000DBE                        579 _set_mode_mode_10000_275:
      000DBE                        580 	.ds 2
      000DC0                        581 _get_matrix_pos_for_led_PARM_2:
      000DC0                        582 	.ds 2
      000DC2                        583 _get_matrix_pos_for_led_led_10000_280:
      000DC2                        584 	.ds 2
      000DC4                        585 _fast_set_leds_PARM_2:
      000DC4                        586 	.ds 1
      000DC5                        587 _fast_set_leds_args_10000_282:
      000DC5                        588 	.ds 2
      000DC7                        589 _fast_set_leds_first_index_10001_285:
      000DC7                        590 	.ds 2
      000DC9                        591 _fast_set_leds_num_leds_10001_285:
      000DC9                        592 	.ds 1
      000DCA                        593 _vialrgb_get_value_PARM_2:
      000DCA                        594 	.ds 1
      000DCB                        595 _vialrgb_get_value_data_10000_291:
      000DCB                        596 	.ds 3
      000DCE                        597 _vialrgb_set_value_PARM_2:
      000DCE                        598 	.ds 1
      000DCF                        599 _vialrgb_set_value_data_10000_302:
      000DCF                        600 	.ds 3
      000DD2                        601 _vialrgb_save_PARM_2:
      000DD2                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B7A5                        654 _get_supported:
      00B7A5 12 3A C2         [24]  655 	lcall	_ak820_outline_0109
      00B7A8 90 0D B8         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B7AB 12 3A C7         [24]  657 	lcall	_ak820_outline_0110
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B7AE 90 0D B8         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B7B1 12 3A 34         [24]  660 	lcall	_ak820_outline_0005
      00B7B4 E0               [24]  661 	movx	a,@dptr
      00B7B5 FD               [12]  662 	mov	r5,a
      00B7B6 7C 00            [12]  663 	mov	r4,#0x00
      00B7B8 12 3A CC         [24]  664 	lcall	_ak820_outline_0120
      00B7BB A3               [24]  665 	inc	dptr
      00B7BC E0               [24]  666 	movx	a,@dptr
      00B7BD FA               [12]  667 	mov	r2,a
      00B7BE E4               [12]  668 	clr	a
      00B7BF 12 45 A2         [24]  669 	lcall	_ak820_outline_0146
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B7C2 90 0D B7         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B7C5 E0               [24]  672 	movx	a,@dptr
      00B7C6 FB               [12]  673 	mov	r3,a
      00B7C7 7A 00            [12]  674 	mov	r2,#0x00
      00B7C9                        675 00107$:
      00B7C9 C3               [12]  676 	clr	c
      00B7CA EA               [12]  677 	mov	a,r2
      00B7CB 9B               [12]  678 	subb	a,r3
      00B7CC 50 0A            [24]  679 	jnc	00101$
      00B7CE EA               [12]  680 	mov	a,r2
      00B7CF 12 3A 71         [24]  681 	lcall	_ak820_outline_0021
      00B7D2 74 FF            [12]  682 	mov	a,#0xff
      00B7D4 F0               [24]  683 	movx	@dptr,a
      00B7D5 0A               [12]  684 	inc	r2
      00B7D6 80 F1            [24]  685 	sjmp	00107$
      00B7D8                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7D8 8D 06            [24]  688 	mov	ar6,r5
      00B7DA 8C 07            [24]  689 	mov	ar7,r4
      00B7DC 8B 05            [24]  690 	mov	ar5,r3
      00B7DE 90 0D B8         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B7E1 12 3A D1         [24]  692 	lcall	_ak820_outline_0124
      00B7E4 7A 00            [12]  693 	mov	r2,#0x00
      00B7E6                        694 00110$:
      00B7E6 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B7E9                        696 00159$:
      00B7E9 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7EB EA               [12]  699 	mov	a,r2
      00B7EC 75 F0 02         [24]  700 	mov	b,#0x02
      00B7EF A4               [48]  701 	mul	ab
      00B7F0 24 49            [12]  702 	add	a, #_supported_modes
      00B7F2 F5 82            [12]  703 	mov	dpl,a
      00B7F4 74 C4            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B7F6 12 5B C6         [24]  705 	lcall	_ak820_outline_0111
      00B7F9 F8               [12]  706 	mov	r0,a
      00B7FA 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B7FC C3               [12]  709 	clr	c
      00B7FD EE               [12]  710 	mov	a,r6
      00B7FE 98               [12]  711 	subb	a,r0
      00B7FF EF               [12]  712 	mov	a,r7
      00B800 99               [12]  713 	subb	a,r1
      00B801 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B803 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B806                        717 00162$:
      00B806 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B808 C0 06            [24]  720 	push	ar6
      00B80A C0 07            [24]  721 	push	ar7
      00B80C 88 07            [24]  722 	mov	ar7,r0
      00B80E 12 36 47         [24]  723 	lcall	_ak820_outline_0125
      00B811 EF               [12]  724 	mov	a,r7
      00B812 12 74 70         [24]  725 	lcall	_ak820_outline_0103
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B815 A3               [24]  727 	inc	dptr
      00B816 89 00            [24]  728 	mov	ar0,r1
      00B818 E8               [12]  729 	mov	a,r0
      00B819 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B81A 1D               [12]  732 	dec	r5
      00B81B 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B81C 74 02            [12]  735 	mov	a,#0x02
      00B81E 2B               [12]  736 	add	a, r3
      00B81F FB               [12]  737 	mov	r3,a
      00B820 E4               [12]  738 	clr	a
      00B821 3C               [12]  739 	addc	a, r4
      00B822 FC               [12]  740 	mov	r4,a
      00B823 90 0D B8         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B826 12 3A A4         [24]  742 	lcall	_ak820_outline_0084
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B829 D0 07            [24]  744 	pop	ar7
      00B82B D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B82D                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B82D 0A               [12]  749 	inc	r2
      00B82E 80 B6            [24]  750 	sjmp	00110$
      00B830                        751 00127$:
      00B830 90 0D B8         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B833 12 3A A4         [24]  753 	lcall	_ak820_outline_0084
                                    754 ;	quantum/vialrgb.c:55: }
      00B836 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B837                        767 _qmk_id_to_vialrgb_id:
      00B837 12 3A C2         [24]  768 	lcall	_ak820_outline_0109
      00B83A 90 0D BA         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B83D 12 3A C7         [24]  770 	lcall	_ak820_outline_0110
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B840 90 0D BA         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B843 12 3A 81         [24]  773 	lcall	_ak820_outline_0052
      00B846 7D 00            [12]  774 	mov	r5,#0x00
      00B848                        775 00105$:
      00B848 BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B84B                        777 00130$:
      00B84B 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B84D 12 BC 60         [24]  780 	lcall	_ak820_outline_0047
      00B850 A3               [24]  781 	inc	dptr
      00B851 E4               [12]  782 	clr	a
      00B852 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B853 7A 00            [12]  785 	mov	r2,#0x00
      00B855 B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B858 EA               [12]  787 	mov	a,r2
      00B859 B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B85C 12 36 47         [24]  790 	lcall	_ak820_outline_0125
      00B85F 12 BC 8C         [24]  791 	lcall	_ak820_outline_0148
      00B862 22               [24]  792 	ret
      00B863                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B863 0D               [12]  795 	inc	r5
      00B864 80 E2            [24]  796 	sjmp	00105$
      00B866                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B866 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B869 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B86A                        813 _vialrgb_id_to_qmk_id:
      00B86A 12 3A C2         [24]  814 	lcall	_ak820_outline_0109
      00B86D 90 0D BC         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B870 12 3A C7         [24]  816 	lcall	_ak820_outline_0110
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B873 90 0D BC         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B876 12 3A 81         [24]  819 	lcall	_ak820_outline_0052
      00B879 7D 00            [12]  820 	mov	r5,#0x00
      00B87B                        821 00105$:
      00B87B BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B87E                        823 00130$:
      00B87E 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B880 12 BC 60         [24]  826 	lcall	_ak820_outline_0047
      00B883 E4               [12]  827 	clr	a
      00B884 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B885 7A 00            [12]  830 	mov	r2,#0x00
      00B887 B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B88A EA               [12]  832 	mov	a,r2
      00B88B B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B88E 12 36 47         [24]  835 	lcall	_ak820_outline_0125
      00B891 A3               [24]  836 	inc	dptr
      00B892 12 BC 8C         [24]  837 	lcall	_ak820_outline_0148
      00B895 22               [24]  838 	ret
      00B896                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B896 0D               [12]  841 	inc	r5
      00B897 80 E2            [24]  842 	sjmp	00105$
      00B899                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B899 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B89C 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B89D                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B89D 12 59 BA         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B8A0 E5 82            [12]  858 	mov	a, dpl
      00B8A2 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B8A4 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B8A7 22               [24]  862 	ret
      00B8A8                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B8A8 12 59 C0         [24]  865 	lcall	_rgb_matrix_get_mode
      00B8AB 7E 00            [12]  866 	mov	r6,#0x00
      00B8AD 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B8AF 01 37            [12]  869 	ajmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B8B1                        879 _set_mode:
      00B8B1 12 3A C2         [24]  880 	lcall	_ak820_outline_0109
      00B8B4 90 0D BE         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B8B7 12 3A C7         [24]  882 	lcall	_ak820_outline_0110
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B8BA 90 0D BE         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B8BD 12 3A 81         [24]  885 	lcall	_ak820_outline_0052
      00B8C0 90 0D BE         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B8C3 12 72 3F         [24]  887 	lcall	_ak820_outline_0040
      00B8C6 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B8C8 02 5A 0D         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B8CB                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B8CB C0 07            [24]  893 	push	ar7
      00B8CD C0 06            [24]  894 	push	ar6
      00B8CF 12 59 FC         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B8D2 D0 06            [24]  896 	pop	ar6
      00B8D4 D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B8D6 12 3A CC         [24]  899 	lcall	_ak820_outline_0120
      00B8D9 11 6A            [12]  900 	acall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B8DB 02 5A 16         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B8DE                        914 _get_matrix_pos_for_led:
      00B8DE 12 3A C2         [24]  915 	lcall	_ak820_outline_0109
      00B8E1 90 0D C2         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B8E4 12 3A C7         [24]  917 	lcall	_ak820_outline_0110
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B8E7 90 0D C2         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B8EA 12 3A 81         [24]  920 	lcall	_ak820_outline_0052
      00B8ED EE               [12]  921 	mov	a,r6
      00B8EE 24 48            [12]  922 	add	a, #_ak820_rgb_slots
      00B8F0 F5 82            [12]  923 	mov	dpl,a
      00B8F2 EF               [12]  924 	mov	a,r7
      00B8F3 34 BE            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B8F5 F5 83            [12]  926 	mov	dph,a
      00B8F7 E4               [12]  927 	clr	a
      00B8F8 93               [24]  928 	movc	a,@a+dptr
      00B8F9 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B8FA 90 0D C0         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8FD 12 3A AA         [24]  932 	lcall	_ak820_outline_0085
      00B900 EF               [12]  933 	mov	a,r7
      00B901 12 5B FC         [24]  934 	lcall	_ak820_outline_0190
      00B904 12 86 61         [24]  935 	lcall	_ak820_outline_0123
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B907 12 3A DC         [24]  937 	lcall	_ak820_outline_0135
      00B90A A3               [24]  938 	inc	dptr
      00B90B 53 07 07         [24]  939 	anl	ar7,#0x07
      00B90E EF               [12]  940 	mov	a,r7
      00B90F F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B910 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B911                        961 _fast_set_leds:
      00B911 12 3A C2         [24]  962 	lcall	_ak820_outline_0109
      00B914 90 0D C5         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B917 12 3A C7         [24]  964 	lcall	_ak820_outline_0110
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B91A 90 0D C4         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B91D E0               [24]  967 	movx	a,@dptr
      00B91E FF               [12]  968 	mov	r7,a
      00B91F BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B922                        970 00159$:
      00B922 50 01            [24]  971 	jnc	00102$
      00B924 22               [24]  972 	ret
      00B925                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B925 90 0D C5         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B928 E0               [24]  976 	movx	a,@dptr
      00B929 FD               [12]  977 	mov	r5,a
      00B92A A3               [24]  978 	inc	dptr
      00B92B E0               [24]  979 	movx	a,@dptr
      00B92C 12 4A C3         [24]  980 	lcall	_ak820_outline_0057
      00B92F 7B 00            [12]  981 	mov	r3,#0x00
      00B931 12 3A DC         [24]  982 	lcall	_ak820_outline_0135
      00B934 A3               [24]  983 	inc	dptr
      00B935 E0               [24]  984 	movx	a,@dptr
      00B936 FA               [12]  985 	mov	r2,a
      00B937 79 00            [12]  986 	mov	r1,#0x00
      00B939 90 0D C7         [24]  987 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B93C E9               [12]  988 	mov	a,r1
      00B93D 4C               [12]  989 	orl	a,r4
      00B93E F0               [24]  990 	movx	@dptr,a
      00B93F EA               [12]  991 	mov	a,r2
      00B940 4B               [12]  992 	orl	a,r3
      00B941 A3               [24]  993 	inc	dptr
      00B942 F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B943 12 3A DC         [24]  996 	lcall	_ak820_outline_0135
      00B946 A3               [24]  997 	inc	dptr
      00B947 A3               [24]  998 	inc	dptr
      00B948 E0               [24]  999 	movx	a,@dptr
      00B949 90 0D C9         [24] 1000 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B94C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:119: length -= 3;
      00B94D EF               [12] 1003 	mov	a,r7
      00B94E 24 FD            [12] 1004 	add	a,#0xfd
      00B950 90 0D C4         [24] 1005 	mov	dptr,#_fast_set_leds_PARM_2
      00B953 F0               [24] 1006 	movx	@dptr,a
                                   1007 ;	quantum/vialrgb.c:120: args += 3;
      00B954 90 0D C5         [24] 1008 	mov	dptr,#_fast_set_leds_args_10000_282
      00B957 74 03            [12] 1009 	mov	a,#0x03
      00B959 2D               [12] 1010 	add	a, r5
      00B95A F0               [24] 1011 	movx	@dptr,a
      00B95B E4               [12] 1012 	clr	a
      00B95C 3E               [12] 1013 	addc	a, r6
      00B95D A3               [24] 1014 	inc	dptr
      00B95E F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B95F 90 0D C9         [24] 1017 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B962 E0               [24] 1018 	movx	a,@dptr
      00B963 FF               [12] 1019 	mov	r7,a
      00B964 75 F0 03         [24] 1020 	mov	b,#0x03
      00B967 A4               [48] 1021 	mul	ab
      00B968 FE               [12] 1022 	mov	r6,a
      00B969 AD F0            [24] 1023 	mov	r5,b
      00B96B 90 0D C4         [24] 1024 	mov	dptr,#_fast_set_leds_PARM_2
      00B96E E0               [24] 1025 	movx	a,@dptr
      00B96F FB               [12] 1026 	mov	r3,a
      00B970 7C 00            [12] 1027 	mov	r4,#0x00
      00B972 C3               [12] 1028 	clr	c
      00B973 EB               [12] 1029 	mov	a,r3
      00B974 9E               [12] 1030 	subb	a,r6
      00B975 EC               [12] 1031 	mov	a,r4
      00B976 9D               [12] 1032 	subb	a,r5
      00B977 40 13            [24] 1033 	jc	00103$
                                   1034 ;	free result
      00B979 90 0D C7         [24] 1035 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B97C 12 3A AA         [24] 1036 	lcall	_ak820_outline_0085
      00B97F 8D 03            [24] 1037 	mov	ar3,r5
      00B981 8E 04            [24] 1038 	mov	ar4,r6
      00B983 C3               [12] 1039 	clr	c
      00B984 EB               [12] 1040 	mov	a,r3
      00B985 94 52            [12] 1041 	subb	a,#0x52
      00B987 EC               [12] 1042 	mov	a,r4
      00B988 94 00            [12] 1043 	subb	a,#0x00
      00B98A 40 01            [24] 1044 	jc	00104$
      00B98C                       1045 00103$:
      00B98C 22               [24] 1046 	ret
      00B98D                       1047 00104$:
                                   1048 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B98D 74 52            [12] 1049 	mov	a,#0x52
      00B98F C3               [12] 1050 	clr	c
      00B990 9D               [12] 1051 	subb	a,r5
      00B991 FB               [12] 1052 	mov	r3,a
      00B992 E4               [12] 1053 	clr	a
      00B993 9E               [12] 1054 	subb	a,r6
      00B994 FC               [12] 1055 	mov	r4,a
      00B995 7A 00            [12] 1056 	mov	r2,#0x00
      00B997 C3               [12] 1057 	clr	c
      00B998 EB               [12] 1058 	mov	a,r3
      00B999 9F               [12] 1059 	subb	a,r7
      00B99A EC               [12] 1060 	mov	a,r4
      00B99B 9A               [12] 1061 	subb	a,r2
      00B99C 50 08            [24] 1062 	jnc	00127$
                                   1063 ;	free result
      00B99E 90 0D C9         [24] 1064 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B9A1 74 52            [12] 1065 	mov	a,#0x52
      00B9A3 C3               [12] 1066 	clr	c
      00B9A4 9D               [12] 1067 	subb	a,r5
      00B9A5 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B9A6                       1070 00127$:
      00B9A6 90 0D C9         [24] 1071 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B9A9 E0               [24] 1072 	movx	a,@dptr
      00B9AA FF               [12] 1073 	mov	r7,a
      00B9AB 90 0D C7         [24] 1074 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B9AE 12 3A AA         [24] 1075 	lcall	_ak820_outline_0085
      00B9B1 7C 00            [12] 1076 	mov	r4,#0x00
      00B9B3                       1077 00110$:
      00B9B3 C3               [12] 1078 	clr	c
      00B9B4 EC               [12] 1079 	mov	a,r4
      00B9B5 9F               [12] 1080 	subb	a,r7
      00B9B6 40 01            [24] 1081 	jc	00164$
      00B9B8 22               [24] 1082 	ret
      00B9B9                       1083 00164$:
                                   1084 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B9B9 C0 07            [24] 1085 	push	ar7
      00B9BB 90 0D E1         [24] 1086 	mov	dptr,#__mulint_PARM_2
      00B9BE 12 45 B8         [24] 1087 	lcall	_ak820_outline_0167
      00B9C1 90 00 03         [24] 1088 	mov	dptr,#0x0003
      00B9C4 C0 07            [24] 1089 	push	ar7
      00B9C6 C0 06            [24] 1090 	push	ar6
      00B9C8 C0 05            [24] 1091 	push	ar5
      00B9CA C0 04            [24] 1092 	push	ar4
      00B9CC B1 F8            [12] 1093 	acall	__mulint
      00B9CE AA 82            [24] 1094 	mov	r2, dpl
      00B9D0 AB 83            [24] 1095 	mov	r3, dph
      00B9D2 D0 04            [24] 1096 	pop	ar4
      00B9D4 D0 05            [24] 1097 	pop	ar5
      00B9D6 D0 06            [24] 1098 	pop	ar6
      00B9D8 D0 07            [24] 1099 	pop	ar7
      00B9DA 0D               [12] 1100 	inc	r5
      00B9DB BD 00 01         [24] 1101 	cjne	r5,#0x00,00165$
      00B9DE 0E               [12] 1102 	inc	r6
      00B9DF                       1103 00165$:
      00B9DF EA               [12] 1104 	mov	a,r2
      00B9E0 24 C1            [12] 1105 	add	a, #_g_direct_mode_colors
      00B9E2 FA               [12] 1106 	mov	r2,a
      00B9E3 EB               [12] 1107 	mov	a,r3
      00B9E4 34 0C            [12] 1108 	addc	a, #(_g_direct_mode_colors >> 8)
      00B9E6 FB               [12] 1109 	mov	r3,a
                                   1110 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B9E7 8A 4A            [24] 1111 	mov	_fast_set_leds_sloc0_1_0,r2
      00B9E9 8B 4B            [24] 1112 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B9EB 12 BC 72         [24] 1113 	lcall	_ak820_outline_0083
      00B9EE F8               [12] 1114 	mov	r0,a
      00B9EF 12 BC 80         [24] 1115 	lcall	_ak820_outline_0108
      00B9F2 85 4A 82         [24] 1116 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9F5 85 4B 83         [24] 1117 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9F8 E8               [12] 1118 	mov	a,r0
      00B9F9 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B9FA 74 01            [12] 1121 	mov	a,#0x01
      00B9FC 2A               [12] 1122 	add	a, r2
      00B9FD F5 4A            [12] 1123 	mov	_fast_set_leds_sloc0_1_0,a
      00B9FF E4               [12] 1124 	clr	a
      00BA00 3B               [12] 1125 	addc	a, r3
      00BA01 F5 4B            [12] 1126 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00BA03 90 0D C5         [24] 1127 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA06 E0               [24] 1128 	movx	a,@dptr
      00BA07 F8               [12] 1129 	mov	r0,a
      00BA08 A3               [24] 1130 	inc	dptr
      00BA09 E0               [24] 1131 	movx	a,@dptr
      00BA0A FF               [12] 1132 	mov	r7,a
      00BA0B 88 82            [24] 1133 	mov	dpl,r0
      00BA0D 8F 83            [24] 1134 	mov	dph,r7
      00BA0F E0               [24] 1135 	movx	a,@dptr
      00BA10 F9               [12] 1136 	mov	r1,a
      00BA11 90 0D C5         [24] 1137 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA14 74 01            [12] 1138 	mov	a,#0x01
      00BA16 28               [12] 1139 	add	a, r0
      00BA17 F0               [24] 1140 	movx	@dptr,a
      00BA18 E4               [12] 1141 	clr	a
      00BA19 3F               [12] 1142 	addc	a, r7
      00BA1A A3               [24] 1143 	inc	dptr
      00BA1B F0               [24] 1144 	movx	@dptr,a
      00BA1C 85 4A 82         [24] 1145 	mov	dpl,_fast_set_leds_sloc0_1_0
      00BA1F 85 4B 83         [24] 1146 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00BA22 E9               [12] 1147 	mov	a,r1
      00BA23 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00BA24 12 BC 72         [24] 1150 	lcall	_ak820_outline_0083
      00BA27 F5 4A            [12] 1151 	mov	_fast_set_leds_sloc0_1_0,a
      00BA29 12 BC 80         [24] 1152 	lcall	_ak820_outline_0108
                                   1153 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00BA2C 74 02            [12] 1154 	mov	a,#0x02
      00BA2E 2A               [12] 1155 	add	a, r2
      00BA2F F5 4C            [12] 1156 	mov	_fast_set_leds_sloc1_1_0,a
      00BA31 E4               [12] 1157 	clr	a
      00BA32 3B               [12] 1158 	addc	a, r3
      00BA33 F5 4D            [12] 1159 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00BA35 C3               [12] 1160 	clr	c
      00BA36 74 A0            [12] 1161 	mov	a,#0xa0
      00BA38 95 4A            [12] 1162 	subb	a,_fast_set_leds_sloc0_1_0
      00BA3A D0 07            [24] 1163 	pop	ar7
      00BA3C 50 04            [24] 1164 	jnc	00114$
                                   1165 ;	free result
      00BA3E 7B A0            [12] 1166 	mov	r3,#0xa0
      00BA40 80 04            [24] 1167 	sjmp	00115$
      00BA42                       1168 00114$:
      00BA42 AA 4A            [24] 1169 	mov	r2,_fast_set_leds_sloc0_1_0
      00BA44 8A 03            [24] 1170 	mov	ar3,r2
      00BA46                       1171 00115$:
      00BA46 85 4C 82         [24] 1172 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BA49 85 4D 83         [24] 1173 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BA4C EB               [12] 1174 	mov	a,r3
      00BA4D F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA4E 0C               [12] 1177 	inc	r4
                                   1178 ;	quantum/vialrgb.c:133: }
      00BA4F 21 B3            [24] 1179 	ajmp	00110$
                                   1180 ;------------------------------------------------------------
                                   1181 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1182 ;------------------------------------------------------------
                                   1183 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1184 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1185 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1186 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1187 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1188 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1189 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1190 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function vialrgb_get_value
                                   1195 ;	-----------------------------------------
      00BA51                       1196 _vialrgb_get_value:
      00BA51 12 45 55         [24] 1197 	lcall	_ak820_outline_0036
      00BA54 90 0D CB         [24] 1198 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA57 12 3A 5F         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BA5A 90 0D CA         [24] 1201 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA5D E0               [24] 1202 	movx	a,@dptr
      00BA5E FF               [12] 1203 	mov	r7,a
      00BA5F BF 20 02         [24] 1204 	cjne	r7,#0x20,00162$
      00BA62 80 01            [24] 1205 	sjmp	00102$
      00BA64                       1206 00162$:
      00BA64 22               [24] 1207 	ret
      00BA65                       1208 00102$:
                                   1209 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA65 90 0D CB         [24] 1210 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA68 12 BC 4C         [24] 1211 	lcall	_ak820_outline_0046
                                   1212 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1213 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BA6B BA 40 02         [24] 1214 	cjne	r2,#0x40,00163$
      00BA6E 80 15            [24] 1215 	sjmp	00103$
      00BA70                       1216 00163$:
      00BA70 BA 41 02         [24] 1217 	cjne	r2,#0x41,00164$
      00BA73 80 23            [24] 1218 	sjmp	00104$
      00BA75                       1219 00164$:
      00BA75 BA 42 02         [24] 1220 	cjne	r2,#0x42,00165$
      00BA78 61 29            [12] 1221 	ajmp	00105$
      00BA7A                       1222 00165$:
      00BA7A BA 43 02         [24] 1223 	cjne	r2,#0x43,00166$
      00BA7D 61 35            [12] 1224 	ajmp	00106$
      00BA7F                       1225 00166$:
      00BA7F BA 44 02         [24] 1226 	cjne	r2,#0x44,00167$
      00BA82 61 41            [12] 1227 	ajmp	00107$
      00BA84                       1228 00167$:
      00BA84 22               [24] 1229 	ret
                                   1230 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BA85                       1231 00103$:
                                   1232 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA85 12 36 47         [24] 1233 	lcall	_ak820_outline_0125
      00BA88 74 01            [12] 1234 	mov	a,#0x01
      00BA8A F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA8B 12 BC 44         [24] 1237 	lcall	_ak820_outline_0039
      00BA8E E4               [12] 1238 	clr	a
      00BA8F F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA90 12 BC 44         [24] 1241 	lcall	_ak820_outline_0039
      00BA93 A3               [24] 1242 	inc	dptr
      00BA94 74 A0            [12] 1243 	mov	a,#0xa0
      00BA96 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/vialrgb.c:147: break;
      00BA97 22               [24] 1246 	ret
                                   1247 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BA98                       1248 00104$:
                                   1249 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BA98 C0 06            [24] 1250 	push	ar6
      00BA9A C0 05            [24] 1251 	push	ar5
      00BA9C C0 04            [24] 1252 	push	ar4
      00BA9E C0 03            [24] 1253 	push	ar3
      00BAA0 11 9D            [12] 1254 	acall	_get_mode
      00BAA2 A9 82            [24] 1255 	mov	r1, dpl
      00BAA4 AA 83            [24] 1256 	mov	r2, dph
      00BAA6 D0 03            [24] 1257 	pop	ar3
      00BAA8 D0 04            [24] 1258 	pop	ar4
      00BAAA D0 05            [24] 1259 	pop	ar5
      00BAAC D0 06            [24] 1260 	pop	ar6
                                   1261 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BAAE 89 00            [24] 1262 	mov	ar0,r1
      00BAB0 12 36 47         [24] 1263 	lcall	_ak820_outline_0125
      00BAB3 E8               [12] 1264 	mov	a,r0
      00BAB4 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BAB5 12 BC 44         [24] 1267 	lcall	_ak820_outline_0039
      00BAB8 8A 01            [24] 1268 	mov	ar1,r2
      00BABA E9               [12] 1269 	mov	a,r1
      00BABB F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BABC 74 04            [12] 1272 	mov	a,#0x04
      00BABE 12 93 AB         [24] 1273 	lcall	_ak820_outline_0138
      00BAC1 C0 06            [24] 1274 	push	ar6
      00BAC3 C0 05            [24] 1275 	push	ar5
      00BAC5 C0 02            [24] 1276 	push	ar2
      00BAC7 C0 01            [24] 1277 	push	ar1
      00BAC9 12 59 DB         [24] 1278 	lcall	_rgb_matrix_get_speed
      00BACC A8 82            [24] 1279 	mov	r0, dpl
      00BACE D0 01            [24] 1280 	pop	ar1
      00BAD0 D0 02            [24] 1281 	pop	ar2
      00BAD2 D0 05            [24] 1282 	pop	ar5
      00BAD4 D0 06            [24] 1283 	pop	ar6
      00BAD6 12 86 3A         [24] 1284 	lcall	_ak820_outline_0064
                                   1285 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BAD9 74 05            [12] 1286 	mov	a,#0x05
      00BADB 12 93 AB         [24] 1287 	lcall	_ak820_outline_0138
      00BADE C0 06            [24] 1288 	push	ar6
      00BAE0 C0 05            [24] 1289 	push	ar5
      00BAE2 C0 02            [24] 1290 	push	ar2
      00BAE4 C0 01            [24] 1291 	push	ar1
      00BAE6 12 59 C6         [24] 1292 	lcall	_rgb_matrix_get_hue
      00BAE9 A8 82            [24] 1293 	mov	r0, dpl
      00BAEB D0 01            [24] 1294 	pop	ar1
      00BAED D0 02            [24] 1295 	pop	ar2
      00BAEF D0 05            [24] 1296 	pop	ar5
      00BAF1 D0 06            [24] 1297 	pop	ar6
      00BAF3 12 86 3A         [24] 1298 	lcall	_ak820_outline_0064
                                   1299 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BAF6 74 06            [12] 1300 	mov	a,#0x06
      00BAF8 12 93 AB         [24] 1301 	lcall	_ak820_outline_0138
      00BAFB C0 06            [24] 1302 	push	ar6
      00BAFD C0 05            [24] 1303 	push	ar5
      00BAFF C0 02            [24] 1304 	push	ar2
      00BB01 C0 01            [24] 1305 	push	ar1
      00BB03 12 59 CD         [24] 1306 	lcall	_rgb_matrix_get_sat
      00BB06 A8 82            [24] 1307 	mov	r0, dpl
      00BB08 D0 01            [24] 1308 	pop	ar1
      00BB0A D0 02            [24] 1309 	pop	ar2
      00BB0C D0 05            [24] 1310 	pop	ar5
      00BB0E D0 06            [24] 1311 	pop	ar6
      00BB10 12 86 3A         [24] 1312 	lcall	_ak820_outline_0064
                                   1313 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BB13 74 07            [12] 1314 	mov	a,#0x07
      00BB15 12 93 AB         [24] 1315 	lcall	_ak820_outline_0138
      00BB18 C0 02            [24] 1316 	push	ar2
      00BB1A C0 01            [24] 1317 	push	ar1
      00BB1C 12 59 D4         [24] 1318 	lcall	_rgb_matrix_get_val
      00BB1F A8 82            [24] 1319 	mov	r0, dpl
      00BB21 D0 01            [24] 1320 	pop	ar1
      00BB23 D0 02            [24] 1321 	pop	ar2
      00BB25 12 86 3A         [24] 1322 	lcall	_ak820_outline_0064
                                   1323 ;	quantum/vialrgb.c:156: break;
      00BB28 22               [24] 1324 	ret
                                   1325 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BB29                       1326 00105$:
                                   1327 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BB29 EF               [12] 1328 	mov	a,r7
      00BB2A 24 FE            [12] 1329 	add	a,#0xfe
      00BB2C 90 0D B7         [24] 1330 	mov	dptr,#_get_supported_PARM_2
      00BB2F 12 74 70         [24] 1331 	lcall	_ak820_outline_0103
                                   1332 ;	quantum/vialrgb.c:160: break;
      00BB32 02 B7 A5         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BB35                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BB35 12 36 47         [24] 1337 	lcall	_ak820_outline_0125
      00BB38 74 52            [12] 1338 	mov	a,#0x52
      00BB3A F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BB3B 12 BC 44         [24] 1341 	lcall	_ak820_outline_0039
      00BB3E E4               [12] 1342 	clr	a
      00BB3F F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00BB40 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BB41                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BB41 12 36 47         [24] 1349 	lcall	_ak820_outline_0125
      00BB44 E0               [24] 1350 	movx	a,@dptr
      00BB45 FF               [12] 1351 	mov	r7,a
      00BB46 7A 00            [12] 1352 	mov	r2,#0x00
      00BB48 74 03            [12] 1353 	mov	a,#0x03
      00BB4A 2D               [12] 1354 	add	a, r5
      00BB4B F8               [12] 1355 	mov	r0,a
      00BB4C E4               [12] 1356 	clr	a
      00BB4D 3E               [12] 1357 	addc	a, r6
      00BB4E F9               [12] 1358 	mov	r1,a
      00BB4F C0 03            [24] 1359 	push	ar3
      00BB51 C0 04            [24] 1360 	push	ar4
      00BB53 12 3A F6         [24] 1361 	lcall	_ak820_outline_0163
      00BB56 E0               [24] 1362 	movx	a,@dptr
      00BB57 FB               [12] 1363 	mov	r3,a
      00BB58 E4               [12] 1364 	clr	a
      00BB59 4F               [12] 1365 	orl	a,r7
      00BB5A F5 4E            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB5C EB               [12] 1367 	mov	a,r3
      00BB5D 4A               [12] 1368 	orl	a,r2
      00BB5E F5 4F            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB60 AC 4E            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB62 AF 4F            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB64 C3               [12] 1373 	clr	c
      00BB65 EC               [12] 1374 	mov	a,r4
      00BB66 94 52            [12] 1375 	subb	a,#0x52
      00BB68 EF               [12] 1376 	mov	a,r7
      00BB69 94 00            [12] 1377 	subb	a,#0x00
      00BB6B D0 04            [24] 1378 	pop	ar4
      00BB6D D0 03            [24] 1379 	pop	ar3
      00BB6F 40 01            [24] 1380 	jc	00109$
      00BB71 22               [24] 1381 	ret
      00BB72                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BB72 E5 4E            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB74 25 4E            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB76 FA               [12] 1386 	mov	r2,a
      00BB77 E5 4F            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB79 33               [12] 1388 	rlc	a
      00BB7A FF               [12] 1389 	mov	r7,a
      00BB7B EA               [12] 1390 	mov	a,r2
      00BB7C 24 02            [12] 1391 	add	a, #_ak820_led_points
      00BB7E F5 50            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB80 EF               [12] 1393 	mov	a,r7
      00BB81 34 C1            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00BB83 F5 51            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB85 85 50 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB88 85 51 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB8B E4               [12] 1398 	clr	a
      00BB8C 93               [24] 1399 	movc	a,@a+dptr
      00BB8D 12 36 47         [24] 1400 	lcall	_ak820_outline_0125
      00BB90 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BB91 85 50 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB94 85 51 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB97 A3               [24] 1405 	inc	dptr
      00BB98 E4               [12] 1406 	clr	a
      00BB99 93               [24] 1407 	movc	a,@a+dptr
      00BB9A 12 3A F6         [24] 1408 	lcall	_ak820_outline_0163
      00BB9D F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BB9E 12 BC 44         [24] 1411 	lcall	_ak820_outline_0039
      00BBA1 A3               [24] 1412 	inc	dptr
      00BBA2 74 04            [12] 1413 	mov	a,#0x04
      00BBA4 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BBA5 90 0D C0         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BBA8 04               [12] 1417 	inc	a
      00BBA9 2D               [12] 1418 	add	a, r5
      00BBAA F0               [24] 1419 	movx	@dptr,a
      00BBAB E4               [12] 1420 	clr	a
      00BBAC 3E               [12] 1421 	addc	a, r6
      00BBAD A3               [24] 1422 	inc	dptr
      00BBAE F0               [24] 1423 	movx	@dptr,a
      00BBAF 85 4E 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BBB2 85 4F 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00BBB5 01 DE            [24] 1428 	ajmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00BBB7                       1443 _vialrgb_set_value:
      00BBB7 12 45 55         [24] 1444 	lcall	_ak820_outline_0036
      00BBBA 90 0D CF         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BBBD 12 3A 5F         [24] 1446 	lcall	_ak820_outline_0016
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BBC0 90 0D CE         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BBC3 E0               [24] 1449 	movx	a,@dptr
      00BBC4 FF               [12] 1450 	mov	r7,a
      00BBC5 BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00BBC8 80 01            [24] 1452 	sjmp	00102$
      00BBCA                       1453 00129$:
      00BBCA 22               [24] 1454 	ret
      00BBCB                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BBCB 90 0D CF         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BBCE 12 BC 4C         [24] 1458 	lcall	_ak820_outline_0046
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BBD1 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00BBD4 80 06            [24] 1462 	sjmp	00103$
      00BBD6                       1463 00130$:
      00BBD6 BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00BBD9 80 5B            [24] 1465 	sjmp	00104$
      00BBDB                       1466 00131$:
      00BBDB 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BBDC                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BBDC 12 4A D1         [24] 1471 	lcall	_ak820_outline_0065
      00BBDF 12 BC 44         [24] 1472 	lcall	_ak820_outline_0039
      00BBE2 E0               [24] 1473 	movx	a,@dptr
      00BBE3 F8               [12] 1474 	mov	r0,a
      00BBE4 79 00            [12] 1475 	mov	r1,#0x00
      00BBE6 88 53            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BBE8 89 52            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BBEA 8A 01            [24] 1478 	mov	ar1,r2
      00BBEC 7A 00            [12] 1479 	mov	r2,#0x00
      00BBEE E5 53            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BBF0 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BBF2 12 45 BE         [24] 1483 	lcall	_ak820_outline_0185
      00BBF5 C0 06            [24] 1484 	push	ar6
      00BBF7 C0 05            [24] 1485 	push	ar5
      00BBF9 11 B1            [24] 1486 	acall	_set_mode
      00BBFB D0 05            [24] 1487 	pop	ar5
      00BBFD D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BBFF 12 BC 44         [24] 1490 	lcall	_ak820_outline_0039
      00BC02 A3               [24] 1491 	inc	dptr
      00BC03 E0               [24] 1492 	movx	a,@dptr
      00BC04 F5 82            [12] 1493 	mov	dpl,a
      00BC06 C0 06            [24] 1494 	push	ar6
      00BC08 C0 05            [24] 1495 	push	ar5
      00BC0A 12 5A A7         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00BC0D D0 05            [24] 1497 	pop	ar5
      00BC0F D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BC11 12 BC 44         [24] 1500 	lcall	_ak820_outline_0039
      00BC14 A3               [24] 1501 	inc	dptr
      00BC15 A3               [24] 1502 	inc	dptr
      00BC16 E0               [24] 1503 	movx	a,@dptr
      00BC17 F9               [12] 1504 	mov	r1,a
      00BC18 7A 00            [12] 1505 	mov	r2,#0x00
      00BC1A 74 06            [12] 1506 	mov	a,#0x06
      00BC1C 12 BC 96         [24] 1507 	lcall	_ak820_outline_0174
      00BC1F F8               [12] 1508 	mov	r0,a
      00BC20 74 07            [12] 1509 	mov	a,#0x07
      00BC22 12 BC 96         [24] 1510 	lcall	_ak820_outline_0174
      00BC25 FE               [12] 1511 	mov	r6,a
      00BC26 90 07 56         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BC29 E8               [12] 1513 	mov	a,r0
      00BC2A F0               [24] 1514 	movx	@dptr,a
      00BC2B 90 07 57         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BC2E EE               [12] 1516 	mov	a,r6
      00BC2F F0               [24] 1517 	movx	@dptr,a
      00BC30 12 45 BE         [24] 1518 	lcall	_ak820_outline_0185
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BC33 02 5A 78         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BC36                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BC36 EF               [12] 1524 	mov	a,r7
      00BC37 24 FE            [12] 1525 	add	a,#0xfe
      00BC39 90 0D C4         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00BC3C 12 74 70         [24] 1527 	lcall	_ak820_outline_0103
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00BC3F 21 11            [24] 1530 	ajmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00BC41                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00BC41 02 55 0B         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00C449                       1548 _supported_modes:
      00C449 00                    1549 	.db #0x00	; 0
      00C44A 00                    1550 	.db #0x00	; 0
      00C44B 01                    1551 	.db #0x01	; 1
      00C44C 05                    1552 	.db #0x05	; 5
      00C44D 02                    1553 	.db #0x02	; 2
      00C44E 01                    1554 	.db #0x01	; 1
      00C44F 06                    1555 	.db #0x06	; 6
      00C450 02                    1556 	.db #0x02	; 2
      00C451 0D                    1557 	.db #0x0d	; 13
      00C452 03                    1558 	.db #0x03	; 3
      00C453 0E                    1559 	.db #0x0e	; 14
      00C454 04                    1560 	.db #0x04	; 4
      00C455 1F                    1561 	.db #0x1f	; 31
      00C456 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0005
                                   1569 	.globl _ak820_outline_0016
                                   1570 	.globl _ak820_outline_0021
                                   1571 	.globl _ak820_outline_0036
                                   1572 	.globl _ak820_outline_0039
                                   1573 	.globl _ak820_outline_0040
                                   1574 	.globl _ak820_outline_0046
                                   1575 	.globl _ak820_outline_0047
                                   1576 	.globl _ak820_outline_0052
                                   1577 	.globl _ak820_outline_0057
                                   1578 	.globl _ak820_outline_0064
                                   1579 	.globl _ak820_outline_0065
                                   1580 	.globl _ak820_outline_0083
                                   1581 	.globl _ak820_outline_0084
                                   1582 	.globl _ak820_outline_0085
                                   1583 	.globl _ak820_outline_0103
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0109
                                   1586 	.globl _ak820_outline_0110
                                   1587 	.globl _ak820_outline_0111
                                   1588 	.globl _ak820_outline_0120
                                   1589 	.globl _ak820_outline_0123
                                   1590 	.globl _ak820_outline_0124
                                   1591 	.globl _ak820_outline_0125
                                   1592 	.globl _ak820_outline_0135
                                   1593 	.globl _ak820_outline_0138
                                   1594 	.globl _ak820_outline_0146
                                   1595 	.globl _ak820_outline_0148
                                   1596 	.globl _ak820_outline_0163
                                   1597 	.globl _ak820_outline_0167
                                   1598 	.globl _ak820_outline_0174
                                   1599 	.globl _ak820_outline_0185
                                   1600 	.globl _ak820_outline_0190
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0039
      00BC44                       1604 _ak820_outline_0039:
      00BC44 8D 82            [24] 1605 	mov	dpl,r5
      00BC46 8E 83            [24] 1606 	mov	dph,r6
      00BC48 A3               [24] 1607 	inc	dptr
      00BC49 A3               [24] 1608 	inc	dptr
      00BC4A A3               [24] 1609 	inc	dptr
      00BC4B 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0046
      00BC4C                       1614 _ak820_outline_0046:
      00BC4C E0               [24] 1615 	movx	a,@dptr
      00BC4D FD               [12] 1616 	mov	r5,a
      00BC4E A3               [24] 1617 	inc	dptr
      00BC4F E0               [24] 1618 	movx	a,@dptr
      00BC50 FE               [12] 1619 	mov	r6,a
      00BC51 74 02            [12] 1620 	mov	a,#0x02
      00BC53 2D               [12] 1621 	add	a,r5
      00BC54 FB               [12] 1622 	mov	r3,a
      00BC55 E4               [12] 1623 	clr	a
      00BC56 3E               [12] 1624 	addc	a,r6
      00BC57 FC               [12] 1625 	mov	r4,a
      00BC58 8D 82            [24] 1626 	mov	dpl,r5
      00BC5A 8E 83            [24] 1627 	mov	dph,r6
      00BC5C A3               [24] 1628 	inc	dptr
      00BC5D E0               [24] 1629 	movx	a,@dptr
      00BC5E FA               [12] 1630 	mov	r2,a
      00BC5F 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0047
      00BC60                       1635 _ak820_outline_0047:
      00BC60 ED               [12] 1636 	mov	a,r5
      00BC61 75 F0 02         [24] 1637 	mov	b,#0x02
      00BC64 A4               [48] 1638 	mul	ab
      00BC65 24 49            [12] 1639 	add	a,#_supported_modes
      00BC67 FB               [12] 1640 	mov	r3,a
      00BC68 74 C4            [12] 1641 	mov	a,#(_supported_modes>>8)
      00BC6A 35 F0            [12] 1642 	addc	a,b
      00BC6C FC               [12] 1643 	mov	r4,a
      00BC6D 8B 82            [24] 1644 	mov	dpl,r3
      00BC6F 8C 83            [24] 1645 	mov	dph,r4
      00BC71 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0083
      00BC72                       1650 _ak820_outline_0083:
      00BC72 90 0D C5         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC75 E0               [24] 1652 	movx	a,@dptr
      00BC76 F9               [12] 1653 	mov	r1,a
      00BC77 A3               [24] 1654 	inc	dptr
      00BC78 E0               [24] 1655 	movx	a,@dptr
      00BC79 FF               [12] 1656 	mov	r7,a
      00BC7A 89 82            [24] 1657 	mov	dpl,r1
      00BC7C 8F 83            [24] 1658 	mov	dph,r7
      00BC7E E0               [24] 1659 	movx	a,@dptr
      00BC7F 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0108
      00BC80                       1664 _ak820_outline_0108:
      00BC80 90 0D C5         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC83 74 01            [12] 1666 	mov	a,#0x01
      00BC85 29               [12] 1667 	add	a,r1
      00BC86 F0               [24] 1668 	movx	@dptr,a
      00BC87 E4               [12] 1669 	clr	a
      00BC88 3F               [12] 1670 	addc	a,r7
      00BC89 A3               [24] 1671 	inc	dptr
      00BC8A F0               [24] 1672 	movx	@dptr,a
      00BC8B 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0148
      00BC8C                       1677 _ak820_outline_0148:
      00BC8C E4               [12] 1678 	clr	a
      00BC8D 93               [24] 1679 	movc	a,@a+dptr
      00BC8E FC               [12] 1680 	mov	r4,a
      00BC8F 7B 00            [12] 1681 	mov	r3,#0x00
      00BC91 8C 82            [24] 1682 	mov	dpl,r4
      00BC93 8B 83            [24] 1683 	mov	dph,r3
      00BC95 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0174
      00BC96                       1688 _ak820_outline_0174:
      00BC96 2D               [12] 1689 	add	a,r5
      00BC97 F5 82            [12] 1690 	mov	dpl,a
      00BC99 E4               [12] 1691 	clr	a
      00BC9A 3E               [12] 1692 	addc	a,r6
      00BC9B F5 83            [12] 1693 	mov	dph,a
      00BC9D E0               [24] 1694 	movx	a,@dptr
      00BC9E 22               [24] 1695 	ret
