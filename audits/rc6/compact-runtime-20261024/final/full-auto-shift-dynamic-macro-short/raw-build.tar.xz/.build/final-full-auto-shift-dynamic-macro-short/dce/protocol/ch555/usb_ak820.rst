                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000018                        577 _control_setup_valid_interface_10000_287:
      000018                        578 	.ds 1
      000019                        579 _control_setup_zero_index_10000_287:
      000019                        580 	.ds 1
      00001A                        581 _control_setup_zero_value_10000_287:
      00001A                        582 	.ds 1
      00001B                        583 _control_setup_zero_length_10000_287:
      00001B                        584 	.ds 1
      00001C                        585 _control_setup_sloc0_1_0:
      00001C                        586 	.ds 1
      00001D                        587 _control_setup_sloc2_1_0:
      00001D                        588 	.ds 1
      00001E                        589 _ak820_usb_try_send_sloc0_1_0:
      00001E                        590 	.ds 1
      00001F                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001F                        592 	.ds 1
      000020                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      000020                        594 	.ds 1
      000021                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000021                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007CB                        605 _D0SetupReqCode::
      0007CB                        606 	.ds 1
      0007CC                        607 _D0SetupLen::
      0007CC                        608 	.ds 2
      0007CE                        609 _pD0Descr::
      0007CE                        610 	.ds 3
      0007D1                        611 _D0UsbConfig::
      0007D1                        612 	.ds 1
      0007D2                        613 _USB_EnumStatus::
      0007D2                        614 	.ds 1
      0007D3                        615 _USB_SleepStatus::
      0007D3                        616 	.ds 1
      0007D4                        617 _MCU_Sleep_Operate::
      0007D4                        618 	.ds 1
      0007D5                        619 _KB_USB_UpStatus::
      0007D5                        620 	.ds 1
      0007D6                        621 _KB_USB_SetReport::
      0007D6                        622 	.ds 1
      0007D7                        623 _ak820_boot_stage::
      0007D7                        624 	.ds 1
      0007D8                        625 _ak820_main_heartbeat::
      0007D8                        626 	.ds 1
      0007D9                        627 _raw_state:
      0007D9                        628 	.ds 1
      0007DA                        629 _raw_buffer:
      0007DA                        630 	.ds 32
      0007FA                        631 _raw_reply_without_nvm:
      0007FA                        632 	.ds 1
      0007FB                        633 _keyboard_reset:
      0007FB                        634 	.ds 1
      0007FC                        635 _input_snapshot:
      0007FC                        636 	.ds 46
      00082A                        637 _control_phase:
      00082A                        638 	.ds 1
      00082B                        639 _output_kind:
      00082B                        640 	.ds 1
      00082C                        641 _output_report_id:
      00082C                        642 	.ds 1
      00082D                        643 _control_zlp:
      00082D                        644 	.ds 1
      00082E                        645 _control_pointer:
      00082E                        646 	.ds 2
      000830                        647 _descriptor_select_PARM_2:
      000830                        648 	.ds 1
      000831                        649 _descriptor_select_PARM_3:
      000831                        650 	.ds 2
      000833                        651 _descriptor_select_type_10000_269:
      000833                        652 	.ds 1
      000834                        653 _control_setup_length_10000_287:
      000834                        654 	.ds 2
      000836                        655 _control_setup_offset_10000_287:
      000836                        656 	.ds 1
      000837                        657 _ak820_usb_send_PARM_2:
      000837                        658 	.ds 2
      000839                        659 _ak820_usb_send_PARM_3:
      000839                        660 	.ds 1
      00083A                        661 _ak820_usb_send_endpoint_10000_423:
      00083A                        662 	.ds 1
      00083B                        663 _ak820_usb_send_offset_10000_424:
      00083B                        664 	.ds 1
      00083C                        665 _ak820_usb_try_send_PARM_2:
      00083C                        666 	.ds 2
      00083E                        667 _ak820_usb_try_send_PARM_3:
      00083E                        668 	.ds 1
      00083F                        669 _ak820_usb_try_send_endpoint_10000_444:
      00083F                        670 	.ds 1
      000840                        671 _ak820_usb_try_send_sent_10000_445:
      000840                        672 	.ds 1
      000841                        673 _ak820_usb_raw_send_PARM_2:
      000841                        674 	.ds 1
      000842                        675 _ak820_usb_raw_send_report_10000_460:
      000842                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      005FBB                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005FBB 90 07 D9         [24]  730 	mov	dptr,#_raw_state
      005FBE E0               [24]  731 	movx	a,@dptr
      005FBF FF               [12]  732 	mov	r7,a
      005FC0 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      005FC3 80 1C            [24]  734 	sjmp	00101$
      005FC5                        735 00130$:
      005FC5 90 07 D9         [24]  736 	mov	dptr,#_raw_state
      005FC8 E0               [24]  737 	movx	a,@dptr
      005FC9 FF               [12]  738 	mov	r7,a
      005FCA BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      005FCD 80 12            [24]  740 	sjmp	00101$
      005FCF                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005FCF 90 07 D9         [24]  743 	mov	dptr,#_raw_state
      005FD2 E0               [24]  744 	movx	a,@dptr
      005FD3 FF               [12]  745 	mov	r7,a
      005FD4 BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      005FD7 80 08            [24]  747 	sjmp	00101$
      005FD9                        748 00132$:
      005FD9 90 07 D9         [24]  749 	mov	dptr,#_raw_state
      005FDC E0               [24]  750 	movx	a,@dptr
      005FDD FF               [12]  751 	mov	r7,a
      005FDE BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      005FE1                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005FE1 90 07 D9         [24]  755 	mov	dptr,#_raw_state
      005FE4 74 07            [12]  756 	mov	a,#0x07
      005FE6 F0               [24]  757 	movx	@dptr,a
      005FE7 80 05            [24]  758 	sjmp	00103$
      005FE9                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005FE9 90 07 D9         [24]  761 	mov	dptr,#_raw_state
      005FEC E4               [12]  762 	clr	a
      005FED F0               [24]  763 	movx	@dptr,a
      005FEE                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005FEE 90 08 2B         [24]  766 	mov	dptr,#_output_kind
      005FF1 E4               [12]  767 	clr	a
      005FF2 F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005FF3 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      005FF4                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005FF4 90 07 D9         [24]  780 	mov	dptr,#_raw_state
      005FF7 E0               [24]  781 	movx	a,@dptr
      005FF8 FF               [12]  782 	mov	r7,a
      005FF9 BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      005FFC 90 07 D9         [24]  784 	mov	dptr,#_raw_state
      005FFF 74 06            [12]  785 	mov	a,#0x06
      006001 F0               [24]  786 	movx	@dptr,a
      006002 22               [24]  787 	ret
      006003                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      006003 90 07 D9         [24]  790 	mov	dptr,#_raw_state
      006006 E0               [24]  791 	movx	a,@dptr
      006007 FF               [12]  792 	mov	r7,a
      006008 BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      00600B 90 07 D9         [24]  794 	mov	dptr,#_raw_state
      00600E E4               [12]  795 	clr	a
      00600F F0               [24]  796 	movx	@dptr,a
      006010                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      006010 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      006011                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      006011 90 22 0C         [24]  811 	mov	dptr,#0x220c
      006014 74 01            [12]  812 	mov	a,#0x01
      006016 F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006017 F5 82            [12]  815 	mov	dpl,a
      006019 74 12            [12]  816 	mov	a,#0x12
      00601B F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00601C A3               [24]  819 	inc	dptr
      00601D F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00601E A3               [24]  822 	inc	dptr
      00601F F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      006020 90 22 0B         [24]  825 	mov	dptr,#0x220b
      006023 E4               [12]  826 	clr	a
      006024 F0               [24]  827 	movx	@dptr,a
      006025 15 82            [12]  828 	dec	dpl
      006027 F0               [24]  829 	movx	@dptr,a
      006028 15 82            [12]  830 	dec	dpl
      00602A F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      00602B FF               [12]  833 	mov	r7,a
      00602C                        834 00103$:
      00602C EF               [12]  835 	mov	a,r7
      00602D 24 FC            [12]  836 	add	a, #_input_snapshot
      00602F F5 82            [12]  837 	mov	dpl,a
      006031 E4               [12]  838 	clr	a
      006032 34 07            [12]  839 	addc	a, #(_input_snapshot >> 8)
      006034 F5 83            [12]  840 	mov	dph,a
      006036 E4               [12]  841 	clr	a
      006037 F0               [24]  842 	movx	@dptr,a
      006038 0F               [12]  843 	inc	r7
      006039 BF 2E 00         [24]  844 	cjne	r7,#0x2e,00139$
      00603C                        845 00139$:
      00603C 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      00603E 90 08 04         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      006041 74 06            [12]  849 	mov	a,#0x06
      006043 F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      006044 90 08 24         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      006047 03               [12]  853 	rr	a
      006048 F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      006049 90 08 27         [24]  856 	mov	dptr,#(_input_snapshot + 0x002b)
      00604C 04               [12]  857 	inc	a
      00604D F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      00604E 7F 00            [12]  860 	mov	r7,#0x00
      006050                        861 00105$:
      006050 8F 06            [24]  862 	mov	ar6,r7
      006052 74 C0            [12]  863 	mov	a,#0xc0
      006054 2E               [12]  864 	add	a, r6
      006055 F5 82            [12]  865 	mov	dpl,a
      006057 74 10            [12]  866 	mov	a,#0x10
      006059 24 00            [12]  867 	add	a, #0x00
      00605B F5 83            [12]  868 	mov	dph,a
      00605D E4               [12]  869 	clr	a
      00605E F0               [24]  870 	movx	@dptr,a
      00605F 0F               [12]  871 	inc	r7
      006060 BF 20 00         [24]  872 	cjne	r7,#0x20,00141$
      006063                        873 00141$:
      006063 40 EB            [24]  874 	jc	00105$
                                    875 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      006065 02 5F BB         [24]  877 	ljmp	_raw_abort
                                    878 ;------------------------------------------------------------
                                    879 ;Allocation info for local variables in function 'control_stall'
                                    880 ;------------------------------------------------------------
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function control_stall
                                    884 ;	-----------------------------------------
      006068                        885 _control_stall:
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      006068 90 07 D9         [24]  887 	mov	dptr,#_raw_state
      00606B E0               [24]  888 	movx	a,@dptr
      00606C FF               [12]  889 	mov	r7,a
      00606D BF 01 05         [24]  890 	cjne	r7,#0x01,00102$
      006070 90 07 D9         [24]  891 	mov	dptr,#_raw_state
      006073 E4               [12]  892 	clr	a
      006074 F0               [24]  893 	movx	@dptr,a
      006075                        894 00102$:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      006075 90 08 2B         [24]  896 	mov	dptr,#_output_kind
      006078 E4               [12]  897 	clr	a
      006079 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      00607A 90 08 2A         [24]  900 	mov	dptr,#_control_phase
      00607D F0               [24]  901 	movx	@dptr,a
                                    902 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      00607E 90 07 CB         [24]  903 	mov	dptr,#_D0SetupReqCode
      006081 14               [12]  904 	dec	a
      006082 F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      006083 90 22 00         [24]  907 	mov	dptr,#0x2200
      006086 74 CF            [12]  908 	mov	a,#0xcf
      006088 F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      006089 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'control_next'
                                    914 ;------------------------------------------------------------
                                    915 ;i             Allocated with name '_control_next_i_10000_266'
                                    916 ;length        Allocated with name '_control_next_length_10000_266'
                                    917 ;------------------------------------------------------------
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function control_next
                                    921 ;	-----------------------------------------
      00608A                        922 _control_next:
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      00608A 90 07 CC         [24]  924 	mov	dptr,#_D0SetupLen
      00608D E0               [24]  925 	movx	a,@dptr
      00608E FE               [12]  926 	mov	r6,a
      00608F A3               [24]  927 	inc	dptr
      006090 E0               [24]  928 	movx	a,@dptr
      006091 FF               [12]  929 	mov	r7,a
      006092 C3               [12]  930 	clr	c
      006093 74 40            [12]  931 	mov	a,#0x40
      006095 9E               [12]  932 	subb	a,r6
      006096 E4               [12]  933 	clr	a
      006097 9F               [12]  934 	subb	a,r7
      006098 50 04            [24]  935 	jnc	00109$
                                    936 ;	free result
      00609A 7E 40            [12]  937 	mov	r6,#0x40
      00609C 80 07            [24]  938 	sjmp	00110$
      00609E                        939 00109$:
      00609E 90 07 CC         [24]  940 	mov	dptr,#_D0SetupLen
      0060A1 E0               [24]  941 	movx	a,@dptr
      0060A2 FE               [12]  942 	mov	r6,a
      0060A3 A3               [24]  943 	inc	dptr
      0060A4 E0               [24]  944 	movx	a,@dptr
      0060A5                        945 00110$:
                                    946 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      0060A5 7F 00            [12]  947 	mov	r7,#0x00
      0060A7                        948 00105$:
      0060A7 C3               [12]  949 	clr	c
      0060A8 EF               [12]  950 	mov	a,r7
      0060A9 9E               [12]  951 	subb	a,r6
      0060AA 50 2A            [24]  952 	jnc	00101$
      0060AC 8F 04            [24]  953 	mov	ar4,r7
      0060AE 74 10            [12]  954 	mov	a,#0x10
      0060B0 24 00            [12]  955 	add	a, #0x00
      0060B2 FD               [12]  956 	mov	r5,a
      0060B3 90 08 2E         [24]  957 	mov	dptr,#_control_pointer
      0060B6 E0               [24]  958 	movx	a,@dptr
      0060B7 FA               [12]  959 	mov	r2,a
      0060B8 A3               [24]  960 	inc	dptr
      0060B9 E0               [24]  961 	movx	a,@dptr
      0060BA FB               [12]  962 	mov	r3,a
      0060BB 8A 82            [24]  963 	mov	dpl,r2
      0060BD 8B 83            [24]  964 	mov	dph,r3
      0060BF E4               [12]  965 	clr	a
      0060C0 93               [24]  966 	movc	a,@a+dptr
      0060C1 F9               [12]  967 	mov	r1,a
      0060C2 90 08 2E         [24]  968 	mov	dptr,#_control_pointer
      0060C5 74 01            [12]  969 	mov	a,#0x01
      0060C7 2A               [12]  970 	add	a, r2
      0060C8 F0               [24]  971 	movx	@dptr,a
      0060C9 E4               [12]  972 	clr	a
      0060CA 3B               [12]  973 	addc	a, r3
      0060CB A3               [24]  974 	inc	dptr
      0060CC F0               [24]  975 	movx	@dptr,a
      0060CD 8C 82            [24]  976 	mov	dpl,r4
      0060CF 8D 83            [24]  977 	mov	dph,r5
      0060D1 E9               [12]  978 	mov	a,r1
      0060D2 F0               [24]  979 	movx	@dptr,a
      0060D3 0F               [12]  980 	inc	r7
      0060D4 80 D1            [24]  981 	sjmp	00105$
      0060D6                        982 00101$:
                                    983 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      0060D6 8E 05            [24]  984 	mov	ar5,r6
      0060D8 7F 00            [12]  985 	mov	r7,#0x00
      0060DA 90 07 CC         [24]  986 	mov	dptr,#_D0SetupLen
      0060DD E0               [24]  987 	movx	a,@dptr
      0060DE FB               [12]  988 	mov	r3,a
      0060DF A3               [24]  989 	inc	dptr
      0060E0 E0               [24]  990 	movx	a,@dptr
      0060E1 FC               [12]  991 	mov	r4,a
      0060E2 EB               [12]  992 	mov	a,r3
      0060E3 C3               [12]  993 	clr	c
      0060E4 9D               [12]  994 	subb	a,r5
      0060E5 FB               [12]  995 	mov	r3,a
      0060E6 EC               [12]  996 	mov	a,r4
      0060E7 9F               [12]  997 	subb	a,r7
      0060E8 FC               [12]  998 	mov	r4,a
      0060E9 90 07 CC         [24]  999 	mov	dptr,#_D0SetupLen
      0060EC EB               [12] 1000 	mov	a,r3
      0060ED F0               [24] 1001 	movx	@dptr,a
      0060EE EC               [12] 1002 	mov	a,r4
      0060EF A3               [24] 1003 	inc	dptr
      0060F0 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      0060F1 EE               [12] 1006 	mov	a,r6
      0060F2 70 05            [24] 1007 	jnz	00103$
      0060F4 90 08 2D         [24] 1008 	mov	dptr,#_control_zlp
      0060F7 E4               [12] 1009 	clr	a
      0060F8 F0               [24] 1010 	movx	@dptr,a
      0060F9                       1011 00103$:
                                   1012 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      0060F9 90 22 08         [24] 1013 	mov	dptr,#0x2208
      0060FC EE               [12] 1014 	mov	a,r6
      0060FD F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      0060FE 90 22 00         [24] 1017 	mov	dptr,#0x2200
      006101 E0               [24] 1018 	movx	a,@dptr
      006102 54 C0            [12] 1019 	anl	a,#0xc0
      006104 F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      006105 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'descriptor_select'
                                   1025 ;------------------------------------------------------------
                                   1026 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1027 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1028 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1029 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function descriptor_select
                                   1034 ;	-----------------------------------------
      006106                       1035 _descriptor_select:
      006106 E5 82            [12] 1036 	mov	a,dpl
      006108 90 08 33         [24] 1037 	mov	dptr,#_descriptor_select_type_10000_269
      00610B F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      00610C E0               [24] 1040 	movx	a,@dptr
      00610D FF               [12] 1041 	mov	r7,a
      00610E BF 01 20         [24] 1042 	cjne	r7,#0x01,00102$
      006111 90 08 30         [24] 1043 	mov	dptr,#_descriptor_select_PARM_2
      006114 E0               [24] 1044 	movx	a,@dptr
      006115 70 1A            [24] 1045 	jnz	00102$
      006117 90 08 31         [24] 1046 	mov	dptr,#_descriptor_select_PARM_3
      00611A E0               [24] 1047 	movx	a,@dptr
      00611B F5 F0            [12] 1048 	mov	b,a
      00611D A3               [24] 1049 	inc	dptr
      00611E E0               [24] 1050 	movx	a,@dptr
      00611F 45 F0            [12] 1051 	orl	a,b
      006121 70 0E            [24] 1052 	jnz	00102$
                                   1053 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      006123 90 08 2E         [24] 1054 	mov	dptr,#_control_pointer
      006126 74 A2            [12] 1055 	mov	a,#_DeviceDescriptor
      006128 F0               [24] 1056 	movx	@dptr,a
      006129 74 C5            [12] 1057 	mov	a,#(_DeviceDescriptor >> 8)
      00612B A3               [24] 1058 	inc	dptr
      00612C F0               [24] 1059 	movx	@dptr,a
                                   1060 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      00612D 90 00 12         [24] 1061 	mov	dptr,#0x0012
      006130 22               [24] 1062 	ret
      006131                       1063 00102$:
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      006131 90 08 33         [24] 1065 	mov	dptr,#_descriptor_select_type_10000_269
      006134 E0               [24] 1066 	movx	a,@dptr
      006135 FF               [12] 1067 	mov	r7,a
      006136 BF 02 20         [24] 1068 	cjne	r7,#0x02,00106$
      006139 90 08 30         [24] 1069 	mov	dptr,#_descriptor_select_PARM_2
      00613C E0               [24] 1070 	movx	a,@dptr
      00613D 70 1A            [24] 1071 	jnz	00106$
      00613F 90 08 31         [24] 1072 	mov	dptr,#_descriptor_select_PARM_3
      006142 E0               [24] 1073 	movx	a,@dptr
      006143 F5 F0            [12] 1074 	mov	b,a
      006145 A3               [24] 1075 	inc	dptr
      006146 E0               [24] 1076 	movx	a,@dptr
      006147 45 F0            [12] 1077 	orl	a,b
      006149 70 0E            [24] 1078 	jnz	00106$
                                   1079 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      00614B 90 08 2E         [24] 1080 	mov	dptr,#_control_pointer
      00614E 74 B4            [12] 1081 	mov	a,#_ConfigurationDescriptor
      006150 F0               [24] 1082 	movx	@dptr,a
      006151 74 C5            [12] 1083 	mov	a,#(_ConfigurationDescriptor >> 8)
      006153 A3               [24] 1084 	inc	dptr
      006154 F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      006155 90 00 54         [24] 1087 	mov	dptr,#0x0054
      006158 22               [24] 1088 	ret
      006159                       1089 00106$:
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      006159 90 08 33         [24] 1091 	mov	dptr,#_descriptor_select_type_10000_269
      00615C E0               [24] 1092 	movx	a,@dptr
      00615D FF               [12] 1093 	mov	r7,a
      00615E BF 03 02         [24] 1094 	cjne	r7,#0x03,00238$
      006161 80 03            [24] 1095 	sjmp	00239$
      006163                       1096 00238$:
      006163 02 61 FD         [24] 1097 	ljmp	00119$
      006166                       1098 00239$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      006166 90 08 31         [24] 1100 	mov	dptr,#_descriptor_select_PARM_3
      006169 E0               [24] 1101 	movx	a,@dptr
      00616A FD               [12] 1102 	mov	r5,a
      00616B A3               [24] 1103 	inc	dptr
      00616C E0               [24] 1104 	movx	a,@dptr
      00616D FE               [12] 1105 	mov	r6,a
      00616E 90 08 31         [24] 1106 	mov	dptr,#_descriptor_select_PARM_3
      006171 E0               [24] 1107 	movx	a,@dptr
      006172 F5 F0            [12] 1108 	mov	b,a
      006174 A3               [24] 1109 	inc	dptr
      006175 E0               [24] 1110 	movx	a,@dptr
      006176 45 F0            [12] 1111 	orl	a,b
      006178 60 0C            [24] 1112 	jz	00110$
      00617A BD 09 05         [24] 1113 	cjne	r5,#0x09,00241$
      00617D BE 04 02         [24] 1114 	cjne	r6,#0x04,00241$
      006180 80 04            [24] 1115 	sjmp	00110$
      006182                       1116 00241$:
      006182 90 00 00         [24] 1117 	mov	dptr,#0x0000
      006185 22               [24] 1118 	ret
      006186                       1119 00110$:
                                   1120 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      006186 90 08 30         [24] 1121 	mov	dptr,#_descriptor_select_PARM_2
      006189 E0               [24] 1122 	movx	a,@dptr
      00618A FE               [12] 1123 	mov  r6,a
      00618B 24 FC            [12] 1124 	add	a,#0xff - 0x03
      00618D 40 6A            [24] 1125 	jc	00116$
                                   1126 ;	free result
      00618F EE               [12] 1127 	mov	a,r6
      006190 2E               [12] 1128 	add	a,r6
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      006191 90 61 95         [24] 1130 	mov	dptr,#00243$
      006194 73               [24] 1131 	jmp	@a+dptr
      006195                       1132 00243$:
      006195 80 06            [24] 1133 	sjmp	00112$
      006197 80 1B            [24] 1134 	sjmp	00113$
      006199 80 30            [24] 1135 	sjmp	00114$
      00619B 80 45            [24] 1136 	sjmp	00115$
      00619D                       1137 00112$:
      00619D 90 08 2E         [24] 1138 	mov	dptr,#_control_pointer
      0061A0 74 08            [12] 1139 	mov	a,#_LanguageString
      0061A2 F0               [24] 1140 	movx	@dptr,a
      0061A3 74 C6            [12] 1141 	mov	a,#(_LanguageString >> 8)
      0061A5 A3               [24] 1142 	inc	dptr
      0061A6 F0               [24] 1143 	movx	@dptr,a
      0061A7 90 C6 08         [24] 1144 	mov	dptr,#_LanguageString
      0061AA E4               [12] 1145 	clr	a
      0061AB 93               [24] 1146 	movc	a,@a+dptr
      0061AC FE               [12] 1147 	mov	r6,a
      0061AD 7D 00            [12] 1148 	mov	r5,#0x00
      0061AF 8E 82            [24] 1149 	mov	dpl, r6
      0061B1 8D 83            [24] 1150 	mov	dph, r5
      0061B3 22               [24] 1151 	ret
                                   1152 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0061B4                       1153 00113$:
      0061B4 90 08 2E         [24] 1154 	mov	dptr,#_control_pointer
      0061B7 74 0C            [12] 1155 	mov	a,#_ManufacturerString
      0061B9 F0               [24] 1156 	movx	@dptr,a
      0061BA 74 C6            [12] 1157 	mov	a,#(_ManufacturerString >> 8)
      0061BC A3               [24] 1158 	inc	dptr
      0061BD F0               [24] 1159 	movx	@dptr,a
      0061BE 90 C6 0C         [24] 1160 	mov	dptr,#_ManufacturerString
      0061C1 E4               [12] 1161 	clr	a
      0061C2 93               [24] 1162 	movc	a,@a+dptr
      0061C3 FE               [12] 1163 	mov	r6,a
      0061C4 7D 00            [12] 1164 	mov	r5,#0x00
      0061C6 8E 82            [24] 1165 	mov	dpl, r6
      0061C8 8D 83            [24] 1166 	mov	dph, r5
      0061CA 22               [24] 1167 	ret
                                   1168 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0061CB                       1169 00114$:
      0061CB 90 08 2E         [24] 1170 	mov	dptr,#_control_pointer
      0061CE 74 1A            [12] 1171 	mov	a,#_ProductString
      0061D0 F0               [24] 1172 	movx	@dptr,a
      0061D1 74 C6            [12] 1173 	mov	a,#(_ProductString >> 8)
      0061D3 A3               [24] 1174 	inc	dptr
      0061D4 F0               [24] 1175 	movx	@dptr,a
      0061D5 90 C6 1A         [24] 1176 	mov	dptr,#_ProductString
      0061D8 E4               [12] 1177 	clr	a
      0061D9 93               [24] 1178 	movc	a,@a+dptr
      0061DA FE               [12] 1179 	mov	r6,a
      0061DB 7D 00            [12] 1180 	mov	r5,#0x00
      0061DD 8E 82            [24] 1181 	mov	dpl, r6
      0061DF 8D 83            [24] 1182 	mov	dph, r5
      0061E1 22               [24] 1183 	ret
                                   1184 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      0061E2                       1185 00115$:
      0061E2 90 08 2E         [24] 1186 	mov	dptr,#_control_pointer
      0061E5 74 52            [12] 1187 	mov	a,#_SerialNumberString
      0061E7 F0               [24] 1188 	movx	@dptr,a
      0061E8 74 C6            [12] 1189 	mov	a,#(_SerialNumberString >> 8)
      0061EA A3               [24] 1190 	inc	dptr
      0061EB F0               [24] 1191 	movx	@dptr,a
      0061EC 90 C6 52         [24] 1192 	mov	dptr,#_SerialNumberString
      0061EF E4               [12] 1193 	clr	a
      0061F0 93               [24] 1194 	movc	a,@a+dptr
      0061F1 FE               [12] 1195 	mov	r6,a
      0061F2 7D 00            [12] 1196 	mov	r5,#0x00
      0061F4 8E 82            [24] 1197 	mov	dpl, r6
      0061F6 8D 83            [24] 1198 	mov	dph, r5
      0061F8 22               [24] 1199 	ret
                                   1200 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      0061F9                       1201 00116$:
      0061F9 90 00 00         [24] 1202 	mov	dptr,#0x0000
      0061FC 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      0061FD                       1205 00119$:
                                   1206 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      0061FD 90 08 30         [24] 1207 	mov	dptr,#_descriptor_select_PARM_2
      006200 E0               [24] 1208 	movx	a,@dptr
      006201 70 11            [24] 1209 	jnz	00120$
      006203 90 08 31         [24] 1210 	mov	dptr,#_descriptor_select_PARM_3
      006206 E0               [24] 1211 	movx	a,@dptr
      006207 FD               [12] 1212 	mov	r5,a
      006208 A3               [24] 1213 	inc	dptr
      006209 E0               [24] 1214 	movx	a,@dptr
      00620A FE               [12] 1215 	mov	r6,a
      00620B C3               [12] 1216 	clr	c
      00620C ED               [12] 1217 	mov	a,r5
      00620D 94 03            [12] 1218 	subb	a,#0x03
      00620F EE               [12] 1219 	mov	a,r6
      006210 94 00            [12] 1220 	subb	a,#0x00
      006212 40 04            [24] 1221 	jc	00121$
      006214                       1222 00120$:
      006214 90 00 00         [24] 1223 	mov	dptr,#0x0000
      006217 22               [24] 1224 	ret
      006218                       1225 00121$:
                                   1226 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006218 BF 22 02         [24] 1227 	cjne	r7,#0x22,00246$
      00621B 80 03            [24] 1228 	sjmp	00127$
      00621D                       1229 00246$:
      00621D BF 21 5D         [24] 1230 	cjne	r7,#0x21,00128$
      006220                       1231 00127$:
                                   1232 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      006220 ED               [12] 1233 	mov	a,r5
      006221 75 F0 04         [24] 1234 	mov	b,#0x04
      006224 A4               [48] 1235 	mul	ab
      006225 24 2B            [12] 1236 	add	a, #_interface_descriptors
      006227 FE               [12] 1237 	mov	r6,a
      006228 74 BF            [12] 1238 	mov	a,#(_interface_descriptors >> 8)
      00622A 35 F0            [12] 1239 	addc	a, b
      00622C FF               [12] 1240 	mov	r7,a
      00622D 8E 82            [24] 1241 	mov	dpl,r6
      00622F 8F 83            [24] 1242 	mov	dph,r7
      006231 A3               [24] 1243 	inc	dptr
      006232 A3               [24] 1244 	inc	dptr
      006233 E4               [12] 1245 	clr	a
      006234 93               [24] 1246 	movc	a,@a+dptr
      006235 FC               [12] 1247 	mov	r4,a
      006236 A3               [24] 1248 	inc	dptr
      006237 E4               [12] 1249 	clr	a
      006238 93               [24] 1250 	movc	a,@a+dptr
                                   1251 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      006239 FD               [12] 1252 	mov	r5,a
      00623A 4C               [12] 1253 	orl	a,r4
      00623B 70 04            [24] 1254 	jnz	00124$
      00623D 90 00 00         [24] 1255 	mov	dptr,#0x0000
      006240 22               [24] 1256 	ret
      006241                       1257 00124$:
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      006241 90 08 33         [24] 1259 	mov	dptr,#_descriptor_select_type_10000_269
      006244 E0               [24] 1260 	movx	a,@dptr
      006245 FB               [12] 1261 	mov	r3,a
      006246 BB 22 28         [24] 1262 	cjne	r3,#0x22,00126$
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006249 8E 82            [24] 1264 	mov	dpl,r6
      00624B 8F 83            [24] 1265 	mov	dph,r7
      00624D E4               [12] 1266 	clr	a
      00624E 93               [24] 1267 	movc	a,@a+dptr
      00624F FE               [12] 1268 	mov	r6,a
      006250 A3               [24] 1269 	inc	dptr
      006251 E4               [12] 1270 	clr	a
      006252 93               [24] 1271 	movc	a,@a+dptr
      006253 FF               [12] 1272 	mov	r7,a
      006254 90 08 2E         [24] 1273 	mov	dptr,#_control_pointer
      006257 EE               [12] 1274 	mov	a,r6
      006258 F0               [24] 1275 	movx	@dptr,a
      006259 EF               [12] 1276 	mov	a,r7
      00625A A3               [24] 1277 	inc	dptr
      00625B F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      00625C 74 07            [12] 1280 	mov	a,#0x07
      00625E 2C               [12] 1281 	add	a, r4
      00625F F5 82            [12] 1282 	mov	dpl,a
      006261 E4               [12] 1283 	clr	a
      006262 3D               [12] 1284 	addc	a, r5
      006263 F5 83            [12] 1285 	mov	dph,a
      006265 E4               [12] 1286 	clr	a
      006266 93               [24] 1287 	movc	a,@a+dptr
      006267 FE               [12] 1288 	mov	r6,a
      006268 A3               [24] 1289 	inc	dptr
      006269 E4               [12] 1290 	clr	a
      00626A 93               [24] 1291 	movc	a,@a+dptr
      00626B FF               [12] 1292 	mov	r7,a
      00626C 8E 82            [24] 1293 	mov	dpl, r6
      00626E 8F 83            [24] 1294 	mov	dph, r7
      006270 22               [24] 1295 	ret
      006271                       1296 00126$:
                                   1297 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      006271 90 08 2E         [24] 1298 	mov	dptr,#_control_pointer
      006274 EC               [12] 1299 	mov	a,r4
      006275 F0               [24] 1300 	movx	@dptr,a
      006276 ED               [12] 1301 	mov	a,r5
      006277 A3               [24] 1302 	inc	dptr
      006278 F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      006279 90 00 09         [24] 1305 	mov	dptr,#0x0009
      00627C 22               [24] 1306 	ret
      00627D                       1307 00128$:
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      00627D 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      006280 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'control_setup'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1316 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1317 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1318 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1319 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1320 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1321 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1322 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1323 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1324 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1325 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1326 ;------------------------------------------------------------
                                   1327 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1328 ;	-----------------------------------------
                                   1329 ;	 function control_setup
                                   1330 ;	-----------------------------------------
      006281                       1331 _control_setup:
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006281 90 10 00         [24] 1333 	mov	dptr,#0x1000
      006284 E0               [24] 1334 	movx	a,@dptr
      006285 FF               [12] 1335 	mov	r7,a
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006286 A3               [24] 1337 	inc	dptr
      006287 A3               [24] 1338 	inc	dptr
      006288 E0               [24] 1339 	movx	a,@dptr
      006289 FE               [12] 1340 	mov	r6,a
      00628A A3               [24] 1341 	inc	dptr
      00628B E0               [24] 1342 	movx	a,@dptr
      00628C FC               [12] 1343 	mov	r4,a
      00628D 7D 00            [12] 1344 	mov	r5,#0x00
      00628F 8E 03            [24] 1345 	mov	ar3,r6
      006291 7E 00            [12] 1346 	mov	r6,#0x00
      006293 ED               [12] 1347 	mov	a,r5
      006294 4B               [12] 1348 	orl	a,r3
      006295 FD               [12] 1349 	mov	r5,a
      006296 EC               [12] 1350 	mov	a,r4
      006297 4E               [12] 1351 	orl	a,r6
      006298 FE               [12] 1352 	mov	r6,a
                                   1353 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006299 A3               [24] 1354 	inc	dptr
      00629A E0               [24] 1355 	movx	a,@dptr
      00629B FC               [12] 1356 	mov	r4,a
      00629C A3               [24] 1357 	inc	dptr
      00629D E0               [24] 1358 	movx	a,@dptr
      00629E FA               [12] 1359 	mov	r2,a
      00629F 7B 00            [12] 1360 	mov	r3,#0x00
      0062A1 8C 01            [24] 1361 	mov	ar1,r4
      0062A3 7C 00            [12] 1362 	mov	r4,#0x00
      0062A5 EB               [12] 1363 	mov	a,r3
      0062A6 49               [12] 1364 	orl	a,r1
      0062A7 FB               [12] 1365 	mov	r3,a
      0062A8 EA               [12] 1366 	mov	a,r2
      0062A9 4C               [12] 1367 	orl	a,r4
      0062AA FC               [12] 1368 	mov	r4,a
                                   1369 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      0062AB C3               [12] 1370 	clr	c
      0062AC EB               [12] 1371 	mov	a,r3
      0062AD 94 03            [12] 1372 	subb	a,#0x03
      0062AF EC               [12] 1373 	mov	a,r4
      0062B0 94 00            [12] 1374 	subb	a,#0x00
      0062B2 92 18            [24] 1375 	mov	_control_setup_valid_interface_10000_287,c
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      0062B4 EB               [12] 1377 	mov	a,r3
      0062B5 4C               [12] 1378 	orl	a,r4
      0062B6 B4 01 00         [24] 1379 	cjne	a,#0x01,01201$
      0062B9                       1380 01201$:
      0062B9 92 19            [24] 1381 	mov	_control_setup_zero_index_10000_287,c
                                   1382 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      0062BB ED               [12] 1383 	mov	a,r5
      0062BC 4E               [12] 1384 	orl	a,r6
      0062BD B4 01 00         [24] 1385 	cjne	a,#0x01,01202$
      0062C0                       1386 01202$:
                                   1387 ;	assignBit
      0062C0 92 1C            [24] 1388 	mov  _control_setup_sloc0_1_0,c
      0062C2 92 1A            [24] 1389 	mov	_control_setup_zero_value_10000_287,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      0062C4 90 08 36         [24] 1391 	mov	dptr,#_control_setup_offset_10000_287
      0062C7 E4               [12] 1392 	clr	a
      0062C8 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0062C9 90 07 D9         [24] 1395 	mov	dptr,#_raw_state
      0062CC E0               [24] 1396 	movx	a,@dptr
      0062CD FA               [12] 1397 	mov	r2,a
      0062CE BA 01 05         [24] 1398 	cjne	r2,#0x01,00102$
      0062D1 90 07 D9         [24] 1399 	mov	dptr,#_raw_state
      0062D4 E4               [12] 1400 	clr	a
      0062D5 F0               [24] 1401 	movx	@dptr,a
      0062D6                       1402 00102$:
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      0062D6 C0 07            [24] 1404 	push	ar7
      0062D8 90 08 2B         [24] 1405 	mov	dptr,#_output_kind
      0062DB E4               [12] 1406 	clr	a
      0062DC F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      0062DD 90 08 2A         [24] 1409 	mov	dptr,#_control_phase
      0062E0 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      0062E1 90 08 2D         [24] 1412 	mov	dptr,#_control_zlp
      0062E4 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0062E5 90 10 01         [24] 1415 	mov	dptr,#0x1001
      0062E8 E0               [24] 1416 	movx	a,@dptr
      0062E9 90 07 CB         [24] 1417 	mov	dptr,#_D0SetupReqCode
      0062EC F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0062ED 90 10 06         [24] 1420 	mov	dptr,#0x1006
      0062F0 E0               [24] 1421 	movx	a,@dptr
      0062F1 FA               [12] 1422 	mov	r2,a
      0062F2 A3               [24] 1423 	inc	dptr
      0062F3 E0               [24] 1424 	movx	a,@dptr
      0062F4 F9               [12] 1425 	mov	r1,a
      0062F5 78 00            [12] 1426 	mov	r0,#0x00
      0062F7 7F 00            [12] 1427 	mov	r7,#0x00
      0062F9 90 07 CC         [24] 1428 	mov	dptr,#_D0SetupLen
      0062FC E8               [12] 1429 	mov	a,r0
      0062FD 4A               [12] 1430 	orl	a,r2
      0062FE F0               [24] 1431 	movx	@dptr,a
      0062FF E9               [12] 1432 	mov	a,r1
      006300 4F               [12] 1433 	orl	a,r7
      006301 A3               [24] 1434 	inc	dptr
      006302 F0               [24] 1435 	movx	@dptr,a
                                   1436 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      006303 90 07 CC         [24] 1437 	mov	dptr,#_D0SetupLen
      006306 E0               [24] 1438 	movx	a,@dptr
      006307 FA               [12] 1439 	mov	r2,a
      006308 A3               [24] 1440 	inc	dptr
      006309 E0               [24] 1441 	movx	a,@dptr
      00630A 4A               [12] 1442 	orl	a,r2
      00630B B4 01 00         [24] 1443 	cjne	a,#0x01,01205$
      00630E                       1444 01205$:
      00630E 92 1B            [24] 1445 	mov	_control_setup_zero_length_10000_287,c
                                   1446 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006310 90 22 00         [24] 1447 	mov	dptr,#0x2200
      006313 74 C2            [12] 1448 	mov	a,#0xc2
      006315 F0               [24] 1449 	movx	@dptr,a
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      006316 90 22 08         [24] 1451 	mov	dptr,#0x2208
      006319 E4               [12] 1452 	clr	a
      00631A F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      00631B 90 07 CB         [24] 1455 	mov	dptr,#_D0SetupReqCode
      00631E E0               [24] 1456 	movx	a,@dptr
      00631F F5 16            [12] 1457 	mov	_control_setup_sloc1_1_0,a
      006321 C3               [12] 1458 	clr	c
      006322 74 0B            [12] 1459 	mov	a,#0x0b
      006324 95 16            [12] 1460 	subb	a,_control_setup_sloc1_1_0
      006326 D0 07            [24] 1461 	pop	ar7
      006328 50 03            [24] 1462 	jnc	01206$
      00632A 02 60 68         [24] 1463 	ljmp	_control_stall
      00632D                       1464 01206$:
                                   1465 ;	free result
      00632D E5 16            [12] 1466 	mov	a,_control_setup_sloc1_1_0
      00632F F5 F0            [12] 1467 	mov	b,a
      006331 24 0B            [12] 1468 	add	a,#(01207$-3-.)
      006333 83               [24] 1469 	movc	a,@a+pc
      006334 F5 82            [12] 1470 	mov	dpl,a
      006336 E5 F0            [12] 1471 	mov	a,b
      006338 24 10            [12] 1472 	add	a,#(01208$-3-.)
      00633A 83               [24] 1473 	movc	a,@a+pc
      00633B F5 83            [12] 1474 	mov	dph,a
      00633D E4               [12] 1475 	clr	a
      00633E 73               [24] 1476 	jmp	@a+dptr
      00633F                       1477 01207$:
      00633F E7                    1478 	.db	00188$
      006340 8D                    1479 	.db	00205$
      006341 D0                    1480 	.db	00282$
      006342 8D                    1481 	.db	00205$
      006343 14                    1482 	.db	00290$
      006344 11                    1483 	.db	00116$
      006345 57                    1484 	.db	00103$
      006346 14                    1485 	.db	00290$
      006347 16                    1486 	.db	00150$
      006348 3A                    1487 	.db	00123$
      006349 46                    1488 	.db	00157$
      00634A 99                    1489 	.db	00173$
      00634B                       1490 01208$:
      00634B 65                    1491 	.db	00188$>>8
      00634C 66                    1492 	.db	00205$>>8
      00634D 69                    1493 	.db	00282$>>8
      00634E 66                    1494 	.db	00205$>>8
      00634F 6A                    1495 	.db	00290$>>8
      006350 64                    1496 	.db	00116$>>8
      006351 63                    1497 	.db	00103$>>8
      006352 6A                    1498 	.db	00290$>>8
      006353 65                    1499 	.db	00150$>>8
      006354 64                    1500 	.db	00123$>>8
      006355 65                    1501 	.db	00157$>>8
      006356 65                    1502 	.db	00173$>>8
                                   1503 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      006357                       1504 00103$:
                                   1505 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      006357 BF 80 02         [24] 1506 	cjne	r7,#0x80,01209$
      00635A 80 08            [24] 1507 	sjmp	00112$
      00635C                       1508 01209$:
      00635C BF 81 02         [24] 1509 	cjne	r7,#0x81,01210$
      00635F 80 03            [24] 1510 	sjmp	01211$
      006361                       1511 01210$:
      006361 02 60 68         [24] 1512 	ljmp	_control_stall
      006364                       1513 01211$:
      006364                       1514 00112$:
                                   1515 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006364 8E 01            [24] 1516 	mov	ar1,r6
      006366 B9 21 02         [24] 1517 	cjne	r1,#0x21,01212$
      006369 80 09            [24] 1518 	sjmp	00301$
      00636B                       1519 01212$:
      00636B B9 22 02         [24] 1520 	cjne	r1,#0x22,01213$
      00636E 80 04            [24] 1521 	sjmp	00301$
      006370                       1522 01213$:
                                   1523 ;	assignBit
      006370 C2 1D            [12] 1524 	clr	_control_setup_sloc2_1_0
      006372 80 02            [24] 1525 	sjmp	00302$
      006374                       1526 00301$:
                                   1527 ;	assignBit
      006374 D2 1D            [12] 1528 	setb	_control_setup_sloc2_1_0
      006376                       1529 00302$:
      006376 E4               [12] 1530 	clr	a
      006377 BF 81 01         [24] 1531 	cjne	r7,#0x81,01214$
      00637A 04               [12] 1532 	inc	a
      00637B                       1533 01214$:
      00637B FA               [12] 1534 	mov	r2,a
      00637C A2 1D            [12] 1535 	mov	c,_control_setup_sloc2_1_0
      00637E E4               [12] 1536 	clr	a
      00637F 33               [12] 1537 	rlc	a
      006380 B5 02 02         [24] 1538 	cjne	a,ar2,01216$
      006383 80 03            [24] 1539 	sjmp	00105$
      006385                       1540 01216$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      006385 02 60 68         [24] 1542 	ljmp	_control_stall
      006388                       1543 00105$:
                                   1544 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      006388 8E 02            [24] 1545 	mov	ar2,r6
      00638A 90 08 30         [24] 1546 	mov	dptr,#_descriptor_select_PARM_2
      00638D ED               [12] 1547 	mov	a,r5
      00638E F0               [24] 1548 	movx	@dptr,a
      00638F 90 08 31         [24] 1549 	mov	dptr,#_descriptor_select_PARM_3
      006392 EB               [12] 1550 	mov	a,r3
      006393 F0               [24] 1551 	movx	@dptr,a
      006394 EC               [12] 1552 	mov	a,r4
      006395 A3               [24] 1553 	inc	dptr
      006396 F0               [24] 1554 	movx	@dptr,a
      006397 8A 82            [24] 1555 	mov	dpl, r2
      006399 12 61 06         [24] 1556 	lcall	_descriptor_select
      00639C 85 82 17         [24] 1557 	mov	_control_setup_sloc3_1_0,dpl
      00639F 85 83 18         [24] 1558 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1559 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      0063A2 E5 17            [12] 1560 	mov	a,_control_setup_sloc3_1_0
      0063A4 45 18            [12] 1561 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0063A6 70 03            [24] 1562 	jnz	00107$
      0063A8 02 60 68         [24] 1563 	ljmp	_control_stall
      0063AB                       1564 00107$:
                                   1565 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0063AB 90 07 CC         [24] 1566 	mov	dptr,#_D0SetupLen
      0063AE E0               [24] 1567 	movx	a,@dptr
      0063AF F8               [12] 1568 	mov	r0,a
      0063B0 A3               [24] 1569 	inc	dptr
      0063B1 E0               [24] 1570 	movx	a,@dptr
      0063B2 FA               [12] 1571 	mov	r2,a
      0063B3 C3               [12] 1572 	clr	c
      0063B4 E5 17            [12] 1573 	mov	a,_control_setup_sloc3_1_0
      0063B6 98               [12] 1574 	subb	a,r0
      0063B7 E5 18            [12] 1575 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063B9 9A               [12] 1576 	subb	a,r2
      0063BA 50 06            [24] 1577 	jnc	00303$
      0063BC E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      0063BE 54 3F            [12] 1579 	anl	a,#0x3f
      0063C0 60 04            [24] 1580 	jz	00304$
      0063C2                       1581 00303$:
                                   1582 ;	assignBit
      0063C2 C2 1D            [12] 1583 	clr	_control_setup_sloc2_1_0
      0063C4 80 02            [24] 1584 	sjmp	00305$
      0063C6                       1585 00304$:
                                   1586 ;	assignBit
      0063C6 D2 1D            [12] 1587 	setb	_control_setup_sloc2_1_0
      0063C8                       1588 00305$:
      0063C8 90 08 2D         [24] 1589 	mov	dptr,#_control_zlp
      0063CB A2 1D            [12] 1590 	mov	c,_control_setup_sloc2_1_0
      0063CD E4               [12] 1591 	clr	a
      0063CE 33               [12] 1592 	rlc	a
      0063CF F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      0063D0 90 07 CC         [24] 1595 	mov	dptr,#_D0SetupLen
      0063D3 E0               [24] 1596 	movx	a,@dptr
      0063D4 F9               [12] 1597 	mov	r1,a
      0063D5 A3               [24] 1598 	inc	dptr
      0063D6 E0               [24] 1599 	movx	a,@dptr
      0063D7 FA               [12] 1600 	mov	r2,a
      0063D8 C3               [12] 1601 	clr	c
      0063D9 E5 17            [12] 1602 	mov	a,_control_setup_sloc3_1_0
      0063DB 99               [12] 1603 	subb	a,r1
      0063DC E5 18            [12] 1604 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063DE 9A               [12] 1605 	subb	a,r2
      0063DF 50 0A            [24] 1606 	jnc	00109$
                                   1607 ;	free result
      0063E1 90 07 CC         [24] 1608 	mov	dptr,#_D0SetupLen
      0063E4 E5 17            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      0063E6 F0               [24] 1610 	movx	@dptr,a
      0063E7 E5 18            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063E9 A3               [24] 1612 	inc	dptr
      0063EA F0               [24] 1613 	movx	@dptr,a
      0063EB                       1614 00109$:
                                   1615 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0063EB 90 07 CC         [24] 1616 	mov	dptr,#_D0SetupLen
      0063EE E0               [24] 1617 	movx	a,@dptr
      0063EF F9               [12] 1618 	mov	r1,a
      0063F0 A3               [24] 1619 	inc	dptr
      0063F1 E0               [24] 1620 	movx	a,@dptr
      0063F2 49               [12] 1621 	orl	a,r1
      0063F3 60 04            [24] 1622 	jz	00306$
      0063F5 7A 01            [12] 1623 	mov	r2,#0x01
      0063F7 80 02            [24] 1624 	sjmp	00307$
      0063F9                       1625 00306$:
      0063F9 7A 02            [12] 1626 	mov	r2,#0x02
      0063FB                       1627 00307$:
      0063FB 90 08 2A         [24] 1628 	mov	dptr,#_control_phase
      0063FE EA               [12] 1629 	mov	a,r2
      0063FF F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      006400 90 07 CC         [24] 1632 	mov	dptr,#_D0SetupLen
      006403 E0               [24] 1633 	movx	a,@dptr
      006404 F9               [12] 1634 	mov	r1,a
      006405 A3               [24] 1635 	inc	dptr
      006406 E0               [24] 1636 	movx	a,@dptr
      006407 49               [12] 1637 	orl	a,r1
      006408 60 03            [24] 1638 	jz	00111$
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      00640A 02 60 8A         [24] 1640 	ljmp	_control_next
      00640D                       1641 00111$:
      00640D 22               [24] 1642 	ret
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      00640E 02 60 68         [24] 1644 	ljmp	_control_stall
                                   1645 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      006411                       1646 00116$:
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006411 EF               [12] 1648 	mov	a,r7
      006412 70 23            [24] 1649 	jnz	00118$
      006414 30 19 20         [24] 1650 	jnb	_control_setup_zero_index_10000_287,00118$
      006417 30 1B 1D         [24] 1651 	jnb	_control_setup_zero_length_10000_287,00118$
      00641A 8D 01            [24] 1652 	mov	ar1,r5
      00641C 8E 02            [24] 1653 	mov	ar2,r6
      00641E C3               [12] 1654 	clr	c
      00641F 74 7F            [12] 1655 	mov	a,#0x7f
      006421 99               [12] 1656 	subb	a,r1
      006422 E4               [12] 1657 	clr	a
      006423 9A               [12] 1658 	subb	a,r2
      006424 40 11            [24] 1659 	jc	00118$
                                   1660 ;	free result
                                   1661 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      006426 90 07 CC         [24] 1662 	mov	dptr,#_D0SetupLen
      006429 ED               [12] 1663 	mov	a,r5
      00642A F0               [24] 1664 	movx	@dptr,a
      00642B EE               [12] 1665 	mov	a,r6
      00642C A3               [24] 1666 	inc	dptr
      00642D F0               [24] 1667 	movx	@dptr,a
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      00642E 90 08 2A         [24] 1669 	mov	dptr,#_control_phase
      006431 74 03            [12] 1670 	mov	a,#0x03
      006433 F0               [24] 1671 	movx	@dptr,a
      006434 02 6A 17         [24] 1672 	ljmp	00291$
      006437                       1673 00118$:
                                   1674 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006437 02 60 68         [24] 1675 	ljmp	_control_stall
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00643A                       1677 00123$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00643A EF               [12] 1679 	mov	a,r7
      00643B 70 3C            [24] 1680 	jnz	00145$
      00643D 30 19 39         [24] 1681 	jnb	_control_setup_zero_index_10000_287,00145$
      006440 30 1B 36         [24] 1682 	jnb	_control_setup_zero_length_10000_287,00145$
      006443 8D 01            [24] 1683 	mov	ar1,r5
      006445 8E 02            [24] 1684 	mov	ar2,r6
      006447 C3               [12] 1685 	clr	c
      006448 74 01            [12] 1686 	mov	a,#0x01
      00644A 99               [12] 1687 	subb	a,r1
      00644B E4               [12] 1688 	clr	a
      00644C 9A               [12] 1689 	subb	a,r2
      00644D 40 2A            [24] 1690 	jc	00145$
                                   1691 ;	free result
                                   1692 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      00644F C0 06            [24] 1693 	push	ar6
      006451 C0 05            [24] 1694 	push	ar5
      006453 12 60 11         [24] 1695 	lcall	_endpoints_reset
      006456 D0 05            [24] 1696 	pop	ar5
      006458 D0 06            [24] 1697 	pop	ar6
                                   1698 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      00645A 90 07 D1         [24] 1699 	mov	dptr,#_D0UsbConfig
      00645D ED               [12] 1700 	mov	a,r5
      00645E F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      00645F A2 1C            [12] 1703 	mov	c,_control_setup_sloc0_1_0
      006461 B3               [12] 1704 	cpl	c
      006462 92 1D            [24] 1705 	mov	_control_setup_sloc2_1_0,c
      006464 90 07 D2         [24] 1706 	mov	dptr,#_USB_EnumStatus
      006467 E4               [12] 1707 	clr	a
      006468 33               [12] 1708 	rlc	a
      006469 F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      00646A 90 07 FB         [24] 1711 	mov	dptr,#_keyboard_reset
      00646D 74 01            [12] 1712 	mov	a,#0x01
      00646F F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      006470 90 08 2A         [24] 1715 	mov	dptr,#_control_phase
      006473 74 03            [12] 1716 	mov	a,#0x03
      006475 F0               [24] 1717 	movx	@dptr,a
      006476 02 6A 17         [24] 1718 	ljmp	00291$
      006479                       1719 00145$:
                                   1720 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      006479 BF 21 02         [24] 1721 	cjne	r7,#0x21,01231$
      00647C 80 03            [24] 1722 	sjmp	01232$
      00647E                       1723 01231$:
      00647E 02 60 68         [24] 1724 	ljmp	_control_stall
      006481                       1725 01232$:
      006481 90 07 D1         [24] 1726 	mov	dptr,#_D0UsbConfig
      006484 E0               [24] 1727 	movx	a,@dptr
      006485 70 03            [24] 1728 	jnz	01233$
      006487 02 60 68         [24] 1729 	ljmp	_control_stall
      00648A                       1730 01233$:
                                   1731 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00648A BB 01 2D         [24] 1732 	cjne	r3,#0x01,00135$
      00648D BC 00 2A         [24] 1733 	cjne	r4,#0x00,00135$
      006490 8D 01            [24] 1734 	mov	ar1,r5
      006492 8E 02            [24] 1735 	mov	ar2,r6
      006494 B9 00 23         [24] 1736 	cjne	r1,#0x00,00135$
      006497 BA 02 20         [24] 1737 	cjne	r2,#0x02,00135$
      00649A 90 07 CC         [24] 1738 	mov	dptr,#_D0SetupLen
      00649D E0               [24] 1739 	movx	a,@dptr
      00649E F9               [12] 1740 	mov	r1,a
      00649F A3               [24] 1741 	inc	dptr
      0064A0 E0               [24] 1742 	movx	a,@dptr
      0064A1 FA               [12] 1743 	mov	r2,a
      0064A2 B9 20 15         [24] 1744 	cjne	r1,#0x20,00135$
      0064A5 BA 00 12         [24] 1745 	cjne	r2,#0x00,00135$
      0064A8 90 07 D9         [24] 1746 	mov	dptr,#_raw_state
      0064AB E0               [24] 1747 	movx	a,@dptr
      0064AC 70 0C            [24] 1748 	jnz	00135$
                                   1749 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      0064AE 90 07 D9         [24] 1750 	mov	dptr,#_raw_state
      0064B1 74 01            [12] 1751 	mov	a,#0x01
      0064B3 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      0064B4 90 08 2B         [24] 1754 	mov	dptr,#_output_kind
      0064B7 F0               [24] 1755 	movx	@dptr,a
      0064B8 80 52            [24] 1756 	sjmp	00136$
      0064BA                       1757 00135$:
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0064BA EB               [12] 1759 	mov	a,r3
      0064BB 4C               [12] 1760 	orl	a,r4
      0064BC 70 20            [24] 1761 	jnz	00130$
      0064BE 8D 01            [24] 1762 	mov	ar1,r5
      0064C0 8E 02            [24] 1763 	mov	ar2,r6
      0064C2 B9 00 19         [24] 1764 	cjne	r1,#0x00,00130$
      0064C5 BA 02 16         [24] 1765 	cjne	r2,#0x02,00130$
      0064C8 90 07 CC         [24] 1766 	mov	dptr,#_D0SetupLen
      0064CB E0               [24] 1767 	movx	a,@dptr
      0064CC F9               [12] 1768 	mov	r1,a
      0064CD A3               [24] 1769 	inc	dptr
      0064CE E0               [24] 1770 	movx	a,@dptr
      0064CF FA               [12] 1771 	mov	r2,a
      0064D0 B9 01 0B         [24] 1772 	cjne	r1,#0x01,00130$
      0064D3 BA 00 08         [24] 1773 	cjne	r2,#0x00,00130$
                                   1774 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      0064D6 90 08 2B         [24] 1775 	mov	dptr,#_output_kind
      0064D9 74 02            [12] 1776 	mov	a,#0x02
      0064DB F0               [24] 1777 	movx	@dptr,a
      0064DC 80 2E            [24] 1778 	sjmp	00136$
      0064DE                       1779 00130$:
                                   1780 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0064DE BB 02 28         [24] 1781 	cjne	r3,#0x02,00125$
      0064E1 BC 00 25         [24] 1782 	cjne	r4,#0x00,00125$
      0064E4 8D 01            [24] 1783 	mov	ar1,r5
      0064E6 8E 02            [24] 1784 	mov	ar2,r6
      0064E8 B9 06 1E         [24] 1785 	cjne	r1,#0x06,00125$
      0064EB BA 02 1B         [24] 1786 	cjne	r2,#0x02,00125$
      0064EE 90 07 CC         [24] 1787 	mov	dptr,#_D0SetupLen
      0064F1 E0               [24] 1788 	movx	a,@dptr
      0064F2 F9               [12] 1789 	mov	r1,a
      0064F3 A3               [24] 1790 	inc	dptr
      0064F4 E0               [24] 1791 	movx	a,@dptr
      0064F5 FA               [12] 1792 	mov	r2,a
      0064F6 B9 02 10         [24] 1793 	cjne	r1,#0x02,00125$
      0064F9 BA 00 0D         [24] 1794 	cjne	r2,#0x00,00125$
                                   1795 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      0064FC 90 08 2B         [24] 1796 	mov	dptr,#_output_kind
      0064FF 74 03            [12] 1797 	mov	a,#0x03
      006501 F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      006502 90 08 2C         [24] 1800 	mov	dptr,#_output_report_id
      006505 23               [12] 1801 	rl	a
      006506 F0               [24] 1802 	movx	@dptr,a
      006507 80 03            [24] 1803 	sjmp	00136$
      006509                       1804 00125$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      006509 02 60 68         [24] 1806 	ljmp	_control_stall
      00650C                       1807 00136$:
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      00650C 90 08 2A         [24] 1809 	mov	dptr,#_control_phase
      00650F 74 04            [12] 1810 	mov	a,#0x04
      006511 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      006512 22               [24] 1813 	ret
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      006513 02 60 68         [24] 1815 	ljmp	_control_stall
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      006516                       1817 00150$:
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006516 BF 80 2A         [24] 1819 	cjne	r7,#0x80,00152$
      006519 30 19 27         [24] 1820 	jnb	_control_setup_zero_index_10000_287,00152$
      00651C 30 1A 24         [24] 1821 	jnb	_control_setup_zero_value_10000_287,00152$
      00651F 90 07 CC         [24] 1822 	mov	dptr,#_D0SetupLen
      006522 E0               [24] 1823 	movx	a,@dptr
      006523 F9               [12] 1824 	mov	r1,a
      006524 A3               [24] 1825 	inc	dptr
      006525 E0               [24] 1826 	movx	a,@dptr
      006526 FA               [12] 1827 	mov	r2,a
      006527 B9 01 19         [24] 1828 	cjne	r1,#0x01,00152$
      00652A BA 00 16         [24] 1829 	cjne	r2,#0x00,00152$
                                   1830 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      00652D 90 07 D1         [24] 1831 	mov	dptr,#_D0UsbConfig
      006530 E0               [24] 1832 	movx	a,@dptr
      006531 90 10 00         [24] 1833 	mov	dptr,#0x1000
      006534 F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      006535 90 22 08         [24] 1836 	mov	dptr,#0x2208
      006538 74 01            [12] 1837 	mov	a,#0x01
      00653A F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      00653B 90 08 2A         [24] 1840 	mov	dptr,#_control_phase
      00653E 04               [12] 1841 	inc	a
      00653F F0               [24] 1842 	movx	@dptr,a
      006540 02 6A 17         [24] 1843 	ljmp	00291$
      006543                       1844 00152$:
                                   1845 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      006543 02 60 68         [24] 1846 	ljmp	_control_stall
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006546                       1848 00157$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006546 BF 81 2C         [24] 1850 	cjne	r7,#0x81,00167$
      006549 30 18 29         [24] 1851 	jnb	_control_setup_valid_interface_10000_287,00167$
      00654C 30 1A 26         [24] 1852 	jnb	_control_setup_zero_value_10000_287,00167$
      00654F 90 07 CC         [24] 1853 	mov	dptr,#_D0SetupLen
      006552 E0               [24] 1854 	movx	a,@dptr
      006553 F9               [12] 1855 	mov	r1,a
      006554 A3               [24] 1856 	inc	dptr
      006555 E0               [24] 1857 	movx	a,@dptr
      006556 FA               [12] 1858 	mov	r2,a
      006557 B9 01 1B         [24] 1859 	cjne	r1,#0x01,00167$
      00655A BA 00 18         [24] 1860 	cjne	r2,#0x00,00167$
      00655D 90 07 D1         [24] 1861 	mov	dptr,#_D0UsbConfig
      006560 E0               [24] 1862 	movx	a,@dptr
      006561 60 12            [24] 1863 	jz	00167$
                                   1864 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      006563 90 10 00         [24] 1865 	mov	dptr,#0x1000
      006566 E4               [12] 1866 	clr	a
      006567 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      006568 90 22 08         [24] 1869 	mov	dptr,#0x2208
      00656B 04               [12] 1870 	inc	a
      00656C F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      00656D 90 08 2A         [24] 1873 	mov	dptr,#_control_phase
      006570 04               [12] 1874 	inc	a
      006571 F0               [24] 1875 	movx	@dptr,a
      006572 02 6A 17         [24] 1876 	ljmp	00291$
      006575                       1877 00167$:
                                   1878 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006575 30 18 1E         [24] 1879 	jnb	_control_setup_valid_interface_10000_287,00161$
      006578 90 07 D1         [24] 1880 	mov	dptr,#_D0UsbConfig
      00657B E0               [24] 1881 	movx	a,@dptr
      00657C 60 18            [24] 1882 	jz	00161$
      00657E BF 21 15         [24] 1883 	cjne	r7,#0x21,00161$
      006581 30 1B 12         [24] 1884 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006584 EB               [12] 1886 	mov	a,r3
      006585 4C               [12] 1887 	orl	a,r4
      006586 70 05            [24] 1888 	jnz	00159$
      006588 90 06 A9         [24] 1889 	mov	dptr,#_keyboard_idle
      00658B EE               [12] 1890 	mov	a,r6
      00658C F0               [24] 1891 	movx	@dptr,a
      00658D                       1892 00159$:
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      00658D 90 08 2A         [24] 1894 	mov	dptr,#_control_phase
      006590 74 03            [12] 1895 	mov	a,#0x03
      006592 F0               [24] 1896 	movx	@dptr,a
      006593 02 6A 17         [24] 1897 	ljmp	00291$
      006596                       1898 00161$:
                                   1899 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      006596 02 60 68         [24] 1900 	ljmp	_control_stall
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006599                       1902 00173$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006599 BF 01 18         [24] 1904 	cjne	r7,#0x01,00182$
      00659C 30 18 15         [24] 1905 	jnb	_control_setup_valid_interface_10000_287,00182$
      00659F 30 1A 12         [24] 1906 	jnb	_control_setup_zero_value_10000_287,00182$
      0065A2 30 1B 0F         [24] 1907 	jnb	_control_setup_zero_length_10000_287,00182$
      0065A5 90 07 D1         [24] 1908 	mov	dptr,#_D0UsbConfig
      0065A8 E0               [24] 1909 	movx	a,@dptr
      0065A9 60 09            [24] 1910 	jz	00182$
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      0065AB 90 08 2A         [24] 1912 	mov	dptr,#_control_phase
      0065AE 74 03            [12] 1913 	mov	a,#0x03
      0065B0 F0               [24] 1914 	movx	@dptr,a
      0065B1 02 6A 17         [24] 1915 	ljmp	00291$
      0065B4                       1916 00182$:
                                   1917 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0065B4 EB               [12] 1918 	mov	a,r3
      0065B5 4C               [12] 1919 	orl	a,r4
      0065B6 70 2C            [24] 1920 	jnz	00175$
      0065B8 90 07 D1         [24] 1921 	mov	dptr,#_D0UsbConfig
      0065BB E0               [24] 1922 	movx	a,@dptr
      0065BC 60 26            [24] 1923 	jz	00175$
      0065BE BF 21 23         [24] 1924 	cjne	r7,#0x21,00175$
      0065C1 30 1B 20         [24] 1925 	jnb	_control_setup_zero_length_10000_287,00175$
      0065C4 8D 01            [24] 1926 	mov	ar1,r5
      0065C6 8E 02            [24] 1927 	mov	ar2,r6
      0065C8 C3               [12] 1928 	clr	c
      0065C9 74 01            [12] 1929 	mov	a,#0x01
      0065CB 99               [12] 1930 	subb	a,r1
      0065CC E4               [12] 1931 	clr	a
      0065CD 9A               [12] 1932 	subb	a,r2
      0065CE 40 14            [24] 1933 	jc	00175$
                                   1934 ;	free result
                                   1935 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      0065D0 90 0E 1D         [24] 1936 	mov	dptr,#_keyboard_protocol
      0065D3 ED               [12] 1937 	mov	a,r5
      0065D4 F0               [24] 1938 	movx	@dptr,a
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      0065D5 90 07 FB         [24] 1940 	mov	dptr,#_keyboard_reset
      0065D8 74 01            [12] 1941 	mov	a,#0x01
      0065DA F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      0065DB 90 08 2A         [24] 1944 	mov	dptr,#_control_phase
      0065DE 74 03            [12] 1945 	mov	a,#0x03
      0065E0 F0               [24] 1946 	movx	@dptr,a
      0065E1 02 6A 17         [24] 1947 	ljmp	00291$
      0065E4                       1948 00175$:
                                   1949 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      0065E4 02 60 68         [24] 1950 	ljmp	_control_stall
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      0065E7                       1952 00188$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      0065E7 20 1A 03         [24] 1954 	jb	_control_setup_zero_value_10000_287,01283$
      0065EA 02 60 68         [24] 1955 	ljmp	_control_stall
      0065ED                       1956 01283$:
      0065ED 90 07 CC         [24] 1957 	mov	dptr,#_D0SetupLen
      0065F0 E0               [24] 1958 	movx	a,@dptr
      0065F1 F9               [12] 1959 	mov	r1,a
      0065F2 A3               [24] 1960 	inc	dptr
      0065F3 E0               [24] 1961 	movx	a,@dptr
      0065F4 FA               [12] 1962 	mov	r2,a
      0065F5 B9 02 05         [24] 1963 	cjne	r1,#0x02,01284$
      0065F8 BA 00 02         [24] 1964 	cjne	r2,#0x00,01284$
      0065FB 80 03            [24] 1965 	sjmp	01285$
      0065FD                       1966 01284$:
      0065FD 02 60 68         [24] 1967 	ljmp	_control_stall
      006600                       1968 01285$:
                                   1969 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006600 E4               [12] 1970 	clr	a
      006601 BF 80 01         [24] 1971 	cjne	r7,#0x80,01286$
      006604 04               [12] 1972 	inc	a
      006605                       1973 01286$:
      006605 FA               [12] 1974 	mov	r2,a
      006606 60 03            [24] 1975 	jz	00196$
      006608 20 19 35         [24] 1976 	jb	_control_setup_zero_index_10000_287,00189$
      00660B                       1977 00196$:
      00660B BF 81 09         [24] 1978 	cjne	r7,#0x81,00202$
      00660E 30 18 06         [24] 1979 	jnb	_control_setup_valid_interface_10000_287,00202$
      006611 90 07 D1         [24] 1980 	mov	dptr,#_D0UsbConfig
      006614 E0               [24] 1981 	movx	a,@dptr
      006615 70 29            [24] 1982 	jnz	00189$
      006617                       1983 00202$:
                                   1984 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006617 BF 82 70         [24] 1985 	cjne	r7,#0x82,00190$
      00661A 90 07 D1         [24] 1986 	mov	dptr,#_D0UsbConfig
      00661D E0               [24] 1987 	movx	a,@dptr
      00661E 60 6A            [24] 1988 	jz	00190$
      006620 EB               [12] 1989 	mov	a,r3
      006621 4C               [12] 1990 	orl	a,r4
      006622 60 1C            [24] 1991 	jz	00189$
      006624 8B 00            [24] 1992 	mov	ar0,r3
      006626 8C 01            [24] 1993 	mov	ar1,r4
      006628 B8 80 05         [24] 1994 	cjne	r0,#0x80,01298$
      00662B B9 00 02         [24] 1995 	cjne	r1,#0x00,01298$
      00662E 80 10            [24] 1996 	sjmp	00189$
      006630                       1997 01298$:
      006630 C3               [12] 1998 	clr	c
      006631 E8               [12] 1999 	mov	a,r0
      006632 94 81            [12] 2000 	subb	a,#0x81
      006634 E9               [12] 2001 	mov	a,r1
      006635 94 00            [12] 2002 	subb	a,#0x00
      006637 40 51            [24] 2003 	jc	00190$
      006639 74 83            [12] 2004 	mov	a,#0x83
      00663B 98               [12] 2005 	subb	a,r0
      00663C E4               [12] 2006 	clr	a
      00663D 99               [12] 2007 	subb	a,r1
      00663E 40 4A            [24] 2008 	jc	00190$
                                   2009 ;	free result
      006640                       2010 00189$:
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      006640 8B 01            [24] 2012 	mov	ar1,r3
      006642 53 01 07         [24] 2013 	anl	ar1,#0x07
                                   2014 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006645 EA               [12] 2015 	mov	a,r2
      006646 60 0B            [24] 2016 	jz	00308$
      006648 90 07 D3         [24] 2017 	mov	dptr,#_USB_SleepStatus
      00664B E0               [24] 2018 	movx	a,@dptr
      00664C 54 01            [12] 2019 	anl	a,#0x01
      00664E 25 E0            [12] 2020 	add	a,acc
      006650 FA               [12] 2021 	mov	r2,a
      006651 80 22            [24] 2022 	sjmp	00309$
      006653                       2023 00308$:
                                   2024 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006653 BF 82 1B         [24] 2025 	cjne	r7,#0x82,00310$
      006656 E9               [12] 2026 	mov	a,r1
      006657 60 18            [24] 2027 	jz	00310$
      006659 89 00            [24] 2028 	mov	ar0,r1
      00665B 79 00            [12] 2029 	mov	r1,#0x00
      00665D 74 22            [12] 2030 	mov	a,#0x22
      00665F 29               [12] 2031 	add	a, r1
      006660 F9               [12] 2032 	mov	r1,a
      006661 88 82            [24] 2033 	mov	dpl,r0
      006663 89 83            [24] 2034 	mov	dph,r1
      006665 E0               [24] 2035 	movx	a,@dptr
      006666 F9               [12] 2036 	mov	r1,a
      006667 53 01 03         [24] 2037 	anl	ar1,#0x03
      00666A B9 03 04         [24] 2038 	cjne	r1,#0x03,00310$
      00666D 79 01            [12] 2039 	mov	r1,#0x01
      00666F 80 02            [24] 2040 	sjmp	00311$
      006671                       2041 00310$:
      006671 79 00            [12] 2042 	mov	r1,#0x00
      006673                       2043 00311$:
      006673 89 02            [24] 2044 	mov	ar2,r1
      006675                       2045 00309$:
      006675 90 10 00         [24] 2046 	mov	dptr,#0x1000
      006678 EA               [12] 2047 	mov	a,r2
      006679 F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      00667A A3               [24] 2050 	inc	dptr
      00667B E4               [12] 2051 	clr	a
      00667C F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      00667D 90 22 08         [24] 2054 	mov	dptr,#0x2208
      006680 74 02            [12] 2055 	mov	a,#0x02
      006682 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      006683 90 08 2A         [24] 2058 	mov	dptr,#_control_phase
      006686 F0               [24] 2059 	movx	@dptr,a
      006687 02 6A 17         [24] 2060 	ljmp	00291$
      00668A                       2061 00190$:
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      00668A 02 60 68         [24] 2063 	ljmp	_control_stall
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00668D                       2065 00205$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      00668D 20 1B 03         [24] 2067 	jb	_control_setup_zero_length_10000_287,01307$
      006690 02 67 20         [24] 2068 	ljmp	00279$
      006693                       2069 01307$:
      006693 90 07 D1         [24] 2070 	mov	dptr,#_D0UsbConfig
      006696 E0               [24] 2071 	movx	a,@dptr
      006697 70 03            [24] 2072 	jnz	01308$
      006699 02 67 20         [24] 2073 	ljmp	00279$
      00669C                       2074 01308$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      00669C EF               [12] 2076 	mov	a,r7
      00669D 70 29            [24] 2077 	jnz	00218$
      00669F 8D 01            [24] 2078 	mov	ar1,r5
      0066A1 8E 02            [24] 2079 	mov	ar2,r6
      0066A3 B9 01 22         [24] 2080 	cjne	r1,#0x01,00218$
      0066A6 BA 00 1F         [24] 2081 	cjne	r2,#0x00,00218$
      0066A9 30 19 1C         [24] 2082 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0066AC 90 07 CB         [24] 2084 	mov	dptr,#_D0SetupReqCode
      0066AF E0               [24] 2085 	movx	a,@dptr
      0066B0 FA               [12] 2086 	mov	r2,a
      0066B1 BA 03 0A         [24] 2087 	cjne	r2,#0x03,00207$
      0066B4 90 07 D3         [24] 2088 	mov	dptr,#_USB_SleepStatus
      0066B7 E0               [24] 2089 	movx	a,@dptr
      0066B8 43 E0 01         [24] 2090 	orl	acc,#0x01
      0066BB F0               [24] 2091 	movx	@dptr,a
      0066BC 80 59            [24] 2092 	sjmp	00219$
      0066BE                       2093 00207$:
                                   2094 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      0066BE 90 07 D3         [24] 2095 	mov	dptr,#_USB_SleepStatus
      0066C1 E0               [24] 2096 	movx	a,@dptr
      0066C2 53 E0 FE         [24] 2097 	anl	acc,#0xfe
      0066C5 F0               [24] 2098 	movx	@dptr,a
      0066C6 80 4F            [24] 2099 	sjmp	00219$
      0066C8                       2100 00218$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0066C8 BF 02 49         [24] 2102 	cjne	r7,#0x02,00212$
      0066CB 30 1A 46         [24] 2103 	jnb	_control_setup_zero_value_10000_287,00212$
      0066CE 8B 01            [24] 2104 	mov	ar1,r3
      0066D0 8C 02            [24] 2105 	mov	ar2,r4
      0066D2 C3               [12] 2106 	clr	c
      0066D3 E9               [12] 2107 	mov	a,r1
      0066D4 94 81            [12] 2108 	subb	a,#0x81
      0066D6 EA               [12] 2109 	mov	a,r2
      0066D7 94 00            [12] 2110 	subb	a,#0x00
      0066D9 40 39            [24] 2111 	jc	00212$
      0066DB 74 83            [12] 2112 	mov	a,#0x83
      0066DD 99               [12] 2113 	subb	a,r1
      0066DE E4               [12] 2114 	clr	a
      0066DF 9A               [12] 2115 	subb	a,r2
      0066E0 40 32            [24] 2116 	jc	00212$
                                   2117 ;	free result
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      0066E2 8B 02            [24] 2119 	mov	ar2,r3
      0066E4 53 02 07         [24] 2120 	anl	ar2,#0x07
                                   2121 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0066E7 8A 00            [24] 2122 	mov	ar0,r2
      0066E9 79 00            [12] 2123 	mov	r1,#0x00
      0066EB 74 22            [12] 2124 	mov	a,#0x22
      0066ED 29               [12] 2125 	add	a, r1
      0066EE F9               [12] 2126 	mov	r1,a
      0066EF 88 17            [24] 2127 	mov	_control_setup_sloc3_1_0,r0
      0066F1 89 18            [24] 2128 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0066F3 90 07 CB         [24] 2129 	mov	dptr,#_D0SetupReqCode
      0066F6 E0               [24] 2130 	movx	a,@dptr
      0066F7 F9               [12] 2131 	mov	r1,a
      0066F8 B9 03 04         [24] 2132 	cjne	r1,#0x03,00318$
      0066FB 79 03            [12] 2133 	mov	r1,#0x03
      0066FD 80 02            [24] 2134 	sjmp	00319$
      0066FF                       2135 00318$:
      0066FF 79 02            [12] 2136 	mov	r1,#0x02
      006701                       2137 00319$:
      006701 43 01 10         [24] 2138 	orl	ar1,#0x10
      006704 85 17 82         [24] 2139 	mov	dpl,_control_setup_sloc3_1_0
      006707 85 18 83         [24] 2140 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00670A E9               [12] 2141 	mov	a,r1
      00670B F0               [24] 2142 	movx	@dptr,a
                                   2143 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00670C BA 03 08         [24] 2144 	cjne	r2,#0x03,00219$
      00670F 12 5F F4         [24] 2145 	lcall	_raw_complete
      006712 80 03            [24] 2146 	sjmp	00219$
      006714                       2147 00212$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006714 02 60 68         [24] 2149 	ljmp	_control_stall
      006717                       2150 00219$:
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006717 90 08 2A         [24] 2152 	mov	dptr,#_control_phase
      00671A 74 03            [12] 2153 	mov	a,#0x03
      00671C F0               [24] 2154 	movx	@dptr,a
      00671D 02 6A 17         [24] 2155 	ljmp	00291$
      006720                       2156 00279$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006720 E4               [12] 2158 	clr	a
      006721 BF A1 01         [24] 2159 	cjne	r7,#0xa1,01324$
      006724 04               [12] 2160 	inc	a
      006725                       2161 01324$:
      006725 FA               [12] 2162 	mov	r2,a
      006726 70 03            [24] 2163 	jnz	01326$
      006728 02 69 92         [24] 2164 	ljmp	00273$
      00672B                       2165 01326$:
      00672B 90 07 CB         [24] 2166 	mov	dptr,#_D0SetupReqCode
      00672E E0               [24] 2167 	movx	a,@dptr
      00672F F9               [12] 2168 	mov	r1,a
      006730 B9 01 02         [24] 2169 	cjne	r1,#0x01,01327$
      006733 80 03            [24] 2170 	sjmp	01328$
      006735                       2171 01327$:
      006735 02 69 92         [24] 2172 	ljmp	00273$
      006738                       2173 01328$:
      006738 90 07 D1         [24] 2174 	mov	dptr,#_D0UsbConfig
      00673B E0               [24] 2175 	movx	a,@dptr
      00673C 70 03            [24] 2176 	jnz	01329$
      00673E 02 69 92         [24] 2177 	ljmp	00273$
      006741                       2178 01329$:
      006741 90 07 CC         [24] 2179 	mov	dptr,#_D0SetupLen
      006744 E0               [24] 2180 	movx	a,@dptr
      006745 F8               [12] 2181 	mov	r0,a
      006746 A3               [24] 2182 	inc	dptr
      006747 E0               [24] 2183 	movx	a,@dptr
      006748 48               [12] 2184 	orl	a,r0
      006749 70 03            [24] 2185 	jnz	01330$
      00674B 02 69 92         [24] 2186 	ljmp	00273$
      00674E                       2187 01330$:
                                   2188 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      00674E C0 03            [24] 2189 	push	ar3
      006750 C0 04            [24] 2190 	push	ar4
      006752 8D 01            [24] 2191 	mov	ar1,r5
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006754 8E 00            [24] 2193 	mov	ar0,r6
      006756 B8 01 03         [24] 2194 	cjne	r0,#0x01,01331$
      006759 E8               [12] 2195 	mov	a,r0
      00675A 80 01            [24] 2196 	sjmp	01332$
      00675C                       2197 01331$:
      00675C E4               [12] 2198 	clr	a
      00675D                       2199 01332$:
      00675D F5 17            [12] 2200 	mov	_control_setup_sloc3_1_0,a
      00675F D0 04            [24] 2201 	pop	ar4
      006761 D0 03            [24] 2202 	pop	ar3
      006763 E5 17            [12] 2203 	mov	a,_control_setup_sloc3_1_0
      006765 60 17            [24] 2204 	jz	00251$
      006767 EB               [12] 2205 	mov	a,r3
      006768 4C               [12] 2206 	orl	a,r4
      006769 70 13            [24] 2207 	jnz	00251$
      00676B E9               [12] 2208 	mov	a,r1
      00676C 70 10            [24] 2209 	jnz	00251$
                                   2210 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      00676E 90 08 34         [24] 2211 	mov	dptr,#_control_setup_length_10000_287
      006771 74 08            [12] 2212 	mov	a,#0x08
      006773 F0               [24] 2213 	movx	@dptr,a
      006774 E4               [12] 2214 	clr	a
      006775 A3               [24] 2215 	inc	dptr
      006776 F0               [24] 2216 	movx	@dptr,a
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      006777 90 08 36         [24] 2218 	mov	dptr,#_control_setup_offset_10000_287
      00677A F0               [24] 2219 	movx	@dptr,a
      00677B 02 69 02         [24] 2220 	ljmp	00252$
      00677E                       2221 00251$:
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00677E E5 17            [12] 2223 	mov	a,_control_setup_sloc3_1_0
      006780 60 27            [24] 2224 	jz	00245$
      006782 BB 02 24         [24] 2225 	cjne	r3,#0x02,00245$
      006785 BC 00 21         [24] 2226 	cjne	r4,#0x00,00245$
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006788 B9 07 00         [24] 2228 	cjne	r1,#0x07,01339$
      00678B                       2229 01339$:
      00678B 50 1C            [24] 2230 	jnc	00245$
      00678D E9               [12] 2231 	mov	a,r1
      00678E 90 BF 24         [24] 2232 	mov	dptr,#_shared_lengths
      006791 93               [24] 2233 	movc	a,@a+dptr
      006792 F8               [12] 2234 	mov	r0,a
      006793 60 14            [24] 2235 	jz	00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      006795 90 08 34         [24] 2237 	mov	dptr,#_control_setup_length_10000_287
      006798 E8               [12] 2238 	mov	a,r0
      006799 F0               [24] 2239 	movx	@dptr,a
      00679A E4               [12] 2240 	clr	a
      00679B A3               [24] 2241 	inc	dptr
      00679C F0               [24] 2242 	movx	@dptr,a
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      00679D E9               [12] 2244 	mov	a,r1
      00679E 90 BF 1D         [24] 2245 	mov	dptr,#_shared_offsets
      0067A1 93               [24] 2246 	movc	a,@a+dptr
      0067A2 90 08 36         [24] 2247 	mov	dptr,#_control_setup_offset_10000_287
      0067A5 F0               [24] 2248 	movx	@dptr,a
      0067A6 02 69 02         [24] 2249 	ljmp	00252$
      0067A9                       2250 00245$:
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0067A9 E5 17            [12] 2252 	mov	a,_control_setup_sloc3_1_0
      0067AB 60 7A            [24] 2253 	jz	00240$
      0067AD BB 01 77         [24] 2254 	cjne	r3,#0x01,00240$
      0067B0 BC 00 74         [24] 2255 	cjne	r4,#0x00,00240$
      0067B3 E9               [12] 2256 	mov	a,r1
      0067B4 70 71            [24] 2257 	jnz	00240$
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0067B6 90 07 CC         [24] 2259 	mov	dptr,#_D0SetupLen
      0067B9 E0               [24] 2260 	movx	a,@dptr
      0067BA F8               [12] 2261 	mov	r0,a
      0067BB A3               [24] 2262 	inc	dptr
      0067BC E0               [24] 2263 	movx	a,@dptr
      0067BD F9               [12] 2264 	mov	r1,a
      0067BE C3               [12] 2265 	clr	c
      0067BF E8               [12] 2266 	mov	a,r0
      0067C0 94 20            [12] 2267 	subb	a,#0x20
      0067C2 E9               [12] 2268 	mov	a,r1
      0067C3 94 00            [12] 2269 	subb	a,#0x00
      0067C5 50 0A            [24] 2270 	jnc	00320$
      0067C7 90 07 CC         [24] 2271 	mov	dptr,#_D0SetupLen
      0067CA E0               [24] 2272 	movx	a,@dptr
      0067CB F8               [12] 2273 	mov	r0,a
      0067CC A3               [24] 2274 	inc	dptr
      0067CD E0               [24] 2275 	movx	a,@dptr
      0067CE F9               [12] 2276 	mov	r1,a
      0067CF 80 04            [24] 2277 	sjmp	00321$
      0067D1                       2278 00320$:
      0067D1 78 20            [12] 2279 	mov	r0,#0x20
      0067D3 79 00            [12] 2280 	mov	r1,#0x00
      0067D5                       2281 00321$:
                                   2282 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0067D5 75 17 00         [24] 2283 	mov	_control_setup_sloc3_1_0,#0x00
      0067D8                       2284 00293$:
      0067D8 C0 03            [24] 2285 	push	ar3
      0067DA C0 04            [24] 2286 	push	ar4
      0067DC AB 17            [24] 2287 	mov	r3,_control_setup_sloc3_1_0
      0067DE 7C 00            [12] 2288 	mov	r4,#0x00
      0067E0 C3               [12] 2289 	clr	c
      0067E1 EB               [12] 2290 	mov	a,r3
      0067E2 98               [12] 2291 	subb	a,r0
      0067E3 EC               [12] 2292 	mov	a,r4
      0067E4 99               [12] 2293 	subb	a,r1
      0067E5 D0 04            [24] 2294 	pop	ar4
      0067E7 D0 03            [24] 2295 	pop	ar3
      0067E9 50 32            [24] 2296 	jnc	00222$
      0067EB C0 00            [24] 2297 	push	ar0
      0067ED C0 01            [24] 2298 	push	ar1
      0067EF 85 17 19         [24] 2299 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0067F2 74 10            [12] 2300 	mov	a,#0x10
      0067F4 24 00            [12] 2301 	add	a, #0x00
      0067F6 F5 1A            [12] 2302 	mov	(_control_setup_sloc4_1_0 + 1),a
      0067F8 A8 17            [24] 2303 	mov	r0,_control_setup_sloc3_1_0
      0067FA 79 00            [12] 2304 	mov	r1,#0x00
      0067FC 74 C0            [12] 2305 	mov	a,#0xc0
      0067FE 28               [12] 2306 	add	a, r0
      0067FF F8               [12] 2307 	mov	r0,a
      006800 E4               [12] 2308 	clr	a
      006801 39               [12] 2309 	addc	a, r1
      006802 F9               [12] 2310 	mov	r1,a
      006803 88 82            [24] 2311 	mov	dpl,r0
      006805 74 10            [12] 2312 	mov	a,#0x10
      006807 29               [12] 2313 	add	a, r1
      006808 F5 83            [12] 2314 	mov	dph,a
      00680A E0               [24] 2315 	movx	a,@dptr
      00680B 85 19 82         [24] 2316 	mov	dpl,_control_setup_sloc4_1_0
      00680E 85 1A 83         [24] 2317 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006811 F0               [24] 2318 	movx	@dptr,a
      006812 E5 17            [12] 2319 	mov	a,_control_setup_sloc3_1_0
      006814 04               [12] 2320 	inc	a
      006815 F5 17            [12] 2321 	mov	_control_setup_sloc3_1_0,a
      006817 D0 01            [24] 2322 	pop	ar1
      006819 D0 00            [24] 2323 	pop	ar0
      00681B 80 BB            [24] 2324 	sjmp	00293$
      00681D                       2325 00222$:
                                   2326 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      00681D 90 08 34         [24] 2327 	mov	dptr,#_control_setup_length_10000_287
      006820 E4               [12] 2328 	clr	a
      006821 F0               [24] 2329 	movx	@dptr,a
      006822 A3               [24] 2330 	inc	dptr
      006823 F0               [24] 2331 	movx	@dptr,a
      006824 02 69 02         [24] 2332 	ljmp	00252$
      006827                       2333 00240$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006827 8D 00            [24] 2335 	mov	ar0,r5
      006829 8E 01            [24] 2336 	mov	ar1,r6
      00682B B8 00 21         [24] 2337 	cjne	r0,#0x00,00236$
      00682E B9 02 1E         [24] 2338 	cjne	r1,#0x02,00236$
      006831 EB               [12] 2339 	mov	a,r3
      006832 4C               [12] 2340 	orl	a,r4
      006833 70 1A            [24] 2341 	jnz	00236$
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006835 90 07 D6         [24] 2343 	mov	dptr,#_KB_USB_SetReport
      006838 E0               [24] 2344 	movx	a,@dptr
      006839 90 10 00         [24] 2345 	mov	dptr,#0x1000
      00683C F0               [24] 2346 	movx	@dptr,a
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00683D 90 08 34         [24] 2348 	mov	dptr,#_control_setup_length_10000_287
      006840 E4               [12] 2349 	clr	a
      006841 F0               [24] 2350 	movx	@dptr,a
      006842 A3               [24] 2351 	inc	dptr
      006843 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006844 90 07 CC         [24] 2354 	mov	dptr,#_D0SetupLen
      006847 04               [12] 2355 	inc	a
      006848 F0               [24] 2356 	movx	@dptr,a
      006849 E4               [12] 2357 	clr	a
      00684A A3               [24] 2358 	inc	dptr
      00684B F0               [24] 2359 	movx	@dptr,a
      00684C 02 69 02         [24] 2360 	ljmp	00252$
      00684F                       2361 00236$:
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      00684F B8 06 41         [24] 2363 	cjne	r0,#0x06,00232$
      006852 B9 02 3E         [24] 2364 	cjne	r1,#0x02,00232$
      006855 BB 02 3B         [24] 2365 	cjne	r3,#0x02,00232$
      006858 BC 00 38         [24] 2366 	cjne	r4,#0x00,00232$
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00685B C0 03            [24] 2368 	push	ar3
      00685D C0 04            [24] 2369 	push	ar4
      00685F 90 10 00         [24] 2370 	mov	dptr,#0x1000
      006862 74 06            [12] 2371 	mov	a,#0x06
      006864 F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006865 90 07 D6         [24] 2374 	mov	dptr,#_KB_USB_SetReport
      006868 E0               [24] 2375 	movx	a,@dptr
      006869 90 10 01         [24] 2376 	mov	dptr,#0x1001
      00686C F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      00686D 90 08 34         [24] 2379 	mov	dptr,#_control_setup_length_10000_287
      006870 E4               [12] 2380 	clr	a
      006871 F0               [24] 2381 	movx	@dptr,a
      006872 A3               [24] 2382 	inc	dptr
      006873 F0               [24] 2383 	movx	@dptr,a
                                   2384 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006874 90 07 CC         [24] 2385 	mov	dptr,#_D0SetupLen
      006877 E0               [24] 2386 	movx	a,@dptr
      006878 FB               [12] 2387 	mov	r3,a
      006879 A3               [24] 2388 	inc	dptr
      00687A E0               [24] 2389 	movx	a,@dptr
      00687B FC               [12] 2390 	mov	r4,a
      00687C C3               [12] 2391 	clr	c
      00687D 74 02            [12] 2392 	mov	a,#0x02
      00687F 9B               [12] 2393 	subb	a,r3
      006880 E4               [12] 2394 	clr	a
      006881 9C               [12] 2395 	subb	a,r4
      006882 D0 04            [24] 2396 	pop	ar4
      006884 D0 03            [24] 2397 	pop	ar3
      006886 50 7A            [24] 2398 	jnc	00252$
                                   2399 ;	free result
      006888 90 07 CC         [24] 2400 	mov	dptr,#_D0SetupLen
      00688B 74 02            [12] 2401 	mov	a,#0x02
      00688D F0               [24] 2402 	movx	@dptr,a
      00688E E4               [12] 2403 	clr	a
      00688F A3               [24] 2404 	inc	dptr
      006890 F0               [24] 2405 	movx	@dptr,a
      006891 80 6F            [24] 2406 	sjmp	00252$
      006893                       2407 00232$:
                                   2408 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006893 B8 00 69         [24] 2409 	cjne	r0,#0x00,00228$
      006896 B9 03 66         [24] 2410 	cjne	r1,#0x03,00228$
      006899 BB 01 63         [24] 2411 	cjne	r3,#0x01,00228$
      00689C BC 00 60         [24] 2412 	cjne	r4,#0x00,00228$
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      00689F 90 10 00         [24] 2414 	mov	dptr,#0x1000
      0068A2 74 41            [12] 2415 	mov	a,#0x41
      0068A4 F0               [24] 2416 	movx	@dptr,a
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      0068A5 A3               [24] 2418 	inc	dptr
      0068A6 74 4B            [12] 2419 	mov	a,#0x4b
      0068A8 F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      0068A9 A3               [24] 2422 	inc	dptr
      0068AA 74 42            [12] 2423 	mov	a,#0x42
      0068AC F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      0068AD A3               [24] 2426 	inc	dptr
      0068AE 74 54            [12] 2427 	mov	a,#0x54
      0068B0 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      0068B1 A3               [24] 2430 	inc	dptr
      0068B2 74 01            [12] 2431 	mov	a,#0x01
      0068B4 F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      0068B5 90 07 D7         [24] 2434 	mov	dptr,#_ak820_boot_stage
      0068B8 E0               [24] 2435 	movx	a,@dptr
      0068B9 90 10 05         [24] 2436 	mov	dptr,#0x1005
      0068BC F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0068BD 90 07 D8         [24] 2439 	mov	dptr,#_ak820_main_heartbeat
      0068C0 E0               [24] 2440 	movx	a,@dptr
      0068C1 90 10 06         [24] 2441 	mov	dptr,#0x1006
      0068C4 F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0068C5 90 07 D2         [24] 2444 	mov	dptr,#_USB_EnumStatus
      0068C8 E0               [24] 2445 	movx	a,@dptr
      0068C9 60 02            [24] 2446 	jz	00322$
      0068CB 74 01            [12] 2447 	mov	a,#0x01
      0068CD                       2448 00322$:
      0068CD F9               [12] 2449 	mov	r1,a
      0068CE 90 07 D3         [24] 2450 	mov	dptr,#_USB_SleepStatus
      0068D1 E0               [24] 2451 	movx	a,@dptr
      0068D2 54 02            [12] 2452 	anl	a,#0x02
      0068D4 F8               [12] 2453 	mov	r0,a
      0068D5 E9               [12] 2454 	mov	a,r1
      0068D6 42 00            [12] 2455 	orl	ar0,a
      0068D8 90 10 07         [24] 2456 	mov	dptr,#0x1007
      0068DB E8               [12] 2457 	mov	a,r0
      0068DC F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      0068DD 90 08 34         [24] 2460 	mov	dptr,#_control_setup_length_10000_287
      0068E0 E4               [12] 2461 	clr	a
      0068E1 F0               [24] 2462 	movx	@dptr,a
      0068E2 A3               [24] 2463 	inc	dptr
      0068E3 F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      0068E4 90 07 CC         [24] 2466 	mov	dptr,#_D0SetupLen
      0068E7 E0               [24] 2467 	movx	a,@dptr
      0068E8 F8               [12] 2468 	mov	r0,a
      0068E9 A3               [24] 2469 	inc	dptr
      0068EA E0               [24] 2470 	movx	a,@dptr
      0068EB F9               [12] 2471 	mov	r1,a
      0068EC C3               [12] 2472 	clr	c
      0068ED 74 08            [12] 2473 	mov	a,#0x08
      0068EF 98               [12] 2474 	subb	a,r0
      0068F0 E4               [12] 2475 	clr	a
      0068F1 99               [12] 2476 	subb	a,r1
      0068F2 50 0E            [24] 2477 	jnc	00252$
                                   2478 ;	free result
      0068F4 90 07 CC         [24] 2479 	mov	dptr,#_D0SetupLen
      0068F7 74 08            [12] 2480 	mov	a,#0x08
      0068F9 F0               [24] 2481 	movx	@dptr,a
      0068FA E4               [12] 2482 	clr	a
      0068FB A3               [24] 2483 	inc	dptr
      0068FC F0               [24] 2484 	movx	@dptr,a
      0068FD 80 03            [24] 2485 	sjmp	00252$
      0068FF                       2486 00228$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      0068FF 02 60 68         [24] 2488 	ljmp	_control_stall
      006902                       2489 00252$:
                                   2490 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006902 90 08 34         [24] 2491 	mov	dptr,#_control_setup_length_10000_287
      006905 E0               [24] 2492 	movx	a,@dptr
      006906 F5 19            [12] 2493 	mov	_control_setup_sloc4_1_0,a
      006908 A3               [24] 2494 	inc	dptr
      006909 E0               [24] 2495 	movx	a,@dptr
      00690A F5 1A            [12] 2496 	mov	(_control_setup_sloc4_1_0 + 1),a
      00690C E5 19            [12] 2497 	mov	a,_control_setup_sloc4_1_0
      00690E 45 1A            [12] 2498 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006910 60 50            [24] 2499 	jz	00262$
                                   2500 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006912 90 07 CC         [24] 2501 	mov	dptr,#_D0SetupLen
      006915 E0               [24] 2502 	movx	a,@dptr
      006916 F8               [12] 2503 	mov	r0,a
      006917 A3               [24] 2504 	inc	dptr
      006918 E0               [24] 2505 	movx	a,@dptr
      006919 F9               [12] 2506 	mov	r1,a
      00691A C3               [12] 2507 	clr	c
      00691B E5 19            [12] 2508 	mov	a,_control_setup_sloc4_1_0
      00691D 98               [12] 2509 	subb	a,r0
      00691E E5 1A            [12] 2510 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006920 99               [12] 2511 	subb	a,r1
      006921 50 0A            [24] 2512 	jnc	00559$
                                   2513 ;	free result
      006923 90 07 CC         [24] 2514 	mov	dptr,#_D0SetupLen
      006926 E5 19            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      006928 F0               [24] 2516 	movx	@dptr,a
      006929 E5 1A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00692B A3               [24] 2518 	inc	dptr
      00692C F0               [24] 2519 	movx	@dptr,a
                                   2520 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00692D                       2521 00559$:
      00692D 75 19 00         [24] 2522 	mov	_control_setup_sloc4_1_0,#0x00
      006930                       2523 00296$:
      006930 90 07 CC         [24] 2524 	mov	dptr,#_D0SetupLen
      006933 E0               [24] 2525 	movx	a,@dptr
      006934 F8               [12] 2526 	mov	r0,a
      006935 C3               [12] 2527 	clr	c
      006936 E5 19            [12] 2528 	mov	a,_control_setup_sloc4_1_0
      006938 98               [12] 2529 	subb	a,r0
      006939 50 46            [24] 2530 	jnc	00263$
      00693B 85 19 17         [24] 2531 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00693E 74 10            [12] 2532 	mov	a,#0x10
      006940 24 00            [12] 2533 	add	a, #0x00
      006942 F5 18            [12] 2534 	mov	(_control_setup_sloc3_1_0 + 1),a
      006944 90 08 36         [24] 2535 	mov	dptr,#_control_setup_offset_10000_287
      006947 E0               [24] 2536 	movx	a,@dptr
      006948 25 19            [12] 2537 	add	a, _control_setup_sloc4_1_0
      00694A 24 FC            [12] 2538 	add	a, #_input_snapshot
      00694C F5 82            [12] 2539 	mov	dpl,a
      00694E E4               [12] 2540 	clr	a
      00694F 34 07            [12] 2541 	addc	a,#(_input_snapshot >> 8)
      006951 F5 83            [12] 2542 	mov	dph,a
      006953 E0               [24] 2543 	movx	a,@dptr
      006954 85 17 82         [24] 2544 	mov	dpl,_control_setup_sloc3_1_0
      006957 85 18 83         [24] 2545 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00695A F0               [24] 2546 	movx	@dptr,a
      00695B E5 19            [12] 2547 	mov	a,_control_setup_sloc4_1_0
      00695D 04               [12] 2548 	inc	a
      00695E F5 19            [12] 2549 	mov	_control_setup_sloc4_1_0,a
      006960 80 CE            [24] 2550 	sjmp	00296$
      006962                       2551 00262$:
                                   2552 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006962 BB 01 1C         [24] 2553 	cjne	r3,#0x01,00263$
      006965 BC 00 19         [24] 2554 	cjne	r4,#0x00,00263$
      006968 90 07 CC         [24] 2555 	mov	dptr,#_D0SetupLen
      00696B E0               [24] 2556 	movx	a,@dptr
      00696C F8               [12] 2557 	mov	r0,a
      00696D A3               [24] 2558 	inc	dptr
      00696E E0               [24] 2559 	movx	a,@dptr
      00696F F9               [12] 2560 	mov	r1,a
      006970 C3               [12] 2561 	clr	c
      006971 74 20            [12] 2562 	mov	a,#0x20
      006973 98               [12] 2563 	subb	a,r0
      006974 E4               [12] 2564 	clr	a
      006975 99               [12] 2565 	subb	a,r1
      006976 50 09            [24] 2566 	jnc	00263$
                                   2567 ;	free result
      006978 90 07 CC         [24] 2568 	mov	dptr,#_D0SetupLen
      00697B 74 20            [12] 2569 	mov	a,#0x20
      00697D F0               [24] 2570 	movx	@dptr,a
      00697E E4               [12] 2571 	clr	a
      00697F A3               [24] 2572 	inc	dptr
      006980 F0               [24] 2573 	movx	@dptr,a
      006981                       2574 00263$:
                                   2575 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006981 90 07 CC         [24] 2576 	mov	dptr,#_D0SetupLen
      006984 E0               [24] 2577 	movx	a,@dptr
      006985 90 22 08         [24] 2578 	mov	dptr,#0x2208
      006988 F0               [24] 2579 	movx	@dptr,a
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      006989 90 08 2A         [24] 2581 	mov	dptr,#_control_phase
      00698C 74 02            [12] 2582 	mov	a,#0x02
      00698E F0               [24] 2583 	movx	@dptr,a
      00698F 02 6A 17         [24] 2584 	ljmp	00291$
      006992                       2585 00273$:
                                   2586 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006992 EB               [12] 2587 	mov	a,r3
      006993 4C               [12] 2588 	orl	a,r4
      006994 70 37            [24] 2589 	jnz	00265$
      006996 90 07 D1         [24] 2590 	mov	dptr,#_D0UsbConfig
      006999 E0               [24] 2591 	movx	a,@dptr
      00699A 60 31            [24] 2592 	jz	00265$
      00699C EA               [12] 2593 	mov	a,r2
      00699D 60 2E            [24] 2594 	jz	00265$
      00699F 90 07 CB         [24] 2595 	mov	dptr,#_D0SetupReqCode
      0069A2 E0               [24] 2596 	movx	a,@dptr
      0069A3 FA               [12] 2597 	mov	r2,a
      0069A4 BA 03 26         [24] 2598 	cjne	r2,#0x03,00265$
      0069A7 30 1A 23         [24] 2599 	jnb	_control_setup_zero_value_10000_287,00265$
      0069AA 90 07 CC         [24] 2600 	mov	dptr,#_D0SetupLen
      0069AD E0               [24] 2601 	movx	a,@dptr
      0069AE F9               [12] 2602 	mov	r1,a
      0069AF A3               [24] 2603 	inc	dptr
      0069B0 E0               [24] 2604 	movx	a,@dptr
      0069B1 FA               [12] 2605 	mov	r2,a
      0069B2 B9 01 18         [24] 2606 	cjne	r1,#0x01,00265$
      0069B5 BA 00 15         [24] 2607 	cjne	r2,#0x00,00265$
                                   2608 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      0069B8 90 0E 1D         [24] 2609 	mov	dptr,#_keyboard_protocol
      0069BB E0               [24] 2610 	movx	a,@dptr
      0069BC 90 10 00         [24] 2611 	mov	dptr,#0x1000
      0069BF F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      0069C0 90 22 08         [24] 2614 	mov	dptr,#0x2208
      0069C3 74 01            [12] 2615 	mov	a,#0x01
      0069C5 F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      0069C6 90 08 2A         [24] 2618 	mov	dptr,#_control_phase
      0069C9 04               [12] 2619 	inc	a
      0069CA F0               [24] 2620 	movx	@dptr,a
      0069CB 80 4A            [24] 2621 	sjmp	00291$
      0069CD                       2622 00265$:
                                   2623 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      0069CD 02 60 68         [24] 2625 	ljmp	_control_stall
      0069D0                       2626 00282$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0069D0 30 18 3E         [24] 2628 	jnb	_control_setup_valid_interface_10000_287,00284$
      0069D3 90 07 D1         [24] 2629 	mov	dptr,#_D0UsbConfig
      0069D6 E0               [24] 2630 	movx	a,@dptr
      0069D7 60 38            [24] 2631 	jz	00284$
      0069D9 BF A1 35         [24] 2632 	cjne	r7,#0xa1,00284$
      0069DC 8E 05            [24] 2633 	mov	ar5,r6
      0069DE 7E 00            [12] 2634 	mov	r6,#0x00
      0069E0 ED               [12] 2635 	mov	a,r5
      0069E1 4E               [12] 2636 	orl	a,r6
      0069E2 70 2D            [24] 2637 	jnz	00284$
      0069E4 90 07 CC         [24] 2638 	mov	dptr,#_D0SetupLen
      0069E7 E0               [24] 2639 	movx	a,@dptr
      0069E8 FE               [12] 2640 	mov	r6,a
      0069E9 A3               [24] 2641 	inc	dptr
      0069EA E0               [24] 2642 	movx	a,@dptr
      0069EB FF               [12] 2643 	mov	r7,a
      0069EC BE 01 22         [24] 2644 	cjne	r6,#0x01,00284$
      0069EF BF 00 1F         [24] 2645 	cjne	r7,#0x00,00284$
                                   2646 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0069F2 EB               [12] 2647 	mov	a,r3
      0069F3 4C               [12] 2648 	orl	a,r4
      0069F4 70 07            [24] 2649 	jnz	00324$
      0069F6 90 06 A9         [24] 2650 	mov	dptr,#_keyboard_idle
      0069F9 E0               [24] 2651 	movx	a,@dptr
      0069FA FF               [12] 2652 	mov	r7,a
      0069FB 80 02            [24] 2653 	sjmp	00325$
      0069FD                       2654 00324$:
      0069FD 7F 00            [12] 2655 	mov	r7,#0x00
      0069FF                       2656 00325$:
      0069FF 90 10 00         [24] 2657 	mov	dptr,#0x1000
      006A02 EF               [12] 2658 	mov	a,r7
      006A03 F0               [24] 2659 	movx	@dptr,a
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006A04 90 22 08         [24] 2661 	mov	dptr,#0x2208
      006A07 74 01            [12] 2662 	mov	a,#0x01
      006A09 F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      006A0A 90 08 2A         [24] 2665 	mov	dptr,#_control_phase
      006A0D 04               [12] 2666 	inc	a
      006A0E F0               [24] 2667 	movx	@dptr,a
      006A0F 80 06            [24] 2668 	sjmp	00291$
      006A11                       2669 00284$:
                                   2670 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006A11 02 60 68         [24] 2672 	ljmp	_control_stall
      006A14                       2673 00290$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006A14 02 60 68         [24] 2675 	ljmp	_control_stall
      006A17                       2676 00291$:
                                   2677 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006A17 90 22 00         [24] 2678 	mov	dptr,#0x2200
      006A1A 74 C0            [12] 2679 	mov	a,#0xc0
      006A1C F0               [24] 2680 	movx	@dptr,a
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      006A1D 22               [24] 2682 	ret
                                   2683 ;------------------------------------------------------------
                                   2684 ;Allocation info for local variables in function 'control_out'
                                   2685 ;------------------------------------------------------------
                                   2686 ;i             Allocated with name '_control_out_i_10000_371'
                                   2687 ;------------------------------------------------------------
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2689 ;	-----------------------------------------
                                   2690 ;	 function control_out
                                   2691 ;	-----------------------------------------
      006A1E                       2692 _control_out:
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006A1E 90 22 0F         [24] 2694 	mov	dptr,#0x220f
      006A21 E0               [24] 2695 	movx	a,@dptr
      006A22 20 E6 01         [24] 2696 	jb	acc.6,00102$
      006A25 22               [24] 2697 	ret
      006A26                       2698 00102$:
                                   2699 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006A26 90 08 2A         [24] 2700 	mov	dptr,#_control_phase
      006A29 E0               [24] 2701 	movx	a,@dptr
      006A2A FF               [12] 2702 	mov	r7,a
      006A2B BF 02 12         [24] 2703 	cjne	r7,#0x02,00104$
      006A2E 90 22 0E         [24] 2704 	mov	dptr,#0x220e
      006A31 E0               [24] 2705 	movx	a,@dptr
      006A32 70 0C            [24] 2706 	jnz	00104$
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006A34 90 08 2A         [24] 2708 	mov	dptr,#_control_phase
      006A37 E4               [12] 2709 	clr	a
      006A38 F0               [24] 2710 	movx	@dptr,a
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A39 90 22 00         [24] 2712 	mov	dptr,#0x2200
      006A3C 74 02            [12] 2713 	mov	a,#0x02
      006A3E F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006A3F 22               [24] 2716 	ret
      006A40                       2717 00104$:
                                   2718 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006A40 BF 04 19         [24] 2719 	cjne	r7,#0x04,00106$
      006A43 90 22 0E         [24] 2720 	mov	dptr,#0x220e
      006A46 E0               [24] 2721 	movx	a,@dptr
      006A47 FF               [12] 2722 	mov	r7,a
      006A48 90 07 CC         [24] 2723 	mov	dptr,#_D0SetupLen
      006A4B E0               [24] 2724 	movx	a,@dptr
      006A4C FD               [12] 2725 	mov	r5,a
      006A4D A3               [24] 2726 	inc	dptr
      006A4E E0               [24] 2727 	movx	a,@dptr
      006A4F FE               [12] 2728 	mov	r6,a
      006A50 7C 00            [12] 2729 	mov	r4,#0x00
      006A52 EF               [12] 2730 	mov	a,r7
      006A53 B5 05 06         [24] 2731 	cjne	a,ar5,00209$
      006A56 EC               [12] 2732 	mov	a,r4
      006A57 B5 06 02         [24] 2733 	cjne	a,ar6,00209$
      006A5A 80 03            [24] 2734 	sjmp	00107$
      006A5C                       2735 00209$:
      006A5C                       2736 00106$:
      006A5C 02 60 68         [24] 2737 	ljmp	_control_stall
      006A5F                       2738 00107$:
                                   2739 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006A5F 90 08 2B         [24] 2740 	mov	dptr,#_output_kind
      006A62 E0               [24] 2741 	movx	a,@dptr
      006A63 FF               [12] 2742 	mov	r7,a
      006A64 BF 01 2E         [24] 2743 	cjne	r7,#0x01,00118$
      006A67 90 07 D9         [24] 2744 	mov	dptr,#_raw_state
      006A6A E0               [24] 2745 	movx	a,@dptr
      006A6B FE               [12] 2746 	mov	r6,a
      006A6C BE 01 26         [24] 2747 	cjne	r6,#0x01,00118$
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006A6F 7E 00            [12] 2749 	mov	r6,#0x00
      006A71                       2750 00121$:
      006A71 EE               [12] 2751 	mov	a,r6
      006A72 24 DA            [12] 2752 	add	a, #_raw_buffer
      006A74 FC               [12] 2753 	mov	r4,a
      006A75 E4               [12] 2754 	clr	a
      006A76 34 07            [12] 2755 	addc	a, #(_raw_buffer >> 8)
      006A78 FD               [12] 2756 	mov	r5,a
      006A79 8E 82            [24] 2757 	mov	dpl,r6
      006A7B 74 10            [12] 2758 	mov	a,#0x10
      006A7D 24 00            [12] 2759 	add	a, #0x00
      006A7F F5 83            [12] 2760 	mov	dph,a
      006A81 E0               [24] 2761 	movx	a,@dptr
      006A82 8C 82            [24] 2762 	mov	dpl,r4
      006A84 8D 83            [24] 2763 	mov	dph,r5
      006A86 F0               [24] 2764 	movx	@dptr,a
      006A87 0E               [12] 2765 	inc	r6
      006A88 BE 20 00         [24] 2766 	cjne	r6,#0x20,00214$
      006A8B                       2767 00214$:
      006A8B 40 E4            [24] 2768 	jc	00121$
                                   2769 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006A8D 90 07 D9         [24] 2770 	mov	dptr,#_raw_state
      006A90 74 02            [12] 2771 	mov	a,#0x02
      006A92 F0               [24] 2772 	movx	@dptr,a
      006A93 80 2B            [24] 2773 	sjmp	00119$
      006A95                       2774 00118$:
                                   2775 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      006A95 BF 02 0A         [24] 2776 	cjne	r7,#0x02,00115$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      006A98 90 10 00         [24] 2778 	mov	dptr,#0x1000
      006A9B E0               [24] 2779 	movx	a,@dptr
      006A9C 90 07 D6         [24] 2780 	mov	dptr,#_KB_USB_SetReport
      006A9F F0               [24] 2781 	movx	@dptr,a
      006AA0 80 1E            [24] 2782 	sjmp	00119$
      006AA2                       2783 00115$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006AA2 BF 03 18         [24] 2785 	cjne	r7,#0x03,00111$
      006AA5 90 10 00         [24] 2786 	mov	dptr,#0x1000
      006AA8 E0               [24] 2787 	movx	a,@dptr
      006AA9 FF               [12] 2788 	mov	r7,a
      006AAA 90 08 2C         [24] 2789 	mov	dptr,#_output_report_id
      006AAD E0               [24] 2790 	movx	a,@dptr
      006AAE FE               [12] 2791 	mov	r6,a
      006AAF EF               [12] 2792 	mov	a,r7
      006AB0 B5 06 0A         [24] 2793 	cjne	a,ar6,00111$
                                   2794 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006AB3 90 10 01         [24] 2795 	mov	dptr,#0x1001
      006AB6 E0               [24] 2796 	movx	a,@dptr
      006AB7 90 07 D6         [24] 2797 	mov	dptr,#_KB_USB_SetReport
      006ABA F0               [24] 2798 	movx	@dptr,a
      006ABB 80 03            [24] 2799 	sjmp	00119$
      006ABD                       2800 00111$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006ABD 02 60 68         [24] 2802 	ljmp	_control_stall
      006AC0                       2803 00119$:
                                   2804 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006AC0 90 08 2B         [24] 2805 	mov	dptr,#_output_kind
      006AC3 E4               [12] 2806 	clr	a
      006AC4 F0               [24] 2807 	movx	@dptr,a
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006AC5 90 07 CC         [24] 2809 	mov	dptr,#_D0SetupLen
      006AC8 F0               [24] 2810 	movx	@dptr,a
      006AC9 A3               [24] 2811 	inc	dptr
      006ACA F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      006ACB 90 08 2A         [24] 2814 	mov	dptr,#_control_phase
      006ACE 74 03            [12] 2815 	mov	a,#0x03
      006AD0 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006AD1 90 22 08         [24] 2818 	mov	dptr,#0x2208
      006AD4 E4               [12] 2819 	clr	a
      006AD5 F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006AD6 F5 82            [12] 2822 	mov	dpl,a
      006AD8 74 48            [12] 2823 	mov	a,#0x48
      006ADA F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      006ADB 22               [24] 2826 	ret
                                   2827 ;------------------------------------------------------------
                                   2828 ;Allocation info for local variables in function 'control_in'
                                   2829 ;------------------------------------------------------------
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2831 ;	-----------------------------------------
                                   2832 ;	 function control_in
                                   2833 ;	-----------------------------------------
      006ADC                       2834 _control_in:
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006ADC 90 08 2A         [24] 2836 	mov	dptr,#_control_phase
      006ADF E0               [24] 2837 	movx	a,@dptr
      006AE0 FF               [12] 2838 	mov	r7,a
      006AE1 BF 01 22         [24] 2839 	cjne	r7,#0x01,00109$
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006AE4 90 07 CC         [24] 2841 	mov	dptr,#_D0SetupLen
      006AE7 E0               [24] 2842 	movx	a,@dptr
      006AE8 FD               [12] 2843 	mov	r5,a
      006AE9 A3               [24] 2844 	inc	dptr
      006AEA E0               [24] 2845 	movx	a,@dptr
      006AEB 4D               [12] 2846 	orl	a,r5
      006AEC 70 06            [24] 2847 	jnz	00101$
      006AEE 90 08 2D         [24] 2848 	mov	dptr,#_control_zlp
      006AF1 E0               [24] 2849 	movx	a,@dptr
      006AF2 60 0A            [24] 2850 	jz	00102$
      006AF4                       2851 00101$:
                                   2852 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006AF4 90 22 00         [24] 2853 	mov	dptr,#0x2200
      006AF7 E0               [24] 2854 	movx	a,@dptr
      006AF8 64 40            [12] 2855 	xrl	a,#0x40
      006AFA F0               [24] 2856 	movx	@dptr,a
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      006AFB 02 60 8A         [24] 2859 	ljmp	_control_next
      006AFE                       2860 00102$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006AFE 90 08 2A         [24] 2862 	mov	dptr,#_control_phase
      006B01 74 02            [12] 2863 	mov	a,#0x02
      006B03 F0               [24] 2864 	movx	@dptr,a
      006B04 80 18            [24] 2865 	sjmp	00110$
      006B06                       2866 00109$:
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006B06 BF 03 15         [24] 2868 	cjne	r7,#0x03,00110$
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006B09 90 07 CB         [24] 2870 	mov	dptr,#_D0SetupReqCode
      006B0C E0               [24] 2871 	movx	a,@dptr
      006B0D FF               [12] 2872 	mov	r7,a
      006B0E BF 05 08         [24] 2873 	cjne	r7,#0x05,00105$
      006B11 90 07 CC         [24] 2874 	mov	dptr,#_D0SetupLen
      006B14 E0               [24] 2875 	movx	a,@dptr
      006B15 90 22 07         [24] 2876 	mov	dptr,#0x2207
      006B18 F0               [24] 2877 	movx	@dptr,a
      006B19                       2878 00105$:
                                   2879 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      006B19 90 08 2A         [24] 2880 	mov	dptr,#_control_phase
      006B1C E4               [12] 2881 	clr	a
      006B1D F0               [24] 2882 	movx	@dptr,a
      006B1E                       2883 00110$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B1E 90 22 00         [24] 2885 	mov	dptr,#0x2200
      006B21 74 82            [12] 2886 	mov	a,#0x82
      006B23 F0               [24] 2887 	movx	@dptr,a
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006B24 22               [24] 2889 	ret
                                   2890 ;------------------------------------------------------------
                                   2891 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2892 ;------------------------------------------------------------
                                   2893 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2894 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2895 ;------------------------------------------------------------
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function USB_DeviceInterrupt
                                   2899 ;	-----------------------------------------
      006B25                       2900 _USB_DeviceInterrupt:
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006B25                       2902 00129$:
                                   2903 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006B25 90 22 3D         [24] 2904 	mov	dptr,#0x223d
      006B28 E0               [24] 2905 	movx	a,@dptr
      006B29 30 E0 4B         [24] 2906 	jnb	acc.0,00127$
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      006B2C 12 60 11         [24] 2908 	lcall	_endpoints_reset
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006B2F 90 22 07         [24] 2910 	mov	dptr,#0x2207
      006B32 E4               [12] 2911 	clr	a
      006B33 F0               [24] 2912 	movx	@dptr,a
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B34 90 07 D3         [24] 2914 	mov	dptr,#_USB_SleepStatus
      006B37 F0               [24] 2915 	movx	@dptr,a
      006B38 90 07 D2         [24] 2916 	mov	dptr,#_USB_EnumStatus
      006B3B F0               [24] 2917 	movx	@dptr,a
      006B3C 90 07 D1         [24] 2918 	mov	dptr,#_D0UsbConfig
      006B3F F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006B40 90 07 D6         [24] 2921 	mov	dptr,#_KB_USB_SetReport
      006B43 F0               [24] 2922 	movx	@dptr,a
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006B44 90 0E 1D         [24] 2924 	mov	dptr,#_keyboard_protocol
      006B47 04               [12] 2925 	inc	a
      006B48 F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      006B49 90 06 A9         [24] 2928 	mov	dptr,#_keyboard_idle
      006B4C E4               [12] 2929 	clr	a
      006B4D F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      006B4E 90 07 FB         [24] 2932 	mov	dptr,#_keyboard_reset
      006B51 04               [12] 2933 	inc	a
      006B52 F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006B53 90 07 CB         [24] 2936 	mov	dptr,#_D0SetupReqCode
      006B56 74 FF            [12] 2937 	mov	a,#0xff
      006B58 F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      006B59 90 07 CC         [24] 2940 	mov	dptr,#_D0SetupLen
      006B5C E4               [12] 2941 	clr	a
      006B5D F0               [24] 2942 	movx	@dptr,a
      006B5E A3               [24] 2943 	inc	dptr
      006B5F F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006B60 90 08 2A         [24] 2946 	mov	dptr,#_control_phase
      006B63 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B64 90 22 00         [24] 2949 	mov	dptr,#0x2200
      006B67 74 02            [12] 2950 	mov	a,#0x02
      006B69 F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      006B6A 90 22 0F         [24] 2953 	mov	dptr,#0x220f
      006B6D E4               [12] 2954 	clr	a
      006B6E F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006B6F 90 22 3D         [24] 2957 	mov	dptr,#0x223d
      006B72 04               [12] 2958 	inc	a
      006B73 F0               [24] 2959 	movx	@dptr,a
      006B74 02 6C 0A         [24] 2960 	ljmp	00130$
      006B77                       2961 00127$:
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006B77 90 22 3D         [24] 2963 	mov	dptr,#0x223d
      006B7A E0               [24] 2964 	movx	a,@dptr
      006B7B 30 E5 60         [24] 2965 	jnb	acc.5,00124$
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006B7E 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      006B81 E0               [24] 2968 	movx	a,@dptr
      006B82 FF               [12] 2969 	mov	r7,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006B83 74 07            [12] 2971 	mov	a,#0x07
      006B85 5F               [12] 2972 	anl	a,r7
      006B86 FE               [12] 2973 	mov	r6,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006B87 EF               [12] 2975 	mov	a,r7
      006B88 54 18            [12] 2976 	anl	a,#0x18
      006B8A 70 08            [24] 2977 	jnz	00115$
      006B8C EE               [12] 2978 	mov	a,r6
      006B8D 70 05            [24] 2979 	jnz	00115$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006B8F 12 6A 1E         [24] 2981 	lcall	_control_out
      006B92 80 43            [24] 2982 	sjmp	00116$
      006B94                       2983 00115$:
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006B94 8F 05            [24] 2985 	mov	ar5,r7
      006B96 74 18            [12] 2986 	mov	a,#0x18
      006B98 5D               [12] 2987 	anl	a,r5
      006B99 FC               [12] 2988 	mov	r4,a
      006B9A BC 10 2D         [24] 2989 	cjne	r4,#0x10,00112$
                                   2990 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006B9D EE               [12] 2991 	mov	a,r6
      006B9E 70 05            [24] 2992 	jnz	00106$
      006BA0 12 6A DC         [24] 2993 	lcall	_control_in
      006BA3 80 32            [24] 2994 	sjmp	00116$
      006BA5                       2995 00106$:
                                   2996 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006BA5 EE               [12] 2997 	mov	a,r6
      006BA6 24 FC            [12] 2998 	add	a,#0xff - 0x03
      006BA8 40 2D            [24] 2999 	jc	00116$
                                   3000 ;	free result
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006BAA 8E 04            [24] 3002 	mov	ar4,r6
      006BAC 7B 00            [12] 3003 	mov	r3,#0x00
      006BAE 74 22            [12] 3004 	mov	a,#0x22
      006BB0 2B               [12] 3005 	add	a, r3
      006BB1 FB               [12] 3006 	mov	r3,a
      006BB2 8C 82            [24] 3007 	mov	dpl,r4
      006BB4 8B 83            [24] 3008 	mov	dph,r3
      006BB6 E0               [24] 3009 	movx	a,@dptr
      006BB7 FA               [12] 3010 	mov	r2,a
      006BB8 74 FC            [12] 3011 	mov	a,#0xfc
      006BBA 5A               [12] 3012 	anl	a,r2
      006BBB 44 02            [12] 3013 	orl	a,#0x02
      006BBD 8C 82            [24] 3014 	mov	dpl,r4
      006BBF 8B 83            [24] 3015 	mov	dph,r3
      006BC1 F0               [24] 3016 	movx	@dptr,a
                                   3017 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006BC2 BE 03 12         [24] 3018 	cjne	r6,#0x03,00116$
      006BC5 12 5F F4         [24] 3019 	lcall	_raw_complete
      006BC8 80 0D            [24] 3020 	sjmp	00116$
      006BCA                       3021 00112$:
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006BCA 53 05 18         [24] 3023 	anl	ar5,#0x18
      006BCD BD 18 07         [24] 3024 	cjne	r5,#0x18,00116$
      006BD0 EF               [12] 3025 	mov	a,r7
      006BD1 30 E5 03         [24] 3026 	jnb	acc.5,00116$
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006BD4 12 62 81         [24] 3028 	lcall	_control_setup
      006BD7                       3029 00116$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      006BD7 90 22 0F         [24] 3031 	mov	dptr,#0x220f
      006BDA E4               [12] 3032 	clr	a
      006BDB F0               [24] 3033 	movx	@dptr,a
      006BDC 80 2C            [24] 3034 	sjmp	00130$
      006BDE                       3035 00124$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006BDE 90 22 3D         [24] 3037 	mov	dptr,#0x223d
      006BE1 E0               [24] 3038 	movx	a,@dptr
      006BE2 30 E2 25         [24] 3039 	jnb	acc.2,00130$
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006BE5 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      006BE8 E0               [24] 3042 	movx	a,@dptr
      006BE9 30 E3 0A         [24] 3043 	jnb	acc.3,00119$
      006BEC 90 07 D3         [24] 3044 	mov	dptr,#_USB_SleepStatus
      006BEF E0               [24] 3045 	movx	a,@dptr
      006BF0 43 E0 02         [24] 3046 	orl	acc,#0x02
      006BF3 F0               [24] 3047 	movx	@dptr,a
      006BF4 80 0E            [24] 3048 	sjmp	00120$
      006BF6                       3049 00119$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006BF6 90 07 D3         [24] 3051 	mov	dptr,#_USB_SleepStatus
      006BF9 E0               [24] 3052 	movx	a,@dptr
      006BFA 53 E0 FD         [24] 3053 	anl	acc,#0xfd
      006BFD F0               [24] 3054 	movx	@dptr,a
                                   3055 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006BFE 90 07 FB         [24] 3056 	mov	dptr,#_keyboard_reset
      006C01 74 01            [12] 3057 	mov	a,#0x01
      006C03 F0               [24] 3058 	movx	@dptr,a
      006C04                       3059 00120$:
                                   3060 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006C04 90 22 3D         [24] 3061 	mov	dptr,#0x223d
      006C07 74 04            [12] 3062 	mov	a,#0x04
      006C09 F0               [24] 3063 	movx	@dptr,a
      006C0A                       3064 00130$:
                                   3065 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006C0A 90 22 3D         [24] 3066 	mov	dptr,#0x223d
      006C0D E0               [24] 3067 	movx	a,@dptr
      006C0E 54 25            [12] 3068 	anl	a,#0x25
      006C10 60 03            [24] 3069 	jz	00242$
      006C12 02 6B 25         [24] 3070 	ljmp	00129$
      006C15                       3071 00242$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006C15 22               [24] 3073 	ret
                                   3074 ;------------------------------------------------------------
                                   3075 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3076 ;------------------------------------------------------------
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3078 ;	-----------------------------------------
                                   3079 ;	 function USB_Device_Init
                                   3080 ;	-----------------------------------------
      006C16                       3081 _USB_Device_Init:
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3083 ;	assignBit
      006C16 C2 E9            [12] 3084 	clr	_IE_USB
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006C18 90 22 3C         [24] 3086 	mov	dptr,#0x223c
      006C1B E4               [12] 3087 	clr	a
      006C1C F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      006C1D 90 07 D9         [24] 3090 	mov	dptr,#_raw_state
      006C20 F0               [24] 3091 	movx	@dptr,a
                                   3092 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006C21 12 60 11         [24] 3093 	lcall	_endpoints_reset
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006C24 90 07 D3         [24] 3095 	mov	dptr,#_USB_SleepStatus
      006C27 E4               [12] 3096 	clr	a
      006C28 F0               [24] 3097 	movx	@dptr,a
      006C29 90 07 D2         [24] 3098 	mov	dptr,#_USB_EnumStatus
      006C2C F0               [24] 3099 	movx	@dptr,a
      006C2D 90 07 D1         [24] 3100 	mov	dptr,#_D0UsbConfig
      006C30 F0               [24] 3101 	movx	@dptr,a
      006C31 90 22 07         [24] 3102 	mov	dptr,#0x2207
      006C34 F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006C35 90 07 D4         [24] 3105 	mov	dptr,#_MCU_Sleep_Operate
      006C38 F0               [24] 3106 	movx	@dptr,a
      006C39 90 07 D5         [24] 3107 	mov	dptr,#_KB_USB_UpStatus
      006C3C F0               [24] 3108 	movx	@dptr,a
      006C3D 90 07 D6         [24] 3109 	mov	dptr,#_KB_USB_SetReport
      006C40 F0               [24] 3110 	movx	@dptr,a
                                   3111 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006C41 90 0E 1D         [24] 3112 	mov	dptr,#_keyboard_protocol
      006C44 04               [12] 3113 	inc	a
      006C45 F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006C46 90 06 A9         [24] 3116 	mov	dptr,#_keyboard_idle
      006C49 E4               [12] 3117 	clr	a
      006C4A F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006C4B 90 07 FB         [24] 3120 	mov	dptr,#_keyboard_reset
      006C4E F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006C4F 90 08 2A         [24] 3123 	mov	dptr,#_control_phase
      006C52 F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006C53 90 07 CB         [24] 3126 	mov	dptr,#_D0SetupReqCode
      006C56 14               [12] 3127 	dec	a
      006C57 F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006C58 90 07 CC         [24] 3130 	mov	dptr,#_D0SetupLen
      006C5B E4               [12] 3131 	clr	a
      006C5C F0               [24] 3132 	movx	@dptr,a
      006C5D A3               [24] 3133 	inc	dptr
      006C5E F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006C5F 90 22 00         [24] 3136 	mov	dptr,#0x2200
      006C62 74 02            [12] 3137 	mov	a,#0x02
      006C64 F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006C65 90 22 37         [24] 3140 	mov	dptr,#0x2237
      006C68 74 7F            [12] 3141 	mov	a,#0x7f
      006C6A F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006C6B 90 22 3D         [24] 3144 	mov	dptr,#0x223d
      006C6E 74 FF            [12] 3145 	mov	a,#0xff
      006C70 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006C71 90 22 3B         [24] 3148 	mov	dptr,#0x223b
      006C74 74 07            [12] 3149 	mov	a,#0x07
      006C76 F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006C77 A3               [24] 3152 	inc	dptr
      006C78 74 80            [12] 3153 	mov	a,#0x80
      006C7A F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3156 ;	assignBit
      006C7B D2 E9            [12] 3157 	setb	_IE_USB
                                   3158 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006C7D 22               [24] 3159 	ret
                                   3160 ;------------------------------------------------------------
                                   3161 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3162 ;------------------------------------------------------------
                                   3163 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3164 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3165 ;------------------------------------------------------------
                                   3166 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3167 ;	-----------------------------------------
                                   3168 ;	 function USB_WakeUp_PC
                                   3169 ;	-----------------------------------------
      006C7E                       3170 _USB_WakeUp_PC:
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006C7E 90 07 D3         [24] 3172 	mov	dptr,#_USB_SleepStatus
      006C81 E0               [24] 3173 	movx	a,@dptr
      006C82 FF               [12] 3174 	mov	r7,a
      006C83 BF 03 22         [24] 3175 	cjne	r7,#0x03,00110$
                                   3176 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006C86 90 22 3C         [24] 3177 	mov	dptr,#0x223c
      006C89 E0               [24] 3178 	movx	a,@dptr
      006C8A FF               [12] 3179 	mov	r7,a
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006C8B E0               [24] 3181 	movx	a,@dptr
      006C8C FE               [12] 3182 	mov	r6,a
      006C8D 63 06 C0         [24] 3183 	xrl	ar6,#0xc0
      006C90 90 22 3C         [24] 3184 	mov	dptr,#0x223c
      006C93 EE               [12] 3185 	mov	a,r6
      006C94 F0               [24] 3186 	movx	@dptr,a
                                   3187 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006C95 7E 0A            [12] 3188 	mov	r6,#0x0a
      006C97                       3189 00108$:
      006C97 EE               [12] 3190 	mov	a,r6
      006C98 60 09            [24] 3191 	jz	00105$
      006C9A 90 00 01         [24] 3192 	mov	dptr,#0x0001
      006C9D 12 5E 38         [24] 3193 	lcall	_mDelaymS
      006CA0 1E               [12] 3194 	dec	r6
      006CA1 80 F4            [24] 3195 	sjmp	00108$
      006CA3                       3196 00105$:
                                   3197 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006CA3 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006CA6 EF               [12] 3199 	mov	a,r7
      006CA7 F0               [24] 3200 	movx	@dptr,a
      006CA8                       3201 00110$:
                                   3202 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006CA8 22               [24] 3203 	ret
                                   3204 ;------------------------------------------------------------
                                   3205 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3206 ;------------------------------------------------------------
                                   3207 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3208 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3209 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3210 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3211 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3212 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3213 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3214 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3215 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3216 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3218 ;------------------------------------------------------------
                                   3219 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3220 ;	-----------------------------------------
                                   3221 ;	 function ak820_usb_send
                                   3222 ;	-----------------------------------------
      006CA9                       3223 _ak820_usb_send:
      006CA9 E5 82            [12] 3224 	mov	a,dpl
      006CAB 90 08 3A         [24] 3225 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CAE F0               [24] 3226 	movx	@dptr,a
                                   3227 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006CAF 90 08 3B         [24] 3228 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006CB2 74 2E            [12] 3229 	mov	a,#0x2e
      006CB4 F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006CB5 90 08 3A         [24] 3232 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CB8 E0               [24] 3233 	movx	a,@dptr
      006CB9 FF               [12] 3234 	mov	r7,a
      006CBA BF 01 00         [24] 3235 	cjne	r7,#0x01,00306$
      006CBD                       3236 00306$:
      006CBD 40 14            [24] 3237 	jc	00101$
      006CBF EF               [12] 3238 	mov	a,r7
      006CC0 24 FC            [12] 3239 	add	a,#0xff - 0x03
      006CC2 40 0F            [24] 3240 	jc	00101$
                                   3241 ;	free result
      006CC4 90 08 39         [24] 3242 	mov	dptr,#_ak820_usb_send_PARM_3
      006CC7 E0               [24] 3243 	movx	a,@dptr
      006CC8 FE               [12] 3244 	mov  r6,a
      006CC9 24 BF            [12] 3245 	add	a,#0xff - 0x40
      006CCB 40 06            [24] 3246 	jc	00101$
                                   3247 ;	free result
      006CCD 90 07 D2         [24] 3248 	mov	dptr,#_USB_EnumStatus
      006CD0 E0               [24] 3249 	movx	a,@dptr
      006CD1 70 04            [24] 3250 	jnz	00102$
      006CD3                       3251 00101$:
      006CD3 75 82 00         [24] 3252 	mov	dpl, #0x00
      006CD6 22               [24] 3253 	ret
      006CD7                       3254 00102$:
                                   3255 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006CD7 BF 01 10         [24] 3256 	cjne	r7,#0x01,00118$
                                   3257 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006CDA BE 08 02         [24] 3258 	cjne	r6,#0x08,00313$
      006CDD 80 04            [24] 3259 	sjmp	00107$
      006CDF                       3260 00313$:
      006CDF 75 82 00         [24] 3261 	mov	dpl, #0x00
      006CE2 22               [24] 3262 	ret
      006CE3                       3263 00107$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006CE3 90 08 3B         [24] 3265 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006CE6 E4               [12] 3266 	clr	a
      006CE7 F0               [24] 3267 	movx	@dptr,a
      006CE8 80 3C            [24] 3268 	sjmp	00119$
      006CEA                       3269 00118$:
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006CEA BF 02 30         [24] 3271 	cjne	r7,#0x02,00115$
                                   3272 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006CED 90 08 37         [24] 3273 	mov	dptr,#_ak820_usb_send_PARM_2
      006CF0 E0               [24] 3274 	movx	a,@dptr
      006CF1 FD               [12] 3275 	mov	r5,a
      006CF2 A3               [24] 3276 	inc	dptr
      006CF3 E0               [24] 3277 	movx	a,@dptr
      006CF4 FF               [12] 3278 	mov	r7,a
      006CF5 8D 82            [24] 3279 	mov	dpl,r5
      006CF7 8F 83            [24] 3280 	mov	dph,r7
      006CF9 E0               [24] 3281 	movx	a,@dptr
      006CFA FF               [12] 3282 	mov	r7,a
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006CFB BF 07 00         [24] 3284 	cjne	r7,#0x07,00316$
      006CFE                       3285 00316$:
      006CFE 50 0E            [24] 3286 	jnc	00108$
      006D00 EF               [12] 3287 	mov	a,r7
      006D01 90 BF 24         [24] 3288 	mov	dptr,#_shared_lengths
      006D04 93               [24] 3289 	movc	a,@a+dptr
      006D05 FD               [12] 3290 	mov	r5,a
      006D06 60 06            [24] 3291 	jz	00108$
      006D08 EE               [12] 3292 	mov	a,r6
      006D09 B5 05 02         [24] 3293 	cjne	a,ar5,00319$
      006D0C 80 04            [24] 3294 	sjmp	00109$
      006D0E                       3295 00319$:
      006D0E                       3296 00108$:
      006D0E 75 82 00         [24] 3297 	mov	dpl, #0x00
      006D11 22               [24] 3298 	ret
      006D12                       3299 00109$:
                                   3300 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006D12 EF               [12] 3301 	mov	a,r7
      006D13 90 BF 1D         [24] 3302 	mov	dptr,#_shared_offsets
      006D16 93               [24] 3303 	movc	a,@a+dptr
      006D17 90 08 3B         [24] 3304 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006D1A F0               [24] 3305 	movx	@dptr,a
      006D1B 80 09            [24] 3306 	sjmp	00119$
      006D1D                       3307 00115$:
                                   3308 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006D1D BE 20 02         [24] 3309 	cjne	r6,#0x20,00320$
      006D20 80 04            [24] 3310 	sjmp	00119$
      006D22                       3311 00320$:
      006D22 75 82 00         [24] 3312 	mov	dpl, #0x00
      006D25 22               [24] 3313 	ret
      006D26                       3314 00119$:
                                   3315 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006D26 90 07 D3         [24] 3316 	mov	dptr,#_USB_SleepStatus
      006D29 E0               [24] 3317 	movx	a,@dptr
      006D2A 30 E1 07         [24] 3318 	jnb	acc.1,00184$
      006D2D 12 6C 7E         [24] 3319 	lcall	_USB_WakeUp_PC
      006D30 75 82 00         [24] 3320 	mov	dpl, #0x00
      006D33 22               [24] 3321 	ret
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006D34                       3323 00184$:
      006D34 7F FA            [12] 3324 	mov	r7,#0xfa
      006D36                       3325 00127$:
      006D36 90 08 3A         [24] 3326 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D39 E0               [24] 3327 	movx	a,@dptr
      006D3A FC               [12] 3328 	mov	r4,a
      006D3B 7D 00            [12] 3329 	mov	r5,#0x00
      006D3D 8C 02            [24] 3330 	mov	ar2,r4
      006D3F 74 22            [12] 3331 	mov	a,#0x22
      006D41 2D               [12] 3332 	add	a, r5
      006D42 FB               [12] 3333 	mov	r3,a
      006D43 8A 82            [24] 3334 	mov	dpl,r2
      006D45 8B 83            [24] 3335 	mov	dph,r3
      006D47 E0               [24] 3336 	movx	a,@dptr
      006D48 54 03            [12] 3337 	anl	a,#0x03
      006D4A 70 20            [24] 3338 	jnz	00129$
      006D4C 8F 03            [24] 3339 	mov	ar3,r7
      006D4E 1F               [12] 3340 	dec	r7
      006D4F EB               [12] 3341 	mov	a,r3
      006D50 60 1A            [24] 3342 	jz	00129$
      006D52 7B 28            [12] 3343 	mov	r3,#0x28
      006D54                       3344 00141$:
      006D54 EB               [12] 3345 	mov	a,r3
      006D55 60 DF            [24] 3346 	jz	00127$
      006D57 90 00 01         [24] 3347 	mov	dptr,#0x0001
      006D5A C0 07            [24] 3348 	push	ar7
      006D5C C0 06            [24] 3349 	push	ar6
      006D5E C0 03            [24] 3350 	push	ar3
      006D60 12 5D FC         [24] 3351 	lcall	_mDelayuS
      006D63 D0 03            [24] 3352 	pop	ar3
      006D65 D0 06            [24] 3353 	pop	ar6
      006D67 D0 07            [24] 3354 	pop	ar7
      006D69 1B               [12] 3355 	dec	r3
      006D6A 80 E8            [24] 3356 	sjmp	00141$
      006D6C                       3357 00129$:
                                   3358 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006D6C A2 AF            [12] 3359 	mov	c,_EA
      006D6E E4               [12] 3360 	clr	a
      006D6F 33               [12] 3361 	rlc	a
      006D70 FF               [12] 3362 	mov	r7,a
                                   3363 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3364 ;	assignBit
      006D71 C2 AF            [12] 3365 	clr	_EA
                                   3366 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006D73 90 07 D2         [24] 3367 	mov	dptr,#_USB_EnumStatus
      006D76 E0               [24] 3368 	movx	a,@dptr
      006D77 60 25            [24] 3369 	jz	00130$
      006D79 90 08 3A         [24] 3370 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D7C E0               [24] 3371 	movx	a,@dptr
      006D7D FB               [12] 3372 	mov	r3,a
      006D7E F9               [12] 3373 	mov	r1,a
      006D7F 7A 00            [12] 3374 	mov	r2,#0x00
      006D81 74 22            [12] 3375 	mov	a,#0x22
      006D83 2A               [12] 3376 	add	a, r2
      006D84 FA               [12] 3377 	mov	r2,a
      006D85 89 82            [24] 3378 	mov	dpl,r1
      006D87 8A 83            [24] 3379 	mov	dph,r2
      006D89 E0               [24] 3380 	movx	a,@dptr
      006D8A FA               [12] 3381 	mov	r2,a
      006D8B 53 02 03         [24] 3382 	anl	ar2,#0x03
      006D8E BA 02 0D         [24] 3383 	cjne	r2,#0x02,00130$
                                   3384 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006D91 BB 03 13         [24] 3385 	cjne	r3,#0x03,00192$
      006D94 90 07 D9         [24] 3386 	mov	dptr,#_raw_state
      006D97 E0               [24] 3387 	movx	a,@dptr
      006D98 FB               [12] 3388 	mov	r3,a
      006D99 BB 03 02         [24] 3389 	cjne	r3,#0x03,00331$
      006D9C 80 09            [24] 3390 	sjmp	00192$
      006D9E                       3391 00331$:
      006D9E                       3392 00130$:
                                   3393 ;	assignBit
      006D9E EF               [12] 3394 	mov	a,r7
      006D9F 24 FF            [12] 3395 	add	a,#0xff
      006DA1 92 AF            [24] 3396 	mov	_EA,c
      006DA3 75 82 00         [24] 3397 	mov	dpl, #0x00
      006DA6 22               [24] 3398 	ret
                                   3399 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006DA7                       3400 00192$:
      006DA7 7B 00            [12] 3401 	mov	r3,#0x00
      006DA9                       3402 00144$:
      006DA9 C3               [12] 3403 	clr	c
      006DAA EB               [12] 3404 	mov	a,r3
      006DAB 9E               [12] 3405 	subb	a,r6
      006DAC 50 67            [24] 3406 	jnc	00137$
                                   3407 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006DAE C0 07            [24] 3408 	push	ar7
      006DB0 90 08 3A         [24] 3409 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006DB3 E0               [24] 3410 	movx	a,@dptr
      006DB4 F9               [12] 3411 	mov	r1,a
      006DB5 E4               [12] 3412 	clr	a
      006DB6 C3               [12] 3413 	clr	c
      006DB7 C9               [12] 3414 	xch	a,r1
      006DB8 13               [12] 3415 	rrc	a
      006DB9 C9               [12] 3416 	xch	a,r1
      006DBA 13               [12] 3417 	rrc	a
      006DBB A2 E0            [12] 3418 	mov	c,acc.0
      006DBD C9               [12] 3419 	xch	a,r1
      006DBE 13               [12] 3420 	rrc	a
      006DBF C9               [12] 3421 	xch	a,r1
      006DC0 13               [12] 3422 	rrc	a
      006DC1 C9               [12] 3423 	xch	a,r1
      006DC2 FA               [12] 3424 	mov	r2,a
      006DC3 8B 00            [24] 3425 	mov	ar0,r3
      006DC5 7F 00            [12] 3426 	mov	r7,#0x00
      006DC7 E8               [12] 3427 	mov	a,r0
      006DC8 29               [12] 3428 	add	a, r1
      006DC9 F9               [12] 3429 	mov	r1,a
      006DCA EF               [12] 3430 	mov	a,r7
      006DCB 3A               [12] 3431 	addc	a, r2
      006DCC 24 10            [12] 3432 	add	a,#0x10
      006DCE FA               [12] 3433 	mov	r2,a
      006DCF 90 08 37         [24] 3434 	mov	dptr,#_ak820_usb_send_PARM_2
      006DD2 E0               [24] 3435 	movx	a,@dptr
      006DD3 F8               [12] 3436 	mov	r0,a
      006DD4 A3               [24] 3437 	inc	dptr
      006DD5 E0               [24] 3438 	movx	a,@dptr
      006DD6 FF               [12] 3439 	mov	r7,a
      006DD7 EB               [12] 3440 	mov	a,r3
      006DD8 28               [12] 3441 	add	a, r0
      006DD9 F5 1B            [12] 3442 	mov	_ak820_usb_send_sloc0_1_0,a
      006DDB E4               [12] 3443 	clr	a
      006DDC 3F               [12] 3444 	addc	a, r7
      006DDD F5 1C            [12] 3445 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006DDF 85 1B 82         [24] 3446 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006DE2 85 1C 83         [24] 3447 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006DE5 E0               [24] 3448 	movx	a,@dptr
      006DE6 89 82            [24] 3449 	mov	dpl,r1
      006DE8 8A 83            [24] 3450 	mov	dph,r2
      006DEA F0               [24] 3451 	movx	@dptr,a
                                   3452 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006DEB 90 08 3B         [24] 3453 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006DEE E0               [24] 3454 	movx	a,@dptr
      006DEF F5 1D            [12] 3455 	mov	_ak820_usb_send_sloc1_1_0,a
      006DF1 74 2E            [12] 3456 	mov	a,#0x2e
      006DF3 B5 1D 04         [24] 3457 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006DF6 D0 07            [24] 3458 	pop	ar7
      006DF8 80 18            [24] 3459 	sjmp	00145$
      006DFA                       3460 00333$:
      006DFA D0 07            [24] 3461 	pop	ar7
      006DFC EB               [12] 3462 	mov	a,r3
      006DFD 25 1D            [12] 3463 	add	a, _ak820_usb_send_sloc1_1_0
      006DFF 24 FC            [12] 3464 	add	a, #_input_snapshot
      006E01 F9               [12] 3465 	mov	r1,a
      006E02 E4               [12] 3466 	clr	a
      006E03 34 07            [12] 3467 	addc	a,#(_input_snapshot >> 8)
      006E05 FA               [12] 3468 	mov	r2,a
      006E06 85 1B 82         [24] 3469 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E09 85 1C 83         [24] 3470 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E0C E0               [24] 3471 	movx	a,@dptr
      006E0D 89 82            [24] 3472 	mov	dpl,r1
      006E0F 8A 83            [24] 3473 	mov	dph,r2
      006E11 F0               [24] 3474 	movx	@dptr,a
      006E12                       3475 00145$:
                                   3476 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006E12 0B               [12] 3477 	inc	r3
      006E13 80 94            [24] 3478 	sjmp	00144$
      006E15                       3479 00137$:
                                   3480 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006E15 90 08 3A         [24] 3481 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006E18 E0               [24] 3482 	movx	a,@dptr
      006E19 FB               [12] 3483 	mov	r3,a
      006E1A F9               [12] 3484 	mov	r1,a
      006E1B 7A 00            [12] 3485 	mov	r2,#0x00
      006E1D 74 08            [12] 3486 	mov	a,#0x08
      006E1F 29               [12] 3487 	add	a, r1
      006E20 F9               [12] 3488 	mov	r1,a
      006E21 74 22            [12] 3489 	mov	a,#0x22
      006E23 3A               [12] 3490 	addc	a, r2
      006E24 FA               [12] 3491 	mov	r2,a
      006E25 89 82            [24] 3492 	mov	dpl,r1
      006E27 8A 83            [24] 3493 	mov	dph,r2
      006E29 EE               [12] 3494 	mov	a,r6
      006E2A F0               [24] 3495 	movx	@dptr,a
                                   3496 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006E2B BB 03 06         [24] 3497 	cjne	r3,#0x03,00139$
      006E2E 90 07 D9         [24] 3498 	mov	dptr,#_raw_state
      006E31 74 04            [12] 3499 	mov	a,#0x04
      006E33 F0               [24] 3500 	movx	@dptr,a
      006E34                       3501 00139$:
                                   3502 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006E34 74 22            [12] 3503 	mov	a,#0x22
      006E36 2D               [12] 3504 	add	a, r5
      006E37 FD               [12] 3505 	mov	r5,a
      006E38 8C 82            [24] 3506 	mov	dpl,r4
      006E3A 8D 83            [24] 3507 	mov	dph,r5
      006E3C E0               [24] 3508 	movx	a,@dptr
      006E3D FE               [12] 3509 	mov	r6,a
      006E3E 53 06 FC         [24] 3510 	anl	ar6,#0xfc
      006E41 8C 82            [24] 3511 	mov	dpl,r4
      006E43 8D 83            [24] 3512 	mov	dph,r5
      006E45 EE               [12] 3513 	mov	a,r6
      006E46 F0               [24] 3514 	movx	@dptr,a
                                   3515 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3516 ;	assignBit
      006E47 EF               [12] 3517 	mov	a,r7
      006E48 24 FF            [12] 3518 	add	a,#0xff
      006E4A 92 AF            [24] 3519 	mov	_EA,c
                                   3520 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006E4C 75 82 01         [24] 3521 	mov	dpl, #0x01
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006E4F 22               [24] 3523 	ret
                                   3524 ;------------------------------------------------------------
                                   3525 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3526 ;------------------------------------------------------------
                                   3527 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3528 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3529 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3530 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3531 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3532 ;------------------------------------------------------------
                                   3533 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3534 ;	-----------------------------------------
                                   3535 ;	 function ak820_usb_try_send
                                   3536 ;	-----------------------------------------
      006E50                       3537 _ak820_usb_try_send:
      006E50 E5 82            [12] 3538 	mov	a,dpl
      006E52 90 08 3F         [24] 3539 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006E55 F0               [24] 3540 	movx	@dptr,a
                                   3541 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3542 ;	assignBit
      006E56 A2 AF            [12] 3543 	mov	c,_EA
      006E58 92 1E            [24] 3544 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3545 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006E5A 90 08 40         [24] 3546 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006E5D E4               [12] 3547 	clr	a
      006E5E F0               [24] 3548 	movx	@dptr,a
                                   3549 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3550 ;	assignBit
      006E5F C2 AF            [12] 3551 	clr	_EA
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006E61 90 08 3F         [24] 3553 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006E64 E0               [24] 3554 	movx	a,@dptr
      006E65 FF               [12] 3555 	mov	r7,a
      006E66 BF 01 00         [24] 3556 	cjne	r7,#0x01,00152$
      006E69                       3557 00152$:
      006E69 40 4E            [24] 3558 	jc	00102$
      006E6B EF               [12] 3559 	mov	a,r7
      006E6C 24 FD            [12] 3560 	add	a,#0xff - 0x02
      006E6E 40 49            [24] 3561 	jc	00102$
                                   3562 ;	free result
      006E70 90 07 D2         [24] 3563 	mov	dptr,#_USB_EnumStatus
      006E73 E0               [24] 3564 	movx	a,@dptr
      006E74 60 43            [24] 3565 	jz	00102$
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006E76 90 07 D3         [24] 3567 	mov	dptr,#_USB_SleepStatus
      006E79 E0               [24] 3568 	movx	a,@dptr
      006E7A 20 E1 3C         [24] 3569 	jb	acc.1,00102$
      006E7D 90 07 FB         [24] 3570 	mov	dptr,#_keyboard_reset
      006E80 E0               [24] 3571 	movx	a,@dptr
                                   3572 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006E81 70 36            [24] 3573 	jnz	00102$
      006E83 8F 06            [24] 3574 	mov	ar6,r7
      006E85 24 22            [12] 3575 	add	a,#0x22
      006E87 FD               [12] 3576 	mov	r5,a
      006E88 8E 82            [24] 3577 	mov	dpl,r6
      006E8A 8D 83            [24] 3578 	mov	dph,r5
      006E8C E0               [24] 3579 	movx	a,@dptr
      006E8D FE               [12] 3580 	mov	r6,a
      006E8E 53 06 03         [24] 3581 	anl	ar6,#0x03
      006E91 BE 02 25         [24] 3582 	cjne	r6,#0x02,00102$
                                   3583 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006E94 90 08 3C         [24] 3584 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006E97 E0               [24] 3585 	movx	a,@dptr
      006E98 FD               [12] 3586 	mov	r5,a
      006E99 A3               [24] 3587 	inc	dptr
      006E9A E0               [24] 3588 	movx	a,@dptr
      006E9B FE               [12] 3589 	mov	r6,a
      006E9C 90 08 3E         [24] 3590 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006E9F E0               [24] 3591 	movx	a,@dptr
      006EA0 FC               [12] 3592 	mov	r4,a
      006EA1 90 08 37         [24] 3593 	mov	dptr,#_ak820_usb_send_PARM_2
      006EA4 ED               [12] 3594 	mov	a,r5
      006EA5 F0               [24] 3595 	movx	@dptr,a
      006EA6 EE               [12] 3596 	mov	a,r6
      006EA7 A3               [24] 3597 	inc	dptr
      006EA8 F0               [24] 3598 	movx	@dptr,a
      006EA9 90 08 39         [24] 3599 	mov	dptr,#_ak820_usb_send_PARM_3
      006EAC EC               [12] 3600 	mov	a,r4
      006EAD F0               [24] 3601 	movx	@dptr,a
      006EAE 8F 82            [24] 3602 	mov	dpl, r7
      006EB0 12 6C A9         [24] 3603 	lcall	_ak820_usb_send
      006EB3 E5 82            [12] 3604 	mov	a, dpl
      006EB5 90 08 40         [24] 3605 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006EB8 F0               [24] 3606 	movx	@dptr,a
      006EB9                       3607 00102$:
                                   3608 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3609 ;	assignBit
      006EB9 A2 1E            [12] 3610 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006EBB 92 AF            [24] 3611 	mov	_EA,c
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006EBD 90 08 40         [24] 3613 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006EC0 E0               [24] 3614 	movx	a,@dptr
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006EC1 F5 82            [12] 3616 	mov	dpl,a
      006EC3 22               [24] 3617 	ret
                                   3618 ;------------------------------------------------------------
                                   3619 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3620 ;------------------------------------------------------------
                                   3621 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3622 ;	-----------------------------------------
                                   3623 ;	 function raw_request_is_nonpersistent
                                   3624 ;	-----------------------------------------
      006EC4                       3625 _raw_request_is_nonpersistent:
                                   3626 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006EC4 90 07 DA         [24] 3627 	mov	dptr,#_raw_buffer
      006EC7 E0               [24] 3628 	movx	a,@dptr
      006EC8 FF               [12] 3629 	mov	r7,a
      006EC9 BF 01 02         [24] 3630 	cjne	r7,#0x01,00302$
      006ECC 80 35            [24] 3631 	sjmp	00108$
      006ECE                       3632 00302$:
      006ECE BF 02 02         [24] 3633 	cjne	r7,#0x02,00303$
      006ED1 80 34            [24] 3634 	sjmp	00109$
      006ED3                       3635 00303$:
      006ED3 BF 04 02         [24] 3636 	cjne	r7,#0x04,00304$
      006ED6 80 2B            [24] 3637 	sjmp	00108$
      006ED8                       3638 00304$:
      006ED8 BF 08 02         [24] 3639 	cjne	r7,#0x08,00305$
      006EDB 80 47            [24] 3640 	sjmp	00116$
      006EDD                       3641 00305$:
      006EDD BF 0B 02         [24] 3642 	cjne	r7,#0x0b,00306$
      006EE0 80 21            [24] 3643 	sjmp	00108$
      006EE2                       3644 00306$:
      006EE2 BF 0C 02         [24] 3645 	cjne	r7,#0x0c,00307$
      006EE5 80 1C            [24] 3646 	sjmp	00108$
      006EE7                       3647 00307$:
      006EE7 BF 0D 02         [24] 3648 	cjne	r7,#0x0d,00308$
      006EEA 80 17            [24] 3649 	sjmp	00108$
      006EEC                       3650 00308$:
      006EEC BF 0E 02         [24] 3651 	cjne	r7,#0x0e,00309$
      006EEF 80 12            [24] 3652 	sjmp	00108$
      006EF1                       3653 00309$:
      006EF1 BF 11 02         [24] 3654 	cjne	r7,#0x11,00310$
      006EF4 80 0D            [24] 3655 	sjmp	00108$
      006EF6                       3656 00310$:
      006EF6 BF 12 02         [24] 3657 	cjne	r7,#0x12,00311$
      006EF9 80 08            [24] 3658 	sjmp	00108$
      006EFB                       3659 00311$:
      006EFB BF FE 02         [24] 3660 	cjne	r7,#0xfe,00312$
      006EFE 80 46            [24] 3661 	sjmp	00124$
      006F00                       3662 00312$:
      006F00 02 6F 9B         [24] 3663 	ljmp	00144$
                                   3664 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006F03                       3665 00108$:
                                   3666 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006F03 75 82 01         [24] 3667 	mov	dpl, #0x01
      006F06 22               [24] 3668 	ret
                                   3669 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006F07                       3670 00109$:
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006F07 12 71 EF         [24] 3672 	lcall	_ak820_outline_0166
      006F0A BF 01 02         [24] 3673 	cjne	r7,#0x01,00313$
      006F0D 80 0D            [24] 3674 	sjmp	00113$
      006F0F                       3675 00313$:
      006F0F BF 02 02         [24] 3676 	cjne	r7,#0x02,00314$
      006F12 80 08            [24] 3677 	sjmp	00113$
      006F14                       3678 00314$:
      006F14 BF 03 02         [24] 3679 	cjne	r7,#0x03,00315$
      006F17 80 03            [24] 3680 	sjmp	00113$
      006F19                       3681 00315$:
      006F19 BF 04 04         [24] 3682 	cjne	r7,#0x04,00114$
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006F1C                       3684 00113$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006F1C 75 82 01         [24] 3686 	mov	dpl, #0x01
      006F1F 22               [24] 3687 	ret
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006F20                       3689 00114$:
      006F20 75 82 00         [24] 3690 	mov	dpl, #0x00
      006F23 22               [24] 3691 	ret
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006F24                       3693 00116$:
                                   3694 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006F24 12 71 EF         [24] 3695 	lcall	_ak820_outline_0166
      006F27 BF 40 02         [24] 3696 	cjne	r7,#0x40,00318$
      006F2A 80 12            [24] 3697 	sjmp	00121$
      006F2C                       3698 00318$:
      006F2C BF 41 02         [24] 3699 	cjne	r7,#0x41,00319$
      006F2F 80 0D            [24] 3700 	sjmp	00121$
      006F31                       3701 00319$:
      006F31 BF 42 02         [24] 3702 	cjne	r7,#0x42,00320$
      006F34 80 08            [24] 3703 	sjmp	00121$
      006F36                       3704 00320$:
      006F36 BF 43 02         [24] 3705 	cjne	r7,#0x43,00321$
      006F39 80 03            [24] 3706 	sjmp	00121$
      006F3B                       3707 00321$:
      006F3B BF 44 04         [24] 3708 	cjne	r7,#0x44,00122$
                                   3709 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006F3E                       3710 00121$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006F3E 75 82 01         [24] 3712 	mov	dpl, #0x01
                                   3713 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006F41 22               [24] 3714 	ret
      006F42                       3715 00122$:
      006F42 75 82 00         [24] 3716 	mov	dpl, #0x00
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006F45 22               [24] 3718 	ret
      006F46                       3719 00124$:
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006F46 12 71 EF         [24] 3721 	lcall	_ak820_outline_0166
      006F49 24 F2            [12] 3722 	add	a,#0xff - 0x0d
      006F4B 40 4A            [24] 3723 	jc	00142$
                                   3724 ;	free result
      006F4D EF               [12] 3725 	mov	a,r7
      006F4E 24 0A            [12] 3726 	add	a,#(00325$-3-.)
      006F50 83               [24] 3727 	movc	a,@a+pc
      006F51 F5 82            [12] 3728 	mov	dpl,a
      006F53 EF               [12] 3729 	mov	a,r7
      006F54 24 12            [12] 3730 	add	a,#(00326$-3-.)
      006F56 83               [24] 3731 	movc	a,@a+pc
      006F57 F5 83            [12] 3732 	mov	dph,a
      006F59 E4               [12] 3733 	clr	a
      006F5A 73               [24] 3734 	jmp	@a+dptr
      006F5B                       3735 00325$:
      006F5B 77                    3736 	.db	00134$
      006F5C 77                    3737 	.db	00134$
      006F5D 77                    3738 	.db	00134$
      006F5E 77                    3739 	.db	00134$
      006F5F 97                    3740 	.db	00142$
      006F60 77                    3741 	.db	00134$
      006F61 77                    3742 	.db	00134$
      006F62 77                    3743 	.db	00134$
      006F63 77                    3744 	.db	00134$
      006F64 77                    3745 	.db	00134$
      006F65 77                    3746 	.db	00134$
      006F66 97                    3747 	.db	00142$
      006F67 97                    3748 	.db	00142$
      006F68 7B                    3749 	.db	00135$
      006F69                       3750 00326$:
      006F69 6F                    3751 	.db	00134$>>8
      006F6A 6F                    3752 	.db	00134$>>8
      006F6B 6F                    3753 	.db	00134$>>8
      006F6C 6F                    3754 	.db	00134$>>8
      006F6D 6F                    3755 	.db	00142$>>8
      006F6E 6F                    3756 	.db	00134$>>8
      006F6F 6F                    3757 	.db	00134$>>8
      006F70 6F                    3758 	.db	00134$>>8
      006F71 6F                    3759 	.db	00134$>>8
      006F72 6F                    3760 	.db	00134$>>8
      006F73 6F                    3761 	.db	00134$>>8
      006F74 6F                    3762 	.db	00142$>>8
      006F75 6F                    3763 	.db	00142$>>8
      006F76 6F                    3764 	.db	00135$>>8
                                   3765 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006F77                       3766 00134$:
                                   3767 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006F77 75 82 01         [24] 3768 	mov	dpl, #0x01
                                   3769 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006F7A 22               [24] 3770 	ret
      006F7B                       3771 00135$:
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006F7B 90 07 DC         [24] 3773 	mov	dptr,#(_raw_buffer + 0x0002)
      006F7E E0               [24] 3774 	movx	a,@dptr
      006F7F FF               [12] 3775 	mov	r7,a
      006F80 60 0D            [24] 3776 	jz	00139$
      006F82 BF 01 02         [24] 3777 	cjne	r7,#0x01,00328$
      006F85 80 08            [24] 3778 	sjmp	00139$
      006F87                       3779 00328$:
      006F87 BF 03 02         [24] 3780 	cjne	r7,#0x03,00329$
      006F8A 80 03            [24] 3781 	sjmp	00139$
      006F8C                       3782 00329$:
      006F8C BF 05 04         [24] 3783 	cjne	r7,#0x05,00140$
                                   3784 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006F8F                       3785 00139$:
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006F8F 75 82 01         [24] 3787 	mov	dpl, #0x01
                                   3788 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006F92 22               [24] 3789 	ret
      006F93                       3790 00140$:
      006F93 75 82 00         [24] 3791 	mov	dpl, #0x00
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006F96 22               [24] 3793 	ret
      006F97                       3794 00142$:
      006F97 75 82 00         [24] 3795 	mov	dpl, #0x00
                                   3796 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006F9A 22               [24] 3797 	ret
      006F9B                       3798 00144$:
      006F9B 75 82 00         [24] 3799 	mov	dpl, #0x00
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3801 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006F9E 22               [24] 3802 	ret
                                   3803 ;------------------------------------------------------------
                                   3804 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3805 ;------------------------------------------------------------
                                   3806 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3807 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3808 ;------------------------------------------------------------
                                   3809 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3810 ;	-----------------------------------------
                                   3811 ;	 function ak820_usb_raw_send
                                   3812 ;	-----------------------------------------
      006F9F                       3813 _ak820_usb_raw_send:
      006F9F 12 48 A0         [24] 3814 	lcall	_ak820_outline_0036
      006FA2 90 08 42         [24] 3815 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006FA5 12 3A 5F         [24] 3816 	lcall	_ak820_outline_0016
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006FA8 90 08 41         [24] 3818 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006FAB E0               [24] 3819 	movx	a,@dptr
      006FAC FF               [12] 3820 	mov	r7,a
      006FAD BF 20 2B         [24] 3821 	cjne	r7,#0x20,00106$
                                   3822 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006FB0 C0 07            [24] 3823 	push	ar7
      006FB2 12 43 B6         [24] 3824 	lcall	_ak820_nvm_flush
      006FB5 D0 07            [24] 3825 	pop	ar7
                                   3826 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006FB7 90 07 FA         [24] 3827 	mov	dptr,#_raw_reply_without_nvm
      006FBA E0               [24] 3828 	movx	a,@dptr
      006FBB 70 07            [24] 3829 	jnz	00103$
      006FBD 12 43 A7         [24] 3830 	lcall	_ak820_nvm_ok
      006FC0 E5 82            [12] 3831 	mov	a, dpl
      006FC2 60 17            [24] 3832 	jz	00106$
      006FC4                       3833 00103$:
      006FC4 90 08 42         [24] 3834 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006FC7 12 3A A4         [24] 3835 	lcall	_ak820_outline_0080
      006FCA 90 08 37         [24] 3836 	mov	dptr,#_ak820_usb_send_PARM_2
      006FCD 12 49 0A         [24] 3837 	lcall	_ak820_outline_0164
      006FD0 90 08 39         [24] 3838 	mov	dptr,#_ak820_usb_send_PARM_3
      006FD3 EF               [12] 3839 	mov	a,r7
      006FD4 F0               [24] 3840 	movx	@dptr,a
      006FD5 75 82 03         [24] 3841 	mov	dpl, #0x03
                                   3842 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006FD8 02 6C A9         [24] 3843 	ljmp	_ak820_usb_send
      006FDB                       3844 00106$:
      006FDB 22               [24] 3845 	ret
                                   3846 ;------------------------------------------------------------
                                   3847 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3848 ;------------------------------------------------------------
                                   3849 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3850 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3851 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3852 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3853 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3854 ;------------------------------------------------------------
                                   3855 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3856 ;	-----------------------------------------
                                   3857 ;	 function ak820_usb_raw_task
                                   3858 ;	-----------------------------------------
      006FDC                       3859 _ak820_usb_raw_task:
                                   3860 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006FDC A2 AF            [12] 3861 	mov	c,_EA
      006FDE E4               [12] 3862 	clr	a
      006FDF 33               [12] 3863 	rlc	a
      006FE0 FF               [12] 3864 	mov	r7,a
                                   3865 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3866 ;	assignBit
      006FE1 C2 AF            [12] 3867 	clr	_EA
                                   3868 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006FE3 90 07 D2         [24] 3869 	mov	dptr,#_USB_EnumStatus
      006FE6 E0               [24] 3870 	movx	a,@dptr
      006FE7 60 0A            [24] 3871 	jz	00101$
      006FE9 90 07 D9         [24] 3872 	mov	dptr,#_raw_state
      006FEC E0               [24] 3873 	movx	a,@dptr
      006FED FE               [12] 3874 	mov	r6,a
      006FEE BE 02 02         [24] 3875 	cjne	r6,#0x02,00270$
      006FF1 80 06            [24] 3876 	sjmp	00102$
      006FF3                       3877 00270$:
      006FF3                       3878 00101$:
                                   3879 ;	assignBit
      006FF3 EF               [12] 3880 	mov	a,r7
      006FF4 24 FF            [12] 3881 	add	a,#0xff
      006FF6 92 AF            [24] 3882 	mov	_EA,c
      006FF8 22               [24] 3883 	ret
      006FF9                       3884 00102$:
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006FF9 90 07 D9         [24] 3886 	mov	dptr,#_raw_state
      006FFC 74 03            [12] 3887 	mov	a,#0x03
      006FFE F0               [24] 3888 	movx	@dptr,a
                                   3889 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3890 ;	assignBit
      006FFF EF               [12] 3891 	mov	a,r7
      007000 24 FF            [12] 3892 	add	a,#0xff
      007002 92 AF            [24] 3893 	mov	_EA,c
                                   3894 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      007004 90 07 DA         [24] 3895 	mov	dptr,#_raw_buffer
      007007 E0               [24] 3896 	movx	a,@dptr
      007008 FF               [12] 3897 	mov	r7,a
      007009 E4               [12] 3898 	clr	a
      00700A BF FD 01         [24] 3899 	cjne	r7,#0xfd,00271$
      00700D 04               [12] 3900 	inc	a
      00700E                       3901 00271$:
      00700E FF               [12] 3902 	mov	r7,a
      00700F 70 03            [24] 3903 	jnz	00273$
      007011 02 70 B1         [24] 3904 	ljmp	00118$
      007014                       3905 00273$:
      007014 90 07 DB         [24] 3906 	mov	dptr,#(_raw_buffer + 0x0001)
      007017 E0               [24] 3907 	movx	a,@dptr
      007018 60 03            [24] 3908 	jz	00274$
      00701A 02 70 B1         [24] 3909 	ljmp	00118$
      00701D                       3910 00274$:
                                   3911 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      00701D 90 07 DC         [24] 3912 	mov	dptr,#(_raw_buffer + 0x0002)
      007020 E0               [24] 3913 	movx	a,@dptr
      007021 FD               [12] 3914 	mov	r5,a
      007022 7E 00            [12] 3915 	mov	r6,#0x00
      007024 90 07 DD         [24] 3916 	mov	dptr,#(_raw_buffer + 0x0003)
      007027 E0               [24] 3917 	movx	a,@dptr
      007028 7B 00            [12] 3918 	mov	r3,#0x00
      00702A 42 06            [12] 3919 	orl	ar6,a
      00702C EB               [12] 3920 	mov	a,r3
      00702D 42 05            [12] 3921 	orl	ar5,a
                                   3922 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      00702F 90 07 DE         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0004)
      007032 E0               [24] 3924 	movx	a,@dptr
      007033 FC               [12] 3925 	mov	r4,a
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      007034 7B 05            [12] 3927 	mov	r3,#0x05
      007036                       3928 00128$:
      007036 EB               [12] 3929 	mov	a,r3
      007037 12 71 DD         [24] 3930 	lcall	_ak820_outline_0107
      00703A 0B               [12] 3931 	inc	r3
      00703B BB 20 00         [24] 3932 	cjne	r3,#0x20,00275$
      00703E                       3933 00275$:
      00703E 40 F6            [24] 3934 	jc	00128$
                                   3935 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      007040 EC               [12] 3936 	mov	a,r4
      007041 24 E4            [12] 3937 	add	a,#0xff - 0x1b
      007043 40 1C            [24] 3938 	jc	00106$
                                   3939 ;	free result
      007045 EC               [12] 3940 	mov	a,r4
      007046 60 26            [24] 3941 	jz	00165$
      007048 8C 03            [24] 3942 	mov	ar3,r4
      00704A 1B               [12] 3943 	dec	r3
      00704B 7A 00            [12] 3944 	mov	r2,#0x00
      00704D 74 FF            [12] 3945 	mov	a,#0xff
      00704F C3               [12] 3946 	clr	c
      007050 9B               [12] 3947 	subb	a,r3
      007051 FB               [12] 3948 	mov	r3,a
      007052 74 FF            [12] 3949 	mov	a,#0xff
      007054 9A               [12] 3950 	subb	a,r2
      007055 FA               [12] 3951 	mov	r2,a
      007056 8E 00            [24] 3952 	mov	ar0,r6
      007058 8D 01            [24] 3953 	mov	ar1,r5
      00705A C3               [12] 3954 	clr	c
      00705B EB               [12] 3955 	mov	a,r3
      00705C 98               [12] 3956 	subb	a,r0
      00705D EA               [12] 3957 	mov	a,r2
      00705E 99               [12] 3958 	subb	a,r1
      00705F 50 0D            [24] 3959 	jnc	00165$
                                   3960 ;	free result
      007061                       3961 00106$:
                                   3962 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      007061 90 07 DB         [24] 3963 	mov	dptr,#(_raw_buffer + 0x0001)
      007064 74 FF            [12] 3964 	mov	a,#0xff
      007066 F0               [24] 3965 	movx	@dptr,a
                                   3966 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      007067 90 07 DE         [24] 3967 	mov	dptr,#(_raw_buffer + 0x0004)
      00706A E4               [12] 3968 	clr	a
      00706B F0               [24] 3969 	movx	@dptr,a
                                   3970 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      00706C 80 3A            [24] 3971 	sjmp	00108$
      00706E                       3972 00165$:
      00706E 7B 00            [12] 3973 	mov	r3,#0x00
      007070                       3974 00131$:
      007070 C3               [12] 3975 	clr	c
      007071 EB               [12] 3976 	mov	a,r3
      007072 9C               [12] 3977 	subb	a,r4
      007073 50 33            [24] 3978 	jnc	00108$
      007075 C0 04            [24] 3979 	push	ar4
      007077 8B 02            [24] 3980 	mov	ar2,r3
      007079 74 05            [12] 3981 	mov	a,#0x05
      00707B 2A               [12] 3982 	add	a, r2
      00707C F9               [12] 3983 	mov	r1,a
      00707D 33               [12] 3984 	rlc	a
      00707E 95 E0            [12] 3985 	subb	a,acc
      007080 FA               [12] 3986 	mov	r2,a
      007081 E9               [12] 3987 	mov	a,r1
      007082 24 DA            [12] 3988 	add	a, #_raw_buffer
      007084 F9               [12] 3989 	mov	r1,a
      007085 EA               [12] 3990 	mov	a,r2
      007086 34 07            [12] 3991 	addc	a, #(_raw_buffer >> 8)
      007088 FA               [12] 3992 	mov	r2,a
      007089 8B 1E            [24] 3993 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      00708B 75 1F 00         [24] 3994 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      00708E 8E 00            [24] 3995 	mov	ar0,r6
      007090 8D 04            [24] 3996 	mov	ar4,r5
      007092 E5 1E            [12] 3997 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      007094 28               [12] 3998 	add	a, r0
      007095 F8               [12] 3999 	mov	r0,a
      007096 E5 1F            [12] 4000 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      007098 3C               [12] 4001 	addc	a, r4
      007099 FC               [12] 4002 	mov	r4,a
      00709A 88 82            [24] 4003 	mov	dpl,r0
      00709C 8C 83            [24] 4004 	mov	dph,r4
      00709E E4               [12] 4005 	clr	a
      00709F 93               [24] 4006 	movc	a,@a+dptr
      0070A0 12 71 E9         [24] 4007 	lcall	_ak820_outline_0141
      0070A3 0B               [12] 4008 	inc	r3
      0070A4 D0 04            [24] 4009 	pop	ar4
      0070A6 80 C8            [24] 4010 	sjmp	00131$
      0070A8                       4011 00108$:
                                   4012 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0070A8 12 71 C9         [24] 4013 	lcall	_ak820_outline_0045
      0070AB 12 6C A9         [24] 4014 	lcall	_ak820_usb_send
      0070AE 02 71 57         [24] 4015 	ljmp	00119$
      0070B1                       4016 00118$:
                                   4017 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      0070B1 EF               [12] 4018 	mov	a,r7
      0070B2 70 03            [24] 4019 	jnz	00281$
      0070B4 02 71 34         [24] 4020 	ljmp	00114$
      0070B7                       4021 00281$:
      0070B7 12 71 EF         [24] 4022 	lcall	_ak820_outline_0166
      0070BA BF 01 02         [24] 4023 	cjne	r7,#0x01,00282$
      0070BD 80 03            [24] 4024 	sjmp	00283$
      0070BF                       4025 00282$:
      0070BF 02 71 34         [24] 4026 	ljmp	00114$
      0070C2                       4027 00283$:
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0070C2 7F 02            [12] 4029 	mov	r7,#0x02
      0070C4                       4030 00133$:
      0070C4 EF               [12] 4031 	mov	a,r7
      0070C5 12 71 DD         [24] 4032 	lcall	_ak820_outline_0107
      0070C8 0F               [12] 4033 	inc	r7
      0070C9 BF 20 00         [24] 4034 	cjne	r7,#0x20,00284$
      0070CC                       4035 00284$:
      0070CC 40 F6            [24] 4036 	jc	00133$
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      0070CE 90 07 DC         [24] 4038 	mov	dptr,#(_raw_buffer + 0x0002)
      0070D1 74 01            [12] 4039 	mov	a,#0x01
      0070D3 F0               [24] 4040 	movx	@dptr,a
                                   4041 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      0070D4 90 07 DD         [24] 4042 	mov	dptr,#(_raw_buffer + 0x0003)
      0070D7 74 A8            [12] 4043 	mov	a,#0xa8
      0070D9 F0               [24] 4044 	movx	@dptr,a
                                   4045 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      0070DA 90 07 DE         [24] 4046 	mov	dptr,#(_raw_buffer + 0x0004)
      0070DD 12 41 24         [24] 4047 	lcall	_ak820_nvm_diagnostic
                                   4048 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      0070E0 7F 00            [12] 4049 	mov	r7,#0x00
      0070E2                       4050 00135$:
      0070E2 8F 06            [24] 4051 	mov	ar6,r7
      0070E4 74 0B            [12] 4052 	mov	a,#0x0b
      0070E6 2E               [12] 4053 	add	a, r6
      0070E7 24 DA            [12] 4054 	add	a,#_raw_buffer
      0070E9 FE               [12] 4055 	mov	r6,a
      0070EA E4               [12] 4056 	clr	a
      0070EB 34 07            [12] 4057 	addc	a, #(_raw_buffer >> 8)
      0070ED FD               [12] 4058 	mov	r5,a
      0070EE EF               [12] 4059 	mov	a,r7
      0070EF 24 CA            [12] 4060 	add	a, #_ak820_flash_diagnostic
      0070F1 F5 82            [12] 4061 	mov	dpl,a
      0070F3 E4               [12] 4062 	clr	a
      0070F4 34 04            [12] 4063 	addc	a, #(_ak820_flash_diagnostic >> 8)
      0070F6 F5 83            [12] 4064 	mov	dph,a
      0070F8 E0               [24] 4065 	movx	a,@dptr
      0070F9 8E 82            [24] 4066 	mov	dpl,r6
      0070FB 8D 83            [24] 4067 	mov	dph,r5
      0070FD F0               [24] 4068 	movx	@dptr,a
      0070FE 0F               [12] 4069 	inc	r7
      0070FF BF 06 00         [24] 4070 	cjne	r7,#0x06,00286$
      007102                       4071 00286$:
      007102 40 DE            [24] 4072 	jc	00135$
                                   4073 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      007104 90 0E 8B         [24] 4074 	mov	dptr,#_vial_unlocked
      007107 E0               [24] 4075 	movx	a,@dptr
      007108 90 07 EB         [24] 4076 	mov	dptr,#(_raw_buffer + 0x0011)
      00710B F0               [24] 4077 	movx	@dptr,a
                                   4078 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      00710C 90 0E 8C         [24] 4079 	mov	dptr,#_vial_unlock_in_progress
      00710F E0               [24] 4080 	movx	a,@dptr
      007110 90 07 EC         [24] 4081 	mov	dptr,#(_raw_buffer + 0x0012)
      007113 F0               [24] 4082 	movx	@dptr,a
                                   4083 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      007114 90 07 D2         [24] 4084 	mov	dptr,#_USB_EnumStatus
      007117 E0               [24] 4085 	movx	a,@dptr
      007118 90 07 ED         [24] 4086 	mov	dptr,#(_raw_buffer + 0x0013)
      00711B F0               [24] 4087 	movx	@dptr,a
                                   4088 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      00711C 90 07 D3         [24] 4089 	mov	dptr,#_USB_SleepStatus
      00711F E0               [24] 4090 	movx	a,@dptr
      007120 90 07 EE         [24] 4091 	mov	dptr,#(_raw_buffer + 0x0014)
      007123 F0               [24] 4092 	movx	@dptr,a
                                   4093 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      007124 90 07 D9         [24] 4094 	mov	dptr,#_raw_state
      007127 E0               [24] 4095 	movx	a,@dptr
      007128 90 07 EF         [24] 4096 	mov	dptr,#(_raw_buffer + 0x0015)
      00712B F0               [24] 4097 	movx	@dptr,a
                                   4098 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00712C 12 71 C9         [24] 4099 	lcall	_ak820_outline_0045
      00712F 12 6C A9         [24] 4100 	lcall	_ak820_usb_send
      007132 80 23            [24] 4101 	sjmp	00119$
      007134                       4102 00114$:
                                   4103 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007134 12 6E C4         [24] 4104 	lcall	_raw_request_is_nonpersistent
      007137 E5 82            [12] 4105 	mov	a, dpl
      007139 90 07 FA         [24] 4106 	mov	dptr,#_raw_reply_without_nvm
      00713C F0               [24] 4107 	movx	@dptr,a
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      00713D 12 45 09         [24] 4109 	lcall	_ak820_nvm_begin
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      007140 90 0C BC         [24] 4111 	mov	dptr,#_raw_hid_receive_PARM_2
      007143 74 20            [12] 4112 	mov	a,#0x20
      007145 F0               [24] 4113 	movx	@dptr,a
      007146 90 07 DA         [24] 4114 	mov	dptr,#_raw_buffer
      007149 75 F0 00         [24] 4115 	mov	b, #0x00
      00714C 12 AC 6A         [24] 4116 	lcall	_raw_hid_receive
                                   4117 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      00714F 12 45 1E         [24] 4118 	lcall	_ak820_nvm_end
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      007152 90 07 FA         [24] 4120 	mov	dptr,#_raw_reply_without_nvm
      007155 E4               [12] 4121 	clr	a
      007156 F0               [24] 4122 	movx	@dptr,a
      007157                       4123 00119$:
                                   4124 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4125 ;	assignBit
      007157 A2 AF            [12] 4126 	mov	c,_EA
      007159 92 1F            [24] 4127 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4128 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4129 ;	assignBit
      00715B C2 AF            [12] 4130 	clr	_EA
                                   4131 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      00715D 12 71 F5         [24] 4132 	lcall	_ak820_outline_0168
      007160 BF 04 08         [24] 4133 	cjne	r7,#0x04,00126$
      007163 90 07 D9         [24] 4134 	mov	dptr,#_raw_state
      007166 74 05            [12] 4135 	mov	a,#0x05
      007168 F0               [24] 4136 	movx	@dptr,a
      007169 80 1B            [24] 4137 	sjmp	00127$
      00716B                       4138 00126$:
                                   4139 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      00716B 12 71 F5         [24] 4140 	lcall	_ak820_outline_0168
      00716E BF 03 02         [24] 4141 	cjne	r7,#0x03,00290$
      007171 80 0E            [24] 4142 	sjmp	00121$
      007173                       4143 00290$:
      007173 12 71 F5         [24] 4144 	lcall	_ak820_outline_0168
      007176 BF 06 02         [24] 4145 	cjne	r7,#0x06,00291$
      007179 80 06            [24] 4146 	sjmp	00121$
      00717B                       4147 00291$:
      00717B 12 71 F5         [24] 4148 	lcall	_ak820_outline_0168
      00717E BF 07 05         [24] 4149 	cjne	r7,#0x07,00127$
      007181                       4150 00121$:
      007181 90 07 D9         [24] 4151 	mov	dptr,#_raw_state
      007184 E4               [12] 4152 	clr	a
      007185 F0               [24] 4153 	movx	@dptr,a
      007186                       4154 00127$:
                                   4155 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4156 ;	assignBit
      007186 A2 1F            [12] 4157 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      007188 92 AF            [24] 4158 	mov	_EA,c
                                   4159 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      00718A 22               [24] 4160 	ret
                                   4161 ;------------------------------------------------------------
                                   4162 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4163 ;------------------------------------------------------------
                                   4164 ;	tmk_core/protocol/ch555/usb_ak820.c:665: bool ak820_usb_keyboard_blocked(void) {
                                   4165 ;	-----------------------------------------
                                   4166 ;	 function ak820_usb_keyboard_blocked
                                   4167 ;	-----------------------------------------
      00718B                       4168 _ak820_usb_keyboard_blocked:
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:666: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      00718B 90 07 D2         [24] 4170 	mov	dptr,#_USB_EnumStatus
      00718E E0               [24] 4171 	movx	a,@dptr
      00718F 60 13            [24] 4172 	jz	00104$
      007191 90 07 D3         [24] 4173 	mov	dptr,#_USB_SleepStatus
      007194 E0               [24] 4174 	movx	a,@dptr
      007195 03               [12] 4175 	rr	a
      007196 54 01            [12] 4176 	anl	a,#0x01
      007198 70 0A            [24] 4177 	jnz	00104$
      00719A 90 07 FB         [24] 4178 	mov	dptr,#_keyboard_reset
      00719D E0               [24] 4179 	movx	a,@dptr
      00719E 70 04            [24] 4180 	jnz	00104$
                                   4181 ;	assignBit
      0071A0 C2 20            [12] 4182 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      0071A2 80 02            [24] 4183 	sjmp	00105$
      0071A4                       4184 00104$:
                                   4185 ;	assignBit
      0071A4 D2 20            [12] 4186 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      0071A6                       4187 00105$:
      0071A6 A2 20            [12] 4188 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      0071A8 E4               [12] 4189 	clr	a
      0071A9 33               [12] 4190 	rlc	a
      0071AA F5 82            [12] 4191 	mov	dpl, a
                                   4192 ;	tmk_core/protocol/ch555/usb_ak820.c:667: }
      0071AC 22               [24] 4193 	ret
                                   4194 ;------------------------------------------------------------
                                   4195 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4196 ;------------------------------------------------------------
                                   4197 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_485'
                                   4198 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_485'
                                   4199 ;------------------------------------------------------------
                                   4200 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4201 ;	-----------------------------------------
                                   4202 ;	 function ak820_usb_take_keyboard_reset
                                   4203 ;	-----------------------------------------
      0071AD                       4204 _ak820_usb_take_keyboard_reset:
                                   4205 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4206 ;	assignBit
      0071AD A2 AF            [12] 4207 	mov	c,_EA
      0071AF 92 21            [24] 4208 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4209 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4210 ;	assignBit
      0071B1 C2 AF            [12] 4211 	clr	_EA
                                   4212 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      0071B3 90 07 FB         [24] 4213 	mov	dptr,#_keyboard_reset
      0071B6 E0               [24] 4214 	movx	a,@dptr
      0071B7 FF               [12] 4215 	mov	r7,a
                                   4216 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      0071B8 E4               [12] 4217 	clr	a
      0071B9 F0               [24] 4218 	movx	@dptr,a
                                   4219 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4220 ;	assignBit
      0071BA A2 21            [12] 4221 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      0071BC 92 AF            [24] 4222 	mov	_EA,c
                                   4223 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      0071BE EF               [12] 4224 	mov	a,r7
      0071BF B4 01 00         [24] 4225 	cjne	a,#0x01,00103$
      0071C2                       4226 00103$:
      0071C2 B3               [12] 4227 	cpl	c
      0071C3 92 21            [24] 4228 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0071C5 12 3A F6         [24] 4229 	lcall	_ak820_outline_0159
                                   4230 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      0071C8 22               [24] 4231 	ret
                                   4232 	.area CSEG    (CODE)
                                   4233 	.area CONST   (CODE)
                                   4234 	.area CONST   (CODE)
      00BF1D                       4235 _shared_offsets:
      00BF1D 00                    4236 	.db #0x00	; 0
      00BF1E 00                    4237 	.db #0x00	; 0
      00BF1F 28                    4238 	.db #0x28	; 40
      00BF20 28                    4239 	.db #0x28	; 40
      00BF21 2B                    4240 	.db #0x2b	; 43
      00BF22 00                    4241 	.db #0x00	; 0
      00BF23 08                    4242 	.db #0x08	; 8
                                   4243 	.area CSEG    (CODE)
                                   4244 	.area CONST   (CODE)
      00BF24                       4245 _shared_lengths:
      00BF24 00                    4246 	.db #0x00	; 0
      00BF25 00                    4247 	.db #0x00	; 0
      00BF26 00                    4248 	.db #0x00	; 0
      00BF27 03                    4249 	.db #0x03	; 3
      00BF28 03                    4250 	.db #0x03	; 3
      00BF29 00                    4251 	.db #0x00	; 0
      00BF2A 20                    4252 	.db #0x20	; 32
                                   4253 	.area CSEG    (CODE)
                                   4254 	.area CONST   (CODE)
      00BF2B                       4255 _interface_descriptors:
      00BF2B C6 C4                 4256 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BF2D C6 C5                 4257 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BF2F 79 C5                 4258 	.byte _RawReport, (_RawReport >> 8)
      00BF31 DF C5                 4259 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BF33 0B C5                 4260 	.byte _SharedReport, (_SharedReport >> 8)
      00BF35 F8 C5                 4261 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4262 	.area CSEG    (CODE)
                                   4263 	.area XINIT   (CODE)
                                   4264 	.area CABS    (ABS,CODE)
                                   4265 
                                   4266 ; Experimental exact instruction outlining.
                                   4267 	.globl _ak820_outline_0016
                                   4268 	.globl _ak820_outline_0036
                                   4269 	.globl _ak820_outline_0045
                                   4270 	.globl _ak820_outline_0080
                                   4271 	.globl _ak820_outline_0107
                                   4272 	.globl _ak820_outline_0141
                                   4273 	.globl _ak820_outline_0159
                                   4274 	.globl _ak820_outline_0164
                                   4275 	.globl _ak820_outline_0166
                                   4276 	.globl _ak820_outline_0168
                                   4277 
                                   4278 	.area CSEG (CODE)
                                   4279 ; function ak820_outline_0045
      0071C9                       4280 _ak820_outline_0045:
      0071C9 90 08 37         [24] 4281 	mov	dptr,#_ak820_usb_send_PARM_2
      0071CC 74 DA            [12] 4282 	mov	a,#_raw_buffer
      0071CE F0               [24] 4283 	movx	@dptr,a
      0071CF 74 07            [12] 4284 	mov	a,#(_raw_buffer>>8)
      0071D1 A3               [24] 4285 	inc	dptr
      0071D2 F0               [24] 4286 	movx	@dptr,a
      0071D3 90 08 39         [24] 4287 	mov	dptr,#_ak820_usb_send_PARM_3
      0071D6 74 20            [12] 4288 	mov	a,#0x20
      0071D8 F0               [24] 4289 	movx	@dptr,a
      0071D9 75 82 03         [24] 4290 	mov	dpl,#0x03
      0071DC 22               [24] 4291 	ret
                                   4292 
                                   4293 	.area CSEG (CODE)
                                   4294 ; function ak820_outline_0107
      0071DD                       4295 _ak820_outline_0107:
      0071DD 24 DA            [12] 4296 	add	a,#_raw_buffer
      0071DF F5 82            [12] 4297 	mov	dpl,a
      0071E1 E4               [12] 4298 	clr	a
      0071E2 34 07            [12] 4299 	addc	a,#(_raw_buffer>>8)
      0071E4 F5 83            [12] 4300 	mov	dph,a
      0071E6 E4               [12] 4301 	clr	a
      0071E7 F0               [24] 4302 	movx	@dptr,a
      0071E8 22               [24] 4303 	ret
                                   4304 
                                   4305 	.area CSEG (CODE)
                                   4306 ; function ak820_outline_0141
      0071E9                       4307 _ak820_outline_0141:
      0071E9 89 82            [24] 4308 	mov	dpl,r1
      0071EB 8A 83            [24] 4309 	mov	dph,r2
      0071ED F0               [24] 4310 	movx	@dptr,a
      0071EE 22               [24] 4311 	ret
                                   4312 
                                   4313 	.area CSEG (CODE)
                                   4314 ; function ak820_outline_0166
      0071EF                       4315 _ak820_outline_0166:
      0071EF 90 07 DB         [24] 4316 	mov	dptr,#(_raw_buffer+0x0001)
      0071F2 E0               [24] 4317 	movx	a,@dptr
      0071F3 FF               [12] 4318 	mov	r7,a
      0071F4 22               [24] 4319 	ret
                                   4320 
                                   4321 	.area CSEG (CODE)
                                   4322 ; function ak820_outline_0168
      0071F5                       4323 _ak820_outline_0168:
      0071F5 90 07 D9         [24] 4324 	mov	dptr,#_raw_state
      0071F8 E0               [24] 4325 	movx	a,@dptr
      0071F9 FF               [12] 4326 	mov	r7,a
      0071FA 22               [24] 4327 	ret
