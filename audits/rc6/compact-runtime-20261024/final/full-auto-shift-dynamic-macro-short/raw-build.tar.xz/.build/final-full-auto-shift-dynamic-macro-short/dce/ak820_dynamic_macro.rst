                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_dynamic_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_keyboard_report_pending
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_key
                                     14 	.globl _add_owned_key
                                     15 	.globl _del_owned_mods
                                     16 	.globl _add_owned_mods
                                     17 	.globl _get_weak_mods
                                     18 	.globl _get_mods
                                     19 	.globl _send_keyboard_report
                                     20 	.globl _timer_read
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_dynamic_macro_observe_PARM_2
                                    265 	.globl _ak820_dynamic_macro_process_PARM_2
                                    266 	.globl _ak820_dynamic_macro_source
                                    267 	.globl _ak820_dynamic_macro_cancel
                                    268 	.globl _ak820_dynamic_macro_process
                                    269 	.globl _ak820_dynamic_macro_observe
                                    270 	.globl _ak820_dynamic_macro_task
                                    271 ;--------------------------------------------------------
                                    272 ; special function registers
                                    273 ;--------------------------------------------------------
                                    274 	.area RSEG    (ABS,DATA)
      000000                        275 	.org 0x0000
                           0000D0   276 _PSW	=	0x00d0
                           0000E0   277 _ACC	=	0x00e0
                           0000F0   278 _B	=	0x00f0
                           0000FD   279 _A_INV	=	0x00fd
                           000081   280 _SP	=	0x0081
                           000082   281 _DPL	=	0x0082
                           000083   282 _DPH	=	0x0083
                           0000A1   283 _SAFE_MOD	=	0x00a1
                           0000B1   284 _GLOBAL_CFG	=	0x00b1
                           000087   285 _PCON	=	0x0087
                           0000BA   286 _POWER_CFG	=	0x00ba
                           0000B9   287 _CLOCK_CFG	=	0x00b9
                           0000A9   288 _WAKE_CTRL	=	0x00a9
                           0000FE   289 _RESET_KEEP	=	0x00fe
                           0000FF   290 _WDOG_COUNT	=	0x00ff
                           0000A8   291 _IE	=	0x00a8
                           0000B8   292 _IP	=	0x00b8
                           0000E8   293 _IE_EX	=	0x00e8
                           0000E9   294 _IP_EX	=	0x00e9
                           0000B2   295 _GPIO_IE	=	0x00b2
                           008584   296 _ROM_ADDR	=	0x8584
                           000084   297 _ROM_ADDR_L	=	0x0084
                           000085   298 _ROM_ADDR_H	=	0x0085
                           008F8E   299 _ROM_DATA_HI	=	0x8f8e
                           00008E   300 _ROM_DATA_HL	=	0x008e
                           00008F   301 _ROM_DATA_HH	=	0x008f
                           000086   302 _ROM_CTRL	=	0x0086
                           000080   303 _P0	=	0x0080
                           0000C4   304 _P0_MOD_OC	=	0x00c4
                           0000C5   305 _P0_DIR_PU	=	0x00c5
                           000090   306 _P1	=	0x0090
                           000092   307 _P1_MOD_OC	=	0x0092
                           000093   308 _P1_DIR_PU	=	0x0093
                           0000A0   309 _P2	=	0x00a0
                           000094   310 _P2_MOD_OC	=	0x0094
                           000095   311 _P2_DIR_PU	=	0x0095
                           0000B0   312 _P3	=	0x00b0
                           000096   313 _P3_MOD_OC	=	0x0096
                           000097   314 _P3_DIR_PU	=	0x0097
                           0000C0   315 _P4	=	0x00c0
                           0000C2   316 _P4_MOD_OC	=	0x00c2
                           0000C3   317 _P4_DIR_PU	=	0x00c3
                           0000C1   318 _P4_LED_KEY	=	0x00c1
                           0000AA   319 _P5_IN	=	0x00aa
                           0000AB   320 _P5_OUT_PU	=	0x00ab
                           0000AC   321 _P5_DIR	=	0x00ac
                           0000AD   322 _P6_IN	=	0x00ad
                           0000AE   323 _P6_OUT_PU	=	0x00ae
                           0000AF   324 _P6_DIR	=	0x00af
                           0000F1   325 _P7	=	0x00f1
                           0000A2   326 _XBUS_AUX	=	0x00a2
                           000088   327 _TCON	=	0x0088
                           000089   328 _TMOD	=	0x0089
                           00008A   329 _TL0	=	0x008a
                           00008B   330 _TL1	=	0x008b
                           00008C   331 _TH0	=	0x008c
                           00008D   332 _TH1	=	0x008d
                           000098   333 _SCON	=	0x0098
                           000099   334 _SBUF	=	0x0099
                           0000C8   335 _T2CON	=	0x00c8
                           0000C9   336 _T2MOD	=	0x00c9
                           00CBCA   337 _RCAP2	=	0xcbca
                           0000CA   338 _RCAP2L	=	0x00ca
                           0000CB   339 _RCAP2H	=	0x00cb
                           00CDCC   340 _T2COUNT	=	0xcdcc
                           0000CC   341 _TL2	=	0x00cc
                           0000CD   342 _TH2	=	0x00cd
                           00CFCE   343 _T2CAP1	=	0xcfce
                           0000CE   344 _T2CAP1L	=	0x00ce
                           0000CF   345 _T2CAP1H	=	0x00cf
                           0000F8   346 _SPI0_STAT	=	0x00f8
                           0000F9   347 _SPI0_DATA	=	0x00f9
                           0000FA   348 _SPI0_CTRL	=	0x00fa
                           0000FB   349 _SPI0_CK_SE	=	0x00fb
                           0000FC   350 _SPI0_SETUP	=	0x00fc
                           0000BC   351 _SCON1	=	0x00bc
                           0000BD   352 _SBUF1	=	0x00bd
                           0000BE   353 _SBAUD1	=	0x00be
                           0000BF   354 _SIF1	=	0x00bf
                           0000B4   355 _SPI1_STAT	=	0x00b4
                           0000B5   356 _SPI1_DATA	=	0x00b5
                           0000B6   357 _SPI1_CTRL	=	0x00b6
                           0000B7   358 _SPI1_CK_SE	=	0x00b7
                           0000F3   359 _ADC_CTRL	=	0x00f3
                           00F5F4   360 _ADC_DAT	=	0xf5f4
                           0000F4   361 _ADC_DAT_L	=	0x00f4
                           0000F5   362 _ADC_DAT_H	=	0x00f5
                           0000F6   363 _ADC_CHAN	=	0x00f6
                           0000A6   364 _LED_COMMON	=	0x00a6
                           0000A7   365 _LED_PWM_OE	=	0x00a7
                           00C7C6   366 _LED_DMA	=	0xc7c6
                           0000C6   367 _LED_DMA_L	=	0x00c6
                           0000C7   368 _LED_DMA_H	=	0x00c7
                           0000F7   369 _LED_STATUS	=	0x00f7
                           0000B3   370 _I2CX_INT	=	0x00b3
                           0000BB   371 _I2CS_INT_ST	=	0x00bb
                                    372 ;--------------------------------------------------------
                                    373 ; special function bits
                                    374 ;--------------------------------------------------------
                                    375 	.area RSEG    (ABS,DATA)
      000000                        376 	.org 0x0000
                           0000D7   377 _CY	=	0x00d7
                           0000D6   378 _AC	=	0x00d6
                           0000D5   379 _F0	=	0x00d5
                           0000D4   380 _RS1	=	0x00d4
                           0000D3   381 _RS0	=	0x00d3
                           0000D2   382 _OV	=	0x00d2
                           0000D1   383 _F1	=	0x00d1
                           0000D0   384 _P	=	0x00d0
                           0000AF   385 _EA	=	0x00af
                           0000AE   386 _E_DIS	=	0x00ae
                           0000AD   387 _ET2	=	0x00ad
                           0000AC   388 _ES	=	0x00ac
                           0000AB   389 _ET1	=	0x00ab
                           0000AA   390 _EX1	=	0x00aa
                           0000A9   391 _ET0	=	0x00a9
                           0000A8   392 _EX0	=	0x00a8
                           0000BF   393 _PH_FLAG	=	0x00bf
                           0000BE   394 _PL_FLAG	=	0x00be
                           0000BD   395 _PT2	=	0x00bd
                           0000BC   396 _PS	=	0x00bc
                           0000BB   397 _PT1	=	0x00bb
                           0000BA   398 _PX1	=	0x00ba
                           0000B9   399 _PT0	=	0x00b9
                           0000B8   400 _PX0	=	0x00b8
                           0000EF   401 _IE_WDOG	=	0x00ef
                           0000EE   402 _IE_GPIO	=	0x00ee
                           0000ED   403 _IE_PWM_I2C	=	0x00ed
                           0000EC   404 _IE_UART1	=	0x00ec
                           0000EB   405 _IE_ADC	=	0x00eb
                           0000E9   406 _IE_USB	=	0x00e9
                           0000E8   407 _IE_SPI0	=	0x00e8
                           000087   408 _P0_7	=	0x0087
                           000086   409 _P0_6	=	0x0086
                           000085   410 _P0_5	=	0x0085
                           000084   411 _P0_4	=	0x0084
                           000083   412 _P0_3	=	0x0083
                           000082   413 _P0_2	=	0x0082
                           000081   414 _P0_1	=	0x0081
                           000080   415 _P0_0	=	0x0080
                           000081   416 _SDA0	=	0x0081
                           000080   417 _SCL0	=	0x0080
                           000083   418 _TXD_	=	0x0083
                           000082   419 _RXD_	=	0x0082
                           000085   420 _AIN13	=	0x0085
                           000084   421 _AIN12	=	0x0084
                           000083   422 _AIN11	=	0x0083
                           000082   423 _AIN10	=	0x0082
                           000081   424 _AIN9	=	0x0081
                           000080   425 _AIN8	=	0x0080
                           000097   426 _P1_7	=	0x0097
                           000096   427 _P1_6	=	0x0096
                           000095   428 _P1_5	=	0x0095
                           000094   429 _P1_4	=	0x0094
                           000093   430 _P1_3	=	0x0093
                           000092   431 _P1_2	=	0x0092
                           000091   432 _P1_1	=	0x0091
                           000090   433 _P1_0	=	0x0090
                           000097   434 _TXD1_	=	0x0097
                           000096   435 _RXD1_	=	0x0096
                           000097   436 _SCK	=	0x0097
                           000096   437 _MISO	=	0x0096
                           000095   438 _MOSI	=	0x0095
                           000094   439 _SCS	=	0x0094
                           000092   440 _INT0_	=	0x0092
                           000091   441 _T2EX	=	0x0091
                           000091   442 _CAP2	=	0x0091
                           000090   443 _T2	=	0x0090
                           000090   444 _CAP1	=	0x0090
                           000097   445 _AIN7	=	0x0097
                           000096   446 _AIN6	=	0x0096
                           000095   447 _AIN5	=	0x0095
                           000094   448 _AIN4	=	0x0094
                           000093   449 _AIN3	=	0x0093
                           000092   450 _AIN2	=	0x0092
                           000091   451 _AIN1	=	0x0091
                           000090   452 _AIN0	=	0x0090
                           0000A7   453 _P2_7	=	0x00a7
                           0000A6   454 _P2_6	=	0x00a6
                           0000A5   455 _P2_5	=	0x00a5
                           0000A4   456 _P2_4	=	0x00a4
                           0000A3   457 _P2_3	=	0x00a3
                           0000A2   458 _P2_2	=	0x00a2
                           0000A1   459 _P2_1	=	0x00a1
                           0000A0   460 _P2_0	=	0x00a0
                           0000A7   461 _TXD1	=	0x00a7
                           0000A6   462 _RXD1	=	0x00a6
                           0000A5   463 _T2EX_	=	0x00a5
                           0000A5   464 _CAP2_	=	0x00a5
                           0000A4   465 _T2_	=	0x00a4
                           0000A4   466 _CAP1_	=	0x00a4
                           0000B7   467 _P3_7	=	0x00b7
                           0000B6   468 _P3_6	=	0x00b6
                           0000B5   469 _P3_5	=	0x00b5
                           0000B4   470 _P3_4	=	0x00b4
                           0000B3   471 _P3_3	=	0x00b3
                           0000B2   472 _P3_2	=	0x00b2
                           0000B1   473 _P3_1	=	0x00b1
                           0000B0   474 _P3_0	=	0x00b0
                           0000B7   475 _SCK1	=	0x00b7
                           0000B6   476 _MISO1	=	0x00b6
                           0000B5   477 _MOSI1	=	0x00b5
                           0000B5   478 _T1	=	0x00b5
                           0000B4   479 _T0	=	0x00b4
                           0000B3   480 _INT1	=	0x00b3
                           0000B2   481 _INT0	=	0x00b2
                           0000B1   482 _TXD	=	0x00b1
                           0000B0   483 _RXD	=	0x00b0
                           0000C6   484 _P4_6	=	0x00c6
                           0000C5   485 _P4_5	=	0x00c5
                           0000C4   486 _P4_4	=	0x00c4
                           0000C3   487 _P4_3	=	0x00c3
                           0000C2   488 _P4_2	=	0x00c2
                           0000C1   489 _P4_1	=	0x00c1
                           0000C0   490 _P4_0	=	0x00c0
                           00008F   491 _TF1	=	0x008f
                           00008E   492 _TR1	=	0x008e
                           00008D   493 _TF0	=	0x008d
                           00008C   494 _TR0	=	0x008c
                           00008B   495 _IE1	=	0x008b
                           00008A   496 _IT1	=	0x008a
                           000089   497 _IE0	=	0x0089
                           000088   498 _IT0	=	0x0088
                           00009F   499 _SM0	=	0x009f
                           00009E   500 _SM1	=	0x009e
                           00009D   501 _SM2	=	0x009d
                           00009C   502 _REN	=	0x009c
                           00009B   503 _TB8	=	0x009b
                           00009A   504 _RB8	=	0x009a
                           000099   505 _TI	=	0x0099
                           000098   506 _RI	=	0x0098
                           0000CF   507 _TF2	=	0x00cf
                           0000CF   508 _CAP1F	=	0x00cf
                           0000CE   509 _EXF2	=	0x00ce
                           0000CD   510 _RCLK	=	0x00cd
                           0000CC   511 _TCLK	=	0x00cc
                           0000CB   512 _EXEN2	=	0x00cb
                           0000CA   513 _TR2	=	0x00ca
                           0000C9   514 _C_T2	=	0x00c9
                           0000C8   515 _CP_RL2	=	0x00c8
                           0000FF   516 _S0_FST_ACT	=	0x00ff
                           0000FE   517 _S0_IF_OV	=	0x00fe
                           0000FD   518 _S0_IF_FIRST	=	0x00fd
                           0000FC   519 _S0_IF_BYTE	=	0x00fc
                           0000FB   520 _S0_FREE	=	0x00fb
                           0000FA   521 _S0_T_FIFO	=	0x00fa
                           0000F8   522 _S0_R_FIFO	=	0x00f8
                           0000F7   523 _ADC_START	=	0x00f7
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable register banks
                                    526 ;--------------------------------------------------------
                                    527 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        528 	.ds 8
                                    529 ;--------------------------------------------------------
                                    530 ; internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area DSEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; overlayable items in internal ram
                                    535 ;--------------------------------------------------------
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
      000474                        557 _dm_taps:
      000474                        558 	.ds 64
      0004B4                        559 _dm_lengths:
      0004B4                        560 	.ds 2
      0004B6                        561 _dm_record:
      0004B6                        562 	.ds 1
      0004B7                        563 _dm_play:
      0004B7                        564 	.ds 1
      0004B8                        565 _dm_index:
      0004B8                        566 	.ds 1
      0004B9                        567 _dm_down:
      0004B9                        568 	.ds 1
      0004BA                        569 _dm_mods:
      0004BA                        570 	.ds 1
      0004BB                        571 _dm_time:
      0004BB                        572 	.ds 2
      0004BD                        573 _ak820_dynamic_macro_source::
      0004BD                        574 	.ds 1
      0004BE                        575 _ak820_dynamic_macro_process_PARM_2:
      0004BE                        576 	.ds 1
      0004BF                        577 _ak820_dynamic_macro_process_code_10000_602:
      0004BF                        578 	.ds 2
      0004C1                        579 _ak820_dynamic_macro_observe_PARM_2:
      0004C1                        580 	.ds 1
      0004C2                        581 _ak820_dynamic_macro_observe_code_10000_611:
      0004C2                        582 	.ds 1
      0004C3                        583 _ak820_dynamic_macro_observe_slot_10001_614:
      0004C3                        584 	.ds 1
      0004C4                        585 _ak820_dynamic_macro_observe_base_10001_614:
      0004C4                        586 	.ds 1
      0004C5                        587 _ak820_dynamic_macro_observe_i_30001_616:
      0004C5                        588 	.ds 1
      0004C6                        589 _ak820_dynamic_macro_task_now_10000_623:
      0004C6                        590 	.ds 2
      0004C8                        591 _ak820_dynamic_macro_task_i_40000_630:
      0004C8                        592 	.ds 1
      0004C9                        593 _ak820_dynamic_macro_task_code_40000_630:
      0004C9                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; absolute external ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area XABS    (ABS,XDATA)
                                    599 ;--------------------------------------------------------
                                    600 ; initialized external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XISEG   (XDATA)
                                    603 	.area HOME    (CODE)
                                    604 	.area GSINIT0 (CODE)
                                    605 	.area GSINIT1 (CODE)
                                    606 	.area GSINIT2 (CODE)
                                    607 	.area GSINIT3 (CODE)
                                    608 	.area GSINIT4 (CODE)
                                    609 	.area GSINIT5 (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 	.area GSFINAL (CODE)
                                    612 	.area CSEG    (CODE)
                                    613 ;--------------------------------------------------------
                                    614 ; global & static initialisations
                                    615 ;--------------------------------------------------------
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area GSINIT  (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; Home
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area HOME    (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; code
                                    627 ;--------------------------------------------------------
                                    628 	.area CSEG    (CODE)
                                    629 ;------------------------------------------------------------
                                    630 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    631 ;------------------------------------------------------------
                                    632 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    633 ;------------------------------------------------------------
                                    634 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    635 ;	-----------------------------------------
                           000007   636 	ar7 = 0x07
                           000006   637 	ar6 = 0x06
                           000005   638 	ar5 = 0x05
                           000004   639 	ar4 = 0x04
                           000003   640 	ar3 = 0x03
                           000002   641 	ar2 = 0x02
                           000001   642 	ar1 = 0x01
                           000000   643 	ar0 = 0x00
                                    644 ;	 function dm_finish
                                    645 ;	-----------------------------------------
      003B0B                        646 _dm_finish:
                                    647 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:17: if (dm_record) {
      003B0B 90 04 B6         [24]  648 	mov	dptr,#_dm_record
      003B0E E0               [24]  649 	movx	a,@dptr
      003B0F FF               [12]  650 	mov	r7,a
      003B10 E0               [24]  651 	movx	a,@dptr
      003B11 70 01            [24]  652 	jnz	00140$
      003B13 22               [24]  653 	ret
      003B14                        654 00140$:
                                    655 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:18: uint8_t slot = dm_record - 1, base = slot * 16, out = 0;
      003B14 1F               [12]  656 	dec	r7
      003B15 EF               [12]  657 	mov	a,r7
      003B16 C4               [12]  658 	swap	a
      003B17 54 F0            [12]  659 	anl	a,#0xf0
      003B19 FE               [12]  660 	mov	r6,a
                                    661 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003B1A EF               [12]  662 	mov	a,r7
      003B1B 24 B4            [12]  663 	add	a, #_dm_lengths
      003B1D FD               [12]  664 	mov	r5,a
      003B1E E4               [12]  665 	clr	a
      003B1F 34 04            [12]  666 	addc	a, #(_dm_lengths >> 8)
      003B21 FF               [12]  667 	mov	r7,a
      003B22 7C 00            [12]  668 	mov	r4,#0x00
      003B24 7B 00            [12]  669 	mov	r3,#0x00
      003B26                        670 00107$:
      003B26 8D 82            [24]  671 	mov	dpl,r5
      003B28 8F 83            [24]  672 	mov	dph,r7
      003B2A E0               [24]  673 	movx	a,@dptr
      003B2B FA               [12]  674 	mov	r2,a
      003B2C C3               [12]  675 	clr	c
      003B2D EB               [12]  676 	mov	a,r3
      003B2E 9A               [12]  677 	subb	a,r2
      003B2F 50 6F            [24]  678 	jnc	00103$
                                    679 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:20: if (!(dm_taps[base + i].code & 0x80)) {
      003B31 EB               [12]  680 	mov	a,r3
      003B32 2E               [12]  681 	add	a, r6
      003B33 75 F0 02         [24]  682 	mov	b,#0x02
      003B36 A4               [48]  683 	mul	ab
      003B37 24 74            [12]  684 	add	a, #_dm_taps
      003B39 F5 82            [12]  685 	mov	dpl,a
      003B3B 74 04            [12]  686 	mov	a,#(_dm_taps >> 8)
      003B3D 35 F0            [12]  687 	addc	a, b
      003B3F F5 83            [12]  688 	mov	dph,a
      003B41 E0               [24]  689 	movx	a,@dptr
      003B42 20 E7 58         [24]  690 	jb	acc.7,00108$
                                    691 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:21: dm_taps[base + out] = dm_taps[base + i];
      003B45 C0 05            [24]  692 	push	ar5
      003B47 C0 07            [24]  693 	push	ar7
      003B49 EC               [12]  694 	mov	a,r4
      003B4A 2E               [12]  695 	add	a, r6
      003B4B 75 F0 02         [24]  696 	mov	b,#0x02
      003B4E A4               [48]  697 	mul	ab
      003B4F 24 74            [12]  698 	add	a, #_dm_taps
      003B51 F9               [12]  699 	mov	r1,a
      003B52 74 04            [12]  700 	mov	a,#(_dm_taps >> 8)
      003B54 35 F0            [12]  701 	addc	a, b
      003B56 F8               [12]  702 	mov	r0,a
      003B57 7A 00            [12]  703 	mov	r2,#0x00
      003B59 EB               [12]  704 	mov	a,r3
      003B5A 2E               [12]  705 	add	a, r6
      003B5B 75 F0 02         [24]  706 	mov	b,#0x02
      003B5E A4               [48]  707 	mul	ab
      003B5F 24 74            [12]  708 	add	a, #_dm_taps
      003B61 FD               [12]  709 	mov	r5,a
      003B62 74 04            [12]  710 	mov	a,#(_dm_taps >> 8)
      003B64 35 F0            [12]  711 	addc	a, b
      003B66 FF               [12]  712 	mov	r7,a
      003B67 90 0E 0A         [24]  713 	mov	dptr,#___memcpy_PARM_2
      003B6A ED               [12]  714 	mov	a,r5
      003B6B F0               [24]  715 	movx	@dptr,a
      003B6C EF               [12]  716 	mov	a,r7
      003B6D A3               [24]  717 	inc	dptr
      003B6E F0               [24]  718 	movx	@dptr,a
      003B6F E4               [12]  719 	clr	a
      003B70 A3               [24]  720 	inc	dptr
      003B71 F0               [24]  721 	movx	@dptr,a
      003B72 90 0E 0D         [24]  722 	mov	dptr,#___memcpy_PARM_3
      003B75 74 02            [12]  723 	mov	a,#0x02
      003B77 F0               [24]  724 	movx	@dptr,a
      003B78 E4               [12]  725 	clr	a
      003B79 A3               [24]  726 	inc	dptr
      003B7A F0               [24]  727 	movx	@dptr,a
      003B7B 89 82            [24]  728 	mov	dpl, r1
      003B7D 88 83            [24]  729 	mov	dph, r0
      003B7F 8A F0            [24]  730 	mov	b, r2
      003B81 C0 07            [24]  731 	push	ar7
      003B83 C0 06            [24]  732 	push	ar6
      003B85 C0 05            [24]  733 	push	ar5
      003B87 C0 04            [24]  734 	push	ar4
      003B89 C0 03            [24]  735 	push	ar3
      003B8B 12 BD B2         [24]  736 	lcall	___memcpy
      003B8E D0 03            [24]  737 	pop	ar3
      003B90 D0 04            [24]  738 	pop	ar4
      003B92 D0 05            [24]  739 	pop	ar5
      003B94 D0 06            [24]  740 	pop	ar6
      003B96 D0 07            [24]  741 	pop	ar7
                                    742 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003B98 0C               [12]  743 	inc	r4
                                    744 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003B99 D0 07            [24]  745 	pop	ar7
      003B9B D0 05            [24]  746 	pop	ar5
                                    747 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003B9D                        748 00108$:
                                    749 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003B9D 0B               [12]  750 	inc	r3
      003B9E 80 86            [24]  751 	sjmp	00107$
      003BA0                        752 00103$:
                                    753 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:25: dm_lengths[slot] = out;
      003BA0 8D 82            [24]  754 	mov	dpl,r5
      003BA2 8F 83            [24]  755 	mov	dph,r7
      003BA4 EC               [12]  756 	mov	a,r4
      003BA5 F0               [24]  757 	movx	@dptr,a
                                    758 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003BA6 90 04 B6         [24]  759 	mov	dptr,#_dm_record
      003BA9 E4               [12]  760 	clr	a
      003BAA F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:28: }
      003BAB 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'ak820_dynamic_macro_cancel'
                                    766 ;------------------------------------------------------------
                                    767 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:29: void ak820_dynamic_macro_cancel(void) {
                                    768 ;	-----------------------------------------
                                    769 ;	 function ak820_dynamic_macro_cancel
                                    770 ;	-----------------------------------------
      003BAC                        771 _ak820_dynamic_macro_cancel:
                                    772 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_finish();
      003BAC 12 3B 0B         [24]  773 	lcall	_dm_finish
                                    774 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:33: dm_play = dm_down = 0;
      003BAF 90 04 B9         [24]  775 	mov	dptr,#_dm_down
      003BB2 E4               [12]  776 	clr	a
      003BB3 F0               [24]  777 	movx	@dptr,a
      003BB4 90 04 B7         [24]  778 	mov	dptr,#_dm_play
      003BB7 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:34: ak820_dynamic_macro_source = false;
      003BB8 90 04 BD         [24]  781 	mov	dptr,#_ak820_dynamic_macro_source
      003BBB F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:35: }
      003BBC 22               [24]  784 	ret
                                    785 ;------------------------------------------------------------
                                    786 ;Allocation info for local variables in function 'ak820_dynamic_macro_process'
                                    787 ;------------------------------------------------------------
                                    788 ;pressed       Allocated with name '_ak820_dynamic_macro_process_PARM_2'
                                    789 ;code          Allocated with name '_ak820_dynamic_macro_process_code_10000_602'
                                    790 ;------------------------------------------------------------
                                    791 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:36: bool ak820_dynamic_macro_process(uint16_t code, bool pressed) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function ak820_dynamic_macro_process
                                    794 ;	-----------------------------------------
      003BBD                        795 _ak820_dynamic_macro_process:
      003BBD AF 83            [24]  796 	mov	r7,dph
      003BBF E5 82            [12]  797 	mov	a,dpl
      003BC1 90 04 BF         [24]  798 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003BC4 F0               [24]  799 	movx	@dptr,a
      003BC5 EF               [12]  800 	mov	a,r7
      003BC6 A3               [24]  801 	inc	dptr
      003BC7 F0               [24]  802 	movx	@dptr,a
                                    803 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:37: if (code < QK_DYNAMIC_MACRO_RECORD_START_1 || code > QK_DYNAMIC_MACRO_PLAY_2) return true;
      003BC8 90 04 BF         [24]  804 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003BCB E0               [24]  805 	movx	a,@dptr
      003BCC FE               [12]  806 	mov	r6,a
      003BCD A3               [24]  807 	inc	dptr
      003BCE E0               [24]  808 	movx	a,@dptr
      003BCF FF               [12]  809 	mov	r7,a
      003BD0 8E 04            [24]  810 	mov	ar4,r6
      003BD2 8F 05            [24]  811 	mov	ar5,r7
      003BD4 C3               [12]  812 	clr	c
      003BD5 EC               [12]  813 	mov	a,r4
      003BD6 94 53            [12]  814 	subb	a,#0x53
      003BD8 ED               [12]  815 	mov	a,r5
      003BD9 94 7C            [12]  816 	subb	a,#0x7c
      003BDB 40 08            [24]  817 	jc	00101$
      003BDD 74 57            [12]  818 	mov	a,#0x57
      003BDF 9C               [12]  819 	subb	a,r4
      003BE0 74 7C            [12]  820 	mov	a,#0x7c
      003BE2 9D               [12]  821 	subb	a,r5
      003BE3 50 04            [24]  822 	jnc	00102$
                                    823 ;	free result
      003BE5                        824 00101$:
      003BE5 75 82 01         [24]  825 	mov	dpl, #0x01
      003BE8 22               [24]  826 	ret
      003BE9                        827 00102$:
                                    828 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:38: if (!pressed || get_repeat_key_count()) return false;
      003BE9 90 04 BE         [24]  829 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      003BEC E0               [24]  830 	movx	a,@dptr
      003BED 60 17            [24]  831 	jz	00104$
      003BEF C0 07            [24]  832 	push	ar7
      003BF1 C0 06            [24]  833 	push	ar6
      003BF3 C0 05            [24]  834 	push	ar5
      003BF5 C0 04            [24]  835 	push	ar4
      003BF7 12 A7 C2         [24]  836 	lcall	_get_repeat_key_count
      003BFA E5 82            [12]  837 	mov	a, dpl
      003BFC D0 04            [24]  838 	pop	ar4
      003BFE D0 05            [24]  839 	pop	ar5
      003C00 D0 06            [24]  840 	pop	ar6
      003C02 D0 07            [24]  841 	pop	ar7
      003C04 60 04            [24]  842 	jz	00105$
      003C06                        843 00104$:
      003C06 75 82 00         [24]  844 	mov	dpl, #0x00
      003C09 22               [24]  845 	ret
      003C0A                        846 00105$:
                                    847 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:41: if (dm_play) return false;
      003C0A 90 04 B7         [24]  848 	mov	dptr,#_dm_play
      003C0D E0               [24]  849 	movx	a,@dptr
      003C0E 60 04            [24]  850 	jz	00108$
      003C10 75 82 00         [24]  851 	mov	dpl, #0x00
      003C13 22               [24]  852 	ret
      003C14                        853 00108$:
                                    854 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:42: dm_finish();
      003C14 C0 07            [24]  855 	push	ar7
      003C16 C0 06            [24]  856 	push	ar6
      003C18 C0 05            [24]  857 	push	ar5
      003C1A C0 04            [24]  858 	push	ar4
      003C1C 12 3B 0B         [24]  859 	lcall	_dm_finish
      003C1F D0 04            [24]  860 	pop	ar4
      003C21 D0 05            [24]  861 	pop	ar5
      003C23 D0 06            [24]  862 	pop	ar6
      003C25 D0 07            [24]  863 	pop	ar7
                                    864 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:43: if (code <= QK_DYNAMIC_MACRO_RECORD_START_2) {
      003C27 C3               [12]  865 	clr	c
      003C28 74 54            [12]  866 	mov	a,#0x54
      003C2A 9C               [12]  867 	subb	a,r4
      003C2B 74 7C            [12]  868 	mov	a,#0x7c
      003C2D 9D               [12]  869 	subb	a,r5
      003C2E 40 1E            [24]  870 	jc	00112$
                                    871 ;	free result
                                    872 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:44: dm_record = code - QK_DYNAMIC_MACRO_RECORD_START_1 + 1;
      003C30 8E 03            [24]  873 	mov	ar3,r6
      003C32 74 AE            [12]  874 	mov	a,#0xae
      003C34 2B               [12]  875 	add	a, r3
      003C35 FB               [12]  876 	mov	r3,a
      003C36 90 04 B6         [24]  877 	mov	dptr,#_dm_record
      003C39 F0               [24]  878 	movx	@dptr,a
                                    879 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:45: dm_lengths[dm_record - 1] = 0;
      003C3A 1B               [12]  880 	dec	r3
      003C3B EB               [12]  881 	mov	a,r3
      003C3C 33               [12]  882 	rlc	a
      003C3D 95 E0            [12]  883 	subb	a,acc
      003C3F FA               [12]  884 	mov	r2,a
      003C40 EB               [12]  885 	mov	a,r3
      003C41 24 B4            [12]  886 	add	a, #_dm_lengths
      003C43 F5 82            [12]  887 	mov	dpl,a
      003C45 EA               [12]  888 	mov	a,r2
      003C46 34 04            [12]  889 	addc	a, #(_dm_lengths >> 8)
      003C48 F5 83            [12]  890 	mov	dph,a
      003C4A E4               [12]  891 	clr	a
      003C4B F0               [24]  892 	movx	@dptr,a
      003C4C 80 29            [24]  893 	sjmp	00113$
      003C4E                        894 00112$:
                                    895 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:46: } else if (code >= QK_DYNAMIC_MACRO_PLAY_1) {
      003C4E C3               [12]  896 	clr	c
      003C4F EC               [12]  897 	mov	a,r4
      003C50 94 56            [12]  898 	subb	a,#0x56
      003C52 ED               [12]  899 	mov	a,r5
      003C53 94 7C            [12]  900 	subb	a,#0x7c
      003C55 40 20            [24]  901 	jc	00113$
                                    902 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:47: dm_play = code - QK_DYNAMIC_MACRO_PLAY_1 + 1;
      003C57 90 04 B7         [24]  903 	mov	dptr,#_dm_play
      003C5A 74 AB            [12]  904 	mov	a,#0xab
      003C5C 2E               [12]  905 	add	a, r6
      003C5D F0               [24]  906 	movx	@dptr,a
                                    907 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:48: dm_index = dm_down = 0;
      003C5E 90 04 B9         [24]  908 	mov	dptr,#_dm_down
      003C61 E4               [12]  909 	clr	a
      003C62 F0               [24]  910 	movx	@dptr,a
      003C63 90 04 B8         [24]  911 	mov	dptr,#_dm_index
      003C66 F0               [24]  912 	movx	@dptr,a
                                    913 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:49: dm_time = timer_read();
      003C67 12 4E B5         [24]  914 	lcall	_timer_read
      003C6A E5 82            [12]  915 	mov	a, dpl
      003C6C 85 83 F0         [24]  916 	mov	b, dph
      003C6F 90 04 BB         [24]  917 	mov	dptr,#_dm_time
      003C72 F0               [24]  918 	movx	@dptr,a
      003C73 E5 F0            [12]  919 	mov	a,b
      003C75 A3               [24]  920 	inc	dptr
      003C76 F0               [24]  921 	movx	@dptr,a
      003C77                        922 00113$:
                                    923 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:51: return false;
      003C77 75 82 00         [24]  924 	mov	dpl, #0x00
                                    925 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:52: }
      003C7A 22               [24]  926 	ret
                                    927 ;------------------------------------------------------------
                                    928 ;Allocation info for local variables in function 'ak820_dynamic_macro_observe'
                                    929 ;------------------------------------------------------------
                                    930 ;pressed       Allocated with name '_ak820_dynamic_macro_observe_PARM_2'
                                    931 ;code          Allocated with name '_ak820_dynamic_macro_observe_code_10000_611'
                                    932 ;slot          Allocated with name '_ak820_dynamic_macro_observe_slot_10001_614'
                                    933 ;base          Allocated with name '_ak820_dynamic_macro_observe_base_10001_614'
                                    934 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_30001_616'
                                    935 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_40001_619'
                                    936 ;------------------------------------------------------------
                                    937 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:53: void ak820_dynamic_macro_observe(uint8_t code, bool pressed) {
                                    938 ;	-----------------------------------------
                                    939 ;	 function ak820_dynamic_macro_observe
                                    940 ;	-----------------------------------------
      003C7B                        941 _ak820_dynamic_macro_observe:
      003C7B E5 82            [12]  942 	mov	a,dpl
      003C7D 90 04 C2         [24]  943 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003C80 F0               [24]  944 	movx	@dptr,a
                                    945 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:54: if (!dm_record || !ak820_dynamic_macro_source || code < KC_A || code >= 0x80) return;
      003C81 90 04 B6         [24]  946 	mov	dptr,#_dm_record
      003C84 E0               [24]  947 	movx	a,@dptr
      003C85 FF               [12]  948 	mov	r7,a
      003C86 E0               [24]  949 	movx	a,@dptr
      003C87 60 15            [24]  950 	jz	00101$
      003C89 90 04 BD         [24]  951 	mov	dptr,#_ak820_dynamic_macro_source
      003C8C E0               [24]  952 	movx	a,@dptr
      003C8D 60 0F            [24]  953 	jz	00101$
      003C8F 90 04 C2         [24]  954 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003C92 E0               [24]  955 	movx	a,@dptr
      003C93 FE               [12]  956 	mov	r6,a
      003C94 BE 04 00         [24]  957 	cjne	r6,#0x04,00177$
      003C97                        958 00177$:
      003C97 40 05            [24]  959 	jc	00101$
      003C99 BE 80 00         [24]  960 	cjne	r6,#0x80,00179$
      003C9C                        961 00179$:
      003C9C 40 01            [24]  962 	jc	00102$
      003C9E                        963 00101$:
      003C9E 22               [24]  964 	ret
      003C9F                        965 00102$:
                                    966 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:55: uint8_t slot = dm_record - 1, base = slot * 16;
      003C9F 1F               [12]  967 	dec	r7
      003CA0 90 04 C3         [24]  968 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003CA3 EF               [12]  969 	mov	a,r7
      003CA4 F0               [24]  970 	movx	@dptr,a
      003CA5 EF               [12]  971 	mov	a,r7
      003CA6 C4               [12]  972 	swap	a
      003CA7 54 F0            [12]  973 	anl	a,#0xf0
      003CA9 FD               [12]  974 	mov	r5,a
      003CAA 90 04 C4         [24]  975 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003CAD F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:56: if (pressed) {
      003CAE 90 04 C1         [24]  978 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      003CB1 E0               [24]  979 	movx	a,@dptr
      003CB2 60 67            [24]  980 	jz	00134$
                                    981 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:57: uint8_t i = dm_lengths[slot];
      003CB4 EF               [12]  982 	mov	a,r7
      003CB5 24 B4            [12]  983 	add	a, #_dm_lengths
      003CB7 F5 82            [12]  984 	mov	dpl,a
      003CB9 E4               [12]  985 	clr	a
      003CBA 34 04            [12]  986 	addc	a, #(_dm_lengths >> 8)
      003CBC F5 83            [12]  987 	mov	dph,a
      003CBE E0               [24]  988 	movx	a,@dptr
      003CBF FC               [12]  989 	mov	r4,a
      003CC0 90 04 C5         [24]  990 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003CC3 F0               [24]  991 	movx	@dptr,a
                                    992 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:58: if (i == 16) return; /* Full: retain first 16; still accept releases. */
      003CC4 BC 10 01         [24]  993 	cjne	r4,#0x10,00107$
      003CC7 22               [24]  994 	ret
      003CC8                        995 00107$:
                                    996 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:59: dm_taps[base + i].code = code | 0x80;
      003CC8 EC               [12]  997 	mov	a,r4
      003CC9 2D               [12]  998 	add	a, r5
      003CCA 75 F0 02         [24]  999 	mov	b,#0x02
      003CCD A4               [48] 1000 	mul	ab
      003CCE 24 74            [12] 1001 	add	a, #_dm_taps
      003CD0 F5 82            [12] 1002 	mov	dpl,a
      003CD2 74 04            [12] 1003 	mov	a,#(_dm_taps >> 8)
      003CD4 35 F0            [12] 1004 	addc	a, b
      003CD6 F5 83            [12] 1005 	mov	dph,a
      003CD8 43 06 80         [24] 1006 	orl	ar6,#0x80
      003CDB EE               [12] 1007 	mov	a,r6
      003CDC F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:60: dm_taps[base + i].mods = get_mods() | get_weak_mods();
      003CDD 90 04 C5         [24] 1010 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003CE0 E0               [24] 1011 	movx	a,@dptr
      003CE1 FE               [12] 1012 	mov	r6,a
      003CE2 90 04 C4         [24] 1013 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003CE5 E0               [24] 1014 	movx	a,@dptr
      003CE6 2E               [12] 1015 	add	a, r6
      003CE7 75 F0 02         [24] 1016 	mov	b,#0x02
      003CEA A4               [48] 1017 	mul	ab
      003CEB 24 74            [12] 1018 	add	a, #_dm_taps
      003CED FB               [12] 1019 	mov	r3,a
      003CEE 74 04            [12] 1020 	mov	a,#(_dm_taps >> 8)
      003CF0 35 F0            [12] 1021 	addc	a, b
      003CF2 FC               [12] 1022 	mov	r4,a
      003CF3 0B               [12] 1023 	inc	r3
      003CF4 BB 00 01         [24] 1024 	cjne	r3,#0x00,00184$
      003CF7 0C               [12] 1025 	inc	r4
      003CF8                       1026 00184$:
      003CF8 12 86 D0         [24] 1027 	lcall	_get_mods
      003CFB AA 82            [24] 1028 	mov	r2, dpl
      003CFD 12 86 E6         [24] 1029 	lcall	_get_weak_mods
      003D00 E5 82            [12] 1030 	mov	a,dpl
      003D02 42 02            [12] 1031 	orl	ar2,a
      003D04 8B 82            [24] 1032 	mov	dpl,r3
      003D06 8C 83            [24] 1033 	mov	dph,r4
      003D08 EA               [12] 1034 	mov	a,r2
      003D09 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:61: dm_lengths[slot] = i + 1;
      003D0A 90 04 C3         [24] 1037 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003D0D E0               [24] 1038 	movx	a,@dptr
      003D0E 24 B4            [12] 1039 	add	a, #_dm_lengths
      003D10 F5 82            [12] 1040 	mov	dpl,a
      003D12 E4               [12] 1041 	clr	a
      003D13 34 04            [12] 1042 	addc	a, #(_dm_lengths >> 8)
      003D15 F5 83            [12] 1043 	mov	dph,a
      003D17 0E               [12] 1044 	inc	r6
      003D18 EE               [12] 1045 	mov	a,r6
      003D19 F0               [24] 1046 	movx	@dptr,a
                                   1047 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003D1A 22               [24] 1048 	ret
      003D1B                       1049 00134$:
      003D1B EF               [12] 1050 	mov	a,r7
      003D1C 24 B4            [12] 1051 	add	a, #_dm_lengths
      003D1E FE               [12] 1052 	mov	r6,a
      003D1F E4               [12] 1053 	clr	a
      003D20 34 04            [12] 1054 	addc	a, #(_dm_lengths >> 8)
      003D22 FF               [12] 1055 	mov	r7,a
      003D23 7C 00            [12] 1056 	mov	r4,#0x00
      003D25                       1057 00115$:
      003D25 8E 82            [24] 1058 	mov	dpl,r6
      003D27 8F 83            [24] 1059 	mov	dph,r7
      003D29 E0               [24] 1060 	movx	a,@dptr
      003D2A FB               [12] 1061 	mov	r3,a
      003D2B C3               [12] 1062 	clr	c
      003D2C EC               [12] 1063 	mov	a,r4
      003D2D 9B               [12] 1064 	subb	a,r3
      003D2E 50 35            [24] 1065 	jnc	00117$
                                   1066 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:64: if (dm_taps[base + i].code == (uint8_t)(code | 0x80)) {
      003D30 EC               [12] 1067 	mov	a,r4
      003D31 2D               [12] 1068 	add	a, r5
      003D32 75 F0 02         [24] 1069 	mov	b,#0x02
      003D35 A4               [48] 1070 	mul	ab
      003D36 24 74            [12] 1071 	add	a, #_dm_taps
      003D38 F5 82            [12] 1072 	mov	dpl,a
      003D3A 74 04            [12] 1073 	mov	a,#(_dm_taps >> 8)
      003D3C 35 F0            [12] 1074 	addc	a, b
      003D3E F5 83            [12] 1075 	mov	dph,a
      003D40 E0               [24] 1076 	movx	a,@dptr
      003D41 FB               [12] 1077 	mov	r3,a
      003D42 90 04 C2         [24] 1078 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003D45 E0               [24] 1079 	movx	a,@dptr
      003D46 FA               [12] 1080 	mov	r2,a
      003D47 74 80            [12] 1081 	mov	a,#0x80
      003D49 4A               [12] 1082 	orl	a,r2
      003D4A F9               [12] 1083 	mov	r1,a
      003D4B EB               [12] 1084 	mov	a,r3
      003D4C B5 01 13         [24] 1085 	cjne	a,ar1,00116$
                                   1086 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:65: dm_taps[base + i].code = code;
      003D4F EC               [12] 1087 	mov	a,r4
      003D50 2D               [12] 1088 	add	a, r5
      003D51 75 F0 02         [24] 1089 	mov	b,#0x02
      003D54 A4               [48] 1090 	mul	ab
      003D55 24 74            [12] 1091 	add	a, #_dm_taps
      003D57 F5 82            [12] 1092 	mov	dpl,a
      003D59 74 04            [12] 1093 	mov	a,#(_dm_taps >> 8)
      003D5B 35 F0            [12] 1094 	addc	a, b
      003D5D F5 83            [12] 1095 	mov	dph,a
      003D5F EA               [12] 1096 	mov	a,r2
      003D60 F0               [24] 1097 	movx	@dptr,a
                                   1098 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:66: break;
      003D61 22               [24] 1099 	ret
      003D62                       1100 00116$:
                                   1101 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003D62 0C               [12] 1102 	inc	r4
      003D63 80 C0            [24] 1103 	sjmp	00115$
      003D65                       1104 00117$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:70: }
      003D65 22               [24] 1106 	ret
                                   1107 ;------------------------------------------------------------
                                   1108 ;Allocation info for local variables in function 'ak820_dynamic_macro_task'
                                   1109 ;------------------------------------------------------------
                                   1110 ;now           Allocated with name '_ak820_dynamic_macro_task_now_10000_623'
                                   1111 ;i             Allocated with name '_ak820_dynamic_macro_task_i_40000_630'
                                   1112 ;code          Allocated with name '_ak820_dynamic_macro_task_code_40000_630'
                                   1113 ;------------------------------------------------------------
                                   1114 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:71: void ak820_dynamic_macro_task(uint16_t now) {
                                   1115 ;	-----------------------------------------
                                   1116 ;	 function ak820_dynamic_macro_task
                                   1117 ;	-----------------------------------------
      003D66                       1118 _ak820_dynamic_macro_task:
      003D66 AF 83            [24] 1119 	mov	r7,dph
      003D68 E5 82            [12] 1120 	mov	a,dpl
      003D6A 90 04 C6         [24] 1121 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003D6D F0               [24] 1122 	movx	@dptr,a
      003D6E EF               [12] 1123 	mov	a,r7
      003D6F A3               [24] 1124 	inc	dptr
      003D70 F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:72: if (!dm_play || ak820_macro_primitive || ak820_keyboard_report_pending() || (uint16_t)(now - dm_time) < 10) return;
      003D71 90 04 B7         [24] 1127 	mov	dptr,#_dm_play
      003D74 E0               [24] 1128 	movx	a,@dptr
      003D75 60 2D            [24] 1129 	jz	00101$
      003D77 90 09 F0         [24] 1130 	mov	dptr,#_ak820_macro_primitive
      003D7A E0               [24] 1131 	movx	a,@dptr
      003D7B 70 27            [24] 1132 	jnz	00101$
      003D7D 12 4F 1D         [24] 1133 	lcall	_ak820_keyboard_report_pending
      003D80 E5 82            [12] 1134 	mov	a, dpl
      003D82 70 20            [24] 1135 	jnz	00101$
      003D84 90 04 BB         [24] 1136 	mov	dptr,#_dm_time
      003D87 E0               [24] 1137 	movx	a,@dptr
      003D88 FE               [12] 1138 	mov	r6,a
      003D89 A3               [24] 1139 	inc	dptr
      003D8A E0               [24] 1140 	movx	a,@dptr
      003D8B FF               [12] 1141 	mov	r7,a
      003D8C 90 04 C6         [24] 1142 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003D8F E0               [24] 1143 	movx	a,@dptr
      003D90 FC               [12] 1144 	mov	r4,a
      003D91 A3               [24] 1145 	inc	dptr
      003D92 E0               [24] 1146 	movx	a,@dptr
      003D93 FD               [12] 1147 	mov	r5,a
      003D94 EC               [12] 1148 	mov	a,r4
      003D95 C3               [12] 1149 	clr	c
      003D96 9E               [12] 1150 	subb	a,r6
      003D97 FE               [12] 1151 	mov	r6,a
      003D98 ED               [12] 1152 	mov	a,r5
      003D99 9F               [12] 1153 	subb	a,r7
      003D9A FF               [12] 1154 	mov	r7,a
      003D9B C3               [12] 1155 	clr	c
      003D9C EE               [12] 1156 	mov	a,r6
      003D9D 94 0A            [12] 1157 	subb	a,#0x0a
      003D9F EF               [12] 1158 	mov	a,r7
      003DA0 94 00            [12] 1159 	subb	a,#0x00
      003DA2 50 01            [24] 1160 	jnc	00102$
      003DA4                       1161 00101$:
      003DA4 22               [24] 1162 	ret
      003DA5                       1163 00102$:
                                   1164 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:73: dm_time = now;
      003DA5 90 04 BB         [24] 1165 	mov	dptr,#_dm_time
      003DA8 EC               [12] 1166 	mov	a,r4
      003DA9 F0               [24] 1167 	movx	@dptr,a
      003DAA ED               [12] 1168 	mov	a,r5
      003DAB A3               [24] 1169 	inc	dptr
      003DAC F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:74: if (dm_down) {
      003DAD 90 04 B9         [24] 1172 	mov	dptr,#_dm_down
      003DB0 E0               [24] 1173 	movx	a,@dptr
      003DB1 FF               [12] 1174 	mov	r7,a
      003DB2 E0               [24] 1175 	movx	a,@dptr
      003DB3 60 16            [24] 1176 	jz	00112$
                                   1177 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:75: del_owned_key(dm_down);
      003DB5 8F 82            [24] 1178 	mov	dpl, r7
      003DB7 12 84 47         [24] 1179 	lcall	_del_owned_key
                                   1180 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:76: del_owned_mods(dm_mods);
      003DBA 90 04 BA         [24] 1181 	mov	dptr,#_dm_mods
      003DBD E0               [24] 1182 	movx	a,@dptr
      003DBE F5 82            [12] 1183 	mov	dpl,a
      003DC0 12 83 3B         [24] 1184 	lcall	_del_owned_mods
                                   1185 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:77: dm_down = 0;
      003DC3 90 04 B9         [24] 1186 	mov	dptr,#_dm_down
      003DC6 E4               [12] 1187 	clr	a
      003DC7 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:78: send_keyboard_report();
      003DC8 02 86 65         [24] 1190 	ljmp	_send_keyboard_report
      003DCB                       1191 00112$:
                                   1192 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:79: } else if (dm_index == dm_lengths[dm_play - 1]) {
      003DCB 90 04 B7         [24] 1193 	mov	dptr,#_dm_play
      003DCE E0               [24] 1194 	movx	a,@dptr
      003DCF FF               [12] 1195 	mov	r7,a
      003DD0 14               [12] 1196 	dec	a
      003DD1 FE               [12] 1197 	mov	r6,a
      003DD2 33               [12] 1198 	rlc	a
      003DD3 95 E0            [12] 1199 	subb	a,acc
      003DD5 FD               [12] 1200 	mov	r5,a
      003DD6 EE               [12] 1201 	mov	a,r6
      003DD7 24 B4            [12] 1202 	add	a, #_dm_lengths
      003DD9 F5 82            [12] 1203 	mov	dpl,a
      003DDB ED               [12] 1204 	mov	a,r5
      003DDC 34 04            [12] 1205 	addc	a, #(_dm_lengths >> 8)
      003DDE F5 83            [12] 1206 	mov	dph,a
      003DE0 E0               [24] 1207 	movx	a,@dptr
      003DE1 FE               [12] 1208 	mov	r6,a
      003DE2 90 04 B8         [24] 1209 	mov	dptr,#_dm_index
      003DE5 E0               [24] 1210 	movx	a,@dptr
      003DE6 FD               [12] 1211 	mov	r5,a
      003DE7 B5 06 06         [24] 1212 	cjne	a,ar6,00109$
                                   1213 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:80: dm_play = 0;
      003DEA 90 04 B7         [24] 1214 	mov	dptr,#_dm_play
      003DED E4               [12] 1215 	clr	a
      003DEE F0               [24] 1216 	movx	@dptr,a
      003DEF 22               [24] 1217 	ret
      003DF0                       1218 00109$:
                                   1219 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:82: uint8_t i = (dm_play - 1) * 16 + dm_index++;
      003DF0 1F               [12] 1220 	dec	r7
      003DF1 EF               [12] 1221 	mov	a,r7
      003DF2 C4               [12] 1222 	swap	a
      003DF3 54 F0            [12] 1223 	anl	a,#0xf0
      003DF5 FF               [12] 1224 	mov	r7,a
      003DF6 8D 06            [24] 1225 	mov	ar6,r5
      003DF8 90 04 B8         [24] 1226 	mov	dptr,#_dm_index
      003DFB ED               [12] 1227 	mov	a,r5
      003DFC 04               [12] 1228 	inc	a
      003DFD F0               [24] 1229 	movx	@dptr,a
      003DFE EE               [12] 1230 	mov	a,r6
      003DFF 2F               [12] 1231 	add	a, r7
      003E00 FF               [12] 1232 	mov	r7,a
      003E01 90 04 C8         [24] 1233 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003E04 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:83: uint8_t code = dm_taps[i].code;
      003E05 8F E0            [24] 1236 	mov	acc,r7
      003E07 75 F0 02         [24] 1237 	mov	b,#0x02
      003E0A A4               [48] 1238 	mul	ab
      003E0B 24 74            [12] 1239 	add	a, #_dm_taps
      003E0D F5 82            [12] 1240 	mov	dpl,a
      003E0F 74 04            [12] 1241 	mov	a,#(_dm_taps >> 8)
      003E11 35 F0            [12] 1242 	addc	a, b
      003E13 F5 83            [12] 1243 	mov	dph,a
      003E15 E0               [24] 1244 	movx	a,@dptr
      003E16 FF               [12] 1245 	mov	r7,a
      003E17 90 04 C9         [24] 1246 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003E1A F0               [24] 1247 	movx	@dptr,a
                                   1248 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:86: if (!add_owned_key(code)) {
      003E1B 8F 82            [24] 1249 	mov	dpl, r7
      003E1D 12 83 CB         [24] 1250 	lcall	_add_owned_key
      003E20 E5 82            [12] 1251 	mov	a, dpl
      003E22 70 09            [24] 1252 	jnz	00107$
                                   1253 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:87: del_owned_key(code);
      003E24 90 04 C9         [24] 1254 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003E27 E0               [24] 1255 	movx	a,@dptr
      003E28 F5 82            [12] 1256 	mov	dpl,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:88: return;
      003E2A 02 84 47         [24] 1258 	ljmp	_del_owned_key
      003E2D                       1259 00107$:
                                   1260 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:90: dm_down = code;
      003E2D 90 04 C9         [24] 1261 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003E30 E0               [24] 1262 	movx	a,@dptr
      003E31 90 04 B9         [24] 1263 	mov	dptr,#_dm_down
      003E34 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:91: dm_mods = dm_taps[i].mods;
      003E35 90 04 C8         [24] 1266 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003E38 E0               [24] 1267 	movx	a,@dptr
      003E39 75 F0 02         [24] 1268 	mov	b,#0x02
      003E3C A4               [48] 1269 	mul	ab
      003E3D 24 74            [12] 1270 	add	a, #_dm_taps
      003E3F FE               [12] 1271 	mov	r6,a
      003E40 74 04            [12] 1272 	mov	a,#(_dm_taps >> 8)
      003E42 35 F0            [12] 1273 	addc	a, b
      003E44 FF               [12] 1274 	mov	r7,a
      003E45 8E 82            [24] 1275 	mov	dpl,r6
      003E47 8F 83            [24] 1276 	mov	dph,r7
      003E49 A3               [24] 1277 	inc	dptr
      003E4A E0               [24] 1278 	movx	a,@dptr
      003E4B FF               [12] 1279 	mov	r7,a
      003E4C 90 04 BA         [24] 1280 	mov	dptr,#_dm_mods
      003E4F F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:92: add_owned_mods(dm_mods);
      003E50 8F 82            [24] 1283 	mov	dpl, r7
      003E52 12 83 2C         [24] 1284 	lcall	_add_owned_mods
                                   1285 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:93: send_keyboard_report();
                                   1286 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:95: }
      003E55 02 86 65         [24] 1287 	ljmp	_send_keyboard_report
                                   1288 	.area CSEG    (CODE)
                                   1289 	.area CONST   (CODE)
                                   1290 	.area XINIT   (CODE)
                                   1291 	.area CABS    (ABS,CODE)
