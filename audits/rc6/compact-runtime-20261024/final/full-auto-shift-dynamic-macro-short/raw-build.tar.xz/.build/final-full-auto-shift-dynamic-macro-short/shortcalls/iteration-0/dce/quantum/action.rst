                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _ak820_dynamic_macro_cancel
                                     24 	.globl _ak820_dynamic_macro_task
                                     25 	.globl _ak820_dynamic_macro_observe
                                     26 	.globl _ak820_dynamic_macro_process
                                     27 	.globl _pre_process_record_quantum
                                     28 	.globl _get_record_keycode
                                     29 	.globl _get_repeat_key_count
                                     30 	.globl _repeat_key_cancel
                                     31 	.globl _clear_owned_usages
                                     32 	.globl _owned_usage_key
                                     33 	.globl _clear_owned_keys
                                     34 	.globl _del_owned_key
                                     35 	.globl _add_owned_key
                                     36 	.globl _clear_owned_mods
                                     37 	.globl _del_owned_weak_mods
                                     38 	.globl _add_owned_weak_mods
                                     39 	.globl _del_owned_mods
                                     40 	.globl _add_owned_mods
                                     41 	.globl _clear_weak_mods
                                     42 	.globl _clear_mods
                                     43 	.globl _send_keyboard_report
                                     44 	.globl _layer_hold_clear
                                     45 	.globl _layer_hold_off
                                     46 	.globl _layer_hold_on
                                     47 	.globl _ak820_resolve_key
                                     48 	.globl _layer_xor
                                     49 	.globl _layer_and
                                     50 	.globl _layer_or
                                     51 	.globl _layer_off
                                     52 	.globl _layer_on
                                     53 	.globl _layer_move
                                     54 	.globl _layer_clear
                                     55 	.globl _layer_state_set
                                     56 	.globl _default_layer_xor
                                     57 	.globl _default_layer_and
                                     58 	.globl _default_layer_or
                                     59 	.globl _default_layer_set
                                     60 	.globl _post_process_record_quantum
                                     61 	.globl _process_record_quantum
                                     62 	.globl _action_for_keycode
                                     63 	.globl _mDelaymS
                                     64 	.globl _host_consumer_send
                                     65 	.globl _host_system_send
                                     66 	.globl _host_keyboard_leds
                                     67 	.globl _led_set
                                     68 	.globl _clear_keys_from_report
                                     69 	.globl ___memcpy
                                     70 	.globl _ADC_START
                                     71 	.globl _S0_R_FIFO
                                     72 	.globl _S0_T_FIFO
                                     73 	.globl _S0_FREE
                                     74 	.globl _S0_IF_BYTE
                                     75 	.globl _S0_IF_FIRST
                                     76 	.globl _S0_IF_OV
                                     77 	.globl _S0_FST_ACT
                                     78 	.globl _CP_RL2
                                     79 	.globl _C_T2
                                     80 	.globl _TR2
                                     81 	.globl _EXEN2
                                     82 	.globl _TCLK
                                     83 	.globl _RCLK
                                     84 	.globl _EXF2
                                     85 	.globl _CAP1F
                                     86 	.globl _TF2
                                     87 	.globl _RI
                                     88 	.globl _TI
                                     89 	.globl _RB8
                                     90 	.globl _TB8
                                     91 	.globl _REN
                                     92 	.globl _SM2
                                     93 	.globl _SM1
                                     94 	.globl _SM0
                                     95 	.globl _IT0
                                     96 	.globl _IE0
                                     97 	.globl _IT1
                                     98 	.globl _IE1
                                     99 	.globl _TR0
                                    100 	.globl _TF0
                                    101 	.globl _TR1
                                    102 	.globl _TF1
                                    103 	.globl _P4_0
                                    104 	.globl _P4_1
                                    105 	.globl _P4_2
                                    106 	.globl _P4_3
                                    107 	.globl _P4_4
                                    108 	.globl _P4_5
                                    109 	.globl _P4_6
                                    110 	.globl _RXD
                                    111 	.globl _TXD
                                    112 	.globl _INT0
                                    113 	.globl _INT1
                                    114 	.globl _T0
                                    115 	.globl _T1
                                    116 	.globl _MOSI1
                                    117 	.globl _MISO1
                                    118 	.globl _SCK1
                                    119 	.globl _P3_0
                                    120 	.globl _P3_1
                                    121 	.globl _P3_2
                                    122 	.globl _P3_3
                                    123 	.globl _P3_4
                                    124 	.globl _P3_5
                                    125 	.globl _P3_6
                                    126 	.globl _P3_7
                                    127 	.globl _CAP1_
                                    128 	.globl _T2_
                                    129 	.globl _CAP2_
                                    130 	.globl _T2EX_
                                    131 	.globl _RXD1
                                    132 	.globl _TXD1
                                    133 	.globl _P2_0
                                    134 	.globl _P2_1
                                    135 	.globl _P2_2
                                    136 	.globl _P2_3
                                    137 	.globl _P2_4
                                    138 	.globl _P2_5
                                    139 	.globl _P2_6
                                    140 	.globl _P2_7
                                    141 	.globl _AIN0
                                    142 	.globl _AIN1
                                    143 	.globl _AIN2
                                    144 	.globl _AIN3
                                    145 	.globl _AIN4
                                    146 	.globl _AIN5
                                    147 	.globl _AIN6
                                    148 	.globl _AIN7
                                    149 	.globl _CAP1
                                    150 	.globl _T2
                                    151 	.globl _CAP2
                                    152 	.globl _T2EX
                                    153 	.globl _INT0_
                                    154 	.globl _SCS
                                    155 	.globl _MOSI
                                    156 	.globl _MISO
                                    157 	.globl _SCK
                                    158 	.globl _RXD1_
                                    159 	.globl _TXD1_
                                    160 	.globl _P1_0
                                    161 	.globl _P1_1
                                    162 	.globl _P1_2
                                    163 	.globl _P1_3
                                    164 	.globl _P1_4
                                    165 	.globl _P1_5
                                    166 	.globl _P1_6
                                    167 	.globl _P1_7
                                    168 	.globl _AIN8
                                    169 	.globl _AIN9
                                    170 	.globl _AIN10
                                    171 	.globl _AIN11
                                    172 	.globl _AIN12
                                    173 	.globl _AIN13
                                    174 	.globl _RXD_
                                    175 	.globl _TXD_
                                    176 	.globl _SCL0
                                    177 	.globl _SDA0
                                    178 	.globl _P0_0
                                    179 	.globl _P0_1
                                    180 	.globl _P0_2
                                    181 	.globl _P0_3
                                    182 	.globl _P0_4
                                    183 	.globl _P0_5
                                    184 	.globl _P0_6
                                    185 	.globl _P0_7
                                    186 	.globl _IE_SPI0
                                    187 	.globl _IE_USB
                                    188 	.globl _IE_ADC
                                    189 	.globl _IE_UART1
                                    190 	.globl _IE_PWM_I2C
                                    191 	.globl _IE_GPIO
                                    192 	.globl _IE_WDOG
                                    193 	.globl _PX0
                                    194 	.globl _PT0
                                    195 	.globl _PX1
                                    196 	.globl _PT1
                                    197 	.globl _PS
                                    198 	.globl _PT2
                                    199 	.globl _PL_FLAG
                                    200 	.globl _PH_FLAG
                                    201 	.globl _EX0
                                    202 	.globl _ET0
                                    203 	.globl _EX1
                                    204 	.globl _ET1
                                    205 	.globl _ES
                                    206 	.globl _ET2
                                    207 	.globl _E_DIS
                                    208 	.globl _EA
                                    209 	.globl _P
                                    210 	.globl _F1
                                    211 	.globl _OV
                                    212 	.globl _RS0
                                    213 	.globl _RS1
                                    214 	.globl _F0
                                    215 	.globl _AC
                                    216 	.globl _CY
                                    217 	.globl _I2CS_INT_ST
                                    218 	.globl _I2CX_INT
                                    219 	.globl _LED_STATUS
                                    220 	.globl _LED_DMA_H
                                    221 	.globl _LED_DMA_L
                                    222 	.globl _LED_DMA
                                    223 	.globl _LED_PWM_OE
                                    224 	.globl _LED_COMMON
                                    225 	.globl _ADC_CHAN
                                    226 	.globl _ADC_DAT_H
                                    227 	.globl _ADC_DAT_L
                                    228 	.globl _ADC_DAT
                                    229 	.globl _ADC_CTRL
                                    230 	.globl _SPI1_CK_SE
                                    231 	.globl _SPI1_CTRL
                                    232 	.globl _SPI1_DATA
                                    233 	.globl _SPI1_STAT
                                    234 	.globl _SIF1
                                    235 	.globl _SBAUD1
                                    236 	.globl _SBUF1
                                    237 	.globl _SCON1
                                    238 	.globl _SPI0_SETUP
                                    239 	.globl _SPI0_CK_SE
                                    240 	.globl _SPI0_CTRL
                                    241 	.globl _SPI0_DATA
                                    242 	.globl _SPI0_STAT
                                    243 	.globl _T2CAP1H
                                    244 	.globl _T2CAP1L
                                    245 	.globl _T2CAP1
                                    246 	.globl _TH2
                                    247 	.globl _TL2
                                    248 	.globl _T2COUNT
                                    249 	.globl _RCAP2H
                                    250 	.globl _RCAP2L
                                    251 	.globl _RCAP2
                                    252 	.globl _T2MOD
                                    253 	.globl _T2CON
                                    254 	.globl _SBUF
                                    255 	.globl _SCON
                                    256 	.globl _TH1
                                    257 	.globl _TH0
                                    258 	.globl _TL1
                                    259 	.globl _TL0
                                    260 	.globl _TMOD
                                    261 	.globl _TCON
                                    262 	.globl _XBUS_AUX
                                    263 	.globl _P7
                                    264 	.globl _P6_DIR
                                    265 	.globl _P6_OUT_PU
                                    266 	.globl _P6_IN
                                    267 	.globl _P5_DIR
                                    268 	.globl _P5_OUT_PU
                                    269 	.globl _P5_IN
                                    270 	.globl _P4_LED_KEY
                                    271 	.globl _P4_DIR_PU
                                    272 	.globl _P4_MOD_OC
                                    273 	.globl _P4
                                    274 	.globl _P3_DIR_PU
                                    275 	.globl _P3_MOD_OC
                                    276 	.globl _P3
                                    277 	.globl _P2_DIR_PU
                                    278 	.globl _P2_MOD_OC
                                    279 	.globl _P2
                                    280 	.globl _P1_DIR_PU
                                    281 	.globl _P1_MOD_OC
                                    282 	.globl _P1
                                    283 	.globl _P0_DIR_PU
                                    284 	.globl _P0_MOD_OC
                                    285 	.globl _P0
                                    286 	.globl _ROM_CTRL
                                    287 	.globl _ROM_DATA_HH
                                    288 	.globl _ROM_DATA_HL
                                    289 	.globl _ROM_DATA_HI
                                    290 	.globl _ROM_ADDR_H
                                    291 	.globl _ROM_ADDR_L
                                    292 	.globl _ROM_ADDR
                                    293 	.globl _GPIO_IE
                                    294 	.globl _IP_EX
                                    295 	.globl _IE_EX
                                    296 	.globl _IP
                                    297 	.globl _IE
                                    298 	.globl _WDOG_COUNT
                                    299 	.globl _RESET_KEEP
                                    300 	.globl _WAKE_CTRL
                                    301 	.globl _CLOCK_CFG
                                    302 	.globl _POWER_CFG
                                    303 	.globl _PCON
                                    304 	.globl _GLOBAL_CFG
                                    305 	.globl _SAFE_MOD
                                    306 	.globl _DPH
                                    307 	.globl _DPL
                                    308 	.globl _SP
                                    309 	.globl _A_INV
                                    310 	.globl _B
                                    311 	.globl _ACC
                                    312 	.globl _PSW
                                    313 	.globl _disable_action_cache
                                    314 	.globl _tap_code_delay_PARM_2
                                    315 	.globl _process_action_PARM_2
                                    316 	.globl _action_exec_PARM_1
                                    317 	.globl _tp_buttons
                                    318 	.globl _action_exec
                                    319 	.globl _ak820_action_exec
                                    320 	.globl _process_record
                                    321 	.globl _process_record_handler
                                    322 	.globl _process_action
                                    323 	.globl _register_code
                                    324 	.globl _unregister_code
                                    325 	.globl _tap_code_delay
                                    326 	.globl _tap_code
                                    327 	.globl _register_mods
                                    328 	.globl _unregister_mods
                                    329 	.globl _register_weak_mods
                                    330 	.globl _unregister_weak_mods
                                    331 	.globl _clear_keyboard
                                    332 	.globl _clear_keyboard_but_mods
                                    333 	.globl _clear_keyboard_but_mods_and_keys
                                    334 ;--------------------------------------------------------
                                    335 ; special function registers
                                    336 ;--------------------------------------------------------
                                    337 	.area RSEG    (ABS,DATA)
      000000                        338 	.org 0x0000
                           0000D0   339 _PSW	=	0x00d0
                           0000E0   340 _ACC	=	0x00e0
                           0000F0   341 _B	=	0x00f0
                           0000FD   342 _A_INV	=	0x00fd
                           000081   343 _SP	=	0x0081
                           000082   344 _DPL	=	0x0082
                           000083   345 _DPH	=	0x0083
                           0000A1   346 _SAFE_MOD	=	0x00a1
                           0000B1   347 _GLOBAL_CFG	=	0x00b1
                           000087   348 _PCON	=	0x0087
                           0000BA   349 _POWER_CFG	=	0x00ba
                           0000B9   350 _CLOCK_CFG	=	0x00b9
                           0000A9   351 _WAKE_CTRL	=	0x00a9
                           0000FE   352 _RESET_KEEP	=	0x00fe
                           0000FF   353 _WDOG_COUNT	=	0x00ff
                           0000A8   354 _IE	=	0x00a8
                           0000B8   355 _IP	=	0x00b8
                           0000E8   356 _IE_EX	=	0x00e8
                           0000E9   357 _IP_EX	=	0x00e9
                           0000B2   358 _GPIO_IE	=	0x00b2
                           008584   359 _ROM_ADDR	=	0x8584
                           000084   360 _ROM_ADDR_L	=	0x0084
                           000085   361 _ROM_ADDR_H	=	0x0085
                           008F8E   362 _ROM_DATA_HI	=	0x8f8e
                           00008E   363 _ROM_DATA_HL	=	0x008e
                           00008F   364 _ROM_DATA_HH	=	0x008f
                           000086   365 _ROM_CTRL	=	0x0086
                           000080   366 _P0	=	0x0080
                           0000C4   367 _P0_MOD_OC	=	0x00c4
                           0000C5   368 _P0_DIR_PU	=	0x00c5
                           000090   369 _P1	=	0x0090
                           000092   370 _P1_MOD_OC	=	0x0092
                           000093   371 _P1_DIR_PU	=	0x0093
                           0000A0   372 _P2	=	0x00a0
                           000094   373 _P2_MOD_OC	=	0x0094
                           000095   374 _P2_DIR_PU	=	0x0095
                           0000B0   375 _P3	=	0x00b0
                           000096   376 _P3_MOD_OC	=	0x0096
                           000097   377 _P3_DIR_PU	=	0x0097
                           0000C0   378 _P4	=	0x00c0
                           0000C2   379 _P4_MOD_OC	=	0x00c2
                           0000C3   380 _P4_DIR_PU	=	0x00c3
                           0000C1   381 _P4_LED_KEY	=	0x00c1
                           0000AA   382 _P5_IN	=	0x00aa
                           0000AB   383 _P5_OUT_PU	=	0x00ab
                           0000AC   384 _P5_DIR	=	0x00ac
                           0000AD   385 _P6_IN	=	0x00ad
                           0000AE   386 _P6_OUT_PU	=	0x00ae
                           0000AF   387 _P6_DIR	=	0x00af
                           0000F1   388 _P7	=	0x00f1
                           0000A2   389 _XBUS_AUX	=	0x00a2
                           000088   390 _TCON	=	0x0088
                           000089   391 _TMOD	=	0x0089
                           00008A   392 _TL0	=	0x008a
                           00008B   393 _TL1	=	0x008b
                           00008C   394 _TH0	=	0x008c
                           00008D   395 _TH1	=	0x008d
                           000098   396 _SCON	=	0x0098
                           000099   397 _SBUF	=	0x0099
                           0000C8   398 _T2CON	=	0x00c8
                           0000C9   399 _T2MOD	=	0x00c9
                           00CBCA   400 _RCAP2	=	0xcbca
                           0000CA   401 _RCAP2L	=	0x00ca
                           0000CB   402 _RCAP2H	=	0x00cb
                           00CDCC   403 _T2COUNT	=	0xcdcc
                           0000CC   404 _TL2	=	0x00cc
                           0000CD   405 _TH2	=	0x00cd
                           00CFCE   406 _T2CAP1	=	0xcfce
                           0000CE   407 _T2CAP1L	=	0x00ce
                           0000CF   408 _T2CAP1H	=	0x00cf
                           0000F8   409 _SPI0_STAT	=	0x00f8
                           0000F9   410 _SPI0_DATA	=	0x00f9
                           0000FA   411 _SPI0_CTRL	=	0x00fa
                           0000FB   412 _SPI0_CK_SE	=	0x00fb
                           0000FC   413 _SPI0_SETUP	=	0x00fc
                           0000BC   414 _SCON1	=	0x00bc
                           0000BD   415 _SBUF1	=	0x00bd
                           0000BE   416 _SBAUD1	=	0x00be
                           0000BF   417 _SIF1	=	0x00bf
                           0000B4   418 _SPI1_STAT	=	0x00b4
                           0000B5   419 _SPI1_DATA	=	0x00b5
                           0000B6   420 _SPI1_CTRL	=	0x00b6
                           0000B7   421 _SPI1_CK_SE	=	0x00b7
                           0000F3   422 _ADC_CTRL	=	0x00f3
                           00F5F4   423 _ADC_DAT	=	0xf5f4
                           0000F4   424 _ADC_DAT_L	=	0x00f4
                           0000F5   425 _ADC_DAT_H	=	0x00f5
                           0000F6   426 _ADC_CHAN	=	0x00f6
                           0000A6   427 _LED_COMMON	=	0x00a6
                           0000A7   428 _LED_PWM_OE	=	0x00a7
                           00C7C6   429 _LED_DMA	=	0xc7c6
                           0000C6   430 _LED_DMA_L	=	0x00c6
                           0000C7   431 _LED_DMA_H	=	0x00c7
                           0000F7   432 _LED_STATUS	=	0x00f7
                           0000B3   433 _I2CX_INT	=	0x00b3
                           0000BB   434 _I2CS_INT_ST	=	0x00bb
                                    435 ;--------------------------------------------------------
                                    436 ; special function bits
                                    437 ;--------------------------------------------------------
                                    438 	.area RSEG    (ABS,DATA)
      000000                        439 	.org 0x0000
                           0000D7   440 _CY	=	0x00d7
                           0000D6   441 _AC	=	0x00d6
                           0000D5   442 _F0	=	0x00d5
                           0000D4   443 _RS1	=	0x00d4
                           0000D3   444 _RS0	=	0x00d3
                           0000D2   445 _OV	=	0x00d2
                           0000D1   446 _F1	=	0x00d1
                           0000D0   447 _P	=	0x00d0
                           0000AF   448 _EA	=	0x00af
                           0000AE   449 _E_DIS	=	0x00ae
                           0000AD   450 _ET2	=	0x00ad
                           0000AC   451 _ES	=	0x00ac
                           0000AB   452 _ET1	=	0x00ab
                           0000AA   453 _EX1	=	0x00aa
                           0000A9   454 _ET0	=	0x00a9
                           0000A8   455 _EX0	=	0x00a8
                           0000BF   456 _PH_FLAG	=	0x00bf
                           0000BE   457 _PL_FLAG	=	0x00be
                           0000BD   458 _PT2	=	0x00bd
                           0000BC   459 _PS	=	0x00bc
                           0000BB   460 _PT1	=	0x00bb
                           0000BA   461 _PX1	=	0x00ba
                           0000B9   462 _PT0	=	0x00b9
                           0000B8   463 _PX0	=	0x00b8
                           0000EF   464 _IE_WDOG	=	0x00ef
                           0000EE   465 _IE_GPIO	=	0x00ee
                           0000ED   466 _IE_PWM_I2C	=	0x00ed
                           0000EC   467 _IE_UART1	=	0x00ec
                           0000EB   468 _IE_ADC	=	0x00eb
                           0000E9   469 _IE_USB	=	0x00e9
                           0000E8   470 _IE_SPI0	=	0x00e8
                           000087   471 _P0_7	=	0x0087
                           000086   472 _P0_6	=	0x0086
                           000085   473 _P0_5	=	0x0085
                           000084   474 _P0_4	=	0x0084
                           000083   475 _P0_3	=	0x0083
                           000082   476 _P0_2	=	0x0082
                           000081   477 _P0_1	=	0x0081
                           000080   478 _P0_0	=	0x0080
                           000081   479 _SDA0	=	0x0081
                           000080   480 _SCL0	=	0x0080
                           000083   481 _TXD_	=	0x0083
                           000082   482 _RXD_	=	0x0082
                           000085   483 _AIN13	=	0x0085
                           000084   484 _AIN12	=	0x0084
                           000083   485 _AIN11	=	0x0083
                           000082   486 _AIN10	=	0x0082
                           000081   487 _AIN9	=	0x0081
                           000080   488 _AIN8	=	0x0080
                           000097   489 _P1_7	=	0x0097
                           000096   490 _P1_6	=	0x0096
                           000095   491 _P1_5	=	0x0095
                           000094   492 _P1_4	=	0x0094
                           000093   493 _P1_3	=	0x0093
                           000092   494 _P1_2	=	0x0092
                           000091   495 _P1_1	=	0x0091
                           000090   496 _P1_0	=	0x0090
                           000097   497 _TXD1_	=	0x0097
                           000096   498 _RXD1_	=	0x0096
                           000097   499 _SCK	=	0x0097
                           000096   500 _MISO	=	0x0096
                           000095   501 _MOSI	=	0x0095
                           000094   502 _SCS	=	0x0094
                           000092   503 _INT0_	=	0x0092
                           000091   504 _T2EX	=	0x0091
                           000091   505 _CAP2	=	0x0091
                           000090   506 _T2	=	0x0090
                           000090   507 _CAP1	=	0x0090
                           000097   508 _AIN7	=	0x0097
                           000096   509 _AIN6	=	0x0096
                           000095   510 _AIN5	=	0x0095
                           000094   511 _AIN4	=	0x0094
                           000093   512 _AIN3	=	0x0093
                           000092   513 _AIN2	=	0x0092
                           000091   514 _AIN1	=	0x0091
                           000090   515 _AIN0	=	0x0090
                           0000A7   516 _P2_7	=	0x00a7
                           0000A6   517 _P2_6	=	0x00a6
                           0000A5   518 _P2_5	=	0x00a5
                           0000A4   519 _P2_4	=	0x00a4
                           0000A3   520 _P2_3	=	0x00a3
                           0000A2   521 _P2_2	=	0x00a2
                           0000A1   522 _P2_1	=	0x00a1
                           0000A0   523 _P2_0	=	0x00a0
                           0000A7   524 _TXD1	=	0x00a7
                           0000A6   525 _RXD1	=	0x00a6
                           0000A5   526 _T2EX_	=	0x00a5
                           0000A5   527 _CAP2_	=	0x00a5
                           0000A4   528 _T2_	=	0x00a4
                           0000A4   529 _CAP1_	=	0x00a4
                           0000B7   530 _P3_7	=	0x00b7
                           0000B6   531 _P3_6	=	0x00b6
                           0000B5   532 _P3_5	=	0x00b5
                           0000B4   533 _P3_4	=	0x00b4
                           0000B3   534 _P3_3	=	0x00b3
                           0000B2   535 _P3_2	=	0x00b2
                           0000B1   536 _P3_1	=	0x00b1
                           0000B0   537 _P3_0	=	0x00b0
                           0000B7   538 _SCK1	=	0x00b7
                           0000B6   539 _MISO1	=	0x00b6
                           0000B5   540 _MOSI1	=	0x00b5
                           0000B5   541 _T1	=	0x00b5
                           0000B4   542 _T0	=	0x00b4
                           0000B3   543 _INT1	=	0x00b3
                           0000B2   544 _INT0	=	0x00b2
                           0000B1   545 _TXD	=	0x00b1
                           0000B0   546 _RXD	=	0x00b0
                           0000C6   547 _P4_6	=	0x00c6
                           0000C5   548 _P4_5	=	0x00c5
                           0000C4   549 _P4_4	=	0x00c4
                           0000C3   550 _P4_3	=	0x00c3
                           0000C2   551 _P4_2	=	0x00c2
                           0000C1   552 _P4_1	=	0x00c1
                           0000C0   553 _P4_0	=	0x00c0
                           00008F   554 _TF1	=	0x008f
                           00008E   555 _TR1	=	0x008e
                           00008D   556 _TF0	=	0x008d
                           00008C   557 _TR0	=	0x008c
                           00008B   558 _IE1	=	0x008b
                           00008A   559 _IT1	=	0x008a
                           000089   560 _IE0	=	0x0089
                           000088   561 _IT0	=	0x0088
                           00009F   562 _SM0	=	0x009f
                           00009E   563 _SM1	=	0x009e
                           00009D   564 _SM2	=	0x009d
                           00009C   565 _REN	=	0x009c
                           00009B   566 _TB8	=	0x009b
                           00009A   567 _RB8	=	0x009a
                           000099   568 _TI	=	0x0099
                           000098   569 _RI	=	0x0098
                           0000CF   570 _TF2	=	0x00cf
                           0000CF   571 _CAP1F	=	0x00cf
                           0000CE   572 _EXF2	=	0x00ce
                           0000CD   573 _RCLK	=	0x00cd
                           0000CC   574 _TCLK	=	0x00cc
                           0000CB   575 _EXEN2	=	0x00cb
                           0000CA   576 _TR2	=	0x00ca
                           0000C9   577 _C_T2	=	0x00c9
                           0000C8   578 _CP_RL2	=	0x00c8
                           0000FF   579 _S0_FST_ACT	=	0x00ff
                           0000FE   580 _S0_IF_OV	=	0x00fe
                           0000FD   581 _S0_IF_FIRST	=	0x00fd
                           0000FC   582 _S0_IF_BYTE	=	0x00fc
                           0000FB   583 _S0_FREE	=	0x00fb
                           0000FA   584 _S0_T_FIFO	=	0x00fa
                           0000F8   585 _S0_R_FIFO	=	0x00f8
                           0000F7   586 _ADC_START	=	0x00f7
                                    587 ;--------------------------------------------------------
                                    588 ; overlayable register banks
                                    589 ;--------------------------------------------------------
                                    590 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        591 	.ds 8
                                    592 ;--------------------------------------------------------
                                    593 ; internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area DSEG    (DATA)
      000027                        596 _process_record_sloc0_1_0:
      000027                        597 	.ds 1
      000028                        598 _process_action_sloc0_1_0:
      000028                        599 	.ds 1
                                    600 ;--------------------------------------------------------
                                    601 ; overlayable items in internal ram
                                    602 ;--------------------------------------------------------
                                    603 ;--------------------------------------------------------
                                    604 ; indirectly addressable internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area ISEG    (DATA)
                                    607 ;--------------------------------------------------------
                                    608 ; absolute internal ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area IABS    (ABS,DATA)
                                    611 	.area IABS    (ABS,DATA)
                                    612 ;--------------------------------------------------------
                                    613 ; bit data
                                    614 ;--------------------------------------------------------
                                    615 	.area BSEG    (BIT)
      000022                        616 _process_action_sloc1_1_0:
      000022                        617 	.ds 1
                                    618 ;--------------------------------------------------------
                                    619 ; paged external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area PSEG    (PAG,XDATA)
                                    622 ;--------------------------------------------------------
                                    623 ; uninitialized external ram data
                                    624 ;--------------------------------------------------------
                                    625 	.area XSEG    (XDATA)
      00087B                        626 _tp_buttons::
      00087B                        627 	.ds 2
      00087D                        628 _action_exec_PARM_1:
      00087D                        629 	.ds 6
      000883                        630 _action_exec_record_10001_633:
      000883                        631 	.ds 9
      00088C                        632 _ak820_action_exec_event_10000_638:
      00088C                        633 	.ds 2
      00088E                        634 _ak820_action_exec_snapshot_10000_639:
      00088E                        635 	.ds 6
      000894                        636 _process_record_record_10000_642:
      000894                        637 	.ds 3
      000897                        638 _process_record_handler_record_argument_10000_651:
      000897                        639 	.ds 3
      00089A                        640 _process_record_handler_action_10000_652:
      00089A                        641 	.ds 2
      00089C                        642 _process_action_PARM_2:
      00089C                        643 	.ds 2
      00089E                        644 _process_action_record_argument_10000_663:
      00089E                        645 	.ds 3
      0008A1                        646 _process_action_on_40000_686:
      0008A1                        647 	.ds 1
      0008A2                        648 _register_code_code_10000_720:
      0008A2                        649 	.ds 1
      0008A3                        650 _unregister_code_code_10000_734:
      0008A3                        651 	.ds 1
      0008A4                        652 _tap_code_delay_PARM_2:
      0008A4                        653 	.ds 2
      0008A6                        654 _tap_code_delay_code_10000_747:
      0008A6                        655 	.ds 1
      0008A7                        656 _tap_code_code_10000_754:
      0008A7                        657 	.ds 1
      0008A8                        658 _register_mods_mods_10000_756:
      0008A8                        659 	.ds 1
      0008A9                        660 _unregister_mods_mods_10000_760:
      0008A9                        661 	.ds 1
      0008AA                        662 _register_weak_mods_mods_10000_764:
      0008AA                        663 	.ds 1
      0008AB                        664 _unregister_weak_mods_mods_10000_768:
      0008AB                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000E2B                        674 _disable_action_cache::
      000E2B                        675 	.ds 1
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT0 (CODE)
                                    678 	.area GSINIT1 (CODE)
                                    679 	.area GSINIT2 (CODE)
                                    680 	.area GSINIT3 (CODE)
                                    681 	.area GSINIT4 (CODE)
                                    682 	.area GSINIT5 (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area CSEG    (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; global & static initialisations
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area GSINIT  (CODE)
                                    691 	.area GSFINAL (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 ;--------------------------------------------------------
                                    694 ; Home
                                    695 ;--------------------------------------------------------
                                    696 	.area HOME    (CODE)
                                    697 	.area HOME    (CODE)
                                    698 ;--------------------------------------------------------
                                    699 ; code
                                    700 ;--------------------------------------------------------
                                    701 	.area CSEG    (CODE)
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    704 ;------------------------------------------------------------
                                    705 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    706 ;------------------------------------------------------------
                                    707 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    708 ;	-----------------------------------------
                           000007   709 	ar7 = 0x07
                           000006   710 	ar6 = 0x06
                           000005   711 	ar5 = 0x05
                           000004   712 	ar4 = 0x04
                           000003   713 	ar3 = 0x03
                           000002   714 	ar2 = 0x02
                           000001   715 	ar1 = 0x01
                           000000   716 	ar0 = 0x00
                                    717 ;	 function action_exec
                                    718 ;	-----------------------------------------
      0075D5                        719 _action_exec:
                                    720 ;	quantum/action.c:89: ak820_dynamic_macro_task(event.time);
      0075D5 90 08 7F         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0075D8 12 3A 34         [24]  722 	lcall	_ak820_outline_0005
      0075DB 12 3D 66         [24]  723 	lcall	_ak820_dynamic_macro_task
                                    724 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      0075DE 90 08 7F         [24]  725 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0075E1 12 3A 34         [24]  726 	lcall	_ak820_outline_0005
      0075E4 12 38 4B         [24]  727 	lcall	_ak820_combo_tick
                                    728 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      0075E7 90 08 7D         [24]  729 	mov	dptr,#_action_exec_PARM_1
      0075EA 12 49 DF         [24]  730 	lcall	_ak820_tapping_before
      0075ED E5 82            [12]  731 	mov	a, dpl
      0075EF 70 01            [24]  732 	jnz	00102$
      0075F1 22               [24]  733 	ret
      0075F2                        734 00102$:
                                    735 ;	quantum/action.c:97: if (!ak820_autoshift_before(&event)) return;
      0075F2 90 08 7D         [24]  736 	mov	dptr,#_action_exec_PARM_1
      0075F5 12 31 2D         [24]  737 	lcall	_ak820_autoshift_before
      0075F8 E5 82            [12]  738 	mov	a, dpl
      0075FA 70 01            [24]  739 	jnz	00104$
      0075FC 22               [24]  740 	ret
      0075FD                        741 00104$:
                                    742 ;	quantum/action.c:113: if (event.pressed) {
      0075FD 90 08 82         [24]  743 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007600 E0               [24]  744 	movx	a,@dptr
      007601 60 03            [24]  745 	jz	00106$
                                    746 ;	quantum/action.c:115: clear_weak_mods();
      007603 12 87 12         [24]  747 	lcall	_clear_weak_mods
      007606                        748 00106$:
                                    749 ;	quantum/action.c:127: record.event = event;
      007606 90 0E 0A         [24]  750 	mov	dptr,#___memcpy_PARM_2
      007609 74 7D            [12]  751 	mov	a,#_action_exec_PARM_1
      00760B F0               [24]  752 	movx	@dptr,a
      00760C 74 08            [12]  753 	mov	a,#(_action_exec_PARM_1 >> 8)
      00760E 12 3A B0         [24]  754 	lcall	_ak820_outline_0095
      007611 12 7D 96         [24]  755 	lcall	_ak820_outline_0071
      007614 90 08 83         [24]  756 	mov	dptr,#_action_exec_record_10001_633
      007617 F5 F0            [12]  757 	mov	b,a
      007619 12 BD A0         [24]  758 	lcall	___memcpy
                                    759 ;	quantum/action.c:129: record.tap.count = 0;
      00761C 90 08 89         [24]  760 	mov	dptr,#(_action_exec_record_10001_633 + 0x0006)
      00761F E0               [24]  761 	movx	a,@dptr
      007620 54 0F            [12]  762 	anl	a,#0x0f
      007622 F0               [24]  763 	movx	@dptr,a
                                    764 ;	quantum/action.c:134: record.keycode = 0;
      007623 90 08 8A         [24]  765 	mov	dptr,#(_action_exec_record_10001_633 + 0x0007)
      007626 12 54 D7         [24]  766 	lcall	_ak820_outline_0183
                                    767 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007629 90 08 87         [24]  768 	mov	dptr,#(_action_exec_record_10001_633 + 0x0004)
      00762C E0               [24]  769 	movx	a,@dptr
      00762D 60 0D            [24]  770 	jz	00111$
      00762F 90 08 83         [24]  771 	mov	dptr,#_action_exec_record_10001_633
      007632 75 F0 00         [24]  772 	mov	b, #0x00
      007635 12 A4 99         [24]  773 	lcall	_pre_process_record_quantum
      007638 E5 82            [12]  774 	mov	a, dpl
      00763A 60 1E            [24]  775 	jz	00114$
      00763C                        776 00111$:
                                    777 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      00763C 90 08 83         [24]  778 	mov	dptr,#_action_exec_record_10001_633
      00763F 12 4A C4         [24]  779 	lcall	_ak820_tapping_process
      007642 E5 82            [12]  780 	mov	a, dpl
      007644 70 01            [24]  781 	jnz	00108$
      007646 22               [24]  782 	ret
      007647                        783 00108$:
                                    784 ;	quantum/action.c:169: if (!ak820_autoshift_process(&record)) return;
      007647 90 08 83         [24]  785 	mov	dptr,#_action_exec_record_10001_633
      00764A 12 32 35         [24]  786 	lcall	_ak820_autoshift_process
      00764D E5 82            [12]  787 	mov	a, dpl
      00764F 70 01            [24]  788 	jnz	00110$
      007651 22               [24]  789 	ret
      007652                        790 00110$:
                                    791 ;	quantum/action.c:172: process_record(&record);
      007652 90 08 83         [24]  792 	mov	dptr,#_action_exec_record_10001_633
      007655 75 F0 00         [24]  793 	mov	b, #0x00
                                    794 ;	quantum/action.c:182: }
      007658 C1 96            [12]  795 	ajmp	_process_record
      00765A                        796 00114$:
      00765A 22               [24]  797 	ret
                                    798 ;------------------------------------------------------------
                                    799 ;Allocation info for local variables in function 'ak820_action_exec'
                                    800 ;------------------------------------------------------------
                                    801 ;event         Allocated with name '_ak820_action_exec_event_10000_638'
                                    802 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_639'
                                    803 ;------------------------------------------------------------
                                    804 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    805 ;	-----------------------------------------
                                    806 ;	 function ak820_action_exec
                                    807 ;	-----------------------------------------
      00765B                        808 _ak820_action_exec:
      00765B 12 3A C2         [24]  809 	lcall	_ak820_outline_0110
      00765E 90 08 8C         [24]  810 	mov	dptr,#_ak820_action_exec_event_10000_638
      007661 12 3A C7         [24]  811 	lcall	_ak820_outline_0111
                                    812 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      007664 90 08 8C         [24]  813 	mov	dptr,#_ak820_action_exec_event_10000_638
      007667 12 3A A4         [24]  814 	lcall	_ak820_outline_0080
      00766A 7F 00            [12]  815 	mov	r7,#0x00
      00766C 90 0E 0A         [24]  816 	mov	dptr,#___memcpy_PARM_2
      00766F ED               [12]  817 	mov	a,r5
      007670 12 3A 5F         [24]  818 	lcall	_ak820_outline_0016
      007673 12 7D 96         [24]  819 	lcall	_ak820_outline_0071
      007676 90 08 8E         [24]  820 	mov	dptr,#_ak820_action_exec_snapshot_10000_639
      007679 F5 F0            [12]  821 	mov	b,a
      00767B 12 BD A0         [24]  822 	lcall	___memcpy
                                    823 ;	quantum/action.c:189: action_exec(snapshot);
      00767E 90 0E 0A         [24]  824 	mov	dptr,#___memcpy_PARM_2
      007681 74 8E            [12]  825 	mov	a,#_ak820_action_exec_snapshot_10000_639
      007683 F0               [24]  826 	movx	@dptr,a
      007684 74 08            [12]  827 	mov	a,#(_ak820_action_exec_snapshot_10000_639 >> 8)
      007686 12 3A B0         [24]  828 	lcall	_ak820_outline_0095
      007689 12 7D 96         [24]  829 	lcall	_ak820_outline_0071
      00768C 90 08 7D         [24]  830 	mov	dptr,#_action_exec_PARM_1
      00768F F5 F0            [12]  831 	mov	b,a
      007691 12 BD A0         [24]  832 	lcall	___memcpy
                                    833 ;	quantum/action.c:190: }
      007694 A1 D5            [12]  834 	ajmp	_action_exec
                                    835 ;------------------------------------------------------------
                                    836 ;Allocation info for local variables in function 'process_record_nocache'
                                    837 ;------------------------------------------------------------
                                    838 ;record        Allocated with name '_process_record_nocache_record_10000_640'
                                    839 ;------------------------------------------------------------
                                    840 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    841 ;	-----------------------------------------
                                    842 ;	 function process_record
                                    843 ;	-----------------------------------------
      007696                        844 _process_record:
      007696 12 48 A0         [24]  845 	lcall	_ak820_outline_0036
      007699 90 08 94         [24]  846 	mov	dptr,#_process_record_record_10000_642
      00769C 12 3A 5F         [24]  847 	lcall	_ak820_outline_0016
                                    848 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      00769F 90 08 94         [24]  849 	mov	dptr,#_process_record_record_10000_642
      0076A2 12 54 84         [24]  850 	lcall	_ak820_outline_0013
      0076A5 74 04            [12]  851 	mov	a,#0x04
      0076A7 12 7D 52         [24]  852 	lcall	_ak820_outline_0006
      0076AA 12 BE 79         [24]  853 	lcall	__gptrget
      0076AD 70 01            [24]  854 	jnz	00102$
                                    855 ;	quantum/action.c:330: return;
      0076AF 22               [24]  856 	ret
      0076B0                        857 00102$:
                                    858 ;	quantum/action.c:334: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      0076B0 74 01            [12]  859 	mov	a,#0x01
      0076B2 12 7D 52         [24]  860 	lcall	_ak820_outline_0006
      0076B5 12 BE 79         [24]  861 	lcall	__gptrget
      0076B8 FA               [12]  862 	mov	r2,a
      0076B9 BA 10 00         [24]  863 	cjne	r2,#0x10,00192$
      0076BC                        864 00192$:
      0076BC 50 49            [24]  865 	jnc	00104$
      0076BE 8D 02            [24]  866 	mov	ar2,r5
      0076C0 8E 03            [24]  867 	mov	ar3,r6
      0076C2 8F 04            [24]  868 	mov	ar4,r7
      0076C4 12 3A EC         [24]  869 	lcall	_ak820_outline_0145
      0076C7 8C F0            [24]  870 	mov	b,r4
      0076C9 12 BE 79         [24]  871 	lcall	__gptrget
      0076CC FA               [12]  872 	mov	r2,a
      0076CD BA 08 00         [24]  873 	cjne	r2,#0x08,00194$
      0076D0                        874 00194$:
      0076D0 50 35            [24]  875 	jnc	00104$
      0076D2 90 09 F0         [24]  876 	mov	dptr,#_ak820_macro_primitive
      0076D5 E0               [24]  877 	movx	a,@dptr
      0076D6 70 2F            [24]  878 	jnz	00104$
                                    879 ;	quantum/action.c:335: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      0076D8 90 0C 61         [24]  880 	mov	dptr,#_get_record_keycode_PARM_2
      0076DB 74 01            [12]  881 	mov	a,#0x01
      0076DD 12 54 8D         [24]  882 	lcall	_ak820_outline_0031
      0076E0 12 A4 5B         [24]  883 	lcall	_get_record_keycode
      0076E3 12 48 E9         [24]  884 	lcall	_ak820_outline_0127
      0076E6 90 08 94         [24]  885 	mov	dptr,#_process_record_record_10000_642
      0076E9 12 7D 7D         [24]  886 	lcall	_ak820_outline_0024
      0076EC 74 05            [12]  887 	mov	a,#0x05
      0076EE 2B               [12]  888 	add	a, r3
      0076EF FB               [12]  889 	mov	r3,a
      0076F0 E4               [12]  890 	clr	a
      0076F1 3C               [12]  891 	addc	a, r4
      0076F2 FC               [12]  892 	mov	r4,a
      0076F3 12 75 46         [24]  893 	lcall	_ak820_outline_0097
      0076F6 12 BE 79         [24]  894 	lcall	__gptrget
      0076F9 90 04 BE         [24]  895 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0076FC 12 48 CB         [24]  896 	lcall	_ak820_outline_0076
      0076FF 12 3B BD         [24]  897 	lcall	_ak820_dynamic_macro_process
      007702 E5 82            [12]  898 	mov	a, dpl
      007704 70 01            [24]  899 	jnz	00104$
      007706 22               [24]  900 	ret
      007707                        901 00104$:
                                    902 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007707 90 08 94         [24]  903 	mov	dptr,#_process_record_record_10000_642
      00770A 12 54 84         [24]  904 	lcall	_ak820_outline_0013
      00770D 8D 02            [24]  905 	mov	ar2,r5
      00770F 8E 03            [24]  906 	mov	ar3,r6
      007711 8F 04            [24]  907 	mov	ar4,r7
      007713 90 0E 0A         [24]  908 	mov	dptr,#___memcpy_PARM_2
      007716 EA               [12]  909 	mov	a,r2
      007717 12 7D E1         [24]  910 	lcall	_ak820_outline_0188
      00771A EC               [12]  911 	mov	a,r4
      00771B A3               [24]  912 	inc	dptr
      00771C F0               [24]  913 	movx	@dptr,a
      00771D 90 0E 0D         [24]  914 	mov	dptr,#___memcpy_PARM_3
      007720 12 54 C9         [24]  915 	lcall	_ak820_outline_0113
      007723 90 06 8A         [24]  916 	mov	dptr,#_ak820_tapping_source_PARM_1
      007726 F5 F0            [12]  917 	mov	b,a
      007728 C0 07            [24]  918 	push	ar7
      00772A C0 06            [24]  919 	push	ar6
      00772C C0 05            [24]  920 	push	ar5
      00772E 12 BD A0         [24]  921 	lcall	___memcpy
      007731 12 49 1A         [24]  922 	lcall	_ak820_tapping_source
      007734 AC 82            [24]  923 	mov	r4, dpl
      007736 D0 05            [24]  924 	pop	ar5
      007738 D0 06            [24]  925 	pop	ar6
      00773A D0 07            [24]  926 	pop	ar7
                                    927 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      00773C 74 05            [12]  928 	mov	a,#0x05
      00773E 12 7D 60         [24]  929 	lcall	_ak820_outline_0014
      007741 12 BE 79         [24]  930 	lcall	__gptrget
      007744 FB               [12]  931 	mov	r3,a
                                    932 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      007745 74 07            [12]  933 	mov	a,#0x07
      007747 2D               [12]  934 	add	a, r5
      007748 F8               [12]  935 	mov	r0,a
      007749 E4               [12]  936 	clr	a
      00774A 3E               [12]  937 	addc	a, r6
      00774B F9               [12]  938 	mov	r1,a
      00774C 8F 02            [24]  939 	mov	ar2,r7
      00774E 90 0C 61         [24]  940 	mov	dptr,#_get_record_keycode_PARM_2
      007751 74 01            [12]  941 	mov	a,#0x01
      007753 12 54 8D         [24]  942 	lcall	_ak820_outline_0031
      007756 C0 04            [24]  943 	push	ar4
      007758 C0 03            [24]  944 	push	ar3
      00775A C0 02            [24]  945 	push	ar2
      00775C C0 01            [24]  946 	push	ar1
      00775E C0 00            [24]  947 	push	ar0
      007760 12 A4 5B         [24]  948 	lcall	_get_record_keycode
      007763 12 48 E9         [24]  949 	lcall	_ak820_outline_0127
      007766 D0 00            [24]  950 	pop	ar0
      007768 D0 01            [24]  951 	pop	ar1
      00776A D0 02            [24]  952 	pop	ar2
      00776C D0 03            [24]  953 	pop	ar3
      00776E D0 04            [24]  954 	pop	ar4
      007770 12 3A F1         [24]  955 	lcall	_ak820_outline_0146
      007773 8A F0            [24]  956 	mov	b,r2
      007775 EE               [12]  957 	mov	a,r6
      007776 12 BE 3E         [24]  958 	lcall	__gptrput
      007779 A3               [24]  959 	inc	dptr
      00777A EF               [12]  960 	mov	a,r7
      00777B 12 BE 3E         [24]  961 	lcall	__gptrput
                                    962 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00777E 90 08 94         [24]  963 	mov	dptr,#_process_record_record_10000_642
      007781 12 54 84         [24]  964 	lcall	_ak820_outline_0013
      007784 74 07            [12]  965 	mov	a,#0x07
      007786 12 7D A7         [24]  966 	lcall	_ak820_outline_0082
      007789 12 BE 79         [24]  967 	lcall	__gptrget
      00778C F8               [12]  968 	mov	r0,a
      00778D A3               [24]  969 	inc	dptr
      00778E 12 BE 79         [24]  970 	lcall	__gptrget
      007791 F9               [12]  971 	mov	r1,a
      007792 90 06 9A         [24]  972 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007795 EC               [12]  973 	mov	a,r4
      007796 F0               [24]  974 	movx	@dptr,a
      007797 90 06 9B         [24]  975 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00779A EB               [12]  976 	mov	a,r3
      00779B F0               [24]  977 	movx	@dptr,a
      00779C 12 3A F1         [24]  978 	lcall	_ak820_outline_0146
      00779F C0 07            [24]  979 	push	ar7
      0077A1 C0 06            [24]  980 	push	ar6
      0077A3 C0 05            [24]  981 	push	ar5
      0077A5 C0 04            [24]  982 	push	ar4
      0077A7 C0 03            [24]  983 	push	ar3
      0077A9 12 4C 74         [24]  984 	lcall	_ak820_oneshot_process
      0077AC E5 82            [12]  985 	mov	a, dpl
      0077AE D0 03            [24]  986 	pop	ar3
      0077B0 D0 04            [24]  987 	pop	ar4
      0077B2 D0 05            [24]  988 	pop	ar5
      0077B4 D0 06            [24]  989 	pop	ar6
      0077B6 D0 07            [24]  990 	pop	ar7
      0077B8 70 01            [24]  991 	jnz	00109$
      0077BA 22               [24]  992 	ret
      0077BB                        993 00109$:
                                    994 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      0077BB 12 73 20         [24]  995 	lcall	_ak820_outline_0050
      0077BE C0 04            [24]  996 	push	ar4
      0077C0 C0 03            [24]  997 	push	ar3
      0077C2 12 A5 1C         [24]  998 	lcall	_process_record_quantum
      0077C5 E5 82            [12]  999 	mov	a, dpl
      0077C7 D0 03            [24] 1000 	pop	ar3
      0077C9 D0 04            [24] 1001 	pop	ar4
      0077CB 70 0A            [24] 1002 	jnz	00111$
                                   1003 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0077CD 90 06 02         [24] 1004 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0077D0 EB               [12] 1005 	mov	a,r3
      0077D1 F0               [24] 1006 	movx	@dptr,a
      0077D2 8C 82            [24] 1007 	mov	dpl, r4
                                   1008 ;	quantum/action.c:352: return;
      0077D4 02 2E BB         [24] 1009 	ljmp	_ak820_oneshot_post
      0077D7                       1010 00111$:
                                   1011 ;	quantum/action.c:356: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      0077D7 90 08 94         [24] 1012 	mov	dptr,#_process_record_record_10000_642
      0077DA 12 54 84         [24] 1013 	lcall	_ak820_outline_0013
      0077DD 74 01            [12] 1014 	mov	a,#0x01
      0077DF 12 7D A7         [24] 1015 	lcall	_ak820_outline_0082
      0077E2 12 BE 79         [24] 1016 	lcall	__gptrget
      0077E5 F8               [12] 1017 	mov	r0,a
      0077E6 B8 10 00         [24] 1018 	cjne	r0,#0x10,00200$
      0077E9                       1019 00200$:
      0077E9 50 21            [24] 1020 	jnc	00114$
      0077EB 12 73 20         [24] 1021 	lcall	_ak820_outline_0050
      0077EE 12 BE 79         [24] 1022 	lcall	__gptrget
      0077F1 FD               [12] 1023 	mov	r5,a
      0077F2 BD 08 00         [24] 1024 	cjne	r5,#0x08,00202$
      0077F5                       1025 00202$:
      0077F5 50 15            [24] 1026 	jnc	00114$
      0077F7 C0 04            [24] 1027 	push	ar4
      0077F9 C0 03            [24] 1028 	push	ar3
      0077FB 12 A7 BC         [24] 1029 	lcall	_get_repeat_key_count
      0077FE E5 82            [12] 1030 	mov	a, dpl
      007800 D0 03            [24] 1031 	pop	ar3
      007802 D0 04            [24] 1032 	pop	ar4
      007804 70 06            [24] 1033 	jnz	00114$
      007806 90 09 F0         [24] 1034 	mov	dptr,#_ak820_macro_primitive
      007809 E0               [24] 1035 	movx	a,@dptr
      00780A 60 05            [24] 1036 	jz	00115$
      00780C                       1037 00114$:
      00780C 75 27 00         [24] 1038 	mov	_process_record_sloc0_1_0,#0x00
      00780F 80 03            [24] 1039 	sjmp	00116$
      007811                       1040 00115$:
      007811 75 27 01         [24] 1041 	mov	_process_record_sloc0_1_0,#0x01
      007814                       1042 00116$:
      007814 90 04 BD         [24] 1043 	mov	dptr,#_ak820_dynamic_macro_source
      007817 E5 27            [12] 1044 	mov	a,_process_record_sloc0_1_0
      007819 F0               [24] 1045 	movx	@dptr,a
                                   1046 ;	quantum/action.c:358: process_record_handler(record);
      00781A 90 08 94         [24] 1047 	mov	dptr,#_process_record_record_10000_642
      00781D 12 54 5E         [24] 1048 	lcall	_ak820_outline_0001
      007820 C0 04            [24] 1049 	push	ar4
      007822 C0 03            [24] 1050 	push	ar3
      007824 11 42            [24] 1051 	acall	_process_record_handler
                                   1052 ;	quantum/action.c:360: ak820_dynamic_macro_source = false;
      007826 90 04 BD         [24] 1053 	mov	dptr,#_ak820_dynamic_macro_source
      007829 E4               [12] 1054 	clr	a
      00782A F0               [24] 1055 	movx	@dptr,a
                                   1056 ;	quantum/action.c:362: post_process_record_quantum(record);
      00782B 90 08 94         [24] 1057 	mov	dptr,#_process_record_record_10000_642
      00782E 12 54 5E         [24] 1058 	lcall	_ak820_outline_0001
      007831 12 A4 F3         [24] 1059 	lcall	_post_process_record_quantum
      007834 D0 03            [24] 1060 	pop	ar3
      007836 D0 04            [24] 1061 	pop	ar4
                                   1062 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007838 90 06 02         [24] 1063 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00783B EB               [12] 1064 	mov	a,r3
      00783C F0               [24] 1065 	movx	@dptr,a
      00783D 8C 82            [24] 1066 	mov	dpl, r4
                                   1067 ;	quantum/action.c:366: }
      00783F 02 2E BB         [24] 1068 	ljmp	_ak820_oneshot_post
                                   1069 ;------------------------------------------------------------
                                   1070 ;Allocation info for local variables in function 'process_record_handler'
                                   1071 ;------------------------------------------------------------
                                   1072 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_651'
                                   1073 ;record        Allocated with name '_process_record_handler_record_10000_652'
                                   1074 ;action        Allocated with name '_process_record_handler_action_10000_652'
                                   1075 ;------------------------------------------------------------
                                   1076 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                   1077 ;	-----------------------------------------
                                   1078 ;	 function process_record_handler
                                   1079 ;	-----------------------------------------
      007842                       1080 _process_record_handler:
      007842 12 48 A0         [24] 1081 	lcall	_ak820_outline_0036
      007845 90 08 97         [24] 1082 	mov	dptr,#_process_record_handler_record_argument_10000_651
      007848 12 3A 5F         [24] 1083 	lcall	_ak820_outline_0016
                                   1084 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00784B 90 08 97         [24] 1085 	mov	dptr,#_process_record_handler_record_argument_10000_651
      00784E 12 3A 3E         [24] 1086 	lcall	_ak820_outline_0008
                                   1087 ;	quantum/action.c:379: if (record->keycode) {
      007851 4C               [12] 1088 	orl	a,r4
      007852 60 19            [24] 1089 	jz	00102$
                                   1090 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      007854 12 3A D7         [24] 1091 	lcall	_ak820_outline_0126
      007857 C0 07            [24] 1092 	push	ar7
      007859 C0 06            [24] 1093 	push	ar6
      00785B 12 9A BA         [24] 1094 	lcall	_action_for_keycode
      00785E 12 48 FA         [24] 1095 	lcall	_ak820_outline_0151
      007861 D0 06            [24] 1096 	pop	ar6
      007863 D0 07            [24] 1097 	pop	ar7
      007865 90 08 9A         [24] 1098 	mov	dptr,#_process_record_handler_action_10000_652
      007868 12 3A 9E         [24] 1099 	lcall	_ak820_outline_0072
      00786B 80 2B            [24] 1100 	sjmp	00104$
      00786D                       1101 00102$:
                                   1102 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00786D 12 7D 6E         [24] 1103 	lcall	_ak820_outline_0021
      007870 7A 00            [12] 1104 	mov	r2,#0x00
      007872 12 48 F4         [24] 1105 	lcall	_ak820_outline_0144
      007875 12 48 8E         [24] 1106 	lcall	_ak820_outline_0012
      007878 E0               [24] 1107 	movx	a,@dptr
      007879 90 09 D6         [24] 1108 	mov	dptr,#_ak820_resolve_key_PARM_2
      00787C F0               [24] 1109 	movx	@dptr,a
      00787D 8D 82            [24] 1110 	mov	dpl, r5
      00787F 8C 83            [24] 1111 	mov	dph, r4
      007881 C0 07            [24] 1112 	push	ar7
      007883 C0 06            [24] 1113 	push	ar6
      007885 12 81 13         [24] 1114 	lcall	_ak820_resolve_key
      007888 12 9A BA         [24] 1115 	lcall	_action_for_keycode
      00788B 12 48 FA         [24] 1116 	lcall	_ak820_outline_0151
      00788E D0 06            [24] 1117 	pop	ar6
      007890 D0 07            [24] 1118 	pop	ar7
      007892 90 08 9A         [24] 1119 	mov	dptr,#_process_record_handler_action_10000_652
      007895 12 3A 9E         [24] 1120 	lcall	_ak820_outline_0072
                                   1121 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      007898                       1122 00104$:
                                   1123 ;	quantum/action.c:403: process_action(record, action);
      007898 7D 00            [12] 1124 	mov	r5,#0x00
      00789A 90 0E 0A         [24] 1125 	mov	dptr,#___memcpy_PARM_2
      00789D 74 9A            [12] 1126 	mov	a,#_process_record_handler_action_10000_652
      00789F F0               [24] 1127 	movx	@dptr,a
      0078A0 74 08            [12] 1128 	mov	a,#(_process_record_handler_action_10000_652 >> 8)
      0078A2 12 3A B0         [24] 1129 	lcall	_ak820_outline_0095
      0078A5 90 0E 0D         [24] 1130 	mov	dptr,#___memcpy_PARM_3
      0078A8 12 54 C9         [24] 1131 	lcall	_ak820_outline_0113
      0078AB 90 08 9C         [24] 1132 	mov	dptr,#_process_action_PARM_2
      0078AE F5 F0            [12] 1133 	mov	b,a
      0078B0 C0 07            [24] 1134 	push	ar7
      0078B2 C0 06            [24] 1135 	push	ar6
      0078B4 C0 05            [24] 1136 	push	ar5
      0078B6 12 BD A0         [24] 1137 	lcall	___memcpy
      0078B9 D0 05            [24] 1138 	pop	ar5
      0078BB D0 06            [24] 1139 	pop	ar6
      0078BD D0 07            [24] 1140 	pop	ar7
      0078BF 12 75 3F         [24] 1141 	lcall	_ak820_outline_0051
                                   1142 ;	quantum/action.c:404: }
      0078C2 01 C4            [24] 1143 	ajmp	_process_action
                                   1144 ;------------------------------------------------------------
                                   1145 ;Allocation info for local variables in function 'register_mouse'
                                   1146 ;------------------------------------------------------------
                                   1147 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1148 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_660'
                                   1149 ;------------------------------------------------------------
                                   1150 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1151 ;	-----------------------------------------
                                   1152 ;	 function process_action
                                   1153 ;	-----------------------------------------
      0078C4                       1154 _process_action:
      0078C4 12 48 A0         [24] 1155 	lcall	_ak820_outline_0036
      0078C7 90 08 9E         [24] 1156 	mov	dptr,#_process_action_record_argument_10000_663
      0078CA 12 3A 5F         [24] 1157 	lcall	_ak820_outline_0016
                                   1158 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0078CD 90 08 9E         [24] 1159 	mov	dptr,#_process_action_record_argument_10000_663
      0078D0 12 3A 34         [24] 1160 	lcall	_ak820_outline_0005
                                   1161 ;	quantum/action.c:475: pressed = record->event.pressed;
      0078D3 A3               [24] 1162 	inc	dptr
      0078D4 A3               [24] 1163 	inc	dptr
      0078D5 A3               [24] 1164 	inc	dptr
      0078D6 A3               [24] 1165 	inc	dptr
      0078D7 A3               [24] 1166 	inc	dptr
      0078D8 E0               [24] 1167 	movx	a,@dptr
      0078D9 F5 28            [12] 1168 	mov	_process_action_sloc0_1_0,a
                                   1169 ;	quantum/action.c:499: switch (action.kind.id) {
      0078DB 90 08 9D         [24] 1170 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078DE E0               [24] 1171 	movx	a,@dptr
      0078DF C4               [12] 1172 	swap	a
      0078E0 54 0F            [12] 1173 	anl	a,#0x0f
      0078E2 FD               [12] 1174 	mov  r5,a
      0078E3 24 F4            [12] 1175 	add	a,#0xff - 0x0b
      0078E5 50 03            [24] 1176 	jnc	00434$
      0078E7 02 7B 65         [24] 1177 	ljmp	00181$
      0078EA                       1178 00434$:
                                   1179 ;	free result
      0078EA ED               [12] 1180 	mov	a,r5
      0078EB 24 0A            [12] 1181 	add	a,#(00435$-3-.)
      0078ED 83               [24] 1182 	movc	a,@a+pc
      0078EE F5 82            [12] 1183 	mov	dpl,a
      0078F0 ED               [12] 1184 	mov	a,r5
      0078F1 24 10            [12] 1185 	add	a,#(00436$-3-.)
      0078F3 83               [24] 1186 	movc	a,@a+pc
      0078F4 F5 83            [12] 1187 	mov	dph,a
      0078F6 E4               [12] 1188 	clr	a
      0078F7 73               [24] 1189 	jmp	@a+dptr
      0078F8                       1190 00435$:
      0078F8 10                    1191 	.db	00102$
      0078F9 10                    1192 	.db	00102$
      0078FA 65                    1193 	.db	00181$
      0078FB 65                    1194 	.db	00181$
      0078FC 9A                    1195 	.db	00123$
      0078FD 65                    1196 	.db	00181$
      0078FE 65                    1197 	.db	00181$
      0078FF 65                    1198 	.db	00181$
      007900 FA                    1199 	.db	00131$
      007901 CC                    1200 	.db	00147$
      007902 F2                    1201 	.db	00152$
      007903 F2                    1202 	.db	00152$
      007904                       1203 00436$:
      007904 79                    1204 	.db	00102$>>8
      007905 79                    1205 	.db	00102$>>8
      007906 7B                    1206 	.db	00181$>>8
      007907 7B                    1207 	.db	00181$>>8
      007908 79                    1208 	.db	00123$>>8
      007909 7B                    1209 	.db	00181$>>8
      00790A 7B                    1210 	.db	00181$>>8
      00790B 7B                    1211 	.db	00181$>>8
      00790C 79                    1212 	.db	00131$>>8
      00790D 7A                    1213 	.db	00147$>>8
      00790E 7A                    1214 	.db	00152$>>8
      00790F 7A                    1215 	.db	00152$>>8
                                   1216 ;	quantum/action.c:502: case ACT_RMODS: {
      007910                       1217 00102$:
                                   1218 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007910 90 08 9D         [24] 1219 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007913 E0               [24] 1220 	movx	a,@dptr
      007914 54 F0            [12] 1221 	anl	a,#0xf0
      007916 70 06            [24] 1222 	jnz	00194$
      007918 12 7D BE         [24] 1223 	lcall	_ak820_outline_0115
      00791B FD               [12] 1224 	mov	r5,a
      00791C 80 07            [24] 1225 	sjmp	00195$
      00791E                       1226 00194$:
      00791E 12 7D BE         [24] 1227 	lcall	_ak820_outline_0115
      007921 C4               [12] 1228 	swap	a
      007922 54 F0            [12] 1229 	anl	a,#0xf0
      007924 FD               [12] 1230 	mov	r5,a
      007925                       1231 00195$:
                                   1232 ;	quantum/action.c:505: if (pressed) {
      007925 E5 28            [12] 1233 	mov	a,_process_action_sloc0_1_0
      007927 60 35            [24] 1234 	jz	00119$
                                   1235 ;	quantum/action.c:506: if (mods) {
      007929 ED               [12] 1236 	mov	a,r5
      00792A 60 29            [24] 1237 	jz	00110$
                                   1238 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00792C 12 7D D0         [24] 1239 	lcall	_ak820_outline_0161
      00792F FC               [12] 1240 	mov	r4,a
      007930 BC E0 00         [24] 1241 	cjne	r4,#0xe0,00440$
      007933                       1242 00440$:
      007933 40 07            [24] 1243 	jc	00108$
      007935 12 7D D0         [24] 1244 	lcall	_ak820_outline_0161
      007938 24 18            [12] 1245 	add	a,#0xff - 0xe7
      00793A 50 0A            [24] 1246 	jnc	00104$
                                   1247 ;	free result
      00793C                       1248 00108$:
      00793C 7B 9C            [12] 1249 	mov	r3,#_process_action_PARM_2
      00793E 7C 08            [12] 1250 	mov	r4,#(_process_action_PARM_2 >> 8)
      007940 12 36 47         [24] 1251 	lcall	_ak820_outline_0125
      007943 E0               [24] 1252 	movx	a,@dptr
      007944 70 07            [24] 1253 	jnz	00105$
      007946                       1254 00104$:
                                   1255 ;	quantum/action.c:511: add_owned_mods(mods);
      007946 8D 82            [24] 1256 	mov	dpl, r5
      007948 12 83 29         [24] 1257 	lcall	_add_owned_mods
      00794B 80 05            [24] 1258 	sjmp	00106$
      00794D                       1259 00105$:
                                   1260 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      00794D 8D 82            [24] 1261 	mov	dpl, r5
      00794F 12 83 45         [24] 1262 	lcall	_add_owned_weak_mods
      007952                       1263 00106$:
                                   1264 ;	quantum/action.c:515: send_keyboard_report();
      007952 12 86 62         [24] 1265 	lcall	_send_keyboard_report
      007955                       1266 00110$:
                                   1267 ;	quantum/action.c:517: register_code(action.key.code);
      007955 12 7D A0         [24] 1268 	lcall	_ak820_outline_0079
      007958 12 7B 7C         [24] 1269 	lcall	_register_code
      00795B 02 7B 65         [24] 1270 	ljmp	00181$
      00795E                       1271 00119$:
                                   1272 ;	quantum/action.c:519: unregister_code(action.key.code);
      00795E 12 7D A0         [24] 1273 	lcall	_ak820_outline_0079
      007961 C0 05            [24] 1274 	push	ar5
      007963 12 7B F8         [24] 1275 	lcall	_unregister_code
      007966 D0 05            [24] 1276 	pop	ar5
                                   1277 ;	quantum/action.c:520: if (mods) {
      007968 ED               [12] 1278 	mov	a,r5
      007969 70 03            [24] 1279 	jnz	00444$
      00796B 02 7B 65         [24] 1280 	ljmp	00181$
      00796E                       1281 00444$:
                                   1282 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00796E 12 7D D0         [24] 1283 	lcall	_ak820_outline_0161
      007971 FC               [12] 1284 	mov	r4,a
      007972 BC E0 00         [24] 1285 	cjne	r4,#0xe0,00445$
      007975                       1286 00445$:
      007975 40 07            [24] 1287 	jc	00115$
      007977 12 7D D0         [24] 1288 	lcall	_ak820_outline_0161
      00797A 24 18            [12] 1289 	add	a,#0xff - 0xe7
      00797C 50 0A            [24] 1290 	jnc	00111$
                                   1291 ;	free result
      00797E                       1292 00115$:
      00797E 7B 9C            [12] 1293 	mov	r3,#_process_action_PARM_2
      007980 7C 08            [12] 1294 	mov	r4,#(_process_action_PARM_2 >> 8)
      007982 12 36 47         [24] 1295 	lcall	_ak820_outline_0125
      007985 E0               [24] 1296 	movx	a,@dptr
      007986 70 07            [24] 1297 	jnz	00112$
      007988                       1298 00111$:
                                   1299 ;	quantum/action.c:522: del_owned_mods(mods);
      007988 8D 82            [24] 1300 	mov	dpl, r5
      00798A 12 83 38         [24] 1301 	lcall	_del_owned_mods
      00798D 80 05            [24] 1302 	sjmp	00113$
      00798F                       1303 00112$:
                                   1304 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      00798F 8D 82            [24] 1305 	mov	dpl, r5
      007991 12 83 54         [24] 1306 	lcall	_del_owned_weak_mods
      007994                       1307 00113$:
                                   1308 ;	quantum/action.c:526: send_keyboard_report();
      007994 12 86 62         [24] 1309 	lcall	_send_keyboard_report
                                   1310 ;	quantum/action.c:529: } break;
      007997 02 7B 65         [24] 1311 	ljmp	00181$
                                   1312 ;	quantum/action.c:606: case ACT_USAGE:
      00799A                       1313 00123$:
                                   1314 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00799A 74 07            [12] 1315 	mov	a,#0x07
      00799C 12 3A 71         [24] 1316 	lcall	_ak820_outline_0022
      00799F 12 4D AC         [24] 1317 	lcall	_ak820_outline_0009
      0079A2 C3               [12] 1318 	clr	c
      0079A3 EC               [12] 1319 	mov	a,r4
      0079A4 94 A5            [12] 1320 	subb	a,#0xa5
      0079A6 ED               [12] 1321 	mov	a,r5
      0079A7 94 00            [12] 1322 	subb	a,#0x00
      0079A9 40 15            [24] 1323 	jc	00125$
      0079AB 74 C2            [12] 1324 	mov	a,#0xc2
      0079AD 9C               [12] 1325 	subb	a,r4
      0079AE E4               [12] 1326 	clr	a
      0079AF 9D               [12] 1327 	subb	a,r5
      0079B0 40 0E            [24] 1328 	jc	00125$
                                   1329 ;	free result
                                   1330 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      0079B2 90 0A FD         [24] 1331 	mov	dptr,#_owned_usage_key_PARM_2
      0079B5 E5 28            [12] 1332 	mov	a,_process_action_sloc0_1_0
      0079B7 F0               [24] 1333 	movx	@dptr,a
      0079B8 8E 82            [24] 1334 	mov	dpl, r6
      0079BA 12 85 0F         [24] 1335 	lcall	_owned_usage_key
                                   1336 ;	quantum/action.c:614: break;
      0079BD 02 7B 65         [24] 1337 	ljmp	00181$
      0079C0                       1338 00125$:
                                   1339 ;	quantum/action.c:617: switch (action.usage.page) {
      0079C0 12 7D B5         [24] 1340 	lcall	_ak820_outline_0091
      0079C3 FF               [12] 1341 	mov	r7,a
      0079C4 60 08            [24] 1342 	jz	00127$
      0079C6 BF 01 02         [24] 1343 	cjne	r7,#0x01,00452$
      0079C9 80 19            [24] 1344 	sjmp	00128$
      0079CB                       1345 00452$:
      0079CB 02 7B 65         [24] 1346 	ljmp	00181$
                                   1347 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0079CE                       1348 00127$:
                                   1349 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0079CE E5 28            [12] 1350 	mov	a,_process_action_sloc0_1_0
      0079D0 60 05            [24] 1351 	jz	00196$
      0079D2 12 7D C5         [24] 1352 	lcall	_ak820_outline_0133
      0079D5 80 04            [24] 1353 	sjmp	00197$
      0079D7                       1354 00196$:
      0079D7 7E 00            [12] 1355 	mov	r6,#0x00
      0079D9 7F 00            [12] 1356 	mov	r7,#0x00
      0079DB                       1357 00197$:
      0079DB 12 3A CC         [24] 1358 	lcall	_ak820_outline_0120
      0079DE 12 72 AC         [24] 1359 	lcall	_host_system_send
                                   1360 ;	quantum/action.c:620: break;
      0079E1 02 7B 65         [24] 1361 	ljmp	00181$
                                   1362 ;	quantum/action.c:621: case PAGE_CONSUMER:
      0079E4                       1363 00128$:
                                   1364 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      0079E4 E5 28            [12] 1365 	mov	a,_process_action_sloc0_1_0
      0079E6 60 05            [24] 1366 	jz	00198$
      0079E8 12 7D C5         [24] 1367 	lcall	_ak820_outline_0133
      0079EB 80 04            [24] 1368 	sjmp	00199$
      0079ED                       1369 00198$:
      0079ED 7E 00            [12] 1370 	mov	r6,#0x00
      0079EF 7F 00            [12] 1371 	mov	r7,#0x00
      0079F1                       1372 00199$:
      0079F1 12 3A CC         [24] 1373 	lcall	_ak820_outline_0120
      0079F4 12 72 DB         [24] 1374 	lcall	_host_consumer_send
                                   1375 ;	quantum/action.c:625: break;
      0079F7 02 7B 65         [24] 1376 	ljmp	00181$
                                   1377 ;	quantum/action.c:632: case ACT_LAYER: {
      0079FA                       1378 00131$:
                                   1379 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0079FA 90 08 9D         [24] 1380 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079FD E0               [24] 1381 	movx	a,@dptr
      0079FE 54 03            [12] 1382 	anl	a,#0x03
      007A00 90 08 A1         [24] 1383 	mov	dptr,#_process_action_on_40000_686
      007A03 F0               [24] 1384 	movx	@dptr,a
                                   1385 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007A04 E0               [24] 1386 	movx	a,@dptr
      007A05 FF               [12] 1387 	mov	r7,a
      007A06 60 11            [24] 1388 	jz	00200$
      007A08 E5 28            [12] 1389 	mov	a,_process_action_sloc0_1_0
      007A0A 60 07            [24] 1390 	jz	00202$
      007A0C 8F 06            [24] 1391 	mov	ar6,r7
      007A0E 53 06 01         [24] 1392 	anl	ar6,#0x01
      007A11 80 10            [24] 1393 	sjmp	00201$
      007A13                       1394 00202$:
      007A13 74 02            [12] 1395 	mov	a,#0x02
      007A15 5F               [12] 1396 	anl	a,r7
      007A16 FE               [12] 1397 	mov	r6,a
      007A17 80 0A            [24] 1398 	sjmp	00201$
      007A19                       1399 00200$:
      007A19 E5 28            [12] 1400 	mov	a,_process_action_sloc0_1_0
      007A1B B4 01 00         [24] 1401 	cjne	a,#0x01,00457$
      007A1E                       1402 00457$:
      007A1E 92 22            [24] 1403 	mov  _process_action_sloc1_1_0,c
      007A20 E4               [12] 1404 	clr	a
      007A21 33               [12] 1405 	rlc	a
      007A22 FE               [12] 1406 	mov	r6,a
      007A23                       1407 00201$:
      007A23 EE               [12] 1408 	mov	a,r6
      007A24 70 03            [24] 1409 	jnz	00458$
      007A26 02 7B 65         [24] 1410 	ljmp	00181$
      007A29                       1411 00458$:
                                   1412 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007A29 12 7D D0         [24] 1413 	lcall	_ak820_outline_0161
      007A2C C4               [12] 1414 	swap	a
      007A2D 03               [12] 1415 	rr	a
      007A2E 54 07            [12] 1416 	anl	a,#0x07
      007A30 25 E0            [12] 1417 	add	a,acc
      007A32 25 E0            [12] 1418 	add	a,acc
      007A34 FF               [12] 1419 	mov	r7,a
                                   1420 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007A35 12 7D D0         [24] 1421 	lcall	_ak820_outline_0161
      007A38 54 0F            [12] 1422 	anl	a,#0x0f
      007A3A FE               [12] 1423 	mov	r6,a
      007A3B 8F F0            [24] 1424 	mov	b,r7
      007A3D 05 F0            [12] 1425 	inc	b
      007A3F EE               [12] 1426 	mov	a,r6
      007A40 80 02            [24] 1427 	sjmp	00460$
      007A42                       1428 00459$:
      007A42 25 E0            [12] 1429 	add	a,acc
      007A44                       1430 00460$:
      007A44 D5 F0 FB         [24] 1431 	djnz	b,00459$
      007A47 FE               [12] 1432 	mov	r6,a
                                   1433 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007A48 12 7D D0         [24] 1434 	lcall	_ak820_outline_0161
      007A4B 30 E4 11         [24] 1435 	jnb	acc.4,00204$
      007A4E 8F F0            [24] 1436 	mov	b,r7
      007A50 05 F0            [12] 1437 	inc	b
      007A52 74 0F            [12] 1438 	mov	a,#0x0f
      007A54 80 02            [24] 1439 	sjmp	00463$
      007A56                       1440 00462$:
      007A56 25 E0            [12] 1441 	add	a,acc
      007A58                       1442 00463$:
      007A58 D5 F0 FB         [24] 1443 	djnz	b,00462$
      007A5B F4               [12] 1444 	cpl	a
      007A5C FF               [12] 1445 	mov	r7,a
      007A5D 80 02            [24] 1446 	sjmp	00205$
      007A5F                       1447 00204$:
      007A5F 7F 00            [12] 1448 	mov	r7,#0x00
      007A61                       1449 00205$:
                                   1450 ;	quantum/action.c:640: bits |= mask;
      007A61 EE               [12] 1451 	mov	a,r6
      007A62 42 07            [12] 1452 	orl	ar7,a
                                   1453 ;	quantum/action.c:641: if (!on) {
      007A64 90 08 A1         [24] 1454 	mov	dptr,#_process_action_on_40000_686
      007A67 E0               [24] 1455 	movx	a,@dptr
      007A68 70 31            [24] 1456 	jnz	00143$
                                   1457 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007A6A 12 7D B5         [24] 1458 	lcall	_ak820_outline_0091
      007A6D FE               [12] 1459 	mov	r6,a
      007A6E 2E               [12] 1460 	add	a,r6
                                   1461 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007A6F 90 7A 73         [24] 1462 	mov	dptr,#00465$
      007A72 73               [24] 1463 	jmp	@a+dptr
      007A73                       1464 00465$:
      007A73 80 06            [24] 1465 	sjmp	00132$
      007A75 80 0C            [24] 1466 	sjmp	00133$
      007A77 80 12            [24] 1467 	sjmp	00134$
      007A79 80 18            [24] 1468 	sjmp	00135$
      007A7B                       1469 00132$:
      007A7B 8F 82            [24] 1470 	mov	dpl, r7
      007A7D 12 7E 30         [24] 1471 	lcall	_default_layer_and
      007A80 02 7B 65         [24] 1472 	ljmp	00181$
                                   1473 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      007A83                       1474 00133$:
      007A83 8F 82            [24] 1475 	mov	dpl, r7
      007A85 12 7E 20         [24] 1476 	lcall	_default_layer_or
      007A88 02 7B 65         [24] 1477 	ljmp	00181$
                                   1478 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007A8B                       1479 00134$:
      007A8B 8F 82            [24] 1480 	mov	dpl, r7
      007A8D 12 7E 45         [24] 1481 	lcall	_default_layer_xor
      007A90 02 7B 65         [24] 1482 	ljmp	00181$
                                   1483 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      007A93                       1484 00135$:
      007A93 8F 82            [24] 1485 	mov	dpl, r7
      007A95 12 7E 16         [24] 1486 	lcall	_default_layer_set
                                   1487 ;	quantum/action.c:647: }
      007A98 02 7B 65         [24] 1488 	ljmp	00181$
      007A9B                       1489 00143$:
                                   1490 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007A9B 12 7D B5         [24] 1491 	lcall	_ak820_outline_0091
      007A9E FE               [12] 1492 	mov	r6,a
      007A9F 2E               [12] 1493 	add	a,r6
                                   1494 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007AA0 90 7A A4         [24] 1495 	mov	dptr,#00466$
      007AA3 73               [24] 1496 	jmp	@a+dptr
      007AA4                       1497 00466$:
      007AA4 80 06            [24] 1498 	sjmp	00137$
      007AA6 80 0C            [24] 1499 	sjmp	00138$
      007AA8 80 12            [24] 1500 	sjmp	00139$
      007AAA 80 18            [24] 1501 	sjmp	00140$
      007AAC                       1502 00137$:
      007AAC 8F 82            [24] 1503 	mov	dpl, r7
      007AAE 12 7F BE         [24] 1504 	lcall	_layer_and
      007AB1 02 7B 65         [24] 1505 	ljmp	00181$
                                   1506 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      007AB4                       1507 00138$:
      007AB4 8F 82            [24] 1508 	mov	dpl, r7
      007AB6 12 7F AD         [24] 1509 	lcall	_layer_or
      007AB9 02 7B 65         [24] 1510 	ljmp	00181$
                                   1511 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007ABC                       1512 00139$:
      007ABC 8F 82            [24] 1513 	mov	dpl, r7
      007ABE 12 7F D4         [24] 1514 	lcall	_layer_xor
      007AC1 02 7B 65         [24] 1515 	ljmp	00181$
                                   1516 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007AC4                       1517 00140$:
      007AC4 8F 82            [24] 1518 	mov	dpl, r7
      007AC6 12 7F 4F         [24] 1519 	lcall	_layer_state_set
                                   1520 ;	quantum/action.c:657: break;
      007AC9 02 7B 65         [24] 1521 	ljmp	00181$
                                   1522 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007ACC                       1523 00147$:
                                   1524 ;	quantum/action.c:660: if (pressed) {
      007ACC E5 28            [12] 1525 	mov	a,_process_action_sloc0_1_0
      007ACE 60 11            [24] 1526 	jz	00149$
                                   1527 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007AD0 12 7D BE         [24] 1528 	lcall	_ak820_outline_0115
      007AD3 F5 82            [12] 1529 	mov	dpl,a
      007AD5 12 7E B3         [24] 1530 	lcall	_layer_hold_on
                                   1531 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      007AD8 12 7D A0         [24] 1532 	lcall	_ak820_outline_0079
      007ADB 12 7C B7         [24] 1533 	lcall	_register_mods
      007ADE 02 7B 65         [24] 1534 	ljmp	00181$
      007AE1                       1535 00149$:
                                   1536 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007AE1 12 7D A0         [24] 1537 	lcall	_ak820_outline_0079
      007AE4 12 7C CB         [24] 1538 	lcall	_unregister_mods
                                   1539 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      007AE7 12 7D BE         [24] 1540 	lcall	_ak820_outline_0115
      007AEA F5 82            [12] 1541 	mov	dpl,a
      007AEC 12 7E EA         [24] 1542 	lcall	_layer_hold_off
                                   1543 ;	quantum/action.c:667: break;
      007AEF 02 7B 65         [24] 1544 	ljmp	00181$
                                   1545 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007AF2                       1546 00152$:
                                   1547 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007AF2 12 7D D0         [24] 1548 	lcall	_ak820_outline_0161
      007AF5 FF               [12] 1549 	mov	r7,a
      007AF6 BF F1 02         [24] 1550 	cjne	r7,#0xf1,00468$
      007AF9 80 0A            [24] 1551 	sjmp	00154$
      007AFB                       1552 00468$:
      007AFB BF F2 02         [24] 1553 	cjne	r7,#0xf2,00469$
      007AFE 80 19            [24] 1554 	sjmp	00155$
      007B00                       1555 00469$:
                                   1556 ;	quantum/action.c:686: momentary_layer_action:
      007B00 BF F3 3B         [24] 1557 	cjne	r7,#0xf3,00160$
      007B03 80 28            [24] 1558 	sjmp	00156$
      007B05                       1559 00154$:
                                   1560 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007B05 E5 28            [12] 1561 	mov	a,_process_action_sloc0_1_0
      007B07 60 08            [24] 1562 	jz	00206$
      007B09 12 7D 86         [24] 1563 	lcall	_ak820_outline_0042
      007B0C 12 7E B3         [24] 1564 	lcall	_layer_hold_on
      007B0F 80 54            [24] 1565 	sjmp	00181$
      007B11                       1566 00206$:
      007B11 12 7D 86         [24] 1567 	lcall	_ak820_outline_0042
      007B14 12 7E EA         [24] 1568 	lcall	_layer_hold_off
                                   1569 ;	quantum/action.c:688: break;
                                   1570 ;	quantum/action.c:689: case OP_OFF_ON:
      007B17 80 4C            [24] 1571 	sjmp	00181$
      007B19                       1572 00155$:
                                   1573 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007B19 E5 28            [12] 1574 	mov	a,_process_action_sloc0_1_0
      007B1B 60 08            [24] 1575 	jz	00208$
      007B1D 12 7D 86         [24] 1576 	lcall	_ak820_outline_0042
      007B20 12 7F 90         [24] 1577 	lcall	_layer_off
      007B23 80 40            [24] 1578 	sjmp	00181$
      007B25                       1579 00208$:
      007B25 12 7D 86         [24] 1580 	lcall	_ak820_outline_0042
      007B28 12 7F 76         [24] 1581 	lcall	_layer_on
                                   1582 ;	quantum/action.c:691: break;
                                   1583 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007B2B 80 38            [24] 1584 	sjmp	00181$
      007B2D                       1585 00156$:
                                   1586 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007B2D E5 28            [12] 1587 	mov	a,_process_action_sloc0_1_0
      007B2F 60 08            [24] 1588 	jz	00210$
      007B31 12 7D 86         [24] 1589 	lcall	_ak820_outline_0042
      007B34 12 7F 61         [24] 1590 	lcall	_layer_move
      007B37 80 2C            [24] 1591 	sjmp	00181$
      007B39                       1592 00210$:
      007B39 12 7F 5C         [24] 1593 	lcall	_layer_clear
                                   1594 ;	quantum/action.c:694: break;
                                   1595 ;	quantum/action.c:740: default:
      007B3C 80 27            [24] 1596 	sjmp	00181$
      007B3E                       1597 00160$:
                                   1598 ;	quantum/action.c:747: if (pressed) {
      007B3E E5 28            [12] 1599 	mov	a,_process_action_sloc0_1_0
      007B40 60 08            [24] 1600 	jz	00163$
                                   1601 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      007B42 12 7D A0         [24] 1602 	lcall	_ak820_outline_0079
      007B45 12 7B 7C         [24] 1603 	lcall	_register_code
                                   1604 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007B48 80 1B            [24] 1605 	sjmp	00181$
      007B4A                       1606 00163$:
                                   1607 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007B4A 12 7D D0         [24] 1608 	lcall	_ak820_outline_0161
      007B4D FF               [12] 1609 	mov	r7,a
      007B4E BF 39 0E         [24] 1610 	cjne	r7,#0x39,00175$
                                   1611 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007B51 7F 50            [12] 1612 	mov	r7,#0x50
      007B53                       1613 00187$:
      007B53 EF               [12] 1614 	mov	a,r7
      007B54 60 09            [24] 1615 	jz	00175$
      007B56 90 00 01         [24] 1616 	mov	dptr,#0x0001
      007B59 12 5E 38         [24] 1617 	lcall	_mDelaymS
      007B5C 1F               [12] 1618 	dec	r7
                                   1619 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007B5D 80 F4            [24] 1620 	sjmp	00187$
      007B5F                       1621 00175$:
                                   1622 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007B5F 12 7D A0         [24] 1623 	lcall	_ak820_outline_0079
      007B62 12 7B F8         [24] 1624 	lcall	_unregister_code
                                   1625 ;	quantum/action.c:840: }
      007B65                       1626 00181$:
                                   1627 ;	quantum/action.c:861: switch (action.kind.id) {
      007B65 90 08 9D         [24] 1628 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B68 E0               [24] 1629 	movx	a,@dptr
      007B69 C4               [12] 1630 	swap	a
      007B6A 54 0F            [12] 1631 	anl	a,#0x0f
      007B6C FF               [12] 1632 	mov	r7,a
      007B6D BF 08 02         [24] 1633 	cjne	r7,#0x08,00478$
      007B70 80 03            [24] 1634 	sjmp	00183$
      007B72                       1635 00478$:
      007B72 BF 09 06         [24] 1636 	cjne	r7,#0x09,00192$
                                   1637 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      007B75                       1638 00183$:
                                   1639 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      007B75 12 72 11         [24] 1640 	lcall	_host_keyboard_leds
                                   1641 ;	quantum/action.c:872: }
                                   1642 ;	quantum/action.c:925: }
      007B78 02 9D 6D         [24] 1643 	ljmp	_led_set
      007B7B                       1644 00192$:
      007B7B 22               [24] 1645 	ret
                                   1646 ;------------------------------------------------------------
                                   1647 ;Allocation info for local variables in function 'register_code'
                                   1648 ;------------------------------------------------------------
                                   1649 ;code          Allocated with name '_register_code_code_10000_720'
                                   1650 ;------------------------------------------------------------
                                   1651 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1652 ;	-----------------------------------------
                                   1653 ;	 function register_code
                                   1654 ;	-----------------------------------------
      007B7C                       1655 _register_code:
      007B7C E5 82            [12] 1656 	mov	a,dpl
      007B7E 90 08 A2         [24] 1657 	mov	dptr,#_register_code_code_10000_720
      007B81 F0               [24] 1658 	movx	@dptr,a
                                   1659 ;	quantum/action.c:932: if (code == KC_NO) {
      007B82 E0               [24] 1660 	movx	a,@dptr
      007B83 FF               [12] 1661 	mov	r7,a
      007B84 70 01            [24] 1662 	jnz	00123$
                                   1663 ;	quantum/action.c:933: return;
      007B86 22               [24] 1664 	ret
      007B87                       1665 00123$:
                                   1666 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      007B87 BF 04 00         [24] 1667 	cjne	r7,#0x04,00186$
      007B8A                       1668 00186$:
      007B8A 40 21            [24] 1669 	jc	00119$
      007B8C EF               [12] 1670 	mov	a,r7
      007B8D 24 5B            [12] 1671 	add	a,#0xff - 0xa4
      007B8F 40 1C            [24] 1672 	jc	00119$
                                   1673 ;	free result
                                   1674 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007B91 8F 82            [24] 1675 	mov	dpl, r7
      007B93 C0 07            [24] 1676 	push	ar7
      007B95 12 83 C8         [24] 1677 	lcall	_add_owned_key
      007B98 E5 82            [12] 1678 	mov	a, dpl
      007B9A D0 07            [24] 1679 	pop	ar7
      007B9C 70 01            [24] 1680 	jnz	00104$
      007B9E 22               [24] 1681 	ret
      007B9F                       1682 00104$:
                                   1683 ;	quantum/action.c:975: ak820_dynamic_macro_observe(code, true);
      007B9F 90 04 C1         [24] 1684 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007BA2 74 01            [12] 1685 	mov	a,#0x01
      007BA4 F0               [24] 1686 	movx	@dptr,a
      007BA5 8F 82            [24] 1687 	mov	dpl, r7
      007BA7 12 3C 7B         [24] 1688 	lcall	_ak820_dynamic_macro_observe
                                   1689 ;	quantum/action.c:987: send_keyboard_report();
      007BAA 02 86 62         [24] 1690 	ljmp	_send_keyboard_report
      007BAD                       1691 00119$:
                                   1692 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007BAD 12 7D D5         [24] 1693 	lcall	_ak820_outline_0169
      007BB0 BF E0 00         [24] 1694 	cjne	r7,#0xe0,00190$
      007BB3                       1695 00190$:
      007BB3 40 1A            [24] 1696 	jc	00115$
      007BB5 EF               [12] 1697 	mov	a,r7
      007BB6 24 18            [12] 1698 	add	a,#0xff - 0xe7
      007BB8 40 15            [24] 1699 	jc	00115$
                                   1700 ;	free result
                                   1701 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007BBA 74 07            [12] 1702 	mov	a,#0x07
      007BBC 5F               [12] 1703 	anl	a,r7
      007BBD 12 7D 8F         [24] 1704 	lcall	_ak820_outline_0063
      007BC0 80 02            [24] 1705 	sjmp	00194$
      007BC2                       1706 00193$:
      007BC2 25 E0            [12] 1707 	add	a,acc
      007BC4                       1708 00194$:
      007BC4 D5 F0 FB         [24] 1709 	djnz	b,00193$
      007BC7 F5 82            [12] 1710 	mov	dpl,a
      007BC9 12 83 29         [24] 1711 	lcall	_add_owned_mods
                                   1712 ;	quantum/action.c:990: send_keyboard_report();
      007BCC 02 86 62         [24] 1713 	ljmp	_send_keyboard_report
      007BCF                       1714 00115$:
                                   1715 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007BCF 12 7D D5         [24] 1716 	lcall	_ak820_outline_0169
      007BD2 BF A5 00         [24] 1717 	cjne	r7,#0xa5,00195$
      007BD5                       1718 00195$:
      007BD5 40 05            [24] 1719 	jc	00113$
      007BD7 EF               [12] 1720 	mov	a,r7
      007BD8 24 58            [12] 1721 	add	a,#0xff - 0xa7
      007BDA 50 0D            [24] 1722 	jnc	00108$
                                   1723 ;	free result
      007BDC                       1724 00113$:
      007BDC 12 7D D5         [24] 1725 	lcall	_ak820_outline_0169
      007BDF BF A8 00         [24] 1726 	cjne	r7,#0xa8,00198$
      007BE2                       1727 00198$:
      007BE2 40 13            [24] 1728 	jc	00125$
      007BE4 EF               [12] 1729 	mov	a,r7
      007BE5 24 3D            [12] 1730 	add	a,#0xff - 0xc2
      007BE7 40 0E            [24] 1731 	jc	00125$
                                   1732 ;	free result
      007BE9                       1733 00108$:
                                   1734 ;	quantum/action.c:995: owned_usage_key(code, true);
      007BE9 12 7D D5         [24] 1735 	lcall	_ak820_outline_0169
      007BEC 90 0A FD         [24] 1736 	mov	dptr,#_owned_usage_key_PARM_2
      007BEF 74 01            [12] 1737 	mov	a,#0x01
      007BF1 F0               [24] 1738 	movx	@dptr,a
      007BF2 8F 82            [24] 1739 	mov	dpl, r7
                                   1740 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1741 ;	quantum/action.c:1005: }
      007BF4 02 85 0F         [24] 1742 	ljmp	_owned_usage_key
      007BF7                       1743 00125$:
      007BF7 22               [24] 1744 	ret
                                   1745 ;------------------------------------------------------------
                                   1746 ;Allocation info for local variables in function 'unregister_code'
                                   1747 ;------------------------------------------------------------
                                   1748 ;code          Allocated with name '_unregister_code_code_10000_734'
                                   1749 ;------------------------------------------------------------
                                   1750 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1751 ;	-----------------------------------------
                                   1752 ;	 function unregister_code
                                   1753 ;	-----------------------------------------
      007BF8                       1754 _unregister_code:
      007BF8 E5 82            [12] 1755 	mov	a,dpl
      007BFA 90 08 A3         [24] 1756 	mov	dptr,#_unregister_code_code_10000_734
      007BFD F0               [24] 1757 	movx	@dptr,a
                                   1758 ;	quantum/action.c:1012: if (code == KC_NO) {
      007BFE E0               [24] 1759 	movx	a,@dptr
      007BFF FF               [12] 1760 	mov	r7,a
      007C00 70 01            [24] 1761 	jnz	00121$
                                   1762 ;	quantum/action.c:1013: return;
      007C02 22               [24] 1763 	ret
      007C03                       1764 00121$:
                                   1765 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      007C03 BF 04 00         [24] 1766 	cjne	r7,#0x04,00184$
      007C06                       1767 00184$:
      007C06 40 1F            [24] 1768 	jc	00117$
      007C08 EF               [12] 1769 	mov	a,r7
      007C09 24 5B            [12] 1770 	add	a,#0xff - 0xa4
      007C0B 40 1A            [24] 1771 	jc	00117$
                                   1772 ;	free result
                                   1773 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007C0D 8F 82            [24] 1774 	mov	dpl, r7
      007C0F C0 07            [24] 1775 	push	ar7
      007C11 12 84 44         [24] 1776 	lcall	_del_owned_key
      007C14 E5 82            [12] 1777 	mov	a, dpl
      007C16 D0 07            [24] 1778 	pop	ar7
      007C18 70 01            [24] 1779 	jnz	00102$
      007C1A 22               [24] 1780 	ret
      007C1B                       1781 00102$:
                                   1782 ;	quantum/action.c:1049: ak820_dynamic_macro_observe(code, false);
      007C1B 90 04 C1         [24] 1783 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      007C1E 12 7D E6         [24] 1784 	lcall	_ak820_outline_0190
      007C21 12 3C 7B         [24] 1785 	lcall	_ak820_dynamic_macro_observe
                                   1786 ;	quantum/action.c:1054: send_keyboard_report();
      007C24 02 86 62         [24] 1787 	ljmp	_send_keyboard_report
      007C27                       1788 00117$:
                                   1789 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007C27 12 7D DB         [24] 1790 	lcall	_ak820_outline_0170
      007C2A BF E0 00         [24] 1791 	cjne	r7,#0xe0,00188$
      007C2D                       1792 00188$:
      007C2D 40 1A            [24] 1793 	jc	00113$
      007C2F EF               [12] 1794 	mov	a,r7
      007C30 24 18            [12] 1795 	add	a,#0xff - 0xe7
      007C32 40 15            [24] 1796 	jc	00113$
                                   1797 ;	free result
                                   1798 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007C34 74 07            [12] 1799 	mov	a,#0x07
      007C36 5F               [12] 1800 	anl	a,r7
      007C37 12 7D 8F         [24] 1801 	lcall	_ak820_outline_0063
      007C3A 80 02            [24] 1802 	sjmp	00192$
      007C3C                       1803 00191$:
      007C3C 25 E0            [12] 1804 	add	a,acc
      007C3E                       1805 00192$:
      007C3E D5 F0 FB         [24] 1806 	djnz	b,00191$
      007C41 F5 82            [12] 1807 	mov	dpl,a
      007C43 12 83 38         [24] 1808 	lcall	_del_owned_mods
                                   1809 ;	quantum/action.c:1057: send_keyboard_report();
      007C46 02 86 62         [24] 1810 	ljmp	_send_keyboard_report
      007C49                       1811 00113$:
                                   1812 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007C49 12 7D DB         [24] 1813 	lcall	_ak820_outline_0170
      007C4C BF A5 00         [24] 1814 	cjne	r7,#0xa5,00193$
      007C4F                       1815 00193$:
      007C4F 40 05            [24] 1816 	jc	00111$
      007C51 EF               [12] 1817 	mov	a,r7
      007C52 24 58            [12] 1818 	add	a,#0xff - 0xa7
      007C54 50 0D            [24] 1819 	jnc	00106$
                                   1820 ;	free result
      007C56                       1821 00111$:
      007C56 12 7D DB         [24] 1822 	lcall	_ak820_outline_0170
      007C59 BF A8 00         [24] 1823 	cjne	r7,#0xa8,00196$
      007C5C                       1824 00196$:
      007C5C 40 11            [24] 1825 	jc	00123$
      007C5E EF               [12] 1826 	mov	a,r7
      007C5F 24 3D            [12] 1827 	add	a,#0xff - 0xc2
      007C61 40 0C            [24] 1828 	jc	00123$
                                   1829 ;	free result
      007C63                       1830 00106$:
                                   1831 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007C63 12 7D DB         [24] 1832 	lcall	_ak820_outline_0170
      007C66 90 0A FD         [24] 1833 	mov	dptr,#_owned_usage_key_PARM_2
      007C69 12 7D E6         [24] 1834 	lcall	_ak820_outline_0190
                                   1835 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1836 ;	quantum/action.c:1072: }
      007C6C 02 85 0F         [24] 1837 	ljmp	_owned_usage_key
      007C6F                       1838 00123$:
      007C6F 22               [24] 1839 	ret
                                   1840 ;------------------------------------------------------------
                                   1841 ;Allocation info for local variables in function 'tap_code_delay'
                                   1842 ;------------------------------------------------------------
                                   1843 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1844 ;code          Allocated with name '_tap_code_delay_code_10000_747'
                                   1845 ;i             Allocated with name '_tap_code_delay_i_20000_749'
                                   1846 ;i             Allocated with name '_tap_code_delay_i_50000_752'
                                   1847 ;------------------------------------------------------------
                                   1848 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1849 ;	-----------------------------------------
                                   1850 ;	 function tap_code_delay
                                   1851 ;	-----------------------------------------
      007C70                       1852 _tap_code_delay:
      007C70 E5 82            [12] 1853 	mov	a,dpl
      007C72 90 08 A6         [24] 1854 	mov	dptr,#_tap_code_delay_code_10000_747
      007C75 F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/action.c:1080: register_code(code);
      007C76 E0               [24] 1857 	movx	a,@dptr
      007C77 FF               [12] 1858 	mov	r7,a
      007C78 F5 82            [12] 1859 	mov	dpl,a
      007C7A C0 07            [24] 1860 	push	ar7
      007C7C 71 7C            [12] 1861 	acall	_register_code
      007C7E D0 07            [24] 1862 	pop	ar7
                                   1863 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007C80 90 08 A4         [24] 1864 	mov	dptr,#_tap_code_delay_PARM_2
      007C83 12 3A A4         [24] 1865 	lcall	_ak820_outline_0080
      007C86                       1866 00110$:
      007C86 ED               [12] 1867 	mov	a,r5
      007C87 4E               [12] 1868 	orl	a,r6
      007C88 60 0D            [24] 1869 	jz	00105$
                                   1870 ;	quantum/action.c:1082: wait_ms(1);
      007C8A 90 00 01         [24] 1871 	mov	dptr,#0x0001
      007C8D 12 5E 38         [24] 1872 	lcall	_mDelaymS
                                   1873 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007C90 1D               [12] 1874 	dec	r5
      007C91 BD FF 01         [24] 1875 	cjne	r5,#0xff,00141$
      007C94 1E               [12] 1876 	dec	r6
      007C95                       1877 00141$:
      007C95 80 EF            [24] 1878 	sjmp	00110$
      007C97                       1879 00105$:
                                   1880 ;	quantum/action.c:1084: unregister_code(code);
      007C97 8F 82            [24] 1881 	mov	dpl, r7
                                   1882 ;	quantum/action.c:1085: }
      007C99 61 F8            [12] 1883 	ajmp	_unregister_code
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'tap_code'
                                   1886 ;------------------------------------------------------------
                                   1887 ;code          Allocated with name '_tap_code_code_10000_754'
                                   1888 ;------------------------------------------------------------
                                   1889 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1890 ;	-----------------------------------------
                                   1891 ;	 function tap_code
                                   1892 ;	-----------------------------------------
      007C9B                       1893 _tap_code:
      007C9B E5 82            [12] 1894 	mov	a,dpl
      007C9D 90 08 A7         [24] 1895 	mov	dptr,#_tap_code_code_10000_754
      007CA0 F0               [24] 1896 	movx	@dptr,a
                                   1897 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007CA1 E0               [24] 1898 	movx	a,@dptr
      007CA2 FF               [12] 1899 	mov	r7,a
      007CA3 BF 39 04         [24] 1900 	cjne	r7,#0x39,00103$
      007CA6 7E 50            [12] 1901 	mov	r6,#0x50
      007CA8 80 02            [24] 1902 	sjmp	00104$
      007CAA                       1903 00103$:
      007CAA 7E 00            [12] 1904 	mov	r6,#0x00
      007CAC                       1905 00104$:
      007CAC 90 08 A4         [24] 1906 	mov	dptr,#_tap_code_delay_PARM_2
      007CAF EE               [12] 1907 	mov	a,r6
      007CB0 12 3A DC         [24] 1908 	lcall	_ak820_outline_0136
      007CB3 8F 82            [24] 1909 	mov	dpl, r7
                                   1910 ;	quantum/action.c:1093: }
      007CB5 81 70            [12] 1911 	ajmp	_tap_code_delay
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'register_mods'
                                   1914 ;------------------------------------------------------------
                                   1915 ;mods          Allocated with name '_register_mods_mods_10000_756'
                                   1916 ;------------------------------------------------------------
                                   1917 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1918 ;	-----------------------------------------
                                   1919 ;	 function register_mods
                                   1920 ;	-----------------------------------------
      007CB7                       1921 _register_mods:
      007CB7 E5 82            [12] 1922 	mov	a,dpl
      007CB9 90 08 A8         [24] 1923 	mov	dptr,#_register_mods_mods_10000_756
      007CBC F0               [24] 1924 	movx	@dptr,a
                                   1925 ;	quantum/action.c:1100: if (mods) {
      007CBD E0               [24] 1926 	movx	a,@dptr
      007CBE FF               [12] 1927 	mov	r7,a
      007CBF E0               [24] 1928 	movx	a,@dptr
      007CC0 60 08            [24] 1929 	jz	00103$
                                   1930 ;	quantum/action.c:1101: add_owned_mods(mods);
      007CC2 8F 82            [24] 1931 	mov	dpl, r7
      007CC4 12 83 29         [24] 1932 	lcall	_add_owned_mods
                                   1933 ;	quantum/action.c:1102: send_keyboard_report();
                                   1934 ;	quantum/action.c:1104: }
      007CC7 02 86 62         [24] 1935 	ljmp	_send_keyboard_report
      007CCA                       1936 00103$:
      007CCA 22               [24] 1937 	ret
                                   1938 ;------------------------------------------------------------
                                   1939 ;Allocation info for local variables in function 'unregister_mods'
                                   1940 ;------------------------------------------------------------
                                   1941 ;mods          Allocated with name '_unregister_mods_mods_10000_760'
                                   1942 ;------------------------------------------------------------
                                   1943 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1944 ;	-----------------------------------------
                                   1945 ;	 function unregister_mods
                                   1946 ;	-----------------------------------------
      007CCB                       1947 _unregister_mods:
      007CCB E5 82            [12] 1948 	mov	a,dpl
      007CCD 90 08 A9         [24] 1949 	mov	dptr,#_unregister_mods_mods_10000_760
      007CD0 F0               [24] 1950 	movx	@dptr,a
                                   1951 ;	quantum/action.c:1111: if (mods) {
      007CD1 E0               [24] 1952 	movx	a,@dptr
      007CD2 FF               [12] 1953 	mov	r7,a
      007CD3 E0               [24] 1954 	movx	a,@dptr
      007CD4 60 08            [24] 1955 	jz	00103$
                                   1956 ;	quantum/action.c:1112: del_owned_mods(mods);
      007CD6 8F 82            [24] 1957 	mov	dpl, r7
      007CD8 12 83 38         [24] 1958 	lcall	_del_owned_mods
                                   1959 ;	quantum/action.c:1113: send_keyboard_report();
                                   1960 ;	quantum/action.c:1115: }
      007CDB 02 86 62         [24] 1961 	ljmp	_send_keyboard_report
      007CDE                       1962 00103$:
      007CDE 22               [24] 1963 	ret
                                   1964 ;------------------------------------------------------------
                                   1965 ;Allocation info for local variables in function 'register_weak_mods'
                                   1966 ;------------------------------------------------------------
                                   1967 ;mods          Allocated with name '_register_weak_mods_mods_10000_764'
                                   1968 ;------------------------------------------------------------
                                   1969 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1970 ;	-----------------------------------------
                                   1971 ;	 function register_weak_mods
                                   1972 ;	-----------------------------------------
      007CDF                       1973 _register_weak_mods:
      007CDF E5 82            [12] 1974 	mov	a,dpl
      007CE1 90 08 AA         [24] 1975 	mov	dptr,#_register_weak_mods_mods_10000_764
      007CE4 F0               [24] 1976 	movx	@dptr,a
                                   1977 ;	quantum/action.c:1122: if (mods) {
      007CE5 E0               [24] 1978 	movx	a,@dptr
      007CE6 FF               [12] 1979 	mov	r7,a
      007CE7 E0               [24] 1980 	movx	a,@dptr
      007CE8 60 08            [24] 1981 	jz	00103$
                                   1982 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007CEA 8F 82            [24] 1983 	mov	dpl, r7
      007CEC 12 83 45         [24] 1984 	lcall	_add_owned_weak_mods
                                   1985 ;	quantum/action.c:1124: send_keyboard_report();
                                   1986 ;	quantum/action.c:1126: }
      007CEF 02 86 62         [24] 1987 	ljmp	_send_keyboard_report
      007CF2                       1988 00103$:
      007CF2 22               [24] 1989 	ret
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_768'
                                   1994 ;------------------------------------------------------------
                                   1995 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1996 ;	-----------------------------------------
                                   1997 ;	 function unregister_weak_mods
                                   1998 ;	-----------------------------------------
      007CF3                       1999 _unregister_weak_mods:
      007CF3 E5 82            [12] 2000 	mov	a,dpl
      007CF5 90 08 AB         [24] 2001 	mov	dptr,#_unregister_weak_mods_mods_10000_768
      007CF8 F0               [24] 2002 	movx	@dptr,a
                                   2003 ;	quantum/action.c:1133: if (mods) {
      007CF9 E0               [24] 2004 	movx	a,@dptr
      007CFA FF               [12] 2005 	mov	r7,a
      007CFB E0               [24] 2006 	movx	a,@dptr
      007CFC 60 08            [24] 2007 	jz	00103$
                                   2008 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007CFE 8F 82            [24] 2009 	mov	dpl, r7
      007D00 12 83 54         [24] 2010 	lcall	_del_owned_weak_mods
                                   2011 ;	quantum/action.c:1135: send_keyboard_report();
                                   2012 ;	quantum/action.c:1137: }
      007D03 02 86 62         [24] 2013 	ljmp	_send_keyboard_report
      007D06                       2014 00103$:
      007D06 22               [24] 2015 	ret
                                   2016 ;------------------------------------------------------------
                                   2017 ;Allocation info for local variables in function 'clear_keyboard'
                                   2018 ;------------------------------------------------------------
                                   2019 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   2020 ;	-----------------------------------------
                                   2021 ;	 function clear_keyboard
                                   2022 ;	-----------------------------------------
      007D07                       2023 _clear_keyboard:
                                   2024 ;	quantum/action.c:1144: clear_mods();
      007D07 12 86 DD         [24] 2025 	lcall	_clear_mods
                                   2026 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   2027 ;	quantum/action.c:1146: }
      007D0A A1 0C            [12] 2028 	ajmp	_clear_keyboard_but_mods
                                   2029 ;------------------------------------------------------------
                                   2030 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2031 ;------------------------------------------------------------
                                   2032 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   2033 ;	-----------------------------------------
                                   2034 ;	 function clear_keyboard_but_mods
                                   2035 ;	-----------------------------------------
      007D0C                       2036 _clear_keyboard_but_mods:
                                   2037 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D0C 90 0E 30         [24] 2038 	mov	dptr,#_actual_keyboard_report
      007D0F 75 F0 00         [24] 2039 	mov	b, #0x00
      007D12 12 74 E0         [24] 2040 	lcall	_clear_keys_from_report
                                   2041 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   2042 ;	quantum/action.c:1155: }
      007D15 A1 17            [12] 2043 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2044 ;------------------------------------------------------------
                                   2045 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2046 ;------------------------------------------------------------
                                   2047 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   2048 ;	-----------------------------------------
                                   2049 ;	 function clear_keyboard_but_mods_and_keys
                                   2050 ;	-----------------------------------------
      007D17                       2051 _clear_keyboard_but_mods_and_keys:
                                   2052 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007D17 12 4C 53         [24] 2053 	lcall	_ak820_tapping_cancel
                                   2054 ;	quantum/action.c:1165: ak820_dynamic_macro_cancel();
      007D1A 12 3B AC         [24] 2055 	lcall	_ak820_dynamic_macro_cancel
                                   2056 ;	quantum/action.c:1168: ak820_autoshift_cancel();
      007D1D 12 33 4A         [24] 2057 	lcall	_ak820_autoshift_cancel
                                   2058 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007D20 12 2E F0         [24] 2059 	lcall	_ak820_oneshot_cancel
                                   2060 ;	quantum/action.c:1174: ak820_combo_cancel();
      007D23 12 37 B7         [24] 2061 	lcall	_ak820_combo_cancel
                                   2062 ;	quantum/action.c:1177: repeat_key_cancel();
      007D26 12 A7 28         [24] 2063 	lcall	_repeat_key_cancel
                                   2064 ;	quantum/action.c:1179: clear_owned_mods();
      007D29 12 83 63         [24] 2065 	lcall	_clear_owned_mods
                                   2066 ;	quantum/action.c:1180: clear_owned_keys();
      007D2C 12 83 9B         [24] 2067 	lcall	_clear_owned_keys
                                   2068 ;	quantum/action.c:1181: clear_owned_usages();
      007D2F 12 84 D7         [24] 2069 	lcall	_clear_owned_usages
                                   2070 ;	quantum/action.c:1182: layer_hold_clear();
      007D32 F1 22            [12] 2071 	acall	_layer_hold_clear
                                   2072 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007D34 12 A2 09         [24] 2073 	lcall	_clear_macro_tri_layer
                                   2074 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D37 90 0E 30         [24] 2075 	mov	dptr,#_actual_keyboard_report
      007D3A 75 F0 00         [24] 2076 	mov	b, #0x00
      007D3D 12 74 E0         [24] 2077 	lcall	_clear_keys_from_report
                                   2078 ;	quantum/action.c:1189: host_system_send(0);
      007D40 90 00 00         [24] 2079 	mov	dptr,#0x0000
      007D43 12 72 AC         [24] 2080 	lcall	_host_system_send
                                   2081 ;	quantum/action.c:1190: host_consumer_send(0);
      007D46 90 00 00         [24] 2082 	mov	dptr,#0x0000
      007D49 12 72 DB         [24] 2083 	lcall	_host_consumer_send
                                   2084 ;	quantum/action.c:1192: clear_weak_mods();
      007D4C 12 87 12         [24] 2085 	lcall	_clear_weak_mods
                                   2086 ;	quantum/action.c:1193: send_keyboard_report();
                                   2087 ;	quantum/action.c:1201: }
      007D4F 02 86 62         [24] 2088 	ljmp	_send_keyboard_report
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'is_tap_record'
                                   2091 ;------------------------------------------------------------
                                   2092 ;record        Allocated with name '_is_tap_record_record_10000_784'
                                   2093 ;action        Allocated with name '_is_tap_record_action_10001_788'
                                   2094 ;------------------------------------------------------------
                                   2095 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   2096 ;	-----------------------------------------
                                   2097 	.area CSEG    (CODE)
                                   2098 	.area CONST   (CODE)
                                   2099 	.area XINIT   (CODE)
      00C671                       2100 __xinit__disable_action_cache:
      00C671 00                    2101 	.db #0x00	;  0
                                   2102 	.area CABS    (ABS,CODE)
                                   2103 
                                   2104 ; Experimental exact instruction outlining.
                                   2105 	.globl _ak820_outline_0001
                                   2106 	.globl _ak820_outline_0005
                                   2107 	.globl _ak820_outline_0006
                                   2108 	.globl _ak820_outline_0008
                                   2109 	.globl _ak820_outline_0009
                                   2110 	.globl _ak820_outline_0012
                                   2111 	.globl _ak820_outline_0013
                                   2112 	.globl _ak820_outline_0014
                                   2113 	.globl _ak820_outline_0016
                                   2114 	.globl _ak820_outline_0021
                                   2115 	.globl _ak820_outline_0022
                                   2116 	.globl _ak820_outline_0024
                                   2117 	.globl _ak820_outline_0031
                                   2118 	.globl _ak820_outline_0036
                                   2119 	.globl _ak820_outline_0042
                                   2120 	.globl _ak820_outline_0050
                                   2121 	.globl _ak820_outline_0051
                                   2122 	.globl _ak820_outline_0063
                                   2123 	.globl _ak820_outline_0071
                                   2124 	.globl _ak820_outline_0072
                                   2125 	.globl _ak820_outline_0076
                                   2126 	.globl _ak820_outline_0079
                                   2127 	.globl _ak820_outline_0080
                                   2128 	.globl _ak820_outline_0082
                                   2129 	.globl _ak820_outline_0091
                                   2130 	.globl _ak820_outline_0095
                                   2131 	.globl _ak820_outline_0097
                                   2132 	.globl _ak820_outline_0110
                                   2133 	.globl _ak820_outline_0111
                                   2134 	.globl _ak820_outline_0113
                                   2135 	.globl _ak820_outline_0115
                                   2136 	.globl _ak820_outline_0120
                                   2137 	.globl _ak820_outline_0125
                                   2138 	.globl _ak820_outline_0126
                                   2139 	.globl _ak820_outline_0127
                                   2140 	.globl _ak820_outline_0133
                                   2141 	.globl _ak820_outline_0136
                                   2142 	.globl _ak820_outline_0144
                                   2143 	.globl _ak820_outline_0145
                                   2144 	.globl _ak820_outline_0146
                                   2145 	.globl _ak820_outline_0151
                                   2146 	.globl _ak820_outline_0161
                                   2147 	.globl _ak820_outline_0169
                                   2148 	.globl _ak820_outline_0170
                                   2149 	.globl _ak820_outline_0183
                                   2150 	.globl _ak820_outline_0188
                                   2151 	.globl _ak820_outline_0190
                                   2152 
                                   2153 	.area CSEG (CODE)
                                   2154 ; function ak820_outline_0006
      007D52                       2155 _ak820_outline_0006:
      007D52 2D               [12] 2156 	add	a,r5
      007D53 FA               [12] 2157 	mov	r2,a
      007D54 E4               [12] 2158 	clr	a
      007D55 3E               [12] 2159 	addc	a,r6
      007D56 FB               [12] 2160 	mov	r3,a
      007D57 8F 04            [24] 2161 	mov	ar4,r7
      007D59 8A 82            [24] 2162 	mov	dpl,r2
      007D5B 8B 83            [24] 2163 	mov	dph,r3
      007D5D 8C F0            [24] 2164 	mov	b,r4
      007D5F 22               [24] 2165 	ret
                                   2166 
                                   2167 	.area CSEG (CODE)
                                   2168 ; function ak820_outline_0014
      007D60                       2169 _ak820_outline_0014:
      007D60 2D               [12] 2170 	add	a,r5
      007D61 F9               [12] 2171 	mov	r1,a
      007D62 E4               [12] 2172 	clr	a
      007D63 3E               [12] 2173 	addc	a,r6
      007D64 FA               [12] 2174 	mov	r2,a
      007D65 8F 03            [24] 2175 	mov	ar3,r7
      007D67 89 82            [24] 2176 	mov	dpl,r1
      007D69 8A 83            [24] 2177 	mov	dph,r2
      007D6B 8B F0            [24] 2178 	mov	b,r3
      007D6D 22               [24] 2179 	ret
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0021
      007D6E                       2183 _ak820_outline_0021:
      007D6E 8E 82            [24] 2184 	mov	dpl,r6
      007D70 8F 83            [24] 2185 	mov	dph,r7
      007D72 A3               [24] 2186 	inc	dptr
      007D73 E0               [24] 2187 	movx	a,@dptr
      007D74 FC               [12] 2188 	mov	r4,a
      007D75 7D 00            [12] 2189 	mov	r5,#0x00
      007D77 8E 82            [24] 2190 	mov	dpl,r6
      007D79 8F 83            [24] 2191 	mov	dph,r7
      007D7B E0               [24] 2192 	movx	a,@dptr
      007D7C 22               [24] 2193 	ret
                                   2194 
                                   2195 	.area CSEG (CODE)
                                   2196 ; function ak820_outline_0024
      007D7D                       2197 _ak820_outline_0024:
      007D7D E0               [24] 2198 	movx	a,@dptr
      007D7E FB               [12] 2199 	mov	r3,a
      007D7F A3               [24] 2200 	inc	dptr
      007D80 E0               [24] 2201 	movx	a,@dptr
      007D81 FC               [12] 2202 	mov	r4,a
      007D82 A3               [24] 2203 	inc	dptr
      007D83 E0               [24] 2204 	movx	a,@dptr
      007D84 FD               [12] 2205 	mov	r5,a
      007D85 22               [24] 2206 	ret
                                   2207 
                                   2208 	.area CSEG (CODE)
                                   2209 ; function ak820_outline_0042
      007D86                       2210 _ak820_outline_0042:
      007D86 90 08 9D         [24] 2211 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D89 E0               [24] 2212 	movx	a,@dptr
      007D8A 54 1F            [12] 2213 	anl	a,#0x1f
      007D8C F5 82            [12] 2214 	mov	dpl,a
      007D8E 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0063
      007D8F                       2219 _ak820_outline_0063:
      007D8F F5 F0            [12] 2220 	mov	b,a
      007D91 05 F0            [12] 2221 	inc	b
      007D93 74 01            [12] 2222 	mov	a,#0x01
      007D95 22               [24] 2223 	ret
                                   2224 
                                   2225 	.area CSEG (CODE)
                                   2226 ; function ak820_outline_0071
      007D96                       2227 _ak820_outline_0071:
      007D96 90 0E 0D         [24] 2228 	mov	dptr,#___memcpy_PARM_3
      007D99 74 06            [12] 2229 	mov	a,#0x06
      007D9B F0               [24] 2230 	movx	@dptr,a
      007D9C E4               [12] 2231 	clr	a
      007D9D A3               [24] 2232 	inc	dptr
      007D9E F0               [24] 2233 	movx	@dptr,a
      007D9F 22               [24] 2234 	ret
                                   2235 
                                   2236 	.area CSEG (CODE)
                                   2237 ; function ak820_outline_0079
      007DA0                       2238 _ak820_outline_0079:
      007DA0 90 08 9C         [24] 2239 	mov	dptr,#_process_action_PARM_2
      007DA3 E0               [24] 2240 	movx	a,@dptr
      007DA4 F5 82            [12] 2241 	mov	dpl,a
      007DA6 22               [24] 2242 	ret
                                   2243 
                                   2244 	.area CSEG (CODE)
                                   2245 ; function ak820_outline_0082
      007DA7                       2246 _ak820_outline_0082:
      007DA7 2D               [12] 2247 	add	a,r5
      007DA8 F8               [12] 2248 	mov	r0,a
      007DA9 E4               [12] 2249 	clr	a
      007DAA 3E               [12] 2250 	addc	a,r6
      007DAB F9               [12] 2251 	mov	r1,a
      007DAC 8F 02            [24] 2252 	mov	ar2,r7
      007DAE 88 82            [24] 2253 	mov	dpl,r0
      007DB0 89 83            [24] 2254 	mov	dph,r1
      007DB2 8A F0            [24] 2255 	mov	b,r2
      007DB4 22               [24] 2256 	ret
                                   2257 
                                   2258 	.area CSEG (CODE)
                                   2259 ; function ak820_outline_0091
      007DB5                       2260 _ak820_outline_0091:
      007DB5 90 08 9D         [24] 2261 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007DB8 E0               [24] 2262 	movx	a,@dptr
      007DB9 03               [12] 2263 	rr	a
      007DBA 03               [12] 2264 	rr	a
      007DBB 54 03            [12] 2265 	anl	a,#0x03
      007DBD 22               [24] 2266 	ret
                                   2267 
                                   2268 	.area CSEG (CODE)
                                   2269 ; function ak820_outline_0115
      007DBE                       2270 _ak820_outline_0115:
      007DBE 90 08 9D         [24] 2271 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007DC1 E0               [24] 2272 	movx	a,@dptr
      007DC2 54 0F            [12] 2273 	anl	a,#0x0f
      007DC4 22               [24] 2274 	ret
                                   2275 
                                   2276 	.area CSEG (CODE)
                                   2277 ; function ak820_outline_0133
      007DC5                       2278 _ak820_outline_0133:
      007DC5 90 08 9C         [24] 2279 	mov	dptr,#_process_action_PARM_2
      007DC8 E0               [24] 2280 	movx	a,@dptr
      007DC9 FE               [12] 2281 	mov	r6,a
      007DCA A3               [24] 2282 	inc	dptr
      007DCB E0               [24] 2283 	movx	a,@dptr
      007DCC 54 03            [12] 2284 	anl	a,#0x03
      007DCE FF               [12] 2285 	mov	r7,a
      007DCF 22               [24] 2286 	ret
                                   2287 
                                   2288 	.area CSEG (CODE)
                                   2289 ; function ak820_outline_0161
      007DD0                       2290 _ak820_outline_0161:
      007DD0 90 08 9C         [24] 2291 	mov	dptr,#_process_action_PARM_2
      007DD3 E0               [24] 2292 	movx	a,@dptr
      007DD4 22               [24] 2293 	ret
                                   2294 
                                   2295 	.area CSEG (CODE)
                                   2296 ; function ak820_outline_0169
      007DD5                       2297 _ak820_outline_0169:
      007DD5 90 08 A2         [24] 2298 	mov	dptr,#_register_code_code_10000_720
      007DD8 E0               [24] 2299 	movx	a,@dptr
      007DD9 FF               [12] 2300 	mov	r7,a
      007DDA 22               [24] 2301 	ret
                                   2302 
                                   2303 	.area CSEG (CODE)
                                   2304 ; function ak820_outline_0170
      007DDB                       2305 _ak820_outline_0170:
      007DDB 90 08 A3         [24] 2306 	mov	dptr,#_unregister_code_code_10000_734
      007DDE E0               [24] 2307 	movx	a,@dptr
      007DDF FF               [12] 2308 	mov	r7,a
      007DE0 22               [24] 2309 	ret
                                   2310 
                                   2311 	.area CSEG (CODE)
                                   2312 ; function ak820_outline_0188
      007DE1                       2313 _ak820_outline_0188:
      007DE1 F0               [24] 2314 	movx	@dptr,a
      007DE2 EB               [12] 2315 	mov	a,r3
      007DE3 A3               [24] 2316 	inc	dptr
      007DE4 F0               [24] 2317 	movx	@dptr,a
      007DE5 22               [24] 2318 	ret
                                   2319 
                                   2320 	.area CSEG (CODE)
                                   2321 ; function ak820_outline_0190
      007DE6                       2322 _ak820_outline_0190:
      007DE6 E4               [12] 2323 	clr	a
      007DE7 F0               [24] 2324 	movx	@dptr,a
      007DE8 8F 82            [24] 2325 	mov	dpl,r7
      007DEA 22               [24] 2326 	ret
