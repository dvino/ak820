                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000011                        595 _suspended:
      000011                        596 	.ds 1
      000012                        597 _dirty:
      000012                        598 	.ds 1
      000013                        599 _rendering:
      000013                        600 	.ds 1
      000014                        601 _rgb_matrix_task_sloc0_1_0:
      000014                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006AB                        611 _rgb_matrix_config::
      0006AB                        612 	.ds 8
      0006B3                        613 _changed_at:
      0006B3                        614 	.ds 2
      0006B5                        615 _frame_at:
      0006B5                        616 	.ds 2
      0006B7                        617 _phase:
      0006B7                        618 	.ds 2
      0006B9                        619 _led_index:
      0006B9                        620 	.ds 1
      0006BA                        621 _frame_mode:
      0006BA                        622 	.ds 1
      0006BB                        623 _frame_hue:
      0006BB                        624 	.ds 1
      0006BC                        625 _frame_sat:
      0006BC                        626 	.ds 1
      0006BD                        627 _frame_val:
      0006BD                        628 	.ds 1
      0006BE                        629 _frame_flags:
      0006BE                        630 	.ds 1
      0006BF                        631 _frame_phase:
      0006BF                        632 	.ds 1
      0006C0                        633 _reactive_age:
      0006C0                        634 	.ds 82
      000712                        635 _reactive_at:
      000712                        636 	.ds 2
      000714                        637 _add_sat_PARM_2:
      000714                        638 	.ds 1
      000715                        639 _add_sat_x_10000_266:
      000715                        640 	.ds 1
      000716                        641 _sub_sat_PARM_2:
      000716                        642 	.ds 1
      000717                        643 _sub_sat_x_10000_268:
      000717                        644 	.ds 1
      000718                        645 _rgb_matrix_set_color_PARM_2:
      000718                        646 	.ds 1
      000719                        647 _rgb_matrix_set_color_PARM_3:
      000719                        648 	.ds 1
      00071A                        649 _rgb_matrix_set_color_PARM_4:
      00071A                        650 	.ds 1
      00071B                        651 _rgb_matrix_set_color_index_10000_284:
      00071B                        652 	.ds 2
      00071D                        653 _rgb_matrix_set_color_all_PARM_2:
      00071D                        654 	.ds 1
      00071E                        655 _rgb_matrix_set_color_all_PARM_3:
      00071E                        656 	.ds 1
      00071F                        657 _rgb_matrix_set_color_all_r_10000_287:
      00071F                        658 	.ds 1
      000720                        659 _sine8_theta_10000_289:
      000720                        660 	.ds 1
      000721                        661 _sine8_offset_10000_290:
      000721                        662 	.ds 1
      000722                        663 _sine8_fraction_10000_290:
      000722                        664 	.ds 1
      000723                        665 _breathing_cie_value_10000_293:
      000723                        666 	.ds 1
      000724                        667 _rgb_matrix_task_end_10000_298:
      000724                        668 	.ds 1
      000725                        669 _rgb_matrix_task_hsv_10000_298:
      000725                        670 	.ds 3
      000728                        671 _rgb_matrix_task_rgb_10000_298:
      000728                        672 	.ds 3
      00072B                        673 _process_rgb_matrix_PARM_2:
      00072B                        674 	.ds 1
      00072C                        675 _process_rgb_matrix_PARM_3:
      00072C                        676 	.ds 1
      00072D                        677 _process_rgb_matrix_row_10000_319:
      00072D                        678 	.ds 1
      00072E                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00072E                        680 	.ds 1
      00072F                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      00072F                        682 	.ds 1
      000730                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000730                        684 	.ds 1
      000731                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000731                        686 	.ds 1
      000732                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000732                        688 	.ds 2
      000734                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000734                        690 	.ds 1
      000735                        691 _rgb_matrix_mode_mode_10000_411:
      000735                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      004F41                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      004F41 12 57 28         [24]  746 	lcall	_ak820_outline_0181
      004F44 74 52            [12]  747 	mov	a,#0x52
      004F46 12 38 9C         [24]  748 	lcall	_ak820_outline_0136
      004F49 90 06 C0         [24]  749 	mov	dptr,#_reactive_age
      004F4C F5 F0            [12]  750 	mov	b,a
      004F4E 12 B7 C0         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      004F51 12 49 36         [24]  753 	lcall	_timer_read
      004F54 12 38 A6         [24]  754 	lcall	_ak820_outline_0140
      004F57 90 07 12         [24]  755 	mov	dptr,#_reactive_at
      004F5A 12 57 14         [24]  756 	lcall	_ak820_outline_0172
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      004F5D 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      004F5E                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004F5E 90 07 12         [24]  772 	mov	dptr,#_reactive_at
      004F61 12 37 F4         [24]  773 	lcall	_ak820_outline_0005
      004F64 12 49 39         [24]  774 	lcall	_timer_elapsed
      004F67 AE 82            [24]  775 	mov	r6, dpl
      004F69 E5 83            [12]  776 	mov	a,dph
      004F6B C4               [12]  777 	swap	a
      004F6C CE               [12]  778 	xch	a,r6
      004F6D C4               [12]  779 	swap	a
      004F6E 54 0F            [12]  780 	anl	a,#0x0f
      004F70 6E               [12]  781 	xrl	a,r6
      004F71 CE               [12]  782 	xch	a,r6
      004F72 54 0F            [12]  783 	anl	a,#0x0f
      004F74 CE               [12]  784 	xch	a,r6
      004F75 6E               [12]  785 	xrl	a,r6
      004F76 CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      004F77 FF               [12]  788 	mov	r7,a
      004F78 4E               [12]  789 	orl	a,r6
      004F79 70 01            [24]  790 	jnz	00102$
      004F7B 22               [24]  791 	ret
      004F7C                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      004F7C 8E 04            [24]  794 	mov	ar4,r6
      004F7E EF               [12]  795 	mov	a,r7
      004F7F C4               [12]  796 	swap	a
      004F80 54 F0            [12]  797 	anl	a,#0xf0
      004F82 CC               [12]  798 	xch	a,r4
      004F83 C4               [12]  799 	swap	a
      004F84 CC               [12]  800 	xch	a,r4
      004F85 6C               [12]  801 	xrl	a,r4
      004F86 CC               [12]  802 	xch	a,r4
      004F87 54 F0            [12]  803 	anl	a,#0xf0
      004F89 CC               [12]  804 	xch	a,r4
      004F8A 6C               [12]  805 	xrl	a,r4
      004F8B FD               [12]  806 	mov	r5,a
      004F8C 90 07 12         [24]  807 	mov	dptr,#_reactive_at
      004F8F 12 43 4A         [24]  808 	lcall	_ak820_outline_0105
      004F92 90 07 12         [24]  809 	mov	dptr,#_reactive_at
      004F95 EC               [12]  810 	mov	a,r4
      004F96 2A               [12]  811 	add	a, r2
      004F97 F0               [24]  812 	movx	@dptr,a
      004F98 ED               [12]  813 	mov	a,r5
      004F99 3B               [12]  814 	addc	a, r3
      004F9A A3               [24]  815 	inc	dptr
      004F9B F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      004F9C 8E 04            [24]  818 	mov	ar4,r6
      004F9E 8F 05            [24]  819 	mov	ar5,r7
      004FA0 C3               [12]  820 	clr	c
      004FA1 74 FF            [12]  821 	mov	a,#0xff
      004FA3 9C               [12]  822 	subb	a,r4
      004FA4 E4               [12]  823 	clr	a
      004FA5 9D               [12]  824 	subb	a,r5
      004FA6 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      004FA8 7D FF            [12]  827 	mov	r5,#0xff
      004FAA 80 02            [24]  828 	sjmp	00109$
      004FAC                        829 00108$:
      004FAC 8E 05            [24]  830 	mov	ar5,r6
      004FAE                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004FAE 7F 00            [12]  833 	mov	r7,#0x00
      004FB0                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      004FB0 EF               [12]  836 	mov	a,r7
      004FB1 24 C0            [12]  837 	add	a, #_reactive_age
      004FB3 FC               [12]  838 	mov	r4,a
      004FB4 E4               [12]  839 	clr	a
      004FB5 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      004FB7 FE               [12]  841 	mov	r6,a
      004FB8 8C 82            [24]  842 	mov	dpl,r4
      004FBA 8E 83            [24]  843 	mov	dph,r6
      004FBC E0               [24]  844 	movx	a,@dptr
      004FBD FB               [12]  845 	mov	r3,a
      004FBE C3               [12]  846 	clr	c
      004FBF ED               [12]  847 	mov	a,r5
      004FC0 9B               [12]  848 	subb	a,r3
      004FC1 40 04            [24]  849 	jc	00110$
      004FC3 7B 00            [12]  850 	mov	r3,#0x00
      004FC5 80 08            [24]  851 	sjmp	00111$
      004FC7                        852 00110$:
      004FC7 8C 82            [24]  853 	mov	dpl,r4
      004FC9 8E 83            [24]  854 	mov	dph,r6
      004FCB E0               [24]  855 	movx	a,@dptr
      004FCC C3               [12]  856 	clr	c
      004FCD 9D               [12]  857 	subb	a,r5
      004FCE FB               [12]  858 	mov	r3,a
      004FCF                        859 00111$:
      004FCF 8C 82            [24]  860 	mov	dpl,r4
      004FD1 8E 83            [24]  861 	mov	dph,r6
      004FD3 EB               [12]  862 	mov	a,r3
      004FD4 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004FD5 0F               [12]  865 	inc	r7
      004FD6 BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      004FD9                        867 00144$:
      004FD9 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      004FDB 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      004FDC                        881 _add_sat:
      004FDC E5 82            [12]  882 	mov	a,dpl
      004FDE 90 07 15         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      004FE1 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      004FE2 90 07 14         [24]  886 	mov	dptr,#_add_sat_PARM_2
      004FE5 E0               [24]  887 	movx	a,@dptr
      004FE6 FF               [12]  888 	mov	r7,a
      004FE7 FE               [12]  889 	mov	r6,a
      004FE8 74 FF            [12]  890 	mov	a,#0xff
      004FEA C3               [12]  891 	clr	c
      004FEB 9E               [12]  892 	subb	a,r6
      004FEC FE               [12]  893 	mov	r6,a
      004FED 90 07 15         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      004FF0 E0               [24]  895 	movx	a,@dptr
      004FF1 FD               [12]  896 	mov	r5,a
      004FF2 C3               [12]  897 	clr	c
      004FF3 EE               [12]  898 	mov	a,r6
      004FF4 9D               [12]  899 	subb	a,r5
      004FF5 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      004FF7 7E FF            [12]  902 	mov	r6,#0xff
      004FF9 80 03            [24]  903 	sjmp	00104$
      004FFB                        904 00103$:
      004FFB EF               [12]  905 	mov	a,r7
      004FFC 2D               [12]  906 	add	a, r5
      004FFD FE               [12]  907 	mov	r6,a
      004FFE                        908 00104$:
      004FFE 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      005000 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      005001                        922 _sub_sat:
      005001 E5 82            [12]  923 	mov	a,dpl
      005003 90 07 17         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      005006 F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      005007 E0               [24]  927 	movx	a,@dptr
      005008 FF               [12]  928 	mov	r7,a
      005009 90 07 16         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      00500C E0               [24]  930 	movx	a,@dptr
      00500D FE               [12]  931 	mov	r6,a
      00500E C3               [12]  932 	clr	c
      00500F EF               [12]  933 	mov	a,r7
      005010 9E               [12]  934 	subb	a,r6
      005011 50 04            [24]  935 	jnc	00103$
      005013 7D 00            [12]  936 	mov	r5,#0x00
      005015 80 04            [24]  937 	sjmp	00104$
      005017                        938 00103$:
      005017 EF               [12]  939 	mov	a,r7
      005018 C3               [12]  940 	clr	c
      005019 9E               [12]  941 	subb	a,r6
      00501A FD               [12]  942 	mov	r5,a
      00501B                        943 00104$:
      00501B 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      00501D 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      00501E                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      00501E D2 12            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005020 12 49 36         [24]  959 	lcall	_timer_read
      005023 12 38 A6         [24]  960 	lcall	_ak820_outline_0140
      005026 90 06 B3         [24]  961 	mov	dptr,#_changed_at
      005029 12 57 14         [24]  962 	lcall	_ak820_outline_0172
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      00502C 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      00502D                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      00502D 90 06 B2         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      005030 E4               [12]  978 	clr	a
      005031 F0               [24]  979 	movx	@dptr,a
      005032 90 06 B1         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      005035 F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005036 90 05 95         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005039 12 56 F7         [24]  984 	lcall	_ak820_outline_0087
      00503C 90 05 98         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00503F 12 56 DE         [24]  986 	lcall	_ak820_outline_0070
      005042 12 42 1E         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      005045 C2 12            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      005047 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005048                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005048 12 57 28         [24] 1002 	lcall	_ak820_outline_0181
      00504B 12 56 DE         [24] 1003 	lcall	_ak820_outline_0070
      00504E F5 F0            [12] 1004 	mov	b,a
      005050 12 B7 C0         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005053 12 57 07         [24] 1007 	lcall	_ak820_outline_0115
      005056 44 01            [12] 1008 	orl	a,#0x01
      005058 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005059 12 56 D7         [24] 1011 	lcall	_ak820_outline_0066
      00505C 44 04            [12] 1012 	orl	a,#0x04
      00505E F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      00505F 90 06 AC         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005062 E4               [12] 1016 	clr	a
      005063 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005064 90 06 AD         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005067 14               [12] 1020 	dec	a
      005068 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005069 90 06 AE         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00506C 74 50            [12] 1024 	mov	a,#0x50
      00506E F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      00506F 90 06 AF         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005072 74 60            [12] 1028 	mov	a,#0x60
      005074 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      005075 90 06 B0         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005078 74 FF            [12] 1032 	mov	a,#0xff
      00507A F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      00507B 02 50 2D         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      00507E                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00507E 90 05 85         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005081 12 56 F7         [24] 1047 	lcall	_ak820_outline_0087
      005084 90 05 88         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005087 12 56 DE         [24] 1049 	lcall	_ak820_outline_0070
      00508A 12 40 AF         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      00508D 12 57 07         [24] 1052 	lcall	_ak820_outline_0115
      005090 60 11            [24] 1053 	jz	00101$
      005092 12 56 B8         [24] 1054 	lcall	_ak820_outline_0019
      005095 C3               [12] 1055 	clr	c
      005096 64 80            [12] 1056 	xrl	a,#0x80
      005098 94 87            [12] 1057 	subb	a,#0x87
      00509A 50 07            [24] 1058 	jnc	00101$
      00509C 12 56 D7         [24] 1059 	lcall	_ak820_outline_0066
      00509F 24 FE            [12] 1060 	add	a,#0xff - 0x01
      0050A1 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      0050A3                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      0050A3 12 50 48         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      0050A6                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      0050A6 90 06 AE         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050A9 E0               [24] 1069 	movx	a,@dptr
      0050AA 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      0050AC 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      0050AE 90 06 AE         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050B1 74 A0            [12] 1075 	mov	a,#0xa0
      0050B3 F0               [24] 1076 	movx	@dptr,a
      0050B4                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      0050B4 C2 12            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      0050B6 C2 13            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      0050B8 02 4F 41         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0050BB                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0050BB 12 50 7E         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0050BE 12 49 36         [24] 1098 	lcall	_timer_read
      0050C1 12 43 5C         [24] 1099 	lcall	_ak820_outline_0135
      0050C4 EE               [12] 1100 	mov	a,r6
      0050C5 24 F0            [12] 1101 	add	a,#0xf0
      0050C7 FE               [12] 1102 	mov	r6,a
      0050C8 EF               [12] 1103 	mov	a,r7
      0050C9 34 FF            [12] 1104 	addc	a,#0xff
      0050CB FF               [12] 1105 	mov	r7,a
      0050CC 90 06 B5         [24] 1106 	mov	dptr,#_frame_at
      0050CF 12 48 83         [24] 1107 	lcall	_ak820_outline_0060
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0050D2 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0050D3                       1122 _rgb_matrix_set_color:
      0050D3 12 38 82         [24] 1123 	lcall	_ak820_outline_0118
      0050D6 90 07 1B         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0050D9 12 38 87         [24] 1125 	lcall	_ak820_outline_0119
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0050DC 90 07 1B         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0050DF 12 38 41         [24] 1128 	lcall	_ak820_outline_0052
      0050E2 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0050E5 C3               [12] 1130 	clr	c
      0050E6 EE               [12] 1131 	mov	a,r6
      0050E7 94 52            [12] 1132 	subb	a,#0x52
      0050E9 EF               [12] 1133 	mov	a,r7
      0050EA 64 80            [12] 1134 	xrl	a,#0x80
      0050EC 94 80            [12] 1135 	subb	a,#0x80
      0050EE 50 23            [24] 1136 	jnc	00104$
      0050F0 90 07 18         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0050F3 E0               [24] 1138 	movx	a,@dptr
      0050F4 FF               [12] 1139 	mov	r7,a
      0050F5 90 07 19         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0050F8 E0               [24] 1141 	movx	a,@dptr
      0050F9 FD               [12] 1142 	mov	r5,a
      0050FA 90 07 1A         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0050FD E0               [24] 1144 	movx	a,@dptr
      0050FE FC               [12] 1145 	mov	r4,a
      0050FF 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005102 EF               [12] 1147 	mov	a,r7
      005103 F0               [24] 1148 	movx	@dptr,a
      005104 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      005107 ED               [12] 1150 	mov	a,r5
      005108 F0               [24] 1151 	movx	@dptr,a
      005109 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      00510C EC               [12] 1153 	mov	a,r4
      00510D F0               [24] 1154 	movx	@dptr,a
      00510E 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      005110 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      005113                       1158 00104$:
      005113 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      005114                       1171 _rgb_matrix_set_color_all:
      005114 E5 82            [12] 1172 	mov	a,dpl
      005116 90 07 1F         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      005119 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      00511A E0               [24] 1176 	movx	a,@dptr
      00511B FF               [12] 1177 	mov	r7,a
      00511C 90 07 1D         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      00511F E0               [24] 1179 	movx	a,@dptr
      005120 FE               [12] 1180 	mov	r6,a
      005121 90 07 1E         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005124 E0               [24] 1182 	movx	a,@dptr
      005125 FD               [12] 1183 	mov	r5,a
      005126 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      005129 EE               [12] 1185 	mov	a,r6
      00512A F0               [24] 1186 	movx	@dptr,a
      00512B 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      00512E ED               [12] 1188 	mov	a,r5
      00512F F0               [24] 1189 	movx	@dptr,a
      005130 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005132 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      005135                       1206 _sine8:
      005135 E5 82            [12] 1207 	mov	a,dpl
      005137 90 07 20         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      00513A F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      00513B E0               [24] 1211 	movx	a,@dptr
      00513C FF               [12] 1212 	mov	r7,a
      00513D 90 07 21         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005140 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005141 EF               [12] 1216 	mov	a,r7
      005142 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      005145 90 07 21         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      005148 74 FF            [12] 1219 	mov	a,#0xff
      00514A C3               [12] 1220 	clr	c
      00514B 9F               [12] 1221 	subb	a,r7
      00514C F0               [24] 1222 	movx	@dptr,a
      00514D                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      00514D 90 07 21         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005150 E0               [24] 1226 	movx	a,@dptr
      005151 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      005154 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      005155 90 07 21         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      005158 E0               [24] 1231 	movx	a,@dptr
      005159 54 0F            [12] 1232 	anl	a,#0x0f
      00515B FF               [12] 1233 	mov	r7,a
      00515C 90 07 22         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      00515F F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005160 90 07 20         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005163 E0               [24] 1238 	movx	a,@dptr
      005164 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      005167 90 07 22         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      00516A EF               [12] 1241 	mov	a,r7
      00516B 04               [12] 1242 	inc	a
      00516C F0               [24] 1243 	movx	@dptr,a
      00516D                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      00516D 90 07 21         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005170 E0               [24] 1247 	movx	a,@dptr
      005171 C4               [12] 1248 	swap	a
      005172 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005174 25 E0            [12] 1251 	add	a,acc
      005176 FF               [12] 1252 	mov	r7,a
      005177 90 B8 A5         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      00517A 93               [24] 1254 	movc	a,@a+dptr
      00517B FE               [12] 1255 	mov	r6,a
      00517C 0F               [12] 1256 	inc	r7
      00517D EF               [12] 1257 	mov	a,r7
      00517E 90 B8 A5         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005181 93               [24] 1259 	movc	a,@a+dptr
      005182 FF               [12] 1260 	mov	r7,a
      005183 90 07 22         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      005186 E0               [24] 1262 	movx	a,@dptr
      005187 8F F0            [24] 1263 	mov	b,r7
      005189 A4               [48] 1264 	mul	ab
      00518A FF               [12] 1265 	mov	r7,a
      00518B E5 F0            [12] 1266 	mov	a,b
      00518D C4               [12] 1267 	swap	a
      00518E CF               [12] 1268 	xch	a,r7
      00518F C4               [12] 1269 	swap	a
      005190 54 0F            [12] 1270 	anl	a,#0x0f
      005192 6F               [12] 1271 	xrl	a,r7
      005193 CF               [12] 1272 	xch	a,r7
      005194 54 0F            [12] 1273 	anl	a,#0x0f
      005196 CF               [12] 1274 	xch	a,r7
      005197 6F               [12] 1275 	xrl	a,r7
      005198 CF               [12] 1276 	xch	a,r7
      005199 EF               [12] 1277 	mov	a,r7
      00519A 2E               [12] 1278 	add	a, r6
      00519B FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      00519C 90 07 20         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      00519F E0               [24] 1282 	movx	a,@dptr
      0051A0 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      0051A3 8F 06            [24] 1284 	mov	ar6,r7
      0051A5 74 80            [12] 1285 	mov	a,#0x80
      0051A7 C3               [12] 1286 	clr	c
      0051A8 9E               [12] 1287 	subb	a,r6
      0051A9 FE               [12] 1288 	mov	r6,a
      0051AA 80 04            [24] 1289 	sjmp	00108$
      0051AC                       1290 00107$:
      0051AC 74 80            [12] 1291 	mov	a,#0x80
      0051AE 2F               [12] 1292 	add	a, r7
      0051AF FE               [12] 1293 	mov	r6,a
      0051B0                       1294 00108$:
      0051B0 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      0051B2 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      0051B3                       1312 _breathing_cie:
      0051B3 E5 82            [12] 1313 	mov	a,dpl
      0051B5 90 07 23         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      0051B8 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      0051B9 E0               [24] 1317 	movx	a,@dptr
      0051BA FF               [12] 1318 	mov	r7,a
      0051BB 12 57 36         [24] 1319 	lcall	_ak820_outline_0190
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0051BE FE               [12] 1321 	mov	r6,a
      0051BF 90 BB B1         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0051C2 93               [24] 1323 	movc	a,@a+dptr
      0051C3 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0051C4 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0051C7 8D 82            [24] 1327 	mov	dpl, r5
      0051C9 22               [24] 1328 	ret
      0051CA                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0051CA EE               [12] 1331 	mov	a,r6
      0051CB 04               [12] 1332 	inc	a
      0051CC 90 BB B1         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0051CF 93               [24] 1334 	movc	a,@a+dptr
      0051D0 C3               [12] 1335 	clr	c
      0051D1 9D               [12] 1336 	subb	a,r5
      0051D2 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0051D3 74 07            [12] 1339 	mov	a,#0x07
      0051D5 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0051D6 F5 F0            [12] 1342 	mov	b,a
      0051D8 EE               [12] 1343 	mov	a,r6
      0051D9 A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0051DA 12 57 36         [24] 1346 	lcall	_ak820_outline_0190
      0051DD 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0051DE F5 82            [12] 1349 	mov	dpl,a
      0051E0 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      0051E1                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0051E1 12 4F 5E         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0051E4 30 12 18         [24] 1369 	jnb	_dirty,00102$
      0051E7 90 06 B3         [24] 1370 	mov	dptr,#_changed_at
      0051EA 12 37 F4         [24] 1371 	lcall	_ak820_outline_0005
      0051ED 12 49 39         [24] 1372 	lcall	_timer_elapsed
      0051F0 12 43 5C         [24] 1373 	lcall	_ak820_outline_0135
      0051F3 C3               [12] 1374 	clr	c
      0051F4 EE               [12] 1375 	mov	a,r6
      0051F5 94 E8            [12] 1376 	subb	a,#0xe8
      0051F7 EF               [12] 1377 	mov	a,r7
      0051F8 94 03            [12] 1378 	subb	a,#0x03
      0051FA 40 03            [24] 1379 	jc	00102$
      0051FC 12 50 2D         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      0051FF                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0051FF 30 13 03         [24] 1383 	jnb	_rendering,00254$
      005202 02 52 BA         [24] 1384 	ljmp	00109$
      005205                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      005205 90 06 B5         [24] 1387 	mov	dptr,#_frame_at
      005208 12 37 F4         [24] 1388 	lcall	_ak820_outline_0005
      00520B 12 49 39         [24] 1389 	lcall	_timer_elapsed
      00520E 12 43 5C         [24] 1390 	lcall	_ak820_outline_0135
      005211 C3               [12] 1391 	clr	c
      005212 EE               [12] 1392 	mov	a,r6
      005213 94 10            [12] 1393 	subb	a,#0x10
      005215 EF               [12] 1394 	mov	a,r7
      005216 94 00            [12] 1395 	subb	a,#0x00
      005218 50 01            [24] 1396 	jnc	00105$
      00521A 22               [24] 1397 	ret
      00521B                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      00521B 12 49 36         [24] 1400 	lcall	_timer_read
      00521E 12 38 A6         [24] 1401 	lcall	_ak820_outline_0140
      005221 90 06 B5         [24] 1402 	mov	dptr,#_frame_at
      005224 12 57 14         [24] 1403 	lcall	_ak820_outline_0172
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      005227 90 06 AF         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00522A E0               [24] 1406 	movx	a,@dptr
      00522B FF               [12] 1407 	mov	r7,a
      00522C 7E 00            [12] 1408 	mov	r6,#0x00
      00522E 74 20            [12] 1409 	mov	a,#0x20
      005230 2F               [12] 1410 	add	a, r7
      005231 FF               [12] 1411 	mov	r7,a
      005232 E4               [12] 1412 	clr	a
      005233 3E               [12] 1413 	addc	a, r6
      005234 FE               [12] 1414 	mov	r6,a
      005235 90 06 B7         [24] 1415 	mov	dptr,#_phase
      005238 12 38 58         [24] 1416 	lcall	_ak820_outline_0061
      00523B EF               [12] 1417 	mov	a,r7
      00523C 2C               [12] 1418 	add	a, r4
      00523D FF               [12] 1419 	mov	r7,a
      00523E EE               [12] 1420 	mov	a,r6
      00523F 3D               [12] 1421 	addc	a, r5
      005240 FE               [12] 1422 	mov	r6,a
      005241 90 06 B7         [24] 1423 	mov	dptr,#_phase
      005244 EF               [12] 1424 	mov	a,r7
      005245 F0               [24] 1425 	movx	@dptr,a
      005246 EE               [12] 1426 	mov	a,r6
      005247 A3               [24] 1427 	inc	dptr
      005248 F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      005249 90 06 B7         [24] 1430 	mov	dptr,#_phase
      00524C E0               [24] 1431 	movx	a,@dptr
      00524D A3               [24] 1432 	inc	dptr
      00524E E0               [24] 1433 	movx	a,@dptr
      00524F FF               [12] 1434 	mov	r7,a
      005250 90 06 BF         [24] 1435 	mov	dptr,#_frame_phase
      005253 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005254 20 11 05         [24] 1438 	jb	_suspended,00135$
      005257 12 56 D7         [24] 1439 	lcall	_ak820_outline_0066
      00525A 70 04            [24] 1440 	jnz	00132$
      00525C                       1441 00135$:
      00525C 7E 00            [12] 1442 	mov	r6,#0x00
      00525E 80 04            [24] 1443 	sjmp	00133$
      005260                       1444 00132$:
      005260 12 56 B8         [24] 1445 	lcall	_ak820_outline_0019
      005263 FE               [12] 1446 	mov	r6,a
      005264                       1447 00133$:
      005264 90 06 BA         [24] 1448 	mov	dptr,#_frame_mode
      005267 EE               [12] 1449 	mov	a,r6
      005268 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      005269 90 06 AC         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00526C E0               [24] 1453 	movx	a,@dptr
      00526D 90 06 BB         [24] 1454 	mov	dptr,#_frame_hue
      005270 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005271 90 06 AD         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005274 E0               [24] 1458 	movx	a,@dptr
      005275 90 06 BC         [24] 1459 	mov	dptr,#_frame_sat
      005278 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      005279 90 06 AE         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00527C E0               [24] 1463 	movx	a,@dptr
      00527D FD               [12] 1464 	mov	r5,a
      00527E 90 06 BD         [24] 1465 	mov	dptr,#_frame_val
      005281 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005282 90 06 B0         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005285 E0               [24] 1469 	movx	a,@dptr
      005286 90 06 BE         [24] 1470 	mov	dptr,#_frame_flags
      005289 F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00528A BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      00528D EF               [12] 1475 	mov	a,r7
      00528E 24 C0            [12] 1476 	add	a,#0xc0
      005290 F5 82            [12] 1477 	mov	dpl,a
      005292 C0 05            [24] 1478 	push	ar5
      005294 12 51 35         [24] 1479 	lcall	_sine8
      005297 AF 82            [24] 1480 	mov	r7, dpl
      005299 D0 05            [24] 1481 	pop	ar5
      00529B 8D F0            [24] 1482 	mov	b,r5
      00529D EF               [12] 1483 	mov	a,r7
      00529E A4               [48] 1484 	mul	ab
      00529F AE F0            [24] 1485 	mov	r6,b
      0052A1 8E 05            [24] 1486 	mov	ar5,r6
      0052A3 90 06 BD         [24] 1487 	mov	dptr,#_frame_val
      0052A6 ED               [12] 1488 	mov	a,r5
      0052A7 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      0052A8 8D 82            [24] 1491 	mov	dpl, r5
      0052AA 12 51 B3         [24] 1492 	lcall	_breathing_cie
      0052AD E5 82            [12] 1493 	mov	a, dpl
      0052AF 90 06 BD         [24] 1494 	mov	dptr,#_frame_val
      0052B2 F0               [24] 1495 	movx	@dptr,a
      0052B3                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      0052B3 90 06 B9         [24] 1498 	mov	dptr,#_led_index
      0052B6 E4               [12] 1499 	clr	a
      0052B7 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      0052B8 D2 13            [12] 1503 	setb	_rendering
      0052BA                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      0052BA 12 57 31         [24] 1506 	lcall	_ak820_outline_0188
      0052BD 24 08            [12] 1507 	add	a,#0x08
      0052BF FF               [12] 1508 	mov	r7,a
      0052C0 90 07 24         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052C3 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0052C4 EF               [12] 1512 	mov	a,r7
      0052C5 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0052C7 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0052C9 90 07 24         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052CC 74 52            [12] 1517 	mov	a,#0x52
      0052CE F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0052CF                       1520 00125$:
      0052CF 12 57 31         [24] 1521 	lcall	_ak820_outline_0188
      0052D2 FF               [12] 1522 	mov	r7,a
      0052D3 90 07 24         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052D6 E0               [24] 1524 	movx	a,@dptr
      0052D7 FE               [12] 1525 	mov	r6,a
      0052D8 C3               [12] 1526 	clr	c
      0052D9 EF               [12] 1527 	mov	a,r7
      0052DA 9E               [12] 1528 	subb	a,r6
      0052DB 40 03            [24] 1529 	jc	00261$
      0052DD 02 54 40         [24] 1530 	ljmp	00127$
      0052E0                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0052E0 12 57 0E         [24] 1533 	lcall	_ak820_outline_0142
      0052E3 E0               [24] 1534 	movx	a,@dptr
      0052E4 60 07            [24] 1535 	jz	00121$
      0052E6 90 06 BE         [24] 1536 	mov	dptr,#_frame_flags
      0052E9 E0               [24] 1537 	movx	a,@dptr
      0052EA 20 E2 1B         [24] 1538 	jb	acc.2,00122$
      0052ED                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0052ED 12 57 31         [24] 1541 	lcall	_ak820_outline_0188
      0052F0 FC               [12] 1542 	mov	r4,a
      0052F1 7D 00            [12] 1543 	mov	r5,#0x00
      0052F3 90 07 18         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0052F6 E4               [12] 1545 	clr	a
      0052F7 F0               [24] 1546 	movx	@dptr,a
      0052F8 90 07 19         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0052FB F0               [24] 1548 	movx	@dptr,a
      0052FC 90 07 1A         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0052FF 12 38 76         [24] 1550 	lcall	_ak820_outline_0103
      005302 12 50 D3         [24] 1551 	lcall	_rgb_matrix_set_color
      005305 02 54 37         [24] 1552 	ljmp	00123$
      005308                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      005308 BE 05 21         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      00530B EF               [12] 1557 	mov	a,r7
      00530C 75 F0 03         [24] 1558 	mov	b,#0x03
      00530F A4               [48] 1559 	mul	ab
      005310 24 8B            [12] 1560 	add	a, #_g_direct_mode_colors
      005312 FD               [12] 1561 	mov	r5,a
      005313 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      005315 35 F0            [12] 1563 	addc	a, b
      005317 FE               [12] 1564 	mov	r6,a
      005318 90 0D 9F         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      00531B ED               [12] 1566 	mov	a,r5
      00531C F0               [24] 1567 	movx	@dptr,a
      00531D EE               [12] 1568 	mov	a,r6
      00531E 12 56 E8         [24] 1569 	lcall	_ak820_outline_0073
      005321 90 07 25         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005324 F5 F0            [12] 1571 	mov	b,a
      005326 12 B7 4A         [24] 1572 	lcall	___memcpy
      005329 02 53 DB         [24] 1573 	ljmp	00120$
      00532C                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      00532C 90 06 BB         [24] 1576 	mov	dptr,#_frame_hue
      00532F E0               [24] 1577 	movx	a,@dptr
      005330 90 07 25         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005333 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005334 90 06 BC         [24] 1581 	mov	dptr,#_frame_sat
      005337 E0               [24] 1582 	movx	a,@dptr
      005338 90 07 26         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      00533B F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      00533C 90 06 BD         [24] 1586 	mov	dptr,#_frame_val
      00533F E0               [24] 1587 	movx	a,@dptr
      005340 90 07 27         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005343 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005344 12 57 0E         [24] 1591 	lcall	_ak820_outline_0142
      005347 BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      00534A 90 07 25         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00534D E0               [24] 1594 	movx	a,@dptr
      00534E FE               [12] 1595 	mov	r6,a
      00534F 90 06 BF         [24] 1596 	mov	dptr,#_frame_phase
      005352 E0               [24] 1597 	movx	a,@dptr
      005353 2E               [12] 1598 	add	a, r6
      005354 90 07 25         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005357 F0               [24] 1600 	movx	@dptr,a
      005358                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005358 12 57 0E         [24] 1603 	lcall	_ak820_outline_0142
      00535B BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      00535E 90 07 25         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005361 E0               [24] 1606 	movx	a,@dptr
      005362 FE               [12] 1607 	mov	r6,a
      005363 12 57 31         [24] 1608 	lcall	_ak820_outline_0188
      005366 75 F0 02         [24] 1609 	mov	b,#0x02
      005369 A4               [48] 1610 	mul	ab
      00536A 24 0D            [12] 1611 	add	a, #_ak820_led_points
      00536C F5 82            [12] 1612 	mov	dpl,a
      00536E 74 BB            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      005370 12 57 00         [24] 1614 	lcall	_ak820_outline_0109
      005373 FD               [12] 1615 	mov	r5,a
      005374 90 06 BF         [24] 1616 	mov	dptr,#_frame_phase
      005377 E0               [24] 1617 	movx	a,@dptr
      005378 FC               [12] 1618 	mov	r4,a
      005379 ED               [12] 1619 	mov	a,r5
      00537A C3               [12] 1620 	clr	c
      00537B 9C               [12] 1621 	subb	a,r4
      00537C 2E               [12] 1622 	add	a, r6
      00537D 90 07 25         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005380 F0               [24] 1624 	movx	@dptr,a
      005381                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      005381 12 57 0E         [24] 1627 	lcall	_ak820_outline_0142
      005384 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005387 12 57 1F         [24] 1630 	lcall	_ak820_outline_0176
      00538A FE               [12] 1631 	mov	r6,a
      00538B 74 07            [12] 1632 	mov	a,#0x07
      00538D C3               [12] 1633 	clr	c
      00538E 9E               [12] 1634 	subb	a,r6
      00538F FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      005390 8E F0            [24] 1637 	mov	b,r6
      005392 05 F0            [12] 1638 	inc	b
      005394 74 01            [12] 1639 	mov	a,#0x01
      005396 80 02            [24] 1640 	sjmp	00273$
      005398                       1641 00272$:
      005398 25 E0            [12] 1642 	add	a,acc
      00539A                       1643 00273$:
      00539A D5 F0 FB         [24] 1644 	djnz	b,00272$
      00539D FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00539E 12 57 31         [24] 1647 	lcall	_ak820_outline_0188
      0053A1 24 C0            [12] 1648 	add	a, #_reactive_age
      0053A3 F5 82            [12] 1649 	mov	dpl,a
      0053A5 E4               [12] 1650 	clr	a
      0053A6 34 06            [12] 1651 	addc	a, #(_reactive_age >> 8)
      0053A8 F5 83            [12] 1652 	mov	dph,a
      0053AA E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      0053AB FC               [12] 1655 	mov	r4,a
      0053AC C3               [12] 1656 	clr	c
      0053AD 9D               [12] 1657 	subb	a,r5
      0053AE 40 07            [24] 1658 	jc	00137$
      0053B0 90 06 BD         [24] 1659 	mov	dptr,#_frame_val
      0053B3 E0               [24] 1660 	movx	a,@dptr
      0053B4 FB               [12] 1661 	mov	r3,a
      0053B5 80 1F            [24] 1662 	sjmp	00138$
      0053B7                       1663 00137$:
      0053B7 90 06 BD         [24] 1664 	mov	dptr,#_frame_val
      0053BA E0               [24] 1665 	movx	a,@dptr
      0053BB F5 F0            [12] 1666 	mov	b, a
      0053BD EC               [12] 1667 	mov	a,r4
      0053BE A4               [48] 1668 	mul	ab
      0053BF FC               [12] 1669 	mov	r4,a
      0053C0 AA F0            [24] 1670 	mov	r2,b
      0053C2 8E F0            [24] 1671 	mov	b,r6
      0053C4 05 F0            [12] 1672 	inc	b
      0053C6 AB 04            [24] 1673 	mov	r3,ar4
      0053C8 AD 02            [24] 1674 	mov	r5,ar2
      0053CA 80 07            [24] 1675 	sjmp	00276$
      0053CC                       1676 00275$:
      0053CC C3               [12] 1677 	clr	c
      0053CD ED               [12] 1678 	mov	a,r5
      0053CE 13               [12] 1679 	rrc	a
      0053CF FD               [12] 1680 	mov	r5,a
      0053D0 EB               [12] 1681 	mov	a,r3
      0053D1 13               [12] 1682 	rrc	a
      0053D2 FB               [12] 1683 	mov	r3,a
      0053D3                       1684 00276$:
      0053D3 D5 F0 F6         [24] 1685 	djnz	b,00275$
      0053D6                       1686 00138$:
      0053D6 90 07 27         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0053D9 EB               [12] 1688 	mov	a,r3
      0053DA F0               [24] 1689 	movx	@dptr,a
      0053DB                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0053DB 12 57 0E         [24] 1692 	lcall	_ak820_outline_0142
      0053DE BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      0053E1 D3               [12] 1694 	setb	c
      0053E2 80 01            [24] 1695 	sjmp	00278$
      0053E4                       1696 00277$:
      0053E4 C3               [12] 1697 	clr	c
      0053E5                       1698 00278$:
      0053E5 B3               [12] 1699 	cpl	c
      0053E6 92 14            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      0053E8 90 0D 9F         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      0053EB 74 25            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0053ED F0               [24] 1703 	movx	@dptr,a
      0053EE 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0053F0 12 56 E8         [24] 1705 	lcall	_ak820_outline_0073
      0053F3 90 0A C7         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0053F6 F5 F0            [12] 1707 	mov	b,a
      0053F8 12 B7 4A         [24] 1708 	lcall	___memcpy
      0053FB 90 0A CA         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0053FE 74 28            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      005400 F0               [24] 1711 	movx	@dptr,a
      005401 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005403 A3               [24] 1713 	inc	dptr
      005404 F0               [24] 1714 	movx	@dptr,a
      005405 A2 14            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      005407 12 38 B1         [24] 1716 	lcall	_ak820_outline_0159
      00540A 12 81 6F         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      00540D 12 57 31         [24] 1719 	lcall	_ak820_outline_0188
      005410 FD               [12] 1720 	mov	r5,a
      005411 7E 00            [12] 1721 	mov	r6,#0x00
      005413 90 07 29         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      005416 E0               [24] 1723 	movx	a,@dptr
      005417 FC               [12] 1724 	mov	r4,a
      005418 90 07 28         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      00541B E0               [24] 1726 	movx	a,@dptr
      00541C FB               [12] 1727 	mov	r3,a
      00541D 90 07 2A         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005420 E0               [24] 1729 	movx	a,@dptr
      005421 FA               [12] 1730 	mov	r2,a
      005422 90 07 18         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005425 EC               [12] 1732 	mov	a,r4
      005426 F0               [24] 1733 	movx	@dptr,a
      005427 90 07 19         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00542A EB               [12] 1735 	mov	a,r3
      00542B F0               [24] 1736 	movx	@dptr,a
      00542C 90 07 1A         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00542F EA               [12] 1738 	mov	a,r2
      005430 F0               [24] 1739 	movx	@dptr,a
      005431 12 38 A1         [24] 1740 	lcall	_ak820_outline_0137
      005434 12 50 D3         [24] 1741 	lcall	_rgb_matrix_set_color
      005437                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005437 12 57 31         [24] 1744 	lcall	_ak820_outline_0188
      00543A 24 01            [12] 1745 	add	a, #0x01
      00543C F0               [24] 1746 	movx	@dptr,a
      00543D 02 52 CF         [24] 1747 	ljmp	00125$
      005440                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005440 BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      005443 C2 13            [12] 1753 	clr	_rendering
      005445                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005445 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      005446                       1770 _process_rgb_matrix:
      005446 E5 82            [12] 1771 	mov	a,dpl
      005448 90 07 2D         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00544B F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      00544C 90 07 2C         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      00544F E0               [24] 1776 	movx	a,@dptr
      005450 60 23            [24] 1777 	jz	00101$
      005452 20 11 20         [24] 1778 	jb	_suspended,00101$
      005455 12 56 D7         [24] 1779 	lcall	_ak820_outline_0066
      005458 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00545A 12 56 B8         [24] 1782 	lcall	_ak820_outline_0019
      00545D FF               [12] 1783 	mov	r7,a
      00545E BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      005461 90 07 2D         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005464 E0               [24] 1786 	movx	a,@dptr
      005465 FF               [12] 1787 	mov	r7,a
      005466 BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      005469                       1789 00169$:
      005469 50 0A            [24] 1790 	jnc	00101$
      00546B 90 07 2B         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      00546E E0               [24] 1792 	movx	a,@dptr
      00546F FE               [12] 1793 	mov	r6,a
      005470 BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      005473                       1795 00171$:
      005473 40 01            [24] 1796 	jc	00102$
      005475                       1797 00101$:
      005475 22               [24] 1798 	ret
      005476                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005476 C0 07            [24] 1801 	push	ar7
      005478 C0 06            [24] 1802 	push	ar6
      00547A 12 4F 5E         [24] 1803 	lcall	_age_reactive
      00547D D0 06            [24] 1804 	pop	ar6
      00547F D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      005481 EF               [12] 1807 	mov	a,r7
      005482 12 38 C6         [24] 1808 	lcall	_ak820_outline_0192
      005485 2E               [12] 1809 	add	a,r6
      005486 FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005487 7E 00            [12] 1812 	mov	r6,#0x00
      005489                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005489 EE               [12] 1815 	mov	a,r6
      00548A 90 B8 53         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      00548D 93               [24] 1817 	movc	a,@a+dptr
      00548E B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      005491 EE               [12] 1820 	mov	a,r6
      005492 24 C0            [12] 1821 	add	a, #_reactive_age
      005494 FC               [12] 1822 	mov	r4,a
      005495 E4               [12] 1823 	clr	a
      005496 34 06            [12] 1824 	addc	a, #(_reactive_age >> 8)
      005498 FD               [12] 1825 	mov	r5,a
      005499 12 57 1F         [24] 1826 	lcall	_ak820_outline_0176
      00549C F5 F0            [12] 1827 	mov	b, a
      00549E 05 F0            [12] 1828 	inc	b
      0054A0 7B 80            [12] 1829 	mov	r3,#0x80
      0054A2 E4               [12] 1830 	clr	a
      0054A3 FA               [12] 1831 	mov	r2,a
      0054A4 33               [12] 1832 	rlc	a
      0054A5 92 D2            [24] 1833 	mov	ov,c
      0054A7 80 08            [24] 1834 	sjmp	00176$
      0054A9                       1835 00175$:
      0054A9 A2 D2            [12] 1836 	mov	c,ov
      0054AB EA               [12] 1837 	mov	a,r2
      0054AC 13               [12] 1838 	rrc	a
      0054AD FA               [12] 1839 	mov	r2,a
      0054AE EB               [12] 1840 	mov	a,r3
      0054AF 13               [12] 1841 	rrc	a
      0054B0 FB               [12] 1842 	mov	r3,a
      0054B1                       1843 00176$:
      0054B1 D5 F0 F5         [24] 1844 	djnz	b,00175$
      0054B4 12 38 97         [24] 1845 	lcall	_ak820_outline_0126
      0054B7 EB               [12] 1846 	mov	a,r3
      0054B8 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      0054B9 22               [24] 1849 	ret
      0054BA                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054BA 0E               [12] 1852 	inc	r6
      0054BB BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      0054BE                       1854 00177$:
      0054BE 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      0054C0 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      0054C1                       1868 _rgb_matrix_set_suspend_state:
      0054C1 E5 82            [12] 1869 	mov	a,dpl
      0054C3 90 07 2E         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0054C6 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0054C7 E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      0054C8 F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0054CA 13               [12] 1876 	rrc	a
      0054CB 92 11            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      0054CD C2 13            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0054CF 12 4F 41         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0054D2 E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0054D4 60 0F            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0054D6 90 07 1D         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0054D9 E4               [12] 1888 	clr	a
      0054DA F0               [24] 1889 	movx	@dptr,a
      0054DB 90 07 1E         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0054DE F0               [24] 1891 	movx	@dptr,a
      0054DF 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0054E2 02 51 14         [24] 1894 	ljmp	_rgb_matrix_set_color_all
      0054E5                       1895 00103$:
      0054E5 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      0054E6                       1904 _rgb_matrix_is_enabled:
      0054E6 12 56 D7         [24] 1905 	lcall	_ak820_outline_0066
      0054E9 F5 82            [12] 1906 	mov	dpl,a
      0054EB 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      0054EC                       1915 _rgb_matrix_get_mode:
      0054EC 12 56 B8         [24] 1916 	lcall	_ak820_outline_0019
      0054EF F5 82            [12] 1917 	mov	dpl,a
      0054F1 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      0054F2                       1926 _rgb_matrix_get_hue:
      0054F2 90 06 AC         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0054F5 E0               [24] 1928 	movx	a,@dptr
      0054F6 F5 82            [12] 1929 	mov	dpl,a
      0054F8 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      0054F9                       1938 _rgb_matrix_get_sat:
      0054F9 90 06 AD         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0054FC E0               [24] 1940 	movx	a,@dptr
      0054FD F5 82            [12] 1941 	mov	dpl,a
      0054FF 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      005500                       1950 _rgb_matrix_get_val:
      005500 90 06 AE         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005503 E0               [24] 1952 	movx	a,@dptr
      005504 F5 82            [12] 1953 	mov	dpl,a
      005506 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      005507                       1962 _rgb_matrix_get_speed:
      005507 90 06 AF         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00550A E0               [24] 1964 	movx	a,@dptr
      00550B F5 82            [12] 1965 	mov	dpl,a
      00550D 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      00550E                       1974 _rgb_matrix_toggle_noeeprom:
      00550E 12 56 D7         [24] 1975 	lcall	_ak820_outline_0066
      005511 FF               [12] 1976 	mov	r7,a
      005512 63 07 01         [24] 1977 	xrl	ar7,#0x01
      005515 90 06 AB         [24] 1978 	mov	dptr,#_rgb_matrix_config
      005518 EF               [12] 1979 	mov	a,r7
      005519 54 03            [12] 1980 	anl	a,#0x03
      00551B F5 F0            [12] 1981 	mov	b,a
      00551D E0               [24] 1982 	movx	a,@dptr
      00551E 54 FC            [12] 1983 	anl	a,#0xfc
      005520 45 F0            [12] 1984 	orl	a,b
      005522 F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      005523 C2 13            [12] 1987 	clr	_rendering
      005525 02 4F 41         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      005528                       1996 _rgb_matrix_enable_noeeprom:
      005528 12 56 D7         [24] 1997 	lcall	_ak820_outline_0066
      00552B 70 03            [24] 1998 	jnz	00102$
      00552D 12 4F 41         [24] 1999 	lcall	_clear_reactive
      005530                       2000 00102$:
      005530 12 57 07         [24] 2001 	lcall	_ak820_outline_0115
      005533 44 01            [12] 2002 	orl	a,#0x01
      005535 F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      005536 C2 13            [12] 2005 	clr	_rendering
      005538 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      005539                       2014 _rgb_matrix_disable_noeeprom:
      005539 12 57 07         [24] 2015 	lcall	_ak820_outline_0115
      00553C F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      00553D C2 13            [12] 2018 	clr	_rendering
      00553F 02 4F 41         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      005542                       2029 _rgb_matrix_mode_noeeprom:
      005542 E5 82            [12] 2030 	mov	a,dpl
      005544 90 07 2F         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005547 F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005548 E0               [24] 2034 	movx	a,@dptr
      005549 FF               [12] 2035 	mov	r7,a
      00554A 60 05            [24] 2036 	jz	00101$
      00554C BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      00554F                       2038 00123$:
      00554F 40 01            [24] 2039 	jc	00102$
      005551                       2040 00101$:
      005551 22               [24] 2041 	ret
      005552                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005552 12 56 B8         [24] 2044 	lcall	_ak820_outline_0019
      005555 FE               [12] 2045 	mov	r6,a
      005556 EF               [12] 2046 	mov	a,r7
      005557 B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      00555A 80 03            [24] 2048 	sjmp	00105$
      00555C                       2049 00125$:
      00555C 12 4F 41         [24] 2050 	lcall	_clear_reactive
      00555F                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      00555F 90 07 2F         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005562 E0               [24] 2054 	movx	a,@dptr
      005563 90 06 AB         [24] 2055 	mov	dptr,#_rgb_matrix_config
      005566 25 E0            [12] 2056 	add	a,acc
      005568 25 E0            [12] 2057 	add	a,acc
      00556A 54 FC            [12] 2058 	anl	a,#0xfc
      00556C F5 F0            [12] 2059 	mov	b,a
      00556E E0               [24] 2060 	movx	a,@dptr
      00556F 54 03            [12] 2061 	anl	a,#0x03
      005571 45 F0            [12] 2062 	orl	a,b
      005573 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      005574 C2 13            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005576 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      005577                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005577 12 56 B8         [24] 2078 	lcall	_ak820_outline_0019
      00557A FF               [12] 2079 	mov	r7,a
      00557B 0F               [12] 2080 	inc	r7
      00557C BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      00557F                       2082 00112$:
      00557F 40 04            [24] 2083 	jc	00103$
      005581 7F 01            [12] 2084 	mov	r7,#0x01
      005583 80 07            [24] 2085 	sjmp	00104$
      005585                       2086 00103$:
      005585 12 56 B8         [24] 2087 	lcall	_ak820_outline_0019
      005588 FE               [12] 2088 	mov	r6,a
      005589 0E               [12] 2089 	inc	r6
      00558A 8E 07            [24] 2090 	mov	ar7,r6
      00558C                       2091 00104$:
      00558C 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      00558E 02 55 42         [24] 2094 	ljmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      005591                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      005591 12 56 B8         [24] 2104 	lcall	_ak820_outline_0019
      005594 24 FE            [12] 2105 	add	a,#0xff - 0x01
      005596 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      005598 7F 06            [12] 2108 	mov	r7,#0x06
      00559A 80 05            [24] 2109 	sjmp	00104$
      00559C                       2110 00103$:
      00559C 12 56 B8         [24] 2111 	lcall	_ak820_outline_0019
      00559F 14               [12] 2112 	dec	a
      0055A0 FF               [12] 2113 	mov	r7,a
      0055A1                       2114 00104$:
      0055A1 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      0055A3 02 55 42         [24] 2117 	ljmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      0055A6                       2129 _rgb_matrix_sethsv_noeeprom:
      0055A6 12 38 82         [24] 2130 	lcall	_ak820_outline_0118
      0055A9 90 07 32         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      0055AC 12 38 87         [24] 2132 	lcall	_ak820_outline_0119
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      0055AF 90 07 32         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      0055B2 E0               [24] 2135 	movx	a,@dptr
      0055B3 90 06 AC         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055B6 F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      0055B7 90 07 30         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      0055BA E0               [24] 2140 	movx	a,@dptr
      0055BB FF               [12] 2141 	mov	r7,a
      0055BC 90 06 AD         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055BF F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0055C0 90 07 31         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      0055C3 E0               [24] 2146 	movx	a,@dptr
      0055C4 FF               [12] 2147 	mov  r7,a
      0055C5 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      0055C7 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      0055C9 7E A0            [12] 2151 	mov	r6,#0xa0
      0055CB 80 02            [24] 2152 	sjmp	00104$
      0055CD                       2153 00103$:
      0055CD 8F 06            [24] 2154 	mov	ar6,r7
      0055CF                       2155 00104$:
      0055CF 90 06 AE         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055D2 EE               [12] 2157 	mov	a,r6
      0055D3 F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      0055D4 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      0055D5                       2170 _rgb_matrix_set_speed_noeeprom:
      0055D5 E5 82            [12] 2171 	mov	a,dpl
      0055D7 90 07 34         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      0055DA F0               [24] 2173 	movx	@dptr,a
      0055DB E0               [24] 2174 	movx	a,@dptr
      0055DC 90 06 AF         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0055DF F0               [24] 2176 	movx	@dptr,a
      0055E0 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      0055E1                       2187 _rgb_matrix_increase_hue_noeeprom:
      0055E1 90 06 AC         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055E4 E0               [24] 2189 	movx	a,@dptr
      0055E5 24 08            [12] 2190 	add	a,#0x08
      0055E7 90 06 AC         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055EA F0               [24] 2192 	movx	@dptr,a
      0055EB 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      0055EC                       2201 _rgb_matrix_decrease_hue_noeeprom:
      0055EC 90 06 AC         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055EF E0               [24] 2203 	movx	a,@dptr
      0055F0 24 F8            [12] 2204 	add	a,#0xf8
      0055F2 90 06 AC         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055F5 F0               [24] 2206 	movx	@dptr,a
      0055F6 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      0055F7                       2215 _rgb_matrix_increase_sat_noeeprom:
      0055F7 90 06 AD         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055FA 12 56 C1         [24] 2217 	lcall	_ak820_outline_0048
      0055FD 12 4F DC         [24] 2218 	lcall	_add_sat
      005600 AF 82            [24] 2219 	mov	r7, dpl
      005602 90 06 AD         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005605 EF               [12] 2221 	mov	a,r7
      005606 F0               [24] 2222 	movx	@dptr,a
      005607 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      005608                       2231 _rgb_matrix_decrease_sat_noeeprom:
      005608 90 06 AD         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00560B 12 56 CC         [24] 2233 	lcall	_ak820_outline_0049
      00560E 12 50 01         [24] 2234 	lcall	_sub_sat
      005611 AF 82            [24] 2235 	mov	r7, dpl
      005613 90 06 AD         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005616 EF               [12] 2237 	mov	a,r7
      005617 F0               [24] 2238 	movx	@dptr,a
      005618 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      005619                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      005619 90 06 AE         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00561C 12 56 C1         [24] 2252 	lcall	_ak820_outline_0048
      00561F 12 4F DC         [24] 2253 	lcall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005622 E5 82            [12] 2255 	mov	a,dpl
      005624 FF               [12] 2256 	mov	r7,a
      005625 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      005627 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      005629 7E A0            [12] 2260 	mov	r6,#0xa0
      00562B 80 02            [24] 2261 	sjmp	00104$
      00562D                       2262 00103$:
      00562D 8F 06            [24] 2263 	mov	ar6,r7
      00562F                       2264 00104$:
      00562F 90 06 AE         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005632 EE               [12] 2266 	mov	a,r6
      005633 F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005634 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      005635                       2277 _rgb_matrix_decrease_val_noeeprom:
      005635 90 06 AE         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005638 12 56 CC         [24] 2279 	lcall	_ak820_outline_0049
      00563B 12 50 01         [24] 2280 	lcall	_sub_sat
      00563E AF 82            [24] 2281 	mov	r7, dpl
      005640 90 06 AE         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005643 EF               [12] 2283 	mov	a,r7
      005644 F0               [24] 2284 	movx	@dptr,a
      005645 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      005646                       2293 _rgb_matrix_increase_speed_noeeprom:
      005646 90 06 AF         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005649 12 56 C1         [24] 2295 	lcall	_ak820_outline_0048
      00564C 12 4F DC         [24] 2296 	lcall	_add_sat
      00564F AF 82            [24] 2297 	mov	r7, dpl
      005651 90 06 AF         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005654 EF               [12] 2299 	mov	a,r7
      005655 F0               [24] 2300 	movx	@dptr,a
      005656 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      005657                       2309 _rgb_matrix_decrease_speed_noeeprom:
      005657 90 06 AF         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00565A 12 56 CC         [24] 2311 	lcall	_ak820_outline_0049
      00565D 12 50 01         [24] 2312 	lcall	_sub_sat
      005660 AF 82            [24] 2313 	mov	r7, dpl
      005662 90 06 AF         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005665 EF               [12] 2315 	mov	a,r7
      005666 F0               [24] 2316 	movx	@dptr,a
      005667 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      005668                       2325 _rgb_matrix_toggle:
      005668 12 55 0E         [24] 2326 	lcall	_rgb_matrix_toggle_noeeprom
      00566B 02 50 1E         [24] 2327 	ljmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      00566E                       2335 _rgb_matrix_step:
      00566E 12 55 77         [24] 2336 	lcall	_rgb_matrix_step_noeeprom
      005671 02 50 1E         [24] 2337 	ljmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      005674                       2345 _rgb_matrix_step_reverse:
      005674 12 55 91         [24] 2346 	lcall	_rgb_matrix_step_reverse_noeeprom
      005677 02 50 1E         [24] 2347 	ljmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      00567A                       2355 _rgb_matrix_increase_hue:
      00567A 12 55 E1         [24] 2356 	lcall	_rgb_matrix_increase_hue_noeeprom
      00567D 02 50 1E         [24] 2357 	ljmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      005680                       2365 _rgb_matrix_decrease_hue:
      005680 12 55 EC         [24] 2366 	lcall	_rgb_matrix_decrease_hue_noeeprom
      005683 02 50 1E         [24] 2367 	ljmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      005686                       2375 _rgb_matrix_increase_sat:
      005686 12 55 F7         [24] 2376 	lcall	_rgb_matrix_increase_sat_noeeprom
      005689 02 50 1E         [24] 2377 	ljmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      00568C                       2385 _rgb_matrix_decrease_sat:
      00568C 12 56 08         [24] 2386 	lcall	_rgb_matrix_decrease_sat_noeeprom
      00568F 02 50 1E         [24] 2387 	ljmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      005692                       2395 _rgb_matrix_increase_val:
      005692 12 56 19         [24] 2396 	lcall	_rgb_matrix_increase_val_noeeprom
      005695 02 50 1E         [24] 2397 	ljmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      005698                       2405 _rgb_matrix_decrease_val:
      005698 12 56 35         [24] 2406 	lcall	_rgb_matrix_decrease_val_noeeprom
      00569B 02 50 1E         [24] 2407 	ljmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      00569E                       2415 _rgb_matrix_increase_speed:
      00569E 12 56 46         [24] 2416 	lcall	_rgb_matrix_increase_speed_noeeprom
      0056A1 02 50 1E         [24] 2417 	ljmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      0056A4                       2425 _rgb_matrix_decrease_speed:
      0056A4 12 56 57         [24] 2426 	lcall	_rgb_matrix_decrease_speed_noeeprom
      0056A7 02 50 1E         [24] 2427 	ljmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      0056AA                       2437 _rgb_matrix_mode:
      0056AA E5 82            [12] 2438 	mov	a,dpl
      0056AC 90 07 35         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      0056AF 12 57 1A         [24] 2440 	lcall	_ak820_outline_0173
      0056B2 12 55 42         [24] 2441 	lcall	_rgb_matrix_mode_noeeprom
      0056B5 02 50 1E         [24] 2442 	ljmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00B8A5                       2455 _sine8_coefficients_10000_290:
      00B8A5 00                    2456 	.db #0x00	; 0
      00B8A6 31                    2457 	.db #0x31	; 49	'1'
      00B8A7 31                    2458 	.db #0x31	; 49	'1'
      00B8A8 29                    2459 	.db #0x29	; 41
      00B8A9 5A                    2460 	.db #0x5a	; 90	'Z'
      00B8AA 1B                    2461 	.db #0x1b	; 27
      00B8AB 75                    2462 	.db #0x75	; 117	'u'
      00B8AC 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0052
                                   2474 	.globl _ak820_outline_0060
                                   2475 	.globl _ak820_outline_0061
                                   2476 	.globl _ak820_outline_0066
                                   2477 	.globl _ak820_outline_0070
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0087
                                   2480 	.globl _ak820_outline_0103
                                   2481 	.globl _ak820_outline_0105
                                   2482 	.globl _ak820_outline_0109
                                   2483 	.globl _ak820_outline_0115
                                   2484 	.globl _ak820_outline_0118
                                   2485 	.globl _ak820_outline_0119
                                   2486 	.globl _ak820_outline_0126
                                   2487 	.globl _ak820_outline_0135
                                   2488 	.globl _ak820_outline_0136
                                   2489 	.globl _ak820_outline_0137
                                   2490 	.globl _ak820_outline_0140
                                   2491 	.globl _ak820_outline_0142
                                   2492 	.globl _ak820_outline_0159
                                   2493 	.globl _ak820_outline_0172
                                   2494 	.globl _ak820_outline_0173
                                   2495 	.globl _ak820_outline_0176
                                   2496 	.globl _ak820_outline_0181
                                   2497 	.globl _ak820_outline_0188
                                   2498 	.globl _ak820_outline_0190
                                   2499 	.globl _ak820_outline_0192
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      0056B8                       2503 _ak820_outline_0019:
      0056B8 90 06 AB         [24] 2504 	mov	dptr,#_rgb_matrix_config
      0056BB E0               [24] 2505 	movx	a,@dptr
      0056BC 03               [12] 2506 	rr	a
      0056BD 03               [12] 2507 	rr	a
      0056BE 54 3F            [12] 2508 	anl	a,#0x3f
      0056C0 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      0056C1                       2513 _ak820_outline_0048:
      0056C1 E0               [24] 2514 	movx	a,@dptr
      0056C2 FF               [12] 2515 	mov	r7,a
      0056C3 90 07 14         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      0056C6 74 10            [12] 2517 	mov	a,#0x10
      0056C8 F0               [24] 2518 	movx	@dptr,a
      0056C9 8F 82            [24] 2519 	mov	dpl,r7
      0056CB 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      0056CC                       2524 _ak820_outline_0049:
      0056CC E0               [24] 2525 	movx	a,@dptr
      0056CD FF               [12] 2526 	mov	r7,a
      0056CE 90 07 16         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      0056D1 74 10            [12] 2528 	mov	a,#0x10
      0056D3 F0               [24] 2529 	movx	@dptr,a
      0056D4 8F 82            [24] 2530 	mov	dpl,r7
      0056D6 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0066
      0056D7                       2535 _ak820_outline_0066:
      0056D7 90 06 AB         [24] 2536 	mov	dptr,#_rgb_matrix_config
      0056DA E0               [24] 2537 	movx	a,@dptr
      0056DB 54 03            [12] 2538 	anl	a,#0x03
      0056DD 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0070
      0056DE                       2543 _ak820_outline_0070:
      0056DE 74 08            [12] 2544 	mov	a,#0x08
      0056E0 F0               [24] 2545 	movx	@dptr,a
      0056E1 E4               [12] 2546 	clr	a
      0056E2 A3               [24] 2547 	inc	dptr
      0056E3 F0               [24] 2548 	movx	@dptr,a
      0056E4 90 06 AB         [24] 2549 	mov	dptr,#_rgb_matrix_config
      0056E7 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      0056E8                       2554 _ak820_outline_0073:
      0056E8 A3               [24] 2555 	inc	dptr
      0056E9 F0               [24] 2556 	movx	@dptr,a
      0056EA E4               [12] 2557 	clr	a
      0056EB A3               [24] 2558 	inc	dptr
      0056EC F0               [24] 2559 	movx	@dptr,a
      0056ED 90 0D A2         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      0056F0 74 03            [12] 2561 	mov	a,#0x03
      0056F2 F0               [24] 2562 	movx	@dptr,a
      0056F3 E4               [12] 2563 	clr	a
      0056F4 A3               [24] 2564 	inc	dptr
      0056F5 F0               [24] 2565 	movx	@dptr,a
      0056F6 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0087
      0056F7                       2570 _ak820_outline_0087:
      0056F7 74 18            [12] 2571 	mov	a,#0x18
      0056F9 F0               [24] 2572 	movx	@dptr,a
      0056FA E4               [12] 2573 	clr	a
      0056FB A3               [24] 2574 	inc	dptr
      0056FC F0               [24] 2575 	movx	@dptr,a
      0056FD A3               [24] 2576 	inc	dptr
      0056FE F0               [24] 2577 	movx	@dptr,a
      0056FF 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0109
      005700                       2582 _ak820_outline_0109:
      005700 35 F0            [12] 2583 	addc	a,b
      005702 F5 83            [12] 2584 	mov	dph,a
      005704 E4               [12] 2585 	clr	a
      005705 93               [24] 2586 	movc	a,@a+dptr
      005706 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0115
      005707                       2591 _ak820_outline_0115:
      005707 90 06 AB         [24] 2592 	mov	dptr,#_rgb_matrix_config
      00570A E0               [24] 2593 	movx	a,@dptr
      00570B 54 FC            [12] 2594 	anl	a,#0xfc
      00570D 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0142
      00570E                       2599 _ak820_outline_0142:
      00570E 90 06 BA         [24] 2600 	mov	dptr,#_frame_mode
      005711 E0               [24] 2601 	movx	a,@dptr
      005712 FE               [12] 2602 	mov	r6,a
      005713 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0172
      005714                       2607 _ak820_outline_0172:
      005714 F0               [24] 2608 	movx	@dptr,a
      005715 E5 F0            [12] 2609 	mov	a,b
      005717 A3               [24] 2610 	inc	dptr
      005718 F0               [24] 2611 	movx	@dptr,a
      005719 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0173
      00571A                       2616 _ak820_outline_0173:
      00571A F0               [24] 2617 	movx	@dptr,a
      00571B E0               [24] 2618 	movx	a,@dptr
      00571C F5 82            [12] 2619 	mov	dpl,a
      00571E 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0176
      00571F                       2624 _ak820_outline_0176:
      00571F 90 06 AF         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      005722 E0               [24] 2626 	movx	a,@dptr
      005723 23               [12] 2627 	rl	a
      005724 23               [12] 2628 	rl	a
      005725 54 03            [12] 2629 	anl	a,#0x03
      005727 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0181
      005728                       2634 _ak820_outline_0181:
      005728 90 0D A7         [24] 2635 	mov	dptr,#_memset_PARM_2
      00572B E4               [12] 2636 	clr	a
      00572C F0               [24] 2637 	movx	@dptr,a
      00572D 90 0D A8         [24] 2638 	mov	dptr,#_memset_PARM_3
      005730 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0188
      005731                       2643 _ak820_outline_0188:
      005731 90 06 B9         [24] 2644 	mov	dptr,#_led_index
      005734 E0               [24] 2645 	movx	a,@dptr
      005735 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0190
      005736                       2650 _ak820_outline_0190:
      005736 C4               [12] 2651 	swap	a
      005737 23               [12] 2652 	rl	a
      005738 54 1F            [12] 2653 	anl	a,#0x1f
      00573A 22               [24] 2654 	ret
