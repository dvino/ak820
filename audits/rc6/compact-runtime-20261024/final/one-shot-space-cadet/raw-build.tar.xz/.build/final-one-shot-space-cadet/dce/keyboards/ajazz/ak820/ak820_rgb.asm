;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_rgb
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_eeprom_update_block_xdata
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_rgb_set_color_all
	.globl _ak820_rgb_set_color
	.globl _timer_elapsed
	.globl _timer_read
	.globl _hsv_to_rgb_into
	.globl _memset
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
	.globl _process_rgb_matrix_PARM_3
	.globl _process_rgb_matrix_PARM_2
	.globl _rgb_matrix_set_color_all_PARM_3
	.globl _rgb_matrix_set_color_all_PARM_2
	.globl _rgb_matrix_set_color_PARM_4
	.globl _rgb_matrix_set_color_PARM_3
	.globl _rgb_matrix_set_color_PARM_2
	.globl _rgb_matrix_config
	.globl _eeconfig_update_rgb_matrix
	.globl _eeconfig_update_rgb_matrix_default
	.globl _rgb_matrix_reload_from_eeprom
	.globl _rgb_matrix_init
	.globl _rgb_matrix_set_color
	.globl _rgb_matrix_set_color_all
	.globl _rgb_matrix_task
	.globl _process_rgb_matrix
	.globl _rgb_matrix_set_suspend_state
	.globl _rgb_matrix_is_enabled
	.globl _rgb_matrix_get_mode
	.globl _rgb_matrix_get_hue
	.globl _rgb_matrix_get_sat
	.globl _rgb_matrix_get_val
	.globl _rgb_matrix_get_speed
	.globl _rgb_matrix_toggle_noeeprom
	.globl _rgb_matrix_enable_noeeprom
	.globl _rgb_matrix_disable_noeeprom
	.globl _rgb_matrix_mode_noeeprom
	.globl _rgb_matrix_step_noeeprom
	.globl _rgb_matrix_step_reverse_noeeprom
	.globl _rgb_matrix_sethsv_noeeprom
	.globl _rgb_matrix_set_speed_noeeprom
	.globl _rgb_matrix_increase_hue_noeeprom
	.globl _rgb_matrix_decrease_hue_noeeprom
	.globl _rgb_matrix_increase_sat_noeeprom
	.globl _rgb_matrix_decrease_sat_noeeprom
	.globl _rgb_matrix_increase_val_noeeprom
	.globl _rgb_matrix_decrease_val_noeeprom
	.globl _rgb_matrix_increase_speed_noeeprom
	.globl _rgb_matrix_decrease_speed_noeeprom
	.globl _rgb_matrix_toggle
	.globl _rgb_matrix_step
	.globl _rgb_matrix_step_reverse
	.globl _rgb_matrix_increase_hue
	.globl _rgb_matrix_decrease_hue
	.globl _rgb_matrix_increase_sat
	.globl _rgb_matrix_decrease_sat
	.globl _rgb_matrix_increase_val
	.globl _rgb_matrix_decrease_val
	.globl _rgb_matrix_increase_speed
	.globl _rgb_matrix_decrease_speed
	.globl _rgb_matrix_mode
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_rgb_matrix_set_suspend_state_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_suspended:
	.ds 1
_dirty:
	.ds 1
_rendering:
	.ds 1
_rgb_matrix_task_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_rgb_matrix_config::
	.ds 8
_changed_at:
	.ds 2
_frame_at:
	.ds 2
_phase:
	.ds 2
_led_index:
	.ds 1
_frame_mode:
	.ds 1
_frame_hue:
	.ds 1
_frame_sat:
	.ds 1
_frame_val:
	.ds 1
_frame_flags:
	.ds 1
_frame_phase:
	.ds 1
_reactive_age:
	.ds 82
_reactive_at:
	.ds 2
_add_sat_PARM_2:
	.ds 1
_add_sat_x_10000_266:
	.ds 1
_sub_sat_PARM_2:
	.ds 1
_sub_sat_x_10000_268:
	.ds 1
_rgb_matrix_set_color_PARM_2:
	.ds 1
_rgb_matrix_set_color_PARM_3:
	.ds 1
_rgb_matrix_set_color_PARM_4:
	.ds 1
_rgb_matrix_set_color_index_10000_284:
	.ds 2
_rgb_matrix_set_color_all_PARM_2:
	.ds 1
_rgb_matrix_set_color_all_PARM_3:
	.ds 1
_rgb_matrix_set_color_all_r_10000_287:
	.ds 1
_sine8_theta_10000_289:
	.ds 1
_sine8_offset_10000_290:
	.ds 1
_sine8_fraction_10000_290:
	.ds 1
_breathing_cie_value_10000_293:
	.ds 1
_rgb_matrix_task_end_10000_298:
	.ds 1
_rgb_matrix_task_hsv_10000_298:
	.ds 3
_rgb_matrix_task_rgb_10000_298:
	.ds 3
_process_rgb_matrix_PARM_2:
	.ds 1
_process_rgb_matrix_PARM_3:
	.ds 1
_process_rgb_matrix_row_10000_319:
	.ds 1
_rgb_matrix_set_suspend_state_state_10000_326:
	.ds 1
_rgb_matrix_mode_noeeprom_mode_10000_355:
	.ds 1
_rgb_matrix_sethsv_noeeprom_PARM_2:
	.ds 1
_rgb_matrix_sethsv_noeeprom_PARM_3:
	.ds 1
_rgb_matrix_sethsv_noeeprom_hue_10000_363:
	.ds 2
_rgb_matrix_set_speed_noeeprom_speed_10000_365:
	.ds 1
_rgb_matrix_mode_mode_10000_411:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function clear_reactive
;	-----------------------------------------
_clear_reactive:
;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
	lcall	_ak820_outline_0181
	mov	a,#0x52
	lcall	_ak820_outline_0136
	mov	dptr,#_reactive_age
	mov	b,a
	lcall	_memset
;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
	lcall	_timer_read
	lcall	_ak820_outline_0140
	mov	dptr,#_reactive_at
	lcall	_ak820_outline_0172
;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'age_reactive'
;------------------------------------------------------------
;ticks         Allocated with name '_age_reactive_ticks_10000_262'
;i             Allocated with name '_age_reactive_i_10000_262'
;decay         Allocated with name '_age_reactive_decay_10000_262'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
;	-----------------------------------------
;	 function age_reactive
;	-----------------------------------------
_age_reactive:
;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
	mov	dptr,#_reactive_at
	lcall	_ak820_outline_0005
	lcall	_timer_elapsed
	mov	r6, dpl
	mov	a,dph
	swap	a
	xch	a,r6
	swap	a
	anl	a,#0x0f
	xrl	a,r6
	xch	a,r6
	anl	a,#0x0f
	xch	a,r6
	xrl	a,r6
	xch	a,r6
;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
	mov	r7,a
	orl	a,r6
	jnz	00102$
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
	mov	ar4,r6
	mov	a,r7
	swap	a
	anl	a,#0xf0
	xch	a,r4
	swap	a
	xch	a,r4
	xrl	a,r4
	xch	a,r4
	anl	a,#0xf0
	xch	a,r4
	xrl	a,r4
	mov	r5,a
	mov	dptr,#_reactive_at
	lcall	_ak820_outline_0105
	mov	dptr,#_reactive_at
	mov	a,r4
	add	a, r2
	movx	@dptr,a
	mov	a,r5
	addc	a, r3
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
	mov	ar4,r6
	mov	ar5,r7
	clr	c
	mov	a,#0xff
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00108$
;	free result
	mov	r5,#0xff
	sjmp	00109$
00108$:
	mov	ar5,r6
00109$:
;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
	mov	r7,#0x00
00104$:
;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
	mov	a,r7
	add	a, #_reactive_age
	mov	r4,a
	clr	a
	addc	a, #(_reactive_age >> 8)
	mov	r6,a
	mov	dpl,r4
	mov	dph,r6
	movx	a,@dptr
	mov	r3,a
	clr	c
	mov	a,r5
	subb	a,r3
	jc	00110$
	mov	r3,#0x00
	sjmp	00111$
00110$:
	mov	dpl,r4
	mov	dph,r6
	movx	a,@dptr
	clr	c
	subb	a,r5
	mov	r3,a
00111$:
	mov	dpl,r4
	mov	dph,r6
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
	inc	r7
	cjne	r7,#0x52,00144$
00144$:
	jc	00104$
;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'add_sat'
;------------------------------------------------------------
;y             Allocated with name '_add_sat_PARM_2'
;x             Allocated with name '_add_sat_x_10000_266'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
;	-----------------------------------------
;	 function add_sat
;	-----------------------------------------
_add_sat:
	mov	a,dpl
	mov	dptr,#_add_sat_x_10000_266
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
	mov	dptr,#_add_sat_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	r6,a
	mov	a,#0xff
	clr	c
	subb	a,r6
	mov	r6,a
	mov	dptr,#_add_sat_x_10000_266
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,r6
	subb	a,r5
	jnc	00103$
;	free result
	mov	r6,#0xff
	sjmp	00104$
00103$:
	mov	a,r7
	add	a, r5
	mov	r6,a
00104$:
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'sub_sat'
;------------------------------------------------------------
;y             Allocated with name '_sub_sat_PARM_2'
;x             Allocated with name '_sub_sat_x_10000_268'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
;	-----------------------------------------
;	 function sub_sat
;	-----------------------------------------
_sub_sat:
	mov	a,dpl
	mov	dptr,#_sub_sat_x_10000_268
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_sub_sat_PARM_2
	movx	a,@dptr
	mov	r6,a
	clr	c
	mov	a,r7
	subb	a,r6
	jnc	00103$
	mov	r5,#0x00
	sjmp	00104$
00103$:
	mov	a,r7
	clr	c
	subb	a,r6
	mov	r5,a
00104$:
	mov	dpl, r5
;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mark_dirty'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
;	-----------------------------------------
;	 function mark_dirty
;	-----------------------------------------
_mark_dirty:
;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
;	assignBit
	setb	_dirty
;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
	lcall	_timer_read
	lcall	_ak820_outline_0140
	mov	dptr,#_changed_at
	lcall	_ak820_outline_0172
;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
;------------------------------------------------------------
;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
;	-----------------------------------------
;	 function eeconfig_update_rgb_matrix
;	-----------------------------------------
_eeconfig_update_rgb_matrix:
;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
	mov	dptr,#(_rgb_matrix_config + 0x0007)
	clr	a
	movx	@dptr,a
	mov	dptr,#(_rgb_matrix_config + 0x0006)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	lcall	_ak820_outline_0087
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	lcall	_ak820_outline_0070
	lcall	_ak820_eeprom_update_block_xdata
;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
;	assignBit
	clr	_dirty
;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
;	-----------------------------------------
;	 function eeconfig_update_rgb_matrix_default
;	-----------------------------------------
_eeconfig_update_rgb_matrix_default:
;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
	lcall	_ak820_outline_0181
	lcall	_ak820_outline_0070
	mov	b,a
	lcall	_memset
;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
	lcall	_ak820_outline_0115
	orl	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
	lcall	_ak820_outline_0066
	orl	a,#0x04
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	dec	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	mov	a,#0x50
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	mov	a,#0x60
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
	mov	dptr,#(_rgb_matrix_config + 0x0005)
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
	ljmp	_eeconfig_update_rgb_matrix
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
;	-----------------------------------------
;	 function rgb_matrix_reload_from_eeprom
;	-----------------------------------------
_rgb_matrix_reload_from_eeprom:
;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	lcall	_ak820_outline_0087
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0070
	lcall	_ak820_eeprom_read_block_xdata
;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
	lcall	_ak820_outline_0115
	jz	00101$
	lcall	_ak820_outline_0019
	clr	c
	xrl	a,#0x80
	subb	a,#0x87
	jnc	00101$
	lcall	_ak820_outline_0066
	add	a,#0xff - 0x01
	jnc	00102$
;	free result
00101$:
;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
	lcall	_eeconfig_update_rgb_matrix_default
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	movx	a,@dptr
	add	a,#0xff - 0xa0
	jnc	00106$
;	free result
;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	mov	a,#0xa0
	movx	@dptr,a
00106$:
;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
;	assignBit
	clr	_dirty
;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
;	assignBit
	clr	_rendering
;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
	ljmp	_clear_reactive
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_init'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
;	-----------------------------------------
;	 function rgb_matrix_init
;	-----------------------------------------
_rgb_matrix_init:
;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
	lcall	_rgb_matrix_reload_from_eeprom
;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
	lcall	_timer_read
	lcall	_ak820_outline_0135
	mov	a,r6
	add	a,#0xf0
	mov	r6,a
	mov	a,r7
	addc	a,#0xff
	mov	r7,a
	mov	dptr,#_frame_at
	lcall	_ak820_outline_0060
;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_set_color'
;------------------------------------------------------------
;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
;	-----------------------------------------
;	 function rgb_matrix_set_color
;	-----------------------------------------
_rgb_matrix_set_color:
	lcall	_ak820_outline_0118
	mov	dptr,#_rgb_matrix_set_color_index_10000_284
	lcall	_ak820_outline_0119
;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
	mov	dptr,#_rgb_matrix_set_color_index_10000_284
	lcall	_ak820_outline_0052
	jb	acc.7,00104$
	clr	c
	mov	a,r6
	subb	a,#0x52
	mov	a,r7
	xrl	a,#0x80
	subb	a,#0x80
	jnc	00104$
	mov	dptr,#_rgb_matrix_set_color_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_rgb_matrix_set_color_PARM_3
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_rgb_matrix_set_color_PARM_4
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_ak820_rgb_set_color_PARM_2
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_ak820_rgb_set_color_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dptr,#_ak820_rgb_set_color_PARM_4
	mov	a,r4
	movx	@dptr,a
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
	ljmp	_ak820_rgb_set_color
00104$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_set_color_all'
;------------------------------------------------------------
;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
;	-----------------------------------------
;	 function rgb_matrix_set_color_all
;	-----------------------------------------
_rgb_matrix_set_color_all:
	mov	a,dpl
	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
	ljmp	_ak820_rgb_set_color_all
;------------------------------------------------------------
;Allocation info for local variables in function 'sine8'
;------------------------------------------------------------
;theta         Allocated with name '_sine8_theta_10000_289'
;offset        Allocated with name '_sine8_offset_10000_290'
;section       Allocated with name '_sine8_section_10000_290'
;fraction      Allocated with name '_sine8_fraction_10000_290'
;value         Allocated with name '_sine8_value_10000_290'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
;	-----------------------------------------
;	 function sine8
;	-----------------------------------------
_sine8:
	mov	a,dpl
	mov	dptr,#_sine8_theta_10000_289
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_sine8_offset_10000_290
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
	mov	a,r7
	jnb	acc.6,00102$
	mov	dptr,#_sine8_offset_10000_290
	mov	a,#0xff
	clr	c
	subb	a,r7
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
	mov	dptr,#_sine8_offset_10000_290
	movx	a,@dptr
	anl	acc,#0x3f
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
	mov	dptr,#_sine8_offset_10000_290
	movx	a,@dptr
	anl	a,#0x0f
	mov	r7,a
	mov	dptr,#_sine8_fraction_10000_290
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
	mov	dptr,#_sine8_theta_10000_289
	movx	a,@dptr
	jnb	acc.6,00104$
	mov	dptr,#_sine8_fraction_10000_290
	mov	a,r7
	inc	a
	movx	@dptr,a
00104$:
;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
	mov	dptr,#_sine8_offset_10000_290
	movx	a,@dptr
	swap	a
	anl	a,#0x0f
;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
	add	a,acc
	mov	r7,a
	mov	dptr,#_sine8_coefficients_10000_290
	movc	a,@a+dptr
	mov	r6,a
	inc	r7
	mov	a,r7
	mov	dptr,#_sine8_coefficients_10000_290
	movc	a,@a+dptr
	mov	r7,a
	mov	dptr,#_sine8_fraction_10000_290
	movx	a,@dptr
	mov	b,r7
	mul	ab
	mov	r7,a
	mov	a,b
	swap	a
	xch	a,r7
	swap	a
	anl	a,#0x0f
	xrl	a,r7
	xch	a,r7
	anl	a,#0x0f
	xch	a,r7
	xrl	a,r7
	xch	a,r7
	mov	a,r7
	add	a, r6
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
	mov	dptr,#_sine8_theta_10000_289
	movx	a,@dptr
	jnb	acc.7,00107$
	mov	ar6,r7
	mov	a,#0x80
	clr	c
	subb	a,r6
	mov	r6,a
	sjmp	00108$
00107$:
	mov	a,#0x80
	add	a, r7
	mov	r6,a
00108$:
	mov	dpl, r6
;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'breathing_cie'
;------------------------------------------------------------
;value         Allocated with name '_breathing_cie_value_10000_293'
;index         Allocated with name '_breathing_cie_index_10000_294'
;low           Allocated with name '_breathing_cie_low_10000_294'
;delta         Allocated with name '_breathing_cie_delta_10001_296'
;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
;product       Allocated with name '_breathing_cie_product_10001_296'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
;	-----------------------------------------
;	 function breathing_cie
;	-----------------------------------------
_breathing_cie:
	mov	a,dpl
	mov	dptr,#_breathing_cie_value_10000_293
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
	movx	a,@dptr
	mov	r7,a
	lcall	_ak820_outline_0190
;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
	mov	r6,a
	mov	dptr,#_CIE1931_CURVE
	movc	a,@a+dptr
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
	cjne	r6,#0x1f,00102$
	mov	dpl, r5
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
	mov	a,r6
	inc	a
	mov	dptr,#_CIE1931_CURVE
	movc	a,@a+dptr
	clr	c
	subb	a,r5
	mov	r6,a
;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
	mov	a,#0x07
	anl	a,r7
;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
	mov	b,a
	mov	a,r6
	mul	ab
;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
	lcall	_ak820_outline_0190
	add	a, r5
;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_task'
;------------------------------------------------------------
;end           Allocated with name '_rgb_matrix_task_end_10000_298'
;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
;age           Allocated with name '_rgb_matrix_task_age_80000_316'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
;	-----------------------------------------
;	 function rgb_matrix_task
;	-----------------------------------------
_rgb_matrix_task:
;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
	lcall	_age_reactive
;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
	jnb	_dirty,00102$
	mov	dptr,#_changed_at
	lcall	_ak820_outline_0005
	lcall	_timer_elapsed
	lcall	_ak820_outline_0135
	clr	c
	mov	a,r6
	subb	a,#0xe8
	mov	a,r7
	subb	a,#0x03
	jc	00102$
	lcall	_eeconfig_update_rgb_matrix
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
	jnb	_rendering,00254$
	ljmp	00109$
00254$:
;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
	mov	dptr,#_frame_at
	lcall	_ak820_outline_0005
	lcall	_timer_elapsed
	lcall	_ak820_outline_0135
	clr	c
	mov	a,r6
	subb	a,#0x10
	mov	a,r7
	subb	a,#0x00
	jnc	00105$
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
	lcall	_timer_read
	lcall	_ak820_outline_0140
	mov	dptr,#_frame_at
	lcall	_ak820_outline_0172
;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	a,#0x20
	add	a, r7
	mov	r7,a
	clr	a
	addc	a, r6
	mov	r6,a
	mov	dptr,#_phase
	lcall	_ak820_outline_0061
	mov	a,r7
	add	a, r4
	mov	r7,a
	mov	a,r6
	addc	a, r5
	mov	r6,a
	mov	dptr,#_phase
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
	mov	dptr,#_phase
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_frame_phase
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
	jb	_suspended,00135$
	lcall	_ak820_outline_0066
	jnz	00132$
00135$:
	mov	r6,#0x00
	sjmp	00133$
00132$:
	lcall	_ak820_outline_0019
	mov	r6,a
00133$:
	mov	dptr,#_frame_mode
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	a,@dptr
	mov	dptr,#_frame_hue
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	movx	a,@dptr
	mov	dptr,#_frame_sat
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_frame_val
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
	mov	dptr,#(_rgb_matrix_config + 0x0005)
	movx	a,@dptr
	mov	dptr,#_frame_flags
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
	cjne	r6,#0x02,00107$
;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
	mov	a,r7
	add	a,#0xc0
	mov	dpl,a
	push	ar5
	lcall	_sine8
	mov	r7, dpl
	pop	ar5
	mov	b,r5
	mov	a,r7
	mul	ab
	mov	r6,b
	mov	ar5,r6
	mov	dptr,#_frame_val
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
	mov	dpl, r5
	lcall	_breathing_cie
	mov	a, dpl
	mov	dptr,#_frame_val
	movx	@dptr,a
00107$:
;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
	mov	dptr,#_led_index
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
;	assignBit
	setb	_rendering
00109$:
;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
	lcall	_ak820_outline_0188
	add	a,#0x08
	mov	r7,a
	mov	dptr,#_rgb_matrix_task_end_10000_298
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
	mov	a,r7
	add	a,#0xff - 0x52
	jnc	00125$
;	free result
	mov	dptr,#_rgb_matrix_task_end_10000_298
	mov	a,#0x52
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
00125$:
	lcall	_ak820_outline_0188
	mov	r7,a
	mov	dptr,#_rgb_matrix_task_end_10000_298
	movx	a,@dptr
	mov	r6,a
	clr	c
	mov	a,r7
	subb	a,r6
	jc	00261$
	ljmp	00127$
00261$:
;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
	lcall	_ak820_outline_0142
	movx	a,@dptr
	jz	00121$
	mov	dptr,#_frame_flags
	movx	a,@dptr
	jb	acc.2,00122$
00121$:
;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
	lcall	_ak820_outline_0188
	mov	r4,a
	mov	r5,#0x00
	mov	dptr,#_rgb_matrix_set_color_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_set_color_PARM_3
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_set_color_PARM_4
	lcall	_ak820_outline_0103
	lcall	_rgb_matrix_set_color
	ljmp	00123$
00122$:
;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
	cjne	r6,#0x05,00119$
;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
	mov	a,r7
	mov	b,#0x03
	mul	ab
	add	a, #_g_direct_mode_colors
	mov	r5,a
	mov	a,#(_g_direct_mode_colors >> 8)
	addc	a, b
	mov	r6,a
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	lcall	_ak820_outline_0073
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	mov	b,a
	lcall	___memcpy
	ljmp	00120$
00119$:
;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
	mov	dptr,#_frame_hue
	movx	a,@dptr
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
	mov	dptr,#_frame_sat
	movx	a,@dptr
	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
	mov	dptr,#_frame_val
	movx	a,@dptr
	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
	lcall	_ak820_outline_0142
	cjne	r6,#0x03,00113$
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_frame_phase
	movx	a,@dptr
	add	a, r6
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	movx	@dptr,a
00113$:
;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
	lcall	_ak820_outline_0142
	cjne	r6,#0x04,00115$
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	movx	a,@dptr
	mov	r6,a
	lcall	_ak820_outline_0188
	mov	b,#0x02
	mul	ab
	add	a, #_ak820_led_points
	mov	dpl,a
	mov	a,#(_ak820_led_points >> 8)
	lcall	_ak820_outline_0109
	mov	r5,a
	mov	dptr,#_frame_phase
	movx	a,@dptr
	mov	r4,a
	mov	a,r5
	clr	c
	subb	a,r4
	add	a, r6
	mov	dptr,#_rgb_matrix_task_hsv_10000_298
	movx	@dptr,a
00115$:
;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
	lcall	_ak820_outline_0142
	cjne	r6,#0x06,00120$
;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
	lcall	_ak820_outline_0176
	mov	r6,a
	mov	a,#0x07
	clr	c
	subb	a,r6
	mov	r6,a
;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
	mov	b,r6
	inc	b
	mov	a,#0x01
	sjmp	00273$
00272$:
	add	a,acc
00273$:
	djnz	b,00272$
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
	lcall	_ak820_outline_0188
	add	a, #_reactive_age
	mov	dpl,a
	clr	a
	addc	a, #(_reactive_age >> 8)
	mov	dph,a
	movx	a,@dptr
;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
	mov	r4,a
	clr	c
	subb	a,r5
	jc	00137$
	mov	dptr,#_frame_val
	movx	a,@dptr
	mov	r3,a
	sjmp	00138$
00137$:
	mov	dptr,#_frame_val
	movx	a,@dptr
	mov	b, a
	mov	a,r4
	mul	ab
	mov	r4,a
	mov	r2,b
	mov	b,r6
	inc	b
	mov	r3,ar4
	mov	r5,ar2
	sjmp	00276$
00275$:
	clr	c
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r3
	rrc	a
	mov	r3,a
00276$:
	djnz	b,00275$
00138$:
	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
	mov	a,r3
	movx	@dptr,a
00120$:
;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
	lcall	_ak820_outline_0142
	cjne	r6,#0x02,00277$
	setb	c
	sjmp	00278$
00277$:
	clr	c
00278$:
	cpl	c
	mov	_rgb_matrix_task_sloc0_1_0,c
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_rgb_matrix_task_hsv_10000_298
	movx	@dptr,a
	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
	lcall	_ak820_outline_0073
	mov	dptr,#_hsv_to_rgb_into_PARM_1
	mov	b,a
	lcall	___memcpy
	mov	dptr,#_hsv_to_rgb_into_PARM_3
	mov	a,#_rgb_matrix_task_rgb_10000_298
	movx	@dptr,a
	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
	inc	dptr
	movx	@dptr,a
	mov	c,_rgb_matrix_task_sloc0_1_0
	lcall	_ak820_outline_0159
	lcall	_hsv_to_rgb_into
;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
	lcall	_ak820_outline_0188
	mov	r5,a
	mov	r6,#0x00
	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_rgb_matrix_task_rgb_10000_298
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
	movx	a,@dptr
	mov	r2,a
	mov	dptr,#_rgb_matrix_set_color_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_set_color_PARM_3
	mov	a,r3
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_set_color_PARM_4
	mov	a,r2
	movx	@dptr,a
	lcall	_ak820_outline_0137
	lcall	_rgb_matrix_set_color
00123$:
;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
	lcall	_ak820_outline_0188
	add	a, #0x01
	movx	@dptr,a
	ljmp	00125$
00127$:
;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
	cjne	r7,#0x52,00130$
;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
;	assignBit
	clr	_rendering
00130$:
;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'process_rgb_matrix'
;------------------------------------------------------------
;col           Allocated with name '_process_rgb_matrix_PARM_2'
;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
;row           Allocated with name '_process_rgb_matrix_row_10000_319'
;i             Allocated with name '_process_rgb_matrix_i_10000_320'
;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
;	-----------------------------------------
;	 function process_rgb_matrix
;	-----------------------------------------
_process_rgb_matrix:
	mov	a,dpl
	mov	dptr,#_process_rgb_matrix_row_10000_319
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
	mov	dptr,#_process_rgb_matrix_PARM_3
	movx	a,@dptr
	jz	00101$
	jb	_suspended,00101$
	lcall	_ak820_outline_0066
	jz	00101$
;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
	lcall	_ak820_outline_0019
	mov	r7,a
	cjne	r7,#0x06,00101$
	mov	dptr,#_process_rgb_matrix_row_10000_319
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x10,00169$
00169$:
	jnc	00101$
	mov	dptr,#_process_rgb_matrix_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x08,00171$
00171$:
	jc	00102$
00101$:
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
	push	ar7
	push	ar6
	lcall	_age_reactive
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
	mov	a,r7
	lcall	_ak820_outline_0192
	add	a,r6
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
	mov	r6,#0x00
00111$:
;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
	mov	a,r6
	mov	dptr,#_ak820_rgb_slots
	movc	a,@a+dptr
	cjne	a,ar7,00112$
;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
	mov	a,r6
	add	a, #_reactive_age
	mov	r4,a
	clr	a
	addc	a, #(_reactive_age >> 8)
	mov	r5,a
	lcall	_ak820_outline_0176
	mov	b, a
	inc	b
	mov	r3,#0x80
	clr	a
	mov	r2,a
	rlc	a
	mov	ov,c
	sjmp	00176$
00175$:
	mov	c,ov
	mov	a,r2
	rrc	a
	mov	r2,a
	mov	a,r3
	rrc	a
	mov	r3,a
00176$:
	djnz	b,00175$
	lcall	_ak820_outline_0126
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
	ret
00112$:
;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
	inc	r6
	cjne	r6,#0x52,00177$
00177$:
	jc	00111$
;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
;------------------------------------------------------------
;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
;	-----------------------------------------
;	 function rgb_matrix_set_suspend_state
;	-----------------------------------------
_rgb_matrix_set_suspend_state:
	mov	a,dpl
	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
	movx	a,@dptr
;	assignBit
	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
	rrc	a
	mov	_suspended,c
;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
;	assignBit
	clr	_rendering
;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
	lcall	_clear_reactive
;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
	jz	00103$
;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
	movx	@dptr,a
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
	ljmp	_rgb_matrix_set_color_all
00103$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
;	-----------------------------------------
;	 function rgb_matrix_is_enabled
;	-----------------------------------------
_rgb_matrix_is_enabled:
	lcall	_ak820_outline_0066
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_mode'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
;	-----------------------------------------
;	 function rgb_matrix_get_mode
;	-----------------------------------------
_rgb_matrix_get_mode:
	lcall	_ak820_outline_0019
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_hsv'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
;	-----------------------------------------
;	 function rgb_matrix_get_hue
;	-----------------------------------------
_rgb_matrix_get_hue:
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_sat'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
;	-----------------------------------------
;	 function rgb_matrix_get_sat
;	-----------------------------------------
_rgb_matrix_get_sat:
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_val'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
;	-----------------------------------------
;	 function rgb_matrix_get_val
;	-----------------------------------------
_rgb_matrix_get_val:
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_speed'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
;	-----------------------------------------
;	 function rgb_matrix_get_speed
;	-----------------------------------------
_rgb_matrix_get_speed:
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_get_flags'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
;	-----------------------------------------
;	 function rgb_matrix_toggle_noeeprom
;	-----------------------------------------
_rgb_matrix_toggle_noeeprom:
	lcall	_ak820_outline_0066
	mov	r7,a
	xrl	ar7,#0x01
	mov	dptr,#_rgb_matrix_config
	mov	a,r7
	anl	a,#0x03
	mov	b,a
	movx	a,@dptr
	anl	a,#0xfc
	orl	a,b
	movx	@dptr,a
;	assignBit
	clr	_rendering
	ljmp	_clear_reactive
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
;	-----------------------------------------
;	 function rgb_matrix_enable_noeeprom
;	-----------------------------------------
_rgb_matrix_enable_noeeprom:
	lcall	_ak820_outline_0066
	jnz	00102$
	lcall	_clear_reactive
00102$:
	lcall	_ak820_outline_0115
	orl	a,#0x01
	movx	@dptr,a
;	assignBit
	clr	_rendering
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
;	-----------------------------------------
;	 function rgb_matrix_disable_noeeprom
;	-----------------------------------------
_rgb_matrix_disable_noeeprom:
	lcall	_ak820_outline_0115
	movx	@dptr,a
;	assignBit
	clr	_rendering
	ljmp	_clear_reactive
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
;------------------------------------------------------------
;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
;	-----------------------------------------
;	 function rgb_matrix_mode_noeeprom
;	-----------------------------------------
_rgb_matrix_mode_noeeprom:
	mov	a,dpl
	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
	movx	a,@dptr
	mov	r7,a
	jz	00101$
	cjne	r7,#0x07,00123$
00123$:
	jc	00102$
00101$:
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
	lcall	_ak820_outline_0019
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00125$
	sjmp	00105$
00125$:
	lcall	_clear_reactive
00105$:
;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
	movx	a,@dptr
	mov	dptr,#_rgb_matrix_config
	add	a,acc
	add	a,acc
	anl	a,#0xfc
	mov	b,a
	movx	a,@dptr
	anl	a,#0x03
	orl	a,b
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
;	assignBit
	clr	_rendering
;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
;	-----------------------------------------
;	 function rgb_matrix_step_noeeprom
;	-----------------------------------------
_rgb_matrix_step_noeeprom:
;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
	lcall	_ak820_outline_0019
	mov	r7,a
	inc	r7
	cjne	r7,#0x07,00112$
00112$:
	jc	00103$
	mov	r7,#0x01
	sjmp	00104$
00103$:
	lcall	_ak820_outline_0019
	mov	r6,a
	inc	r6
	mov	ar7,r6
00104$:
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
	ljmp	_rgb_matrix_mode_noeeprom
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
;	-----------------------------------------
;	 function rgb_matrix_step_reverse_noeeprom
;	-----------------------------------------
_rgb_matrix_step_reverse_noeeprom:
;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
	lcall	_ak820_outline_0019
	add	a,#0xff - 0x01
	jc	00103$
;	free result
	mov	r7,#0x06
	sjmp	00104$
00103$:
	lcall	_ak820_outline_0019
	dec	a
	mov	r7,a
00104$:
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
	ljmp	_rgb_matrix_mode_noeeprom
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
;------------------------------------------------------------
;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
;	-----------------------------------------
;	 function rgb_matrix_sethsv_noeeprom
;	-----------------------------------------
_rgb_matrix_sethsv_noeeprom:
	lcall	_ak820_outline_0118
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
	lcall	_ak820_outline_0119
;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
	movx	a,@dptr
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
	movx	a,@dptr
	mov  r7,a
	add	a,#0xff - 0xa0
	jnc	00103$
;	free result
	mov	r6,#0xa0
	sjmp	00104$
00103$:
	mov	ar6,r7
00104$:
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
;------------------------------------------------------------
;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
;	-----------------------------------------
;	 function rgb_matrix_set_speed_noeeprom
;	-----------------------------------------
_rgb_matrix_set_speed_noeeprom:
	mov	a,dpl
	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
	movx	@dptr,a
	movx	a,@dptr
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
;------------------------------------------------------------
;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
;	-----------------------------------------
;	 function rgb_matrix_increase_hue_noeeprom
;	-----------------------------------------
_rgb_matrix_increase_hue_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	a,@dptr
	add	a,#0x08
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
;	-----------------------------------------
;	 function rgb_matrix_decrease_hue_noeeprom
;	-----------------------------------------
_rgb_matrix_decrease_hue_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	a,@dptr
	add	a,#0xf8
	mov	dptr,#(_rgb_matrix_config + 0x0001)
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
;	-----------------------------------------
;	 function rgb_matrix_increase_sat_noeeprom
;	-----------------------------------------
_rgb_matrix_increase_sat_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	lcall	_ak820_outline_0048
	lcall	_add_sat
	mov	r7, dpl
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	mov	a,r7
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
;	-----------------------------------------
;	 function rgb_matrix_decrease_sat_noeeprom
;	-----------------------------------------
_rgb_matrix_decrease_sat_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	lcall	_ak820_outline_0049
	lcall	_sub_sat
	mov	r7, dpl
	mov	dptr,#(_rgb_matrix_config + 0x0002)
	mov	a,r7
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
;------------------------------------------------------------
;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
;	-----------------------------------------
;	 function rgb_matrix_increase_val_noeeprom
;	-----------------------------------------
_rgb_matrix_increase_val_noeeprom:
;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	lcall	_ak820_outline_0048
	lcall	_add_sat
;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
	mov	a,dpl
	mov	r7,a
	add	a,#0xff - 0xa0
	jnc	00103$
;	free result
	mov	r6,#0xa0
	sjmp	00104$
00103$:
	mov	ar6,r7
00104$:
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
;	-----------------------------------------
;	 function rgb_matrix_decrease_val_noeeprom
;	-----------------------------------------
_rgb_matrix_decrease_val_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	lcall	_ak820_outline_0049
	lcall	_sub_sat
	mov	r7, dpl
	mov	dptr,#(_rgb_matrix_config + 0x0003)
	mov	a,r7
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
;	-----------------------------------------
;	 function rgb_matrix_increase_speed_noeeprom
;	-----------------------------------------
_rgb_matrix_increase_speed_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	lcall	_ak820_outline_0048
	lcall	_add_sat
	mov	r7, dpl
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	mov	a,r7
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
;	-----------------------------------------
;	 function rgb_matrix_decrease_speed_noeeprom
;	-----------------------------------------
_rgb_matrix_decrease_speed_noeeprom:
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	lcall	_ak820_outline_0049
	lcall	_sub_sat
	mov	r7, dpl
	mov	dptr,#(_rgb_matrix_config + 0x0004)
	mov	a,r7
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_toggle'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
;	-----------------------------------------
;	 function rgb_matrix_toggle
;	-----------------------------------------
_rgb_matrix_toggle:
	lcall	_rgb_matrix_toggle_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_enable'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
;	-----------------------------------------
;	 function rgb_matrix_step
;	-----------------------------------------
_rgb_matrix_step:
	lcall	_rgb_matrix_step_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_step_reverse'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
;	-----------------------------------------
;	 function rgb_matrix_step_reverse
;	-----------------------------------------
_rgb_matrix_step_reverse:
	lcall	_rgb_matrix_step_reverse_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_hue'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
;	-----------------------------------------
;	 function rgb_matrix_increase_hue
;	-----------------------------------------
_rgb_matrix_increase_hue:
	lcall	_rgb_matrix_increase_hue_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
;	-----------------------------------------
;	 function rgb_matrix_decrease_hue
;	-----------------------------------------
_rgb_matrix_decrease_hue:
	lcall	_rgb_matrix_decrease_hue_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_sat'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
;	-----------------------------------------
;	 function rgb_matrix_increase_sat
;	-----------------------------------------
_rgb_matrix_increase_sat:
	lcall	_rgb_matrix_increase_sat_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
;	-----------------------------------------
;	 function rgb_matrix_decrease_sat
;	-----------------------------------------
_rgb_matrix_decrease_sat:
	lcall	_rgb_matrix_decrease_sat_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_val'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
;	-----------------------------------------
;	 function rgb_matrix_increase_val
;	-----------------------------------------
_rgb_matrix_increase_val:
	lcall	_rgb_matrix_increase_val_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_val'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
;	-----------------------------------------
;	 function rgb_matrix_decrease_val
;	-----------------------------------------
_rgb_matrix_decrease_val:
	lcall	_rgb_matrix_decrease_val_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_increase_speed'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
;	-----------------------------------------
;	 function rgb_matrix_increase_speed
;	-----------------------------------------
_rgb_matrix_increase_speed:
	lcall	_rgb_matrix_increase_speed_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
;	-----------------------------------------
;	 function rgb_matrix_decrease_speed
;	-----------------------------------------
_rgb_matrix_decrease_speed:
	lcall	_rgb_matrix_decrease_speed_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_mode'
;------------------------------------------------------------
;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
;	-----------------------------------------
;	 function rgb_matrix_mode
;	-----------------------------------------
_rgb_matrix_mode:
	mov	a,dpl
	mov	dptr,#_rgb_matrix_mode_mode_10000_411
	lcall	_ak820_outline_0173
	lcall	_rgb_matrix_mode_noeeprom
	ljmp	_mark_dirty
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_sethsv'
;------------------------------------------------------------
;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_sine8_coefficients_10000_290:
	.db #0x00	; 0
	.db #0x31	; 49	'1'
	.db #0x31	; 49	'1'
	.db #0x29	; 41
	.db #0x5a	; 90	'Z'
	.db #0x1b	; 27
	.db #0x75	; 117	'u'
	.db #0x0a	; 10
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0005
	.globl _ak820_outline_0019
	.globl _ak820_outline_0048
	.globl _ak820_outline_0049
	.globl _ak820_outline_0052
	.globl _ak820_outline_0060
	.globl _ak820_outline_0061
	.globl _ak820_outline_0066
	.globl _ak820_outline_0070
	.globl _ak820_outline_0073
	.globl _ak820_outline_0087
	.globl _ak820_outline_0103
	.globl _ak820_outline_0105
	.globl _ak820_outline_0109
	.globl _ak820_outline_0115
	.globl _ak820_outline_0118
	.globl _ak820_outline_0119
	.globl _ak820_outline_0126
	.globl _ak820_outline_0135
	.globl _ak820_outline_0136
	.globl _ak820_outline_0137
	.globl _ak820_outline_0140
	.globl _ak820_outline_0142
	.globl _ak820_outline_0159
	.globl _ak820_outline_0172
	.globl _ak820_outline_0173
	.globl _ak820_outline_0176
	.globl _ak820_outline_0181
	.globl _ak820_outline_0188
	.globl _ak820_outline_0190
	.globl _ak820_outline_0192

	.area CSEG (CODE)
; function ak820_outline_0019
_ak820_outline_0019:
	mov	dptr,#_rgb_matrix_config
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x3f
	ret

	.area CSEG (CODE)
; function ak820_outline_0048
_ak820_outline_0048:
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_add_sat_PARM_2
	mov	a,#0x10
	movx	@dptr,a
	mov	dpl,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0049
_ak820_outline_0049:
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_sub_sat_PARM_2
	mov	a,#0x10
	movx	@dptr,a
	mov	dpl,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0066
_ak820_outline_0066:
	mov	dptr,#_rgb_matrix_config
	movx	a,@dptr
	anl	a,#0x03
	ret

	.area CSEG (CODE)
; function ak820_outline_0070
_ak820_outline_0070:
	mov	a,#0x08
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_rgb_matrix_config
	ret

	.area CSEG (CODE)
; function ak820_outline_0073
_ak820_outline_0073:
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x03
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0087
_ak820_outline_0087:
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0109
_ak820_outline_0109:
	addc	a,b
	mov	dph,a
	clr	a
	movc	a,@a+dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0115
_ak820_outline_0115:
	mov	dptr,#_rgb_matrix_config
	movx	a,@dptr
	anl	a,#0xfc
	ret

	.area CSEG (CODE)
; function ak820_outline_0142
_ak820_outline_0142:
	mov	dptr,#_frame_mode
	movx	a,@dptr
	mov	r6,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0172
_ak820_outline_0172:
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0173
_ak820_outline_0173:
	movx	@dptr,a
	movx	a,@dptr
	mov	dpl,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0176
_ak820_outline_0176:
	mov	dptr,#(_rgb_matrix_config+0x0004)
	movx	a,@dptr
	rl	a
	rl	a
	anl	a,#0x03
	ret

	.area CSEG (CODE)
; function ak820_outline_0181
_ak820_outline_0181:
	mov	dptr,#_memset_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	ret

	.area CSEG (CODE)
; function ak820_outline_0188
_ak820_outline_0188:
	mov	dptr,#_led_index
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0190
_ak820_outline_0190:
	swap	a
	rl	a
	anl	a,#0x1f
	ret
