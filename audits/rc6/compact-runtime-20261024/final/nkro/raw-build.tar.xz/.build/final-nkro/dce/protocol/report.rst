                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007E5                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007E5                        556 	.ds 1
      0007E6                        557 _add_key_byte_PARM_2:
      0007E6                        558 	.ds 1
      0007E7                        559 _add_key_byte_report_arg_10000_144:
      0007E7                        560 	.ds 3
      0007EA                        561 _add_key_byte_empty_10000_145:
      0007EA                        562 	.ds 1
      0007EB                        563 _del_key_byte_PARM_2:
      0007EB                        564 	.ds 1
      0007EC                        565 _del_key_byte_report_arg_10000_156:
      0007EC                        566 	.ds 3
      0007EF                        567 _add_key_bit_PARM_2:
      0007EF                        568 	.ds 1
      0007F0                        569 _add_key_bit_report_arg_10000_162:
      0007F0                        570 	.ds 3
      0007F3                        571 _del_key_bit_PARM_2:
      0007F3                        572 	.ds 1
      0007F4                        573 _del_key_bit_report_arg_10000_167:
      0007F4                        574 	.ds 3
      0007F7                        575 _add_key_to_report_PARM_2:
      0007F7                        576 	.ds 1
      0007F8                        577 _add_key_to_report_report_arg_10000_172:
      0007F8                        578 	.ds 3
      0007FB                        579 _del_key_from_report_PARM_2:
      0007FB                        580 	.ds 1
      0007FC                        581 _del_key_from_report_report_arg_10000_176:
      0007FC                        582 	.ds 3
      0007FF                        583 _clear_keys_from_report_report_arg_10000_180:
      0007FF                        584 	.ds 3
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006BBC                        636 _KEYCODE2CONSUMER:
      006BBC E5 82            [12]  637 	mov	a,dpl
      006BBE 90 07 E5         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006BC1 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006BC2 E0               [24]  641 	movx	a,@dptr
      006BC3 FF               [12]  642 	mov	r7,a
      006BC4 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006BC7                        644 00113$:
      006BC7 40 05            [24]  645 	jc	00101$
      006BC9 EF               [12]  646 	mov	a,r7
      006BCA 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006BCC 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006BCE                        650 00101$:
      006BCE 90 00 00         [24]  651 	mov	dptr,#0x0000
      006BD1 22               [24]  652 	ret
      006BD2                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      006BD2 EF               [12]  655 	mov	a,r7
      006BD3 24 58            [12]  656 	add	a,#0x58
      006BD5 FF               [12]  657 	mov	r7,a
      006BD6 C2 D5            [12]  658 	clr	F0
      006BD8 75 F0 02         [24]  659 	mov	b,#0x02
      006BDB EF               [12]  660 	mov	a,r7
      006BDC 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006BDF B2 D5            [12]  662 	cpl	F0
      006BE1 F4               [12]  663 	cpl	a
      006BE2 04               [12]  664 	inc	a
      006BE3                        665 00116$:
      006BE3 A4               [48]  666 	mul	ab
      006BE4 30 D5 03         [24]  667 	jnb	F0,00117$
      006BE7 12 6D DF         [24]  668 	lcall	_ak820_outline_0127
      006BEA                        669 00117$:
      006BEA 24 DB            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006BEC F5 82            [12]  671 	mov	dpl,a
      006BEE 74 B6            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006BF0 12 55 38         [24]  673 	lcall	_ak820_outline_0106
      006BF3 FE               [12]  674 	mov	r6,a
      006BF4 A3               [24]  675 	inc	dptr
      006BF5 E4               [12]  676 	clr	a
      006BF6 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:54: }
      006BF7 8E 82            [24]  679 	mov	dpl,r6
      006BF9 F5 83            [12]  680 	mov	dph,a
      006BFB 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006BFC                        695 _add_key_byte:
      006BFC 12 43 0E         [24]  696 	lcall	_ak820_outline_0035
      006BFF 90 07 E7         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006C02 12 38 20         [24]  698 	lcall	_ak820_outline_0014
                                    699 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006C05 90 07 E7         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006C08 12 38 42         [24]  701 	lcall	_ak820_outline_0052
                                    702 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      006C0B 90 07 EA         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006C0E 74 FF            [12]  704 	mov	a,#0xff
      006C10 F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:209: }
      006C11 7D 00            [12]  707 	mov	r5,#0x00
      006C13                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006C13 C3               [12]  710 	clr	c
      006C14 ED               [12]  711 	mov	a,r5
      006C15 64 80            [12]  712 	xrl	a,#0x80
      006C17 94 86            [12]  713 	subb	a,#0x86
      006C19 50 26            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      006C1B 12 6D F1         [24]  716 	lcall	_ak820_outline_0169
      006C1E 12 46 EA         [24]  717 	lcall	_ak820_outline_0115
      006C21 E0               [24]  718 	movx	a,@dptr
      006C22 FC               [12]  719 	mov	r4,a
      006C23 90 07 E6         [24]  720 	mov	dptr,#_add_key_byte_PARM_2
      006C26 E0               [24]  721 	movx	a,@dptr
      006C27 FB               [12]  722 	mov	r3,a
      006C28 EC               [12]  723 	mov	a,r4
      006C29 B5 03 02         [24]  724 	cjne	a,ar3,00167$
      006C2C 80 13            [24]  725 	sjmp	00106$
      006C2E                        726 00167$:
                                    727 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006C2E 90 07 EA         [24]  728 	mov	dptr,#_add_key_byte_empty_10000_145
      006C31 E0               [24]  729 	movx	a,@dptr
      006C32 FB               [12]  730 	mov	r3,a
      006C33 BB FF 08         [24]  731 	cjne	r3,#0xff,00113$
      006C36 EC               [12]  732 	mov	a,r4
      006C37 70 05            [24]  733 	jnz	00113$
                                    734 ;	tmk_core/protocol/report.c:200: empty = i;
      006C39 90 07 EA         [24]  735 	mov	dptr,#_add_key_byte_empty_10000_145
      006C3C ED               [12]  736 	mov	a,r5
      006C3D F0               [24]  737 	movx	@dptr,a
      006C3E                        738 00113$:
                                    739 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006C3E 0D               [12]  740 	inc	r5
      006C3F 80 D2            [24]  741 	sjmp	00112$
      006C41                        742 00106$:
                                    743 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      006C41 BD 06 1D         [24]  744 	cjne	r5,#0x06,00114$
                                    745 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      006C44 90 07 EA         [24]  746 	mov	dptr,#_add_key_byte_empty_10000_145
      006C47 E0               [24]  747 	movx	a,@dptr
      006C48 FD               [12]  748 	mov	r5,a
      006C49 BD FF 01         [24]  749 	cjne	r5,#0xff,00173$
      006C4C 22               [24]  750 	ret
      006C4D                        751 00173$:
                                    752 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      006C4D 74 02            [12]  753 	mov	a,#0x02
      006C4F 12 43 5B         [24]  754 	lcall	_ak820_outline_0133
      006C52 ED               [12]  755 	mov	a,r5
      006C53 2E               [12]  756 	add	a, r6
      006C54 FD               [12]  757 	mov	r5,a
      006C55 E4               [12]  758 	clr	a
      006C56 3F               [12]  759 	addc	a, r7
      006C57 FC               [12]  760 	mov	r4,a
      006C58 90 07 E6         [24]  761 	mov	dptr,#_add_key_byte_PARM_2
      006C5B E0               [24]  762 	movx	a,@dptr
      006C5C 8D 82            [24]  763 	mov	dpl,r5
      006C5E 8C 83            [24]  764 	mov	dph,r4
      006C60 F0               [24]  765 	movx	@dptr,a
      006C61                        766 00114$:
                                    767 ;	tmk_core/protocol/report.c:209: }
      006C61 22               [24]  768 	ret
                                    769 ;------------------------------------------------------------
                                    770 ;Allocation info for local variables in function 'del_key_byte'
                                    771 ;------------------------------------------------------------
                                    772 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    773 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    774 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    775 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    776 ;------------------------------------------------------------
                                    777 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    778 ;	-----------------------------------------
                                    779 ;	 function del_key_byte
                                    780 ;	-----------------------------------------
      006C62                        781 _del_key_byte:
      006C62 12 43 0E         [24]  782 	lcall	_ak820_outline_0035
      006C65 90 07 EC         [24]  783 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006C68 12 38 20         [24]  784 	lcall	_ak820_outline_0014
                                    785 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006C6B 90 07 EC         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006C6E 12 38 42         [24]  787 	lcall	_ak820_outline_0052
                                    788 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006C71 7D 00            [12]  789 	mov	r5,#0x00
      006C73                        790 00105$:
      006C73 BD 06 00         [24]  791 	cjne	r5,#0x06,00131$
      006C76                        792 00131$:
      006C76 50 1B            [24]  793 	jnc	00107$
                                    794 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      006C78 12 6D F1         [24]  795 	lcall	_ak820_outline_0169
      006C7B 2B               [12]  796 	add	a, r3
      006C7C FB               [12]  797 	mov	r3,a
      006C7D E4               [12]  798 	clr	a
      006C7E 3C               [12]  799 	addc	a, r4
      006C7F 12 46 CE         [24]  800 	lcall	_ak820_outline_0056
      006C82 90 07 EB         [24]  801 	mov	dptr,#_del_key_byte_PARM_2
      006C85 E0               [24]  802 	movx	a,@dptr
      006C86 F9               [12]  803 	mov	r1,a
      006C87 EA               [12]  804 	mov	a,r2
      006C88 B5 01 05         [24]  805 	cjne	a,ar1,00106$
                                    806 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      006C8B 12 33 FC         [24]  807 	lcall	_ak820_outline_0120
      006C8E E4               [12]  808 	clr	a
      006C8F F0               [24]  809 	movx	@dptr,a
      006C90                        810 00106$:
                                    811 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006C90 0D               [12]  812 	inc	r5
      006C91 80 E0            [24]  813 	sjmp	00105$
      006C93                        814 00107$:
                                    815 ;	tmk_core/protocol/report.c:249: }
      006C93 22               [24]  816 	ret
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'add_key_bit'
                                    819 ;------------------------------------------------------------
                                    820 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    821 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    822 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    823 ;------------------------------------------------------------
                                    824 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    825 ;	-----------------------------------------
                                    826 ;	 function add_key_bit
                                    827 ;	-----------------------------------------
      006C94                        828 _add_key_bit:
      006C94 12 43 0E         [24]  829 	lcall	_ak820_outline_0035
      006C97 90 07 F0         [24]  830 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006C9A 12 38 20         [24]  831 	lcall	_ak820_outline_0014
                                    832 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006C9D 90 07 F0         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006CA0 12 38 42         [24]  834 	lcall	_ak820_outline_0052
                                    835 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006CA3 90 07 EF         [24]  836 	mov	dptr,#_add_key_bit_PARM_2
      006CA6 E0               [24]  837 	movx	a,@dptr
      006CA7 FD               [12]  838 	mov	r5,a
      006CA8 12 55 6E         [24]  839 	lcall	_ak820_outline_0182
      006CAB FC               [12]  840 	mov	r4,a
      006CAC BC 1E 00         [24]  841 	cjne	r4,#0x1e,00112$
      006CAF                        842 00112$:
      006CAF 50 16            [24]  843 	jnc	00103$
                                    844 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      006CB1 12 6D C1         [24]  845 	lcall	_ak820_outline_0033
      006CB4 80 02            [24]  846 	sjmp	00115$
      006CB6                        847 00114$:
      006CB6 25 E0            [12]  848 	add	a,acc
      006CB8                        849 00115$:
      006CB8 D5 F0 FB         [24]  850 	djnz	b,00114$
      006CBB FF               [12]  851 	mov	r7,a
      006CBC 12 43 82         [24]  852 	lcall	_ak820_outline_0179
      006CBF E0               [24]  853 	movx	a,@dptr
      006CC0 42 07            [12]  854 	orl	ar7,a
      006CC2 12 43 82         [24]  855 	lcall	_ak820_outline_0179
      006CC5 EF               [12]  856 	mov	a,r7
      006CC6 F0               [24]  857 	movx	@dptr,a
      006CC7                        858 00103$:
                                    859 ;	tmk_core/protocol/report.c:263: }
      006CC7 22               [24]  860 	ret
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'del_key_bit'
                                    863 ;------------------------------------------------------------
                                    864 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    865 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    866 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    867 ;------------------------------------------------------------
                                    868 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    869 ;	-----------------------------------------
                                    870 ;	 function del_key_bit
                                    871 ;	-----------------------------------------
      006CC8                        872 _del_key_bit:
      006CC8 12 43 0E         [24]  873 	lcall	_ak820_outline_0035
      006CCB 90 07 F4         [24]  874 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006CCE 12 38 20         [24]  875 	lcall	_ak820_outline_0014
                                    876 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006CD1 90 07 F4         [24]  877 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006CD4 12 38 42         [24]  878 	lcall	_ak820_outline_0052
                                    879 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006CD7 90 07 F3         [24]  880 	mov	dptr,#_del_key_bit_PARM_2
      006CDA E0               [24]  881 	movx	a,@dptr
      006CDB FD               [12]  882 	mov	r5,a
      006CDC 12 55 6E         [24]  883 	lcall	_ak820_outline_0182
      006CDF FC               [12]  884 	mov	r4,a
      006CE0 BC 1E 00         [24]  885 	cjne	r4,#0x1e,00112$
      006CE3                        886 00112$:
      006CE3 50 17            [24]  887 	jnc	00103$
                                    888 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      006CE5 12 6D C1         [24]  889 	lcall	_ak820_outline_0033
      006CE8 80 02            [24]  890 	sjmp	00115$
      006CEA                        891 00114$:
      006CEA 25 E0            [12]  892 	add	a,acc
      006CEC                        893 00115$:
      006CEC D5 F0 FB         [24]  894 	djnz	b,00114$
      006CEF F4               [12]  895 	cpl	a
      006CF0 FF               [12]  896 	mov	r7,a
      006CF1 12 43 82         [24]  897 	lcall	_ak820_outline_0179
      006CF4 E0               [24]  898 	movx	a,@dptr
      006CF5 52 07            [12]  899 	anl	ar7,a
      006CF7 12 43 82         [24]  900 	lcall	_ak820_outline_0179
      006CFA EF               [12]  901 	mov	a,r7
      006CFB F0               [24]  902 	movx	@dptr,a
      006CFC                        903 00103$:
                                    904 ;	tmk_core/protocol/report.c:276: }
      006CFC 22               [24]  905 	ret
                                    906 ;------------------------------------------------------------
                                    907 ;Allocation info for local variables in function 'add_key_to_report'
                                    908 ;------------------------------------------------------------
                                    909 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    910 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    911 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    912 ;------------------------------------------------------------
                                    913 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    914 ;	-----------------------------------------
                                    915 ;	 function add_key_to_report
                                    916 ;	-----------------------------------------
      006CFD                        917 _add_key_to_report:
      006CFD 12 43 0E         [24]  918 	lcall	_ak820_outline_0035
      006D00 90 07 F8         [24]  919 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006D03 12 38 20         [24]  920 	lcall	_ak820_outline_0014
                                    921 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006D06 90 07 F8         [24]  922 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006D09 12 38 42         [24]  923 	lcall	_ak820_outline_0052
                                    924 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      006D0C 90 0D A9         [24]  925 	mov	dptr,#_keyboard_protocol
      006D0F E0               [24]  926 	movx	a,@dptr
      006D10 60 19            [24]  927 	jz	00102$
      006D12 90 0A B6         [24]  928 	mov	dptr,#_keymap_config
      006D15 E0               [24]  929 	movx	a,@dptr
      006D16 30 E7 12         [24]  930 	jnb	acc.7,00102$
                                    931 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      006D19 12 6D EA         [24]  932 	lcall	_ak820_outline_0146
      006D1C 90 07 F7         [24]  933 	mov	dptr,#_add_key_to_report_PARM_2
      006D1F E0               [24]  934 	movx	a,@dptr
      006D20 90 07 EF         [24]  935 	mov	dptr,#_add_key_bit_PARM_2
      006D23 12 46 E4         [24]  936 	lcall	_ak820_outline_0097
      006D26 8D F0            [24]  937 	mov	b, r5
                                    938 ;	tmk_core/protocol/report.c:288: return;
      006D28 02 6C 94         [24]  939 	ljmp	_add_key_bit
      006D2B                        940 00102$:
                                    941 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      006D2B 7D 00            [12]  942 	mov	r5,#0x00
      006D2D 90 07 F7         [24]  943 	mov	dptr,#_add_key_to_report_PARM_2
      006D30 E0               [24]  944 	movx	a,@dptr
      006D31 90 07 E6         [24]  945 	mov	dptr,#_add_key_byte_PARM_2
      006D34 F0               [24]  946 	movx	@dptr,a
      006D35 12 6D D8         [24]  947 	lcall	_ak820_outline_0050
                                    948 ;	tmk_core/protocol/report.c:292: }
      006D38 02 6B FC         [24]  949 	ljmp	_add_key_byte
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'del_key_from_report'
                                    952 ;------------------------------------------------------------
                                    953 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    954 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    955 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    956 ;------------------------------------------------------------
                                    957 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function del_key_from_report
                                    960 ;	-----------------------------------------
      006D3B                        961 _del_key_from_report:
      006D3B 12 43 0E         [24]  962 	lcall	_ak820_outline_0035
      006D3E 90 07 FC         [24]  963 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006D41 12 38 20         [24]  964 	lcall	_ak820_outline_0014
                                    965 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006D44 90 07 FC         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006D47 12 38 42         [24]  967 	lcall	_ak820_outline_0052
                                    968 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      006D4A 90 0D A9         [24]  969 	mov	dptr,#_keyboard_protocol
      006D4D E0               [24]  970 	movx	a,@dptr
      006D4E 60 19            [24]  971 	jz	00102$
      006D50 90 0A B6         [24]  972 	mov	dptr,#_keymap_config
      006D53 E0               [24]  973 	movx	a,@dptr
      006D54 30 E7 12         [24]  974 	jnb	acc.7,00102$
                                    975 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      006D57 12 6D EA         [24]  976 	lcall	_ak820_outline_0146
      006D5A 90 07 FB         [24]  977 	mov	dptr,#_del_key_from_report_PARM_2
      006D5D E0               [24]  978 	movx	a,@dptr
      006D5E 90 07 F3         [24]  979 	mov	dptr,#_del_key_bit_PARM_2
      006D61 12 46 E4         [24]  980 	lcall	_ak820_outline_0097
      006D64 8D F0            [24]  981 	mov	b, r5
                                    982 ;	tmk_core/protocol/report.c:303: return;
      006D66 02 6C C8         [24]  983 	ljmp	_del_key_bit
      006D69                        984 00102$:
                                    985 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      006D69 7D 00            [12]  986 	mov	r5,#0x00
      006D6B 90 07 FB         [24]  987 	mov	dptr,#_del_key_from_report_PARM_2
      006D6E E0               [24]  988 	movx	a,@dptr
      006D6F 90 07 EB         [24]  989 	mov	dptr,#_del_key_byte_PARM_2
      006D72 F0               [24]  990 	movx	@dptr,a
      006D73 12 6D D8         [24]  991 	lcall	_ak820_outline_0050
                                    992 ;	tmk_core/protocol/report.c:307: }
      006D76 02 6C 62         [24]  993 	ljmp	_del_key_byte
                                    994 ;------------------------------------------------------------
                                    995 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    996 ;------------------------------------------------------------
                                    997 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    998 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    999 ;------------------------------------------------------------
                                   1000 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function clear_keys_from_report
                                   1003 ;	-----------------------------------------
      006D79                       1004 _clear_keys_from_report:
      006D79 12 43 0E         [24] 1005 	lcall	_ak820_outline_0035
      006D7C 90 07 FF         [24] 1006 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006D7F 12 38 20         [24] 1007 	lcall	_ak820_outline_0014
                                   1008 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006D82 90 07 FF         [24] 1009 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006D85 12 38 42         [24] 1010 	lcall	_ak820_outline_0052
                                   1011 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      006D88 90 0D A9         [24] 1012 	mov	dptr,#_keyboard_protocol
      006D8B E0               [24] 1013 	movx	a,@dptr
      006D8C 60 1E            [24] 1014 	jz	00102$
      006D8E 90 0A B6         [24] 1015 	mov	dptr,#_keymap_config
      006D91 E0               [24] 1016 	movx	a,@dptr
      006D92 30 E7 17         [24] 1017 	jnb	acc.7,00102$
                                   1018 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      006D95 74 02            [12] 1019 	mov	a,#0x02
      006D97 12 43 76         [24] 1020 	lcall	_ak820_outline_0157
      006D9A 7B 00            [12] 1021 	mov	r3,#0x00
      006D9C 12 6D FA         [24] 1022 	lcall	_ak820_outline_0177
      006D9F 74 1E            [12] 1023 	mov	a,#0x1e
      006DA1 12 38 97         [24] 1024 	lcall	_ak820_outline_0122
      006DA4 12 38 92         [24] 1025 	lcall	_ak820_outline_0121
      006DA7 8B F0            [24] 1026 	mov	b, r3
                                   1027 ;	tmk_core/protocol/report.c:319: return;
      006DA9 02 B5 CC         [24] 1028 	ljmp	_memset
      006DAC                       1029 00102$:
                                   1030 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      006DAC 74 02            [12] 1031 	mov	a,#0x02
      006DAE 12 43 5B         [24] 1032 	lcall	_ak820_outline_0133
      006DB1 7D 00            [12] 1033 	mov	r5,#0x00
      006DB3 12 6D FA         [24] 1034 	lcall	_ak820_outline_0177
      006DB6 74 06            [12] 1035 	mov	a,#0x06
      006DB8 12 38 97         [24] 1036 	lcall	_ak820_outline_0122
      006DBB 12 6D D8         [24] 1037 	lcall	_ak820_outline_0050
                                   1038 ;	tmk_core/protocol/report.c:323: }
      006DBE 02 B5 CC         [24] 1039 	ljmp	_memset
                                   1040 	.area CSEG    (CODE)
                                   1041 	.area CONST   (CODE)
                                   1042 	.area CONST   (CODE)
      00B6DB                       1043 _KEYCODE2CONSUMER_usages_10000_118:
      00B6DB E2 00                 1044 	.byte #0xe2, #0x00	; 226
      00B6DD E9 00                 1045 	.byte #0xe9, #0x00	; 233
      00B6DF EA 00                 1046 	.byte #0xea, #0x00	; 234
      00B6E1 B5 00                 1047 	.byte #0xb5, #0x00	; 181
      00B6E3 B6 00                 1048 	.byte #0xb6, #0x00	; 182
      00B6E5 B7 00                 1049 	.byte #0xb7, #0x00	; 183
      00B6E7 CD 00                 1050 	.byte #0xcd, #0x00	; 205
      00B6E9 83 01                 1051 	.byte #0x83, #0x01	; 387
      00B6EB CC 00                 1052 	.byte #0xcc, #0x00	; 204
      00B6ED 8A 01                 1053 	.byte #0x8a, #0x01	; 394
      00B6EF 92 01                 1054 	.byte #0x92, #0x01	; 402
      00B6F1 94 01                 1055 	.byte #0x94, #0x01	; 404
      00B6F3 21 02                 1056 	.byte #0x21, #0x02	; 545
      00B6F5 23 02                 1057 	.byte #0x23, #0x02	; 547
      00B6F7 24 02                 1058 	.byte #0x24, #0x02	; 548
      00B6F9 25 02                 1059 	.byte #0x25, #0x02	; 549
      00B6FB 26 02                 1060 	.byte #0x26, #0x02	; 550
      00B6FD 27 02                 1061 	.byte #0x27, #0x02	; 551
      00B6FF 2A 02                 1062 	.byte #0x2a, #0x02	; 554
      00B701 B3 00                 1063 	.byte #0xb3, #0x00	; 179
      00B703 B4 00                 1064 	.byte #0xb4, #0x00	; 180
      00B705 6F 00                 1065 	.byte #0x6f, #0x00	; 111
      00B707 70 00                 1066 	.byte #0x70, #0x00	; 112
      00B709 9F 01                 1067 	.byte #0x9f, #0x01	; 415
      00B70B CB 01                 1068 	.byte #0xcb, #0x01	; 459
      00B70D 9F 02                 1069 	.byte #0x9f, #0x02	; 671
      00B70F A0 02                 1070 	.byte #0xa0, #0x02	; 672
                                   1071 	.area CSEG    (CODE)
                                   1072 	.area XINIT   (CODE)
                                   1073 	.area CABS    (ABS,CODE)
                                   1074 
                                   1075 ; Experimental exact instruction outlining.
                                   1076 	.globl _ak820_outline_0014
                                   1077 	.globl _ak820_outline_0033
                                   1078 	.globl _ak820_outline_0035
                                   1079 	.globl _ak820_outline_0050
                                   1080 	.globl _ak820_outline_0052
                                   1081 	.globl _ak820_outline_0056
                                   1082 	.globl _ak820_outline_0097
                                   1083 	.globl _ak820_outline_0106
                                   1084 	.globl _ak820_outline_0115
                                   1085 	.globl _ak820_outline_0120
                                   1086 	.globl _ak820_outline_0121
                                   1087 	.globl _ak820_outline_0122
                                   1088 	.globl _ak820_outline_0127
                                   1089 	.globl _ak820_outline_0133
                                   1090 	.globl _ak820_outline_0146
                                   1091 	.globl _ak820_outline_0157
                                   1092 	.globl _ak820_outline_0169
                                   1093 	.globl _ak820_outline_0177
                                   1094 	.globl _ak820_outline_0179
                                   1095 	.globl _ak820_outline_0182
                                   1096 
                                   1097 	.area CSEG (CODE)
                                   1098 ; function ak820_outline_0033
      006DC1                       1099 _ak820_outline_0033:
      006DC1 74 02            [12] 1100 	mov	a,#0x02
      006DC3 2E               [12] 1101 	add	a,r6
      006DC4 FE               [12] 1102 	mov	r6,a
      006DC5 E4               [12] 1103 	clr	a
      006DC6 3F               [12] 1104 	addc	a,r7
      006DC7 FF               [12] 1105 	mov	r7,a
      006DC8 EC               [12] 1106 	mov	a,r4
      006DC9 2E               [12] 1107 	add	a,r6
      006DCA FC               [12] 1108 	mov	r4,a
      006DCB E4               [12] 1109 	clr	a
      006DCC 3F               [12] 1110 	addc	a,r7
      006DCD FB               [12] 1111 	mov	r3,a
      006DCE 74 07            [12] 1112 	mov	a,#0x07
      006DD0 5D               [12] 1113 	anl	a,r5
      006DD1 F5 F0            [12] 1114 	mov	b,a
      006DD3 05 F0            [12] 1115 	inc	b
      006DD5 74 01            [12] 1116 	mov	a,#0x01
      006DD7 22               [24] 1117 	ret
                                   1118 
                                   1119 	.area CSEG (CODE)
                                   1120 ; function ak820_outline_0050
      006DD8                       1121 _ak820_outline_0050:
      006DD8 8E 82            [24] 1122 	mov	dpl,r6
      006DDA 8F 83            [24] 1123 	mov	dph,r7
      006DDC 8D F0            [24] 1124 	mov	b,r5
      006DDE 22               [24] 1125 	ret
                                   1126 
                                   1127 	.area CSEG (CODE)
                                   1128 ; function ak820_outline_0127
      006DDF                       1129 _ak820_outline_0127:
      006DDF F4               [12] 1130 	cpl	a
      006DE0 24 01            [12] 1131 	add	a,#0x01
      006DE2 C5 F0            [12] 1132 	xch	a,b
      006DE4 F4               [12] 1133 	cpl	a
      006DE5 34 00            [12] 1134 	addc	a,#0x00
      006DE7 C5 F0            [12] 1135 	xch	a,b
      006DE9 22               [24] 1136 	ret
                                   1137 
                                   1138 	.area CSEG (CODE)
                                   1139 ; function ak820_outline_0146
      006DEA                       1140 _ak820_outline_0146:
      006DEA 8E 03            [24] 1141 	mov	ar3,r6
      006DEC 8F 04            [24] 1142 	mov	ar4,r7
      006DEE 7D 00            [12] 1143 	mov	r5,#0x00
      006DF0 22               [24] 1144 	ret
                                   1145 
                                   1146 	.area CSEG (CODE)
                                   1147 ; function ak820_outline_0169
      006DF1                       1148 _ak820_outline_0169:
      006DF1 74 02            [12] 1149 	mov	a,#0x02
      006DF3 2E               [12] 1150 	add	a,r6
      006DF4 FB               [12] 1151 	mov	r3,a
      006DF5 E4               [12] 1152 	clr	a
      006DF6 3F               [12] 1153 	addc	a,r7
      006DF7 FC               [12] 1154 	mov	r4,a
      006DF8 ED               [12] 1155 	mov	a,r5
      006DF9 22               [24] 1156 	ret
                                   1157 
                                   1158 	.area CSEG (CODE)
                                   1159 ; function ak820_outline_0177
      006DFA                       1160 _ak820_outline_0177:
      006DFA 90 0D A0         [24] 1161 	mov	dptr,#_memset_PARM_2
      006DFD E4               [12] 1162 	clr	a
      006DFE F0               [24] 1163 	movx	@dptr,a
      006DFF 90 0D A1         [24] 1164 	mov	dptr,#_memset_PARM_3
      006E02 22               [24] 1165 	ret
