                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00096A                        580 _owned_mod_refs:
      00096A                        581 	.ds 8
      000972                        582 _owned_weak_refs:
      000972                        583 	.ds 8
      00097A                        584 _owned_mods:
      00097A                        585 	.ds 1
      00097B                        586 _owned_weak_mods:
      00097B                        587 	.ds 1
      00097C                        588 _macro_mods:
      00097C                        589 	.ds 2
      00097E                        590 _ak820_macro_primitive::
      00097E                        591 	.ds 1
      00097F                        592 _ak820_macro_cancelled::
      00097F                        593 	.ds 1
      000980                        594 _ak820_macro_change_PARM_2:
      000980                        595 	.ds 1
      000981                        596 _ak820_macro_change_PARM_3:
      000981                        597 	.ds 1
      000982                        598 _ak820_macro_change_bits_10000_293:
      000982                        599 	.ds 2
      000984                        600 _change_owned_PARM_2:
      000984                        601 	.ds 1
      000985                        602 _change_owned_mods_10000_298:
      000985                        603 	.ds 1
      000986                        604 _change_owned_result_10001_302:
      000986                        605 	.ds 1
      000987                        606 _change_owned_bit_20001_303:
      000987                        607 	.ds 1
      000988                        608 _add_owned_mods_mods_10000_311:
      000988                        609 	.ds 1
      000989                        610 _del_owned_mods_mods_10000_313:
      000989                        611 	.ds 1
      00098A                        612 _add_owned_weak_mods_mods_10000_315:
      00098A                        613 	.ds 1
      00098B                        614 _del_owned_weak_mods_mods_10000_317:
      00098B                        615 	.ds 1
      00098C                        616 _key_refs:
      00098C                        617 	.ds 165
      000A31                        618 _distinct_keys:
      000A31                        619 	.ds 1
      000A32                        620 _macro_keys:
      000A32                        621 	.ds 21
      000A47                        622 _add_owned_key_code_10000_326:
      000A47                        623 	.ds 1
      000A48                        624 _del_owned_key_code_10000_341:
      000A48                        625 	.ds 1
      000A49                        626 _usage_refs:
      000A49                        627 	.ds 30
      000A67                        628 _usage_order:
      000A67                        629 	.ds 30
      000A85                        630 _usage_lengths:
      000A85                        631 	.ds 2
      000A87                        632 _macro_usages:
      000A87                        633 	.ds 4
      000A8B                        634 _owned_usage_key_PARM_2:
      000A8B                        635 	.ds 1
      000A8C                        636 _owned_usage_key_code_10000_368:
      000A8C                        637 	.ds 1
      000A8D                        638 _owned_usage_key___200000085_20000_369:
      000A8D                        639 	.ds 2
      000A8F                        640 _owned_usage_key_which_10000_369:
      000A8F                        641 	.ds 1
      000A90                        642 _owned_usage_key_count_10000_369:
      000A90                        643 	.ds 1
      000A91                        644 _owned_usage_key_pos_30001_376:
      000A91                        645 	.ds 1
      000A92                        646 _owned_usage_key_key_40000_381:
      000A92                        647 	.ds 1
      000A93                        648 _send_keyboard_report_last_report_10001_388:
      000A93                        649 	.ds 32
      000AB3                        650 _send_keyboard_report_changed_10001_388:
      000AB3                        651 	.ds 1
      000AB4                        652 _add_weak_mods_mods_10000_406:
      000AB4                        653 	.ds 1
      000AB5                        654 _del_weak_mods_mods_10000_408:
      000AB5                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DBA                        664 _real_mods:
      000DBA                        665 	.ds 1
      000DBB                        666 _weak_mods:
      000DBB                        667 	.ds 1
      000DBC                        668 _actual_keyboard_report::
      000DBC                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      0078C4                        713 _ak820_macro_change:
      0078C4 12 38 88         [24]  714 	lcall	_ak820_outline_0113
      0078C7 90 09 82         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078CA 12 38 83         [24]  716 	lcall	_ak820_outline_0105
                                    717 ;	quantum/action_util.c:57: if (!ak820_macro_primitive) return true;
      0078CD 90 09 7E         [24]  718 	mov	dptr,#_ak820_macro_primitive
      0078D0 E0               [24]  719 	movx	a,@dptr
      0078D1 70 04            [24]  720 	jnz	00102$
      0078D3 75 82 01         [24]  721 	mov	dpl, #0x01
      0078D6 22               [24]  722 	ret
      0078D7                        723 00102$:
                                    724 ;	quantum/action_util.c:58: uint8_t mask = 1u << (index & 7);
      0078D7 90 09 80         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      0078DA E0               [24]  726 	movx	a,@dptr
      0078DB FF               [12]  727 	mov	r7,a
      0078DC 74 07            [12]  728 	mov	a,#0x07
      0078DE 5F               [12]  729 	anl	a,r7
      0078DF 12 74 65         [24]  730 	lcall	_ak820_outline_0063
      0078E2 80 02            [24]  731 	sjmp	00123$
      0078E4                        732 00122$:
      0078E4 25 E0            [12]  733 	add	a,acc
      0078E6                        734 00123$:
      0078E6 D5 F0 FB         [24]  735 	djnz	b,00122$
      0078E9 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:59: bits += index >> 3;
      0078EA EF               [12]  738 	mov	a,r7
      0078EB 12 55 6E         [24]  739 	lcall	_ak820_outline_0182
      0078EE FF               [12]  740 	mov	r7,a
      0078EF 90 09 82         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078F2 12 38 59         [24]  742 	lcall	_ak820_outline_0060
      0078F5 90 09 82         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0078F8 EF               [12]  744 	mov	a,r7
      0078F9 2C               [12]  745 	add	a, r4
      0078FA F0               [24]  746 	movx	@dptr,a
      0078FB E4               [12]  747 	clr	a
      0078FC 3D               [12]  748 	addc	a, r5
      0078FD A3               [24]  749 	inc	dptr
      0078FE F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:60: if (((*bits & mask) != 0) == pressed) return false;
      0078FF 90 09 82         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007902 E0               [24]  753 	movx	a,@dptr
      007903 FD               [12]  754 	mov	r5,a
      007904 A3               [24]  755 	inc	dptr
      007905 E0               [24]  756 	movx	a,@dptr
      007906 FF               [12]  757 	mov	r7,a
      007907 12 7E 51         [24]  758 	lcall	_ak820_outline_0183
      00790A E0               [24]  759 	movx	a,@dptr
      00790B FC               [12]  760 	mov	r4,a
      00790C EE               [12]  761 	mov	a,r6
      00790D 5C               [12]  762 	anl	a,r4
      00790E B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007911                        764 00124$:
      007911 B3               [12]  765 	cpl	c
      007912 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007914 90 09 81         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007917 E0               [24]  768 	movx	a,@dptr
      007918 FB               [12]  769 	mov	r3,a
      007919 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      00791B E4               [12]  771 	clr	a
      00791C 33               [12]  772 	rlc	a
      00791D B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007920 75 82 00         [24]  774 	mov	dpl, #0x00
      007923 22               [24]  775 	ret
      007924                        776 00104$:
                                    777 ;	quantum/action_util.c:61: *bits ^= mask;
      007924 EC               [12]  778 	mov	a,r4
      007925 62 06            [12]  779 	xrl	ar6,a
      007927 12 7E 51         [24]  780 	lcall	_ak820_outline_0183
      00792A EE               [12]  781 	mov	a,r6
      00792B F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:62: return true;
      00792C 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:63: }
      00792F 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:64: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007930                        805 _change_owned:
      007930 E5 82            [12]  806 	mov	a,dpl
      007932 90 09 85         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007935 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:65: uint8_t kind = mode >> 1;
      007936 90 09 84         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007939 E0               [24]  811 	movx	a,@dptr
      00793A FF               [12]  812 	mov	r7,a
      00793B C3               [12]  813 	clr	c
      00793C 13               [12]  814 	rrc	a
      00793D FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:66: bool pressed = (mode & 1) != 0;
      00793E 53 07 01         [24]  817 	anl	ar7,#0x01
      007941 EF               [12]  818 	mov	a,r7
      007942 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007945                        820 00205$:
      007945 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007947 B3               [12]  822 	cpl	c
      007948 E4               [12]  823 	clr	a
      007949 33               [12]  824 	rlc	a
      00794A F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:67: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      00794C EE               [12]  827 	mov	a,r6
      00794D 60 06            [24]  828 	jz	00121$
      00794F 7D 72            [12]  829 	mov	r5,#_owned_weak_refs
      007951 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007953 80 04            [24]  831 	sjmp	00122$
      007955                        832 00121$:
      007955 7D 6A            [12]  833 	mov	r5,#_owned_mod_refs
      007957 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007959                        835 00122$:
                                    836 ;	quantum/action_util.c:68: if (ak820_macro_primitive) {
      007959 90 09 7E         [24]  837 	mov	dptr,#_ak820_macro_primitive
      00795C E0               [24]  838 	movx	a,@dptr
      00795D 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:69: uint8_t old = macro_mods[kind];
      00795F EE               [12]  841 	mov	a,r6
      007960 24 7C            [12]  842 	add	a, #_macro_mods
      007962 FB               [12]  843 	mov	r3,a
      007963 E4               [12]  844 	clr	a
      007964 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007966 12 46 CE         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:70: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007969 E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      00796B 60 0A            [24]  849 	jz	00123$
      00796D 90 09 85         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007970 E0               [24]  851 	movx	a,@dptr
      007971 F9               [12]  852 	mov	r1,a
      007972 EA               [12]  853 	mov	a,r2
      007973 42 01            [12]  854 	orl	ar1,a
      007975 80 07            [24]  855 	sjmp	00124$
      007977                        856 00123$:
      007977 90 09 85         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      00797A E0               [24]  858 	movx	a,@dptr
      00797B F4               [12]  859 	cpl	a
      00797C 5A               [12]  860 	anl	a,r2
      00797D F9               [12]  861 	mov	r1,a
      00797E                        862 00124$:
      00797E 12 33 FC         [24]  863 	lcall	_ak820_outline_0120
      007981 E9               [12]  864 	mov	a,r1
      007982 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:71: mods &= pressed ? ~old : old;
      007983 E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007985 60 06            [24]  868 	jz	00125$
      007987 74 FF            [12]  869 	mov	a,#0xff
      007989 6A               [12]  870 	xrl	a,r2
      00798A FC               [12]  871 	mov	r4,a
      00798B 80 02            [24]  872 	sjmp	00126$
      00798D                        873 00125$:
      00798D 8A 04            [24]  874 	mov	ar4,r2
      00798F                        875 00126$:
      00798F 90 09 85         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007992 E0               [24]  877 	movx	a,@dptr
      007993 5C               [12]  878 	anl	a,r4
      007994 F0               [24]  879 	movx	@dptr,a
      007995                        880 00102$:
                                    881 ;	quantum/action_util.c:73: uint8_t result = 0;
      007995 90 09 86         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007998 E4               [12]  883 	clr	a
      007999 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00799A 90 09 87         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      00799D 04               [12]  887 	inc	a
      00799E F0               [24]  888 	movx	@dptr,a
      00799F 90 09 85         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      0079A2 E0               [24]  890 	movx	a,@dptr
      0079A3 FC               [12]  891 	mov	r4,a
      0079A4 7B 00            [12]  892 	mov	r3,#0x00
      0079A6                        893 00117$:
      0079A6 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      0079A9                        895 00210$:
      0079A9 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:75: if (mods & bit) {
      0079AB 90 09 87         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      0079AE E0               [24]  899 	movx	a,@dptr
      0079AF 5C               [12]  900 	anl	a,r4
      0079B0 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:76: if (pressed) ++refs[i];
      0079B2 E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      0079B4 60 0C            [24]  904 	jz	00106$
      0079B6 EB               [12]  905 	mov	a,r3
      0079B7 2D               [12]  906 	add	a, r5
      0079B8 12 38 28         [24]  907 	lcall	_ak820_outline_0015
      0079BB F8               [12]  908 	mov	r0,a
      0079BC 08               [12]  909 	inc	r0
      0079BD 12 7E 0E         [24]  910 	lcall	_ak820_outline_0064
      0079C0 80 0C            [24]  911 	sjmp	00109$
      0079C2                        912 00106$:
                                    913 ;	quantum/action_util.c:77: else if (refs[i]) --refs[i];
      0079C2 EB               [12]  914 	mov	a,r3
      0079C3 2D               [12]  915 	add	a, r5
      0079C4 12 38 28         [24]  916 	lcall	_ak820_outline_0015
      0079C7 F8               [12]  917 	mov	r0,a
      0079C8 60 04            [24]  918 	jz	00109$
      0079CA 18               [12]  919 	dec	r0
      0079CB 12 7E 0E         [24]  920 	lcall	_ak820_outline_0064
      0079CE                        921 00109$:
                                    922 ;	quantum/action_util.c:79: if (refs[i]) result |= bit;
      0079CE EB               [12]  923 	mov	a,r3
      0079CF 2D               [12]  924 	add	a, r5
      0079D0 12 38 28         [24]  925 	lcall	_ak820_outline_0015
      0079D3 60 0B            [24]  926 	jz	00118$
      0079D5 90 09 87         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      0079D8 E0               [24]  928 	movx	a,@dptr
      0079D9 FA               [12]  929 	mov	r2,a
      0079DA 90 09 86         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      0079DD E0               [24]  931 	movx	a,@dptr
      0079DE 4A               [12]  932 	orl	a,r2
      0079DF F0               [24]  933 	movx	@dptr,a
      0079E0                        934 00118$:
                                    935 ;	quantum/action_util.c:74: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0079E0 0B               [12]  936 	inc	r3
      0079E1 90 09 87         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      0079E4 E0               [24]  938 	movx	a,@dptr
      0079E5 25 E0            [12]  939 	add	a,acc
      0079E7 F0               [24]  940 	movx	@dptr,a
      0079E8 80 BC            [24]  941 	sjmp	00117$
      0079EA                        942 00112$:
                                    943 ;	quantum/action_util.c:81: if (kind) owned_weak_mods = result;
      0079EA EE               [12]  944 	mov	a,r6
      0079EB 60 09            [24]  945 	jz	00114$
      0079ED 90 09 86         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      0079F0 E0               [24]  947 	movx	a,@dptr
      0079F1 90 09 7B         [24]  948 	mov	dptr,#_owned_weak_mods
      0079F4 F0               [24]  949 	movx	@dptr,a
      0079F5 22               [24]  950 	ret
      0079F6                        951 00114$:
                                    952 ;	quantum/action_util.c:82: else owned_mods = result;
      0079F6 90 09 86         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      0079F9 E0               [24]  954 	movx	a,@dptr
      0079FA 90 09 7A         [24]  955 	mov	dptr,#_owned_mods
      0079FD F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:83: }
      0079FE 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:84: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      0079FF                        968 _add_owned_mods:
      0079FF E5 82            [12]  969 	mov	a,dpl
      007A01 90 09 88         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007A04 12 7E 2E         [24]  971 	lcall	_ak820_outline_0112
      007A07 74 01            [12]  972 	mov	a,#0x01
      007A09 F0               [24]  973 	movx	@dptr,a
      007A0A 8F 82            [24]  974 	mov	dpl, r7
      007A0C 02 79 30         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:85: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007A0F                        985 _del_owned_mods:
      007A0F E5 82            [12]  986 	mov	a,dpl
      007A11 90 09 89         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007A14 12 7E 2E         [24]  988 	lcall	_ak820_outline_0112
      007A17 E4               [12]  989 	clr	a
      007A18 F0               [24]  990 	movx	@dptr,a
      007A19 8F 82            [24]  991 	mov	dpl, r7
      007A1B 02 79 30         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:86: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007A1E                       1002 _add_owned_weak_mods:
      007A1E E5 82            [12] 1003 	mov	a,dpl
      007A20 90 09 8A         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007A23 12 7E 2E         [24] 1005 	lcall	_ak820_outline_0112
      007A26 74 03            [12] 1006 	mov	a,#0x03
      007A28 F0               [24] 1007 	movx	@dptr,a
      007A29 8F 82            [24] 1008 	mov	dpl, r7
      007A2B 02 79 30         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:87: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007A2E                       1019 _del_owned_weak_mods:
      007A2E E5 82            [12] 1020 	mov	a,dpl
      007A30 90 09 8B         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007A33 12 7E 2E         [24] 1022 	lcall	_ak820_outline_0112
      007A36 74 02            [12] 1023 	mov	a,#0x02
      007A38 F0               [24] 1024 	movx	@dptr,a
      007A39 8F 82            [24] 1025 	mov	dpl, r7
      007A3B 02 79 30         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:88: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007A3E                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:89: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007A3E 7F 00            [12] 1038 	mov	r7,#0x00
      007A40                       1039 00103$:
      007A40 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007A43                       1041 00122$:
      007A43 50 1A            [24] 1042 	jnc	00101$
      007A45 EF               [12] 1043 	mov	a,r7
      007A46 24 6A            [12] 1044 	add	a, #_owned_mod_refs
      007A48 FD               [12] 1045 	mov	r5,a
      007A49 E4               [12] 1046 	clr	a
      007A4A 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007A4C FE               [12] 1048 	mov	r6,a
      007A4D EF               [12] 1049 	mov	a,r7
      007A4E 24 72            [12] 1050 	add	a, #_owned_weak_refs
      007A50 F5 82            [12] 1051 	mov	dpl,a
      007A52 E4               [12] 1052 	clr	a
      007A53 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007A55 F5 83            [12] 1054 	mov	dph,a
      007A57 E4               [12] 1055 	clr	a
      007A58 F0               [24] 1056 	movx	@dptr,a
      007A59 12 7E 35         [24] 1057 	lcall	_ak820_outline_0119
      007A5C 0F               [12] 1058 	inc	r7
      007A5D 80 E1            [24] 1059 	sjmp	00103$
      007A5F                       1060 00101$:
                                   1061 ;	quantum/action_util.c:90: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007A5F 90 09 7D         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007A62 E4               [12] 1063 	clr	a
      007A63 F0               [24] 1064 	movx	@dptr,a
      007A64 90 09 7C         [24] 1065 	mov	dptr,#_macro_mods
      007A67 F0               [24] 1066 	movx	@dptr,a
      007A68 90 09 7B         [24] 1067 	mov	dptr,#_owned_weak_mods
      007A6B F0               [24] 1068 	movx	@dptr,a
      007A6C 90 09 7A         [24] 1069 	mov	dptr,#_owned_mods
      007A6F F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:91: ak820_macro_cancelled = true;
      007A70 90 09 7F         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007A73 04               [12] 1073 	inc	a
      007A74 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:92: }
      007A75 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:98: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007A76                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:99: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007A76 7F 00            [12] 1089 	mov	r7,#0x00
      007A78                       1090 00104$:
      007A78 EF               [12] 1091 	mov	a,r7
      007A79 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007A7B 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007A7D EF               [12] 1095 	mov	a,r7
      007A7E 24 8C            [12] 1096 	add	a, #_key_refs
      007A80 F5 82            [12] 1097 	mov	dpl,a
      007A82 E4               [12] 1098 	clr	a
      007A83 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007A85 12 78 B5         [24] 1100 	lcall	_ak820_outline_0159
      007A88 80 EE            [24] 1101 	sjmp	00104$
      007A8A                       1102 00101$:
                                   1103 ;	quantum/action_util.c:100: distinct_keys = 0;
      007A8A 90 0A 31         [24] 1104 	mov	dptr,#_distinct_keys
      007A8D E4               [12] 1105 	clr	a
      007A8E F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:101: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007A8F FF               [12] 1108 	mov	r7,a
      007A90                       1109 00107$:
      007A90 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007A93                       1111 00142$:
      007A93 50 0D            [24] 1112 	jnc	00109$
      007A95 EF               [12] 1113 	mov	a,r7
      007A96 24 32            [12] 1114 	add	a, #_macro_keys
      007A98 F5 82            [12] 1115 	mov	dpl,a
      007A9A E4               [12] 1116 	clr	a
      007A9B 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007A9D 12 78 B5         [24] 1118 	lcall	_ak820_outline_0159
      007AA0 80 EE            [24] 1119 	sjmp	00107$
      007AA2                       1120 00109$:
                                   1121 ;	quantum/action_util.c:102: }
      007AA2 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:103: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007AA3                       1137 _add_owned_key:
      007AA3 E5 82            [12] 1138 	mov	a,dpl
      007AA5 90 0A 47         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007AA8 12 7E 46         [24] 1140 	lcall	_ak820_outline_0129
                                   1141 ;	quantum/action_util.c:104: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007AAB 74 01            [12] 1142 	mov	a,#0x01
      007AAD F0               [24] 1143 	movx	@dptr,a
      007AAE 90 0A 32         [24] 1144 	mov	dptr,#_macro_keys
      007AB1 C0 07            [24] 1145 	push	ar7
      007AB3 12 78 C4         [24] 1146 	lcall	_ak820_macro_change
      007AB6 E5 82            [12] 1147 	mov	a, dpl
      007AB8 D0 07            [24] 1148 	pop	ar7
      007ABA 70 03            [24] 1149 	jnz	00102$
      007ABC F5 82            [12] 1150 	mov	dpl,a
      007ABE 22               [24] 1151 	ret
      007ABF                       1152 00102$:
                                   1153 ;	quantum/action_util.c:105: if (key_refs[code]++) return false;
      007ABF 12 7D F8         [24] 1154 	lcall	_ak820_outline_0029
      007AC2 FC               [12] 1155 	mov	r4,a
      007AC3 04               [12] 1156 	inc	a
      007AC4 12 7E 35         [24] 1157 	lcall	_ak820_outline_0119
      007AC7 EC               [12] 1158 	mov	a,r4
      007AC8 60 04            [24] 1159 	jz	00104$
      007ACA 75 82 00         [24] 1160 	mov	dpl, #0x00
      007ACD 22               [24] 1161 	ret
      007ACE                       1162 00104$:
                                   1163 ;	quantum/action_util.c:106: ++distinct_keys;
      007ACE 90 0A 31         [24] 1164 	mov	dptr,#_distinct_keys
      007AD1 E0               [24] 1165 	movx	a,@dptr
      007AD2 24 01            [12] 1166 	add	a, #0x01
      007AD4 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007AD5 90 0D A9         [24] 1169 	mov	dptr,#_keyboard_protocol
      007AD8 E0               [24] 1170 	movx	a,@dptr
      007AD9 60 15            [24] 1171 	jz	00106$
      007ADB 90 0A B6         [24] 1172 	mov	dptr,#_keymap_config
      007ADE E0               [24] 1173 	movx	a,@dptr
      007ADF 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007AE2 90 07 F7         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007AE5 EF               [12] 1177 	mov	a,r7
      007AE6 12 7E 06         [24] 1178 	lcall	_ak820_outline_0059
      007AE9 12 6C FD         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:108: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007AEC 75 82 01         [24] 1181 	mov	dpl, #0x01
      007AEF 22               [24] 1182 	ret
      007AF0                       1183 00106$:
                                   1184 ;	quantum/action_util.c:110: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007AF0 90 0A 31         [24] 1185 	mov	dptr,#_distinct_keys
      007AF3 E0               [24] 1186 	movx	a,@dptr
      007AF4 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007AF6 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007AF8 7F 00            [12] 1191 	mov	r7,#0x00
      007AFA                       1192 00115$:
      007AFA BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007AFD                       1194 00174$:
      007AFD 50 1D            [24] 1195 	jnc	00111$
      007AFF EF               [12] 1196 	mov	a,r7
      007B00 24 BE            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007B02 F5 82            [12] 1198 	mov	dpl,a
      007B04 E4               [12] 1199 	clr	a
      007B05 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007B07 F5 83            [12] 1201 	mov	dph,a
      007B09 74 01            [12] 1202 	mov	a,#0x01
      007B0B F0               [24] 1203 	movx	@dptr,a
      007B0C 0F               [12] 1204 	inc	r7
      007B0D 80 EB            [24] 1205 	sjmp	00115$
      007B0F                       1206 00110$:
                                   1207 ;	quantum/action_util.c:112: } else add_key(code);
      007B0F 90 0A 47         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_326
      007B12 E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007B13 90 07 F7         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007B16 12 7E 06         [24] 1212 	lcall	_ak820_outline_0059
      007B19 12 6C FD         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:112: } else add_key(code);
      007B1C                       1215 00111$:
                                   1216 ;	quantum/action_util.c:113: return true;
      007B1C 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:114: }
      007B1F 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:115: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007B20                       1236 _del_owned_key:
      007B20 E5 82            [12] 1237 	mov	a,dpl
      007B22 90 0A 48         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_341
      007B25 12 7E 46         [24] 1239 	lcall	_ak820_outline_0129
                                   1240 ;	quantum/action_util.c:116: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007B28 E4               [12] 1241 	clr	a
      007B29 F0               [24] 1242 	movx	@dptr,a
      007B2A 90 0A 32         [24] 1243 	mov	dptr,#_macro_keys
      007B2D C0 07            [24] 1244 	push	ar7
      007B2F 12 78 C4         [24] 1245 	lcall	_ak820_macro_change
      007B32 E5 82            [12] 1246 	mov	a, dpl
      007B34 D0 07            [24] 1247 	pop	ar7
      007B36 70 03            [24] 1248 	jnz	00102$
      007B38 F5 82            [12] 1249 	mov	dpl,a
      007B3A 22               [24] 1250 	ret
      007B3B                       1251 00102$:
                                   1252 ;	quantum/action_util.c:117: if (!key_refs[code] || --key_refs[code]) return false;
      007B3B 12 7D F8         [24] 1253 	lcall	_ak820_outline_0029
      007B3E FC               [12] 1254 	mov	r4,a
      007B3F 60 09            [24] 1255 	jz	00103$
      007B41 1C               [12] 1256 	dec	r4
      007B42 12 38 9C         [24] 1257 	lcall	_ak820_outline_0130
      007B45 EC               [12] 1258 	mov	a,r4
      007B46 F0               [24] 1259 	movx	@dptr,a
      007B47 EC               [12] 1260 	mov	a,r4
      007B48 60 04            [24] 1261 	jz	00104$
      007B4A                       1262 00103$:
      007B4A 75 82 00         [24] 1263 	mov	dpl, #0x00
      007B4D 22               [24] 1264 	ret
      007B4E                       1265 00104$:
                                   1266 ;	quantum/action_util.c:118: --distinct_keys;
      007B4E 90 0A 31         [24] 1267 	mov	dptr,#_distinct_keys
      007B51 E0               [24] 1268 	movx	a,@dptr
      007B52 14               [12] 1269 	dec	a
      007B53 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B54 90 0D A9         [24] 1272 	mov	dptr,#_keyboard_protocol
      007B57 E0               [24] 1273 	movx	a,@dptr
      007B58 60 15            [24] 1274 	jz	00107$
      007B5A 90 0A B6         [24] 1275 	mov	dptr,#_keymap_config
      007B5D E0               [24] 1276 	movx	a,@dptr
      007B5E 30 E7 0E         [24] 1277 	jnb	acc.7,00107$
                                   1278 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007B61 90 07 FB         [24] 1279 	mov	dptr,#_del_key_from_report_PARM_2
      007B64 EF               [12] 1280 	mov	a,r7
      007B65 12 7E 06         [24] 1281 	lcall	_ak820_outline_0059
      007B68 12 6D 3B         [24] 1282 	lcall	_del_key_from_report
                                   1283 ;	quantum/action_util.c:120: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007B6B 75 82 01         [24] 1284 	mov	dpl, #0x01
      007B6E 22               [24] 1285 	ret
      007B6F                       1286 00107$:
                                   1287 ;	quantum/action_util.c:122: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007B6F 90 0A 31         [24] 1288 	mov	dptr,#_distinct_keys
      007B72 E0               [24] 1289 	movx	a,@dptr
      007B73 FF               [12] 1290 	mov  r7,a
      007B74 24 F9            [12] 1291 	add	a,#0xff - 0x06
      007B76 50 04            [24] 1292 	jnc	00110$
                                   1293 ;	free result
      007B78 75 82 01         [24] 1294 	mov	dpl, #0x01
      007B7B 22               [24] 1295 	ret
      007B7C                       1296 00110$:
                                   1297 ;	quantum/action_util.c:123: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007B7C BF 06 26         [24] 1298 	cjne	r7,#0x06,00115$
                                   1299 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B7F 90 0D BC         [24] 1300 	mov	dptr,#_actual_keyboard_report
      007B82 75 F0 00         [24] 1301 	mov	b, #0x00
      007B85 12 6D 79         [24] 1302 	lcall	_clear_keys_from_report
                                   1303 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007B88 7F 04            [12] 1304 	mov	r7,#0x04
      007B8A                       1305 00122$:
      007B8A EF               [12] 1306 	mov	a,r7
      007B8B 24 5B            [12] 1307 	add	a,#0xff - 0xa4
      007B8D 40 23            [24] 1308 	jc	00116$
                                   1309 ;	free result
      007B8F 12 7D F8         [24] 1310 	lcall	_ak820_outline_0029
      007B92 60 0E            [24] 1311 	jz	00123$
                                   1312 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007B94 90 07 F7         [24] 1313 	mov	dptr,#_add_key_to_report_PARM_2
      007B97 EF               [12] 1314 	mov	a,r7
      007B98 12 7E 06         [24] 1315 	lcall	_ak820_outline_0059
      007B9B C0 07            [24] 1316 	push	ar7
      007B9D 12 6C FD         [24] 1317 	lcall	_add_key_to_report
      007BA0 D0 07            [24] 1318 	pop	ar7
                                   1319 ;	quantum/action_util.c:126: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007BA2                       1320 00123$:
      007BA2 0F               [12] 1321 	inc	r7
      007BA3 80 E5            [24] 1322 	sjmp	00122$
      007BA5                       1323 00115$:
                                   1324 ;	quantum/action_util.c:127: } else del_key(code);
      007BA5 90 0A 48         [24] 1325 	mov	dptr,#_del_owned_key_code_10000_341
      007BA8 E0               [24] 1326 	movx	a,@dptr
                                   1327 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007BA9 90 07 FB         [24] 1328 	mov	dptr,#_del_key_from_report_PARM_2
      007BAC 12 7E 06         [24] 1329 	lcall	_ak820_outline_0059
      007BAF 12 6D 3B         [24] 1330 	lcall	_del_key_from_report
                                   1331 ;	quantum/action_util.c:127: } else del_key(code);
      007BB2                       1332 00116$:
                                   1333 ;	quantum/action_util.c:128: return true;
      007BB2 75 82 01         [24] 1334 	mov	dpl, #0x01
                                   1335 ;	quantum/action_util.c:129: }
      007BB5 22               [24] 1336 	ret
                                   1337 ;------------------------------------------------------------
                                   1338 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1339 ;------------------------------------------------------------
                                   1340 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1341 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1342 ;------------------------------------------------------------
                                   1343 ;	quantum/action_util.c:139: void clear_owned_usages(void) {
                                   1344 ;	-----------------------------------------
                                   1345 ;	 function clear_owned_usages
                                   1346 ;	-----------------------------------------
      007BB6                       1347 _clear_owned_usages:
                                   1348 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007BB6 7F 00            [12] 1349 	mov	r7,#0x00
      007BB8                       1350 00104$:
      007BB8 BF 1E 00         [24] 1351 	cjne	r7,#0x1e,00141$
      007BBB                       1352 00141$:
      007BBB 50 14            [24] 1353 	jnc	00101$
      007BBD EF               [12] 1354 	mov	a,r7
      007BBE 24 49            [12] 1355 	add	a, #_usage_refs
      007BC0 FD               [12] 1356 	mov	r5,a
      007BC1 E4               [12] 1357 	clr	a
      007BC2 34 0A            [12] 1358 	addc	a, #(_usage_refs >> 8)
      007BC4 FE               [12] 1359 	mov	r6,a
      007BC5 EF               [12] 1360 	mov	a,r7
      007BC6 12 7E 15         [24] 1361 	lcall	_ak820_outline_0067
      007BC9 E4               [12] 1362 	clr	a
      007BCA F0               [24] 1363 	movx	@dptr,a
      007BCB 12 7E 35         [24] 1364 	lcall	_ak820_outline_0119
      007BCE 0F               [12] 1365 	inc	r7
      007BCF 80 E7            [24] 1366 	sjmp	00104$
      007BD1                       1367 00101$:
                                   1368 ;	quantum/action_util.c:141: usage_lengths[0] = usage_lengths[1] = 0;
      007BD1 90 0A 86         [24] 1369 	mov	dptr,#(_usage_lengths + 0x0001)
      007BD4 E4               [12] 1370 	clr	a
      007BD5 F0               [24] 1371 	movx	@dptr,a
      007BD6 90 0A 85         [24] 1372 	mov	dptr,#_usage_lengths
      007BD9 F0               [24] 1373 	movx	@dptr,a
                                   1374 ;	quantum/action_util.c:142: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007BDA FF               [12] 1375 	mov	r7,a
      007BDB                       1376 00107$:
      007BDB BF 04 00         [24] 1377 	cjne	r7,#0x04,00143$
      007BDE                       1378 00143$:
      007BDE 50 0D            [24] 1379 	jnc	00109$
      007BE0 EF               [12] 1380 	mov	a,r7
      007BE1 24 87            [12] 1381 	add	a, #_macro_usages
      007BE3 F5 82            [12] 1382 	mov	dpl,a
      007BE5 E4               [12] 1383 	clr	a
      007BE6 34 0A            [12] 1384 	addc	a, #(_macro_usages >> 8)
      007BE8 12 78 B5         [24] 1385 	lcall	_ak820_outline_0159
      007BEB 80 EE            [24] 1386 	sjmp	00107$
      007BED                       1387 00109$:
                                   1388 ;	quantum/action_util.c:143: }
      007BED 22               [24] 1389 	ret
                                   1390 ;------------------------------------------------------------
                                   1391 ;Allocation info for local variables in function 'owned_usage_key'
                                   1392 ;------------------------------------------------------------
                                   1393 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1394 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1395 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1396 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1397 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1398 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1399 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1400 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1401 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1402 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1403 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1404 ;------------------------------------------------------------
                                   1405 ;	quantum/action_util.c:144: void owned_usage_key(uint8_t code, bool pressed) {
                                   1406 ;	-----------------------------------------
                                   1407 ;	 function owned_usage_key
                                   1408 ;	-----------------------------------------
      007BEE                       1409 _owned_usage_key:
      007BEE E5 82            [12] 1410 	mov	a,dpl
      007BF0 90 0A 8C         [24] 1411 	mov	dptr,#_owned_usage_key_code_10000_368
      007BF3 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/action_util.c:145: uint8_t which = code >= KC_AUDIO_MUTE;
      007BF4 E0               [24] 1414 	movx	a,@dptr
      007BF5 FF               [12] 1415 	mov	r7,a
      007BF6 BF A8 00         [24] 1416 	cjne	r7,#0xa8,00244$
      007BF9                       1417 00244$:
      007BF9 B3               [12] 1418 	cpl	c
      007BFA 92 22            [24] 1419 	mov	_owned_usage_key_sloc0_1_0,c
      007BFC E4               [12] 1420 	clr	a
      007BFD 33               [12] 1421 	rlc	a
      007BFE FF               [12] 1422 	mov	r7,a
      007BFF 90 0A 8F         [24] 1423 	mov	dptr,#_owned_usage_key_which_10000_369
      007C02 F0               [24] 1424 	movx	@dptr,a
                                   1425 ;	quantum/action_util.c:146: uint8_t base = which ? SYSTEM_COUNT : 0;
      007C03 EF               [12] 1426 	mov	a,r7
      007C04 60 02            [24] 1427 	jz	00129$
      007C06 74 03            [12] 1428 	mov	a,#0x03
      007C08                       1429 00129$:
      007C08 FE               [12] 1430 	mov	r6,a
                                   1431 ;	quantum/action_util.c:147: uint8_t count = usage_lengths[which];
      007C09 EF               [12] 1432 	mov	a,r7
      007C0A 24 85            [12] 1433 	add	a, #_usage_lengths
      007C0C FD               [12] 1434 	mov	r5,a
      007C0D E4               [12] 1435 	clr	a
      007C0E 34 0A            [12] 1436 	addc	a, #(_usage_lengths >> 8)
      007C10 FF               [12] 1437 	mov	r7,a
      007C11 12 7E 51         [24] 1438 	lcall	_ak820_outline_0183
      007C14 E0               [24] 1439 	movx	a,@dptr
      007C15 FC               [12] 1440 	mov	r4,a
                                   1441 ;	quantum/action_util.c:148: uint8_t index = code - KC_SYSTEM_POWER;
      007C16 90 0A 8C         [24] 1442 	mov	dptr,#_owned_usage_key_code_10000_368
      007C19 E0               [24] 1443 	movx	a,@dptr
      007C1A 24 5B            [12] 1444 	add	a,#0x5b
      007C1C FB               [12] 1445 	mov	r3,a
                                   1446 ;	quantum/action_util.c:149: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007C1D 90 0A 8B         [24] 1447 	mov	dptr,#_owned_usage_key_PARM_2
      007C20 E0               [24] 1448 	movx	a,@dptr
      007C21 FA               [12] 1449 	mov	r2,a
      007C22 90 09 80         [24] 1450 	mov	dptr,#_ak820_macro_change_PARM_2
      007C25 EB               [12] 1451 	mov	a,r3
      007C26 F0               [24] 1452 	movx	@dptr,a
      007C27 90 09 81         [24] 1453 	mov	dptr,#_ak820_macro_change_PARM_3
      007C2A EA               [12] 1454 	mov	a,r2
      007C2B F0               [24] 1455 	movx	@dptr,a
      007C2C 90 0A 87         [24] 1456 	mov	dptr,#_macro_usages
      007C2F C0 07            [24] 1457 	push	ar7
      007C31 C0 06            [24] 1458 	push	ar6
      007C33 C0 05            [24] 1459 	push	ar5
      007C35 C0 04            [24] 1460 	push	ar4
      007C37 C0 03            [24] 1461 	push	ar3
      007C39 C0 02            [24] 1462 	push	ar2
      007C3B 12 78 C4         [24] 1463 	lcall	_ak820_macro_change
      007C3E E5 82            [12] 1464 	mov	a, dpl
      007C40 D0 02            [24] 1465 	pop	ar2
      007C42 D0 03            [24] 1466 	pop	ar3
      007C44 D0 04            [24] 1467 	pop	ar4
      007C46 D0 05            [24] 1468 	pop	ar5
      007C48 D0 06            [24] 1469 	pop	ar6
      007C4A D0 07            [24] 1470 	pop	ar7
      007C4C 70 01            [24] 1471 	jnz	00102$
      007C4E 22               [24] 1472 	ret
      007C4F                       1473 00102$:
                                   1474 ;	quantum/action_util.c:150: if (pressed) {
      007C4F EA               [12] 1475 	mov	a,r2
      007C50 60 1B            [24] 1476 	jz	00115$
                                   1477 ;	quantum/action_util.c:151: if (usage_refs[index]++) return;
      007C52 12 7E 1F         [24] 1478 	lcall	_ak820_outline_0074
      007C55 04               [12] 1479 	inc	a
      007C56 12 6A 7C         [24] 1480 	lcall	_ak820_outline_0135
      007C59 E8               [12] 1481 	mov	a,r0
      007C5A 60 01            [24] 1482 	jz	00104$
      007C5C 22               [24] 1483 	ret
      007C5D                       1484 00104$:
                                   1485 ;	quantum/action_util.c:152: usage_order[base + count++] = index;
      007C5D 90 0A 90         [24] 1486 	mov	dptr,#_owned_usage_key_count_10000_369
      007C60 EC               [12] 1487 	mov	a,r4
      007C61 04               [12] 1488 	inc	a
      007C62 F0               [24] 1489 	movx	@dptr,a
      007C63 EC               [12] 1490 	mov	a,r4
      007C64 2E               [12] 1491 	add	a, r6
      007C65 12 7E 15         [24] 1492 	lcall	_ak820_outline_0067
      007C68 EB               [12] 1493 	mov	a,r3
      007C69 F0               [24] 1494 	movx	@dptr,a
      007C6A 02 7C CE         [24] 1495 	ljmp	00116$
      007C6D                       1496 00115$:
                                   1497 ;	quantum/action_util.c:154: if (!usage_refs[index] || --usage_refs[index]) return;
      007C6D 12 7E 1F         [24] 1498 	lcall	_ak820_outline_0074
      007C70 60 07            [24] 1499 	jz	00105$
      007C72 18               [12] 1500 	dec	r0
      007C73 12 7E 0E         [24] 1501 	lcall	_ak820_outline_0064
      007C76 E8               [12] 1502 	mov	a,r0
      007C77 60 01            [24] 1503 	jz	00106$
      007C79                       1504 00105$:
      007C79 22               [24] 1505 	ret
      007C7A                       1506 00106$:
                                   1507 ;	quantum/action_util.c:156: while (usage_order[base + pos] != index) ++pos;
      007C7A 7A 00            [12] 1508 	mov	r2,#0x00
      007C7C                       1509 00108$:
      007C7C EA               [12] 1510 	mov	a,r2
      007C7D 2E               [12] 1511 	add	a, r6
      007C7E 12 7E 15         [24] 1512 	lcall	_ak820_outline_0067
      007C81 E0               [24] 1513 	movx	a,@dptr
      007C82 B5 03 02         [24] 1514 	cjne	a,ar3,00251$
      007C85 80 03            [24] 1515 	sjmp	00167$
      007C87                       1516 00251$:
      007C87 0A               [12] 1517 	inc	r2
      007C88 80 F2            [24] 1518 	sjmp	00108$
      007C8A                       1519 00167$:
      007C8A 90 0A 91         [24] 1520 	mov	dptr,#_owned_usage_key_pos_30001_376
      007C8D EA               [12] 1521 	mov	a,r2
      007C8E F0               [24] 1522 	movx	@dptr,a
                                   1523 ;	quantum/action_util.c:157: --count;
      007C8F 1C               [12] 1524 	dec	r4
      007C90 90 0A 90         [24] 1525 	mov	dptr,#_owned_usage_key_count_10000_369
      007C93 EC               [12] 1526 	mov	a,r4
      007C94 F0               [24] 1527 	movx	@dptr,a
                                   1528 ;	quantum/action_util.c:158: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007C95 8A 03            [24] 1529 	mov	ar3,r2
      007C97                       1530 00125$:
      007C97 C3               [12] 1531 	clr	c
      007C98 EB               [12] 1532 	mov	a,r3
      007C99 9C               [12] 1533 	subb	a,r4
      007C9A 50 23            [24] 1534 	jnc	00111$
      007C9C C0 05            [24] 1535 	push	ar5
      007C9E C0 07            [24] 1536 	push	ar7
      007CA0 EB               [12] 1537 	mov	a,r3
      007CA1 2E               [12] 1538 	add	a, r6
      007CA2 FA               [12] 1539 	mov	r2,a
      007CA3 24 67            [12] 1540 	add	a, #_usage_order
      007CA5 F8               [12] 1541 	mov	r0,a
      007CA6 E4               [12] 1542 	clr	a
      007CA7 34 0A            [12] 1543 	addc	a, #(_usage_order >> 8)
      007CA9 F9               [12] 1544 	mov	r1,a
      007CAA 0A               [12] 1545 	inc	r2
      007CAB EA               [12] 1546 	mov	a,r2
      007CAC 33               [12] 1547 	rlc	a
      007CAD 95 E0            [12] 1548 	subb	a,acc
      007CAF FF               [12] 1549 	mov	r7,a
      007CB0 EA               [12] 1550 	mov	a,r2
      007CB1 12 7E 3B         [24] 1551 	lcall	_ak820_outline_0123
      007CB4 12 38 B1         [24] 1552 	lcall	_ak820_outline_0153
      007CB7 F0               [24] 1553 	movx	@dptr,a
      007CB8 0B               [12] 1554 	inc	r3
      007CB9 D0 07            [24] 1555 	pop	ar7
      007CBB D0 05            [24] 1556 	pop	ar5
      007CBD 80 D8            [24] 1557 	sjmp	00125$
      007CBF                       1558 00111$:
                                   1559 ;	quantum/action_util.c:159: usage_lengths[which] = count;
      007CBF 12 7E 51         [24] 1560 	lcall	_ak820_outline_0183
      007CC2 EC               [12] 1561 	mov	a,r4
      007CC3 F0               [24] 1562 	movx	@dptr,a
                                   1563 ;	quantum/action_util.c:160: if (pos != count) return; /* A non-winning owner changed only storage. */
      007CC4 90 0A 91         [24] 1564 	mov	dptr,#_owned_usage_key_pos_30001_376
      007CC7 E0               [24] 1565 	movx	a,@dptr
      007CC8 B5 04 02         [24] 1566 	cjne	a,ar4,00253$
      007CCB 80 01            [24] 1567 	sjmp	00116$
      007CCD                       1568 00253$:
      007CCD 22               [24] 1569 	ret
      007CCE                       1570 00116$:
                                   1571 ;	quantum/action_util.c:162: usage_lengths[which] = count;
      007CCE 90 0A 90         [24] 1572 	mov	dptr,#_owned_usage_key_count_10000_369
      007CD1 E0               [24] 1573 	movx	a,@dptr
      007CD2 FC               [12] 1574 	mov	r4,a
      007CD3 12 7E 51         [24] 1575 	lcall	_ak820_outline_0183
      007CD6 F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/action_util.c:163: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007CD7 EC               [12] 1578 	mov	a,r4
      007CD8 60 15            [24] 1579 	jz	00131$
      007CDA EC               [12] 1580 	mov	a,r4
      007CDB 2E               [12] 1581 	add	a, r6
      007CDC FE               [12] 1582 	mov	r6,a
      007CDD 1E               [12] 1583 	dec	r6
      007CDE EE               [12] 1584 	mov	a,r6
      007CDF 33               [12] 1585 	rlc	a
      007CE0 95 E0            [12] 1586 	subb	a,acc
      007CE2 FF               [12] 1587 	mov	r7,a
      007CE3 EE               [12] 1588 	mov	a,r6
      007CE4 12 7E 3B         [24] 1589 	lcall	_ak820_outline_0123
      007CE7 24 A5            [12] 1590 	add	a,#0xa5
      007CE9 FE               [12] 1591 	mov	r6,a
      007CEA 33               [12] 1592 	rlc	a
      007CEB 95 E0            [12] 1593 	subb	a,acc
      007CED 80 02            [24] 1594 	sjmp	00132$
      007CEF                       1595 00131$:
      007CEF 7E 00            [12] 1596 	mov	r6,#0x00
      007CF1                       1597 00132$:
      007CF1 90 0A 8C         [24] 1598 	mov	dptr,#_owned_usage_key_code_10000_368
      007CF4 EE               [12] 1599 	mov	a,r6
      007CF5 F0               [24] 1600 	movx	@dptr,a
                                   1601 ;	quantum/action_util.c:164: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007CF6 90 0A 8F         [24] 1602 	mov	dptr,#_owned_usage_key_which_10000_369
      007CF9 E0               [24] 1603 	movx	a,@dptr
      007CFA 60 18            [24] 1604 	jz	00118$
      007CFC EE               [12] 1605 	mov	a,r6
      007CFD 60 0B            [24] 1606 	jz	00133$
      007CFF 8E 82            [24] 1607 	mov	dpl, r6
      007D01 12 6B BC         [24] 1608 	lcall	_KEYCODE2CONSUMER
      007D04 AD 82            [24] 1609 	mov	r5, dpl
      007D06 AF 83            [24] 1610 	mov	r7, dph
      007D08 80 04            [24] 1611 	sjmp	00134$
      007D0A                       1612 00133$:
      007D0A 7D 00            [12] 1613 	mov	r5,#0x00
      007D0C 7F 00            [12] 1614 	mov	r7,#0x00
      007D0E                       1615 00134$:
      007D0E 12 7E 51         [24] 1616 	lcall	_ak820_outline_0183
      007D11 02 6B 6F         [24] 1617 	ljmp	_host_consumer_send
      007D14                       1618 00118$:
                                   1619 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007D14 EE               [12] 1620 	mov	a,r6
      007D15 60 22            [24] 1621 	jz	00135$
                                   1622 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007D17 BE A5 00         [24] 1623 	cjne	r6,#0xa5,00258$
      007D1A                       1624 00258$:
      007D1A 40 05            [24] 1625 	jc	00121$
      007D1C EE               [12] 1626 	mov	a,r6
      007D1D 24 58            [12] 1627 	add	a,#0xff - 0xa7
      007D1F 50 08            [24] 1628 	jnc	00122$
                                   1629 ;	free result
      007D21                       1630 00121$:
      007D21 90 0A 8D         [24] 1631 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D24 12 4D 73         [24] 1632 	lcall	_ak820_outline_0166
      007D27 80 09            [24] 1633 	sjmp	00123$
      007D29                       1634 00122$:
                                   1635 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007D29 74 DC            [12] 1636 	mov	a,#0xdc
      007D2B 2E               [12] 1637 	add	a, r6
      007D2C 90 0A 8D         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D2F 12 38 97         [24] 1639 	lcall	_ak820_outline_0122
                                   1640 ;	quantum/action_util.c:165: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007D32                       1641 00123$:
      007D32 90 0A 8D         [24] 1642 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007D35 E0               [24] 1643 	movx	a,@dptr
      007D36 FF               [12] 1644 	mov	r7,a
      007D37 80 02            [24] 1645 	sjmp	00136$
      007D39                       1646 00135$:
      007D39 7F 00            [12] 1647 	mov	r7,#0x00
      007D3B                       1648 00136$:
      007D3B 7E 00            [12] 1649 	mov	r6,#0x00
      007D3D 12 43 71         [24] 1650 	lcall	_ak820_outline_0154
                                   1651 ;	quantum/action_util.c:166: }
      007D40 02 6B 3F         [24] 1652 	ljmp	_host_system_send
                                   1653 ;------------------------------------------------------------
                                   1654 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1655 ;------------------------------------------------------------
                                   1656 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1657 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1658 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1659 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1660 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1661 ;------------------------------------------------------------
                                   1662 ;	quantum/action_util.c:388: void send_keyboard_report(void) {
                                   1663 ;	-----------------------------------------
                                   1664 ;	 function send_keyboard_report
                                   1665 ;	-----------------------------------------
      007D43                       1666 _send_keyboard_report:
                                   1667 ;	quantum/action_util.c:389: keyboard_report->mods = real_mods;
      007D43 90 0D BA         [24] 1668 	mov	dptr,#_real_mods
      007D46 E0               [24] 1669 	movx	a,@dptr
      007D47 FF               [12] 1670 	mov	r7,a
      007D48 90 0D BC         [24] 1671 	mov	dptr,#_actual_keyboard_report
      007D4B F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/action_util.c:390: keyboard_report->mods |= weak_mods;
      007D4C 90 0D BB         [24] 1674 	mov	dptr,#_weak_mods
      007D4F E0               [24] 1675 	movx	a,@dptr
      007D50 42 07            [12] 1676 	orl	ar7,a
      007D52 90 0D BC         [24] 1677 	mov	dptr,#_actual_keyboard_report
      007D55 EF               [12] 1678 	mov	a,r7
      007D56 F0               [24] 1679 	movx	@dptr,a
                                   1680 ;	quantum/action_util.c:392: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007D57 90 09 7B         [24] 1681 	mov	dptr,#_owned_weak_mods
      007D5A E0               [24] 1682 	movx	a,@dptr
      007D5B FE               [12] 1683 	mov	r6,a
      007D5C 90 09 7A         [24] 1684 	mov	dptr,#_owned_mods
      007D5F E0               [24] 1685 	movx	a,@dptr
      007D60 4E               [12] 1686 	orl	a,r6
      007D61 42 07            [12] 1687 	orl	ar7,a
      007D63 90 0D BC         [24] 1688 	mov	dptr,#_actual_keyboard_report
      007D66 EF               [12] 1689 	mov	a,r7
      007D67 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:427: bool changed = false;
      007D68 90 0A B3         [24] 1692 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D6B E4               [12] 1693 	clr	a
      007D6C F0               [24] 1694 	movx	@dptr,a
                                   1695 ;	quantum/action_util.c:429: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1696 ;	quantum/action_util.c:430: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1697 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D6D FF               [12] 1698 	mov	r7,a
      007D6E                       1699 00107$:
      007D6E BF 20 00         [24] 1700 	cjne	r7,#0x20,00140$
      007D71                       1701 00140$:
      007D71 50 2A            [24] 1702 	jnc	00103$
                                   1703 ;	quantum/action_util.c:436: if (dest[i] != src[i]) {
      007D73 EF               [12] 1704 	mov	a,r7
      007D74 24 93            [12] 1705 	add	a, #_send_keyboard_report_last_report_10001_388
      007D76 FD               [12] 1706 	mov	r5,a
      007D77 E4               [12] 1707 	clr	a
      007D78 34 0A            [12] 1708 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007D7A 12 46 D6         [24] 1709 	lcall	_ak820_outline_0058
      007D7D EF               [12] 1710 	mov	a,r7
      007D7E 24 BC            [12] 1711 	add	a, #_actual_keyboard_report
      007D80 F5 82            [12] 1712 	mov	dpl,a
      007D82 E4               [12] 1713 	clr	a
      007D83 34 0D            [12] 1714 	addc	a, #(_actual_keyboard_report >> 8)
      007D85 F5 83            [12] 1715 	mov	dph,a
      007D87 E0               [24] 1716 	movx	a,@dptr
      007D88 FB               [12] 1717 	mov	r3,a
      007D89 EC               [12] 1718 	mov	a,r4
      007D8A B5 03 02         [24] 1719 	cjne	a,ar3,00142$
      007D8D 80 0B            [24] 1720 	sjmp	00108$
      007D8F                       1721 00142$:
                                   1722 ;	quantum/action_util.c:437: dest[i] = src[i];
      007D8F 12 38 9C         [24] 1723 	lcall	_ak820_outline_0130
      007D92 EB               [12] 1724 	mov	a,r3
      007D93 F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action_util.c:438: changed = true;
      007D94 90 0A B3         [24] 1727 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007D97 74 01            [12] 1728 	mov	a,#0x01
      007D99 F0               [24] 1729 	movx	@dptr,a
      007D9A                       1730 00108$:
                                   1731 ;	quantum/action_util.c:435: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007D9A 0F               [12] 1732 	inc	r7
      007D9B 80 D1            [24] 1733 	sjmp	00107$
      007D9D                       1734 00103$:
                                   1735 ;	quantum/action_util.c:441: if (changed) host_keyboard_send(keyboard_report);
      007D9D 90 0A B3         [24] 1736 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007DA0 E0               [24] 1737 	movx	a,@dptr
      007DA1 60 09            [24] 1738 	jz	00109$
      007DA3 90 0D BC         [24] 1739 	mov	dptr,#_actual_keyboard_report
      007DA6 75 F0 00         [24] 1740 	mov	b, #0x00
                                   1741 ;	quantum/action_util.c:449: }
      007DA9 02 6A B4         [24] 1742 	ljmp	_host_keyboard_send
      007DAC                       1743 00109$:
      007DAC 22               [24] 1744 	ret
                                   1745 ;------------------------------------------------------------
                                   1746 ;Allocation info for local variables in function 'get_mods'
                                   1747 ;------------------------------------------------------------
                                   1748 ;	quantum/action_util.c:455: uint8_t get_mods(void) {
                                   1749 ;	-----------------------------------------
                                   1750 ;	 function get_mods
                                   1751 ;	-----------------------------------------
      007DAD                       1752 _get_mods:
      007DAD C0 07            [24] 1753 	push	ar7
                                   1754 ;	quantum/action_util.c:460: ;
      007DAF 90 09 7A         [24] 1755 	mov	dptr,#_owned_mods
      007DB2 E0               [24] 1756 	movx	a,@dptr
      007DB3 FF               [12] 1757 	mov	r7,a
      007DB4 90 0D BA         [24] 1758 	mov	dptr,#_real_mods
      007DB7 12 78 AF         [24] 1759 	lcall	_ak820_outline_0137
                                   1760 ;	quantum/action_util.c:461: }
      007DBA D0 07            [24] 1761 	pop	ar7
      007DBC 22               [24] 1762 	ret
                                   1763 ;------------------------------------------------------------
                                   1764 ;Allocation info for local variables in function 'add_mods'
                                   1765 ;------------------------------------------------------------
                                   1766 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1767 ;------------------------------------------------------------
                                   1768 ;	quantum/action_util.c:466: void add_mods(uint8_t mods) {
                                   1769 ;	-----------------------------------------
                                   1770 ;	 function clear_mods
                                   1771 ;	-----------------------------------------
      007DBD                       1772 _clear_mods:
                                   1773 ;	quantum/action_util.c:488: real_mods = 0;
      007DBD 90 0D BA         [24] 1774 	mov	dptr,#_real_mods
      007DC0 E4               [12] 1775 	clr	a
      007DC1 F0               [24] 1776 	movx	@dptr,a
                                   1777 ;	quantum/action_util.c:489: }
      007DC2 22               [24] 1778 	ret
                                   1779 ;------------------------------------------------------------
                                   1780 ;Allocation info for local variables in function 'get_weak_mods'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/action_util.c:495: uint8_t get_weak_mods(void) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function get_weak_mods
                                   1785 ;	-----------------------------------------
      007DC3                       1786 _get_weak_mods:
      007DC3 C0 07            [24] 1787 	push	ar7
                                   1788 ;	quantum/action_util.c:500: ;
      007DC5 90 09 7B         [24] 1789 	mov	dptr,#_owned_weak_mods
      007DC8 E0               [24] 1790 	movx	a,@dptr
      007DC9 FF               [12] 1791 	mov	r7,a
      007DCA 90 0D BB         [24] 1792 	mov	dptr,#_weak_mods
      007DCD 12 78 AF         [24] 1793 	lcall	_ak820_outline_0137
                                   1794 ;	quantum/action_util.c:501: }
      007DD0 D0 07            [24] 1795 	pop	ar7
      007DD2 22               [24] 1796 	ret
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'add_weak_mods'
                                   1799 ;------------------------------------------------------------
                                   1800 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1801 ;------------------------------------------------------------
                                   1802 ;	quantum/action_util.c:506: void add_weak_mods(uint8_t mods) {
                                   1803 ;	-----------------------------------------
                                   1804 ;	 function add_weak_mods
                                   1805 ;	-----------------------------------------
      007DD3                       1806 _add_weak_mods:
      007DD3 E5 82            [12] 1807 	mov	a,dpl
      007DD5 90 0A B4         [24] 1808 	mov	dptr,#_add_weak_mods_mods_10000_406
      007DD8 F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action_util.c:507: weak_mods |= mods;
      007DD9 E0               [24] 1811 	movx	a,@dptr
      007DDA FF               [12] 1812 	mov	r7,a
      007DDB 90 0D BB         [24] 1813 	mov	dptr,#_weak_mods
      007DDE E0               [24] 1814 	movx	a,@dptr
      007DDF 4F               [12] 1815 	orl	a,r7
      007DE0 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action_util.c:508: }
      007DE1 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'del_weak_mods'
                                   1821 ;------------------------------------------------------------
                                   1822 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1823 ;------------------------------------------------------------
                                   1824 ;	quantum/action_util.c:513: void del_weak_mods(uint8_t mods) {
                                   1825 ;	-----------------------------------------
                                   1826 ;	 function del_weak_mods
                                   1827 ;	-----------------------------------------
      007DE2                       1828 _del_weak_mods:
      007DE2 E5 82            [12] 1829 	mov	a,dpl
      007DE4 90 0A B5         [24] 1830 	mov	dptr,#_del_weak_mods_mods_10000_408
      007DE7 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	quantum/action_util.c:514: weak_mods &= ~mods;
      007DE8 E0               [24] 1833 	movx	a,@dptr
      007DE9 F4               [12] 1834 	cpl	a
      007DEA FF               [12] 1835 	mov	r7,a
      007DEB 90 0D BB         [24] 1836 	mov	dptr,#_weak_mods
      007DEE E0               [24] 1837 	movx	a,@dptr
      007DEF 5F               [12] 1838 	anl	a,r7
      007DF0 F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	quantum/action_util.c:515: }
      007DF1 22               [24] 1841 	ret
                                   1842 ;------------------------------------------------------------
                                   1843 ;Allocation info for local variables in function 'set_weak_mods'
                                   1844 ;------------------------------------------------------------
                                   1845 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1846 ;------------------------------------------------------------
                                   1847 ;	quantum/action_util.c:520: void set_weak_mods(uint8_t mods) {
                                   1848 ;	-----------------------------------------
                                   1849 ;	 function clear_weak_mods
                                   1850 ;	-----------------------------------------
      007DF2                       1851 _clear_weak_mods:
                                   1852 ;	quantum/action_util.c:528: weak_mods = 0;
      007DF2 90 0D BB         [24] 1853 	mov	dptr,#_weak_mods
      007DF5 E4               [12] 1854 	clr	a
      007DF6 F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/action_util.c:529: }
      007DF7 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action_util.c:611: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1864 ;	-----------------------------------------
                                   1865 	.area CSEG    (CODE)
                                   1866 	.area CONST   (CODE)
                                   1867 	.area XINIT   (CODE)
      00BE28                       1868 __xinit__real_mods:
      00BE28 00                    1869 	.db #0x00	; 0
      00BE29                       1870 __xinit__weak_mods:
      00BE29 00                    1871 	.db #0x00	; 0
      00BE2A                       1872 __xinit__actual_keyboard_report:
      00BE2A 00                    1873 	.db #0x00	; 0
      00BE2B 00                    1874 	.db #0x00	; 0
      00BE2C 00                    1875 	.db #0x00	; 0
      00BE2D 00                    1876 	.db #0x00	; 0
      00BE2E 00                    1877 	.db #0x00	; 0
      00BE2F 00                    1878 	.db #0x00	; 0
      00BE30 00                    1879 	.db #0x00	; 0
      00BE31 00                    1880 	.db #0x00	; 0
      00BE32 00                    1881 	.db 0x00
      00BE33 00                    1882 	.db 0x00
      00BE34 00                    1883 	.db 0x00
      00BE35 00                    1884 	.db 0x00
      00BE36 00                    1885 	.db 0x00
      00BE37 00                    1886 	.db 0x00
      00BE38 00                    1887 	.db 0x00
      00BE39 00                    1888 	.db 0x00
      00BE3A 00                    1889 	.db 0x00
      00BE3B 00                    1890 	.db 0x00
      00BE3C 00                    1891 	.db 0x00
      00BE3D 00                    1892 	.db 0x00
      00BE3E 00                    1893 	.db 0x00
      00BE3F 00                    1894 	.db 0x00
      00BE40 00                    1895 	.db 0x00
      00BE41 00                    1896 	.db 0x00
      00BE42 00                    1897 	.db 0x00
      00BE43 00                    1898 	.db 0x00
      00BE44 00                    1899 	.db 0x00
      00BE45 00                    1900 	.db 0x00
      00BE46 00                    1901 	.db 0x00
      00BE47 00                    1902 	.db 0x00
      00BE48 00                    1903 	.db 0x00
      00BE49 00                    1904 	.db 0x00
                                   1905 	.area CABS    (ABS,CODE)
                                   1906 
                                   1907 ; Experimental exact instruction outlining.
                                   1908 	.globl _ak820_outline_0015
                                   1909 	.globl _ak820_outline_0029
                                   1910 	.globl _ak820_outline_0056
                                   1911 	.globl _ak820_outline_0058
                                   1912 	.globl _ak820_outline_0059
                                   1913 	.globl _ak820_outline_0060
                                   1914 	.globl _ak820_outline_0063
                                   1915 	.globl _ak820_outline_0064
                                   1916 	.globl _ak820_outline_0067
                                   1917 	.globl _ak820_outline_0074
                                   1918 	.globl _ak820_outline_0105
                                   1919 	.globl _ak820_outline_0112
                                   1920 	.globl _ak820_outline_0113
                                   1921 	.globl _ak820_outline_0119
                                   1922 	.globl _ak820_outline_0120
                                   1923 	.globl _ak820_outline_0122
                                   1924 	.globl _ak820_outline_0123
                                   1925 	.globl _ak820_outline_0129
                                   1926 	.globl _ak820_outline_0130
                                   1927 	.globl _ak820_outline_0135
                                   1928 	.globl _ak820_outline_0137
                                   1929 	.globl _ak820_outline_0153
                                   1930 	.globl _ak820_outline_0154
                                   1931 	.globl _ak820_outline_0159
                                   1932 	.globl _ak820_outline_0166
                                   1933 	.globl _ak820_outline_0182
                                   1934 	.globl _ak820_outline_0183
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0029
      007DF8                       1938 _ak820_outline_0029:
      007DF8 EF               [12] 1939 	mov	a,r7
      007DF9 24 8C            [12] 1940 	add	a,#_key_refs
      007DFB FD               [12] 1941 	mov	r5,a
      007DFC E4               [12] 1942 	clr	a
      007DFD 34 09            [12] 1943 	addc	a,#(_key_refs>>8)
      007DFF FE               [12] 1944 	mov	r6,a
      007E00 8D 82            [24] 1945 	mov	dpl,r5
      007E02 8E 83            [24] 1946 	mov	dph,r6
      007E04 E0               [24] 1947 	movx	a,@dptr
      007E05 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0059
      007E06                       1952 _ak820_outline_0059:
      007E06 F0               [24] 1953 	movx	@dptr,a
      007E07 90 0D BC         [24] 1954 	mov	dptr,#_actual_keyboard_report
      007E0A 75 F0 00         [24] 1955 	mov	b,#0x00
      007E0D 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0064
      007E0E                       1960 _ak820_outline_0064:
      007E0E 89 82            [24] 1961 	mov	dpl,r1
      007E10 8A 83            [24] 1962 	mov	dph,r2
      007E12 E8               [12] 1963 	mov	a,r0
      007E13 F0               [24] 1964 	movx	@dptr,a
      007E14 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0067
      007E15                       1969 _ak820_outline_0067:
      007E15 24 67            [12] 1970 	add	a,#_usage_order
      007E17 F5 82            [12] 1971 	mov	dpl,a
      007E19 E4               [12] 1972 	clr	a
      007E1A 34 0A            [12] 1973 	addc	a,#(_usage_order>>8)
      007E1C F5 83            [12] 1974 	mov	dph,a
      007E1E 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0074
      007E1F                       1979 _ak820_outline_0074:
      007E1F EB               [12] 1980 	mov	a,r3
      007E20 24 49            [12] 1981 	add	a,#_usage_refs
      007E22 F9               [12] 1982 	mov	r1,a
      007E23 E4               [12] 1983 	clr	a
      007E24 34 0A            [12] 1984 	addc	a,#(_usage_refs>>8)
      007E26 FA               [12] 1985 	mov	r2,a
      007E27 89 82            [24] 1986 	mov	dpl,r1
      007E29 8A 83            [24] 1987 	mov	dph,r2
      007E2B E0               [24] 1988 	movx	a,@dptr
      007E2C F8               [12] 1989 	mov	r0,a
      007E2D 22               [24] 1990 	ret
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0112
      007E2E                       1994 _ak820_outline_0112:
      007E2E F0               [24] 1995 	movx	@dptr,a
      007E2F E0               [24] 1996 	movx	a,@dptr
      007E30 FF               [12] 1997 	mov	r7,a
      007E31 90 09 84         [24] 1998 	mov	dptr,#_change_owned_PARM_2
      007E34 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0119
      007E35                       2003 _ak820_outline_0119:
      007E35 8D 82            [24] 2004 	mov	dpl,r5
      007E37 8E 83            [24] 2005 	mov	dph,r6
      007E39 F0               [24] 2006 	movx	@dptr,a
      007E3A 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0123
      007E3B                       2011 _ak820_outline_0123:
      007E3B 24 67            [12] 2012 	add	a,#_usage_order
      007E3D F5 82            [12] 2013 	mov	dpl,a
      007E3F EF               [12] 2014 	mov	a,r7
      007E40 34 0A            [12] 2015 	addc	a,#(_usage_order>>8)
      007E42 F5 83            [12] 2016 	mov	dph,a
      007E44 E0               [24] 2017 	movx	a,@dptr
      007E45 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0129
      007E46                       2022 _ak820_outline_0129:
      007E46 F0               [24] 2023 	movx	@dptr,a
      007E47 E0               [24] 2024 	movx	a,@dptr
      007E48 FF               [12] 2025 	mov	r7,a
      007E49 90 09 80         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_2
      007E4C F0               [24] 2027 	movx	@dptr,a
      007E4D 90 09 81         [24] 2028 	mov	dptr,#_ak820_macro_change_PARM_3
      007E50 22               [24] 2029 	ret
                                   2030 
                                   2031 	.area CSEG (CODE)
                                   2032 ; function ak820_outline_0183
      007E51                       2033 _ak820_outline_0183:
      007E51 8D 82            [24] 2034 	mov	dpl,r5
      007E53 8F 83            [24] 2035 	mov	dph,r7
      007E55 22               [24] 2036 	ret
