                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_keyboard_blocked
                                    286 	.globl _ak820_usb_take_keyboard_reset
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
      000016                        549 _control_setup_sloc1_1_0:
      000016                        550 	.ds 1
      000017                        551 _control_setup_sloc3_1_0:
      000017                        552 	.ds 2
      000019                        553 _control_setup_sloc4_1_0:
      000019                        554 	.ds 2
      00001B                        555 _ak820_usb_send_sloc0_1_0:
      00001B                        556 	.ds 2
      00001D                        557 _ak820_usb_send_sloc1_1_0:
      00001D                        558 	.ds 1
      00001E                        559 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        560 	.ds 2
                                    561 ;--------------------------------------------------------
                                    562 ; overlayable items in internal ram
                                    563 ;--------------------------------------------------------
                                    564 ;--------------------------------------------------------
                                    565 ; indirectly addressable internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area ISEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; absolute internal ram data
                                    570 ;--------------------------------------------------------
                                    571 	.area IABS    (ABS,DATA)
                                    572 	.area IABS    (ABS,DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; bit data
                                    575 ;--------------------------------------------------------
                                    576 	.area BSEG    (BIT)
      000017                        577 _control_setup_valid_interface_10000_287:
      000017                        578 	.ds 1
      000018                        579 _control_setup_zero_index_10000_287:
      000018                        580 	.ds 1
      000019                        581 _control_setup_zero_value_10000_287:
      000019                        582 	.ds 1
      00001A                        583 _control_setup_zero_length_10000_287:
      00001A                        584 	.ds 1
      00001B                        585 _control_setup_sloc0_1_0:
      00001B                        586 	.ds 1
      00001C                        587 _control_setup_sloc2_1_0:
      00001C                        588 	.ds 1
      00001D                        589 _ak820_usb_try_send_sloc0_1_0:
      00001D                        590 	.ds 1
      00001E                        591 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        592 	.ds 1
      00001F                        593 _ak820_usb_keyboard_blocked_sloc0_1_0:
      00001F                        594 	.ds 1
      000020                        595 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      000020                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; paged external ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area PSEG    (PAG,XDATA)
                                    601 ;--------------------------------------------------------
                                    602 ; uninitialized external ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area XSEG    (XDATA)
      0007BB                        605 _D0SetupReqCode::
      0007BB                        606 	.ds 1
      0007BC                        607 _D0SetupLen::
      0007BC                        608 	.ds 2
      0007BE                        609 _pD0Descr::
      0007BE                        610 	.ds 3
      0007C1                        611 _D0UsbConfig::
      0007C1                        612 	.ds 1
      0007C2                        613 _USB_EnumStatus::
      0007C2                        614 	.ds 1
      0007C3                        615 _USB_SleepStatus::
      0007C3                        616 	.ds 1
      0007C4                        617 _MCU_Sleep_Operate::
      0007C4                        618 	.ds 1
      0007C5                        619 _KB_USB_UpStatus::
      0007C5                        620 	.ds 1
      0007C6                        621 _KB_USB_SetReport::
      0007C6                        622 	.ds 1
      0007C7                        623 _ak820_boot_stage::
      0007C7                        624 	.ds 1
      0007C8                        625 _ak820_main_heartbeat::
      0007C8                        626 	.ds 1
      0007C9                        627 _raw_state:
      0007C9                        628 	.ds 1
      0007CA                        629 _raw_buffer:
      0007CA                        630 	.ds 32
      0007EA                        631 _raw_reply_without_nvm:
      0007EA                        632 	.ds 1
      0007EB                        633 _keyboard_reset:
      0007EB                        634 	.ds 1
      0007EC                        635 _input_snapshot:
      0007EC                        636 	.ds 46
      00081A                        637 _control_phase:
      00081A                        638 	.ds 1
      00081B                        639 _output_kind:
      00081B                        640 	.ds 1
      00081C                        641 _output_report_id:
      00081C                        642 	.ds 1
      00081D                        643 _control_zlp:
      00081D                        644 	.ds 1
      00081E                        645 _control_pointer:
      00081E                        646 	.ds 2
      000820                        647 _descriptor_select_PARM_2:
      000820                        648 	.ds 1
      000821                        649 _descriptor_select_PARM_3:
      000821                        650 	.ds 2
      000823                        651 _descriptor_select_type_10000_269:
      000823                        652 	.ds 1
      000824                        653 _control_setup_length_10000_287:
      000824                        654 	.ds 2
      000826                        655 _control_setup_offset_10000_287:
      000826                        656 	.ds 1
      000827                        657 _ak820_usb_send_PARM_2:
      000827                        658 	.ds 2
      000829                        659 _ak820_usb_send_PARM_3:
      000829                        660 	.ds 1
      00082A                        661 _ak820_usb_send_endpoint_10000_423:
      00082A                        662 	.ds 1
      00082B                        663 _ak820_usb_send_offset_10000_424:
      00082B                        664 	.ds 1
      00082C                        665 _ak820_usb_try_send_PARM_2:
      00082C                        666 	.ds 2
      00082E                        667 _ak820_usb_try_send_PARM_3:
      00082E                        668 	.ds 1
      00082F                        669 _ak820_usb_try_send_endpoint_10000_444:
      00082F                        670 	.ds 1
      000830                        671 _ak820_usb_try_send_sent_10000_445:
      000830                        672 	.ds 1
      000831                        673 _ak820_usb_raw_send_PARM_2:
      000831                        674 	.ds 1
      000832                        675 _ak820_usb_raw_send_report_10000_460:
      000832                        676 	.ds 3
                                    677 ;--------------------------------------------------------
                                    678 ; absolute external ram data
                                    679 ;--------------------------------------------------------
                                    680 	.area XABS    (ABS,XDATA)
                                    681 ;--------------------------------------------------------
                                    682 ; initialized external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XISEG   (XDATA)
                                    685 	.area HOME    (CODE)
                                    686 	.area GSINIT0 (CODE)
                                    687 	.area GSINIT1 (CODE)
                                    688 	.area GSINIT2 (CODE)
                                    689 	.area GSINIT3 (CODE)
                                    690 	.area GSINIT4 (CODE)
                                    691 	.area GSINIT5 (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area CSEG    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; global & static initialisations
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area GSINIT  (CODE)
                                    700 	.area GSFINAL (CODE)
                                    701 	.area GSINIT  (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; Home
                                    704 ;--------------------------------------------------------
                                    705 	.area HOME    (CODE)
                                    706 	.area HOME    (CODE)
                                    707 ;--------------------------------------------------------
                                    708 ; code
                                    709 ;--------------------------------------------------------
                                    710 	.area CSEG    (CODE)
                                    711 ;------------------------------------------------------------
                                    712 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    713 ;------------------------------------------------------------
                                    714 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    715 ;------------------------------------------------------------
                                    716 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    717 ;	-----------------------------------------
                           000007   718 	ar7 = 0x07
                           000006   719 	ar6 = 0x06
                           000005   720 	ar5 = 0x05
                           000004   721 	ar4 = 0x04
                           000003   722 	ar3 = 0x03
                           000002   723 	ar2 = 0x02
                           000001   724 	ar1 = 0x01
                           000000   725 	ar0 = 0x00
                                    726 ;	 function raw_abort
                                    727 ;	-----------------------------------------
      005D9C                        728 _raw_abort:
                                    729 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D9C 90 07 C9         [24]  730 	mov	dptr,#_raw_state
      005D9F E0               [24]  731 	movx	a,@dptr
      005DA0 FF               [12]  732 	mov	r7,a
      005DA1 BF 03 02         [24]  733 	cjne	r7,#0x03,00130$
      005DA4 80 1C            [24]  734 	sjmp	00101$
      005DA6                        735 00130$:
      005DA6 90 07 C9         [24]  736 	mov	dptr,#_raw_state
      005DA9 E0               [24]  737 	movx	a,@dptr
      005DAA FF               [12]  738 	mov	r7,a
      005DAB BF 04 02         [24]  739 	cjne	r7,#0x04,00131$
      005DAE 80 12            [24]  740 	sjmp	00101$
      005DB0                        741 00131$:
                                    742 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005DB0 90 07 C9         [24]  743 	mov	dptr,#_raw_state
      005DB3 E0               [24]  744 	movx	a,@dptr
      005DB4 FF               [12]  745 	mov	r7,a
      005DB5 BF 06 02         [24]  746 	cjne	r7,#0x06,00132$
      005DB8 80 08            [24]  747 	sjmp	00101$
      005DBA                        748 00132$:
      005DBA 90 07 C9         [24]  749 	mov	dptr,#_raw_state
      005DBD E0               [24]  750 	movx	a,@dptr
      005DBE FF               [12]  751 	mov	r7,a
      005DBF BF 07 08         [24]  752 	cjne	r7,#0x07,00102$
      005DC2                        753 00101$:
                                    754 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005DC2 90 07 C9         [24]  755 	mov	dptr,#_raw_state
      005DC5 74 07            [12]  756 	mov	a,#0x07
      005DC7 F0               [24]  757 	movx	@dptr,a
      005DC8 80 05            [24]  758 	sjmp	00103$
      005DCA                        759 00102$:
                                    760 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005DCA 90 07 C9         [24]  761 	mov	dptr,#_raw_state
      005DCD E4               [12]  762 	clr	a
      005DCE F0               [24]  763 	movx	@dptr,a
      005DCF                        764 00103$:
                                    765 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005DCF 90 08 1B         [24]  766 	mov	dptr,#_output_kind
      005DD2 E4               [12]  767 	clr	a
      005DD3 F0               [24]  768 	movx	@dptr,a
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005DD4 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'raw_complete'
                                    773 ;------------------------------------------------------------
                                    774 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    775 ;	-----------------------------------------
                                    776 ;	 function raw_complete
                                    777 ;	-----------------------------------------
      005DD5                        778 _raw_complete:
                                    779 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005DD5 90 07 C9         [24]  780 	mov	dptr,#_raw_state
      005DD8 E0               [24]  781 	movx	a,@dptr
      005DD9 FF               [12]  782 	mov	r7,a
      005DDA BF 04 07         [24]  783 	cjne	r7,#0x04,00104$
      005DDD 90 07 C9         [24]  784 	mov	dptr,#_raw_state
      005DE0 74 06            [12]  785 	mov	a,#0x06
      005DE2 F0               [24]  786 	movx	@dptr,a
      005DE3 22               [24]  787 	ret
      005DE4                        788 00104$:
                                    789 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005DE4 90 07 C9         [24]  790 	mov	dptr,#_raw_state
      005DE7 E0               [24]  791 	movx	a,@dptr
      005DE8 FF               [12]  792 	mov	r7,a
      005DE9 BF 05 05         [24]  793 	cjne	r7,#0x05,00106$
      005DEC 90 07 C9         [24]  794 	mov	dptr,#_raw_state
      005DEF E4               [12]  795 	clr	a
      005DF0 F0               [24]  796 	movx	@dptr,a
      005DF1                        797 00106$:
                                    798 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005DF1 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'endpoints_reset'
                                    802 ;------------------------------------------------------------
                                    803 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    804 ;------------------------------------------------------------
                                    805 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function endpoints_reset
                                    808 ;	-----------------------------------------
      005DF2                        809 _endpoints_reset:
                                    810 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005DF2 90 22 0C         [24]  811 	mov	dptr,#0x220c
      005DF5 74 01            [12]  812 	mov	a,#0x01
      005DF7 F0               [24]  813 	movx	@dptr,a
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DF8 F5 82            [12]  815 	mov	dpl,a
      005DFA 74 12            [12]  816 	mov	a,#0x12
      005DFC F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DFD A3               [24]  819 	inc	dptr
      005DFE F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DFF A3               [24]  822 	inc	dptr
      005E00 F0               [24]  823 	movx	@dptr,a
                                    824 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005E01 90 22 0B         [24]  825 	mov	dptr,#0x220b
      005E04 E4               [12]  826 	clr	a
      005E05 F0               [24]  827 	movx	@dptr,a
      005E06 15 82            [12]  828 	dec	dpl
      005E08 F0               [24]  829 	movx	@dptr,a
      005E09 15 82            [12]  830 	dec	dpl
      005E0B F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005E0C FF               [12]  833 	mov	r7,a
      005E0D                        834 00103$:
      005E0D EF               [12]  835 	mov	a,r7
      005E0E 24 EC            [12]  836 	add	a, #_input_snapshot
      005E10 F5 82            [12]  837 	mov	dpl,a
      005E12 E4               [12]  838 	clr	a
      005E13 34 07            [12]  839 	addc	a, #(_input_snapshot >> 8)
      005E15 F5 83            [12]  840 	mov	dph,a
      005E17 E4               [12]  841 	clr	a
      005E18 F0               [24]  842 	movx	@dptr,a
      005E19 0F               [12]  843 	inc	r7
      005E1A BF 2E 00         [24]  844 	cjne	r7,#0x2e,00139$
      005E1D                        845 00139$:
      005E1D 40 EE            [24]  846 	jc	00103$
                                    847 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005E1F 90 07 F4         [24]  848 	mov	dptr,#(_input_snapshot + 0x0008)
      005E22 74 06            [12]  849 	mov	a,#0x06
      005E24 F0               [24]  850 	movx	@dptr,a
                                    851 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005E25 90 08 14         [24]  852 	mov	dptr,#(_input_snapshot + 0x0028)
      005E28 03               [12]  853 	rr	a
      005E29 F0               [24]  854 	movx	@dptr,a
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005E2A 90 08 17         [24]  856 	mov	dptr,#(_input_snapshot + 0x002b)
      005E2D 04               [12]  857 	inc	a
      005E2E F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005E2F 7F 00            [12]  860 	mov	r7,#0x00
      005E31                        861 00105$:
      005E31 8F 06            [24]  862 	mov	ar6,r7
      005E33 74 C0            [12]  863 	mov	a,#0xc0
      005E35 2E               [12]  864 	add	a, r6
      005E36 F5 82            [12]  865 	mov	dpl,a
      005E38 74 10            [12]  866 	mov	a,#0x10
      005E3A 24 00            [12]  867 	add	a, #0x00
      005E3C F5 83            [12]  868 	mov	dph,a
      005E3E E4               [12]  869 	clr	a
      005E3F F0               [24]  870 	movx	@dptr,a
      005E40 0F               [12]  871 	inc	r7
      005E41 BF 20 00         [24]  872 	cjne	r7,#0x20,00141$
      005E44                        873 00141$:
      005E44 40 EB            [24]  874 	jc	00105$
                                    875 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005E46 02 5D 9C         [24]  877 	ljmp	_raw_abort
                                    878 ;------------------------------------------------------------
                                    879 ;Allocation info for local variables in function 'control_stall'
                                    880 ;------------------------------------------------------------
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function control_stall
                                    884 ;	-----------------------------------------
      005E49                        885 _control_stall:
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005E49 90 07 C9         [24]  887 	mov	dptr,#_raw_state
      005E4C E0               [24]  888 	movx	a,@dptr
      005E4D FF               [12]  889 	mov	r7,a
      005E4E BF 01 05         [24]  890 	cjne	r7,#0x01,00102$
      005E51 90 07 C9         [24]  891 	mov	dptr,#_raw_state
      005E54 E4               [12]  892 	clr	a
      005E55 F0               [24]  893 	movx	@dptr,a
      005E56                        894 00102$:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005E56 90 08 1B         [24]  896 	mov	dptr,#_output_kind
      005E59 E4               [12]  897 	clr	a
      005E5A F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005E5B 90 08 1A         [24]  900 	mov	dptr,#_control_phase
      005E5E F0               [24]  901 	movx	@dptr,a
                                    902 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005E5F 90 07 BB         [24]  903 	mov	dptr,#_D0SetupReqCode
      005E62 14               [12]  904 	dec	a
      005E63 F0               [24]  905 	movx	@dptr,a
                                    906 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005E64 90 22 00         [24]  907 	mov	dptr,#0x2200
      005E67 74 CF            [12]  908 	mov	a,#0xcf
      005E69 F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005E6A 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'control_next'
                                    914 ;------------------------------------------------------------
                                    915 ;i             Allocated with name '_control_next_i_10000_266'
                                    916 ;length        Allocated with name '_control_next_length_10000_266'
                                    917 ;------------------------------------------------------------
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function control_next
                                    921 ;	-----------------------------------------
      005E6B                        922 _control_next:
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005E6B 90 07 BC         [24]  924 	mov	dptr,#_D0SetupLen
      005E6E E0               [24]  925 	movx	a,@dptr
      005E6F FE               [12]  926 	mov	r6,a
      005E70 A3               [24]  927 	inc	dptr
      005E71 E0               [24]  928 	movx	a,@dptr
      005E72 FF               [12]  929 	mov	r7,a
      005E73 C3               [12]  930 	clr	c
      005E74 74 40            [12]  931 	mov	a,#0x40
      005E76 9E               [12]  932 	subb	a,r6
      005E77 E4               [12]  933 	clr	a
      005E78 9F               [12]  934 	subb	a,r7
      005E79 50 04            [24]  935 	jnc	00109$
                                    936 ;	free result
      005E7B 7E 40            [12]  937 	mov	r6,#0x40
      005E7D 80 07            [24]  938 	sjmp	00110$
      005E7F                        939 00109$:
      005E7F 90 07 BC         [24]  940 	mov	dptr,#_D0SetupLen
      005E82 E0               [24]  941 	movx	a,@dptr
      005E83 FE               [12]  942 	mov	r6,a
      005E84 A3               [24]  943 	inc	dptr
      005E85 E0               [24]  944 	movx	a,@dptr
      005E86                        945 00110$:
                                    946 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E86 7F 00            [12]  947 	mov	r7,#0x00
      005E88                        948 00105$:
      005E88 C3               [12]  949 	clr	c
      005E89 EF               [12]  950 	mov	a,r7
      005E8A 9E               [12]  951 	subb	a,r6
      005E8B 50 2A            [24]  952 	jnc	00101$
      005E8D 8F 04            [24]  953 	mov	ar4,r7
      005E8F 74 10            [12]  954 	mov	a,#0x10
      005E91 24 00            [12]  955 	add	a, #0x00
      005E93 FD               [12]  956 	mov	r5,a
      005E94 90 08 1E         [24]  957 	mov	dptr,#_control_pointer
      005E97 E0               [24]  958 	movx	a,@dptr
      005E98 FA               [12]  959 	mov	r2,a
      005E99 A3               [24]  960 	inc	dptr
      005E9A E0               [24]  961 	movx	a,@dptr
      005E9B FB               [12]  962 	mov	r3,a
      005E9C 8A 82            [24]  963 	mov	dpl,r2
      005E9E 8B 83            [24]  964 	mov	dph,r3
      005EA0 E4               [12]  965 	clr	a
      005EA1 93               [24]  966 	movc	a,@a+dptr
      005EA2 F9               [12]  967 	mov	r1,a
      005EA3 90 08 1E         [24]  968 	mov	dptr,#_control_pointer
      005EA6 74 01            [12]  969 	mov	a,#0x01
      005EA8 2A               [12]  970 	add	a, r2
      005EA9 F0               [24]  971 	movx	@dptr,a
      005EAA E4               [12]  972 	clr	a
      005EAB 3B               [12]  973 	addc	a, r3
      005EAC A3               [24]  974 	inc	dptr
      005EAD F0               [24]  975 	movx	@dptr,a
      005EAE 8C 82            [24]  976 	mov	dpl,r4
      005EB0 8D 83            [24]  977 	mov	dph,r5
      005EB2 E9               [12]  978 	mov	a,r1
      005EB3 F0               [24]  979 	movx	@dptr,a
      005EB4 0F               [12]  980 	inc	r7
      005EB5 80 D1            [24]  981 	sjmp	00105$
      005EB7                        982 00101$:
                                    983 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005EB7 8E 05            [24]  984 	mov	ar5,r6
      005EB9 7F 00            [12]  985 	mov	r7,#0x00
      005EBB 90 07 BC         [24]  986 	mov	dptr,#_D0SetupLen
      005EBE E0               [24]  987 	movx	a,@dptr
      005EBF FB               [12]  988 	mov	r3,a
      005EC0 A3               [24]  989 	inc	dptr
      005EC1 E0               [24]  990 	movx	a,@dptr
      005EC2 FC               [12]  991 	mov	r4,a
      005EC3 EB               [12]  992 	mov	a,r3
      005EC4 C3               [12]  993 	clr	c
      005EC5 9D               [12]  994 	subb	a,r5
      005EC6 FB               [12]  995 	mov	r3,a
      005EC7 EC               [12]  996 	mov	a,r4
      005EC8 9F               [12]  997 	subb	a,r7
      005EC9 FC               [12]  998 	mov	r4,a
      005ECA 90 07 BC         [24]  999 	mov	dptr,#_D0SetupLen
      005ECD EB               [12] 1000 	mov	a,r3
      005ECE F0               [24] 1001 	movx	@dptr,a
      005ECF EC               [12] 1002 	mov	a,r4
      005ED0 A3               [24] 1003 	inc	dptr
      005ED1 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005ED2 EE               [12] 1006 	mov	a,r6
      005ED3 70 05            [24] 1007 	jnz	00103$
      005ED5 90 08 1D         [24] 1008 	mov	dptr,#_control_zlp
      005ED8 E4               [12] 1009 	clr	a
      005ED9 F0               [24] 1010 	movx	@dptr,a
      005EDA                       1011 00103$:
                                   1012 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005EDA 90 22 08         [24] 1013 	mov	dptr,#0x2208
      005EDD EE               [12] 1014 	mov	a,r6
      005EDE F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005EDF 90 22 00         [24] 1017 	mov	dptr,#0x2200
      005EE2 E0               [24] 1018 	movx	a,@dptr
      005EE3 54 C0            [12] 1019 	anl	a,#0xc0
      005EE5 F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005EE6 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'descriptor_select'
                                   1025 ;------------------------------------------------------------
                                   1026 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1027 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1028 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1029 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function descriptor_select
                                   1034 ;	-----------------------------------------
      005EE7                       1035 _descriptor_select:
      005EE7 E5 82            [12] 1036 	mov	a,dpl
      005EE9 90 08 23         [24] 1037 	mov	dptr,#_descriptor_select_type_10000_269
      005EEC F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005EED E0               [24] 1040 	movx	a,@dptr
      005EEE FF               [12] 1041 	mov	r7,a
      005EEF BF 01 20         [24] 1042 	cjne	r7,#0x01,00102$
      005EF2 90 08 20         [24] 1043 	mov	dptr,#_descriptor_select_PARM_2
      005EF5 E0               [24] 1044 	movx	a,@dptr
      005EF6 70 1A            [24] 1045 	jnz	00102$
      005EF8 90 08 21         [24] 1046 	mov	dptr,#_descriptor_select_PARM_3
      005EFB E0               [24] 1047 	movx	a,@dptr
      005EFC F5 F0            [12] 1048 	mov	b,a
      005EFE A3               [24] 1049 	inc	dptr
      005EFF E0               [24] 1050 	movx	a,@dptr
      005F00 45 F0            [12] 1051 	orl	a,b
      005F02 70 0E            [24] 1052 	jnz	00102$
                                   1053 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005F04 90 08 1E         [24] 1054 	mov	dptr,#_control_pointer
      005F07 74 25            [12] 1055 	mov	a,#_DeviceDescriptor
      005F09 F0               [24] 1056 	movx	@dptr,a
      005F0A 74 C4            [12] 1057 	mov	a,#(_DeviceDescriptor >> 8)
      005F0C A3               [24] 1058 	inc	dptr
      005F0D F0               [24] 1059 	movx	@dptr,a
                                   1060 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005F0E 90 00 12         [24] 1061 	mov	dptr,#0x0012
      005F11 22               [24] 1062 	ret
      005F12                       1063 00102$:
                                   1064 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005F12 90 08 23         [24] 1065 	mov	dptr,#_descriptor_select_type_10000_269
      005F15 E0               [24] 1066 	movx	a,@dptr
      005F16 FF               [12] 1067 	mov	r7,a
      005F17 BF 02 20         [24] 1068 	cjne	r7,#0x02,00106$
      005F1A 90 08 20         [24] 1069 	mov	dptr,#_descriptor_select_PARM_2
      005F1D E0               [24] 1070 	movx	a,@dptr
      005F1E 70 1A            [24] 1071 	jnz	00106$
      005F20 90 08 21         [24] 1072 	mov	dptr,#_descriptor_select_PARM_3
      005F23 E0               [24] 1073 	movx	a,@dptr
      005F24 F5 F0            [12] 1074 	mov	b,a
      005F26 A3               [24] 1075 	inc	dptr
      005F27 E0               [24] 1076 	movx	a,@dptr
      005F28 45 F0            [12] 1077 	orl	a,b
      005F2A 70 0E            [24] 1078 	jnz	00106$
                                   1079 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005F2C 90 08 1E         [24] 1080 	mov	dptr,#_control_pointer
      005F2F 74 37            [12] 1081 	mov	a,#_ConfigurationDescriptor
      005F31 F0               [24] 1082 	movx	@dptr,a
      005F32 74 C4            [12] 1083 	mov	a,#(_ConfigurationDescriptor >> 8)
      005F34 A3               [24] 1084 	inc	dptr
      005F35 F0               [24] 1085 	movx	@dptr,a
                                   1086 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005F36 90 00 54         [24] 1087 	mov	dptr,#0x0054
      005F39 22               [24] 1088 	ret
      005F3A                       1089 00106$:
                                   1090 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005F3A 90 08 23         [24] 1091 	mov	dptr,#_descriptor_select_type_10000_269
      005F3D E0               [24] 1092 	movx	a,@dptr
      005F3E FF               [12] 1093 	mov	r7,a
      005F3F BF 03 02         [24] 1094 	cjne	r7,#0x03,00238$
      005F42 80 03            [24] 1095 	sjmp	00239$
      005F44                       1096 00238$:
      005F44 02 5F DE         [24] 1097 	ljmp	00119$
      005F47                       1098 00239$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005F47 90 08 21         [24] 1100 	mov	dptr,#_descriptor_select_PARM_3
      005F4A E0               [24] 1101 	movx	a,@dptr
      005F4B FD               [12] 1102 	mov	r5,a
      005F4C A3               [24] 1103 	inc	dptr
      005F4D E0               [24] 1104 	movx	a,@dptr
      005F4E FE               [12] 1105 	mov	r6,a
      005F4F 90 08 21         [24] 1106 	mov	dptr,#_descriptor_select_PARM_3
      005F52 E0               [24] 1107 	movx	a,@dptr
      005F53 F5 F0            [12] 1108 	mov	b,a
      005F55 A3               [24] 1109 	inc	dptr
      005F56 E0               [24] 1110 	movx	a,@dptr
      005F57 45 F0            [12] 1111 	orl	a,b
      005F59 60 0C            [24] 1112 	jz	00110$
      005F5B BD 09 05         [24] 1113 	cjne	r5,#0x09,00241$
      005F5E BE 04 02         [24] 1114 	cjne	r6,#0x04,00241$
      005F61 80 04            [24] 1115 	sjmp	00110$
      005F63                       1116 00241$:
      005F63 90 00 00         [24] 1117 	mov	dptr,#0x0000
      005F66 22               [24] 1118 	ret
      005F67                       1119 00110$:
                                   1120 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005F67 90 08 20         [24] 1121 	mov	dptr,#_descriptor_select_PARM_2
      005F6A E0               [24] 1122 	movx	a,@dptr
      005F6B FE               [12] 1123 	mov  r6,a
      005F6C 24 FC            [12] 1124 	add	a,#0xff - 0x03
      005F6E 40 6A            [24] 1125 	jc	00116$
                                   1126 ;	free result
      005F70 EE               [12] 1127 	mov	a,r6
      005F71 2E               [12] 1128 	add	a,r6
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005F72 90 5F 76         [24] 1130 	mov	dptr,#00243$
      005F75 73               [24] 1131 	jmp	@a+dptr
      005F76                       1132 00243$:
      005F76 80 06            [24] 1133 	sjmp	00112$
      005F78 80 1B            [24] 1134 	sjmp	00113$
      005F7A 80 30            [24] 1135 	sjmp	00114$
      005F7C 80 45            [24] 1136 	sjmp	00115$
      005F7E                       1137 00112$:
      005F7E 90 08 1E         [24] 1138 	mov	dptr,#_control_pointer
      005F81 74 8B            [12] 1139 	mov	a,#_LanguageString
      005F83 F0               [24] 1140 	movx	@dptr,a
      005F84 74 C4            [12] 1141 	mov	a,#(_LanguageString >> 8)
      005F86 A3               [24] 1142 	inc	dptr
      005F87 F0               [24] 1143 	movx	@dptr,a
      005F88 90 C4 8B         [24] 1144 	mov	dptr,#_LanguageString
      005F8B E4               [12] 1145 	clr	a
      005F8C 93               [24] 1146 	movc	a,@a+dptr
      005F8D FE               [12] 1147 	mov	r6,a
      005F8E 7D 00            [12] 1148 	mov	r5,#0x00
      005F90 8E 82            [24] 1149 	mov	dpl, r6
      005F92 8D 83            [24] 1150 	mov	dph, r5
      005F94 22               [24] 1151 	ret
                                   1152 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F95                       1153 00113$:
      005F95 90 08 1E         [24] 1154 	mov	dptr,#_control_pointer
      005F98 74 8F            [12] 1155 	mov	a,#_ManufacturerString
      005F9A F0               [24] 1156 	movx	@dptr,a
      005F9B 74 C4            [12] 1157 	mov	a,#(_ManufacturerString >> 8)
      005F9D A3               [24] 1158 	inc	dptr
      005F9E F0               [24] 1159 	movx	@dptr,a
      005F9F 90 C4 8F         [24] 1160 	mov	dptr,#_ManufacturerString
      005FA2 E4               [12] 1161 	clr	a
      005FA3 93               [24] 1162 	movc	a,@a+dptr
      005FA4 FE               [12] 1163 	mov	r6,a
      005FA5 7D 00            [12] 1164 	mov	r5,#0x00
      005FA7 8E 82            [24] 1165 	mov	dpl, r6
      005FA9 8D 83            [24] 1166 	mov	dph, r5
      005FAB 22               [24] 1167 	ret
                                   1168 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005FAC                       1169 00114$:
      005FAC 90 08 1E         [24] 1170 	mov	dptr,#_control_pointer
      005FAF 74 9D            [12] 1171 	mov	a,#_ProductString
      005FB1 F0               [24] 1172 	movx	@dptr,a
      005FB2 74 C4            [12] 1173 	mov	a,#(_ProductString >> 8)
      005FB4 A3               [24] 1174 	inc	dptr
      005FB5 F0               [24] 1175 	movx	@dptr,a
      005FB6 90 C4 9D         [24] 1176 	mov	dptr,#_ProductString
      005FB9 E4               [12] 1177 	clr	a
      005FBA 93               [24] 1178 	movc	a,@a+dptr
      005FBB FE               [12] 1179 	mov	r6,a
      005FBC 7D 00            [12] 1180 	mov	r5,#0x00
      005FBE 8E 82            [24] 1181 	mov	dpl, r6
      005FC0 8D 83            [24] 1182 	mov	dph, r5
      005FC2 22               [24] 1183 	ret
                                   1184 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005FC3                       1185 00115$:
      005FC3 90 08 1E         [24] 1186 	mov	dptr,#_control_pointer
      005FC6 74 D5            [12] 1187 	mov	a,#_SerialNumberString
      005FC8 F0               [24] 1188 	movx	@dptr,a
      005FC9 74 C4            [12] 1189 	mov	a,#(_SerialNumberString >> 8)
      005FCB A3               [24] 1190 	inc	dptr
      005FCC F0               [24] 1191 	movx	@dptr,a
      005FCD 90 C4 D5         [24] 1192 	mov	dptr,#_SerialNumberString
      005FD0 E4               [12] 1193 	clr	a
      005FD1 93               [24] 1194 	movc	a,@a+dptr
      005FD2 FE               [12] 1195 	mov	r6,a
      005FD3 7D 00            [12] 1196 	mov	r5,#0x00
      005FD5 8E 82            [24] 1197 	mov	dpl, r6
      005FD7 8D 83            [24] 1198 	mov	dph, r5
      005FD9 22               [24] 1199 	ret
                                   1200 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005FDA                       1201 00116$:
      005FDA 90 00 00         [24] 1202 	mov	dptr,#0x0000
      005FDD 22               [24] 1203 	ret
                                   1204 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005FDE                       1205 00119$:
                                   1206 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005FDE 90 08 20         [24] 1207 	mov	dptr,#_descriptor_select_PARM_2
      005FE1 E0               [24] 1208 	movx	a,@dptr
      005FE2 70 11            [24] 1209 	jnz	00120$
      005FE4 90 08 21         [24] 1210 	mov	dptr,#_descriptor_select_PARM_3
      005FE7 E0               [24] 1211 	movx	a,@dptr
      005FE8 FD               [12] 1212 	mov	r5,a
      005FE9 A3               [24] 1213 	inc	dptr
      005FEA E0               [24] 1214 	movx	a,@dptr
      005FEB FE               [12] 1215 	mov	r6,a
      005FEC C3               [12] 1216 	clr	c
      005FED ED               [12] 1217 	mov	a,r5
      005FEE 94 03            [12] 1218 	subb	a,#0x03
      005FF0 EE               [12] 1219 	mov	a,r6
      005FF1 94 00            [12] 1220 	subb	a,#0x00
      005FF3 40 04            [24] 1221 	jc	00121$
      005FF5                       1222 00120$:
      005FF5 90 00 00         [24] 1223 	mov	dptr,#0x0000
      005FF8 22               [24] 1224 	ret
      005FF9                       1225 00121$:
                                   1226 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005FF9 BF 22 02         [24] 1227 	cjne	r7,#0x22,00246$
      005FFC 80 03            [24] 1228 	sjmp	00127$
      005FFE                       1229 00246$:
      005FFE BF 21 5D         [24] 1230 	cjne	r7,#0x21,00128$
      006001                       1231 00127$:
                                   1232 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      006001 ED               [12] 1233 	mov	a,r5
      006002 75 F0 04         [24] 1234 	mov	b,#0x04
      006005 A4               [48] 1235 	mul	ab
      006006 24 AE            [12] 1236 	add	a, #_interface_descriptors
      006008 FE               [12] 1237 	mov	r6,a
      006009 74 BD            [12] 1238 	mov	a,#(_interface_descriptors >> 8)
      00600B 35 F0            [12] 1239 	addc	a, b
      00600D FF               [12] 1240 	mov	r7,a
      00600E 8E 82            [24] 1241 	mov	dpl,r6
      006010 8F 83            [24] 1242 	mov	dph,r7
      006012 A3               [24] 1243 	inc	dptr
      006013 A3               [24] 1244 	inc	dptr
      006014 E4               [12] 1245 	clr	a
      006015 93               [24] 1246 	movc	a,@a+dptr
      006016 FC               [12] 1247 	mov	r4,a
      006017 A3               [24] 1248 	inc	dptr
      006018 E4               [12] 1249 	clr	a
      006019 93               [24] 1250 	movc	a,@a+dptr
                                   1251 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      00601A FD               [12] 1252 	mov	r5,a
      00601B 4C               [12] 1253 	orl	a,r4
      00601C 70 04            [24] 1254 	jnz	00124$
      00601E 90 00 00         [24] 1255 	mov	dptr,#0x0000
      006021 22               [24] 1256 	ret
      006022                       1257 00124$:
                                   1258 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      006022 90 08 23         [24] 1259 	mov	dptr,#_descriptor_select_type_10000_269
      006025 E0               [24] 1260 	movx	a,@dptr
      006026 FB               [12] 1261 	mov	r3,a
      006027 BB 22 28         [24] 1262 	cjne	r3,#0x22,00126$
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      00602A 8E 82            [24] 1264 	mov	dpl,r6
      00602C 8F 83            [24] 1265 	mov	dph,r7
      00602E E4               [12] 1266 	clr	a
      00602F 93               [24] 1267 	movc	a,@a+dptr
      006030 FE               [12] 1268 	mov	r6,a
      006031 A3               [24] 1269 	inc	dptr
      006032 E4               [12] 1270 	clr	a
      006033 93               [24] 1271 	movc	a,@a+dptr
      006034 FF               [12] 1272 	mov	r7,a
      006035 90 08 1E         [24] 1273 	mov	dptr,#_control_pointer
      006038 EE               [12] 1274 	mov	a,r6
      006039 F0               [24] 1275 	movx	@dptr,a
      00603A EF               [12] 1276 	mov	a,r7
      00603B A3               [24] 1277 	inc	dptr
      00603C F0               [24] 1278 	movx	@dptr,a
                                   1279 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      00603D 74 07            [12] 1280 	mov	a,#0x07
      00603F 2C               [12] 1281 	add	a, r4
      006040 F5 82            [12] 1282 	mov	dpl,a
      006042 E4               [12] 1283 	clr	a
      006043 3D               [12] 1284 	addc	a, r5
      006044 F5 83            [12] 1285 	mov	dph,a
      006046 E4               [12] 1286 	clr	a
      006047 93               [24] 1287 	movc	a,@a+dptr
      006048 FE               [12] 1288 	mov	r6,a
      006049 A3               [24] 1289 	inc	dptr
      00604A E4               [12] 1290 	clr	a
      00604B 93               [24] 1291 	movc	a,@a+dptr
      00604C FF               [12] 1292 	mov	r7,a
      00604D 8E 82            [24] 1293 	mov	dpl, r6
      00604F 8F 83            [24] 1294 	mov	dph, r7
      006051 22               [24] 1295 	ret
      006052                       1296 00126$:
                                   1297 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      006052 90 08 1E         [24] 1298 	mov	dptr,#_control_pointer
      006055 EC               [12] 1299 	mov	a,r4
      006056 F0               [24] 1300 	movx	@dptr,a
      006057 ED               [12] 1301 	mov	a,r5
      006058 A3               [24] 1302 	inc	dptr
      006059 F0               [24] 1303 	movx	@dptr,a
                                   1304 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      00605A 90 00 09         [24] 1305 	mov	dptr,#0x0009
      00605D 22               [24] 1306 	ret
      00605E                       1307 00128$:
                                   1308 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      00605E 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      006061 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'control_setup'
                                   1314 ;------------------------------------------------------------
                                   1315 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1316 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1317 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1318 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1319 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1320 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1321 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1322 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1323 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1324 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1325 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1326 ;------------------------------------------------------------
                                   1327 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1328 ;	-----------------------------------------
                                   1329 ;	 function control_setup
                                   1330 ;	-----------------------------------------
      006062                       1331 _control_setup:
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006062 90 10 00         [24] 1333 	mov	dptr,#0x1000
      006065 E0               [24] 1334 	movx	a,@dptr
      006066 FF               [12] 1335 	mov	r7,a
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006067 A3               [24] 1337 	inc	dptr
      006068 A3               [24] 1338 	inc	dptr
      006069 E0               [24] 1339 	movx	a,@dptr
      00606A FE               [12] 1340 	mov	r6,a
      00606B A3               [24] 1341 	inc	dptr
      00606C E0               [24] 1342 	movx	a,@dptr
      00606D FC               [12] 1343 	mov	r4,a
      00606E 7D 00            [12] 1344 	mov	r5,#0x00
      006070 8E 03            [24] 1345 	mov	ar3,r6
      006072 7E 00            [12] 1346 	mov	r6,#0x00
      006074 ED               [12] 1347 	mov	a,r5
      006075 4B               [12] 1348 	orl	a,r3
      006076 FD               [12] 1349 	mov	r5,a
      006077 EC               [12] 1350 	mov	a,r4
      006078 4E               [12] 1351 	orl	a,r6
      006079 FE               [12] 1352 	mov	r6,a
                                   1353 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      00607A A3               [24] 1354 	inc	dptr
      00607B E0               [24] 1355 	movx	a,@dptr
      00607C FC               [12] 1356 	mov	r4,a
      00607D A3               [24] 1357 	inc	dptr
      00607E E0               [24] 1358 	movx	a,@dptr
      00607F FA               [12] 1359 	mov	r2,a
      006080 7B 00            [12] 1360 	mov	r3,#0x00
      006082 8C 01            [24] 1361 	mov	ar1,r4
      006084 7C 00            [12] 1362 	mov	r4,#0x00
      006086 EB               [12] 1363 	mov	a,r3
      006087 49               [12] 1364 	orl	a,r1
      006088 FB               [12] 1365 	mov	r3,a
      006089 EA               [12] 1366 	mov	a,r2
      00608A 4C               [12] 1367 	orl	a,r4
      00608B FC               [12] 1368 	mov	r4,a
                                   1369 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      00608C C3               [12] 1370 	clr	c
      00608D EB               [12] 1371 	mov	a,r3
      00608E 94 03            [12] 1372 	subb	a,#0x03
      006090 EC               [12] 1373 	mov	a,r4
      006091 94 00            [12] 1374 	subb	a,#0x00
      006093 92 17            [24] 1375 	mov	_control_setup_valid_interface_10000_287,c
                                   1376 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      006095 EB               [12] 1377 	mov	a,r3
      006096 4C               [12] 1378 	orl	a,r4
      006097 B4 01 00         [24] 1379 	cjne	a,#0x01,01201$
      00609A                       1380 01201$:
      00609A 92 18            [24] 1381 	mov	_control_setup_zero_index_10000_287,c
                                   1382 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      00609C ED               [12] 1383 	mov	a,r5
      00609D 4E               [12] 1384 	orl	a,r6
      00609E B4 01 00         [24] 1385 	cjne	a,#0x01,01202$
      0060A1                       1386 01202$:
                                   1387 ;	assignBit
      0060A1 92 1B            [24] 1388 	mov  _control_setup_sloc0_1_0,c
      0060A3 92 19            [24] 1389 	mov	_control_setup_zero_value_10000_287,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      0060A5 90 08 26         [24] 1391 	mov	dptr,#_control_setup_offset_10000_287
      0060A8 E4               [12] 1392 	clr	a
      0060A9 F0               [24] 1393 	movx	@dptr,a
                                   1394 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0060AA 90 07 C9         [24] 1395 	mov	dptr,#_raw_state
      0060AD E0               [24] 1396 	movx	a,@dptr
      0060AE FA               [12] 1397 	mov	r2,a
      0060AF BA 01 05         [24] 1398 	cjne	r2,#0x01,00102$
      0060B2 90 07 C9         [24] 1399 	mov	dptr,#_raw_state
      0060B5 E4               [12] 1400 	clr	a
      0060B6 F0               [24] 1401 	movx	@dptr,a
      0060B7                       1402 00102$:
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      0060B7 C0 07            [24] 1404 	push	ar7
      0060B9 90 08 1B         [24] 1405 	mov	dptr,#_output_kind
      0060BC E4               [12] 1406 	clr	a
      0060BD F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      0060BE 90 08 1A         [24] 1409 	mov	dptr,#_control_phase
      0060C1 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      0060C2 90 08 1D         [24] 1412 	mov	dptr,#_control_zlp
      0060C5 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0060C6 90 10 01         [24] 1415 	mov	dptr,#0x1001
      0060C9 E0               [24] 1416 	movx	a,@dptr
      0060CA 90 07 BB         [24] 1417 	mov	dptr,#_D0SetupReqCode
      0060CD F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0060CE 90 10 06         [24] 1420 	mov	dptr,#0x1006
      0060D1 E0               [24] 1421 	movx	a,@dptr
      0060D2 FA               [12] 1422 	mov	r2,a
      0060D3 A3               [24] 1423 	inc	dptr
      0060D4 E0               [24] 1424 	movx	a,@dptr
      0060D5 F9               [12] 1425 	mov	r1,a
      0060D6 78 00            [12] 1426 	mov	r0,#0x00
      0060D8 7F 00            [12] 1427 	mov	r7,#0x00
      0060DA 90 07 BC         [24] 1428 	mov	dptr,#_D0SetupLen
      0060DD E8               [12] 1429 	mov	a,r0
      0060DE 4A               [12] 1430 	orl	a,r2
      0060DF F0               [24] 1431 	movx	@dptr,a
      0060E0 E9               [12] 1432 	mov	a,r1
      0060E1 4F               [12] 1433 	orl	a,r7
      0060E2 A3               [24] 1434 	inc	dptr
      0060E3 F0               [24] 1435 	movx	@dptr,a
                                   1436 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      0060E4 90 07 BC         [24] 1437 	mov	dptr,#_D0SetupLen
      0060E7 E0               [24] 1438 	movx	a,@dptr
      0060E8 FA               [12] 1439 	mov	r2,a
      0060E9 A3               [24] 1440 	inc	dptr
      0060EA E0               [24] 1441 	movx	a,@dptr
      0060EB 4A               [12] 1442 	orl	a,r2
      0060EC B4 01 00         [24] 1443 	cjne	a,#0x01,01205$
      0060EF                       1444 01205$:
      0060EF 92 1A            [24] 1445 	mov	_control_setup_zero_length_10000_287,c
                                   1446 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0060F1 90 22 00         [24] 1447 	mov	dptr,#0x2200
      0060F4 74 C2            [12] 1448 	mov	a,#0xc2
      0060F6 F0               [24] 1449 	movx	@dptr,a
                                   1450 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      0060F7 90 22 08         [24] 1451 	mov	dptr,#0x2208
      0060FA E4               [12] 1452 	clr	a
      0060FB F0               [24] 1453 	movx	@dptr,a
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      0060FC 90 07 BB         [24] 1455 	mov	dptr,#_D0SetupReqCode
      0060FF E0               [24] 1456 	movx	a,@dptr
      006100 F5 16            [12] 1457 	mov	_control_setup_sloc1_1_0,a
      006102 C3               [12] 1458 	clr	c
      006103 74 0B            [12] 1459 	mov	a,#0x0b
      006105 95 16            [12] 1460 	subb	a,_control_setup_sloc1_1_0
      006107 D0 07            [24] 1461 	pop	ar7
      006109 50 03            [24] 1462 	jnc	01206$
      00610B 02 5E 49         [24] 1463 	ljmp	_control_stall
      00610E                       1464 01206$:
                                   1465 ;	free result
      00610E E5 16            [12] 1466 	mov	a,_control_setup_sloc1_1_0
      006110 F5 F0            [12] 1467 	mov	b,a
      006112 24 0B            [12] 1468 	add	a,#(01207$-3-.)
      006114 83               [24] 1469 	movc	a,@a+pc
      006115 F5 82            [12] 1470 	mov	dpl,a
      006117 E5 F0            [12] 1471 	mov	a,b
      006119 24 10            [12] 1472 	add	a,#(01208$-3-.)
      00611B 83               [24] 1473 	movc	a,@a+pc
      00611C F5 83            [12] 1474 	mov	dph,a
      00611E E4               [12] 1475 	clr	a
      00611F 73               [24] 1476 	jmp	@a+dptr
      006120                       1477 01207$:
      006120 C8                    1478 	.db	00188$
      006121 6E                    1479 	.db	00205$
      006122 B1                    1480 	.db	00282$
      006123 6E                    1481 	.db	00205$
      006124 F5                    1482 	.db	00290$
      006125 F2                    1483 	.db	00116$
      006126 38                    1484 	.db	00103$
      006127 F5                    1485 	.db	00290$
      006128 F7                    1486 	.db	00150$
      006129 1B                    1487 	.db	00123$
      00612A 27                    1488 	.db	00157$
      00612B 7A                    1489 	.db	00173$
      00612C                       1490 01208$:
      00612C 63                    1491 	.db	00188$>>8
      00612D 64                    1492 	.db	00205$>>8
      00612E 67                    1493 	.db	00282$>>8
      00612F 64                    1494 	.db	00205$>>8
      006130 67                    1495 	.db	00290$>>8
      006131 61                    1496 	.db	00116$>>8
      006132 61                    1497 	.db	00103$>>8
      006133 67                    1498 	.db	00290$>>8
      006134 62                    1499 	.db	00150$>>8
      006135 62                    1500 	.db	00123$>>8
      006136 63                    1501 	.db	00157$>>8
      006137 63                    1502 	.db	00173$>>8
                                   1503 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      006138                       1504 00103$:
                                   1505 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      006138 BF 80 02         [24] 1506 	cjne	r7,#0x80,01209$
      00613B 80 08            [24] 1507 	sjmp	00112$
      00613D                       1508 01209$:
      00613D BF 81 02         [24] 1509 	cjne	r7,#0x81,01210$
      006140 80 03            [24] 1510 	sjmp	01211$
      006142                       1511 01210$:
      006142 02 5E 49         [24] 1512 	ljmp	_control_stall
      006145                       1513 01211$:
      006145                       1514 00112$:
                                   1515 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006145 8E 01            [24] 1516 	mov	ar1,r6
      006147 B9 21 02         [24] 1517 	cjne	r1,#0x21,01212$
      00614A 80 09            [24] 1518 	sjmp	00301$
      00614C                       1519 01212$:
      00614C B9 22 02         [24] 1520 	cjne	r1,#0x22,01213$
      00614F 80 04            [24] 1521 	sjmp	00301$
      006151                       1522 01213$:
                                   1523 ;	assignBit
      006151 C2 1C            [12] 1524 	clr	_control_setup_sloc2_1_0
      006153 80 02            [24] 1525 	sjmp	00302$
      006155                       1526 00301$:
                                   1527 ;	assignBit
      006155 D2 1C            [12] 1528 	setb	_control_setup_sloc2_1_0
      006157                       1529 00302$:
      006157 E4               [12] 1530 	clr	a
      006158 BF 81 01         [24] 1531 	cjne	r7,#0x81,01214$
      00615B 04               [12] 1532 	inc	a
      00615C                       1533 01214$:
      00615C FA               [12] 1534 	mov	r2,a
      00615D A2 1C            [12] 1535 	mov	c,_control_setup_sloc2_1_0
      00615F E4               [12] 1536 	clr	a
      006160 33               [12] 1537 	rlc	a
      006161 B5 02 02         [24] 1538 	cjne	a,ar2,01216$
      006164 80 03            [24] 1539 	sjmp	00105$
      006166                       1540 01216$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      006166 02 5E 49         [24] 1542 	ljmp	_control_stall
      006169                       1543 00105$:
                                   1544 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      006169 8E 02            [24] 1545 	mov	ar2,r6
      00616B 90 08 20         [24] 1546 	mov	dptr,#_descriptor_select_PARM_2
      00616E ED               [12] 1547 	mov	a,r5
      00616F F0               [24] 1548 	movx	@dptr,a
      006170 90 08 21         [24] 1549 	mov	dptr,#_descriptor_select_PARM_3
      006173 EB               [12] 1550 	mov	a,r3
      006174 F0               [24] 1551 	movx	@dptr,a
      006175 EC               [12] 1552 	mov	a,r4
      006176 A3               [24] 1553 	inc	dptr
      006177 F0               [24] 1554 	movx	@dptr,a
      006178 8A 82            [24] 1555 	mov	dpl, r2
      00617A 12 5E E7         [24] 1556 	lcall	_descriptor_select
      00617D 85 82 17         [24] 1557 	mov	_control_setup_sloc3_1_0,dpl
      006180 85 83 18         [24] 1558 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1559 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      006183 E5 17            [12] 1560 	mov	a,_control_setup_sloc3_1_0
      006185 45 18            [12] 1561 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006187 70 03            [24] 1562 	jnz	00107$
      006189 02 5E 49         [24] 1563 	ljmp	_control_stall
      00618C                       1564 00107$:
                                   1565 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00618C 90 07 BC         [24] 1566 	mov	dptr,#_D0SetupLen
      00618F E0               [24] 1567 	movx	a,@dptr
      006190 F8               [12] 1568 	mov	r0,a
      006191 A3               [24] 1569 	inc	dptr
      006192 E0               [24] 1570 	movx	a,@dptr
      006193 FA               [12] 1571 	mov	r2,a
      006194 C3               [12] 1572 	clr	c
      006195 E5 17            [12] 1573 	mov	a,_control_setup_sloc3_1_0
      006197 98               [12] 1574 	subb	a,r0
      006198 E5 18            [12] 1575 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00619A 9A               [12] 1576 	subb	a,r2
      00619B 50 06            [24] 1577 	jnc	00303$
      00619D E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      00619F 54 3F            [12] 1579 	anl	a,#0x3f
      0061A1 60 04            [24] 1580 	jz	00304$
      0061A3                       1581 00303$:
                                   1582 ;	assignBit
      0061A3 C2 1C            [12] 1583 	clr	_control_setup_sloc2_1_0
      0061A5 80 02            [24] 1584 	sjmp	00305$
      0061A7                       1585 00304$:
                                   1586 ;	assignBit
      0061A7 D2 1C            [12] 1587 	setb	_control_setup_sloc2_1_0
      0061A9                       1588 00305$:
      0061A9 90 08 1D         [24] 1589 	mov	dptr,#_control_zlp
      0061AC A2 1C            [12] 1590 	mov	c,_control_setup_sloc2_1_0
      0061AE E4               [12] 1591 	clr	a
      0061AF 33               [12] 1592 	rlc	a
      0061B0 F0               [24] 1593 	movx	@dptr,a
                                   1594 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      0061B1 90 07 BC         [24] 1595 	mov	dptr,#_D0SetupLen
      0061B4 E0               [24] 1596 	movx	a,@dptr
      0061B5 F9               [12] 1597 	mov	r1,a
      0061B6 A3               [24] 1598 	inc	dptr
      0061B7 E0               [24] 1599 	movx	a,@dptr
      0061B8 FA               [12] 1600 	mov	r2,a
      0061B9 C3               [12] 1601 	clr	c
      0061BA E5 17            [12] 1602 	mov	a,_control_setup_sloc3_1_0
      0061BC 99               [12] 1603 	subb	a,r1
      0061BD E5 18            [12] 1604 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061BF 9A               [12] 1605 	subb	a,r2
      0061C0 50 0A            [24] 1606 	jnc	00109$
                                   1607 ;	free result
      0061C2 90 07 BC         [24] 1608 	mov	dptr,#_D0SetupLen
      0061C5 E5 17            [12] 1609 	mov	a,_control_setup_sloc3_1_0
      0061C7 F0               [24] 1610 	movx	@dptr,a
      0061C8 E5 18            [12] 1611 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0061CA A3               [24] 1612 	inc	dptr
      0061CB F0               [24] 1613 	movx	@dptr,a
      0061CC                       1614 00109$:
                                   1615 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0061CC 90 07 BC         [24] 1616 	mov	dptr,#_D0SetupLen
      0061CF E0               [24] 1617 	movx	a,@dptr
      0061D0 F9               [12] 1618 	mov	r1,a
      0061D1 A3               [24] 1619 	inc	dptr
      0061D2 E0               [24] 1620 	movx	a,@dptr
      0061D3 49               [12] 1621 	orl	a,r1
      0061D4 60 04            [24] 1622 	jz	00306$
      0061D6 7A 01            [12] 1623 	mov	r2,#0x01
      0061D8 80 02            [24] 1624 	sjmp	00307$
      0061DA                       1625 00306$:
      0061DA 7A 02            [12] 1626 	mov	r2,#0x02
      0061DC                       1627 00307$:
      0061DC 90 08 1A         [24] 1628 	mov	dptr,#_control_phase
      0061DF EA               [12] 1629 	mov	a,r2
      0061E0 F0               [24] 1630 	movx	@dptr,a
                                   1631 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      0061E1 90 07 BC         [24] 1632 	mov	dptr,#_D0SetupLen
      0061E4 E0               [24] 1633 	movx	a,@dptr
      0061E5 F9               [12] 1634 	mov	r1,a
      0061E6 A3               [24] 1635 	inc	dptr
      0061E7 E0               [24] 1636 	movx	a,@dptr
      0061E8 49               [12] 1637 	orl	a,r1
      0061E9 60 03            [24] 1638 	jz	00111$
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      0061EB 02 5E 6B         [24] 1640 	ljmp	_control_next
      0061EE                       1641 00111$:
      0061EE 22               [24] 1642 	ret
                                   1643 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      0061EF 02 5E 49         [24] 1644 	ljmp	_control_stall
                                   1645 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      0061F2                       1646 00116$:
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0061F2 EF               [12] 1648 	mov	a,r7
      0061F3 70 23            [24] 1649 	jnz	00118$
      0061F5 30 18 20         [24] 1650 	jnb	_control_setup_zero_index_10000_287,00118$
      0061F8 30 1A 1D         [24] 1651 	jnb	_control_setup_zero_length_10000_287,00118$
      0061FB 8D 01            [24] 1652 	mov	ar1,r5
      0061FD 8E 02            [24] 1653 	mov	ar2,r6
      0061FF C3               [12] 1654 	clr	c
      006200 74 7F            [12] 1655 	mov	a,#0x7f
      006202 99               [12] 1656 	subb	a,r1
      006203 E4               [12] 1657 	clr	a
      006204 9A               [12] 1658 	subb	a,r2
      006205 40 11            [24] 1659 	jc	00118$
                                   1660 ;	free result
                                   1661 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      006207 90 07 BC         [24] 1662 	mov	dptr,#_D0SetupLen
      00620A ED               [12] 1663 	mov	a,r5
      00620B F0               [24] 1664 	movx	@dptr,a
      00620C EE               [12] 1665 	mov	a,r6
      00620D A3               [24] 1666 	inc	dptr
      00620E F0               [24] 1667 	movx	@dptr,a
                                   1668 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      00620F 90 08 1A         [24] 1669 	mov	dptr,#_control_phase
      006212 74 03            [12] 1670 	mov	a,#0x03
      006214 F0               [24] 1671 	movx	@dptr,a
      006215 02 67 F8         [24] 1672 	ljmp	00291$
      006218                       1673 00118$:
                                   1674 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      006218 02 5E 49         [24] 1675 	ljmp	_control_stall
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00621B                       1677 00123$:
                                   1678 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00621B EF               [12] 1679 	mov	a,r7
      00621C 70 3C            [24] 1680 	jnz	00145$
      00621E 30 18 39         [24] 1681 	jnb	_control_setup_zero_index_10000_287,00145$
      006221 30 1A 36         [24] 1682 	jnb	_control_setup_zero_length_10000_287,00145$
      006224 8D 01            [24] 1683 	mov	ar1,r5
      006226 8E 02            [24] 1684 	mov	ar2,r6
      006228 C3               [12] 1685 	clr	c
      006229 74 01            [12] 1686 	mov	a,#0x01
      00622B 99               [12] 1687 	subb	a,r1
      00622C E4               [12] 1688 	clr	a
      00622D 9A               [12] 1689 	subb	a,r2
      00622E 40 2A            [24] 1690 	jc	00145$
                                   1691 ;	free result
                                   1692 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      006230 C0 06            [24] 1693 	push	ar6
      006232 C0 05            [24] 1694 	push	ar5
      006234 12 5D F2         [24] 1695 	lcall	_endpoints_reset
      006237 D0 05            [24] 1696 	pop	ar5
      006239 D0 06            [24] 1697 	pop	ar6
                                   1698 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      00623B 90 07 C1         [24] 1699 	mov	dptr,#_D0UsbConfig
      00623E ED               [12] 1700 	mov	a,r5
      00623F F0               [24] 1701 	movx	@dptr,a
                                   1702 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      006240 A2 1B            [12] 1703 	mov	c,_control_setup_sloc0_1_0
      006242 B3               [12] 1704 	cpl	c
      006243 92 1C            [24] 1705 	mov	_control_setup_sloc2_1_0,c
      006245 90 07 C2         [24] 1706 	mov	dptr,#_USB_EnumStatus
      006248 E4               [12] 1707 	clr	a
      006249 33               [12] 1708 	rlc	a
      00624A F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      00624B 90 07 EB         [24] 1711 	mov	dptr,#_keyboard_reset
      00624E 74 01            [12] 1712 	mov	a,#0x01
      006250 F0               [24] 1713 	movx	@dptr,a
                                   1714 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      006251 90 08 1A         [24] 1715 	mov	dptr,#_control_phase
      006254 74 03            [12] 1716 	mov	a,#0x03
      006256 F0               [24] 1717 	movx	@dptr,a
      006257 02 67 F8         [24] 1718 	ljmp	00291$
      00625A                       1719 00145$:
                                   1720 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      00625A BF 21 02         [24] 1721 	cjne	r7,#0x21,01231$
      00625D 80 03            [24] 1722 	sjmp	01232$
      00625F                       1723 01231$:
      00625F 02 5E 49         [24] 1724 	ljmp	_control_stall
      006262                       1725 01232$:
      006262 90 07 C1         [24] 1726 	mov	dptr,#_D0UsbConfig
      006265 E0               [24] 1727 	movx	a,@dptr
      006266 70 03            [24] 1728 	jnz	01233$
      006268 02 5E 49         [24] 1729 	ljmp	_control_stall
      00626B                       1730 01233$:
                                   1731 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00626B BB 01 2D         [24] 1732 	cjne	r3,#0x01,00135$
      00626E BC 00 2A         [24] 1733 	cjne	r4,#0x00,00135$
      006271 8D 01            [24] 1734 	mov	ar1,r5
      006273 8E 02            [24] 1735 	mov	ar2,r6
      006275 B9 00 23         [24] 1736 	cjne	r1,#0x00,00135$
      006278 BA 02 20         [24] 1737 	cjne	r2,#0x02,00135$
      00627B 90 07 BC         [24] 1738 	mov	dptr,#_D0SetupLen
      00627E E0               [24] 1739 	movx	a,@dptr
      00627F F9               [12] 1740 	mov	r1,a
      006280 A3               [24] 1741 	inc	dptr
      006281 E0               [24] 1742 	movx	a,@dptr
      006282 FA               [12] 1743 	mov	r2,a
      006283 B9 20 15         [24] 1744 	cjne	r1,#0x20,00135$
      006286 BA 00 12         [24] 1745 	cjne	r2,#0x00,00135$
      006289 90 07 C9         [24] 1746 	mov	dptr,#_raw_state
      00628C E0               [24] 1747 	movx	a,@dptr
      00628D 70 0C            [24] 1748 	jnz	00135$
                                   1749 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      00628F 90 07 C9         [24] 1750 	mov	dptr,#_raw_state
      006292 74 01            [12] 1751 	mov	a,#0x01
      006294 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      006295 90 08 1B         [24] 1754 	mov	dptr,#_output_kind
      006298 F0               [24] 1755 	movx	@dptr,a
      006299 80 52            [24] 1756 	sjmp	00136$
      00629B                       1757 00135$:
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      00629B EB               [12] 1759 	mov	a,r3
      00629C 4C               [12] 1760 	orl	a,r4
      00629D 70 20            [24] 1761 	jnz	00130$
      00629F 8D 01            [24] 1762 	mov	ar1,r5
      0062A1 8E 02            [24] 1763 	mov	ar2,r6
      0062A3 B9 00 19         [24] 1764 	cjne	r1,#0x00,00130$
      0062A6 BA 02 16         [24] 1765 	cjne	r2,#0x02,00130$
      0062A9 90 07 BC         [24] 1766 	mov	dptr,#_D0SetupLen
      0062AC E0               [24] 1767 	movx	a,@dptr
      0062AD F9               [12] 1768 	mov	r1,a
      0062AE A3               [24] 1769 	inc	dptr
      0062AF E0               [24] 1770 	movx	a,@dptr
      0062B0 FA               [12] 1771 	mov	r2,a
      0062B1 B9 01 0B         [24] 1772 	cjne	r1,#0x01,00130$
      0062B4 BA 00 08         [24] 1773 	cjne	r2,#0x00,00130$
                                   1774 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      0062B7 90 08 1B         [24] 1775 	mov	dptr,#_output_kind
      0062BA 74 02            [12] 1776 	mov	a,#0x02
      0062BC F0               [24] 1777 	movx	@dptr,a
      0062BD 80 2E            [24] 1778 	sjmp	00136$
      0062BF                       1779 00130$:
                                   1780 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0062BF BB 02 28         [24] 1781 	cjne	r3,#0x02,00125$
      0062C2 BC 00 25         [24] 1782 	cjne	r4,#0x00,00125$
      0062C5 8D 01            [24] 1783 	mov	ar1,r5
      0062C7 8E 02            [24] 1784 	mov	ar2,r6
      0062C9 B9 06 1E         [24] 1785 	cjne	r1,#0x06,00125$
      0062CC BA 02 1B         [24] 1786 	cjne	r2,#0x02,00125$
      0062CF 90 07 BC         [24] 1787 	mov	dptr,#_D0SetupLen
      0062D2 E0               [24] 1788 	movx	a,@dptr
      0062D3 F9               [12] 1789 	mov	r1,a
      0062D4 A3               [24] 1790 	inc	dptr
      0062D5 E0               [24] 1791 	movx	a,@dptr
      0062D6 FA               [12] 1792 	mov	r2,a
      0062D7 B9 02 10         [24] 1793 	cjne	r1,#0x02,00125$
      0062DA BA 00 0D         [24] 1794 	cjne	r2,#0x00,00125$
                                   1795 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      0062DD 90 08 1B         [24] 1796 	mov	dptr,#_output_kind
      0062E0 74 03            [12] 1797 	mov	a,#0x03
      0062E2 F0               [24] 1798 	movx	@dptr,a
                                   1799 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      0062E3 90 08 1C         [24] 1800 	mov	dptr,#_output_report_id
      0062E6 23               [12] 1801 	rl	a
      0062E7 F0               [24] 1802 	movx	@dptr,a
      0062E8 80 03            [24] 1803 	sjmp	00136$
      0062EA                       1804 00125$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      0062EA 02 5E 49         [24] 1806 	ljmp	_control_stall
      0062ED                       1807 00136$:
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      0062ED 90 08 1A         [24] 1809 	mov	dptr,#_control_phase
      0062F0 74 04            [12] 1810 	mov	a,#0x04
      0062F2 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      0062F3 22               [24] 1813 	ret
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      0062F4 02 5E 49         [24] 1815 	ljmp	_control_stall
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      0062F7                       1817 00150$:
                                   1818 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0062F7 BF 80 2A         [24] 1819 	cjne	r7,#0x80,00152$
      0062FA 30 18 27         [24] 1820 	jnb	_control_setup_zero_index_10000_287,00152$
      0062FD 30 19 24         [24] 1821 	jnb	_control_setup_zero_value_10000_287,00152$
      006300 90 07 BC         [24] 1822 	mov	dptr,#_D0SetupLen
      006303 E0               [24] 1823 	movx	a,@dptr
      006304 F9               [12] 1824 	mov	r1,a
      006305 A3               [24] 1825 	inc	dptr
      006306 E0               [24] 1826 	movx	a,@dptr
      006307 FA               [12] 1827 	mov	r2,a
      006308 B9 01 19         [24] 1828 	cjne	r1,#0x01,00152$
      00630B BA 00 16         [24] 1829 	cjne	r2,#0x00,00152$
                                   1830 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      00630E 90 07 C1         [24] 1831 	mov	dptr,#_D0UsbConfig
      006311 E0               [24] 1832 	movx	a,@dptr
      006312 90 10 00         [24] 1833 	mov	dptr,#0x1000
      006315 F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      006316 90 22 08         [24] 1836 	mov	dptr,#0x2208
      006319 74 01            [12] 1837 	mov	a,#0x01
      00631B F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      00631C 90 08 1A         [24] 1840 	mov	dptr,#_control_phase
      00631F 04               [12] 1841 	inc	a
      006320 F0               [24] 1842 	movx	@dptr,a
      006321 02 67 F8         [24] 1843 	ljmp	00291$
      006324                       1844 00152$:
                                   1845 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      006324 02 5E 49         [24] 1846 	ljmp	_control_stall
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006327                       1848 00157$:
                                   1849 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006327 BF 81 2C         [24] 1850 	cjne	r7,#0x81,00167$
      00632A 30 17 29         [24] 1851 	jnb	_control_setup_valid_interface_10000_287,00167$
      00632D 30 19 26         [24] 1852 	jnb	_control_setup_zero_value_10000_287,00167$
      006330 90 07 BC         [24] 1853 	mov	dptr,#_D0SetupLen
      006333 E0               [24] 1854 	movx	a,@dptr
      006334 F9               [12] 1855 	mov	r1,a
      006335 A3               [24] 1856 	inc	dptr
      006336 E0               [24] 1857 	movx	a,@dptr
      006337 FA               [12] 1858 	mov	r2,a
      006338 B9 01 1B         [24] 1859 	cjne	r1,#0x01,00167$
      00633B BA 00 18         [24] 1860 	cjne	r2,#0x00,00167$
      00633E 90 07 C1         [24] 1861 	mov	dptr,#_D0UsbConfig
      006341 E0               [24] 1862 	movx	a,@dptr
      006342 60 12            [24] 1863 	jz	00167$
                                   1864 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      006344 90 10 00         [24] 1865 	mov	dptr,#0x1000
      006347 E4               [12] 1866 	clr	a
      006348 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      006349 90 22 08         [24] 1869 	mov	dptr,#0x2208
      00634C 04               [12] 1870 	inc	a
      00634D F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      00634E 90 08 1A         [24] 1873 	mov	dptr,#_control_phase
      006351 04               [12] 1874 	inc	a
      006352 F0               [24] 1875 	movx	@dptr,a
      006353 02 67 F8         [24] 1876 	ljmp	00291$
      006356                       1877 00167$:
                                   1878 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006356 30 17 1E         [24] 1879 	jnb	_control_setup_valid_interface_10000_287,00161$
      006359 90 07 C1         [24] 1880 	mov	dptr,#_D0UsbConfig
      00635C E0               [24] 1881 	movx	a,@dptr
      00635D 60 18            [24] 1882 	jz	00161$
      00635F BF 21 15         [24] 1883 	cjne	r7,#0x21,00161$
      006362 30 1A 12         [24] 1884 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1885 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006365 EB               [12] 1886 	mov	a,r3
      006366 4C               [12] 1887 	orl	a,r4
      006367 70 05            [24] 1888 	jnz	00159$
      006369 90 06 99         [24] 1889 	mov	dptr,#_keyboard_idle
      00636C EE               [12] 1890 	mov	a,r6
      00636D F0               [24] 1891 	movx	@dptr,a
      00636E                       1892 00159$:
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      00636E 90 08 1A         [24] 1894 	mov	dptr,#_control_phase
      006371 74 03            [12] 1895 	mov	a,#0x03
      006373 F0               [24] 1896 	movx	@dptr,a
      006374 02 67 F8         [24] 1897 	ljmp	00291$
      006377                       1898 00161$:
                                   1899 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      006377 02 5E 49         [24] 1900 	ljmp	_control_stall
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00637A                       1902 00173$:
                                   1903 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00637A BF 01 18         [24] 1904 	cjne	r7,#0x01,00182$
      00637D 30 17 15         [24] 1905 	jnb	_control_setup_valid_interface_10000_287,00182$
      006380 30 19 12         [24] 1906 	jnb	_control_setup_zero_value_10000_287,00182$
      006383 30 1A 0F         [24] 1907 	jnb	_control_setup_zero_length_10000_287,00182$
      006386 90 07 C1         [24] 1908 	mov	dptr,#_D0UsbConfig
      006389 E0               [24] 1909 	movx	a,@dptr
      00638A 60 09            [24] 1910 	jz	00182$
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      00638C 90 08 1A         [24] 1912 	mov	dptr,#_control_phase
      00638F 74 03            [12] 1913 	mov	a,#0x03
      006391 F0               [24] 1914 	movx	@dptr,a
      006392 02 67 F8         [24] 1915 	ljmp	00291$
      006395                       1916 00182$:
                                   1917 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006395 EB               [12] 1918 	mov	a,r3
      006396 4C               [12] 1919 	orl	a,r4
      006397 70 2C            [24] 1920 	jnz	00175$
      006399 90 07 C1         [24] 1921 	mov	dptr,#_D0UsbConfig
      00639C E0               [24] 1922 	movx	a,@dptr
      00639D 60 26            [24] 1923 	jz	00175$
      00639F BF 21 23         [24] 1924 	cjne	r7,#0x21,00175$
      0063A2 30 1A 20         [24] 1925 	jnb	_control_setup_zero_length_10000_287,00175$
      0063A5 8D 01            [24] 1926 	mov	ar1,r5
      0063A7 8E 02            [24] 1927 	mov	ar2,r6
      0063A9 C3               [12] 1928 	clr	c
      0063AA 74 01            [12] 1929 	mov	a,#0x01
      0063AC 99               [12] 1930 	subb	a,r1
      0063AD E4               [12] 1931 	clr	a
      0063AE 9A               [12] 1932 	subb	a,r2
      0063AF 40 14            [24] 1933 	jc	00175$
                                   1934 ;	free result
                                   1935 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      0063B1 90 0E 0C         [24] 1936 	mov	dptr,#_keyboard_protocol
      0063B4 ED               [12] 1937 	mov	a,r5
      0063B5 F0               [24] 1938 	movx	@dptr,a
                                   1939 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      0063B6 90 07 EB         [24] 1940 	mov	dptr,#_keyboard_reset
      0063B9 74 01            [12] 1941 	mov	a,#0x01
      0063BB F0               [24] 1942 	movx	@dptr,a
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      0063BC 90 08 1A         [24] 1944 	mov	dptr,#_control_phase
      0063BF 74 03            [12] 1945 	mov	a,#0x03
      0063C1 F0               [24] 1946 	movx	@dptr,a
      0063C2 02 67 F8         [24] 1947 	ljmp	00291$
      0063C5                       1948 00175$:
                                   1949 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      0063C5 02 5E 49         [24] 1950 	ljmp	_control_stall
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      0063C8                       1952 00188$:
                                   1953 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      0063C8 20 19 03         [24] 1954 	jb	_control_setup_zero_value_10000_287,01283$
      0063CB 02 5E 49         [24] 1955 	ljmp	_control_stall
      0063CE                       1956 01283$:
      0063CE 90 07 BC         [24] 1957 	mov	dptr,#_D0SetupLen
      0063D1 E0               [24] 1958 	movx	a,@dptr
      0063D2 F9               [12] 1959 	mov	r1,a
      0063D3 A3               [24] 1960 	inc	dptr
      0063D4 E0               [24] 1961 	movx	a,@dptr
      0063D5 FA               [12] 1962 	mov	r2,a
      0063D6 B9 02 05         [24] 1963 	cjne	r1,#0x02,01284$
      0063D9 BA 00 02         [24] 1964 	cjne	r2,#0x00,01284$
      0063DC 80 03            [24] 1965 	sjmp	01285$
      0063DE                       1966 01284$:
      0063DE 02 5E 49         [24] 1967 	ljmp	_control_stall
      0063E1                       1968 01285$:
                                   1969 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0063E1 E4               [12] 1970 	clr	a
      0063E2 BF 80 01         [24] 1971 	cjne	r7,#0x80,01286$
      0063E5 04               [12] 1972 	inc	a
      0063E6                       1973 01286$:
      0063E6 FA               [12] 1974 	mov	r2,a
      0063E7 60 03            [24] 1975 	jz	00196$
      0063E9 20 18 35         [24] 1976 	jb	_control_setup_zero_index_10000_287,00189$
      0063EC                       1977 00196$:
      0063EC BF 81 09         [24] 1978 	cjne	r7,#0x81,00202$
      0063EF 30 17 06         [24] 1979 	jnb	_control_setup_valid_interface_10000_287,00202$
      0063F2 90 07 C1         [24] 1980 	mov	dptr,#_D0UsbConfig
      0063F5 E0               [24] 1981 	movx	a,@dptr
      0063F6 70 29            [24] 1982 	jnz	00189$
      0063F8                       1983 00202$:
                                   1984 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0063F8 BF 82 70         [24] 1985 	cjne	r7,#0x82,00190$
      0063FB 90 07 C1         [24] 1986 	mov	dptr,#_D0UsbConfig
      0063FE E0               [24] 1987 	movx	a,@dptr
      0063FF 60 6A            [24] 1988 	jz	00190$
      006401 EB               [12] 1989 	mov	a,r3
      006402 4C               [12] 1990 	orl	a,r4
      006403 60 1C            [24] 1991 	jz	00189$
      006405 8B 00            [24] 1992 	mov	ar0,r3
      006407 8C 01            [24] 1993 	mov	ar1,r4
      006409 B8 80 05         [24] 1994 	cjne	r0,#0x80,01298$
      00640C B9 00 02         [24] 1995 	cjne	r1,#0x00,01298$
      00640F 80 10            [24] 1996 	sjmp	00189$
      006411                       1997 01298$:
      006411 C3               [12] 1998 	clr	c
      006412 E8               [12] 1999 	mov	a,r0
      006413 94 81            [12] 2000 	subb	a,#0x81
      006415 E9               [12] 2001 	mov	a,r1
      006416 94 00            [12] 2002 	subb	a,#0x00
      006418 40 51            [24] 2003 	jc	00190$
      00641A 74 83            [12] 2004 	mov	a,#0x83
      00641C 98               [12] 2005 	subb	a,r0
      00641D E4               [12] 2006 	clr	a
      00641E 99               [12] 2007 	subb	a,r1
      00641F 40 4A            [24] 2008 	jc	00190$
                                   2009 ;	free result
      006421                       2010 00189$:
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      006421 8B 01            [24] 2012 	mov	ar1,r3
      006423 53 01 07         [24] 2013 	anl	ar1,#0x07
                                   2014 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006426 EA               [12] 2015 	mov	a,r2
      006427 60 0B            [24] 2016 	jz	00308$
      006429 90 07 C3         [24] 2017 	mov	dptr,#_USB_SleepStatus
      00642C E0               [24] 2018 	movx	a,@dptr
      00642D 54 01            [12] 2019 	anl	a,#0x01
      00642F 25 E0            [12] 2020 	add	a,acc
      006431 FA               [12] 2021 	mov	r2,a
      006432 80 22            [24] 2022 	sjmp	00309$
      006434                       2023 00308$:
                                   2024 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006434 BF 82 1B         [24] 2025 	cjne	r7,#0x82,00310$
      006437 E9               [12] 2026 	mov	a,r1
      006438 60 18            [24] 2027 	jz	00310$
      00643A 89 00            [24] 2028 	mov	ar0,r1
      00643C 79 00            [12] 2029 	mov	r1,#0x00
      00643E 74 22            [12] 2030 	mov	a,#0x22
      006440 29               [12] 2031 	add	a, r1
      006441 F9               [12] 2032 	mov	r1,a
      006442 88 82            [24] 2033 	mov	dpl,r0
      006444 89 83            [24] 2034 	mov	dph,r1
      006446 E0               [24] 2035 	movx	a,@dptr
      006447 F9               [12] 2036 	mov	r1,a
      006448 53 01 03         [24] 2037 	anl	ar1,#0x03
      00644B B9 03 04         [24] 2038 	cjne	r1,#0x03,00310$
      00644E 79 01            [12] 2039 	mov	r1,#0x01
      006450 80 02            [24] 2040 	sjmp	00311$
      006452                       2041 00310$:
      006452 79 00            [12] 2042 	mov	r1,#0x00
      006454                       2043 00311$:
      006454 89 02            [24] 2044 	mov	ar2,r1
      006456                       2045 00309$:
      006456 90 10 00         [24] 2046 	mov	dptr,#0x1000
      006459 EA               [12] 2047 	mov	a,r2
      00645A F0               [24] 2048 	movx	@dptr,a
                                   2049 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      00645B A3               [24] 2050 	inc	dptr
      00645C E4               [12] 2051 	clr	a
      00645D F0               [24] 2052 	movx	@dptr,a
                                   2053 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      00645E 90 22 08         [24] 2054 	mov	dptr,#0x2208
      006461 74 02            [12] 2055 	mov	a,#0x02
      006463 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      006464 90 08 1A         [24] 2058 	mov	dptr,#_control_phase
      006467 F0               [24] 2059 	movx	@dptr,a
      006468 02 67 F8         [24] 2060 	ljmp	00291$
      00646B                       2061 00190$:
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      00646B 02 5E 49         [24] 2063 	ljmp	_control_stall
                                   2064 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00646E                       2065 00205$:
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      00646E 20 1A 03         [24] 2067 	jb	_control_setup_zero_length_10000_287,01307$
      006471 02 65 01         [24] 2068 	ljmp	00279$
      006474                       2069 01307$:
      006474 90 07 C1         [24] 2070 	mov	dptr,#_D0UsbConfig
      006477 E0               [24] 2071 	movx	a,@dptr
      006478 70 03            [24] 2072 	jnz	01308$
      00647A 02 65 01         [24] 2073 	ljmp	00279$
      00647D                       2074 01308$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      00647D EF               [12] 2076 	mov	a,r7
      00647E 70 29            [24] 2077 	jnz	00218$
      006480 8D 01            [24] 2078 	mov	ar1,r5
      006482 8E 02            [24] 2079 	mov	ar2,r6
      006484 B9 01 22         [24] 2080 	cjne	r1,#0x01,00218$
      006487 BA 00 1F         [24] 2081 	cjne	r2,#0x00,00218$
      00648A 30 18 1C         [24] 2082 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00648D 90 07 BB         [24] 2084 	mov	dptr,#_D0SetupReqCode
      006490 E0               [24] 2085 	movx	a,@dptr
      006491 FA               [12] 2086 	mov	r2,a
      006492 BA 03 0A         [24] 2087 	cjne	r2,#0x03,00207$
      006495 90 07 C3         [24] 2088 	mov	dptr,#_USB_SleepStatus
      006498 E0               [24] 2089 	movx	a,@dptr
      006499 43 E0 01         [24] 2090 	orl	acc,#0x01
      00649C F0               [24] 2091 	movx	@dptr,a
      00649D 80 59            [24] 2092 	sjmp	00219$
      00649F                       2093 00207$:
                                   2094 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      00649F 90 07 C3         [24] 2095 	mov	dptr,#_USB_SleepStatus
      0064A2 E0               [24] 2096 	movx	a,@dptr
      0064A3 53 E0 FE         [24] 2097 	anl	acc,#0xfe
      0064A6 F0               [24] 2098 	movx	@dptr,a
      0064A7 80 4F            [24] 2099 	sjmp	00219$
      0064A9                       2100 00218$:
                                   2101 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0064A9 BF 02 49         [24] 2102 	cjne	r7,#0x02,00212$
      0064AC 30 19 46         [24] 2103 	jnb	_control_setup_zero_value_10000_287,00212$
      0064AF 8B 01            [24] 2104 	mov	ar1,r3
      0064B1 8C 02            [24] 2105 	mov	ar2,r4
      0064B3 C3               [12] 2106 	clr	c
      0064B4 E9               [12] 2107 	mov	a,r1
      0064B5 94 81            [12] 2108 	subb	a,#0x81
      0064B7 EA               [12] 2109 	mov	a,r2
      0064B8 94 00            [12] 2110 	subb	a,#0x00
      0064BA 40 39            [24] 2111 	jc	00212$
      0064BC 74 83            [12] 2112 	mov	a,#0x83
      0064BE 99               [12] 2113 	subb	a,r1
      0064BF E4               [12] 2114 	clr	a
      0064C0 9A               [12] 2115 	subb	a,r2
      0064C1 40 32            [24] 2116 	jc	00212$
                                   2117 ;	free result
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      0064C3 8B 02            [24] 2119 	mov	ar2,r3
      0064C5 53 02 07         [24] 2120 	anl	ar2,#0x07
                                   2121 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0064C8 8A 00            [24] 2122 	mov	ar0,r2
      0064CA 79 00            [12] 2123 	mov	r1,#0x00
      0064CC 74 22            [12] 2124 	mov	a,#0x22
      0064CE 29               [12] 2125 	add	a, r1
      0064CF F9               [12] 2126 	mov	r1,a
      0064D0 88 17            [24] 2127 	mov	_control_setup_sloc3_1_0,r0
      0064D2 89 18            [24] 2128 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0064D4 90 07 BB         [24] 2129 	mov	dptr,#_D0SetupReqCode
      0064D7 E0               [24] 2130 	movx	a,@dptr
      0064D8 F9               [12] 2131 	mov	r1,a
      0064D9 B9 03 04         [24] 2132 	cjne	r1,#0x03,00318$
      0064DC 79 03            [12] 2133 	mov	r1,#0x03
      0064DE 80 02            [24] 2134 	sjmp	00319$
      0064E0                       2135 00318$:
      0064E0 79 02            [12] 2136 	mov	r1,#0x02
      0064E2                       2137 00319$:
      0064E2 43 01 10         [24] 2138 	orl	ar1,#0x10
      0064E5 85 17 82         [24] 2139 	mov	dpl,_control_setup_sloc3_1_0
      0064E8 85 18 83         [24] 2140 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0064EB E9               [12] 2141 	mov	a,r1
      0064EC F0               [24] 2142 	movx	@dptr,a
                                   2143 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0064ED BA 03 08         [24] 2144 	cjne	r2,#0x03,00219$
      0064F0 12 5D D5         [24] 2145 	lcall	_raw_complete
      0064F3 80 03            [24] 2146 	sjmp	00219$
      0064F5                       2147 00212$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      0064F5 02 5E 49         [24] 2149 	ljmp	_control_stall
      0064F8                       2150 00219$:
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      0064F8 90 08 1A         [24] 2152 	mov	dptr,#_control_phase
      0064FB 74 03            [12] 2153 	mov	a,#0x03
      0064FD F0               [24] 2154 	movx	@dptr,a
      0064FE 02 67 F8         [24] 2155 	ljmp	00291$
      006501                       2156 00279$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006501 E4               [12] 2158 	clr	a
      006502 BF A1 01         [24] 2159 	cjne	r7,#0xa1,01324$
      006505 04               [12] 2160 	inc	a
      006506                       2161 01324$:
      006506 FA               [12] 2162 	mov	r2,a
      006507 70 03            [24] 2163 	jnz	01326$
      006509 02 67 73         [24] 2164 	ljmp	00273$
      00650C                       2165 01326$:
      00650C 90 07 BB         [24] 2166 	mov	dptr,#_D0SetupReqCode
      00650F E0               [24] 2167 	movx	a,@dptr
      006510 F9               [12] 2168 	mov	r1,a
      006511 B9 01 02         [24] 2169 	cjne	r1,#0x01,01327$
      006514 80 03            [24] 2170 	sjmp	01328$
      006516                       2171 01327$:
      006516 02 67 73         [24] 2172 	ljmp	00273$
      006519                       2173 01328$:
      006519 90 07 C1         [24] 2174 	mov	dptr,#_D0UsbConfig
      00651C E0               [24] 2175 	movx	a,@dptr
      00651D 70 03            [24] 2176 	jnz	01329$
      00651F 02 67 73         [24] 2177 	ljmp	00273$
      006522                       2178 01329$:
      006522 90 07 BC         [24] 2179 	mov	dptr,#_D0SetupLen
      006525 E0               [24] 2180 	movx	a,@dptr
      006526 F8               [12] 2181 	mov	r0,a
      006527 A3               [24] 2182 	inc	dptr
      006528 E0               [24] 2183 	movx	a,@dptr
      006529 48               [12] 2184 	orl	a,r0
      00652A 70 03            [24] 2185 	jnz	01330$
      00652C 02 67 73         [24] 2186 	ljmp	00273$
      00652F                       2187 01330$:
                                   2188 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      00652F C0 03            [24] 2189 	push	ar3
      006531 C0 04            [24] 2190 	push	ar4
      006533 8D 01            [24] 2191 	mov	ar1,r5
                                   2192 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006535 8E 00            [24] 2193 	mov	ar0,r6
      006537 B8 01 03         [24] 2194 	cjne	r0,#0x01,01331$
      00653A E8               [12] 2195 	mov	a,r0
      00653B 80 01            [24] 2196 	sjmp	01332$
      00653D                       2197 01331$:
      00653D E4               [12] 2198 	clr	a
      00653E                       2199 01332$:
      00653E F5 17            [12] 2200 	mov	_control_setup_sloc3_1_0,a
      006540 D0 04            [24] 2201 	pop	ar4
      006542 D0 03            [24] 2202 	pop	ar3
      006544 E5 17            [12] 2203 	mov	a,_control_setup_sloc3_1_0
      006546 60 17            [24] 2204 	jz	00251$
      006548 EB               [12] 2205 	mov	a,r3
      006549 4C               [12] 2206 	orl	a,r4
      00654A 70 13            [24] 2207 	jnz	00251$
      00654C E9               [12] 2208 	mov	a,r1
      00654D 70 10            [24] 2209 	jnz	00251$
                                   2210 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      00654F 90 08 24         [24] 2211 	mov	dptr,#_control_setup_length_10000_287
      006552 74 08            [12] 2212 	mov	a,#0x08
      006554 F0               [24] 2213 	movx	@dptr,a
      006555 E4               [12] 2214 	clr	a
      006556 A3               [24] 2215 	inc	dptr
      006557 F0               [24] 2216 	movx	@dptr,a
                                   2217 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      006558 90 08 26         [24] 2218 	mov	dptr,#_control_setup_offset_10000_287
      00655B F0               [24] 2219 	movx	@dptr,a
      00655C 02 66 E3         [24] 2220 	ljmp	00252$
      00655F                       2221 00251$:
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00655F E5 17            [12] 2223 	mov	a,_control_setup_sloc3_1_0
      006561 60 27            [24] 2224 	jz	00245$
      006563 BB 02 24         [24] 2225 	cjne	r3,#0x02,00245$
      006566 BC 00 21         [24] 2226 	cjne	r4,#0x00,00245$
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006569 B9 07 00         [24] 2228 	cjne	r1,#0x07,01339$
      00656C                       2229 01339$:
      00656C 50 1C            [24] 2230 	jnc	00245$
      00656E E9               [12] 2231 	mov	a,r1
      00656F 90 BD A7         [24] 2232 	mov	dptr,#_shared_lengths
      006572 93               [24] 2233 	movc	a,@a+dptr
      006573 F8               [12] 2234 	mov	r0,a
      006574 60 14            [24] 2235 	jz	00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      006576 90 08 24         [24] 2237 	mov	dptr,#_control_setup_length_10000_287
      006579 E8               [12] 2238 	mov	a,r0
      00657A F0               [24] 2239 	movx	@dptr,a
      00657B E4               [12] 2240 	clr	a
      00657C A3               [24] 2241 	inc	dptr
      00657D F0               [24] 2242 	movx	@dptr,a
                                   2243 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      00657E E9               [12] 2244 	mov	a,r1
      00657F 90 BD A0         [24] 2245 	mov	dptr,#_shared_offsets
      006582 93               [24] 2246 	movc	a,@a+dptr
      006583 90 08 26         [24] 2247 	mov	dptr,#_control_setup_offset_10000_287
      006586 F0               [24] 2248 	movx	@dptr,a
      006587 02 66 E3         [24] 2249 	ljmp	00252$
      00658A                       2250 00245$:
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00658A E5 17            [12] 2252 	mov	a,_control_setup_sloc3_1_0
      00658C 60 7A            [24] 2253 	jz	00240$
      00658E BB 01 77         [24] 2254 	cjne	r3,#0x01,00240$
      006591 BC 00 74         [24] 2255 	cjne	r4,#0x00,00240$
      006594 E9               [12] 2256 	mov	a,r1
      006595 70 71            [24] 2257 	jnz	00240$
                                   2258 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006597 90 07 BC         [24] 2259 	mov	dptr,#_D0SetupLen
      00659A E0               [24] 2260 	movx	a,@dptr
      00659B F8               [12] 2261 	mov	r0,a
      00659C A3               [24] 2262 	inc	dptr
      00659D E0               [24] 2263 	movx	a,@dptr
      00659E F9               [12] 2264 	mov	r1,a
      00659F C3               [12] 2265 	clr	c
      0065A0 E8               [12] 2266 	mov	a,r0
      0065A1 94 20            [12] 2267 	subb	a,#0x20
      0065A3 E9               [12] 2268 	mov	a,r1
      0065A4 94 00            [12] 2269 	subb	a,#0x00
      0065A6 50 0A            [24] 2270 	jnc	00320$
      0065A8 90 07 BC         [24] 2271 	mov	dptr,#_D0SetupLen
      0065AB E0               [24] 2272 	movx	a,@dptr
      0065AC F8               [12] 2273 	mov	r0,a
      0065AD A3               [24] 2274 	inc	dptr
      0065AE E0               [24] 2275 	movx	a,@dptr
      0065AF F9               [12] 2276 	mov	r1,a
      0065B0 80 04            [24] 2277 	sjmp	00321$
      0065B2                       2278 00320$:
      0065B2 78 20            [12] 2279 	mov	r0,#0x20
      0065B4 79 00            [12] 2280 	mov	r1,#0x00
      0065B6                       2281 00321$:
                                   2282 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0065B6 75 17 00         [24] 2283 	mov	_control_setup_sloc3_1_0,#0x00
      0065B9                       2284 00293$:
      0065B9 C0 03            [24] 2285 	push	ar3
      0065BB C0 04            [24] 2286 	push	ar4
      0065BD AB 17            [24] 2287 	mov	r3,_control_setup_sloc3_1_0
      0065BF 7C 00            [12] 2288 	mov	r4,#0x00
      0065C1 C3               [12] 2289 	clr	c
      0065C2 EB               [12] 2290 	mov	a,r3
      0065C3 98               [12] 2291 	subb	a,r0
      0065C4 EC               [12] 2292 	mov	a,r4
      0065C5 99               [12] 2293 	subb	a,r1
      0065C6 D0 04            [24] 2294 	pop	ar4
      0065C8 D0 03            [24] 2295 	pop	ar3
      0065CA 50 32            [24] 2296 	jnc	00222$
      0065CC C0 00            [24] 2297 	push	ar0
      0065CE C0 01            [24] 2298 	push	ar1
      0065D0 85 17 19         [24] 2299 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0065D3 74 10            [12] 2300 	mov	a,#0x10
      0065D5 24 00            [12] 2301 	add	a, #0x00
      0065D7 F5 1A            [12] 2302 	mov	(_control_setup_sloc4_1_0 + 1),a
      0065D9 A8 17            [24] 2303 	mov	r0,_control_setup_sloc3_1_0
      0065DB 79 00            [12] 2304 	mov	r1,#0x00
      0065DD 74 C0            [12] 2305 	mov	a,#0xc0
      0065DF 28               [12] 2306 	add	a, r0
      0065E0 F8               [12] 2307 	mov	r0,a
      0065E1 E4               [12] 2308 	clr	a
      0065E2 39               [12] 2309 	addc	a, r1
      0065E3 F9               [12] 2310 	mov	r1,a
      0065E4 88 82            [24] 2311 	mov	dpl,r0
      0065E6 74 10            [12] 2312 	mov	a,#0x10
      0065E8 29               [12] 2313 	add	a, r1
      0065E9 F5 83            [12] 2314 	mov	dph,a
      0065EB E0               [24] 2315 	movx	a,@dptr
      0065EC 85 19 82         [24] 2316 	mov	dpl,_control_setup_sloc4_1_0
      0065EF 85 1A 83         [24] 2317 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0065F2 F0               [24] 2318 	movx	@dptr,a
      0065F3 E5 17            [12] 2319 	mov	a,_control_setup_sloc3_1_0
      0065F5 04               [12] 2320 	inc	a
      0065F6 F5 17            [12] 2321 	mov	_control_setup_sloc3_1_0,a
      0065F8 D0 01            [24] 2322 	pop	ar1
      0065FA D0 00            [24] 2323 	pop	ar0
      0065FC 80 BB            [24] 2324 	sjmp	00293$
      0065FE                       2325 00222$:
                                   2326 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      0065FE 90 08 24         [24] 2327 	mov	dptr,#_control_setup_length_10000_287
      006601 E4               [12] 2328 	clr	a
      006602 F0               [24] 2329 	movx	@dptr,a
      006603 A3               [24] 2330 	inc	dptr
      006604 F0               [24] 2331 	movx	@dptr,a
      006605 02 66 E3         [24] 2332 	ljmp	00252$
      006608                       2333 00240$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006608 8D 00            [24] 2335 	mov	ar0,r5
      00660A 8E 01            [24] 2336 	mov	ar1,r6
      00660C B8 00 21         [24] 2337 	cjne	r0,#0x00,00236$
      00660F B9 02 1E         [24] 2338 	cjne	r1,#0x02,00236$
      006612 EB               [12] 2339 	mov	a,r3
      006613 4C               [12] 2340 	orl	a,r4
      006614 70 1A            [24] 2341 	jnz	00236$
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006616 90 07 C6         [24] 2343 	mov	dptr,#_KB_USB_SetReport
      006619 E0               [24] 2344 	movx	a,@dptr
      00661A 90 10 00         [24] 2345 	mov	dptr,#0x1000
      00661D F0               [24] 2346 	movx	@dptr,a
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00661E 90 08 24         [24] 2348 	mov	dptr,#_control_setup_length_10000_287
      006621 E4               [12] 2349 	clr	a
      006622 F0               [24] 2350 	movx	@dptr,a
      006623 A3               [24] 2351 	inc	dptr
      006624 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006625 90 07 BC         [24] 2354 	mov	dptr,#_D0SetupLen
      006628 04               [12] 2355 	inc	a
      006629 F0               [24] 2356 	movx	@dptr,a
      00662A E4               [12] 2357 	clr	a
      00662B A3               [24] 2358 	inc	dptr
      00662C F0               [24] 2359 	movx	@dptr,a
      00662D 02 66 E3         [24] 2360 	ljmp	00252$
      006630                       2361 00236$:
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006630 B8 06 41         [24] 2363 	cjne	r0,#0x06,00232$
      006633 B9 02 3E         [24] 2364 	cjne	r1,#0x02,00232$
      006636 BB 02 3B         [24] 2365 	cjne	r3,#0x02,00232$
      006639 BC 00 38         [24] 2366 	cjne	r4,#0x00,00232$
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00663C C0 03            [24] 2368 	push	ar3
      00663E C0 04            [24] 2369 	push	ar4
      006640 90 10 00         [24] 2370 	mov	dptr,#0x1000
      006643 74 06            [12] 2371 	mov	a,#0x06
      006645 F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006646 90 07 C6         [24] 2374 	mov	dptr,#_KB_USB_SetReport
      006649 E0               [24] 2375 	movx	a,@dptr
      00664A 90 10 01         [24] 2376 	mov	dptr,#0x1001
      00664D F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      00664E 90 08 24         [24] 2379 	mov	dptr,#_control_setup_length_10000_287
      006651 E4               [12] 2380 	clr	a
      006652 F0               [24] 2381 	movx	@dptr,a
      006653 A3               [24] 2382 	inc	dptr
      006654 F0               [24] 2383 	movx	@dptr,a
                                   2384 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006655 90 07 BC         [24] 2385 	mov	dptr,#_D0SetupLen
      006658 E0               [24] 2386 	movx	a,@dptr
      006659 FB               [12] 2387 	mov	r3,a
      00665A A3               [24] 2388 	inc	dptr
      00665B E0               [24] 2389 	movx	a,@dptr
      00665C FC               [12] 2390 	mov	r4,a
      00665D C3               [12] 2391 	clr	c
      00665E 74 02            [12] 2392 	mov	a,#0x02
      006660 9B               [12] 2393 	subb	a,r3
      006661 E4               [12] 2394 	clr	a
      006662 9C               [12] 2395 	subb	a,r4
      006663 D0 04            [24] 2396 	pop	ar4
      006665 D0 03            [24] 2397 	pop	ar3
      006667 50 7A            [24] 2398 	jnc	00252$
                                   2399 ;	free result
      006669 90 07 BC         [24] 2400 	mov	dptr,#_D0SetupLen
      00666C 74 02            [12] 2401 	mov	a,#0x02
      00666E F0               [24] 2402 	movx	@dptr,a
      00666F E4               [12] 2403 	clr	a
      006670 A3               [24] 2404 	inc	dptr
      006671 F0               [24] 2405 	movx	@dptr,a
      006672 80 6F            [24] 2406 	sjmp	00252$
      006674                       2407 00232$:
                                   2408 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006674 B8 00 69         [24] 2409 	cjne	r0,#0x00,00228$
      006677 B9 03 66         [24] 2410 	cjne	r1,#0x03,00228$
      00667A BB 01 63         [24] 2411 	cjne	r3,#0x01,00228$
      00667D BC 00 60         [24] 2412 	cjne	r4,#0x00,00228$
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      006680 90 10 00         [24] 2414 	mov	dptr,#0x1000
      006683 74 41            [12] 2415 	mov	a,#0x41
      006685 F0               [24] 2416 	movx	@dptr,a
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      006686 A3               [24] 2418 	inc	dptr
      006687 74 4B            [12] 2419 	mov	a,#0x4b
      006689 F0               [24] 2420 	movx	@dptr,a
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      00668A A3               [24] 2422 	inc	dptr
      00668B 74 42            [12] 2423 	mov	a,#0x42
      00668D F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      00668E A3               [24] 2426 	inc	dptr
      00668F 74 54            [12] 2427 	mov	a,#0x54
      006691 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      006692 A3               [24] 2430 	inc	dptr
      006693 74 01            [12] 2431 	mov	a,#0x01
      006695 F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      006696 90 07 C7         [24] 2434 	mov	dptr,#_ak820_boot_stage
      006699 E0               [24] 2435 	movx	a,@dptr
      00669A 90 10 05         [24] 2436 	mov	dptr,#0x1005
      00669D F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00669E 90 07 C8         [24] 2439 	mov	dptr,#_ak820_main_heartbeat
      0066A1 E0               [24] 2440 	movx	a,@dptr
      0066A2 90 10 06         [24] 2441 	mov	dptr,#0x1006
      0066A5 F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0066A6 90 07 C2         [24] 2444 	mov	dptr,#_USB_EnumStatus
      0066A9 E0               [24] 2445 	movx	a,@dptr
      0066AA 60 02            [24] 2446 	jz	00322$
      0066AC 74 01            [12] 2447 	mov	a,#0x01
      0066AE                       2448 00322$:
      0066AE F9               [12] 2449 	mov	r1,a
      0066AF 90 07 C3         [24] 2450 	mov	dptr,#_USB_SleepStatus
      0066B2 E0               [24] 2451 	movx	a,@dptr
      0066B3 54 02            [12] 2452 	anl	a,#0x02
      0066B5 F8               [12] 2453 	mov	r0,a
      0066B6 E9               [12] 2454 	mov	a,r1
      0066B7 42 00            [12] 2455 	orl	ar0,a
      0066B9 90 10 07         [24] 2456 	mov	dptr,#0x1007
      0066BC E8               [12] 2457 	mov	a,r0
      0066BD F0               [24] 2458 	movx	@dptr,a
                                   2459 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      0066BE 90 08 24         [24] 2460 	mov	dptr,#_control_setup_length_10000_287
      0066C1 E4               [12] 2461 	clr	a
      0066C2 F0               [24] 2462 	movx	@dptr,a
      0066C3 A3               [24] 2463 	inc	dptr
      0066C4 F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      0066C5 90 07 BC         [24] 2466 	mov	dptr,#_D0SetupLen
      0066C8 E0               [24] 2467 	movx	a,@dptr
      0066C9 F8               [12] 2468 	mov	r0,a
      0066CA A3               [24] 2469 	inc	dptr
      0066CB E0               [24] 2470 	movx	a,@dptr
      0066CC F9               [12] 2471 	mov	r1,a
      0066CD C3               [12] 2472 	clr	c
      0066CE 74 08            [12] 2473 	mov	a,#0x08
      0066D0 98               [12] 2474 	subb	a,r0
      0066D1 E4               [12] 2475 	clr	a
      0066D2 99               [12] 2476 	subb	a,r1
      0066D3 50 0E            [24] 2477 	jnc	00252$
                                   2478 ;	free result
      0066D5 90 07 BC         [24] 2479 	mov	dptr,#_D0SetupLen
      0066D8 74 08            [12] 2480 	mov	a,#0x08
      0066DA F0               [24] 2481 	movx	@dptr,a
      0066DB E4               [12] 2482 	clr	a
      0066DC A3               [24] 2483 	inc	dptr
      0066DD F0               [24] 2484 	movx	@dptr,a
      0066DE 80 03            [24] 2485 	sjmp	00252$
      0066E0                       2486 00228$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      0066E0 02 5E 49         [24] 2488 	ljmp	_control_stall
      0066E3                       2489 00252$:
                                   2490 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      0066E3 90 08 24         [24] 2491 	mov	dptr,#_control_setup_length_10000_287
      0066E6 E0               [24] 2492 	movx	a,@dptr
      0066E7 F5 19            [12] 2493 	mov	_control_setup_sloc4_1_0,a
      0066E9 A3               [24] 2494 	inc	dptr
      0066EA E0               [24] 2495 	movx	a,@dptr
      0066EB F5 1A            [12] 2496 	mov	(_control_setup_sloc4_1_0 + 1),a
      0066ED E5 19            [12] 2497 	mov	a,_control_setup_sloc4_1_0
      0066EF 45 1A            [12] 2498 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0066F1 60 50            [24] 2499 	jz	00262$
                                   2500 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      0066F3 90 07 BC         [24] 2501 	mov	dptr,#_D0SetupLen
      0066F6 E0               [24] 2502 	movx	a,@dptr
      0066F7 F8               [12] 2503 	mov	r0,a
      0066F8 A3               [24] 2504 	inc	dptr
      0066F9 E0               [24] 2505 	movx	a,@dptr
      0066FA F9               [12] 2506 	mov	r1,a
      0066FB C3               [12] 2507 	clr	c
      0066FC E5 19            [12] 2508 	mov	a,_control_setup_sloc4_1_0
      0066FE 98               [12] 2509 	subb	a,r0
      0066FF E5 1A            [12] 2510 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006701 99               [12] 2511 	subb	a,r1
      006702 50 0A            [24] 2512 	jnc	00559$
                                   2513 ;	free result
      006704 90 07 BC         [24] 2514 	mov	dptr,#_D0SetupLen
      006707 E5 19            [12] 2515 	mov	a,_control_setup_sloc4_1_0
      006709 F0               [24] 2516 	movx	@dptr,a
      00670A E5 1A            [12] 2517 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00670C A3               [24] 2518 	inc	dptr
      00670D F0               [24] 2519 	movx	@dptr,a
                                   2520 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00670E                       2521 00559$:
      00670E 75 19 00         [24] 2522 	mov	_control_setup_sloc4_1_0,#0x00
      006711                       2523 00296$:
      006711 90 07 BC         [24] 2524 	mov	dptr,#_D0SetupLen
      006714 E0               [24] 2525 	movx	a,@dptr
      006715 F8               [12] 2526 	mov	r0,a
      006716 C3               [12] 2527 	clr	c
      006717 E5 19            [12] 2528 	mov	a,_control_setup_sloc4_1_0
      006719 98               [12] 2529 	subb	a,r0
      00671A 50 46            [24] 2530 	jnc	00263$
      00671C 85 19 17         [24] 2531 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00671F 74 10            [12] 2532 	mov	a,#0x10
      006721 24 00            [12] 2533 	add	a, #0x00
      006723 F5 18            [12] 2534 	mov	(_control_setup_sloc3_1_0 + 1),a
      006725 90 08 26         [24] 2535 	mov	dptr,#_control_setup_offset_10000_287
      006728 E0               [24] 2536 	movx	a,@dptr
      006729 25 19            [12] 2537 	add	a, _control_setup_sloc4_1_0
      00672B 24 EC            [12] 2538 	add	a, #_input_snapshot
      00672D F5 82            [12] 2539 	mov	dpl,a
      00672F E4               [12] 2540 	clr	a
      006730 34 07            [12] 2541 	addc	a,#(_input_snapshot >> 8)
      006732 F5 83            [12] 2542 	mov	dph,a
      006734 E0               [24] 2543 	movx	a,@dptr
      006735 85 17 82         [24] 2544 	mov	dpl,_control_setup_sloc3_1_0
      006738 85 18 83         [24] 2545 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00673B F0               [24] 2546 	movx	@dptr,a
      00673C E5 19            [12] 2547 	mov	a,_control_setup_sloc4_1_0
      00673E 04               [12] 2548 	inc	a
      00673F F5 19            [12] 2549 	mov	_control_setup_sloc4_1_0,a
      006741 80 CE            [24] 2550 	sjmp	00296$
      006743                       2551 00262$:
                                   2552 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006743 BB 01 1C         [24] 2553 	cjne	r3,#0x01,00263$
      006746 BC 00 19         [24] 2554 	cjne	r4,#0x00,00263$
      006749 90 07 BC         [24] 2555 	mov	dptr,#_D0SetupLen
      00674C E0               [24] 2556 	movx	a,@dptr
      00674D F8               [12] 2557 	mov	r0,a
      00674E A3               [24] 2558 	inc	dptr
      00674F E0               [24] 2559 	movx	a,@dptr
      006750 F9               [12] 2560 	mov	r1,a
      006751 C3               [12] 2561 	clr	c
      006752 74 20            [12] 2562 	mov	a,#0x20
      006754 98               [12] 2563 	subb	a,r0
      006755 E4               [12] 2564 	clr	a
      006756 99               [12] 2565 	subb	a,r1
      006757 50 09            [24] 2566 	jnc	00263$
                                   2567 ;	free result
      006759 90 07 BC         [24] 2568 	mov	dptr,#_D0SetupLen
      00675C 74 20            [12] 2569 	mov	a,#0x20
      00675E F0               [24] 2570 	movx	@dptr,a
      00675F E4               [12] 2571 	clr	a
      006760 A3               [24] 2572 	inc	dptr
      006761 F0               [24] 2573 	movx	@dptr,a
      006762                       2574 00263$:
                                   2575 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006762 90 07 BC         [24] 2576 	mov	dptr,#_D0SetupLen
      006765 E0               [24] 2577 	movx	a,@dptr
      006766 90 22 08         [24] 2578 	mov	dptr,#0x2208
      006769 F0               [24] 2579 	movx	@dptr,a
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      00676A 90 08 1A         [24] 2581 	mov	dptr,#_control_phase
      00676D 74 02            [12] 2582 	mov	a,#0x02
      00676F F0               [24] 2583 	movx	@dptr,a
      006770 02 67 F8         [24] 2584 	ljmp	00291$
      006773                       2585 00273$:
                                   2586 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006773 EB               [12] 2587 	mov	a,r3
      006774 4C               [12] 2588 	orl	a,r4
      006775 70 37            [24] 2589 	jnz	00265$
      006777 90 07 C1         [24] 2590 	mov	dptr,#_D0UsbConfig
      00677A E0               [24] 2591 	movx	a,@dptr
      00677B 60 31            [24] 2592 	jz	00265$
      00677D EA               [12] 2593 	mov	a,r2
      00677E 60 2E            [24] 2594 	jz	00265$
      006780 90 07 BB         [24] 2595 	mov	dptr,#_D0SetupReqCode
      006783 E0               [24] 2596 	movx	a,@dptr
      006784 FA               [12] 2597 	mov	r2,a
      006785 BA 03 26         [24] 2598 	cjne	r2,#0x03,00265$
      006788 30 19 23         [24] 2599 	jnb	_control_setup_zero_value_10000_287,00265$
      00678B 90 07 BC         [24] 2600 	mov	dptr,#_D0SetupLen
      00678E E0               [24] 2601 	movx	a,@dptr
      00678F F9               [12] 2602 	mov	r1,a
      006790 A3               [24] 2603 	inc	dptr
      006791 E0               [24] 2604 	movx	a,@dptr
      006792 FA               [12] 2605 	mov	r2,a
      006793 B9 01 18         [24] 2606 	cjne	r1,#0x01,00265$
      006796 BA 00 15         [24] 2607 	cjne	r2,#0x00,00265$
                                   2608 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      006799 90 0E 0C         [24] 2609 	mov	dptr,#_keyboard_protocol
      00679C E0               [24] 2610 	movx	a,@dptr
      00679D 90 10 00         [24] 2611 	mov	dptr,#0x1000
      0067A0 F0               [24] 2612 	movx	@dptr,a
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      0067A1 90 22 08         [24] 2614 	mov	dptr,#0x2208
      0067A4 74 01            [12] 2615 	mov	a,#0x01
      0067A6 F0               [24] 2616 	movx	@dptr,a
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      0067A7 90 08 1A         [24] 2618 	mov	dptr,#_control_phase
      0067AA 04               [12] 2619 	inc	a
      0067AB F0               [24] 2620 	movx	@dptr,a
      0067AC 80 4A            [24] 2621 	sjmp	00291$
      0067AE                       2622 00265$:
                                   2623 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      0067AE 02 5E 49         [24] 2625 	ljmp	_control_stall
      0067B1                       2626 00282$:
                                   2627 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0067B1 30 17 3E         [24] 2628 	jnb	_control_setup_valid_interface_10000_287,00284$
      0067B4 90 07 C1         [24] 2629 	mov	dptr,#_D0UsbConfig
      0067B7 E0               [24] 2630 	movx	a,@dptr
      0067B8 60 38            [24] 2631 	jz	00284$
      0067BA BF A1 35         [24] 2632 	cjne	r7,#0xa1,00284$
      0067BD 8E 05            [24] 2633 	mov	ar5,r6
      0067BF 7E 00            [12] 2634 	mov	r6,#0x00
      0067C1 ED               [12] 2635 	mov	a,r5
      0067C2 4E               [12] 2636 	orl	a,r6
      0067C3 70 2D            [24] 2637 	jnz	00284$
      0067C5 90 07 BC         [24] 2638 	mov	dptr,#_D0SetupLen
      0067C8 E0               [24] 2639 	movx	a,@dptr
      0067C9 FE               [12] 2640 	mov	r6,a
      0067CA A3               [24] 2641 	inc	dptr
      0067CB E0               [24] 2642 	movx	a,@dptr
      0067CC FF               [12] 2643 	mov	r7,a
      0067CD BE 01 22         [24] 2644 	cjne	r6,#0x01,00284$
      0067D0 BF 00 1F         [24] 2645 	cjne	r7,#0x00,00284$
                                   2646 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0067D3 EB               [12] 2647 	mov	a,r3
      0067D4 4C               [12] 2648 	orl	a,r4
      0067D5 70 07            [24] 2649 	jnz	00324$
      0067D7 90 06 99         [24] 2650 	mov	dptr,#_keyboard_idle
      0067DA E0               [24] 2651 	movx	a,@dptr
      0067DB FF               [12] 2652 	mov	r7,a
      0067DC 80 02            [24] 2653 	sjmp	00325$
      0067DE                       2654 00324$:
      0067DE 7F 00            [12] 2655 	mov	r7,#0x00
      0067E0                       2656 00325$:
      0067E0 90 10 00         [24] 2657 	mov	dptr,#0x1000
      0067E3 EF               [12] 2658 	mov	a,r7
      0067E4 F0               [24] 2659 	movx	@dptr,a
                                   2660 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      0067E5 90 22 08         [24] 2661 	mov	dptr,#0x2208
      0067E8 74 01            [12] 2662 	mov	a,#0x01
      0067EA F0               [24] 2663 	movx	@dptr,a
                                   2664 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      0067EB 90 08 1A         [24] 2665 	mov	dptr,#_control_phase
      0067EE 04               [12] 2666 	inc	a
      0067EF F0               [24] 2667 	movx	@dptr,a
      0067F0 80 06            [24] 2668 	sjmp	00291$
      0067F2                       2669 00284$:
                                   2670 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      0067F2 02 5E 49         [24] 2672 	ljmp	_control_stall
      0067F5                       2673 00290$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      0067F5 02 5E 49         [24] 2675 	ljmp	_control_stall
      0067F8                       2676 00291$:
                                   2677 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0067F8 90 22 00         [24] 2678 	mov	dptr,#0x2200
      0067FB 74 C0            [12] 2679 	mov	a,#0xc0
      0067FD F0               [24] 2680 	movx	@dptr,a
                                   2681 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      0067FE 22               [24] 2682 	ret
                                   2683 ;------------------------------------------------------------
                                   2684 ;Allocation info for local variables in function 'control_out'
                                   2685 ;------------------------------------------------------------
                                   2686 ;i             Allocated with name '_control_out_i_10000_371'
                                   2687 ;------------------------------------------------------------
                                   2688 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2689 ;	-----------------------------------------
                                   2690 ;	 function control_out
                                   2691 ;	-----------------------------------------
      0067FF                       2692 _control_out:
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0067FF 90 22 0F         [24] 2694 	mov	dptr,#0x220f
      006802 E0               [24] 2695 	movx	a,@dptr
      006803 20 E6 01         [24] 2696 	jb	acc.6,00102$
      006806 22               [24] 2697 	ret
      006807                       2698 00102$:
                                   2699 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006807 90 08 1A         [24] 2700 	mov	dptr,#_control_phase
      00680A E0               [24] 2701 	movx	a,@dptr
      00680B FF               [12] 2702 	mov	r7,a
      00680C BF 02 12         [24] 2703 	cjne	r7,#0x02,00104$
      00680F 90 22 0E         [24] 2704 	mov	dptr,#0x220e
      006812 E0               [24] 2705 	movx	a,@dptr
      006813 70 0C            [24] 2706 	jnz	00104$
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006815 90 08 1A         [24] 2708 	mov	dptr,#_control_phase
      006818 E4               [12] 2709 	clr	a
      006819 F0               [24] 2710 	movx	@dptr,a
                                   2711 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00681A 90 22 00         [24] 2712 	mov	dptr,#0x2200
      00681D 74 02            [12] 2713 	mov	a,#0x02
      00681F F0               [24] 2714 	movx	@dptr,a
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006820 22               [24] 2716 	ret
      006821                       2717 00104$:
                                   2718 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006821 BF 04 19         [24] 2719 	cjne	r7,#0x04,00106$
      006824 90 22 0E         [24] 2720 	mov	dptr,#0x220e
      006827 E0               [24] 2721 	movx	a,@dptr
      006828 FF               [12] 2722 	mov	r7,a
      006829 90 07 BC         [24] 2723 	mov	dptr,#_D0SetupLen
      00682C E0               [24] 2724 	movx	a,@dptr
      00682D FD               [12] 2725 	mov	r5,a
      00682E A3               [24] 2726 	inc	dptr
      00682F E0               [24] 2727 	movx	a,@dptr
      006830 FE               [12] 2728 	mov	r6,a
      006831 7C 00            [12] 2729 	mov	r4,#0x00
      006833 EF               [12] 2730 	mov	a,r7
      006834 B5 05 06         [24] 2731 	cjne	a,ar5,00209$
      006837 EC               [12] 2732 	mov	a,r4
      006838 B5 06 02         [24] 2733 	cjne	a,ar6,00209$
      00683B 80 03            [24] 2734 	sjmp	00107$
      00683D                       2735 00209$:
      00683D                       2736 00106$:
      00683D 02 5E 49         [24] 2737 	ljmp	_control_stall
      006840                       2738 00107$:
                                   2739 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006840 90 08 1B         [24] 2740 	mov	dptr,#_output_kind
      006843 E0               [24] 2741 	movx	a,@dptr
      006844 FF               [12] 2742 	mov	r7,a
      006845 BF 01 2E         [24] 2743 	cjne	r7,#0x01,00118$
      006848 90 07 C9         [24] 2744 	mov	dptr,#_raw_state
      00684B E0               [24] 2745 	movx	a,@dptr
      00684C FE               [12] 2746 	mov	r6,a
      00684D BE 01 26         [24] 2747 	cjne	r6,#0x01,00118$
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006850 7E 00            [12] 2749 	mov	r6,#0x00
      006852                       2750 00121$:
      006852 EE               [12] 2751 	mov	a,r6
      006853 24 CA            [12] 2752 	add	a, #_raw_buffer
      006855 FC               [12] 2753 	mov	r4,a
      006856 E4               [12] 2754 	clr	a
      006857 34 07            [12] 2755 	addc	a, #(_raw_buffer >> 8)
      006859 FD               [12] 2756 	mov	r5,a
      00685A 8E 82            [24] 2757 	mov	dpl,r6
      00685C 74 10            [12] 2758 	mov	a,#0x10
      00685E 24 00            [12] 2759 	add	a, #0x00
      006860 F5 83            [12] 2760 	mov	dph,a
      006862 E0               [24] 2761 	movx	a,@dptr
      006863 8C 82            [24] 2762 	mov	dpl,r4
      006865 8D 83            [24] 2763 	mov	dph,r5
      006867 F0               [24] 2764 	movx	@dptr,a
      006868 0E               [12] 2765 	inc	r6
      006869 BE 20 00         [24] 2766 	cjne	r6,#0x20,00214$
      00686C                       2767 00214$:
      00686C 40 E4            [24] 2768 	jc	00121$
                                   2769 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00686E 90 07 C9         [24] 2770 	mov	dptr,#_raw_state
      006871 74 02            [12] 2771 	mov	a,#0x02
      006873 F0               [24] 2772 	movx	@dptr,a
      006874 80 2B            [24] 2773 	sjmp	00119$
      006876                       2774 00118$:
                                   2775 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      006876 BF 02 0A         [24] 2776 	cjne	r7,#0x02,00115$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      006879 90 10 00         [24] 2778 	mov	dptr,#0x1000
      00687C E0               [24] 2779 	movx	a,@dptr
      00687D 90 07 C6         [24] 2780 	mov	dptr,#_KB_USB_SetReport
      006880 F0               [24] 2781 	movx	@dptr,a
      006881 80 1E            [24] 2782 	sjmp	00119$
      006883                       2783 00115$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006883 BF 03 18         [24] 2785 	cjne	r7,#0x03,00111$
      006886 90 10 00         [24] 2786 	mov	dptr,#0x1000
      006889 E0               [24] 2787 	movx	a,@dptr
      00688A FF               [12] 2788 	mov	r7,a
      00688B 90 08 1C         [24] 2789 	mov	dptr,#_output_report_id
      00688E E0               [24] 2790 	movx	a,@dptr
      00688F FE               [12] 2791 	mov	r6,a
      006890 EF               [12] 2792 	mov	a,r7
      006891 B5 06 0A         [24] 2793 	cjne	a,ar6,00111$
                                   2794 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006894 90 10 01         [24] 2795 	mov	dptr,#0x1001
      006897 E0               [24] 2796 	movx	a,@dptr
      006898 90 07 C6         [24] 2797 	mov	dptr,#_KB_USB_SetReport
      00689B F0               [24] 2798 	movx	@dptr,a
      00689C 80 03            [24] 2799 	sjmp	00119$
      00689E                       2800 00111$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      00689E 02 5E 49         [24] 2802 	ljmp	_control_stall
      0068A1                       2803 00119$:
                                   2804 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      0068A1 90 08 1B         [24] 2805 	mov	dptr,#_output_kind
      0068A4 E4               [12] 2806 	clr	a
      0068A5 F0               [24] 2807 	movx	@dptr,a
                                   2808 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      0068A6 90 07 BC         [24] 2809 	mov	dptr,#_D0SetupLen
      0068A9 F0               [24] 2810 	movx	@dptr,a
      0068AA A3               [24] 2811 	inc	dptr
      0068AB F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      0068AC 90 08 1A         [24] 2814 	mov	dptr,#_control_phase
      0068AF 74 03            [12] 2815 	mov	a,#0x03
      0068B1 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      0068B2 90 22 08         [24] 2818 	mov	dptr,#0x2208
      0068B5 E4               [12] 2819 	clr	a
      0068B6 F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0068B7 F5 82            [12] 2822 	mov	dpl,a
      0068B9 74 48            [12] 2823 	mov	a,#0x48
      0068BB F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      0068BC 22               [24] 2826 	ret
                                   2827 ;------------------------------------------------------------
                                   2828 ;Allocation info for local variables in function 'control_in'
                                   2829 ;------------------------------------------------------------
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2831 ;	-----------------------------------------
                                   2832 ;	 function control_in
                                   2833 ;	-----------------------------------------
      0068BD                       2834 _control_in:
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      0068BD 90 08 1A         [24] 2836 	mov	dptr,#_control_phase
      0068C0 E0               [24] 2837 	movx	a,@dptr
      0068C1 FF               [12] 2838 	mov	r7,a
      0068C2 BF 01 22         [24] 2839 	cjne	r7,#0x01,00109$
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      0068C5 90 07 BC         [24] 2841 	mov	dptr,#_D0SetupLen
      0068C8 E0               [24] 2842 	movx	a,@dptr
      0068C9 FD               [12] 2843 	mov	r5,a
      0068CA A3               [24] 2844 	inc	dptr
      0068CB E0               [24] 2845 	movx	a,@dptr
      0068CC 4D               [12] 2846 	orl	a,r5
      0068CD 70 06            [24] 2847 	jnz	00101$
      0068CF 90 08 1D         [24] 2848 	mov	dptr,#_control_zlp
      0068D2 E0               [24] 2849 	movx	a,@dptr
      0068D3 60 0A            [24] 2850 	jz	00102$
      0068D5                       2851 00101$:
                                   2852 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      0068D5 90 22 00         [24] 2853 	mov	dptr,#0x2200
      0068D8 E0               [24] 2854 	movx	a,@dptr
      0068D9 64 40            [12] 2855 	xrl	a,#0x40
      0068DB F0               [24] 2856 	movx	@dptr,a
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      0068DC 02 5E 6B         [24] 2859 	ljmp	_control_next
      0068DF                       2860 00102$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      0068DF 90 08 1A         [24] 2862 	mov	dptr,#_control_phase
      0068E2 74 02            [12] 2863 	mov	a,#0x02
      0068E4 F0               [24] 2864 	movx	@dptr,a
      0068E5 80 18            [24] 2865 	sjmp	00110$
      0068E7                       2866 00109$:
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      0068E7 BF 03 15         [24] 2868 	cjne	r7,#0x03,00110$
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0068EA 90 07 BB         [24] 2870 	mov	dptr,#_D0SetupReqCode
      0068ED E0               [24] 2871 	movx	a,@dptr
      0068EE FF               [12] 2872 	mov	r7,a
      0068EF BF 05 08         [24] 2873 	cjne	r7,#0x05,00105$
      0068F2 90 07 BC         [24] 2874 	mov	dptr,#_D0SetupLen
      0068F5 E0               [24] 2875 	movx	a,@dptr
      0068F6 90 22 07         [24] 2876 	mov	dptr,#0x2207
      0068F9 F0               [24] 2877 	movx	@dptr,a
      0068FA                       2878 00105$:
                                   2879 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      0068FA 90 08 1A         [24] 2880 	mov	dptr,#_control_phase
      0068FD E4               [12] 2881 	clr	a
      0068FE F0               [24] 2882 	movx	@dptr,a
      0068FF                       2883 00110$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068FF 90 22 00         [24] 2885 	mov	dptr,#0x2200
      006902 74 82            [12] 2886 	mov	a,#0x82
      006904 F0               [24] 2887 	movx	@dptr,a
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006905 22               [24] 2889 	ret
                                   2890 ;------------------------------------------------------------
                                   2891 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2892 ;------------------------------------------------------------
                                   2893 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2894 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2895 ;------------------------------------------------------------
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2897 ;	-----------------------------------------
                                   2898 ;	 function USB_DeviceInterrupt
                                   2899 ;	-----------------------------------------
      006906                       2900 _USB_DeviceInterrupt:
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006906                       2902 00129$:
                                   2903 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006906 90 22 3D         [24] 2904 	mov	dptr,#0x223d
      006909 E0               [24] 2905 	movx	a,@dptr
      00690A 30 E0 4B         [24] 2906 	jnb	acc.0,00127$
                                   2907 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      00690D 12 5D F2         [24] 2908 	lcall	_endpoints_reset
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006910 90 22 07         [24] 2910 	mov	dptr,#0x2207
      006913 E4               [12] 2911 	clr	a
      006914 F0               [24] 2912 	movx	@dptr,a
                                   2913 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006915 90 07 C3         [24] 2914 	mov	dptr,#_USB_SleepStatus
      006918 F0               [24] 2915 	movx	@dptr,a
      006919 90 07 C2         [24] 2916 	mov	dptr,#_USB_EnumStatus
      00691C F0               [24] 2917 	movx	@dptr,a
      00691D 90 07 C1         [24] 2918 	mov	dptr,#_D0UsbConfig
      006920 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006921 90 07 C6         [24] 2921 	mov	dptr,#_KB_USB_SetReport
      006924 F0               [24] 2922 	movx	@dptr,a
                                   2923 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006925 90 0E 0C         [24] 2924 	mov	dptr,#_keyboard_protocol
      006928 04               [12] 2925 	inc	a
      006929 F0               [24] 2926 	movx	@dptr,a
                                   2927 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      00692A 90 06 99         [24] 2928 	mov	dptr,#_keyboard_idle
      00692D E4               [12] 2929 	clr	a
      00692E F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      00692F 90 07 EB         [24] 2932 	mov	dptr,#_keyboard_reset
      006932 04               [12] 2933 	inc	a
      006933 F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006934 90 07 BB         [24] 2936 	mov	dptr,#_D0SetupReqCode
      006937 74 FF            [12] 2937 	mov	a,#0xff
      006939 F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      00693A 90 07 BC         [24] 2940 	mov	dptr,#_D0SetupLen
      00693D E4               [12] 2941 	clr	a
      00693E F0               [24] 2942 	movx	@dptr,a
      00693F A3               [24] 2943 	inc	dptr
      006940 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006941 90 08 1A         [24] 2946 	mov	dptr,#_control_phase
      006944 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006945 90 22 00         [24] 2949 	mov	dptr,#0x2200
      006948 74 02            [12] 2950 	mov	a,#0x02
      00694A F0               [24] 2951 	movx	@dptr,a
                                   2952 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      00694B 90 22 0F         [24] 2953 	mov	dptr,#0x220f
      00694E E4               [12] 2954 	clr	a
      00694F F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006950 90 22 3D         [24] 2957 	mov	dptr,#0x223d
      006953 04               [12] 2958 	inc	a
      006954 F0               [24] 2959 	movx	@dptr,a
      006955 02 69 EB         [24] 2960 	ljmp	00130$
      006958                       2961 00127$:
                                   2962 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006958 90 22 3D         [24] 2963 	mov	dptr,#0x223d
      00695B E0               [24] 2964 	movx	a,@dptr
      00695C 30 E5 60         [24] 2965 	jnb	acc.5,00124$
                                   2966 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      00695F 90 22 0F         [24] 2967 	mov	dptr,#0x220f
      006962 E0               [24] 2968 	movx	a,@dptr
      006963 FF               [12] 2969 	mov	r7,a
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006964 74 07            [12] 2971 	mov	a,#0x07
      006966 5F               [12] 2972 	anl	a,r7
      006967 FE               [12] 2973 	mov	r6,a
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006968 EF               [12] 2975 	mov	a,r7
      006969 54 18            [12] 2976 	anl	a,#0x18
      00696B 70 08            [24] 2977 	jnz	00115$
      00696D EE               [12] 2978 	mov	a,r6
      00696E 70 05            [24] 2979 	jnz	00115$
                                   2980 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006970 12 67 FF         [24] 2981 	lcall	_control_out
      006973 80 43            [24] 2982 	sjmp	00116$
      006975                       2983 00115$:
                                   2984 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006975 8F 05            [24] 2985 	mov	ar5,r7
      006977 74 18            [12] 2986 	mov	a,#0x18
      006979 5D               [12] 2987 	anl	a,r5
      00697A FC               [12] 2988 	mov	r4,a
      00697B BC 10 2D         [24] 2989 	cjne	r4,#0x10,00112$
                                   2990 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      00697E EE               [12] 2991 	mov	a,r6
      00697F 70 05            [24] 2992 	jnz	00106$
      006981 12 68 BD         [24] 2993 	lcall	_control_in
      006984 80 32            [24] 2994 	sjmp	00116$
      006986                       2995 00106$:
                                   2996 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006986 EE               [12] 2997 	mov	a,r6
      006987 24 FC            [12] 2998 	add	a,#0xff - 0x03
      006989 40 2D            [24] 2999 	jc	00116$
                                   3000 ;	free result
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00698B 8E 04            [24] 3002 	mov	ar4,r6
      00698D 7B 00            [12] 3003 	mov	r3,#0x00
      00698F 74 22            [12] 3004 	mov	a,#0x22
      006991 2B               [12] 3005 	add	a, r3
      006992 FB               [12] 3006 	mov	r3,a
      006993 8C 82            [24] 3007 	mov	dpl,r4
      006995 8B 83            [24] 3008 	mov	dph,r3
      006997 E0               [24] 3009 	movx	a,@dptr
      006998 FA               [12] 3010 	mov	r2,a
      006999 74 FC            [12] 3011 	mov	a,#0xfc
      00699B 5A               [12] 3012 	anl	a,r2
      00699C 44 02            [12] 3013 	orl	a,#0x02
      00699E 8C 82            [24] 3014 	mov	dpl,r4
      0069A0 8B 83            [24] 3015 	mov	dph,r3
      0069A2 F0               [24] 3016 	movx	@dptr,a
                                   3017 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0069A3 BE 03 12         [24] 3018 	cjne	r6,#0x03,00116$
      0069A6 12 5D D5         [24] 3019 	lcall	_raw_complete
      0069A9 80 0D            [24] 3020 	sjmp	00116$
      0069AB                       3021 00112$:
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      0069AB 53 05 18         [24] 3023 	anl	ar5,#0x18
      0069AE BD 18 07         [24] 3024 	cjne	r5,#0x18,00116$
      0069B1 EF               [12] 3025 	mov	a,r7
      0069B2 30 E5 03         [24] 3026 	jnb	acc.5,00116$
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      0069B5 12 60 62         [24] 3028 	lcall	_control_setup
      0069B8                       3029 00116$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      0069B8 90 22 0F         [24] 3031 	mov	dptr,#0x220f
      0069BB E4               [12] 3032 	clr	a
      0069BC F0               [24] 3033 	movx	@dptr,a
      0069BD 80 2C            [24] 3034 	sjmp	00130$
      0069BF                       3035 00124$:
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      0069BF 90 22 3D         [24] 3037 	mov	dptr,#0x223d
      0069C2 E0               [24] 3038 	movx	a,@dptr
      0069C3 30 E2 25         [24] 3039 	jnb	acc.2,00130$
                                   3040 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0069C6 90 22 3D         [24] 3041 	mov	dptr,#0x223d
      0069C9 E0               [24] 3042 	movx	a,@dptr
      0069CA 30 E3 0A         [24] 3043 	jnb	acc.3,00119$
      0069CD 90 07 C3         [24] 3044 	mov	dptr,#_USB_SleepStatus
      0069D0 E0               [24] 3045 	movx	a,@dptr
      0069D1 43 E0 02         [24] 3046 	orl	acc,#0x02
      0069D4 F0               [24] 3047 	movx	@dptr,a
      0069D5 80 0E            [24] 3048 	sjmp	00120$
      0069D7                       3049 00119$:
                                   3050 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      0069D7 90 07 C3         [24] 3051 	mov	dptr,#_USB_SleepStatus
      0069DA E0               [24] 3052 	movx	a,@dptr
      0069DB 53 E0 FD         [24] 3053 	anl	acc,#0xfd
      0069DE F0               [24] 3054 	movx	@dptr,a
                                   3055 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      0069DF 90 07 EB         [24] 3056 	mov	dptr,#_keyboard_reset
      0069E2 74 01            [12] 3057 	mov	a,#0x01
      0069E4 F0               [24] 3058 	movx	@dptr,a
      0069E5                       3059 00120$:
                                   3060 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      0069E5 90 22 3D         [24] 3061 	mov	dptr,#0x223d
      0069E8 74 04            [12] 3062 	mov	a,#0x04
      0069EA F0               [24] 3063 	movx	@dptr,a
      0069EB                       3064 00130$:
                                   3065 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      0069EB 90 22 3D         [24] 3066 	mov	dptr,#0x223d
      0069EE E0               [24] 3067 	movx	a,@dptr
      0069EF 54 25            [12] 3068 	anl	a,#0x25
      0069F1 60 03            [24] 3069 	jz	00242$
      0069F3 02 69 06         [24] 3070 	ljmp	00129$
      0069F6                       3071 00242$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      0069F6 22               [24] 3073 	ret
                                   3074 ;------------------------------------------------------------
                                   3075 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3076 ;------------------------------------------------------------
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3078 ;	-----------------------------------------
                                   3079 ;	 function USB_Device_Init
                                   3080 ;	-----------------------------------------
      0069F7                       3081 _USB_Device_Init:
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3083 ;	assignBit
      0069F7 C2 E9            [12] 3084 	clr	_IE_USB
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      0069F9 90 22 3C         [24] 3086 	mov	dptr,#0x223c
      0069FC E4               [12] 3087 	clr	a
      0069FD F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      0069FE 90 07 C9         [24] 3090 	mov	dptr,#_raw_state
      006A01 F0               [24] 3091 	movx	@dptr,a
                                   3092 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006A02 12 5D F2         [24] 3093 	lcall	_endpoints_reset
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A05 90 07 C3         [24] 3095 	mov	dptr,#_USB_SleepStatus
      006A08 E4               [12] 3096 	clr	a
      006A09 F0               [24] 3097 	movx	@dptr,a
      006A0A 90 07 C2         [24] 3098 	mov	dptr,#_USB_EnumStatus
      006A0D F0               [24] 3099 	movx	@dptr,a
      006A0E 90 07 C1         [24] 3100 	mov	dptr,#_D0UsbConfig
      006A11 F0               [24] 3101 	movx	@dptr,a
      006A12 90 22 07         [24] 3102 	mov	dptr,#0x2207
      006A15 F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006A16 90 07 C4         [24] 3105 	mov	dptr,#_MCU_Sleep_Operate
      006A19 F0               [24] 3106 	movx	@dptr,a
      006A1A 90 07 C5         [24] 3107 	mov	dptr,#_KB_USB_UpStatus
      006A1D F0               [24] 3108 	movx	@dptr,a
      006A1E 90 07 C6         [24] 3109 	mov	dptr,#_KB_USB_SetReport
      006A21 F0               [24] 3110 	movx	@dptr,a
                                   3111 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006A22 90 0E 0C         [24] 3112 	mov	dptr,#_keyboard_protocol
      006A25 04               [12] 3113 	inc	a
      006A26 F0               [24] 3114 	movx	@dptr,a
                                   3115 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006A27 90 06 99         [24] 3116 	mov	dptr,#_keyboard_idle
      006A2A E4               [12] 3117 	clr	a
      006A2B F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      006A2C 90 07 EB         [24] 3120 	mov	dptr,#_keyboard_reset
      006A2F F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006A30 90 08 1A         [24] 3123 	mov	dptr,#_control_phase
      006A33 F0               [24] 3124 	movx	@dptr,a
                                   3125 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006A34 90 07 BB         [24] 3126 	mov	dptr,#_D0SetupReqCode
      006A37 14               [12] 3127 	dec	a
      006A38 F0               [24] 3128 	movx	@dptr,a
                                   3129 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006A39 90 07 BC         [24] 3130 	mov	dptr,#_D0SetupLen
      006A3C E4               [12] 3131 	clr	a
      006A3D F0               [24] 3132 	movx	@dptr,a
      006A3E A3               [24] 3133 	inc	dptr
      006A3F F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A40 90 22 00         [24] 3136 	mov	dptr,#0x2200
      006A43 74 02            [12] 3137 	mov	a,#0x02
      006A45 F0               [24] 3138 	movx	@dptr,a
                                   3139 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006A46 90 22 37         [24] 3140 	mov	dptr,#0x2237
      006A49 74 7F            [12] 3141 	mov	a,#0x7f
      006A4B F0               [24] 3142 	movx	@dptr,a
                                   3143 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      006A4C 90 22 3D         [24] 3144 	mov	dptr,#0x223d
      006A4F 74 FF            [12] 3145 	mov	a,#0xff
      006A51 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006A52 90 22 3B         [24] 3148 	mov	dptr,#0x223b
      006A55 74 07            [12] 3149 	mov	a,#0x07
      006A57 F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006A58 A3               [24] 3152 	inc	dptr
      006A59 74 80            [12] 3153 	mov	a,#0x80
      006A5B F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3156 ;	assignBit
      006A5C D2 E9            [12] 3157 	setb	_IE_USB
                                   3158 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006A5E 22               [24] 3159 	ret
                                   3160 ;------------------------------------------------------------
                                   3161 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3162 ;------------------------------------------------------------
                                   3163 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3164 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3165 ;------------------------------------------------------------
                                   3166 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3167 ;	-----------------------------------------
                                   3168 ;	 function USB_WakeUp_PC
                                   3169 ;	-----------------------------------------
      006A5F                       3170 _USB_WakeUp_PC:
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006A5F 90 07 C3         [24] 3172 	mov	dptr,#_USB_SleepStatus
      006A62 E0               [24] 3173 	movx	a,@dptr
      006A63 FF               [12] 3174 	mov	r7,a
      006A64 BF 03 22         [24] 3175 	cjne	r7,#0x03,00110$
                                   3176 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006A67 90 22 3C         [24] 3177 	mov	dptr,#0x223c
      006A6A E0               [24] 3178 	movx	a,@dptr
      006A6B FF               [12] 3179 	mov	r7,a
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006A6C E0               [24] 3181 	movx	a,@dptr
      006A6D FE               [12] 3182 	mov	r6,a
      006A6E 63 06 C0         [24] 3183 	xrl	ar6,#0xc0
      006A71 90 22 3C         [24] 3184 	mov	dptr,#0x223c
      006A74 EE               [12] 3185 	mov	a,r6
      006A75 F0               [24] 3186 	movx	@dptr,a
                                   3187 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006A76 7E 0A            [12] 3188 	mov	r6,#0x0a
      006A78                       3189 00108$:
      006A78 EE               [12] 3190 	mov	a,r6
      006A79 60 09            [24] 3191 	jz	00105$
      006A7B 90 00 01         [24] 3192 	mov	dptr,#0x0001
      006A7E 12 5C 19         [24] 3193 	lcall	_mDelaymS
      006A81 1E               [12] 3194 	dec	r6
      006A82 80 F4            [24] 3195 	sjmp	00108$
      006A84                       3196 00105$:
                                   3197 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006A84 90 22 3C         [24] 3198 	mov	dptr,#0x223c
      006A87 EF               [12] 3199 	mov	a,r7
      006A88 F0               [24] 3200 	movx	@dptr,a
      006A89                       3201 00110$:
                                   3202 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006A89 22               [24] 3203 	ret
                                   3204 ;------------------------------------------------------------
                                   3205 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3206 ;------------------------------------------------------------
                                   3207 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3208 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3209 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3210 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3211 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3212 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3213 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3214 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3215 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3216 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3217 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3218 ;------------------------------------------------------------
                                   3219 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3220 ;	-----------------------------------------
                                   3221 ;	 function ak820_usb_send
                                   3222 ;	-----------------------------------------
      006A8A                       3223 _ak820_usb_send:
      006A8A E5 82            [12] 3224 	mov	a,dpl
      006A8C 90 08 2A         [24] 3225 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A8F F0               [24] 3226 	movx	@dptr,a
                                   3227 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006A90 90 08 2B         [24] 3228 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006A93 74 2E            [12] 3229 	mov	a,#0x2e
      006A95 F0               [24] 3230 	movx	@dptr,a
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A96 90 08 2A         [24] 3232 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006A99 E0               [24] 3233 	movx	a,@dptr
      006A9A FF               [12] 3234 	mov	r7,a
      006A9B BF 01 00         [24] 3235 	cjne	r7,#0x01,00306$
      006A9E                       3236 00306$:
      006A9E 40 14            [24] 3237 	jc	00101$
      006AA0 EF               [12] 3238 	mov	a,r7
      006AA1 24 FC            [12] 3239 	add	a,#0xff - 0x03
      006AA3 40 0F            [24] 3240 	jc	00101$
                                   3241 ;	free result
      006AA5 90 08 29         [24] 3242 	mov	dptr,#_ak820_usb_send_PARM_3
      006AA8 E0               [24] 3243 	movx	a,@dptr
      006AA9 FE               [12] 3244 	mov  r6,a
      006AAA 24 BF            [12] 3245 	add	a,#0xff - 0x40
      006AAC 40 06            [24] 3246 	jc	00101$
                                   3247 ;	free result
      006AAE 90 07 C2         [24] 3248 	mov	dptr,#_USB_EnumStatus
      006AB1 E0               [24] 3249 	movx	a,@dptr
      006AB2 70 04            [24] 3250 	jnz	00102$
      006AB4                       3251 00101$:
      006AB4 75 82 00         [24] 3252 	mov	dpl, #0x00
      006AB7 22               [24] 3253 	ret
      006AB8                       3254 00102$:
                                   3255 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      006AB8 BF 01 10         [24] 3256 	cjne	r7,#0x01,00118$
                                   3257 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      006ABB BE 08 02         [24] 3258 	cjne	r6,#0x08,00313$
      006ABE 80 04            [24] 3259 	sjmp	00107$
      006AC0                       3260 00313$:
      006AC0 75 82 00         [24] 3261 	mov	dpl, #0x00
      006AC3 22               [24] 3262 	ret
      006AC4                       3263 00107$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006AC4 90 08 2B         [24] 3265 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006AC7 E4               [12] 3266 	clr	a
      006AC8 F0               [24] 3267 	movx	@dptr,a
      006AC9 80 3C            [24] 3268 	sjmp	00119$
      006ACB                       3269 00118$:
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      006ACB BF 02 30         [24] 3271 	cjne	r7,#0x02,00115$
                                   3272 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006ACE 90 08 27         [24] 3273 	mov	dptr,#_ak820_usb_send_PARM_2
      006AD1 E0               [24] 3274 	movx	a,@dptr
      006AD2 FD               [12] 3275 	mov	r5,a
      006AD3 A3               [24] 3276 	inc	dptr
      006AD4 E0               [24] 3277 	movx	a,@dptr
      006AD5 FF               [12] 3278 	mov	r7,a
      006AD6 8D 82            [24] 3279 	mov	dpl,r5
      006AD8 8F 83            [24] 3280 	mov	dph,r7
      006ADA E0               [24] 3281 	movx	a,@dptr
      006ADB FF               [12] 3282 	mov	r7,a
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006ADC BF 07 00         [24] 3284 	cjne	r7,#0x07,00316$
      006ADF                       3285 00316$:
      006ADF 50 0E            [24] 3286 	jnc	00108$
      006AE1 EF               [12] 3287 	mov	a,r7
      006AE2 90 BD A7         [24] 3288 	mov	dptr,#_shared_lengths
      006AE5 93               [24] 3289 	movc	a,@a+dptr
      006AE6 FD               [12] 3290 	mov	r5,a
      006AE7 60 06            [24] 3291 	jz	00108$
      006AE9 EE               [12] 3292 	mov	a,r6
      006AEA B5 05 02         [24] 3293 	cjne	a,ar5,00319$
      006AED 80 04            [24] 3294 	sjmp	00109$
      006AEF                       3295 00319$:
      006AEF                       3296 00108$:
      006AEF 75 82 00         [24] 3297 	mov	dpl, #0x00
      006AF2 22               [24] 3298 	ret
      006AF3                       3299 00109$:
                                   3300 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006AF3 EF               [12] 3301 	mov	a,r7
      006AF4 90 BD A0         [24] 3302 	mov	dptr,#_shared_offsets
      006AF7 93               [24] 3303 	movc	a,@a+dptr
      006AF8 90 08 2B         [24] 3304 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006AFB F0               [24] 3305 	movx	@dptr,a
      006AFC 80 09            [24] 3306 	sjmp	00119$
      006AFE                       3307 00115$:
                                   3308 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      006AFE BE 20 02         [24] 3309 	cjne	r6,#0x20,00320$
      006B01 80 04            [24] 3310 	sjmp	00119$
      006B03                       3311 00320$:
      006B03 75 82 00         [24] 3312 	mov	dpl, #0x00
      006B06 22               [24] 3313 	ret
      006B07                       3314 00119$:
                                   3315 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006B07 90 07 C3         [24] 3316 	mov	dptr,#_USB_SleepStatus
      006B0A E0               [24] 3317 	movx	a,@dptr
      006B0B 30 E1 07         [24] 3318 	jnb	acc.1,00184$
      006B0E 12 6A 5F         [24] 3319 	lcall	_USB_WakeUp_PC
      006B11 75 82 00         [24] 3320 	mov	dpl, #0x00
      006B14 22               [24] 3321 	ret
                                   3322 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006B15                       3323 00184$:
      006B15 7F FA            [12] 3324 	mov	r7,#0xfa
      006B17                       3325 00127$:
      006B17 90 08 2A         [24] 3326 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B1A E0               [24] 3327 	movx	a,@dptr
      006B1B FC               [12] 3328 	mov	r4,a
      006B1C 7D 00            [12] 3329 	mov	r5,#0x00
      006B1E 8C 02            [24] 3330 	mov	ar2,r4
      006B20 74 22            [12] 3331 	mov	a,#0x22
      006B22 2D               [12] 3332 	add	a, r5
      006B23 FB               [12] 3333 	mov	r3,a
      006B24 8A 82            [24] 3334 	mov	dpl,r2
      006B26 8B 83            [24] 3335 	mov	dph,r3
      006B28 E0               [24] 3336 	movx	a,@dptr
      006B29 54 03            [12] 3337 	anl	a,#0x03
      006B2B 70 20            [24] 3338 	jnz	00129$
      006B2D 8F 03            [24] 3339 	mov	ar3,r7
      006B2F 1F               [12] 3340 	dec	r7
      006B30 EB               [12] 3341 	mov	a,r3
      006B31 60 1A            [24] 3342 	jz	00129$
      006B33 7B 28            [12] 3343 	mov	r3,#0x28
      006B35                       3344 00141$:
      006B35 EB               [12] 3345 	mov	a,r3
      006B36 60 DF            [24] 3346 	jz	00127$
      006B38 90 00 01         [24] 3347 	mov	dptr,#0x0001
      006B3B C0 07            [24] 3348 	push	ar7
      006B3D C0 06            [24] 3349 	push	ar6
      006B3F C0 03            [24] 3350 	push	ar3
      006B41 12 5B DD         [24] 3351 	lcall	_mDelayuS
      006B44 D0 03            [24] 3352 	pop	ar3
      006B46 D0 06            [24] 3353 	pop	ar6
      006B48 D0 07            [24] 3354 	pop	ar7
      006B4A 1B               [12] 3355 	dec	r3
      006B4B 80 E8            [24] 3356 	sjmp	00141$
      006B4D                       3357 00129$:
                                   3358 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006B4D A2 AF            [12] 3359 	mov	c,_EA
      006B4F E4               [12] 3360 	clr	a
      006B50 33               [12] 3361 	rlc	a
      006B51 FF               [12] 3362 	mov	r7,a
                                   3363 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3364 ;	assignBit
      006B52 C2 AF            [12] 3365 	clr	_EA
                                   3366 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006B54 90 07 C2         [24] 3367 	mov	dptr,#_USB_EnumStatus
      006B57 E0               [24] 3368 	movx	a,@dptr
      006B58 60 25            [24] 3369 	jz	00130$
      006B5A 90 08 2A         [24] 3370 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B5D E0               [24] 3371 	movx	a,@dptr
      006B5E FB               [12] 3372 	mov	r3,a
      006B5F F9               [12] 3373 	mov	r1,a
      006B60 7A 00            [12] 3374 	mov	r2,#0x00
      006B62 74 22            [12] 3375 	mov	a,#0x22
      006B64 2A               [12] 3376 	add	a, r2
      006B65 FA               [12] 3377 	mov	r2,a
      006B66 89 82            [24] 3378 	mov	dpl,r1
      006B68 8A 83            [24] 3379 	mov	dph,r2
      006B6A E0               [24] 3380 	movx	a,@dptr
      006B6B FA               [12] 3381 	mov	r2,a
      006B6C 53 02 03         [24] 3382 	anl	ar2,#0x03
      006B6F BA 02 0D         [24] 3383 	cjne	r2,#0x02,00130$
                                   3384 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006B72 BB 03 13         [24] 3385 	cjne	r3,#0x03,00192$
      006B75 90 07 C9         [24] 3386 	mov	dptr,#_raw_state
      006B78 E0               [24] 3387 	movx	a,@dptr
      006B79 FB               [12] 3388 	mov	r3,a
      006B7A BB 03 02         [24] 3389 	cjne	r3,#0x03,00331$
      006B7D 80 09            [24] 3390 	sjmp	00192$
      006B7F                       3391 00331$:
      006B7F                       3392 00130$:
                                   3393 ;	assignBit
      006B7F EF               [12] 3394 	mov	a,r7
      006B80 24 FF            [12] 3395 	add	a,#0xff
      006B82 92 AF            [24] 3396 	mov	_EA,c
      006B84 75 82 00         [24] 3397 	mov	dpl, #0x00
      006B87 22               [24] 3398 	ret
                                   3399 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006B88                       3400 00192$:
      006B88 7B 00            [12] 3401 	mov	r3,#0x00
      006B8A                       3402 00144$:
      006B8A C3               [12] 3403 	clr	c
      006B8B EB               [12] 3404 	mov	a,r3
      006B8C 9E               [12] 3405 	subb	a,r6
      006B8D 50 67            [24] 3406 	jnc	00137$
                                   3407 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B8F C0 07            [24] 3408 	push	ar7
      006B91 90 08 2A         [24] 3409 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006B94 E0               [24] 3410 	movx	a,@dptr
      006B95 F9               [12] 3411 	mov	r1,a
      006B96 E4               [12] 3412 	clr	a
      006B97 C3               [12] 3413 	clr	c
      006B98 C9               [12] 3414 	xch	a,r1
      006B99 13               [12] 3415 	rrc	a
      006B9A C9               [12] 3416 	xch	a,r1
      006B9B 13               [12] 3417 	rrc	a
      006B9C A2 E0            [12] 3418 	mov	c,acc.0
      006B9E C9               [12] 3419 	xch	a,r1
      006B9F 13               [12] 3420 	rrc	a
      006BA0 C9               [12] 3421 	xch	a,r1
      006BA1 13               [12] 3422 	rrc	a
      006BA2 C9               [12] 3423 	xch	a,r1
      006BA3 FA               [12] 3424 	mov	r2,a
      006BA4 8B 00            [24] 3425 	mov	ar0,r3
      006BA6 7F 00            [12] 3426 	mov	r7,#0x00
      006BA8 E8               [12] 3427 	mov	a,r0
      006BA9 29               [12] 3428 	add	a, r1
      006BAA F9               [12] 3429 	mov	r1,a
      006BAB EF               [12] 3430 	mov	a,r7
      006BAC 3A               [12] 3431 	addc	a, r2
      006BAD 24 10            [12] 3432 	add	a,#0x10
      006BAF FA               [12] 3433 	mov	r2,a
      006BB0 90 08 27         [24] 3434 	mov	dptr,#_ak820_usb_send_PARM_2
      006BB3 E0               [24] 3435 	movx	a,@dptr
      006BB4 F8               [12] 3436 	mov	r0,a
      006BB5 A3               [24] 3437 	inc	dptr
      006BB6 E0               [24] 3438 	movx	a,@dptr
      006BB7 FF               [12] 3439 	mov	r7,a
      006BB8 EB               [12] 3440 	mov	a,r3
      006BB9 28               [12] 3441 	add	a, r0
      006BBA F5 1B            [12] 3442 	mov	_ak820_usb_send_sloc0_1_0,a
      006BBC E4               [12] 3443 	clr	a
      006BBD 3F               [12] 3444 	addc	a, r7
      006BBE F5 1C            [12] 3445 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006BC0 85 1B 82         [24] 3446 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BC3 85 1C 83         [24] 3447 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BC6 E0               [24] 3448 	movx	a,@dptr
      006BC7 89 82            [24] 3449 	mov	dpl,r1
      006BC9 8A 83            [24] 3450 	mov	dph,r2
      006BCB F0               [24] 3451 	movx	@dptr,a
                                   3452 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006BCC 90 08 2B         [24] 3453 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006BCF E0               [24] 3454 	movx	a,@dptr
      006BD0 F5 1D            [12] 3455 	mov	_ak820_usb_send_sloc1_1_0,a
      006BD2 74 2E            [12] 3456 	mov	a,#0x2e
      006BD4 B5 1D 04         [24] 3457 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006BD7 D0 07            [24] 3458 	pop	ar7
      006BD9 80 18            [24] 3459 	sjmp	00145$
      006BDB                       3460 00333$:
      006BDB D0 07            [24] 3461 	pop	ar7
      006BDD EB               [12] 3462 	mov	a,r3
      006BDE 25 1D            [12] 3463 	add	a, _ak820_usb_send_sloc1_1_0
      006BE0 24 EC            [12] 3464 	add	a, #_input_snapshot
      006BE2 F9               [12] 3465 	mov	r1,a
      006BE3 E4               [12] 3466 	clr	a
      006BE4 34 07            [12] 3467 	addc	a,#(_input_snapshot >> 8)
      006BE6 FA               [12] 3468 	mov	r2,a
      006BE7 85 1B 82         [24] 3469 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006BEA 85 1C 83         [24] 3470 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006BED E0               [24] 3471 	movx	a,@dptr
      006BEE 89 82            [24] 3472 	mov	dpl,r1
      006BF0 8A 83            [24] 3473 	mov	dph,r2
      006BF2 F0               [24] 3474 	movx	@dptr,a
      006BF3                       3475 00145$:
                                   3476 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006BF3 0B               [12] 3477 	inc	r3
      006BF4 80 94            [24] 3478 	sjmp	00144$
      006BF6                       3479 00137$:
                                   3480 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      006BF6 90 08 2A         [24] 3481 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BF9 E0               [24] 3482 	movx	a,@dptr
      006BFA FB               [12] 3483 	mov	r3,a
      006BFB F9               [12] 3484 	mov	r1,a
      006BFC 7A 00            [12] 3485 	mov	r2,#0x00
      006BFE 74 08            [12] 3486 	mov	a,#0x08
      006C00 29               [12] 3487 	add	a, r1
      006C01 F9               [12] 3488 	mov	r1,a
      006C02 74 22            [12] 3489 	mov	a,#0x22
      006C04 3A               [12] 3490 	addc	a, r2
      006C05 FA               [12] 3491 	mov	r2,a
      006C06 89 82            [24] 3492 	mov	dpl,r1
      006C08 8A 83            [24] 3493 	mov	dph,r2
      006C0A EE               [12] 3494 	mov	a,r6
      006C0B F0               [24] 3495 	movx	@dptr,a
                                   3496 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006C0C BB 03 06         [24] 3497 	cjne	r3,#0x03,00139$
      006C0F 90 07 C9         [24] 3498 	mov	dptr,#_raw_state
      006C12 74 04            [12] 3499 	mov	a,#0x04
      006C14 F0               [24] 3500 	movx	@dptr,a
      006C15                       3501 00139$:
                                   3502 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006C15 74 22            [12] 3503 	mov	a,#0x22
      006C17 2D               [12] 3504 	add	a, r5
      006C18 FD               [12] 3505 	mov	r5,a
      006C19 8C 82            [24] 3506 	mov	dpl,r4
      006C1B 8D 83            [24] 3507 	mov	dph,r5
      006C1D E0               [24] 3508 	movx	a,@dptr
      006C1E FE               [12] 3509 	mov	r6,a
      006C1F 53 06 FC         [24] 3510 	anl	ar6,#0xfc
      006C22 8C 82            [24] 3511 	mov	dpl,r4
      006C24 8D 83            [24] 3512 	mov	dph,r5
      006C26 EE               [12] 3513 	mov	a,r6
      006C27 F0               [24] 3514 	movx	@dptr,a
                                   3515 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3516 ;	assignBit
      006C28 EF               [12] 3517 	mov	a,r7
      006C29 24 FF            [12] 3518 	add	a,#0xff
      006C2B 92 AF            [24] 3519 	mov	_EA,c
                                   3520 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006C2D 75 82 01         [24] 3521 	mov	dpl, #0x01
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006C30 22               [24] 3523 	ret
                                   3524 ;------------------------------------------------------------
                                   3525 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3526 ;------------------------------------------------------------
                                   3527 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3528 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3529 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3530 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3531 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3532 ;------------------------------------------------------------
                                   3533 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3534 ;	-----------------------------------------
                                   3535 ;	 function ak820_usb_try_send
                                   3536 ;	-----------------------------------------
      006C31                       3537 _ak820_usb_try_send:
      006C31 E5 82            [12] 3538 	mov	a,dpl
      006C33 90 08 2F         [24] 3539 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006C36 F0               [24] 3540 	movx	@dptr,a
                                   3541 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3542 ;	assignBit
      006C37 A2 AF            [12] 3543 	mov	c,_EA
      006C39 92 1D            [24] 3544 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3545 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      006C3B 90 08 30         [24] 3546 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C3E E4               [12] 3547 	clr	a
      006C3F F0               [24] 3548 	movx	@dptr,a
                                   3549 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3550 ;	assignBit
      006C40 C2 AF            [12] 3551 	clr	_EA
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006C42 90 08 2F         [24] 3553 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006C45 E0               [24] 3554 	movx	a,@dptr
      006C46 FF               [12] 3555 	mov	r7,a
      006C47 BF 01 00         [24] 3556 	cjne	r7,#0x01,00152$
      006C4A                       3557 00152$:
      006C4A 40 4E            [24] 3558 	jc	00102$
      006C4C EF               [12] 3559 	mov	a,r7
      006C4D 24 FD            [12] 3560 	add	a,#0xff - 0x02
      006C4F 40 49            [24] 3561 	jc	00102$
                                   3562 ;	free result
      006C51 90 07 C2         [24] 3563 	mov	dptr,#_USB_EnumStatus
      006C54 E0               [24] 3564 	movx	a,@dptr
      006C55 60 43            [24] 3565 	jz	00102$
                                   3566 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006C57 90 07 C3         [24] 3567 	mov	dptr,#_USB_SleepStatus
      006C5A E0               [24] 3568 	movx	a,@dptr
      006C5B 20 E1 3C         [24] 3569 	jb	acc.1,00102$
      006C5E 90 07 EB         [24] 3570 	mov	dptr,#_keyboard_reset
      006C61 E0               [24] 3571 	movx	a,@dptr
                                   3572 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006C62 70 36            [24] 3573 	jnz	00102$
      006C64 8F 06            [24] 3574 	mov	ar6,r7
      006C66 24 22            [12] 3575 	add	a,#0x22
      006C68 FD               [12] 3576 	mov	r5,a
      006C69 8E 82            [24] 3577 	mov	dpl,r6
      006C6B 8D 83            [24] 3578 	mov	dph,r5
      006C6D E0               [24] 3579 	movx	a,@dptr
      006C6E FE               [12] 3580 	mov	r6,a
      006C6F 53 06 03         [24] 3581 	anl	ar6,#0x03
      006C72 BE 02 25         [24] 3582 	cjne	r6,#0x02,00102$
                                   3583 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006C75 90 08 2C         [24] 3584 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006C78 E0               [24] 3585 	movx	a,@dptr
      006C79 FD               [12] 3586 	mov	r5,a
      006C7A A3               [24] 3587 	inc	dptr
      006C7B E0               [24] 3588 	movx	a,@dptr
      006C7C FE               [12] 3589 	mov	r6,a
      006C7D 90 08 2E         [24] 3590 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006C80 E0               [24] 3591 	movx	a,@dptr
      006C81 FC               [12] 3592 	mov	r4,a
      006C82 90 08 27         [24] 3593 	mov	dptr,#_ak820_usb_send_PARM_2
      006C85 ED               [12] 3594 	mov	a,r5
      006C86 F0               [24] 3595 	movx	@dptr,a
      006C87 EE               [12] 3596 	mov	a,r6
      006C88 A3               [24] 3597 	inc	dptr
      006C89 F0               [24] 3598 	movx	@dptr,a
      006C8A 90 08 29         [24] 3599 	mov	dptr,#_ak820_usb_send_PARM_3
      006C8D EC               [12] 3600 	mov	a,r4
      006C8E F0               [24] 3601 	movx	@dptr,a
      006C8F 8F 82            [24] 3602 	mov	dpl, r7
      006C91 12 6A 8A         [24] 3603 	lcall	_ak820_usb_send
      006C94 E5 82            [12] 3604 	mov	a, dpl
      006C96 90 08 30         [24] 3605 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006C99 F0               [24] 3606 	movx	@dptr,a
      006C9A                       3607 00102$:
                                   3608 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3609 ;	assignBit
      006C9A A2 1D            [12] 3610 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C9C 92 AF            [24] 3611 	mov	_EA,c
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006C9E 90 08 30         [24] 3613 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006CA1 E0               [24] 3614 	movx	a,@dptr
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006CA2 F5 82            [12] 3616 	mov	dpl,a
      006CA4 22               [24] 3617 	ret
                                   3618 ;------------------------------------------------------------
                                   3619 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3620 ;------------------------------------------------------------
                                   3621 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3622 ;	-----------------------------------------
                                   3623 ;	 function raw_request_is_nonpersistent
                                   3624 ;	-----------------------------------------
      006CA5                       3625 _raw_request_is_nonpersistent:
                                   3626 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006CA5 90 07 CA         [24] 3627 	mov	dptr,#_raw_buffer
      006CA8 E0               [24] 3628 	movx	a,@dptr
      006CA9 FF               [12] 3629 	mov	r7,a
      006CAA BF 01 02         [24] 3630 	cjne	r7,#0x01,00302$
      006CAD 80 35            [24] 3631 	sjmp	00108$
      006CAF                       3632 00302$:
      006CAF BF 02 02         [24] 3633 	cjne	r7,#0x02,00303$
      006CB2 80 34            [24] 3634 	sjmp	00109$
      006CB4                       3635 00303$:
      006CB4 BF 04 02         [24] 3636 	cjne	r7,#0x04,00304$
      006CB7 80 2B            [24] 3637 	sjmp	00108$
      006CB9                       3638 00304$:
      006CB9 BF 08 02         [24] 3639 	cjne	r7,#0x08,00305$
      006CBC 80 47            [24] 3640 	sjmp	00116$
      006CBE                       3641 00305$:
      006CBE BF 0B 02         [24] 3642 	cjne	r7,#0x0b,00306$
      006CC1 80 21            [24] 3643 	sjmp	00108$
      006CC3                       3644 00306$:
      006CC3 BF 0C 02         [24] 3645 	cjne	r7,#0x0c,00307$
      006CC6 80 1C            [24] 3646 	sjmp	00108$
      006CC8                       3647 00307$:
      006CC8 BF 0D 02         [24] 3648 	cjne	r7,#0x0d,00308$
      006CCB 80 17            [24] 3649 	sjmp	00108$
      006CCD                       3650 00308$:
      006CCD BF 0E 02         [24] 3651 	cjne	r7,#0x0e,00309$
      006CD0 80 12            [24] 3652 	sjmp	00108$
      006CD2                       3653 00309$:
      006CD2 BF 11 02         [24] 3654 	cjne	r7,#0x11,00310$
      006CD5 80 0D            [24] 3655 	sjmp	00108$
      006CD7                       3656 00310$:
      006CD7 BF 12 02         [24] 3657 	cjne	r7,#0x12,00311$
      006CDA 80 08            [24] 3658 	sjmp	00108$
      006CDC                       3659 00311$:
      006CDC BF FE 02         [24] 3660 	cjne	r7,#0xfe,00312$
      006CDF 80 46            [24] 3661 	sjmp	00124$
      006CE1                       3662 00312$:
      006CE1 02 6D 7C         [24] 3663 	ljmp	00144$
                                   3664 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006CE4                       3665 00108$:
                                   3666 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006CE4 75 82 01         [24] 3667 	mov	dpl, #0x01
      006CE7 22               [24] 3668 	ret
                                   3669 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      006CE8                       3670 00109$:
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      006CE8 12 6F D0         [24] 3672 	lcall	_ak820_outline_0166
      006CEB BF 01 02         [24] 3673 	cjne	r7,#0x01,00313$
      006CEE 80 0D            [24] 3674 	sjmp	00113$
      006CF0                       3675 00313$:
      006CF0 BF 02 02         [24] 3676 	cjne	r7,#0x02,00314$
      006CF3 80 08            [24] 3677 	sjmp	00113$
      006CF5                       3678 00314$:
      006CF5 BF 03 02         [24] 3679 	cjne	r7,#0x03,00315$
      006CF8 80 03            [24] 3680 	sjmp	00113$
      006CFA                       3681 00315$:
      006CFA BF 04 04         [24] 3682 	cjne	r7,#0x04,00114$
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006CFD                       3684 00113$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006CFD 75 82 01         [24] 3686 	mov	dpl, #0x01
      006D00 22               [24] 3687 	ret
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006D01                       3689 00114$:
      006D01 75 82 00         [24] 3690 	mov	dpl, #0x00
      006D04 22               [24] 3691 	ret
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006D05                       3693 00116$:
                                   3694 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006D05 12 6F D0         [24] 3695 	lcall	_ak820_outline_0166
      006D08 BF 40 02         [24] 3696 	cjne	r7,#0x40,00318$
      006D0B 80 12            [24] 3697 	sjmp	00121$
      006D0D                       3698 00318$:
      006D0D BF 41 02         [24] 3699 	cjne	r7,#0x41,00319$
      006D10 80 0D            [24] 3700 	sjmp	00121$
      006D12                       3701 00319$:
      006D12 BF 42 02         [24] 3702 	cjne	r7,#0x42,00320$
      006D15 80 08            [24] 3703 	sjmp	00121$
      006D17                       3704 00320$:
      006D17 BF 43 02         [24] 3705 	cjne	r7,#0x43,00321$
      006D1A 80 03            [24] 3706 	sjmp	00121$
      006D1C                       3707 00321$:
      006D1C BF 44 04         [24] 3708 	cjne	r7,#0x44,00122$
                                   3709 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006D1F                       3710 00121$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006D1F 75 82 01         [24] 3712 	mov	dpl, #0x01
                                   3713 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006D22 22               [24] 3714 	ret
      006D23                       3715 00122$:
      006D23 75 82 00         [24] 3716 	mov	dpl, #0x00
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      006D26 22               [24] 3718 	ret
      006D27                       3719 00124$:
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      006D27 12 6F D0         [24] 3721 	lcall	_ak820_outline_0166
      006D2A 24 F2            [12] 3722 	add	a,#0xff - 0x0d
      006D2C 40 4A            [24] 3723 	jc	00142$
                                   3724 ;	free result
      006D2E EF               [12] 3725 	mov	a,r7
      006D2F 24 0A            [12] 3726 	add	a,#(00325$-3-.)
      006D31 83               [24] 3727 	movc	a,@a+pc
      006D32 F5 82            [12] 3728 	mov	dpl,a
      006D34 EF               [12] 3729 	mov	a,r7
      006D35 24 12            [12] 3730 	add	a,#(00326$-3-.)
      006D37 83               [24] 3731 	movc	a,@a+pc
      006D38 F5 83            [12] 3732 	mov	dph,a
      006D3A E4               [12] 3733 	clr	a
      006D3B 73               [24] 3734 	jmp	@a+dptr
      006D3C                       3735 00325$:
      006D3C 58                    3736 	.db	00134$
      006D3D 58                    3737 	.db	00134$
      006D3E 58                    3738 	.db	00134$
      006D3F 58                    3739 	.db	00134$
      006D40 78                    3740 	.db	00142$
      006D41 58                    3741 	.db	00134$
      006D42 58                    3742 	.db	00134$
      006D43 58                    3743 	.db	00134$
      006D44 58                    3744 	.db	00134$
      006D45 58                    3745 	.db	00134$
      006D46 58                    3746 	.db	00134$
      006D47 78                    3747 	.db	00142$
      006D48 78                    3748 	.db	00142$
      006D49 5C                    3749 	.db	00135$
      006D4A                       3750 00326$:
      006D4A 6D                    3751 	.db	00134$>>8
      006D4B 6D                    3752 	.db	00134$>>8
      006D4C 6D                    3753 	.db	00134$>>8
      006D4D 6D                    3754 	.db	00134$>>8
      006D4E 6D                    3755 	.db	00142$>>8
      006D4F 6D                    3756 	.db	00134$>>8
      006D50 6D                    3757 	.db	00134$>>8
      006D51 6D                    3758 	.db	00134$>>8
      006D52 6D                    3759 	.db	00134$>>8
      006D53 6D                    3760 	.db	00134$>>8
      006D54 6D                    3761 	.db	00134$>>8
      006D55 6D                    3762 	.db	00142$>>8
      006D56 6D                    3763 	.db	00142$>>8
      006D57 6D                    3764 	.db	00135$>>8
                                   3765 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006D58                       3766 00134$:
                                   3767 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006D58 75 82 01         [24] 3768 	mov	dpl, #0x01
                                   3769 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006D5B 22               [24] 3770 	ret
      006D5C                       3771 00135$:
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006D5C 90 07 CC         [24] 3773 	mov	dptr,#(_raw_buffer + 0x0002)
      006D5F E0               [24] 3774 	movx	a,@dptr
      006D60 FF               [12] 3775 	mov	r7,a
      006D61 60 0D            [24] 3776 	jz	00139$
      006D63 BF 01 02         [24] 3777 	cjne	r7,#0x01,00328$
      006D66 80 08            [24] 3778 	sjmp	00139$
      006D68                       3779 00328$:
      006D68 BF 03 02         [24] 3780 	cjne	r7,#0x03,00329$
      006D6B 80 03            [24] 3781 	sjmp	00139$
      006D6D                       3782 00329$:
      006D6D BF 05 04         [24] 3783 	cjne	r7,#0x05,00140$
                                   3784 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006D70                       3785 00139$:
                                   3786 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006D70 75 82 01         [24] 3787 	mov	dpl, #0x01
                                   3788 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006D73 22               [24] 3789 	ret
      006D74                       3790 00140$:
      006D74 75 82 00         [24] 3791 	mov	dpl, #0x00
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006D77 22               [24] 3793 	ret
      006D78                       3794 00142$:
      006D78 75 82 00         [24] 3795 	mov	dpl, #0x00
                                   3796 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006D7B 22               [24] 3797 	ret
      006D7C                       3798 00144$:
      006D7C 75 82 00         [24] 3799 	mov	dpl, #0x00
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3801 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006D7F 22               [24] 3802 	ret
                                   3803 ;------------------------------------------------------------
                                   3804 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3805 ;------------------------------------------------------------
                                   3806 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3807 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3808 ;------------------------------------------------------------
                                   3809 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3810 ;	-----------------------------------------
                                   3811 ;	 function ak820_usb_raw_send
                                   3812 ;	-----------------------------------------
      006D80                       3813 _ak820_usb_raw_send:
      006D80 12 46 60         [24] 3814 	lcall	_ak820_outline_0036
      006D83 90 08 32         [24] 3815 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006D86 12 38 1F         [24] 3816 	lcall	_ak820_outline_0016
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006D89 90 08 31         [24] 3818 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D8C E0               [24] 3819 	movx	a,@dptr
      006D8D FF               [12] 3820 	mov	r7,a
      006D8E BF 20 2B         [24] 3821 	cjne	r7,#0x20,00106$
                                   3822 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006D91 C0 07            [24] 3823 	push	ar7
      006D93 12 41 76         [24] 3824 	lcall	_ak820_nvm_flush
      006D96 D0 07            [24] 3825 	pop	ar7
                                   3826 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D98 90 07 EA         [24] 3827 	mov	dptr,#_raw_reply_without_nvm
      006D9B E0               [24] 3828 	movx	a,@dptr
      006D9C 70 07            [24] 3829 	jnz	00103$
      006D9E 12 41 67         [24] 3830 	lcall	_ak820_nvm_ok
      006DA1 E5 82            [12] 3831 	mov	a, dpl
      006DA3 60 17            [24] 3832 	jz	00106$
      006DA5                       3833 00103$:
      006DA5 90 08 32         [24] 3834 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006DA8 12 38 64         [24] 3835 	lcall	_ak820_outline_0080
      006DAB 90 08 27         [24] 3836 	mov	dptr,#_ak820_usb_send_PARM_2
      006DAE 12 46 CA         [24] 3837 	lcall	_ak820_outline_0164
      006DB1 90 08 29         [24] 3838 	mov	dptr,#_ak820_usb_send_PARM_3
      006DB4 EF               [12] 3839 	mov	a,r7
      006DB5 F0               [24] 3840 	movx	@dptr,a
      006DB6 75 82 03         [24] 3841 	mov	dpl, #0x03
                                   3842 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006DB9 02 6A 8A         [24] 3843 	ljmp	_ak820_usb_send
      006DBC                       3844 00106$:
      006DBC 22               [24] 3845 	ret
                                   3846 ;------------------------------------------------------------
                                   3847 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3848 ;------------------------------------------------------------
                                   3849 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3850 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3851 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3852 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3853 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3854 ;------------------------------------------------------------
                                   3855 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3856 ;	-----------------------------------------
                                   3857 ;	 function ak820_usb_raw_task
                                   3858 ;	-----------------------------------------
      006DBD                       3859 _ak820_usb_raw_task:
                                   3860 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006DBD A2 AF            [12] 3861 	mov	c,_EA
      006DBF E4               [12] 3862 	clr	a
      006DC0 33               [12] 3863 	rlc	a
      006DC1 FF               [12] 3864 	mov	r7,a
                                   3865 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3866 ;	assignBit
      006DC2 C2 AF            [12] 3867 	clr	_EA
                                   3868 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006DC4 90 07 C2         [24] 3869 	mov	dptr,#_USB_EnumStatus
      006DC7 E0               [24] 3870 	movx	a,@dptr
      006DC8 60 0A            [24] 3871 	jz	00101$
      006DCA 90 07 C9         [24] 3872 	mov	dptr,#_raw_state
      006DCD E0               [24] 3873 	movx	a,@dptr
      006DCE FE               [12] 3874 	mov	r6,a
      006DCF BE 02 02         [24] 3875 	cjne	r6,#0x02,00270$
      006DD2 80 06            [24] 3876 	sjmp	00102$
      006DD4                       3877 00270$:
      006DD4                       3878 00101$:
                                   3879 ;	assignBit
      006DD4 EF               [12] 3880 	mov	a,r7
      006DD5 24 FF            [12] 3881 	add	a,#0xff
      006DD7 92 AF            [24] 3882 	mov	_EA,c
      006DD9 22               [24] 3883 	ret
      006DDA                       3884 00102$:
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006DDA 90 07 C9         [24] 3886 	mov	dptr,#_raw_state
      006DDD 74 03            [12] 3887 	mov	a,#0x03
      006DDF F0               [24] 3888 	movx	@dptr,a
                                   3889 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3890 ;	assignBit
      006DE0 EF               [12] 3891 	mov	a,r7
      006DE1 24 FF            [12] 3892 	add	a,#0xff
      006DE3 92 AF            [24] 3893 	mov	_EA,c
                                   3894 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006DE5 90 07 CA         [24] 3895 	mov	dptr,#_raw_buffer
      006DE8 E0               [24] 3896 	movx	a,@dptr
      006DE9 FF               [12] 3897 	mov	r7,a
      006DEA E4               [12] 3898 	clr	a
      006DEB BF FD 01         [24] 3899 	cjne	r7,#0xfd,00271$
      006DEE 04               [12] 3900 	inc	a
      006DEF                       3901 00271$:
      006DEF FF               [12] 3902 	mov	r7,a
      006DF0 70 03            [24] 3903 	jnz	00273$
      006DF2 02 6E 92         [24] 3904 	ljmp	00118$
      006DF5                       3905 00273$:
      006DF5 90 07 CB         [24] 3906 	mov	dptr,#(_raw_buffer + 0x0001)
      006DF8 E0               [24] 3907 	movx	a,@dptr
      006DF9 60 03            [24] 3908 	jz	00274$
      006DFB 02 6E 92         [24] 3909 	ljmp	00118$
      006DFE                       3910 00274$:
                                   3911 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006DFE 90 07 CC         [24] 3912 	mov	dptr,#(_raw_buffer + 0x0002)
      006E01 E0               [24] 3913 	movx	a,@dptr
      006E02 FD               [12] 3914 	mov	r5,a
      006E03 7E 00            [12] 3915 	mov	r6,#0x00
      006E05 90 07 CD         [24] 3916 	mov	dptr,#(_raw_buffer + 0x0003)
      006E08 E0               [24] 3917 	movx	a,@dptr
      006E09 7B 00            [12] 3918 	mov	r3,#0x00
      006E0B 42 06            [12] 3919 	orl	ar6,a
      006E0D EB               [12] 3920 	mov	a,r3
      006E0E 42 05            [12] 3921 	orl	ar5,a
                                   3922 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006E10 90 07 CE         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0004)
      006E13 E0               [24] 3924 	movx	a,@dptr
      006E14 FC               [12] 3925 	mov	r4,a
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E15 7B 05            [12] 3927 	mov	r3,#0x05
      006E17                       3928 00128$:
      006E17 EB               [12] 3929 	mov	a,r3
      006E18 12 6F BE         [24] 3930 	lcall	_ak820_outline_0107
      006E1B 0B               [12] 3931 	inc	r3
      006E1C BB 20 00         [24] 3932 	cjne	r3,#0x20,00275$
      006E1F                       3933 00275$:
      006E1F 40 F6            [24] 3934 	jc	00128$
                                   3935 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006E21 EC               [12] 3936 	mov	a,r4
      006E22 24 E4            [12] 3937 	add	a,#0xff - 0x1b
      006E24 40 1C            [24] 3938 	jc	00106$
                                   3939 ;	free result
      006E26 EC               [12] 3940 	mov	a,r4
      006E27 60 26            [24] 3941 	jz	00165$
      006E29 8C 03            [24] 3942 	mov	ar3,r4
      006E2B 1B               [12] 3943 	dec	r3
      006E2C 7A 00            [12] 3944 	mov	r2,#0x00
      006E2E 74 FF            [12] 3945 	mov	a,#0xff
      006E30 C3               [12] 3946 	clr	c
      006E31 9B               [12] 3947 	subb	a,r3
      006E32 FB               [12] 3948 	mov	r3,a
      006E33 74 FF            [12] 3949 	mov	a,#0xff
      006E35 9A               [12] 3950 	subb	a,r2
      006E36 FA               [12] 3951 	mov	r2,a
      006E37 8E 00            [24] 3952 	mov	ar0,r6
      006E39 8D 01            [24] 3953 	mov	ar1,r5
      006E3B C3               [12] 3954 	clr	c
      006E3C EB               [12] 3955 	mov	a,r3
      006E3D 98               [12] 3956 	subb	a,r0
      006E3E EA               [12] 3957 	mov	a,r2
      006E3F 99               [12] 3958 	subb	a,r1
      006E40 50 0D            [24] 3959 	jnc	00165$
                                   3960 ;	free result
      006E42                       3961 00106$:
                                   3962 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006E42 90 07 CB         [24] 3963 	mov	dptr,#(_raw_buffer + 0x0001)
      006E45 74 FF            [12] 3964 	mov	a,#0xff
      006E47 F0               [24] 3965 	movx	@dptr,a
                                   3966 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006E48 90 07 CE         [24] 3967 	mov	dptr,#(_raw_buffer + 0x0004)
      006E4B E4               [12] 3968 	clr	a
      006E4C F0               [24] 3969 	movx	@dptr,a
                                   3970 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006E4D 80 3A            [24] 3971 	sjmp	00108$
      006E4F                       3972 00165$:
      006E4F 7B 00            [12] 3973 	mov	r3,#0x00
      006E51                       3974 00131$:
      006E51 C3               [12] 3975 	clr	c
      006E52 EB               [12] 3976 	mov	a,r3
      006E53 9C               [12] 3977 	subb	a,r4
      006E54 50 33            [24] 3978 	jnc	00108$
      006E56 C0 04            [24] 3979 	push	ar4
      006E58 8B 02            [24] 3980 	mov	ar2,r3
      006E5A 74 05            [12] 3981 	mov	a,#0x05
      006E5C 2A               [12] 3982 	add	a, r2
      006E5D F9               [12] 3983 	mov	r1,a
      006E5E 33               [12] 3984 	rlc	a
      006E5F 95 E0            [12] 3985 	subb	a,acc
      006E61 FA               [12] 3986 	mov	r2,a
      006E62 E9               [12] 3987 	mov	a,r1
      006E63 24 CA            [12] 3988 	add	a, #_raw_buffer
      006E65 F9               [12] 3989 	mov	r1,a
      006E66 EA               [12] 3990 	mov	a,r2
      006E67 34 07            [12] 3991 	addc	a, #(_raw_buffer >> 8)
      006E69 FA               [12] 3992 	mov	r2,a
      006E6A 8B 1E            [24] 3993 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006E6C 75 1F 00         [24] 3994 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006E6F 8E 00            [24] 3995 	mov	ar0,r6
      006E71 8D 04            [24] 3996 	mov	ar4,r5
      006E73 E5 1E            [12] 3997 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006E75 28               [12] 3998 	add	a, r0
      006E76 F8               [12] 3999 	mov	r0,a
      006E77 E5 1F            [12] 4000 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006E79 3C               [12] 4001 	addc	a, r4
      006E7A FC               [12] 4002 	mov	r4,a
      006E7B 88 82            [24] 4003 	mov	dpl,r0
      006E7D 8C 83            [24] 4004 	mov	dph,r4
      006E7F E4               [12] 4005 	clr	a
      006E80 93               [24] 4006 	movc	a,@a+dptr
      006E81 12 6F CA         [24] 4007 	lcall	_ak820_outline_0141
      006E84 0B               [12] 4008 	inc	r3
      006E85 D0 04            [24] 4009 	pop	ar4
      006E87 80 C8            [24] 4010 	sjmp	00131$
      006E89                       4011 00108$:
                                   4012 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E89 12 6F AA         [24] 4013 	lcall	_ak820_outline_0045
      006E8C 12 6A 8A         [24] 4014 	lcall	_ak820_usb_send
      006E8F 02 6F 38         [24] 4015 	ljmp	00119$
      006E92                       4016 00118$:
                                   4017 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E92 EF               [12] 4018 	mov	a,r7
      006E93 70 03            [24] 4019 	jnz	00281$
      006E95 02 6F 15         [24] 4020 	ljmp	00114$
      006E98                       4021 00281$:
      006E98 12 6F D0         [24] 4022 	lcall	_ak820_outline_0166
      006E9B BF 01 02         [24] 4023 	cjne	r7,#0x01,00282$
      006E9E 80 03            [24] 4024 	sjmp	00283$
      006EA0                       4025 00282$:
      006EA0 02 6F 15         [24] 4026 	ljmp	00114$
      006EA3                       4027 00283$:
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006EA3 7F 02            [12] 4029 	mov	r7,#0x02
      006EA5                       4030 00133$:
      006EA5 EF               [12] 4031 	mov	a,r7
      006EA6 12 6F BE         [24] 4032 	lcall	_ak820_outline_0107
      006EA9 0F               [12] 4033 	inc	r7
      006EAA BF 20 00         [24] 4034 	cjne	r7,#0x20,00284$
      006EAD                       4035 00284$:
      006EAD 40 F6            [24] 4036 	jc	00133$
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006EAF 90 07 CC         [24] 4038 	mov	dptr,#(_raw_buffer + 0x0002)
      006EB2 74 01            [12] 4039 	mov	a,#0x01
      006EB4 F0               [24] 4040 	movx	@dptr,a
                                   4041 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006EB5 90 07 CD         [24] 4042 	mov	dptr,#(_raw_buffer + 0x0003)
      006EB8 74 A8            [12] 4043 	mov	a,#0xa8
      006EBA F0               [24] 4044 	movx	@dptr,a
                                   4045 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006EBB 90 07 CE         [24] 4046 	mov	dptr,#(_raw_buffer + 0x0004)
      006EBE 12 3E E4         [24] 4047 	lcall	_ak820_nvm_diagnostic
                                   4048 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006EC1 7F 00            [12] 4049 	mov	r7,#0x00
      006EC3                       4050 00135$:
      006EC3 8F 06            [24] 4051 	mov	ar6,r7
      006EC5 74 0B            [12] 4052 	mov	a,#0x0b
      006EC7 2E               [12] 4053 	add	a, r6
      006EC8 24 CA            [12] 4054 	add	a,#_raw_buffer
      006ECA FE               [12] 4055 	mov	r6,a
      006ECB E4               [12] 4056 	clr	a
      006ECC 34 07            [12] 4057 	addc	a, #(_raw_buffer >> 8)
      006ECE FD               [12] 4058 	mov	r5,a
      006ECF EF               [12] 4059 	mov	a,r7
      006ED0 24 BA            [12] 4060 	add	a, #_ak820_flash_diagnostic
      006ED2 F5 82            [12] 4061 	mov	dpl,a
      006ED4 E4               [12] 4062 	clr	a
      006ED5 34 04            [12] 4063 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006ED7 F5 83            [12] 4064 	mov	dph,a
      006ED9 E0               [24] 4065 	movx	a,@dptr
      006EDA 8E 82            [24] 4066 	mov	dpl,r6
      006EDC 8D 83            [24] 4067 	mov	dph,r5
      006EDE F0               [24] 4068 	movx	@dptr,a
      006EDF 0F               [12] 4069 	inc	r7
      006EE0 BF 06 00         [24] 4070 	cjne	r7,#0x06,00286$
      006EE3                       4071 00286$:
      006EE3 40 DE            [24] 4072 	jc	00135$
                                   4073 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006EE5 90 0E 7A         [24] 4074 	mov	dptr,#_vial_unlocked
      006EE8 E0               [24] 4075 	movx	a,@dptr
      006EE9 90 07 DB         [24] 4076 	mov	dptr,#(_raw_buffer + 0x0011)
      006EEC F0               [24] 4077 	movx	@dptr,a
                                   4078 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006EED 90 0E 7B         [24] 4079 	mov	dptr,#_vial_unlock_in_progress
      006EF0 E0               [24] 4080 	movx	a,@dptr
      006EF1 90 07 DC         [24] 4081 	mov	dptr,#(_raw_buffer + 0x0012)
      006EF4 F0               [24] 4082 	movx	@dptr,a
                                   4083 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006EF5 90 07 C2         [24] 4084 	mov	dptr,#_USB_EnumStatus
      006EF8 E0               [24] 4085 	movx	a,@dptr
      006EF9 90 07 DD         [24] 4086 	mov	dptr,#(_raw_buffer + 0x0013)
      006EFC F0               [24] 4087 	movx	@dptr,a
                                   4088 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006EFD 90 07 C3         [24] 4089 	mov	dptr,#_USB_SleepStatus
      006F00 E0               [24] 4090 	movx	a,@dptr
      006F01 90 07 DE         [24] 4091 	mov	dptr,#(_raw_buffer + 0x0014)
      006F04 F0               [24] 4092 	movx	@dptr,a
                                   4093 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006F05 90 07 C9         [24] 4094 	mov	dptr,#_raw_state
      006F08 E0               [24] 4095 	movx	a,@dptr
      006F09 90 07 DF         [24] 4096 	mov	dptr,#(_raw_buffer + 0x0015)
      006F0C F0               [24] 4097 	movx	@dptr,a
                                   4098 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006F0D 12 6F AA         [24] 4099 	lcall	_ak820_outline_0045
      006F10 12 6A 8A         [24] 4100 	lcall	_ak820_usb_send
      006F13 80 23            [24] 4101 	sjmp	00119$
      006F15                       4102 00114$:
                                   4103 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006F15 12 6C A5         [24] 4104 	lcall	_raw_request_is_nonpersistent
      006F18 E5 82            [12] 4105 	mov	a, dpl
      006F1A 90 07 EA         [24] 4106 	mov	dptr,#_raw_reply_without_nvm
      006F1D F0               [24] 4107 	movx	@dptr,a
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006F1E 12 42 C9         [24] 4109 	lcall	_ak820_nvm_begin
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006F21 90 0C AC         [24] 4111 	mov	dptr,#_raw_hid_receive_PARM_2
      006F24 74 20            [12] 4112 	mov	a,#0x20
      006F26 F0               [24] 4113 	movx	@dptr,a
      006F27 90 07 CA         [24] 4114 	mov	dptr,#_raw_buffer
      006F2A 75 F0 00         [24] 4115 	mov	b, #0x00
      006F2D 12 AA CC         [24] 4116 	lcall	_raw_hid_receive
                                   4117 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006F30 12 42 DE         [24] 4118 	lcall	_ak820_nvm_end
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006F33 90 07 EA         [24] 4120 	mov	dptr,#_raw_reply_without_nvm
      006F36 E4               [12] 4121 	clr	a
      006F37 F0               [24] 4122 	movx	@dptr,a
      006F38                       4123 00119$:
                                   4124 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4125 ;	assignBit
      006F38 A2 AF            [12] 4126 	mov	c,_EA
      006F3A 92 1E            [24] 4127 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4128 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4129 ;	assignBit
      006F3C C2 AF            [12] 4130 	clr	_EA
                                   4131 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006F3E 12 6F D6         [24] 4132 	lcall	_ak820_outline_0168
      006F41 BF 04 08         [24] 4133 	cjne	r7,#0x04,00126$
      006F44 90 07 C9         [24] 4134 	mov	dptr,#_raw_state
      006F47 74 05            [12] 4135 	mov	a,#0x05
      006F49 F0               [24] 4136 	movx	@dptr,a
      006F4A 80 1B            [24] 4137 	sjmp	00127$
      006F4C                       4138 00126$:
                                   4139 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006F4C 12 6F D6         [24] 4140 	lcall	_ak820_outline_0168
      006F4F BF 03 02         [24] 4141 	cjne	r7,#0x03,00290$
      006F52 80 0E            [24] 4142 	sjmp	00121$
      006F54                       4143 00290$:
      006F54 12 6F D6         [24] 4144 	lcall	_ak820_outline_0168
      006F57 BF 06 02         [24] 4145 	cjne	r7,#0x06,00291$
      006F5A 80 06            [24] 4146 	sjmp	00121$
      006F5C                       4147 00291$:
      006F5C 12 6F D6         [24] 4148 	lcall	_ak820_outline_0168
      006F5F BF 07 05         [24] 4149 	cjne	r7,#0x07,00127$
      006F62                       4150 00121$:
      006F62 90 07 C9         [24] 4151 	mov	dptr,#_raw_state
      006F65 E4               [12] 4152 	clr	a
      006F66 F0               [24] 4153 	movx	@dptr,a
      006F67                       4154 00127$:
                                   4155 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4156 ;	assignBit
      006F67 A2 1E            [12] 4157 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006F69 92 AF            [24] 4158 	mov	_EA,c
                                   4159 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006F6B 22               [24] 4160 	ret
                                   4161 ;------------------------------------------------------------
                                   4162 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4163 ;------------------------------------------------------------
                                   4164 ;	tmk_core/protocol/ch555/usb_ak820.c:665: bool ak820_usb_keyboard_blocked(void) {
                                   4165 ;	-----------------------------------------
                                   4166 ;	 function ak820_usb_keyboard_blocked
                                   4167 ;	-----------------------------------------
      006F6C                       4168 _ak820_usb_keyboard_blocked:
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:666: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      006F6C 90 07 C2         [24] 4170 	mov	dptr,#_USB_EnumStatus
      006F6F E0               [24] 4171 	movx	a,@dptr
      006F70 60 13            [24] 4172 	jz	00104$
      006F72 90 07 C3         [24] 4173 	mov	dptr,#_USB_SleepStatus
      006F75 E0               [24] 4174 	movx	a,@dptr
      006F76 03               [12] 4175 	rr	a
      006F77 54 01            [12] 4176 	anl	a,#0x01
      006F79 70 0A            [24] 4177 	jnz	00104$
      006F7B 90 07 EB         [24] 4178 	mov	dptr,#_keyboard_reset
      006F7E E0               [24] 4179 	movx	a,@dptr
      006F7F 70 04            [24] 4180 	jnz	00104$
                                   4181 ;	assignBit
      006F81 C2 1F            [12] 4182 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      006F83 80 02            [24] 4183 	sjmp	00105$
      006F85                       4184 00104$:
                                   4185 ;	assignBit
      006F85 D2 1F            [12] 4186 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      006F87                       4187 00105$:
      006F87 A2 1F            [12] 4188 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      006F89 E4               [12] 4189 	clr	a
      006F8A 33               [12] 4190 	rlc	a
      006F8B F5 82            [12] 4191 	mov	dpl, a
                                   4192 ;	tmk_core/protocol/ch555/usb_ak820.c:667: }
      006F8D 22               [24] 4193 	ret
                                   4194 ;------------------------------------------------------------
                                   4195 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4196 ;------------------------------------------------------------
                                   4197 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_485'
                                   4198 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_485'
                                   4199 ;------------------------------------------------------------
                                   4200 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4201 ;	-----------------------------------------
                                   4202 ;	 function ak820_usb_take_keyboard_reset
                                   4203 ;	-----------------------------------------
      006F8E                       4204 _ak820_usb_take_keyboard_reset:
                                   4205 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4206 ;	assignBit
      006F8E A2 AF            [12] 4207 	mov	c,_EA
      006F90 92 20            [24] 4208 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4209 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4210 ;	assignBit
      006F92 C2 AF            [12] 4211 	clr	_EA
                                   4212 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006F94 90 07 EB         [24] 4213 	mov	dptr,#_keyboard_reset
      006F97 E0               [24] 4214 	movx	a,@dptr
      006F98 FF               [12] 4215 	mov	r7,a
                                   4216 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006F99 E4               [12] 4217 	clr	a
      006F9A F0               [24] 4218 	movx	@dptr,a
                                   4219 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4220 ;	assignBit
      006F9B A2 20            [12] 4221 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006F9D 92 AF            [24] 4222 	mov	_EA,c
                                   4223 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006F9F EF               [12] 4224 	mov	a,r7
      006FA0 B4 01 00         [24] 4225 	cjne	a,#0x01,00103$
      006FA3                       4226 00103$:
      006FA3 B3               [12] 4227 	cpl	c
      006FA4 92 20            [24] 4228 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006FA6 12 38 B6         [24] 4229 	lcall	_ak820_outline_0159
                                   4230 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006FA9 22               [24] 4231 	ret
                                   4232 	.area CSEG    (CODE)
                                   4233 	.area CONST   (CODE)
                                   4234 	.area CONST   (CODE)
      00BDA0                       4235 _shared_offsets:
      00BDA0 00                    4236 	.db #0x00	; 0
      00BDA1 00                    4237 	.db #0x00	; 0
      00BDA2 28                    4238 	.db #0x28	; 40
      00BDA3 28                    4239 	.db #0x28	; 40
      00BDA4 2B                    4240 	.db #0x2b	; 43
      00BDA5 00                    4241 	.db #0x00	; 0
      00BDA6 08                    4242 	.db #0x08	; 8
                                   4243 	.area CSEG    (CODE)
                                   4244 	.area CONST   (CODE)
      00BDA7                       4245 _shared_lengths:
      00BDA7 00                    4246 	.db #0x00	; 0
      00BDA8 00                    4247 	.db #0x00	; 0
      00BDA9 00                    4248 	.db #0x00	; 0
      00BDAA 03                    4249 	.db #0x03	; 3
      00BDAB 03                    4250 	.db #0x03	; 3
      00BDAC 00                    4251 	.db #0x00	; 0
      00BDAD 20                    4252 	.db #0x20	; 32
                                   4253 	.area CSEG    (CODE)
                                   4254 	.area CONST   (CODE)
      00BDAE                       4255 _interface_descriptors:
      00BDAE 49 C3                 4256 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BDB0 49 C4                 4257 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BDB2 FC C3                 4258 	.byte _RawReport, (_RawReport >> 8)
      00BDB4 62 C4                 4259 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BDB6 8E C3                 4260 	.byte _SharedReport, (_SharedReport >> 8)
      00BDB8 7B C4                 4261 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4262 	.area CSEG    (CODE)
                                   4263 	.area XINIT   (CODE)
                                   4264 	.area CABS    (ABS,CODE)
                                   4265 
                                   4266 ; Experimental exact instruction outlining.
                                   4267 	.globl _ak820_outline_0016
                                   4268 	.globl _ak820_outline_0036
                                   4269 	.globl _ak820_outline_0045
                                   4270 	.globl _ak820_outline_0080
                                   4271 	.globl _ak820_outline_0107
                                   4272 	.globl _ak820_outline_0141
                                   4273 	.globl _ak820_outline_0159
                                   4274 	.globl _ak820_outline_0164
                                   4275 	.globl _ak820_outline_0166
                                   4276 	.globl _ak820_outline_0168
                                   4277 
                                   4278 	.area CSEG (CODE)
                                   4279 ; function ak820_outline_0045
      006FAA                       4280 _ak820_outline_0045:
      006FAA 90 08 27         [24] 4281 	mov	dptr,#_ak820_usb_send_PARM_2
      006FAD 74 CA            [12] 4282 	mov	a,#_raw_buffer
      006FAF F0               [24] 4283 	movx	@dptr,a
      006FB0 74 07            [12] 4284 	mov	a,#(_raw_buffer>>8)
      006FB2 A3               [24] 4285 	inc	dptr
      006FB3 F0               [24] 4286 	movx	@dptr,a
      006FB4 90 08 29         [24] 4287 	mov	dptr,#_ak820_usb_send_PARM_3
      006FB7 74 20            [12] 4288 	mov	a,#0x20
      006FB9 F0               [24] 4289 	movx	@dptr,a
      006FBA 75 82 03         [24] 4290 	mov	dpl,#0x03
      006FBD 22               [24] 4291 	ret
                                   4292 
                                   4293 	.area CSEG (CODE)
                                   4294 ; function ak820_outline_0107
      006FBE                       4295 _ak820_outline_0107:
      006FBE 24 CA            [12] 4296 	add	a,#_raw_buffer
      006FC0 F5 82            [12] 4297 	mov	dpl,a
      006FC2 E4               [12] 4298 	clr	a
      006FC3 34 07            [12] 4299 	addc	a,#(_raw_buffer>>8)
      006FC5 F5 83            [12] 4300 	mov	dph,a
      006FC7 E4               [12] 4301 	clr	a
      006FC8 F0               [24] 4302 	movx	@dptr,a
      006FC9 22               [24] 4303 	ret
                                   4304 
                                   4305 	.area CSEG (CODE)
                                   4306 ; function ak820_outline_0141
      006FCA                       4307 _ak820_outline_0141:
      006FCA 89 82            [24] 4308 	mov	dpl,r1
      006FCC 8A 83            [24] 4309 	mov	dph,r2
      006FCE F0               [24] 4310 	movx	@dptr,a
      006FCF 22               [24] 4311 	ret
                                   4312 
                                   4313 	.area CSEG (CODE)
                                   4314 ; function ak820_outline_0166
      006FD0                       4315 _ak820_outline_0166:
      006FD0 90 07 CB         [24] 4316 	mov	dptr,#(_raw_buffer+0x0001)
      006FD3 E0               [24] 4317 	movx	a,@dptr
      006FD4 FF               [12] 4318 	mov	r7,a
      006FD5 22               [24] 4319 	ret
                                   4320 
                                   4321 	.area CSEG (CODE)
                                   4322 ; function ak820_outline_0168
      006FD6                       4323 _ak820_outline_0168:
      006FD6 90 07 C9         [24] 4324 	mov	dptr,#_raw_state
      006FD9 E0               [24] 4325 	movx	a,@dptr
      006FDA FF               [12] 4326 	mov	r7,a
      006FDB 22               [24] 4327 	ret
