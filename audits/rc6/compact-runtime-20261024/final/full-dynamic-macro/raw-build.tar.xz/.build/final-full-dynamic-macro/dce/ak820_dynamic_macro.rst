                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_dynamic_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_keyboard_report_pending
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_key
                                     14 	.globl _add_owned_key
                                     15 	.globl _del_owned_mods
                                     16 	.globl _add_owned_mods
                                     17 	.globl _get_weak_mods
                                     18 	.globl _get_mods
                                     19 	.globl _send_keyboard_report
                                     20 	.globl _timer_read
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_dynamic_macro_observe_PARM_2
                                    265 	.globl _ak820_dynamic_macro_process_PARM_2
                                    266 	.globl _ak820_dynamic_macro_source
                                    267 	.globl _ak820_dynamic_macro_cancel
                                    268 	.globl _ak820_dynamic_macro_process
                                    269 	.globl _ak820_dynamic_macro_observe
                                    270 	.globl _ak820_dynamic_macro_task
                                    271 ;--------------------------------------------------------
                                    272 ; special function registers
                                    273 ;--------------------------------------------------------
                                    274 	.area RSEG    (ABS,DATA)
      000000                        275 	.org 0x0000
                           0000D0   276 _PSW	=	0x00d0
                           0000E0   277 _ACC	=	0x00e0
                           0000F0   278 _B	=	0x00f0
                           0000FD   279 _A_INV	=	0x00fd
                           000081   280 _SP	=	0x0081
                           000082   281 _DPL	=	0x0082
                           000083   282 _DPH	=	0x0083
                           0000A1   283 _SAFE_MOD	=	0x00a1
                           0000B1   284 _GLOBAL_CFG	=	0x00b1
                           000087   285 _PCON	=	0x0087
                           0000BA   286 _POWER_CFG	=	0x00ba
                           0000B9   287 _CLOCK_CFG	=	0x00b9
                           0000A9   288 _WAKE_CTRL	=	0x00a9
                           0000FE   289 _RESET_KEEP	=	0x00fe
                           0000FF   290 _WDOG_COUNT	=	0x00ff
                           0000A8   291 _IE	=	0x00a8
                           0000B8   292 _IP	=	0x00b8
                           0000E8   293 _IE_EX	=	0x00e8
                           0000E9   294 _IP_EX	=	0x00e9
                           0000B2   295 _GPIO_IE	=	0x00b2
                           008584   296 _ROM_ADDR	=	0x8584
                           000084   297 _ROM_ADDR_L	=	0x0084
                           000085   298 _ROM_ADDR_H	=	0x0085
                           008F8E   299 _ROM_DATA_HI	=	0x8f8e
                           00008E   300 _ROM_DATA_HL	=	0x008e
                           00008F   301 _ROM_DATA_HH	=	0x008f
                           000086   302 _ROM_CTRL	=	0x0086
                           000080   303 _P0	=	0x0080
                           0000C4   304 _P0_MOD_OC	=	0x00c4
                           0000C5   305 _P0_DIR_PU	=	0x00c5
                           000090   306 _P1	=	0x0090
                           000092   307 _P1_MOD_OC	=	0x0092
                           000093   308 _P1_DIR_PU	=	0x0093
                           0000A0   309 _P2	=	0x00a0
                           000094   310 _P2_MOD_OC	=	0x0094
                           000095   311 _P2_DIR_PU	=	0x0095
                           0000B0   312 _P3	=	0x00b0
                           000096   313 _P3_MOD_OC	=	0x0096
                           000097   314 _P3_DIR_PU	=	0x0097
                           0000C0   315 _P4	=	0x00c0
                           0000C2   316 _P4_MOD_OC	=	0x00c2
                           0000C3   317 _P4_DIR_PU	=	0x00c3
                           0000C1   318 _P4_LED_KEY	=	0x00c1
                           0000AA   319 _P5_IN	=	0x00aa
                           0000AB   320 _P5_OUT_PU	=	0x00ab
                           0000AC   321 _P5_DIR	=	0x00ac
                           0000AD   322 _P6_IN	=	0x00ad
                           0000AE   323 _P6_OUT_PU	=	0x00ae
                           0000AF   324 _P6_DIR	=	0x00af
                           0000F1   325 _P7	=	0x00f1
                           0000A2   326 _XBUS_AUX	=	0x00a2
                           000088   327 _TCON	=	0x0088
                           000089   328 _TMOD	=	0x0089
                           00008A   329 _TL0	=	0x008a
                           00008B   330 _TL1	=	0x008b
                           00008C   331 _TH0	=	0x008c
                           00008D   332 _TH1	=	0x008d
                           000098   333 _SCON	=	0x0098
                           000099   334 _SBUF	=	0x0099
                           0000C8   335 _T2CON	=	0x00c8
                           0000C9   336 _T2MOD	=	0x00c9
                           00CBCA   337 _RCAP2	=	0xcbca
                           0000CA   338 _RCAP2L	=	0x00ca
                           0000CB   339 _RCAP2H	=	0x00cb
                           00CDCC   340 _T2COUNT	=	0xcdcc
                           0000CC   341 _TL2	=	0x00cc
                           0000CD   342 _TH2	=	0x00cd
                           00CFCE   343 _T2CAP1	=	0xcfce
                           0000CE   344 _T2CAP1L	=	0x00ce
                           0000CF   345 _T2CAP1H	=	0x00cf
                           0000F8   346 _SPI0_STAT	=	0x00f8
                           0000F9   347 _SPI0_DATA	=	0x00f9
                           0000FA   348 _SPI0_CTRL	=	0x00fa
                           0000FB   349 _SPI0_CK_SE	=	0x00fb
                           0000FC   350 _SPI0_SETUP	=	0x00fc
                           0000BC   351 _SCON1	=	0x00bc
                           0000BD   352 _SBUF1	=	0x00bd
                           0000BE   353 _SBAUD1	=	0x00be
                           0000BF   354 _SIF1	=	0x00bf
                           0000B4   355 _SPI1_STAT	=	0x00b4
                           0000B5   356 _SPI1_DATA	=	0x00b5
                           0000B6   357 _SPI1_CTRL	=	0x00b6
                           0000B7   358 _SPI1_CK_SE	=	0x00b7
                           0000F3   359 _ADC_CTRL	=	0x00f3
                           00F5F4   360 _ADC_DAT	=	0xf5f4
                           0000F4   361 _ADC_DAT_L	=	0x00f4
                           0000F5   362 _ADC_DAT_H	=	0x00f5
                           0000F6   363 _ADC_CHAN	=	0x00f6
                           0000A6   364 _LED_COMMON	=	0x00a6
                           0000A7   365 _LED_PWM_OE	=	0x00a7
                           00C7C6   366 _LED_DMA	=	0xc7c6
                           0000C6   367 _LED_DMA_L	=	0x00c6
                           0000C7   368 _LED_DMA_H	=	0x00c7
                           0000F7   369 _LED_STATUS	=	0x00f7
                           0000B3   370 _I2CX_INT	=	0x00b3
                           0000BB   371 _I2CS_INT_ST	=	0x00bb
                                    372 ;--------------------------------------------------------
                                    373 ; special function bits
                                    374 ;--------------------------------------------------------
                                    375 	.area RSEG    (ABS,DATA)
      000000                        376 	.org 0x0000
                           0000D7   377 _CY	=	0x00d7
                           0000D6   378 _AC	=	0x00d6
                           0000D5   379 _F0	=	0x00d5
                           0000D4   380 _RS1	=	0x00d4
                           0000D3   381 _RS0	=	0x00d3
                           0000D2   382 _OV	=	0x00d2
                           0000D1   383 _F1	=	0x00d1
                           0000D0   384 _P	=	0x00d0
                           0000AF   385 _EA	=	0x00af
                           0000AE   386 _E_DIS	=	0x00ae
                           0000AD   387 _ET2	=	0x00ad
                           0000AC   388 _ES	=	0x00ac
                           0000AB   389 _ET1	=	0x00ab
                           0000AA   390 _EX1	=	0x00aa
                           0000A9   391 _ET0	=	0x00a9
                           0000A8   392 _EX0	=	0x00a8
                           0000BF   393 _PH_FLAG	=	0x00bf
                           0000BE   394 _PL_FLAG	=	0x00be
                           0000BD   395 _PT2	=	0x00bd
                           0000BC   396 _PS	=	0x00bc
                           0000BB   397 _PT1	=	0x00bb
                           0000BA   398 _PX1	=	0x00ba
                           0000B9   399 _PT0	=	0x00b9
                           0000B8   400 _PX0	=	0x00b8
                           0000EF   401 _IE_WDOG	=	0x00ef
                           0000EE   402 _IE_GPIO	=	0x00ee
                           0000ED   403 _IE_PWM_I2C	=	0x00ed
                           0000EC   404 _IE_UART1	=	0x00ec
                           0000EB   405 _IE_ADC	=	0x00eb
                           0000E9   406 _IE_USB	=	0x00e9
                           0000E8   407 _IE_SPI0	=	0x00e8
                           000087   408 _P0_7	=	0x0087
                           000086   409 _P0_6	=	0x0086
                           000085   410 _P0_5	=	0x0085
                           000084   411 _P0_4	=	0x0084
                           000083   412 _P0_3	=	0x0083
                           000082   413 _P0_2	=	0x0082
                           000081   414 _P0_1	=	0x0081
                           000080   415 _P0_0	=	0x0080
                           000081   416 _SDA0	=	0x0081
                           000080   417 _SCL0	=	0x0080
                           000083   418 _TXD_	=	0x0083
                           000082   419 _RXD_	=	0x0082
                           000085   420 _AIN13	=	0x0085
                           000084   421 _AIN12	=	0x0084
                           000083   422 _AIN11	=	0x0083
                           000082   423 _AIN10	=	0x0082
                           000081   424 _AIN9	=	0x0081
                           000080   425 _AIN8	=	0x0080
                           000097   426 _P1_7	=	0x0097
                           000096   427 _P1_6	=	0x0096
                           000095   428 _P1_5	=	0x0095
                           000094   429 _P1_4	=	0x0094
                           000093   430 _P1_3	=	0x0093
                           000092   431 _P1_2	=	0x0092
                           000091   432 _P1_1	=	0x0091
                           000090   433 _P1_0	=	0x0090
                           000097   434 _TXD1_	=	0x0097
                           000096   435 _RXD1_	=	0x0096
                           000097   436 _SCK	=	0x0097
                           000096   437 _MISO	=	0x0096
                           000095   438 _MOSI	=	0x0095
                           000094   439 _SCS	=	0x0094
                           000092   440 _INT0_	=	0x0092
                           000091   441 _T2EX	=	0x0091
                           000091   442 _CAP2	=	0x0091
                           000090   443 _T2	=	0x0090
                           000090   444 _CAP1	=	0x0090
                           000097   445 _AIN7	=	0x0097
                           000096   446 _AIN6	=	0x0096
                           000095   447 _AIN5	=	0x0095
                           000094   448 _AIN4	=	0x0094
                           000093   449 _AIN3	=	0x0093
                           000092   450 _AIN2	=	0x0092
                           000091   451 _AIN1	=	0x0091
                           000090   452 _AIN0	=	0x0090
                           0000A7   453 _P2_7	=	0x00a7
                           0000A6   454 _P2_6	=	0x00a6
                           0000A5   455 _P2_5	=	0x00a5
                           0000A4   456 _P2_4	=	0x00a4
                           0000A3   457 _P2_3	=	0x00a3
                           0000A2   458 _P2_2	=	0x00a2
                           0000A1   459 _P2_1	=	0x00a1
                           0000A0   460 _P2_0	=	0x00a0
                           0000A7   461 _TXD1	=	0x00a7
                           0000A6   462 _RXD1	=	0x00a6
                           0000A5   463 _T2EX_	=	0x00a5
                           0000A5   464 _CAP2_	=	0x00a5
                           0000A4   465 _T2_	=	0x00a4
                           0000A4   466 _CAP1_	=	0x00a4
                           0000B7   467 _P3_7	=	0x00b7
                           0000B6   468 _P3_6	=	0x00b6
                           0000B5   469 _P3_5	=	0x00b5
                           0000B4   470 _P3_4	=	0x00b4
                           0000B3   471 _P3_3	=	0x00b3
                           0000B2   472 _P3_2	=	0x00b2
                           0000B1   473 _P3_1	=	0x00b1
                           0000B0   474 _P3_0	=	0x00b0
                           0000B7   475 _SCK1	=	0x00b7
                           0000B6   476 _MISO1	=	0x00b6
                           0000B5   477 _MOSI1	=	0x00b5
                           0000B5   478 _T1	=	0x00b5
                           0000B4   479 _T0	=	0x00b4
                           0000B3   480 _INT1	=	0x00b3
                           0000B2   481 _INT0	=	0x00b2
                           0000B1   482 _TXD	=	0x00b1
                           0000B0   483 _RXD	=	0x00b0
                           0000C6   484 _P4_6	=	0x00c6
                           0000C5   485 _P4_5	=	0x00c5
                           0000C4   486 _P4_4	=	0x00c4
                           0000C3   487 _P4_3	=	0x00c3
                           0000C2   488 _P4_2	=	0x00c2
                           0000C1   489 _P4_1	=	0x00c1
                           0000C0   490 _P4_0	=	0x00c0
                           00008F   491 _TF1	=	0x008f
                           00008E   492 _TR1	=	0x008e
                           00008D   493 _TF0	=	0x008d
                           00008C   494 _TR0	=	0x008c
                           00008B   495 _IE1	=	0x008b
                           00008A   496 _IT1	=	0x008a
                           000089   497 _IE0	=	0x0089
                           000088   498 _IT0	=	0x0088
                           00009F   499 _SM0	=	0x009f
                           00009E   500 _SM1	=	0x009e
                           00009D   501 _SM2	=	0x009d
                           00009C   502 _REN	=	0x009c
                           00009B   503 _TB8	=	0x009b
                           00009A   504 _RB8	=	0x009a
                           000099   505 _TI	=	0x0099
                           000098   506 _RI	=	0x0098
                           0000CF   507 _TF2	=	0x00cf
                           0000CF   508 _CAP1F	=	0x00cf
                           0000CE   509 _EXF2	=	0x00ce
                           0000CD   510 _RCLK	=	0x00cd
                           0000CC   511 _TCLK	=	0x00cc
                           0000CB   512 _EXEN2	=	0x00cb
                           0000CA   513 _TR2	=	0x00ca
                           0000C9   514 _C_T2	=	0x00c9
                           0000C8   515 _CP_RL2	=	0x00c8
                           0000FF   516 _S0_FST_ACT	=	0x00ff
                           0000FE   517 _S0_IF_OV	=	0x00fe
                           0000FD   518 _S0_IF_FIRST	=	0x00fd
                           0000FC   519 _S0_IF_BYTE	=	0x00fc
                           0000FB   520 _S0_FREE	=	0x00fb
                           0000FA   521 _S0_T_FIFO	=	0x00fa
                           0000F8   522 _S0_R_FIFO	=	0x00f8
                           0000F7   523 _ADC_START	=	0x00f7
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable register banks
                                    526 ;--------------------------------------------------------
                                    527 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        528 	.ds 8
                                    529 ;--------------------------------------------------------
                                    530 ; internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area DSEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; overlayable items in internal ram
                                    535 ;--------------------------------------------------------
                                    536 ;--------------------------------------------------------
                                    537 ; indirectly addressable internal ram data
                                    538 ;--------------------------------------------------------
                                    539 	.area ISEG    (DATA)
                                    540 ;--------------------------------------------------------
                                    541 ; absolute internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area IABS    (ABS,DATA)
                                    544 	.area IABS    (ABS,DATA)
                                    545 ;--------------------------------------------------------
                                    546 ; bit data
                                    547 ;--------------------------------------------------------
                                    548 	.area BSEG    (BIT)
                                    549 ;--------------------------------------------------------
                                    550 ; paged external ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area PSEG    (PAG,XDATA)
                                    553 ;--------------------------------------------------------
                                    554 ; uninitialized external ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area XSEG    (XDATA)
      000464                        557 _dm_taps:
      000464                        558 	.ds 64
      0004A4                        559 _dm_lengths:
      0004A4                        560 	.ds 2
      0004A6                        561 _dm_record:
      0004A6                        562 	.ds 1
      0004A7                        563 _dm_play:
      0004A7                        564 	.ds 1
      0004A8                        565 _dm_index:
      0004A8                        566 	.ds 1
      0004A9                        567 _dm_down:
      0004A9                        568 	.ds 1
      0004AA                        569 _dm_mods:
      0004AA                        570 	.ds 1
      0004AB                        571 _dm_time:
      0004AB                        572 	.ds 2
      0004AD                        573 _ak820_dynamic_macro_source::
      0004AD                        574 	.ds 1
      0004AE                        575 _ak820_dynamic_macro_process_PARM_2:
      0004AE                        576 	.ds 1
      0004AF                        577 _ak820_dynamic_macro_process_code_10000_602:
      0004AF                        578 	.ds 2
      0004B1                        579 _ak820_dynamic_macro_observe_PARM_2:
      0004B1                        580 	.ds 1
      0004B2                        581 _ak820_dynamic_macro_observe_code_10000_611:
      0004B2                        582 	.ds 1
      0004B3                        583 _ak820_dynamic_macro_observe_slot_10001_614:
      0004B3                        584 	.ds 1
      0004B4                        585 _ak820_dynamic_macro_observe_base_10001_614:
      0004B4                        586 	.ds 1
      0004B5                        587 _ak820_dynamic_macro_observe_i_30001_616:
      0004B5                        588 	.ds 1
      0004B6                        589 _ak820_dynamic_macro_task_now_10000_623:
      0004B6                        590 	.ds 2
      0004B8                        591 _ak820_dynamic_macro_task_i_40000_630:
      0004B8                        592 	.ds 1
      0004B9                        593 _ak820_dynamic_macro_task_code_40000_630:
      0004B9                        594 	.ds 1
                                    595 ;--------------------------------------------------------
                                    596 ; absolute external ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area XABS    (ABS,XDATA)
                                    599 ;--------------------------------------------------------
                                    600 ; initialized external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XISEG   (XDATA)
                                    603 	.area HOME    (CODE)
                                    604 	.area GSINIT0 (CODE)
                                    605 	.area GSINIT1 (CODE)
                                    606 	.area GSINIT2 (CODE)
                                    607 	.area GSINIT3 (CODE)
                                    608 	.area GSINIT4 (CODE)
                                    609 	.area GSINIT5 (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 	.area GSFINAL (CODE)
                                    612 	.area CSEG    (CODE)
                                    613 ;--------------------------------------------------------
                                    614 ; global & static initialisations
                                    615 ;--------------------------------------------------------
                                    616 	.area HOME    (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area GSINIT  (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; Home
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area HOME    (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; code
                                    627 ;--------------------------------------------------------
                                    628 	.area CSEG    (CODE)
                                    629 ;------------------------------------------------------------
                                    630 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    631 ;------------------------------------------------------------
                                    632 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    633 ;------------------------------------------------------------
                                    634 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    635 ;	-----------------------------------------
                           000007   636 	ar7 = 0x07
                           000006   637 	ar6 = 0x06
                           000005   638 	ar5 = 0x05
                           000004   639 	ar4 = 0x04
                           000003   640 	ar3 = 0x03
                           000002   641 	ar2 = 0x02
                           000001   642 	ar1 = 0x01
                           000000   643 	ar0 = 0x00
                                    644 ;	 function dm_finish
                                    645 ;	-----------------------------------------
      0038CB                        646 _dm_finish:
                                    647 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:17: if (dm_record) {
      0038CB 90 04 A6         [24]  648 	mov	dptr,#_dm_record
      0038CE E0               [24]  649 	movx	a,@dptr
      0038CF FF               [12]  650 	mov	r7,a
      0038D0 E0               [24]  651 	movx	a,@dptr
      0038D1 70 01            [24]  652 	jnz	00140$
      0038D3 22               [24]  653 	ret
      0038D4                        654 00140$:
                                    655 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:18: uint8_t slot = dm_record - 1, base = slot * 16, out = 0;
      0038D4 1F               [12]  656 	dec	r7
      0038D5 EF               [12]  657 	mov	a,r7
      0038D6 C4               [12]  658 	swap	a
      0038D7 54 F0            [12]  659 	anl	a,#0xf0
      0038D9 FE               [12]  660 	mov	r6,a
                                    661 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      0038DA EF               [12]  662 	mov	a,r7
      0038DB 24 A4            [12]  663 	add	a, #_dm_lengths
      0038DD FD               [12]  664 	mov	r5,a
      0038DE E4               [12]  665 	clr	a
      0038DF 34 04            [12]  666 	addc	a, #(_dm_lengths >> 8)
      0038E1 FF               [12]  667 	mov	r7,a
      0038E2 7C 00            [12]  668 	mov	r4,#0x00
      0038E4 7B 00            [12]  669 	mov	r3,#0x00
      0038E6                        670 00107$:
      0038E6 8D 82            [24]  671 	mov	dpl,r5
      0038E8 8F 83            [24]  672 	mov	dph,r7
      0038EA E0               [24]  673 	movx	a,@dptr
      0038EB FA               [12]  674 	mov	r2,a
      0038EC C3               [12]  675 	clr	c
      0038ED EB               [12]  676 	mov	a,r3
      0038EE 9A               [12]  677 	subb	a,r2
      0038EF 50 6F            [24]  678 	jnc	00103$
                                    679 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:20: if (!(dm_taps[base + i].code & 0x80)) {
      0038F1 EB               [12]  680 	mov	a,r3
      0038F2 2E               [12]  681 	add	a, r6
      0038F3 75 F0 02         [24]  682 	mov	b,#0x02
      0038F6 A4               [48]  683 	mul	ab
      0038F7 24 64            [12]  684 	add	a, #_dm_taps
      0038F9 F5 82            [12]  685 	mov	dpl,a
      0038FB 74 04            [12]  686 	mov	a,#(_dm_taps >> 8)
      0038FD 35 F0            [12]  687 	addc	a, b
      0038FF F5 83            [12]  688 	mov	dph,a
      003901 E0               [24]  689 	movx	a,@dptr
      003902 20 E7 58         [24]  690 	jb	acc.7,00108$
                                    691 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:21: dm_taps[base + out] = dm_taps[base + i];
      003905 C0 05            [24]  692 	push	ar5
      003907 C0 07            [24]  693 	push	ar7
      003909 EC               [12]  694 	mov	a,r4
      00390A 2E               [12]  695 	add	a, r6
      00390B 75 F0 02         [24]  696 	mov	b,#0x02
      00390E A4               [48]  697 	mul	ab
      00390F 24 64            [12]  698 	add	a, #_dm_taps
      003911 F9               [12]  699 	mov	r1,a
      003912 74 04            [12]  700 	mov	a,#(_dm_taps >> 8)
      003914 35 F0            [12]  701 	addc	a, b
      003916 F8               [12]  702 	mov	r0,a
      003917 7A 00            [12]  703 	mov	r2,#0x00
      003919 EB               [12]  704 	mov	a,r3
      00391A 2E               [12]  705 	add	a, r6
      00391B 75 F0 02         [24]  706 	mov	b,#0x02
      00391E A4               [48]  707 	mul	ab
      00391F 24 64            [12]  708 	add	a, #_dm_taps
      003921 FD               [12]  709 	mov	r5,a
      003922 74 04            [12]  710 	mov	a,#(_dm_taps >> 8)
      003924 35 F0            [12]  711 	addc	a, b
      003926 FF               [12]  712 	mov	r7,a
      003927 90 0D FA         [24]  713 	mov	dptr,#___memcpy_PARM_2
      00392A ED               [12]  714 	mov	a,r5
      00392B F0               [24]  715 	movx	@dptr,a
      00392C EF               [12]  716 	mov	a,r7
      00392D A3               [24]  717 	inc	dptr
      00392E F0               [24]  718 	movx	@dptr,a
      00392F E4               [12]  719 	clr	a
      003930 A3               [24]  720 	inc	dptr
      003931 F0               [24]  721 	movx	@dptr,a
      003932 90 0D FD         [24]  722 	mov	dptr,#___memcpy_PARM_3
      003935 74 02            [12]  723 	mov	a,#0x02
      003937 F0               [24]  724 	movx	@dptr,a
      003938 E4               [12]  725 	clr	a
      003939 A3               [24]  726 	inc	dptr
      00393A F0               [24]  727 	movx	@dptr,a
      00393B 89 82            [24]  728 	mov	dpl, r1
      00393D 88 83            [24]  729 	mov	dph, r0
      00393F 8A F0            [24]  730 	mov	b, r2
      003941 C0 07            [24]  731 	push	ar7
      003943 C0 06            [24]  732 	push	ar6
      003945 C0 05            [24]  733 	push	ar5
      003947 C0 04            [24]  734 	push	ar4
      003949 C0 03            [24]  735 	push	ar3
      00394B 12 BC 35         [24]  736 	lcall	___memcpy
      00394E D0 03            [24]  737 	pop	ar3
      003950 D0 04            [24]  738 	pop	ar4
      003952 D0 05            [24]  739 	pop	ar5
      003954 D0 06            [24]  740 	pop	ar6
      003956 D0 07            [24]  741 	pop	ar7
                                    742 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      003958 0C               [12]  743 	inc	r4
                                    744 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003959 D0 07            [24]  745 	pop	ar7
      00395B D0 05            [24]  746 	pop	ar5
                                    747 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:22: ++out;
      00395D                        748 00108$:
                                    749 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:19: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      00395D 0B               [12]  750 	inc	r3
      00395E 80 86            [24]  751 	sjmp	00107$
      003960                        752 00103$:
                                    753 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:25: dm_lengths[slot] = out;
      003960 8D 82            [24]  754 	mov	dpl,r5
      003962 8F 83            [24]  755 	mov	dph,r7
      003964 EC               [12]  756 	mov	a,r4
      003965 F0               [24]  757 	movx	@dptr,a
                                    758 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:26: dm_record = 0;
      003966 90 04 A6         [24]  759 	mov	dptr,#_dm_record
      003969 E4               [12]  760 	clr	a
      00396A F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:28: }
      00396B 22               [24]  763 	ret
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'ak820_dynamic_macro_cancel'
                                    766 ;------------------------------------------------------------
                                    767 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:29: void ak820_dynamic_macro_cancel(void) {
                                    768 ;	-----------------------------------------
                                    769 ;	 function ak820_dynamic_macro_cancel
                                    770 ;	-----------------------------------------
      00396C                        771 _ak820_dynamic_macro_cancel:
                                    772 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:30: dm_finish();
      00396C 12 38 CB         [24]  773 	lcall	_dm_finish
                                    774 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:33: dm_play = dm_down = 0;
      00396F 90 04 A9         [24]  775 	mov	dptr,#_dm_down
      003972 E4               [12]  776 	clr	a
      003973 F0               [24]  777 	movx	@dptr,a
      003974 90 04 A7         [24]  778 	mov	dptr,#_dm_play
      003977 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:34: ak820_dynamic_macro_source = false;
      003978 90 04 AD         [24]  781 	mov	dptr,#_ak820_dynamic_macro_source
      00397B F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:35: }
      00397C 22               [24]  784 	ret
                                    785 ;------------------------------------------------------------
                                    786 ;Allocation info for local variables in function 'ak820_dynamic_macro_process'
                                    787 ;------------------------------------------------------------
                                    788 ;pressed       Allocated with name '_ak820_dynamic_macro_process_PARM_2'
                                    789 ;code          Allocated with name '_ak820_dynamic_macro_process_code_10000_602'
                                    790 ;------------------------------------------------------------
                                    791 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:36: bool ak820_dynamic_macro_process(uint16_t code, bool pressed) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function ak820_dynamic_macro_process
                                    794 ;	-----------------------------------------
      00397D                        795 _ak820_dynamic_macro_process:
      00397D AF 83            [24]  796 	mov	r7,dph
      00397F E5 82            [12]  797 	mov	a,dpl
      003981 90 04 AF         [24]  798 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      003984 F0               [24]  799 	movx	@dptr,a
      003985 EF               [12]  800 	mov	a,r7
      003986 A3               [24]  801 	inc	dptr
      003987 F0               [24]  802 	movx	@dptr,a
                                    803 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:37: if (code < QK_DYNAMIC_MACRO_RECORD_START_1 || code > QK_DYNAMIC_MACRO_PLAY_2) return true;
      003988 90 04 AF         [24]  804 	mov	dptr,#_ak820_dynamic_macro_process_code_10000_602
      00398B E0               [24]  805 	movx	a,@dptr
      00398C FE               [12]  806 	mov	r6,a
      00398D A3               [24]  807 	inc	dptr
      00398E E0               [24]  808 	movx	a,@dptr
      00398F FF               [12]  809 	mov	r7,a
      003990 8E 04            [24]  810 	mov	ar4,r6
      003992 8F 05            [24]  811 	mov	ar5,r7
      003994 C3               [12]  812 	clr	c
      003995 EC               [12]  813 	mov	a,r4
      003996 94 53            [12]  814 	subb	a,#0x53
      003998 ED               [12]  815 	mov	a,r5
      003999 94 7C            [12]  816 	subb	a,#0x7c
      00399B 40 08            [24]  817 	jc	00101$
      00399D 74 57            [12]  818 	mov	a,#0x57
      00399F 9C               [12]  819 	subb	a,r4
      0039A0 74 7C            [12]  820 	mov	a,#0x7c
      0039A2 9D               [12]  821 	subb	a,r5
      0039A3 50 04            [24]  822 	jnc	00102$
                                    823 ;	free result
      0039A5                        824 00101$:
      0039A5 75 82 01         [24]  825 	mov	dpl, #0x01
      0039A8 22               [24]  826 	ret
      0039A9                        827 00102$:
                                    828 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:38: if (!pressed || get_repeat_key_count()) return false;
      0039A9 90 04 AE         [24]  829 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0039AC E0               [24]  830 	movx	a,@dptr
      0039AD 60 17            [24]  831 	jz	00104$
      0039AF C0 07            [24]  832 	push	ar7
      0039B1 C0 06            [24]  833 	push	ar6
      0039B3 C0 05            [24]  834 	push	ar5
      0039B5 C0 04            [24]  835 	push	ar4
      0039B7 12 A6 18         [24]  836 	lcall	_get_repeat_key_count
      0039BA E5 82            [12]  837 	mov	a, dpl
      0039BC D0 04            [24]  838 	pop	ar4
      0039BE D0 05            [24]  839 	pop	ar5
      0039C0 D0 06            [24]  840 	pop	ar6
      0039C2 D0 07            [24]  841 	pop	ar7
      0039C4 60 04            [24]  842 	jz	00105$
      0039C6                        843 00104$:
      0039C6 75 82 00         [24]  844 	mov	dpl, #0x00
      0039C9 22               [24]  845 	ret
      0039CA                        846 00105$:
                                    847 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:41: if (dm_play) return false;
      0039CA 90 04 A7         [24]  848 	mov	dptr,#_dm_play
      0039CD E0               [24]  849 	movx	a,@dptr
      0039CE 60 04            [24]  850 	jz	00108$
      0039D0 75 82 00         [24]  851 	mov	dpl, #0x00
      0039D3 22               [24]  852 	ret
      0039D4                        853 00108$:
                                    854 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:42: dm_finish();
      0039D4 C0 07            [24]  855 	push	ar7
      0039D6 C0 06            [24]  856 	push	ar6
      0039D8 C0 05            [24]  857 	push	ar5
      0039DA C0 04            [24]  858 	push	ar4
      0039DC 12 38 CB         [24]  859 	lcall	_dm_finish
      0039DF D0 04            [24]  860 	pop	ar4
      0039E1 D0 05            [24]  861 	pop	ar5
      0039E3 D0 06            [24]  862 	pop	ar6
      0039E5 D0 07            [24]  863 	pop	ar7
                                    864 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:43: if (code <= QK_DYNAMIC_MACRO_RECORD_START_2) {
      0039E7 C3               [12]  865 	clr	c
      0039E8 74 54            [12]  866 	mov	a,#0x54
      0039EA 9C               [12]  867 	subb	a,r4
      0039EB 74 7C            [12]  868 	mov	a,#0x7c
      0039ED 9D               [12]  869 	subb	a,r5
      0039EE 40 1E            [24]  870 	jc	00112$
                                    871 ;	free result
                                    872 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:44: dm_record = code - QK_DYNAMIC_MACRO_RECORD_START_1 + 1;
      0039F0 8E 03            [24]  873 	mov	ar3,r6
      0039F2 74 AE            [12]  874 	mov	a,#0xae
      0039F4 2B               [12]  875 	add	a, r3
      0039F5 FB               [12]  876 	mov	r3,a
      0039F6 90 04 A6         [24]  877 	mov	dptr,#_dm_record
      0039F9 F0               [24]  878 	movx	@dptr,a
                                    879 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:45: dm_lengths[dm_record - 1] = 0;
      0039FA 1B               [12]  880 	dec	r3
      0039FB EB               [12]  881 	mov	a,r3
      0039FC 33               [12]  882 	rlc	a
      0039FD 95 E0            [12]  883 	subb	a,acc
      0039FF FA               [12]  884 	mov	r2,a
      003A00 EB               [12]  885 	mov	a,r3
      003A01 24 A4            [12]  886 	add	a, #_dm_lengths
      003A03 F5 82            [12]  887 	mov	dpl,a
      003A05 EA               [12]  888 	mov	a,r2
      003A06 34 04            [12]  889 	addc	a, #(_dm_lengths >> 8)
      003A08 F5 83            [12]  890 	mov	dph,a
      003A0A E4               [12]  891 	clr	a
      003A0B F0               [24]  892 	movx	@dptr,a
      003A0C 80 29            [24]  893 	sjmp	00113$
      003A0E                        894 00112$:
                                    895 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:46: } else if (code >= QK_DYNAMIC_MACRO_PLAY_1) {
      003A0E C3               [12]  896 	clr	c
      003A0F EC               [12]  897 	mov	a,r4
      003A10 94 56            [12]  898 	subb	a,#0x56
      003A12 ED               [12]  899 	mov	a,r5
      003A13 94 7C            [12]  900 	subb	a,#0x7c
      003A15 40 20            [24]  901 	jc	00113$
                                    902 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:47: dm_play = code - QK_DYNAMIC_MACRO_PLAY_1 + 1;
      003A17 90 04 A7         [24]  903 	mov	dptr,#_dm_play
      003A1A 74 AB            [12]  904 	mov	a,#0xab
      003A1C 2E               [12]  905 	add	a, r6
      003A1D F0               [24]  906 	movx	@dptr,a
                                    907 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:48: dm_index = dm_down = 0;
      003A1E 90 04 A9         [24]  908 	mov	dptr,#_dm_down
      003A21 E4               [12]  909 	clr	a
      003A22 F0               [24]  910 	movx	@dptr,a
      003A23 90 04 A8         [24]  911 	mov	dptr,#_dm_index
      003A26 F0               [24]  912 	movx	@dptr,a
                                    913 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:49: dm_time = timer_read();
      003A27 12 4C 7E         [24]  914 	lcall	_timer_read
      003A2A E5 82            [12]  915 	mov	a, dpl
      003A2C 85 83 F0         [24]  916 	mov	b, dph
      003A2F 90 04 AB         [24]  917 	mov	dptr,#_dm_time
      003A32 F0               [24]  918 	movx	@dptr,a
      003A33 E5 F0            [12]  919 	mov	a,b
      003A35 A3               [24]  920 	inc	dptr
      003A36 F0               [24]  921 	movx	@dptr,a
      003A37                        922 00113$:
                                    923 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:51: return false;
      003A37 75 82 00         [24]  924 	mov	dpl, #0x00
                                    925 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:52: }
      003A3A 22               [24]  926 	ret
                                    927 ;------------------------------------------------------------
                                    928 ;Allocation info for local variables in function 'ak820_dynamic_macro_observe'
                                    929 ;------------------------------------------------------------
                                    930 ;pressed       Allocated with name '_ak820_dynamic_macro_observe_PARM_2'
                                    931 ;code          Allocated with name '_ak820_dynamic_macro_observe_code_10000_611'
                                    932 ;slot          Allocated with name '_ak820_dynamic_macro_observe_slot_10001_614'
                                    933 ;base          Allocated with name '_ak820_dynamic_macro_observe_base_10001_614'
                                    934 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_30001_616'
                                    935 ;i             Allocated with name '_ak820_dynamic_macro_observe_i_40001_619'
                                    936 ;------------------------------------------------------------
                                    937 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:53: void ak820_dynamic_macro_observe(uint8_t code, bool pressed) {
                                    938 ;	-----------------------------------------
                                    939 ;	 function ak820_dynamic_macro_observe
                                    940 ;	-----------------------------------------
      003A3B                        941 _ak820_dynamic_macro_observe:
      003A3B E5 82            [12]  942 	mov	a,dpl
      003A3D 90 04 B2         [24]  943 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003A40 F0               [24]  944 	movx	@dptr,a
                                    945 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:54: if (!dm_record || !ak820_dynamic_macro_source || code < KC_A || code >= 0x80) return;
      003A41 90 04 A6         [24]  946 	mov	dptr,#_dm_record
      003A44 E0               [24]  947 	movx	a,@dptr
      003A45 FF               [12]  948 	mov	r7,a
      003A46 E0               [24]  949 	movx	a,@dptr
      003A47 60 15            [24]  950 	jz	00101$
      003A49 90 04 AD         [24]  951 	mov	dptr,#_ak820_dynamic_macro_source
      003A4C E0               [24]  952 	movx	a,@dptr
      003A4D 60 0F            [24]  953 	jz	00101$
      003A4F 90 04 B2         [24]  954 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003A52 E0               [24]  955 	movx	a,@dptr
      003A53 FE               [12]  956 	mov	r6,a
      003A54 BE 04 00         [24]  957 	cjne	r6,#0x04,00177$
      003A57                        958 00177$:
      003A57 40 05            [24]  959 	jc	00101$
      003A59 BE 80 00         [24]  960 	cjne	r6,#0x80,00179$
      003A5C                        961 00179$:
      003A5C 40 01            [24]  962 	jc	00102$
      003A5E                        963 00101$:
      003A5E 22               [24]  964 	ret
      003A5F                        965 00102$:
                                    966 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:55: uint8_t slot = dm_record - 1, base = slot * 16;
      003A5F 1F               [12]  967 	dec	r7
      003A60 90 04 B3         [24]  968 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003A63 EF               [12]  969 	mov	a,r7
      003A64 F0               [24]  970 	movx	@dptr,a
      003A65 EF               [12]  971 	mov	a,r7
      003A66 C4               [12]  972 	swap	a
      003A67 54 F0            [12]  973 	anl	a,#0xf0
      003A69 FD               [12]  974 	mov	r5,a
      003A6A 90 04 B4         [24]  975 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003A6D F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:56: if (pressed) {
      003A6E 90 04 B1         [24]  978 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      003A71 E0               [24]  979 	movx	a,@dptr
      003A72 60 67            [24]  980 	jz	00134$
                                    981 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:57: uint8_t i = dm_lengths[slot];
      003A74 EF               [12]  982 	mov	a,r7
      003A75 24 A4            [12]  983 	add	a, #_dm_lengths
      003A77 F5 82            [12]  984 	mov	dpl,a
      003A79 E4               [12]  985 	clr	a
      003A7A 34 04            [12]  986 	addc	a, #(_dm_lengths >> 8)
      003A7C F5 83            [12]  987 	mov	dph,a
      003A7E E0               [24]  988 	movx	a,@dptr
      003A7F FC               [12]  989 	mov	r4,a
      003A80 90 04 B5         [24]  990 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003A83 F0               [24]  991 	movx	@dptr,a
                                    992 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:58: if (i == 16) return; /* Full: retain first 16; still accept releases. */
      003A84 BC 10 01         [24]  993 	cjne	r4,#0x10,00107$
      003A87 22               [24]  994 	ret
      003A88                        995 00107$:
                                    996 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:59: dm_taps[base + i].code = code | 0x80;
      003A88 EC               [12]  997 	mov	a,r4
      003A89 2D               [12]  998 	add	a, r5
      003A8A 75 F0 02         [24]  999 	mov	b,#0x02
      003A8D A4               [48] 1000 	mul	ab
      003A8E 24 64            [12] 1001 	add	a, #_dm_taps
      003A90 F5 82            [12] 1002 	mov	dpl,a
      003A92 74 04            [12] 1003 	mov	a,#(_dm_taps >> 8)
      003A94 35 F0            [12] 1004 	addc	a, b
      003A96 F5 83            [12] 1005 	mov	dph,a
      003A98 43 06 80         [24] 1006 	orl	ar6,#0x80
      003A9B EE               [12] 1007 	mov	a,r6
      003A9C F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:60: dm_taps[base + i].mods = get_mods() | get_weak_mods();
      003A9D 90 04 B5         [24] 1010 	mov	dptr,#_ak820_dynamic_macro_observe_i_30001_616
      003AA0 E0               [24] 1011 	movx	a,@dptr
      003AA1 FE               [12] 1012 	mov	r6,a
      003AA2 90 04 B4         [24] 1013 	mov	dptr,#_ak820_dynamic_macro_observe_base_10001_614
      003AA5 E0               [24] 1014 	movx	a,@dptr
      003AA6 2E               [12] 1015 	add	a, r6
      003AA7 75 F0 02         [24] 1016 	mov	b,#0x02
      003AAA A4               [48] 1017 	mul	ab
      003AAB 24 64            [12] 1018 	add	a, #_dm_taps
      003AAD FB               [12] 1019 	mov	r3,a
      003AAE 74 04            [12] 1020 	mov	a,#(_dm_taps >> 8)
      003AB0 35 F0            [12] 1021 	addc	a, b
      003AB2 FC               [12] 1022 	mov	r4,a
      003AB3 0B               [12] 1023 	inc	r3
      003AB4 BB 00 01         [24] 1024 	cjne	r3,#0x00,00184$
      003AB7 0C               [12] 1025 	inc	r4
      003AB8                       1026 00184$:
      003AB8 12 84 C5         [24] 1027 	lcall	_get_mods
      003ABB AA 82            [24] 1028 	mov	r2, dpl
      003ABD 12 84 DB         [24] 1029 	lcall	_get_weak_mods
      003AC0 E5 82            [12] 1030 	mov	a,dpl
      003AC2 42 02            [12] 1031 	orl	ar2,a
      003AC4 8B 82            [24] 1032 	mov	dpl,r3
      003AC6 8C 83            [24] 1033 	mov	dph,r4
      003AC8 EA               [12] 1034 	mov	a,r2
      003AC9 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:61: dm_lengths[slot] = i + 1;
      003ACA 90 04 B3         [24] 1037 	mov	dptr,#_ak820_dynamic_macro_observe_slot_10001_614
      003ACD E0               [24] 1038 	movx	a,@dptr
      003ACE 24 A4            [12] 1039 	add	a, #_dm_lengths
      003AD0 F5 82            [12] 1040 	mov	dpl,a
      003AD2 E4               [12] 1041 	clr	a
      003AD3 34 04            [12] 1042 	addc	a, #(_dm_lengths >> 8)
      003AD5 F5 83            [12] 1043 	mov	dph,a
      003AD7 0E               [12] 1044 	inc	r6
      003AD8 EE               [12] 1045 	mov	a,r6
      003AD9 F0               [24] 1046 	movx	@dptr,a
                                   1047 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003ADA 22               [24] 1048 	ret
      003ADB                       1049 00134$:
      003ADB EF               [12] 1050 	mov	a,r7
      003ADC 24 A4            [12] 1051 	add	a, #_dm_lengths
      003ADE FE               [12] 1052 	mov	r6,a
      003ADF E4               [12] 1053 	clr	a
      003AE0 34 04            [12] 1054 	addc	a, #(_dm_lengths >> 8)
      003AE2 FF               [12] 1055 	mov	r7,a
      003AE3 7C 00            [12] 1056 	mov	r4,#0x00
      003AE5                       1057 00115$:
      003AE5 8E 82            [24] 1058 	mov	dpl,r6
      003AE7 8F 83            [24] 1059 	mov	dph,r7
      003AE9 E0               [24] 1060 	movx	a,@dptr
      003AEA FB               [12] 1061 	mov	r3,a
      003AEB C3               [12] 1062 	clr	c
      003AEC EC               [12] 1063 	mov	a,r4
      003AED 9B               [12] 1064 	subb	a,r3
      003AEE 50 35            [24] 1065 	jnc	00117$
                                   1066 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:64: if (dm_taps[base + i].code == (uint8_t)(code | 0x80)) {
      003AF0 EC               [12] 1067 	mov	a,r4
      003AF1 2D               [12] 1068 	add	a, r5
      003AF2 75 F0 02         [24] 1069 	mov	b,#0x02
      003AF5 A4               [48] 1070 	mul	ab
      003AF6 24 64            [12] 1071 	add	a, #_dm_taps
      003AF8 F5 82            [12] 1072 	mov	dpl,a
      003AFA 74 04            [12] 1073 	mov	a,#(_dm_taps >> 8)
      003AFC 35 F0            [12] 1074 	addc	a, b
      003AFE F5 83            [12] 1075 	mov	dph,a
      003B00 E0               [24] 1076 	movx	a,@dptr
      003B01 FB               [12] 1077 	mov	r3,a
      003B02 90 04 B2         [24] 1078 	mov	dptr,#_ak820_dynamic_macro_observe_code_10000_611
      003B05 E0               [24] 1079 	movx	a,@dptr
      003B06 FA               [12] 1080 	mov	r2,a
      003B07 74 80            [12] 1081 	mov	a,#0x80
      003B09 4A               [12] 1082 	orl	a,r2
      003B0A F9               [12] 1083 	mov	r1,a
      003B0B EB               [12] 1084 	mov	a,r3
      003B0C B5 01 13         [24] 1085 	cjne	a,ar1,00116$
                                   1086 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:65: dm_taps[base + i].code = code;
      003B0F EC               [12] 1087 	mov	a,r4
      003B10 2D               [12] 1088 	add	a, r5
      003B11 75 F0 02         [24] 1089 	mov	b,#0x02
      003B14 A4               [48] 1090 	mul	ab
      003B15 24 64            [12] 1091 	add	a, #_dm_taps
      003B17 F5 82            [12] 1092 	mov	dpl,a
      003B19 74 04            [12] 1093 	mov	a,#(_dm_taps >> 8)
      003B1B 35 F0            [12] 1094 	addc	a, b
      003B1D F5 83            [12] 1095 	mov	dph,a
      003B1F EA               [12] 1096 	mov	a,r2
      003B20 F0               [24] 1097 	movx	@dptr,a
                                   1098 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:66: break;
      003B21 22               [24] 1099 	ret
      003B22                       1100 00116$:
                                   1101 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:63: for (uint8_t i = 0; i < dm_lengths[slot]; ++i) {
      003B22 0C               [12] 1102 	inc	r4
      003B23 80 C0            [24] 1103 	sjmp	00115$
      003B25                       1104 00117$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:70: }
      003B25 22               [24] 1106 	ret
                                   1107 ;------------------------------------------------------------
                                   1108 ;Allocation info for local variables in function 'ak820_dynamic_macro_task'
                                   1109 ;------------------------------------------------------------
                                   1110 ;now           Allocated with name '_ak820_dynamic_macro_task_now_10000_623'
                                   1111 ;i             Allocated with name '_ak820_dynamic_macro_task_i_40000_630'
                                   1112 ;code          Allocated with name '_ak820_dynamic_macro_task_code_40000_630'
                                   1113 ;------------------------------------------------------------
                                   1114 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:71: void ak820_dynamic_macro_task(uint16_t now) {
                                   1115 ;	-----------------------------------------
                                   1116 ;	 function ak820_dynamic_macro_task
                                   1117 ;	-----------------------------------------
      003B26                       1118 _ak820_dynamic_macro_task:
      003B26 AF 83            [24] 1119 	mov	r7,dph
      003B28 E5 82            [12] 1120 	mov	a,dpl
      003B2A 90 04 B6         [24] 1121 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003B2D F0               [24] 1122 	movx	@dptr,a
      003B2E EF               [12] 1123 	mov	a,r7
      003B2F A3               [24] 1124 	inc	dptr
      003B30 F0               [24] 1125 	movx	@dptr,a
                                   1126 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:72: if (!dm_play || ak820_macro_primitive || ak820_keyboard_report_pending() || (uint16_t)(now - dm_time) < 10) return;
      003B31 90 04 A7         [24] 1127 	mov	dptr,#_dm_play
      003B34 E0               [24] 1128 	movx	a,@dptr
      003B35 60 2D            [24] 1129 	jz	00101$
      003B37 90 09 E0         [24] 1130 	mov	dptr,#_ak820_macro_primitive
      003B3A E0               [24] 1131 	movx	a,@dptr
      003B3B 70 27            [24] 1132 	jnz	00101$
      003B3D 12 4C E6         [24] 1133 	lcall	_ak820_keyboard_report_pending
      003B40 E5 82            [12] 1134 	mov	a, dpl
      003B42 70 20            [24] 1135 	jnz	00101$
      003B44 90 04 AB         [24] 1136 	mov	dptr,#_dm_time
      003B47 E0               [24] 1137 	movx	a,@dptr
      003B48 FE               [12] 1138 	mov	r6,a
      003B49 A3               [24] 1139 	inc	dptr
      003B4A E0               [24] 1140 	movx	a,@dptr
      003B4B FF               [12] 1141 	mov	r7,a
      003B4C 90 04 B6         [24] 1142 	mov	dptr,#_ak820_dynamic_macro_task_now_10000_623
      003B4F E0               [24] 1143 	movx	a,@dptr
      003B50 FC               [12] 1144 	mov	r4,a
      003B51 A3               [24] 1145 	inc	dptr
      003B52 E0               [24] 1146 	movx	a,@dptr
      003B53 FD               [12] 1147 	mov	r5,a
      003B54 EC               [12] 1148 	mov	a,r4
      003B55 C3               [12] 1149 	clr	c
      003B56 9E               [12] 1150 	subb	a,r6
      003B57 FE               [12] 1151 	mov	r6,a
      003B58 ED               [12] 1152 	mov	a,r5
      003B59 9F               [12] 1153 	subb	a,r7
      003B5A FF               [12] 1154 	mov	r7,a
      003B5B C3               [12] 1155 	clr	c
      003B5C EE               [12] 1156 	mov	a,r6
      003B5D 94 0A            [12] 1157 	subb	a,#0x0a
      003B5F EF               [12] 1158 	mov	a,r7
      003B60 94 00            [12] 1159 	subb	a,#0x00
      003B62 50 01            [24] 1160 	jnc	00102$
      003B64                       1161 00101$:
      003B64 22               [24] 1162 	ret
      003B65                       1163 00102$:
                                   1164 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:73: dm_time = now;
      003B65 90 04 AB         [24] 1165 	mov	dptr,#_dm_time
      003B68 EC               [12] 1166 	mov	a,r4
      003B69 F0               [24] 1167 	movx	@dptr,a
      003B6A ED               [12] 1168 	mov	a,r5
      003B6B A3               [24] 1169 	inc	dptr
      003B6C F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:74: if (dm_down) {
      003B6D 90 04 A9         [24] 1172 	mov	dptr,#_dm_down
      003B70 E0               [24] 1173 	movx	a,@dptr
      003B71 FF               [12] 1174 	mov	r7,a
      003B72 E0               [24] 1175 	movx	a,@dptr
      003B73 60 16            [24] 1176 	jz	00112$
                                   1177 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:75: del_owned_key(dm_down);
      003B75 8F 82            [24] 1178 	mov	dpl, r7
      003B77 12 82 39         [24] 1179 	lcall	_del_owned_key
                                   1180 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:76: del_owned_mods(dm_mods);
      003B7A 90 04 AA         [24] 1181 	mov	dptr,#_dm_mods
      003B7D E0               [24] 1182 	movx	a,@dptr
      003B7E F5 82            [12] 1183 	mov	dpl,a
      003B80 12 81 29         [24] 1184 	lcall	_del_owned_mods
                                   1185 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:77: dm_down = 0;
      003B83 90 04 A9         [24] 1186 	mov	dptr,#_dm_down
      003B86 E4               [12] 1187 	clr	a
      003B87 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:78: send_keyboard_report();
      003B88 02 84 5A         [24] 1190 	ljmp	_send_keyboard_report
      003B8B                       1191 00112$:
                                   1192 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:79: } else if (dm_index == dm_lengths[dm_play - 1]) {
      003B8B 90 04 A7         [24] 1193 	mov	dptr,#_dm_play
      003B8E E0               [24] 1194 	movx	a,@dptr
      003B8F FF               [12] 1195 	mov	r7,a
      003B90 14               [12] 1196 	dec	a
      003B91 FE               [12] 1197 	mov	r6,a
      003B92 33               [12] 1198 	rlc	a
      003B93 95 E0            [12] 1199 	subb	a,acc
      003B95 FD               [12] 1200 	mov	r5,a
      003B96 EE               [12] 1201 	mov	a,r6
      003B97 24 A4            [12] 1202 	add	a, #_dm_lengths
      003B99 F5 82            [12] 1203 	mov	dpl,a
      003B9B ED               [12] 1204 	mov	a,r5
      003B9C 34 04            [12] 1205 	addc	a, #(_dm_lengths >> 8)
      003B9E F5 83            [12] 1206 	mov	dph,a
      003BA0 E0               [24] 1207 	movx	a,@dptr
      003BA1 FE               [12] 1208 	mov	r6,a
      003BA2 90 04 A8         [24] 1209 	mov	dptr,#_dm_index
      003BA5 E0               [24] 1210 	movx	a,@dptr
      003BA6 FD               [12] 1211 	mov	r5,a
      003BA7 B5 06 06         [24] 1212 	cjne	a,ar6,00109$
                                   1213 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:80: dm_play = 0;
      003BAA 90 04 A7         [24] 1214 	mov	dptr,#_dm_play
      003BAD E4               [12] 1215 	clr	a
      003BAE F0               [24] 1216 	movx	@dptr,a
      003BAF 22               [24] 1217 	ret
      003BB0                       1218 00109$:
                                   1219 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:82: uint8_t i = (dm_play - 1) * 16 + dm_index++;
      003BB0 1F               [12] 1220 	dec	r7
      003BB1 EF               [12] 1221 	mov	a,r7
      003BB2 C4               [12] 1222 	swap	a
      003BB3 54 F0            [12] 1223 	anl	a,#0xf0
      003BB5 FF               [12] 1224 	mov	r7,a
      003BB6 8D 06            [24] 1225 	mov	ar6,r5
      003BB8 90 04 A8         [24] 1226 	mov	dptr,#_dm_index
      003BBB ED               [12] 1227 	mov	a,r5
      003BBC 04               [12] 1228 	inc	a
      003BBD F0               [24] 1229 	movx	@dptr,a
      003BBE EE               [12] 1230 	mov	a,r6
      003BBF 2F               [12] 1231 	add	a, r7
      003BC0 FF               [12] 1232 	mov	r7,a
      003BC1 90 04 B8         [24] 1233 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003BC4 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:83: uint8_t code = dm_taps[i].code;
      003BC5 8F E0            [24] 1236 	mov	acc,r7
      003BC7 75 F0 02         [24] 1237 	mov	b,#0x02
      003BCA A4               [48] 1238 	mul	ab
      003BCB 24 64            [12] 1239 	add	a, #_dm_taps
      003BCD F5 82            [12] 1240 	mov	dpl,a
      003BCF 74 04            [12] 1241 	mov	a,#(_dm_taps >> 8)
      003BD1 35 F0            [12] 1242 	addc	a, b
      003BD3 F5 83            [12] 1243 	mov	dph,a
      003BD5 E0               [24] 1244 	movx	a,@dptr
      003BD6 FF               [12] 1245 	mov	r7,a
      003BD7 90 04 B9         [24] 1246 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003BDA F0               [24] 1247 	movx	@dptr,a
                                   1248 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:86: if (!add_owned_key(code)) {
      003BDB 8F 82            [24] 1249 	mov	dpl, r7
      003BDD 12 81 BC         [24] 1250 	lcall	_add_owned_key
      003BE0 E5 82            [12] 1251 	mov	a, dpl
      003BE2 70 09            [24] 1252 	jnz	00107$
                                   1253 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:87: del_owned_key(code);
      003BE4 90 04 B9         [24] 1254 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003BE7 E0               [24] 1255 	movx	a,@dptr
      003BE8 F5 82            [12] 1256 	mov	dpl,a
                                   1257 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:88: return;
      003BEA 02 82 39         [24] 1258 	ljmp	_del_owned_key
      003BED                       1259 00107$:
                                   1260 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:90: dm_down = code;
      003BED 90 04 B9         [24] 1261 	mov	dptr,#_ak820_dynamic_macro_task_code_40000_630
      003BF0 E0               [24] 1262 	movx	a,@dptr
      003BF1 90 04 A9         [24] 1263 	mov	dptr,#_dm_down
      003BF4 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:91: dm_mods = dm_taps[i].mods;
      003BF5 90 04 B8         [24] 1266 	mov	dptr,#_ak820_dynamic_macro_task_i_40000_630
      003BF8 E0               [24] 1267 	movx	a,@dptr
      003BF9 75 F0 02         [24] 1268 	mov	b,#0x02
      003BFC A4               [48] 1269 	mul	ab
      003BFD 24 64            [12] 1270 	add	a, #_dm_taps
      003BFF FE               [12] 1271 	mov	r6,a
      003C00 74 04            [12] 1272 	mov	a,#(_dm_taps >> 8)
      003C02 35 F0            [12] 1273 	addc	a, b
      003C04 FF               [12] 1274 	mov	r7,a
      003C05 8E 82            [24] 1275 	mov	dpl,r6
      003C07 8F 83            [24] 1276 	mov	dph,r7
      003C09 A3               [24] 1277 	inc	dptr
      003C0A E0               [24] 1278 	movx	a,@dptr
      003C0B FF               [12] 1279 	mov	r7,a
      003C0C 90 04 AA         [24] 1280 	mov	dptr,#_dm_mods
      003C0F F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:92: add_owned_mods(dm_mods);
      003C10 8F 82            [24] 1283 	mov	dpl, r7
      003C12 12 81 19         [24] 1284 	lcall	_add_owned_mods
                                   1285 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:93: send_keyboard_report();
                                   1286 ;	keyboards/ajazz/ak820/ak820_dynamic_macro.c:95: }
      003C15 02 84 5A         [24] 1287 	ljmp	_send_keyboard_report
                                   1288 	.area CSEG    (CODE)
                                   1289 	.area CONST   (CODE)
                                   1290 	.area XINIT   (CODE)
                                   1291 	.area CABS    (ABS,CODE)
