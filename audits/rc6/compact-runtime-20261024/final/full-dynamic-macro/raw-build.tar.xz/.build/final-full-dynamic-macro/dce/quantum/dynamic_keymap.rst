                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      00002A                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      00002A                        588 	.ds 2
      00002C                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002C                        590 	.ds 1
      00002D                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002D                        592 	.ds 1
      00002E                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002E                        594 	.ds 2
      000030                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      000030                        596 	.ds 2
      000032                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000032                        598 	.ds 1
      000033                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000033                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000026                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000026                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B32                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B32                        628 	.ds 1
      000B33                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B33                        630 	.ds 1
      000B34                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000B34                        632 	.ds 1
      000B35                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B35                        634 	.ds 1
      000B36                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B36                        636 	.ds 1
      000B37                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000B37                        638 	.ds 1
      000B38                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B38                        640 	.ds 1
      000B39                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B39                        642 	.ds 1
      000B3A                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B3A                        644 	.ds 2
      000B3C                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000B3C                        646 	.ds 1
      000B3D                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B3D                        648 	.ds 1
      000B3E                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000B3E                        650 	.ds 1
      000B3F                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B3F                        652 	.ds 1
      000B40                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B40                        654 	.ds 1
      000B41                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000B41                        656 	.ds 1
      000B42                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B42                        658 	.ds 1
      000B43                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B43                        660 	.ds 1
      000B44                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B44                        662 	.ds 2
      000B46                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000B46                        664 	.ds 1
      000B47                        665 _dynamic_keymap_get_combo_PARM_2:
      000B47                        666 	.ds 3
      000B4A                        667 _dynamic_keymap_get_combo_index_10000_384:
      000B4A                        668 	.ds 1
      000B4B                        669 _dynamic_keymap_set_combo_PARM_2:
      000B4B                        670 	.ds 3
      000B4E                        671 _dynamic_keymap_set_combo_index_10000_390:
      000B4E                        672 	.ds 1
      000B4F                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000B4F                        674 	.ds 10
      000B59                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000B59                        676 	.ds 1
      000B5A                        677 _dynamic_keymap_reset_combo_10001_407:
      000B5A                        678 	.ds 10
      000B64                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B64                        680 	.ds 2
      000B66                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B66                        682 	.ds 2
      000B68                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B68                        684 	.ds 2
      000B6A                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B6A                        686 	.ds 3
      000B6D                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B6D                        688 	.ds 2
      000B6F                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B6F                        690 	.ds 1
      000B70                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B70                        692 	.ds 2
      000B72                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B72                        694 	.ds 3
      000B75                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B75                        696 	.ds 2
      000B77                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B77                        698 	.ds 2
      000B79                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B79                        700 	.ds 3
      000B7C                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B7C                        702 	.ds 2
      000B7E                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B7E                        704 	.ds 1
      000B7F                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B7F                        706 	.ds 1
      000B80                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B80                        708 	.ds 1
      000B81                        709 _keycode_at_keymap_location_PARM_2:
      000B81                        710 	.ds 1
      000B82                        711 _keycode_at_keymap_location_PARM_3:
      000B82                        712 	.ds 1
      000B83                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B83                        714 	.ds 1
      000B84                        715 _keycode_at_encodermap_location_PARM_2:
      000B84                        716 	.ds 1
      000B85                        717 _keycode_at_encodermap_location_PARM_3:
      000B85                        718 	.ds 1
      000B86                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B86                        720 	.ds 1
      000B87                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B87                        722 	.ds 2
      000B89                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B89                        724 	.ds 3
      000B8C                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B8C                        726 	.ds 2
      000B8E                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B8E                        728 	.ds 2
      000B90                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B90                        730 	.ds 3
      000B93                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B93                        732 	.ds 2
      000B95                        733 _decode_keycode_kc_10000_454:
      000B95                        734 	.ds 2
      000B97                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B97                        736 	.ds 1
      000B98                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B98                        738 	.ds 1
      000B99                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B99                        740 	.ds 2
      000B9B                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B9B                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      0087FF                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0087FF 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008802 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008803                        810 _dynamic_keymap_key_to_eeprom_address:
      008803 E5 82            [12]  811 	mov	a,dpl
      008805 90 0B 34         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      008808 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008809 E0               [24]  815 	movx	a,@dptr
      00880A FF               [12]  816 	mov	r7,a
      00880B 7E 00            [12]  817 	mov	r6,#0x00
      00880D 74 40            [12]  818 	mov	a,#0x40
      00880F 12 46 AE         [24]  819 	lcall	_ak820_outline_0139
      008812 7D 00            [12]  820 	mov	r5,#0x00
      008814 90 0B 32         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008817 E0               [24]  822 	movx	a,@dptr
      008818 75 F0 10         [24]  823 	mov	b,#0x10
      00881B A4               [48]  824 	mul	ab
      00881C 2E               [12]  825 	add	a, r6
      00881D FE               [12]  826 	mov	r6,a
      00881E EF               [12]  827 	mov	a,r7
      00881F 35 F0            [12]  828 	addc	a, b
      008821 FF               [12]  829 	mov	r7,a
      008822 90 0B 33         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008825 E0               [24]  831 	movx	a,@dptr
      008826 7C 00            [12]  832 	mov	r4,#0x00
      008828 25 E0            [12]  833 	add	a,acc
      00882A FB               [12]  834 	mov	r3,a
      00882B EC               [12]  835 	mov	a,r4
      00882C 33               [12]  836 	rlc	a
      00882D FC               [12]  837 	mov	r4,a
      00882E EB               [12]  838 	mov	a,r3
      00882F 2E               [12]  839 	add	a, r6
      008830 FE               [12]  840 	mov	r6,a
      008831 EC               [12]  841 	mov	a,r4
      008832 3F               [12]  842 	addc	a, r7
      008833 FF               [12]  843 	mov	r7,a
      008834 12 73 26         [24]  844 	lcall	_ak820_outline_0051
                                    845 ;	quantum/dynamic_keymap.c:184: }
      008837 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      008838                        860 _dynamic_keymap_get_keycode:
      008838 E5 82            [12]  861 	mov	a,dpl
      00883A 90 0B 37         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      00883D F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      00883E E0               [24]  865 	movx	a,@dptr
      00883F FF               [12]  866 	mov	r7,a
      008840 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      008843                        868 00121$:
      008843 50 14            [24]  869 	jnc	00101$
      008845 90 0B 35         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008848 E0               [24]  871 	movx	a,@dptr
      008849 FE               [12]  872 	mov	r6,a
      00884A BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      00884D                        874 00123$:
      00884D 50 0A            [24]  875 	jnc	00101$
      00884F 90 0B 36         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008852 E0               [24]  877 	movx	a,@dptr
      008853 FD               [12]  878 	mov	r5,a
      008854 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      008857                        880 00125$:
      008857 40 04            [24]  881 	jc	00102$
      008859                        882 00101$:
      008859 90 00 00         [24]  883 	mov	dptr,#0x0000
      00885C 22               [24]  884 	ret
      00885D                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00885D 12 92 91         [24]  887 	lcall	_ak820_outline_0102
      008860 12 88 03         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008863 12 92 A5         [24]  890 	lcall	_ak820_outline_0118
      008866 12 43 C1         [24]  891 	lcall	_eeprom_read_byte
      008869 AB 82            [24]  892 	mov	r3,dpl
      00886B 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      00886D 0D               [12]  895 	inc	r5
      00886E BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      008871 0E               [12]  897 	inc	r6
      008872                        898 00127$:
      008872 12 71 03         [24]  899 	lcall	_ak820_outline_0050
      008875 12 43 C1         [24]  900 	lcall	_eeprom_read_byte
      008878 AF 82            [24]  901 	mov	r7, dpl
      00887A 7E 00            [12]  902 	mov	r6,#0x00
      00887C EF               [12]  903 	mov	a,r7
      00887D 42 04            [12]  904 	orl	ar4,a
      00887F EE               [12]  905 	mov	a,r6
      008880 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      008882 12 46 D5         [24]  908 	lcall	_ak820_outline_0185
                                    909 ;	quantum/dynamic_keymap.c:193: }
      008885 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      008886                        924 _dynamic_keymap_set_keycode:
      008886 E5 82            [12]  925 	mov	a,dpl
      008888 90 0B 3C         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      00888B F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      00888C E0               [24]  929 	movx	a,@dptr
      00888D FF               [12]  930 	mov	r7,a
      00888E BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008891                        932 00121$:
      008891 50 14            [24]  933 	jnc	00101$
      008893 90 0B 38         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008896 E0               [24]  935 	movx	a,@dptr
      008897 FE               [12]  936 	mov	r6,a
      008898 BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      00889B                        938 00123$:
      00889B 50 0A            [24]  939 	jnc	00101$
      00889D 90 0B 39         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0088A0 E0               [24]  941 	movx	a,@dptr
      0088A1 FD               [12]  942 	mov	r5,a
      0088A2 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      0088A5                        944 00125$:
      0088A5 40 01            [24]  945 	jc	00102$
      0088A7                        946 00101$:
      0088A7 22               [24]  947 	ret
      0088A8                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0088A8 12 92 91         [24]  950 	lcall	_ak820_outline_0102
      0088AB 12 88 03         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      0088AE 12 92 A5         [24]  952 	lcall	_ak820_outline_0118
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0088B1 90 0B 3A         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0088B4 E0               [24]  955 	movx	a,@dptr
      0088B5 FB               [12]  956 	mov	r3,a
      0088B6 A3               [24]  957 	inc	dptr
      0088B7 E0               [24]  958 	movx	a,@dptr
      0088B8 90 06 F1         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088BB 12 52 56         [24]  960 	lcall	_ak820_outline_0031
      0088BE 12 51 41         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0088C1 0D               [12]  963 	inc	r5
      0088C2 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      0088C5 0E               [12]  965 	inc	r6
      0088C6                        966 00127$:
      0088C6 90 06 F1         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088C9 EB               [12]  968 	mov	a,r3
      0088CA 12 52 56         [24]  969 	lcall	_ak820_outline_0031
                                    970 ;	quantum/dynamic_keymap.c:201: }
      0088CD 02 51 41         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      0088D0                        982 _dynamic_keymap_encoder_to_eeprom_address:
      0088D0 E5 82            [12]  983 	mov	a,dpl
      0088D2 90 0B 3E         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      0088D5 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0088D6 E0               [24]  987 	movx	a,@dptr
      0088D7 75 F0 04         [24]  988 	mov	b,#0x04
      0088DA A4               [48]  989 	mul	ab
      0088DB 24 40            [12]  990 	add	a, #0x40
      0088DD FD               [12]  991 	mov	r5,a
      0088DE 74 06            [12]  992 	mov	a,#0x06
      0088E0 35 F0            [12]  993 	addc	a, b
      0088E2 FE               [12]  994 	mov	r6,a
      0088E3 7F 00            [12]  995 	mov	r7,#0x00
      0088E5 90 0B 3D         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088E8 E0               [24]  997 	movx	a,@dptr
      0088E9 75 F0 04         [24]  998 	mov	b,#0x04
      0088EC A4               [48]  999 	mul	ab
      0088ED 2D               [12] 1000 	add	a, r5
      0088EE FD               [12] 1001 	mov	r5,a
      0088EF EE               [12] 1002 	mov	a,r6
      0088F0 35 F0            [12] 1003 	addc	a, b
      0088F2 FE               [12] 1004 	mov	r6,a
      0088F3 12 71 03         [24] 1005 	lcall	_ak820_outline_0050
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      0088F6 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      0088F7                       1021 _dynamic_keymap_get_encoder:
      0088F7 E5 82            [12] 1022 	mov	a,dpl
      0088F9 90 0B 41         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      0088FC F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0088FD E0               [24] 1026 	movx	a,@dptr
      0088FE FF               [12] 1027 	mov	r7,a
      0088FF BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008902                       1029 00131$:
      008902 50 0A            [24] 1030 	jnc	00101$
      008904 90 0B 3F         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008907 E0               [24] 1032 	movx	a,@dptr
      008908 FE               [12] 1033 	mov	r6,a
      008909 BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      00890C                       1035 00133$:
      00890C 40 04            [24] 1036 	jc	00102$
      00890E                       1037 00101$:
      00890E 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008911 22               [24] 1039 	ret
      008912                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008912 90 0B 3D         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008915 12 7B BE         [24] 1043 	lcall	_ak820_outline_0190
      008918 12 88 D0         [24] 1044 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00891B 12 92 A5         [24] 1045 	lcall	_ak820_outline_0118
                                   1046 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      00891E 90 0B 40         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008921 E0               [24] 1048 	movx	a,@dptr
      008922 FC               [12] 1049 	mov	r4,a
      008923 E0               [24] 1050 	movx	a,@dptr
      008924 60 04            [24] 1051 	jz	00106$
      008926 7B 00            [12] 1052 	mov	r3,#0x00
      008928 80 02            [24] 1053 	sjmp	00107$
      00892A                       1054 00106$:
      00892A 7B 02            [12] 1055 	mov	r3,#0x02
      00892C                       1056 00107$:
      00892C EB               [12] 1057 	mov	a,r3
      00892D 12 7B 38         [24] 1058 	lcall	_ak820_outline_0014
      008930 12 43 C1         [24] 1059 	lcall	_eeprom_read_byte
      008933 AA 82            [24] 1060 	mov	r2,dpl
      008935 7B 00            [12] 1061 	mov	r3,#0x00
                                   1062 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008937 EC               [12] 1063 	mov	a,r4
      008938 60 04            [24] 1064 	jz	00108$
      00893A 7C 00            [12] 1065 	mov	r4,#0x00
      00893C 80 02            [24] 1066 	sjmp	00109$
      00893E                       1067 00108$:
      00893E 7C 02            [12] 1068 	mov	r4,#0x02
      008940                       1069 00109$:
      008940 EC               [12] 1070 	mov	a,r4
      008941 12 38 BB         [24] 1071 	lcall	_ak820_outline_0162
      008944 0D               [12] 1072 	inc	r5
      008945 BD 00 01         [24] 1073 	cjne	r5,#0x00,00137$
      008948 0E               [12] 1074 	inc	r6
      008949                       1075 00137$:
      008949 12 71 03         [24] 1076 	lcall	_ak820_outline_0050
      00894C 12 43 C1         [24] 1077 	lcall	_eeprom_read_byte
      00894F AF 82            [24] 1078 	mov	r7, dpl
      008951 7E 00            [12] 1079 	mov	r6,#0x00
      008953 EF               [12] 1080 	mov	a,r7
      008954 42 03            [12] 1081 	orl	ar3,a
      008956 EE               [12] 1082 	mov	a,r6
      008957 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/dynamic_keymap.c:214: return keycode;
      008959 8B 82            [24] 1085 	mov	dpl, r3
      00895B 8A 83            [24] 1086 	mov	dph, r2
                                   1087 ;	quantum/dynamic_keymap.c:215: }
      00895D 22               [24] 1088 	ret
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1091 ;------------------------------------------------------------
                                   1092 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1093 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1094 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1095 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1096 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1097 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function dynamic_keymap_set_encoder
                                   1102 ;	-----------------------------------------
      00895E                       1103 _dynamic_keymap_set_encoder:
      00895E E5 82            [12] 1104 	mov	a,dpl
      008960 90 0B 46         [24] 1105 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008963 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008964 E0               [24] 1108 	movx	a,@dptr
      008965 FF               [12] 1109 	mov	r7,a
      008966 BF 06 00         [24] 1110 	cjne	r7,#0x06,00131$
      008969                       1111 00131$:
      008969 50 0A            [24] 1112 	jnc	00101$
      00896B 90 0B 42         [24] 1113 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00896E E0               [24] 1114 	movx	a,@dptr
      00896F FE               [12] 1115 	mov	r6,a
      008970 BE 01 00         [24] 1116 	cjne	r6,#0x01,00133$
      008973                       1117 00133$:
      008973 40 01            [24] 1118 	jc	00102$
      008975                       1119 00101$:
      008975 22               [24] 1120 	ret
      008976                       1121 00102$:
                                   1122 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008976 90 0B 3D         [24] 1123 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008979 12 7B BE         [24] 1124 	lcall	_ak820_outline_0190
      00897C 12 88 D0         [24] 1125 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00897F 12 92 A5         [24] 1126 	lcall	_ak820_outline_0118
                                   1127 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008982 90 0B 43         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008985 E0               [24] 1129 	movx	a,@dptr
      008986 FC               [12] 1130 	mov	r4,a
      008987 E0               [24] 1131 	movx	a,@dptr
      008988 60 04            [24] 1132 	jz	00106$
      00898A 7B 00            [12] 1133 	mov	r3,#0x00
      00898C 80 02            [24] 1134 	sjmp	00107$
      00898E                       1135 00106$:
      00898E 7B 02            [12] 1136 	mov	r3,#0x02
      008990                       1137 00107$:
      008990 EB               [12] 1138 	mov	a,r3
      008991 12 92 B7         [24] 1139 	lcall	_ak820_outline_0138
      008994 8F 03            [24] 1140 	mov	ar3,r7
      008996 90 0B 44         [24] 1141 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008999 E0               [24] 1142 	movx	a,@dptr
      00899A F5 2A            [12] 1143 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      00899C A3               [24] 1144 	inc	dptr
      00899D E0               [24] 1145 	movx	a,@dptr
      00899E F5 2B            [12] 1146 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0089A0 90 06 F1         [24] 1147 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089A3 F0               [24] 1148 	movx	@dptr,a
      0089A4 12 46 D0         [24] 1149 	lcall	_ak820_outline_0184
      0089A7 8B F0            [24] 1150 	mov	b, r3
      0089A9 12 51 41         [24] 1151 	lcall	_eeprom_update_byte
                                   1152 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0089AC EC               [12] 1153 	mov	a,r4
      0089AD 60 04            [24] 1154 	jz	00108$
      0089AF 7C 00            [12] 1155 	mov	r4,#0x00
      0089B1 80 02            [24] 1156 	sjmp	00109$
      0089B3                       1157 00108$:
      0089B3 7C 02            [12] 1158 	mov	r4,#0x02
      0089B5                       1159 00109$:
      0089B5 EC               [12] 1160 	mov	a,r4
      0089B6 12 38 BB         [24] 1161 	lcall	_ak820_outline_0162
      0089B9 0D               [12] 1162 	inc	r5
      0089BA BD 00 01         [24] 1163 	cjne	r5,#0x00,00137$
      0089BD 0E               [12] 1164 	inc	r6
      0089BE                       1165 00137$:
      0089BE 90 06 F1         [24] 1166 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089C1 E5 2A            [12] 1167 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0089C3 12 52 56         [24] 1168 	lcall	_ak820_outline_0031
                                   1169 ;	quantum/dynamic_keymap.c:223: }
      0089C6 02 51 41         [24] 1170 	ljmp	_eeprom_update_byte
                                   1171 ;------------------------------------------------------------
                                   1172 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1173 ;------------------------------------------------------------
                                   1174 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1175 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1176 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1177 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1178 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1179 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function dynamic_keymap_get_combo
                                   1184 ;	-----------------------------------------
      0089C9                       1185 _dynamic_keymap_get_combo:
      0089C9 E5 82            [12] 1186 	mov	a,dpl
      0089CB 90 0B 4A         [24] 1187 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0089CE F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0089CF 90 0B 47         [24] 1190 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0089D2 12 38 41         [24] 1191 	lcall	_ak820_outline_0053
                                   1192 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      0089D5 90 0B 4A         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      0089D8 E0               [24] 1194 	movx	a,@dptr
      0089D9 FD               [12] 1195 	mov	r5,a
      0089DA BD 08 00         [24] 1196 	cjne	r5,#0x08,00132$
      0089DD                       1197 00132$:
      0089DD 40 04            [24] 1198 	jc	00102$
                                   1199 ;	quantum/dynamic_keymap.c:275: return -1;
      0089DF 90 FF FF         [24] 1200 	mov	dptr,#0xffff
      0089E2 22               [24] 1201 	ret
      0089E3                       1202 00102$:
                                   1203 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0089E3 12 92 7D         [24] 1204 	lcall	_ak820_outline_0083
                                   1205 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0089E6 8E 02            [24] 1206 	mov	ar2,r6
      0089E8 8F 03            [24] 1207 	mov	ar3,r7
      0089EA 90 05 DB         [24] 1208 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0089ED 12 38 5E         [24] 1209 	lcall	_ak820_outline_0072
      0089F0 E4               [12] 1210 	clr	a
      0089F1 A3               [24] 1211 	inc	dptr
      0089F2 F0               [24] 1212 	movx	@dptr,a
      0089F3 90 05 DE         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0089F6 12 92 9E         [24] 1214 	lcall	_ak820_outline_0114
      0089F9 12 38 AC         [24] 1215 	lcall	_ak820_outline_0145
      0089FC C0 07            [24] 1216 	push	ar7
      0089FE C0 06            [24] 1217 	push	ar6
      008A00 12 43 FC         [24] 1218 	lcall	_ak820_eeprom_read_block_xdata
      008A03 D0 06            [24] 1219 	pop	ar6
      008A05 D0 07            [24] 1220 	pop	ar7
                                   1221 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008A07 74 04            [12] 1222 	mov	a,#0x04
      008A09 12 4B BF         [24] 1223 	lcall	_ak820_outline_0034
      008A0C FA               [12] 1224 	mov	r2,a
      008A0D A3               [24] 1225 	inc	dptr
      008A0E E0               [24] 1226 	movx	a,@dptr
      008A0F FB               [12] 1227 	mov	r3,a
      008A10 BA 20 13         [24] 1228 	cjne	r2,#0x20,00108$
      008A13 BB 08 10         [24] 1229 	cjne	r3,#0x08,00108$
      008A16 74 06            [12] 1230 	mov	a,#0x06
      008A18 12 38 31         [24] 1231 	lcall	_ak820_outline_0022
      008A1B 12 46 97         [24] 1232 	lcall	_ak820_outline_0106
      008A1E BA 01 05         [24] 1233 	cjne	r2,#0x01,00136$
      008A21 BB 00 02         [24] 1234 	cjne	r3,#0x00,00136$
      008A24 80 05            [24] 1235 	sjmp	00109$
      008A26                       1236 00136$:
      008A26                       1237 00108$:
      008A26 75 2C 00         [24] 1238 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008A29 80 03            [24] 1239 	sjmp	00110$
      008A2B                       1240 00109$:
      008A2B 75 2C 01         [24] 1241 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008A2E                       1242 00110$:
                                   1243 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008A2E 74 06            [12] 1244 	mov	a,#0x06
      008A30 12 38 31         [24] 1245 	lcall	_ak820_outline_0022
      008A33 E4               [12] 1246 	clr	a
      008A34 F0               [24] 1247 	movx	@dptr,a
      008A35 A3               [24] 1248 	inc	dptr
      008A36 12 38 76         [24] 1249 	lcall	_ak820_outline_0104
      008A39 F0               [24] 1250 	movx	@dptr,a
      008A3A A3               [24] 1251 	inc	dptr
      008A3B F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008A3C E5 2C            [12] 1254 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008A3E 60 12            [24] 1255 	jz	00103$
      008A40 12 38 8C         [24] 1256 	lcall	_ak820_outline_0120
      008A43 C0 07            [24] 1257 	push	ar7
      008A45 C0 06            [24] 1258 	push	ar6
      008A47 12 34 D1         [24] 1259 	lcall	_ak820_combo_valid
      008A4A E5 82            [12] 1260 	mov	a, dpl
      008A4C D0 06            [24] 1261 	pop	ar6
      008A4E D0 07            [24] 1262 	pop	ar7
      008A50 70 13            [24] 1263 	jnz	00104$
      008A52                       1264 00103$:
      008A52 7D 00            [12] 1265 	mov	r5,#0x00
      008A54 90 0E 02         [24] 1266 	mov	dptr,#_memset_PARM_2
      008A57 E4               [12] 1267 	clr	a
      008A58 F0               [24] 1268 	movx	@dptr,a
      008A59 90 0E 03         [24] 1269 	mov	dptr,#_memset_PARM_3
      008A5C 12 92 9E         [24] 1270 	lcall	_ak820_outline_0114
      008A5F 12 73 26         [24] 1271 	lcall	_ak820_outline_0051
      008A62 12 BC AB         [24] 1272 	lcall	_memset
      008A65                       1273 00104$:
                                   1274 ;	quantum/dynamic_keymap.c:289: return 0;
      008A65 90 00 00         [24] 1275 	mov	dptr,#0x0000
                                   1276 ;	quantum/dynamic_keymap.c:290: }
      008A68 22               [24] 1277 	ret
                                   1278 ;------------------------------------------------------------
                                   1279 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1280 ;------------------------------------------------------------
                                   1281 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1282 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1283 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1284 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1285 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1286 ;------------------------------------------------------------
                                   1287 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1288 ;	-----------------------------------------
                                   1289 ;	 function dynamic_keymap_set_combo
                                   1290 ;	-----------------------------------------
      008A69                       1291 _dynamic_keymap_set_combo:
      008A69 E5 82            [12] 1292 	mov	a,dpl
      008A6B 90 0B 4E         [24] 1293 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008A6E F0               [24] 1294 	movx	@dptr,a
                                   1295 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A6F 90 0B 4B         [24] 1296 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008A72 12 37 F4         [24] 1297 	lcall	_ak820_outline_0005
                                   1298 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008A75 C0 07            [24] 1299 	push	ar7
      008A77 C0 06            [24] 1300 	push	ar6
      008A79 12 34 D1         [24] 1301 	lcall	_ak820_combo_valid
      008A7C E5 82            [12] 1302 	mov	a, dpl
      008A7E D0 06            [24] 1303 	pop	ar6
      008A80 D0 07            [24] 1304 	pop	ar7
      008A82 60 07            [24] 1305 	jz	00101$
      008A84 12 41 67         [24] 1306 	lcall	_ak820_nvm_ok
      008A87 E5 82            [12] 1307 	mov	a, dpl
      008A89 70 04            [24] 1308 	jnz	00102$
      008A8B                       1309 00101$:
      008A8B 90 FF FF         [24] 1310 	mov	dptr,#0xffff
      008A8E 22               [24] 1311 	ret
      008A8F                       1312 00102$:
                                   1313 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008A8F 90 0B 4E         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008A92 E0               [24] 1315 	movx	a,@dptr
      008A93 FD               [12] 1316 	mov	r5,a
      008A94 BD 08 00         [24] 1317 	cjne	r5,#0x08,00133$
      008A97                       1318 00133$:
      008A97 40 04            [24] 1319 	jc	00105$
                                   1320 ;	quantum/dynamic_keymap.c:302: return -1;
      008A99 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008A9C 22               [24] 1322 	ret
      008A9D                       1323 00105$:
                                   1324 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008A9D 12 92 7D         [24] 1325 	lcall	_ak820_outline_0083
                                   1326 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008AA0 C0 07            [24] 1327 	push	ar7
      008AA2 C0 06            [24] 1328 	push	ar6
      008AA4 C0 05            [24] 1329 	push	ar5
      008AA6 C0 04            [24] 1330 	push	ar4
      008AA8 12 7A DF         [24] 1331 	lcall	_clear_keyboard
      008AAB D0 04            [24] 1332 	pop	ar4
      008AAD D0 05            [24] 1333 	pop	ar5
      008AAF D0 06            [24] 1334 	pop	ar6
      008AB1 D0 07            [24] 1335 	pop	ar7
                                   1336 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008AB3 90 0D FA         [24] 1337 	mov	dptr,#___memcpy_PARM_2
      008AB6 12 4B D2         [24] 1338 	lcall	_ak820_outline_0060
      008AB9 E4               [12] 1339 	clr	a
      008ABA A3               [24] 1340 	inc	dptr
      008ABB F0               [24] 1341 	movx	@dptr,a
      008ABC 90 0D FD         [24] 1342 	mov	dptr,#___memcpy_PARM_3
      008ABF 12 92 9E         [24] 1343 	lcall	_ak820_outline_0114
      008AC2 90 0B 4F         [24] 1344 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008AC5 F5 F0            [12] 1345 	mov	b,a
      008AC7 C0 05            [24] 1346 	push	ar5
      008AC9 C0 04            [24] 1347 	push	ar4
      008ACB 12 BC 35         [24] 1348 	lcall	___memcpy
      008ACE D0 04            [24] 1349 	pop	ar4
      008AD0 D0 05            [24] 1350 	pop	ar5
                                   1351 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008AD2 90 0B 53         [24] 1352 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008AD5 74 20            [12] 1353 	mov	a,#0x20
      008AD7 F0               [24] 1354 	movx	@dptr,a
      008AD8 74 08            [12] 1355 	mov	a,#0x08
      008ADA A3               [24] 1356 	inc	dptr
      008ADB F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008ADC 90 0B 55         [24] 1359 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      008ADF 74 01            [12] 1360 	mov	a,#0x01
      008AE1 12 38 9C         [24] 1361 	lcall	_ak820_outline_0136
                                   1362 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008AE4 90 05 E4         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008AE7 12 38 5E         [24] 1364 	lcall	_ak820_outline_0072
      008AEA E4               [12] 1365 	clr	a
      008AEB A3               [24] 1366 	inc	dptr
      008AEC F0               [24] 1367 	movx	@dptr,a
      008AED 90 05 E7         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008AF0 12 92 9E         [24] 1369 	lcall	_ak820_outline_0114
      008AF3 90 0B 4F         [24] 1370 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008AF6 12 44 88         [24] 1371 	lcall	_ak820_eeprom_write_block_xdata
                                   1372 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008AF9 12 41 76         [24] 1373 	lcall	_ak820_nvm_flush
                                   1374 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008AFC 12 41 67         [24] 1375 	lcall	_ak820_nvm_ok
      008AFF E5 82            [12] 1376 	mov	a, dpl
      008B01 70 04            [24] 1377 	jnz	00107$
      008B03 90 FF FF         [24] 1378 	mov	dptr,#0xffff
      008B06 22               [24] 1379 	ret
      008B07                       1380 00107$:
                                   1381 ;	quantum/dynamic_keymap.c:320: return 0;
      008B07 90 00 00         [24] 1382 	mov	dptr,#0x0000
                                   1383 ;	quantum/dynamic_keymap.c:321: }
      008B0A 22               [24] 1384 	ret
                                   1385 ;------------------------------------------------------------
                                   1386 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1387 ;------------------------------------------------------------
                                   1388 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1389 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1390 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1391 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1392 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1393 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1394 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1395 ;------------------------------------------------------------
                                   1396 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1397 ;	-----------------------------------------
                                   1398 ;	 function dynamic_keymap_reset
                                   1399 ;	-----------------------------------------
      008B0B                       1400 _dynamic_keymap_reset:
                                   1401 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008B0B 90 0E 7A         [24] 1402 	mov	dptr,#_vial_unlocked
      008B0E E0               [24] 1403 	movx	a,@dptr
      008B0F 90 0B 59         [24] 1404 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008B12 F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008B13 90 0E 7A         [24] 1407 	mov	dptr,#_vial_unlocked
      008B16 74 01            [12] 1408 	mov	a,#0x01
      008B18 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008B19 7F 00            [12] 1411 	mov	r7,#0x00
      008B1B                       1412 00116$:
      008B1B BF 06 00         [24] 1413 	cjne	r7,#0x06,00198$
      008B1E                       1414 00198$:
      008B1E 40 03            [24] 1415 	jc	00199$
      008B20 02 8B CE         [24] 1416 	ljmp	00104$
      008B23                       1417 00199$:
                                   1418 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B23 7E 00            [12] 1419 	mov	r6,#0x00
      008B25                       1420 00110$:
      008B25 BE 10 00         [24] 1421 	cjne	r6,#0x10,00200$
      008B28                       1422 00200$:
      008B28 50 4D            [24] 1423 	jnc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B2A 7D 00            [12] 1425 	mov	r5,#0x00
      008B2C                       1426 00107$:
      008B2C BD 08 00         [24] 1427 	cjne	r5,#0x08,00202$
      008B2F                       1428 00202$:
      008B2F 50 43            [24] 1429 	jnc	00111$
                                   1430 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008B31 90 0B F5         [24] 1431 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008B34 EE               [12] 1432 	mov	a,r6
      008B35 F0               [24] 1433 	movx	@dptr,a
      008B36 90 0B F6         [24] 1434 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008B39 ED               [12] 1435 	mov	a,r5
      008B3A F0               [24] 1436 	movx	@dptr,a
      008B3B 8F 82            [24] 1437 	mov	dpl, r7
      008B3D C0 07            [24] 1438 	push	ar7
      008B3F C0 06            [24] 1439 	push	ar6
      008B41 C0 05            [24] 1440 	push	ar5
      008B43 12 9A CC         [24] 1441 	lcall	_keycode_at_keymap_location_raw
      008B46 AB 82            [24] 1442 	mov	r3, dpl
      008B48 AC 83            [24] 1443 	mov	r4, dph
      008B4A D0 05            [24] 1444 	pop	ar5
      008B4C D0 06            [24] 1445 	pop	ar6
      008B4E D0 07            [24] 1446 	pop	ar7
      008B50 90 0B 38         [24] 1447 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008B53 EE               [12] 1448 	mov	a,r6
      008B54 F0               [24] 1449 	movx	@dptr,a
      008B55 90 0B 39         [24] 1450 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008B58 ED               [12] 1451 	mov	a,r5
      008B59 F0               [24] 1452 	movx	@dptr,a
      008B5A 90 0B 3A         [24] 1453 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008B5D 12 38 6A         [24] 1454 	lcall	_ak820_outline_0087
      008B60 8F 82            [24] 1455 	mov	dpl, r7
      008B62 C0 07            [24] 1456 	push	ar7
      008B64 C0 06            [24] 1457 	push	ar6
      008B66 C0 05            [24] 1458 	push	ar5
      008B68 12 88 86         [24] 1459 	lcall	_dynamic_keymap_set_keycode
      008B6B D0 05            [24] 1460 	pop	ar5
      008B6D D0 06            [24] 1461 	pop	ar6
      008B6F D0 07            [24] 1462 	pop	ar7
                                   1463 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008B71 0D               [12] 1464 	inc	r5
      008B72 80 B8            [24] 1465 	sjmp	00107$
      008B74                       1466 00111$:
                                   1467 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008B74 0E               [12] 1468 	inc	r6
      008B75 80 AE            [24] 1469 	sjmp	00110$
      008B77                       1470 00102$:
                                   1471 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008B77 7E 00            [12] 1472 	mov	r6,#0x00
      008B79                       1473 00113$:
      008B79 BE 01 00         [24] 1474 	cjne	r6,#0x01,00204$
      008B7C                       1475 00204$:
      008B7C 50 4C            [24] 1476 	jnc	00117$
                                   1477 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008B7E 12 92 D3         [24] 1478 	lcall	_ak820_outline_0179
      008B81 04               [12] 1479 	inc	a
      008B82 F0               [24] 1480 	movx	@dptr,a
      008B83 8F 82            [24] 1481 	mov	dpl, r7
      008B85 C0 07            [24] 1482 	push	ar7
      008B87 12 9B 11         [24] 1483 	lcall	_keycode_at_encodermap_location_raw
      008B8A 12 46 BA         [24] 1484 	lcall	_ak820_outline_0151
      008B8D D0 07            [24] 1485 	pop	ar7
      008B8F 12 92 CA         [24] 1486 	lcall	_ak820_outline_0178
      008B92 04               [12] 1487 	inc	a
      008B93 F0               [24] 1488 	movx	@dptr,a
      008B94 90 0B 44         [24] 1489 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008B97 12 38 5E         [24] 1490 	lcall	_ak820_outline_0072
      008B9A 8F 82            [24] 1491 	mov	dpl, r7
      008B9C C0 07            [24] 1492 	push	ar7
      008B9E 12 89 5E         [24] 1493 	lcall	_dynamic_keymap_set_encoder
      008BA1 D0 07            [24] 1494 	pop	ar7
                                   1495 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008BA3 12 92 D3         [24] 1496 	lcall	_ak820_outline_0179
      008BA6 F0               [24] 1497 	movx	@dptr,a
      008BA7 8F 82            [24] 1498 	mov	dpl, r7
      008BA9 C0 07            [24] 1499 	push	ar7
      008BAB 12 9B 11         [24] 1500 	lcall	_keycode_at_encodermap_location_raw
      008BAE 12 46 BA         [24] 1501 	lcall	_ak820_outline_0151
      008BB1 D0 07            [24] 1502 	pop	ar7
      008BB3 12 92 CA         [24] 1503 	lcall	_ak820_outline_0178
      008BB6 F0               [24] 1504 	movx	@dptr,a
      008BB7 90 0B 44         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BBA 12 38 5E         [24] 1506 	lcall	_ak820_outline_0072
      008BBD 8F 82            [24] 1507 	mov	dpl, r7
      008BBF C0 07            [24] 1508 	push	ar7
      008BC1 12 89 5E         [24] 1509 	lcall	_dynamic_keymap_set_encoder
      008BC4 D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008BC6 7E 01            [12] 1512 	mov	r6,#0x01
      008BC8 80 AF            [24] 1513 	sjmp	00113$
      008BCA                       1514 00117$:
                                   1515 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BCA 0F               [12] 1516 	inc	r7
      008BCB 02 8B 1B         [24] 1517 	ljmp	00116$
      008BCE                       1518 00104$:
                                   1519 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008BCE 90 0B 5A         [24] 1520 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008BD1 12 52 A0         [24] 1521 	lcall	_ak820_outline_0183
      008BD4 90 0B 5C         [24] 1522 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008BD7 F0               [24] 1523 	movx	@dptr,a
      008BD8 A3               [24] 1524 	inc	dptr
      008BD9 F0               [24] 1525 	movx	@dptr,a
      008BDA 90 0B 5E         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      008BDD F0               [24] 1527 	movx	@dptr,a
      008BDE A3               [24] 1528 	inc	dptr
      008BDF F0               [24] 1529 	movx	@dptr,a
      008BE0 90 0B 60         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008BE3 F0               [24] 1531 	movx	@dptr,a
      008BE4 A3               [24] 1532 	inc	dptr
      008BE5 F0               [24] 1533 	movx	@dptr,a
      008BE6 90 0B 62         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008BE9 F0               [24] 1535 	movx	@dptr,a
      008BEA A3               [24] 1536 	inc	dptr
      008BEB F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008BEC FF               [12] 1539 	mov	r7,a
      008BED                       1540 00119$:
      008BED BF 08 00         [24] 1541 	cjne	r7,#0x08,00206$
      008BF0                       1542 00206$:
      008BF0 50 19            [24] 1543 	jnc	00105$
                                   1544 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008BF2 8F 06            [24] 1545 	mov	ar6,r7
      008BF4 90 0B 4B         [24] 1546 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008BF7 74 5A            [12] 1547 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      008BF9 F0               [24] 1548 	movx	@dptr,a
      008BFA 74 0B            [12] 1549 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      008BFC 12 38 70         [24] 1550 	lcall	_ak820_outline_0095
      008BFF 8E 82            [24] 1551 	mov	dpl, r6
      008C01 C0 07            [24] 1552 	push	ar7
      008C03 12 8A 69         [24] 1553 	lcall	_dynamic_keymap_set_combo
      008C06 D0 07            [24] 1554 	pop	ar7
                                   1555 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008C08 0F               [12] 1556 	inc	r7
      008C09 80 E2            [24] 1557 	sjmp	00119$
      008C0B                       1558 00105$:
                                   1559 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008C0B 90 0B 59         [24] 1560 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008C0E E0               [24] 1561 	movx	a,@dptr
      008C0F 90 0E 7A         [24] 1562 	mov	dptr,#_vial_unlocked
      008C12 F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/dynamic_keymap.c:405: }
      008C13 22               [24] 1565 	ret
                                   1566 ;------------------------------------------------------------
                                   1567 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1568 ;------------------------------------------------------------
                                   1569 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1570 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1571 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1572 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1573 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1574 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1575 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1576 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1577 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1578 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function ak820_dynamic_read_buffer
                                   1583 ;	-----------------------------------------
      008C14                       1584 _ak820_dynamic_read_buffer:
      008C14 12 38 82         [24] 1585 	lcall	_ak820_outline_0110
      008C17 90 0B 6D         [24] 1586 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008C1A 12 38 87         [24] 1587 	lcall	_ak820_outline_0111
                                   1588 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008C1D 90 0B 6A         [24] 1589 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008C20 12 38 41         [24] 1590 	lcall	_ak820_outline_0053
                                   1591 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008C23 90 0B 6F         [24] 1592 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008C26 E4               [12] 1593 	clr	a
      008C27 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008C28 90 0B 68         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008C2B 12 38 58         [24] 1597 	lcall	_ak820_outline_0061
      008C2E 8C 02            [24] 1598 	mov	ar2,r4
      008C30 8D 03            [24] 1599 	mov	ar3,r5
      008C32 C3               [12] 1600 	clr	c
      008C33 74 1C            [12] 1601 	mov	a,#0x1c
      008C35 9A               [12] 1602 	subb	a,r2
      008C36 E4               [12] 1603 	clr	a
      008C37 9B               [12] 1604 	subb	a,r3
      008C38 50 01            [24] 1605 	jnc	00102$
                                   1606 ;	free result
      008C3A 22               [24] 1607 	ret
      008C3B                       1608 00102$:
                                   1609 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008C3B 90 0B 66         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008C3E 12 46 97         [24] 1611 	lcall	_ak820_outline_0106
      008C41 90 0B 64         [24] 1612 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008C44 12 38 7C         [24] 1613 	lcall	_ak820_outline_0105
      008C47 C3               [12] 1614 	clr	c
      008C48 EA               [12] 1615 	mov	a,r2
      008C49 98               [12] 1616 	subb	a,r0
      008C4A EB               [12] 1617 	mov	a,r3
      008C4B 99               [12] 1618 	subb	a,r1
      008C4C 50 17            [24] 1619 	jnc	00104$
                                   1620 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008C4E E8               [12] 1621 	mov	a,r0
      008C4F C3               [12] 1622 	clr	c
      008C50 9A               [12] 1623 	subb	a,r2
      008C51 F8               [12] 1624 	mov	r0,a
      008C52 E9               [12] 1625 	mov	a,r1
      008C53 9B               [12] 1626 	subb	a,r3
      008C54 F9               [12] 1627 	mov	r1,a
                                   1628 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008C55 C3               [12] 1629 	clr	c
      008C56 E8               [12] 1630 	mov	a,r0
      008C57 9C               [12] 1631 	subb	a,r4
      008C58 E9               [12] 1632 	mov	a,r1
      008C59 9D               [12] 1633 	subb	a,r5
      008C5A 40 04            [24] 1634 	jc	00114$
      008C5C 8C 00            [24] 1635 	mov	ar0,r4
      008C5E 8D 01            [24] 1636 	mov	ar1,r5
      008C60                       1637 00114$:
      008C60 90 0B 6F         [24] 1638 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008C63 E8               [12] 1639 	mov	a,r0
      008C64 F0               [24] 1640 	movx	@dptr,a
      008C65                       1641 00104$:
                                   1642 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008C65 90 0B 6F         [24] 1643 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008C68 E0               [24] 1644 	movx	a,@dptr
      008C69 F5 2D            [12] 1645 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008C6B E0               [24] 1646 	movx	a,@dptr
      008C6C 60 42            [24] 1647 	jz	00106$
      008C6E C0 04            [24] 1648 	push	ar4
      008C70 C0 05            [24] 1649 	push	ar5
      008C72 8E 00            [24] 1650 	mov	ar0,r6
      008C74 8F 05            [24] 1651 	mov	ar5,r7
      008C76 90 0B 6D         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008C79 E0               [24] 1653 	movx	a,@dptr
      008C7A F9               [12] 1654 	mov	r1,a
      008C7B A3               [24] 1655 	inc	dptr
      008C7C E0               [24] 1656 	movx	a,@dptr
      008C7D FC               [12] 1657 	mov	r4,a
      008C7E EA               [12] 1658 	mov	a,r2
      008C7F 29               [12] 1659 	add	a, r1
      008C80 FA               [12] 1660 	mov	r2,a
      008C81 EB               [12] 1661 	mov	a,r3
      008C82 3C               [12] 1662 	addc	a, r4
      008C83 FB               [12] 1663 	mov	r3,a
      008C84 90 05 DB         [24] 1664 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008C87 EA               [12] 1665 	mov	a,r2
      008C88 F0               [24] 1666 	movx	@dptr,a
      008C89 EB               [12] 1667 	mov	a,r3
      008C8A 12 38 70         [24] 1668 	lcall	_ak820_outline_0095
      008C8D 90 05 DE         [24] 1669 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008C90 E5 2D            [12] 1670 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008C92 12 38 9C         [24] 1671 	lcall	_ak820_outline_0136
      008C95 88 82            [24] 1672 	mov	dpl, r0
      008C97 8D 83            [24] 1673 	mov	dph, r5
      008C99 C0 07            [24] 1674 	push	ar7
      008C9B C0 06            [24] 1675 	push	ar6
      008C9D C0 05            [24] 1676 	push	ar5
      008C9F C0 04            [24] 1677 	push	ar4
      008CA1 12 43 FC         [24] 1678 	lcall	_ak820_eeprom_read_block_xdata
      008CA4 D0 04            [24] 1679 	pop	ar4
      008CA6 D0 05            [24] 1680 	pop	ar5
      008CA8 D0 06            [24] 1681 	pop	ar6
      008CAA D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CAC D0 05            [24] 1684 	pop	ar5
      008CAE D0 04            [24] 1685 	pop	ar4
                                   1686 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008CB0                       1687 00106$:
                                   1688 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008CB0 90 0B 6F         [24] 1689 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008CB3 E0               [24] 1690 	movx	a,@dptr
      008CB4 FB               [12] 1691 	mov	r3,a
      008CB5                       1692 00109$:
      008CB5 8B 01            [24] 1693 	mov	ar1,r3
      008CB7 7A 00            [12] 1694 	mov	r2,#0x00
      008CB9 C3               [12] 1695 	clr	c
      008CBA E9               [12] 1696 	mov	a,r1
      008CBB 9C               [12] 1697 	subb	a,r4
      008CBC EA               [12] 1698 	mov	a,r2
      008CBD 9D               [12] 1699 	subb	a,r5
      008CBE 50 09            [24] 1700 	jnc	00111$
      008CC0 EB               [12] 1701 	mov	a,r3
      008CC1 12 38 31         [24] 1702 	lcall	_ak820_outline_0022
      008CC4 E4               [12] 1703 	clr	a
      008CC5 F0               [24] 1704 	movx	@dptr,a
      008CC6 0B               [12] 1705 	inc	r3
      008CC7 80 EC            [24] 1706 	sjmp	00109$
      008CC9                       1707 00111$:
                                   1708 ;	quantum/dynamic_keymap.c:420: }
      008CC9 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1712 ;------------------------------------------------------------
                                   1713 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1714 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1715 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function dynamic_keymap_get_buffer
                                   1720 ;	-----------------------------------------
      008CCA                       1721 _dynamic_keymap_get_buffer:
      008CCA 12 38 82         [24] 1722 	lcall	_ak820_outline_0110
      008CCD 90 0B 75         [24] 1723 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008CD0 12 38 87         [24] 1724 	lcall	_ak820_outline_0111
                                   1725 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008CD3 90 0B 75         [24] 1726 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008CD6 12 38 41         [24] 1727 	lcall	_ak820_outline_0053
      008CD9 90 0B 70         [24] 1728 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008CDC 12 38 58         [24] 1729 	lcall	_ak820_outline_0061
      008CDF 90 0B 72         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008CE2 12 52 80         [24] 1731 	lcall	_ak820_outline_0093
      008CE5 90 0B 64         [24] 1732 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CE8 E4               [12] 1733 	clr	a
      008CE9 F0               [24] 1734 	movx	@dptr,a
      008CEA 74 06            [12] 1735 	mov	a,#0x06
      008CEC A3               [24] 1736 	inc	dptr
      008CED F0               [24] 1737 	movx	@dptr,a
      008CEE 90 0B 66         [24] 1738 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CF1 12 4B D2         [24] 1739 	lcall	_ak820_outline_0060
      008CF4 90 0B 68         [24] 1740 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008CF7 12 38 5E         [24] 1741 	lcall	_ak820_outline_0072
      008CFA 90 0B 6A         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008CFD E9               [12] 1743 	mov	a,r1
      008CFE 12 52 99         [24] 1744 	lcall	_ak820_outline_0158
      008D01 F0               [24] 1745 	movx	@dptr,a
      008D02 90 00 40         [24] 1746 	mov	dptr,#0x0040
                                   1747 ;	quantum/dynamic_keymap.c:448: }
      008D05 02 8C 14         [24] 1748 	ljmp	_ak820_dynamic_read_buffer
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1751 ;------------------------------------------------------------
                                   1752 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1753 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1754 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1755 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1756 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1757 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1758 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1759 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1760 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1761 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1762 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1763 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1764 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1766 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1767 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function dynamic_keymap_set_buffer
                                   1772 ;	-----------------------------------------
      008D08                       1773 _dynamic_keymap_set_buffer:
      008D08 12 38 82         [24] 1774 	lcall	_ak820_outline_0110
      008D0B 90 0B 7C         [24] 1775 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008D0E 12 38 87         [24] 1776 	lcall	_ak820_outline_0111
                                   1777 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008D11 90 0B 7C         [24] 1778 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008D14 12 4B 75         [24] 1779 	lcall	_ak820_outline_0009
      008D17 74 40            [12] 1780 	mov	a,#0x40
      008D19 2C               [12] 1781 	add	a, r4
      008D1A FA               [12] 1782 	mov	r2,a
      008D1B E4               [12] 1783 	clr	a
      008D1C 3D               [12] 1784 	addc	a, r5
      008D1D FB               [12] 1785 	mov	r3,a
                                   1786 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D1E 90 0B 79         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008D21 12 38 7C         [24] 1788 	lcall	_ak820_outline_0105
                                   1789 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008D24 90 0B 77         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008D27 E0               [24] 1791 	movx	a,@dptr
      008D28 F5 2E            [12] 1792 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008D2A A3               [24] 1793 	inc	dptr
      008D2B E0               [24] 1794 	movx	a,@dptr
      008D2C F5 2F            [12] 1795 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008D2E E5 2E            [12] 1796 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D30 45 2F            [12] 1797 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D32 70 01            [24] 1798 	jnz	00102$
      008D34 22               [24] 1799 	ret
      008D35                       1800 00102$:
                                   1801 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008D35 85 2E 30         [24] 1802 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008D38 85 2F 31         [24] 1803 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D3B C3               [12] 1804 	clr	c
      008D3C 74 1C            [12] 1805 	mov	a,#0x1c
      008D3E 95 30            [12] 1806 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008D40 E4               [12] 1807 	clr	a
      008D41 95 31            [12] 1808 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008D43 50 01            [24] 1809 	jnc	00104$
                                   1810 ;	free result
      008D45 22               [24] 1811 	ret
      008D46                       1812 00104$:
                                   1813 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008D46 85 2E 32         [24] 1814 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1815 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008D49 74 FA            [12] 1816 	mov	a,#0x100 - 0x06
      008D4B 2F               [12] 1817 	add	a,r7
      008D4C 40 11            [24] 1818 	jc	00105$
      008D4E E4               [12] 1819 	clr	a
      008D4F C3               [12] 1820 	clr	c
      008D50 9E               [12] 1821 	subb	a,r6
      008D51 FE               [12] 1822 	mov	r6,a
      008D52 74 06            [12] 1823 	mov	a,#0x06
      008D54 9F               [12] 1824 	subb	a,r7
      008D55 FF               [12] 1825 	mov	r7,a
      008D56 C3               [12] 1826 	clr	c
      008D57 EE               [12] 1827 	mov	a,r6
      008D58 95 2E            [12] 1828 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008D5A EF               [12] 1829 	mov	a,r7
      008D5B 95 2F            [12] 1830 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D5D 50 01            [24] 1831 	jnc	00106$
      008D5F                       1832 00105$:
                                   1833 ;	quantum/dynamic_keymap.c:466: return;
      008D5F 22               [24] 1834 	ret
      008D60                       1835 00106$:
                                   1836 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008D60 90 0E 7A         [24] 1837 	mov	dptr,#_vial_unlocked
      008D63 E0               [24] 1838 	movx	a,@dptr
      008D64 60 03            [24] 1839 	jz	00207$
      008D66 02 8E 73         [24] 1840 	ljmp	00120$
      008D69                       1841 00207$:
                                   1842 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008D69 90 0B 7E         [24] 1843 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008D6C E4               [12] 1844 	clr	a
      008D6D F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008D6E 90 0B 7F         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008D71 E5 32            [12] 1848 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D73 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008D74 EC               [12] 1851 	mov	a,r4
      008D75 30 E0 31         [24] 1852 	jnb	acc.0,00111$
                                   1853 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008D78 EA               [12] 1854 	mov	a,r2
      008D79 24 FF            [12] 1855 	add	a,#0xff
      008D7B FE               [12] 1856 	mov	r6,a
      008D7C EB               [12] 1857 	mov	a,r3
      008D7D 34 FF            [12] 1858 	addc	a,#0xff
      008D7F FF               [12] 1859 	mov	r7,a
      008D80 7D 00            [12] 1860 	mov	r5,#0x00
      008D82 12 73 26         [24] 1861 	lcall	_ak820_outline_0051
      008D85 12 43 C1         [24] 1862 	lcall	_eeprom_read_byte
      008D88 AE 82            [24] 1863 	mov	r6,dpl
      008D8A 7F 00            [12] 1864 	mov	r7,#0x00
      008D8C 12 38 B1         [24] 1865 	lcall	_ak820_outline_0146
      008D8F E0               [24] 1866 	movx	a,@dptr
      008D90 7C 00            [12] 1867 	mov	r4,#0x00
      008D92 42 07            [12] 1868 	orl	ar7,a
      008D94 EC               [12] 1869 	mov	a,r4
      008D95 42 06            [12] 1870 	orl	ar6,a
                                   1871 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008D97 BF 00 09         [24] 1872 	cjne	r7,#0x00,00109$
      008D9A BE 7C 06         [24] 1873 	cjne	r6,#0x7c,00109$
                                   1874 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008D9D 12 38 B1         [24] 1875 	lcall	_ak820_outline_0146
      008DA0 74 FF            [12] 1876 	mov	a,#0xff
      008DA2 F0               [24] 1877 	movx	@dptr,a
      008DA3                       1878 00109$:
                                   1879 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008DA3 90 0B 7E         [24] 1880 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008DA6 74 01            [12] 1881 	mov	a,#0x01
      008DA8 F0               [24] 1882 	movx	@dptr,a
      008DA9                       1883 00111$:
                                   1884 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008DA9 90 0B 7C         [24] 1885 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008DAC 12 38 41         [24] 1886 	lcall	_ak820_outline_0053
      008DAF E5 2E            [12] 1887 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008DB1 2E               [12] 1888 	add	a, r6
      008DB2 FE               [12] 1889 	mov	r6,a
      008DB3 E5 2F            [12] 1890 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008DB5 3F               [12] 1891 	addc	a, r7
      008DB6 EE               [12] 1892 	mov	a,r6
      008DB7 30 E0 5A         [24] 1893 	jnb	acc.0,00115$
                                   1894 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008DBA AE 32            [24] 1895 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008DBC 7F 00            [12] 1896 	mov	r7,#0x00
      008DBE EE               [12] 1897 	mov	a,r6
      008DBF 24 FF            [12] 1898 	add	a,#0xff
      008DC1 FC               [12] 1899 	mov	r4,a
      008DC2 EF               [12] 1900 	mov	a,r7
      008DC3 34 FF            [12] 1901 	addc	a,#0xff
      008DC5 FD               [12] 1902 	mov	r5,a
      008DC6 EC               [12] 1903 	mov	a,r4
      008DC7 28               [12] 1904 	add	a, r0
      008DC8 F5 82            [12] 1905 	mov	dpl,a
      008DCA ED               [12] 1906 	mov	a,r5
      008DCB 39               [12] 1907 	addc	a, r1
      008DCC F5 83            [12] 1908 	mov	dph,a
      008DCE E0               [24] 1909 	movx	a,@dptr
      008DCF FC               [12] 1910 	mov	r4,a
      008DD0 7D 00            [12] 1911 	mov	r5,#0x00
      008DD2 E5 32            [12] 1912 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008DD4 2A               [12] 1913 	add	a, r2
      008DD5 FA               [12] 1914 	mov	r2,a
      008DD6 E4               [12] 1915 	clr	a
      008DD7 3B               [12] 1916 	addc	a, r3
      008DD8 FB               [12] 1917 	mov	r3,a
      008DD9 C0 00            [24] 1918 	push	ar0
      008DDB C0 01            [24] 1919 	push	ar1
      008DDD 8B 01            [24] 1920 	mov	ar1,r3
      008DDF 7B 00            [12] 1921 	mov	r3,#0x00
      008DE1 8A 82            [24] 1922 	mov	dpl, r2
      008DE3 89 83            [24] 1923 	mov	dph, r1
      008DE5 8B F0            [24] 1924 	mov	b, r3
      008DE7 12 43 C1         [24] 1925 	lcall	_eeprom_read_byte
      008DEA AB 82            [24] 1926 	mov	r3, dpl
      008DEC 7A 00            [12] 1927 	mov	r2,#0x00
      008DEE EB               [12] 1928 	mov	a,r3
      008DEF 12 46 B4         [24] 1929 	lcall	_ak820_outline_0144
                                   1930 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008DF2 BD 00 05         [24] 1931 	cjne	r5,#0x00,00212$
      008DF5 BC 7C 02         [24] 1932 	cjne	r4,#0x7c,00212$
      008DF8 80 06            [24] 1933 	sjmp	00213$
      008DFA                       1934 00212$:
      008DFA D0 01            [24] 1935 	pop	ar1
      008DFC D0 00            [24] 1936 	pop	ar0
      008DFE 80 0D            [24] 1937 	sjmp	00113$
      008E00                       1938 00213$:
      008E00 D0 01            [24] 1939 	pop	ar1
      008E02 D0 00            [24] 1940 	pop	ar0
                                   1941 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008E04 1E               [12] 1942 	dec	r6
      008E05 BE FF 01         [24] 1943 	cjne	r6,#0xff,00214$
      008E08 1F               [12] 1944 	dec	r7
      008E09                       1945 00214$:
      008E09 EE               [12] 1946 	mov	a,r6
      008E0A 12 92 AC         [24] 1947 	lcall	_ak820_outline_0131
      008E0D                       1948 00113$:
                                   1949 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008E0D E5 32            [12] 1950 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E0F 14               [12] 1951 	dec	a
      008E10 90 0B 7F         [24] 1952 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008E13 F0               [24] 1953 	movx	@dptr,a
      008E14                       1954 00115$:
                                   1955 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E14 90 0B 7E         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008E17 E0               [24] 1957 	movx	a,@dptr
      008E18 90 0B 80         [24] 1958 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008E1B F0               [24] 1959 	movx	@dptr,a
      008E1C                       1960 00122$:
      008E1C 90 0B 80         [24] 1961 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008E1F E0               [24] 1962 	movx	a,@dptr
      008E20 FF               [12] 1963 	mov	r7,a
      008E21 90 0B 7F         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008E24 E0               [24] 1965 	movx	a,@dptr
      008E25 FE               [12] 1966 	mov	r6,a
      008E26 C3               [12] 1967 	clr	c
      008E27 EF               [12] 1968 	mov	a,r7
      008E28 9E               [12] 1969 	subb	a,r6
      008E29 50 48            [24] 1970 	jnc	00120$
                                   1971 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008E2B EF               [12] 1972 	mov	a,r7
      008E2C 28               [12] 1973 	add	a, r0
      008E2D FD               [12] 1974 	mov	r5,a
      008E2E E4               [12] 1975 	clr	a
      008E2F 39               [12] 1976 	addc	a, r1
      008E30 FE               [12] 1977 	mov	r6,a
      008E31 12 4B DF         [24] 1978 	lcall	_ak820_outline_0078
      008E34 7B 00            [12] 1979 	mov	r3,#0x00
      008E36 8C 2F            [24] 1980 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008E38 8B 2E            [24] 1981 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008E3A 8F 02            [24] 1982 	mov	ar2,r7
      008E3C 7F 00            [12] 1983 	mov	r7,#0x00
      008E3E 74 01            [12] 1984 	mov	a,#0x01
      008E40 2A               [12] 1985 	add	a, r2
      008E41 FB               [12] 1986 	mov	r3,a
      008E42 E4               [12] 1987 	clr	a
      008E43 3F               [12] 1988 	addc	a, r7
      008E44 FC               [12] 1989 	mov	r4,a
      008E45 EB               [12] 1990 	mov	a,r3
      008E46 28               [12] 1991 	add	a, r0
      008E47 F5 82            [12] 1992 	mov	dpl,a
      008E49 EC               [12] 1993 	mov	a,r4
      008E4A 39               [12] 1994 	addc	a, r1
      008E4B F5 83            [12] 1995 	mov	dph,a
      008E4D E0               [24] 1996 	movx	a,@dptr
      008E4E FC               [12] 1997 	mov	r4,a
      008E4F 7B 00            [12] 1998 	mov	r3,#0x00
      008E51 E5 2F            [12] 1999 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E53 42 03            [12] 2000 	orl	ar3,a
                                   2001 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008E55 BC 00 12         [24] 2002 	cjne	r4,#0x00,00123$
      008E58 BB 7C 0F         [24] 2003 	cjne	r3,#0x7c,00123$
                                   2004 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008E5B 12 38 A1         [24] 2005 	lcall	_ak820_outline_0137
      008E5E 74 FF            [12] 2006 	mov	a,#0xff
      008E60 F0               [24] 2007 	movx	@dptr,a
                                   2008 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008E61 0A               [12] 2009 	inc	r2
      008E62 BA 00 01         [24] 2010 	cjne	r2,#0x00,00218$
      008E65 0F               [12] 2011 	inc	r7
      008E66                       2012 00218$:
      008E66 EA               [12] 2013 	mov	a,r2
      008E67 12 92 AC         [24] 2014 	lcall	_ak820_outline_0131
      008E6A                       2015 00123$:
                                   2016 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008E6A 90 0B 80         [24] 2017 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008E6D E0               [24] 2018 	movx	a,@dptr
      008E6E 24 02            [12] 2019 	add	a,#0x02
      008E70 F0               [24] 2020 	movx	@dptr,a
      008E71 80 A9            [24] 2021 	sjmp	00122$
      008E73                       2022 00120$:
                                   2023 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008E73 90 0B 7C         [24] 2024 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008E76 12 38 41         [24] 2025 	lcall	_ak820_outline_0053
      008E79 74 40            [12] 2026 	mov	a,#0x40
      008E7B 12 46 AE         [24] 2027 	lcall	_ak820_outline_0139
      008E7E 90 05 E4         [24] 2028 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008E81 12 4B D2         [24] 2029 	lcall	_ak820_outline_0060
      008E84 E4               [12] 2030 	clr	a
      008E85 A3               [24] 2031 	inc	dptr
      008E86 F0               [24] 2032 	movx	@dptr,a
      008E87 90 05 E7         [24] 2033 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008E8A E5 30            [12] 2034 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E8C F0               [24] 2035 	movx	@dptr,a
      008E8D E5 31            [12] 2036 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E8F A3               [24] 2037 	inc	dptr
      008E90 F0               [24] 2038 	movx	@dptr,a
      008E91 12 38 B1         [24] 2039 	lcall	_ak820_outline_0146
                                   2040 ;	quantum/dynamic_keymap.c:521: }
      008E94 02 44 88         [24] 2041 	ljmp	_ak820_eeprom_write_block_xdata
                                   2042 ;------------------------------------------------------------
                                   2043 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2044 ;------------------------------------------------------------
                                   2045 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2046 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2047 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function keycode_at_keymap_location
                                   2052 ;	-----------------------------------------
      008E97                       2053 _keycode_at_keymap_location:
      008E97 E5 82            [12] 2054 	mov	a,dpl
      008E99 90 0B 83         [24] 2055 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008E9C F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008E9D E0               [24] 2058 	movx	a,@dptr
      008E9E FF               [12] 2059 	mov	r7,a
      008E9F BF 06 00         [24] 2060 	cjne	r7,#0x06,00128$
      008EA2                       2061 00128$:
      008EA2 50 23            [24] 2062 	jnc	00102$
      008EA4 90 0B 81         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008EA7 E0               [24] 2064 	movx	a,@dptr
      008EA8 FE               [12] 2065 	mov	r6,a
      008EA9 BE 10 00         [24] 2066 	cjne	r6,#0x10,00130$
      008EAC                       2067 00130$:
      008EAC 50 19            [24] 2068 	jnc	00102$
      008EAE 90 0B 82         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008EB1 E0               [24] 2070 	movx	a,@dptr
      008EB2 FD               [12] 2071 	mov	r5,a
      008EB3 BD 08 00         [24] 2072 	cjne	r5,#0x08,00132$
      008EB6                       2073 00132$:
      008EB6 50 0F            [24] 2074 	jnc	00102$
                                   2075 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008EB8 90 0B 35         [24] 2076 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008EBB EE               [12] 2077 	mov	a,r6
      008EBC F0               [24] 2078 	movx	@dptr,a
      008EBD 90 0B 36         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008EC0 ED               [12] 2080 	mov	a,r5
      008EC1 F0               [24] 2081 	movx	@dptr,a
      008EC2 8F 82            [24] 2082 	mov	dpl, r7
      008EC4 02 88 38         [24] 2083 	ljmp	_dynamic_keymap_get_keycode
      008EC7                       2084 00102$:
                                   2085 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008EC7 90 00 00         [24] 2086 	mov	dptr,#0x0000
                                   2087 ;	quantum/dynamic_keymap.c:528: }
      008ECA 22               [24] 2088 	ret
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2091 ;------------------------------------------------------------
                                   2092 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2093 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2094 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2095 ;------------------------------------------------------------
                                   2096 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2097 ;	-----------------------------------------
                                   2098 ;	 function keycode_at_encodermap_location
                                   2099 ;	-----------------------------------------
      008ECB                       2100 _keycode_at_encodermap_location:
      008ECB E5 82            [12] 2101 	mov	a,dpl
      008ECD 90 0B 86         [24] 2102 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008ED0 F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008ED1 E0               [24] 2105 	movx	a,@dptr
      008ED2 FF               [12] 2106 	mov	r7,a
      008ED3 BF 06 00         [24] 2107 	cjne	r7,#0x06,00120$
      008ED6                       2108 00120$:
      008ED6 50 1E            [24] 2109 	jnc	00102$
      008ED8 90 0B 84         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008EDB E0               [24] 2111 	movx	a,@dptr
      008EDC FE               [12] 2112 	mov	r6,a
      008EDD BE 01 00         [24] 2113 	cjne	r6,#0x01,00122$
      008EE0                       2114 00122$:
      008EE0 50 14            [24] 2115 	jnc	00102$
                                   2116 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008EE2 90 0B 85         [24] 2117 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008EE5 E0               [24] 2118 	movx	a,@dptr
      008EE6 FE               [12] 2119 	mov	r6,a
      008EE7 90 0B 3F         [24] 2120 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008EEA E4               [12] 2121 	clr	a
      008EEB F0               [24] 2122 	movx	@dptr,a
      008EEC 90 0B 40         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008EEF EE               [12] 2124 	mov	a,r6
      008EF0 F0               [24] 2125 	movx	@dptr,a
      008EF1 8F 82            [24] 2126 	mov	dpl, r7
      008EF3 02 88 F7         [24] 2127 	ljmp	_dynamic_keymap_get_encoder
      008EF6                       2128 00102$:
                                   2129 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008EF6 90 00 00         [24] 2130 	mov	dptr,#0x0000
                                   2131 ;	quantum/dynamic_keymap.c:536: }
      008EF9 22               [24] 2132 	ret
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function dynamic_keymap_macro_get_count
                                   2139 ;	-----------------------------------------
      008EFA                       2140 _dynamic_keymap_macro_get_count:
                                   2141 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008EFA 75 82 10         [24] 2142 	mov	dpl, #0x10
                                   2143 ;	quantum/dynamic_keymap.c:541: }
      008EFD 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2151 ;	-----------------------------------------
      008EFE                       2152 _dynamic_keymap_macro_get_buffer_size:
                                   2153 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008EFE 90 20 00         [24] 2154 	mov	dptr,#0x2000
                                   2155 ;	quantum/dynamic_keymap.c:545: }
      008F01 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2159 ;------------------------------------------------------------
                                   2160 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2161 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2162 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2163 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer
                                   2168 ;	-----------------------------------------
      008F02                       2169 _dynamic_keymap_macro_get_buffer:
      008F02 12 38 82         [24] 2170 	lcall	_ak820_outline_0110
      008F05 90 0B 8C         [24] 2171 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008F08 12 38 87         [24] 2172 	lcall	_ak820_outline_0111
                                   2173 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008F0B 12 2B 2B         [24] 2174 	lcall	_ak820_macro_length
      008F0E 12 46 A9         [24] 2175 	lcall	_ak820_outline_0127
      008F11 90 0B 8C         [24] 2176 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008F14 12 38 58         [24] 2177 	lcall	_ak820_outline_0061
      008F17 90 0B 87         [24] 2178 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008F1A E0               [24] 2179 	movx	a,@dptr
      008F1B F5 33            [12] 2180 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008F1D A3               [24] 2181 	inc	dptr
      008F1E E0               [24] 2182 	movx	a,@dptr
      008F1F F5 34            [12] 2183 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008F21 90 0B 89         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008F24 12 38 7C         [24] 2185 	lcall	_ak820_outline_0105
      008F27 A3               [24] 2186 	inc	dptr
      008F28 E0               [24] 2187 	movx	a,@dptr
      008F29 FB               [12] 2188 	mov	r3,a
      008F2A 90 0B 64         [24] 2189 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F2D 12 4B D2         [24] 2190 	lcall	_ak820_outline_0060
      008F30 90 0B 66         [24] 2191 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F33 12 38 5E         [24] 2192 	lcall	_ak820_outline_0072
      008F36 90 0B 68         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008F39 E5 33            [12] 2194 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008F3B F0               [24] 2195 	movx	@dptr,a
      008F3C E5 34            [12] 2196 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008F3E A3               [24] 2197 	inc	dptr
      008F3F F0               [24] 2198 	movx	@dptr,a
      008F40 90 0B 6A         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008F43 E8               [12] 2200 	mov	a,r0
      008F44 F0               [24] 2201 	movx	@dptr,a
      008F45 E9               [12] 2202 	mov	a,r1
      008F46 A3               [24] 2203 	inc	dptr
      008F47 12 7B B9         [24] 2204 	lcall	_ak820_outline_0188
      008F4A 90 08 00         [24] 2205 	mov	dptr,#0x0800
                                   2206 ;	quantum/dynamic_keymap.c:572: }
      008F4D 02 8C 14         [24] 2207 	ljmp	_ak820_dynamic_read_buffer
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2210 ;------------------------------------------------------------
                                   2211 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2212 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2213 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2214 ;------------------------------------------------------------
                                   2215 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2216 ;	-----------------------------------------
                                   2217 ;	 function dynamic_keymap_macro_set_buffer
                                   2218 ;	-----------------------------------------
      008F50                       2219 _dynamic_keymap_macro_set_buffer:
      008F50 12 38 82         [24] 2220 	lcall	_ak820_outline_0110
      008F53 90 0B 93         [24] 2221 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008F56 12 38 87         [24] 2222 	lcall	_ak820_outline_0111
                                   2223 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008F59 90 0B 93         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008F5C 12 38 41         [24] 2225 	lcall	_ak820_outline_0053
      008F5F 90 0B 8E         [24] 2226 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008F62 12 38 58         [24] 2227 	lcall	_ak820_outline_0061
      008F65 90 0B 90         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008F68 12 52 80         [24] 2229 	lcall	_ak820_outline_0093
      008F6B 90 05 6A         [24] 2230 	mov	dptr,#_ak820_macro_write_PARM_2
      008F6E 12 38 5E         [24] 2231 	lcall	_ak820_outline_0072
      008F71 90 05 6C         [24] 2232 	mov	dptr,#_ak820_macro_write_PARM_3
      008F74 E9               [12] 2233 	mov	a,r1
      008F75 12 52 99         [24] 2234 	lcall	_ak820_outline_0158
      008F78 12 46 8B         [24] 2235 	lcall	_ak820_outline_0076
                                   2236 ;	quantum/dynamic_keymap.c:577: }
      008F7B 02 2B 45         [24] 2237 	ljmp	_ak820_macro_write
                                   2238 ;------------------------------------------------------------
                                   2239 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2240 ;------------------------------------------------------------
                                   2241 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2242 ;	-----------------------------------------
                                   2243 ;	 function dynamic_keymap_macro_reset
                                   2244 ;	-----------------------------------------
      008F7E                       2245 _dynamic_keymap_macro_reset:
                                   2246 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2247 ;	quantum/dynamic_keymap.c:603: }
      008F7E 02 2E 64         [24] 2248 	ljmp	_ak820_macro_reset
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'decode_keycode'
                                   2251 ;------------------------------------------------------------
                                   2252 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function decode_keycode
                                   2257 ;	-----------------------------------------
      008F81                       2258 _decode_keycode:
      008F81 12 38 82         [24] 2259 	lcall	_ak820_outline_0110
      008F84 90 0B 95         [24] 2260 	mov	dptr,#_decode_keycode_kc_10000_454
      008F87 12 38 87         [24] 2261 	lcall	_ak820_outline_0111
                                   2262 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008F8A 90 0B 95         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_454
      008F8D 12 4B 75         [24] 2264 	lcall	_ak820_outline_0009
      008F90 C3               [12] 2265 	clr	c
      008F91 E4               [12] 2266 	clr	a
      008F92 9C               [12] 2267 	subb	a,r4
      008F93 74 FF            [12] 2268 	mov	a,#0xff
      008F95 9D               [12] 2269 	subb	a,r5
      008F96 50 08            [24] 2270 	jnc	00102$
                                   2271 ;	free result
                                   2272 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008F98 8C 05            [24] 2273 	mov	ar5,r4
      008F9A 7C 00            [12] 2274 	mov	r4,#0x00
      008F9C 12 38 97         [24] 2275 	lcall	_ak820_outline_0126
      008F9F 22               [24] 2276 	ret
      008FA0                       2277 00102$:
                                   2278 ;	quantum/dynamic_keymap.c:609: return kc;
      008FA0 12 38 8C         [24] 2279 	lcall	_ak820_outline_0120
                                   2280 ;	quantum/dynamic_keymap.c:610: }
      008FA3 22               [24] 2281 	ret
                                   2282 ;------------------------------------------------------------
                                   2283 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2284 ;------------------------------------------------------------
                                   2285 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2286 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2287 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2288 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2289 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2290 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2291 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2292 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2293 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2294 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2295 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2296 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function dynamic_keymap_macro_send
                                   2301 ;	-----------------------------------------
      008FA4                       2302 _dynamic_keymap_macro_send:
      008FA4 E5 82            [12] 2303 	mov	a,dpl
      008FA6 90 0B 97         [24] 2304 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008FA9 F0               [24] 2305 	movx	@dptr,a
                                   2306 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008FAA 90 0B 98         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008FAD E0               [24] 2308 	movx	a,@dptr
      008FAE 60 01            [24] 2309 	jz	00102$
      008FB0 22               [24] 2310 	ret
      008FB1                       2311 00102$:
                                   2312 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008FB1 90 0B 97         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008FB4 E0               [24] 2314 	movx	a,@dptr
      008FB5 FF               [12] 2315 	mov	r7,a
      008FB6 BF 10 00         [24] 2316 	cjne	r7,#0x10,00422$
      008FB9                       2317 00422$:
      008FB9 40 01            [24] 2318 	jc	00104$
                                   2319 ;	quantum/dynamic_keymap.c:620: return;
      008FBB 22               [24] 2320 	ret
      008FBC                       2321 00104$:
                                   2322 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008FBC C0 07            [24] 2323 	push	ar7
      008FBE 12 2A F2         [24] 2324 	lcall	_ak820_macro_ready
      008FC1 E5 82            [12] 2325 	mov	a, dpl
      008FC3 D0 07            [24] 2326 	pop	ar7
      008FC5 70 01            [24] 2327 	jnz	00106$
      008FC7 22               [24] 2328 	ret
      008FC8                       2329 00106$:
                                   2330 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008FC8 90 0B 99         [24] 2331 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008FCB E4               [12] 2332 	clr	a
      008FCC F0               [24] 2333 	movx	@dptr,a
      008FCD 74 08            [12] 2334 	mov	a,#0x08
      008FCF A3               [24] 2335 	inc	dptr
      008FD0 F0               [24] 2336 	movx	@dptr,a
                                   2337 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008FD1 C0 07            [24] 2338 	push	ar7
      008FD3 12 2B 2B         [24] 2339 	lcall	_ak820_macro_length
      008FD6 AD 82            [24] 2340 	mov	r5, dpl
      008FD8 AE 83            [24] 2341 	mov	r6, dph
      008FDA D0 07            [24] 2342 	pop	ar7
      008FDC 74 08            [12] 2343 	mov	a,#0x08
      008FDE 2E               [12] 2344 	add	a, r6
      008FDF FE               [12] 2345 	mov	r6,a
                                   2346 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008FE0 7B 00            [12] 2347 	mov	r3,#0x00
      008FE2 7C 08            [12] 2348 	mov	r4,#0x08
      008FE4                       2349 00111$:
      008FE4 EF               [12] 2350 	mov	a,r7
      008FE5 60 31            [24] 2351 	jz	00113$
                                   2352 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008FE7 EB               [12] 2353 	mov	a,r3
      008FE8 B5 05 05         [24] 2354 	cjne	a,ar5,00108$
      008FEB EC               [12] 2355 	mov	a,r4
      008FEC B5 06 01         [24] 2356 	cjne	a,ar6,00108$
                                   2357 ;	quantum/dynamic_keymap.c:654: return;
      008FEF 22               [24] 2358 	ret
      008FF0                       2359 00108$:
                                   2360 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008FF0 8B 01            [24] 2361 	mov	ar1,r3
      008FF2 8C 02            [24] 2362 	mov	ar2,r4
      008FF4 8A 00            [24] 2363 	mov	ar0,r2
      008FF6 7A 00            [12] 2364 	mov	r2,#0x00
      008FF8 89 82            [24] 2365 	mov	dpl, r1
      008FFA 88 83            [24] 2366 	mov	dph, r0
      008FFC 8A F0            [24] 2367 	mov	b, r2
      008FFE 12 43 C1         [24] 2368 	lcall	_eeprom_read_byte
      009001 E5 82            [12] 2369 	mov	a, dpl
      009003 70 06            [24] 2370 	jnz	00110$
                                   2371 ;	quantum/dynamic_keymap.c:657: --id;
      009005 1F               [12] 2372 	dec	r7
      009006 90 0B 97         [24] 2373 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      009009 EF               [12] 2374 	mov	a,r7
      00900A F0               [24] 2375 	movx	@dptr,a
      00900B                       2376 00110$:
                                   2377 ;	quantum/dynamic_keymap.c:659: ++p;
      00900B 0B               [12] 2378 	inc	r3
      00900C BB 00 01         [24] 2379 	cjne	r3,#0x00,00429$
      00900F 0C               [12] 2380 	inc	r4
      009010                       2381 00429$:
      009010 90 0B 99         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009013 12 38 6A         [24] 2383 	lcall	_ak820_outline_0087
      009016 80 CC            [24] 2384 	sjmp	00111$
      009018                       2385 00113$:
                                   2386 ;	quantum/dynamic_keymap.c:665: sending = true;
      009018 90 0B 98         [24] 2387 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      00901B 74 01            [12] 2388 	mov	a,#0x01
      00901D F0               [24] 2389 	movx	@dptr,a
                                   2390 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      00901E 12 92 C4         [24] 2391 	lcall	_ak820_outline_0167
      009021 90 09 E1         [24] 2392 	mov	dptr,#_ak820_macro_cancelled
      009024 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      009025 90 0B 9B         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009028 F0               [24] 2396 	movx	@dptr,a
      009029 90 0B 9C         [24] 2397 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00902C F0               [24] 2398 	movx	@dptr,a
      00902D 90 0B 9D         [24] 2399 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      009030 F0               [24] 2400 	movx	@dptr,a
      009031 90 0B 9E         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      009034 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:675: while (p < end
      009035                       2404 00167$:
                                   2405 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      009035 90 0B 99         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009038 E0               [24] 2407 	movx	a,@dptr
      009039 FC               [12] 2408 	mov	r4,a
      00903A A3               [24] 2409 	inc	dptr
      00903B E0               [24] 2410 	movx	a,@dptr
      00903C FF               [12] 2411 	mov	r7,a
      00903D C3               [12] 2412 	clr	c
      00903E EC               [12] 2413 	mov	a,r4
      00903F 9D               [12] 2414 	subb	a,r5
      009040 EF               [12] 2415 	mov	a,r7
      009041 9E               [12] 2416 	subb	a,r6
      009042 40 03            [24] 2417 	jc	00430$
      009044 02 92 59         [24] 2418 	ljmp	00169$
      009047                       2419 00430$:
      009047 90 09 E1         [24] 2420 	mov	dptr,#_ak820_macro_cancelled
      00904A E0               [24] 2421 	movx	a,@dptr
      00904B 60 03            [24] 2422 	jz	00431$
      00904D 02 92 59         [24] 2423 	ljmp	00169$
      009050                       2424 00431$:
                                   2425 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009050 8C 02            [24] 2426 	mov	ar2,r4
      009052 8F 03            [24] 2427 	mov	ar3,r7
      009054 90 0B 99         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009057 74 01            [12] 2429 	mov	a,#0x01
      009059 2C               [12] 2430 	add	a, r4
      00905A F0               [24] 2431 	movx	@dptr,a
      00905B E4               [12] 2432 	clr	a
      00905C 3F               [12] 2433 	addc	a, r7
      00905D A3               [24] 2434 	inc	dptr
      00905E F0               [24] 2435 	movx	@dptr,a
      00905F 7F 00            [12] 2436 	mov	r7,#0x00
      009061 12 38 AC         [24] 2437 	lcall	_ak820_outline_0145
      009064 8F F0            [24] 2438 	mov	b, r7
      009066 12 43 C1         [24] 2439 	lcall	_eeprom_read_byte
      009069 AF 82            [24] 2440 	mov	r7, dpl
      00906B 90 0B 9B         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00906E EF               [12] 2442 	mov	a,r7
      00906F F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      009070 90 0B 9C         [24] 2445 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      009073 E4               [12] 2446 	clr	a
      009074 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      009075 90 0B 9B         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009078 E0               [24] 2450 	movx	a,@dptr
      009079 70 03            [24] 2451 	jnz	00432$
      00907B 02 92 59         [24] 2452 	ljmp	00169$
      00907E                       2453 00432$:
                                   2454 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      00907E 90 0B 9B         [24] 2455 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009081 E0               [24] 2456 	movx	a,@dptr
      009082 FF               [12] 2457 	mov	r7,a
      009083 BF 01 02         [24] 2458 	cjne	r7,#0x01,00433$
      009086 80 03            [24] 2459 	sjmp	00434$
      009088                       2460 00433$:
      009088 02 92 3B         [24] 2461 	ljmp	00164$
      00908B                       2462 00434$:
                                   2463 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00908B 12 92 61         [24] 2464 	lcall	_ak820_outline_0000
      00908E 12 43 C1         [24] 2465 	lcall	_eeprom_read_byte
      009091 AF 82            [24] 2466 	mov	r7, dpl
      009093 90 0B 9C         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      009096 EF               [12] 2468 	mov	a,r7
      009097 F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      009098 EF               [12] 2471 	mov	a,r7
      009099 70 03            [24] 2472 	jnz	00435$
      00909B 02 92 59         [24] 2473 	ljmp	00169$
      00909E                       2474 00435$:
                                   2475 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      00909E 12 92 8B         [24] 2476 	lcall	_ak820_outline_0096
      0090A1 BF 01 02         [24] 2477 	cjne	r7,#0x01,00436$
      0090A4 80 13            [24] 2478 	sjmp	00151$
      0090A6                       2479 00436$:
      0090A6 12 92 8B         [24] 2480 	lcall	_ak820_outline_0096
      0090A9 BF 02 02         [24] 2481 	cjne	r7,#0x02,00437$
      0090AC 80 0B            [24] 2482 	sjmp	00151$
      0090AE                       2483 00437$:
      0090AE 12 92 8B         [24] 2484 	lcall	_ak820_outline_0096
      0090B1 BF 03 02         [24] 2485 	cjne	r7,#0x03,00438$
      0090B4 80 03            [24] 2486 	sjmp	00439$
      0090B6                       2487 00438$:
      0090B6 02 91 1A         [24] 2488 	ljmp	00152$
      0090B9                       2489 00439$:
      0090B9                       2490 00151$:
                                   2491 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090B9 12 92 61         [24] 2492 	lcall	_ak820_outline_0000
      0090BC 12 43 C1         [24] 2493 	lcall	_eeprom_read_byte
      0090BF 12 92 DC         [24] 2494 	lcall	_ak820_outline_0182
                                   2495 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      0090C2 70 03            [24] 2496 	jnz	00440$
      0090C4 02 90 35         [24] 2497 	ljmp	00167$
      0090C7                       2498 00440$:
                                   2499 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0090C7 12 92 8B         [24] 2500 	lcall	_ak820_outline_0096
      0090CA BF 01 03         [24] 2501 	cjne	r7,#0x01,00441$
      0090CD D3               [12] 2502 	setb	c
      0090CE 80 01            [24] 2503 	sjmp	00442$
      0090D0                       2504 00441$:
      0090D0 C3               [12] 2505 	clr	c
      0090D1                       2506 00442$:
      0090D1 92 26            [24] 2507 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0090D3 90 09 E0         [24] 2508 	mov	dptr,#_ak820_macro_primitive
      0090D6 B3               [12] 2509 	cpl	c
      0090D7 E4               [12] 2510 	clr	a
      0090D8 33               [12] 2511 	rlc	a
      0090D9 F0               [24] 2512 	movx	@dptr,a
                                   2513 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0090DA 12 92 8B         [24] 2514 	lcall	_ak820_outline_0096
      0090DD BF 01 10         [24] 2515 	cjne	r7,#0x01,00122$
      0090E0 12 92 BD         [24] 2516 	lcall	_ak820_outline_0154
      0090E3 C0 06            [24] 2517 	push	ar6
      0090E5 C0 05            [24] 2518 	push	ar5
      0090E7 12 7A 72         [24] 2519 	lcall	_tap_code
      0090EA D0 05            [24] 2520 	pop	ar5
      0090EC D0 06            [24] 2521 	pop	ar6
      0090EE 80 24            [24] 2522 	sjmp	00123$
      0090F0                       2523 00122$:
                                   2524 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0090F0 12 92 8B         [24] 2525 	lcall	_ak820_outline_0096
      0090F3 BF 02 10         [24] 2526 	cjne	r7,#0x02,00119$
      0090F6 12 92 BD         [24] 2527 	lcall	_ak820_outline_0154
      0090F9 C0 06            [24] 2528 	push	ar6
      0090FB C0 05            [24] 2529 	push	ar5
      0090FD 12 79 51         [24] 2530 	lcall	_register_code
      009100 D0 05            [24] 2531 	pop	ar5
      009102 D0 06            [24] 2532 	pop	ar6
      009104 80 0E            [24] 2533 	sjmp	00123$
      009106                       2534 00119$:
                                   2535 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      009106 12 92 BD         [24] 2536 	lcall	_ak820_outline_0154
      009109 C0 06            [24] 2537 	push	ar6
      00910B C0 05            [24] 2538 	push	ar5
      00910D 12 79 CD         [24] 2539 	lcall	_unregister_code
      009110 D0 05            [24] 2540 	pop	ar5
      009112 D0 06            [24] 2541 	pop	ar6
      009114                       2542 00123$:
                                   2543 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      009114 12 92 C4         [24] 2544 	lcall	_ak820_outline_0167
      009117 02 90 35         [24] 2545 	ljmp	00167$
      00911A                       2546 00152$:
                                   2547 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      00911A 12 92 8B         [24] 2548 	lcall	_ak820_outline_0096
      00911D BF 05 02         [24] 2549 	cjne	r7,#0x05,00447$
      009120 80 13            [24] 2550 	sjmp	00146$
      009122                       2551 00447$:
      009122 12 92 8B         [24] 2552 	lcall	_ak820_outline_0096
      009125 BF 06 02         [24] 2553 	cjne	r7,#0x06,00448$
      009128 80 0B            [24] 2554 	sjmp	00146$
      00912A                       2555 00448$:
      00912A 12 92 8B         [24] 2556 	lcall	_ak820_outline_0096
      00912D BF 07 02         [24] 2557 	cjne	r7,#0x07,00449$
      009130 80 03            [24] 2558 	sjmp	00450$
      009132                       2559 00449$:
      009132 02 91 DB         [24] 2560 	ljmp	00147$
      009135                       2561 00450$:
      009135                       2562 00146$:
                                   2563 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009135 12 92 61         [24] 2564 	lcall	_ak820_outline_0000
      009138 12 43 C1         [24] 2565 	lcall	_eeprom_read_byte
      00913B 12 92 DC         [24] 2566 	lcall	_ak820_outline_0182
                                   2567 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      00913E 70 03            [24] 2568 	jnz	00451$
      009140 02 90 35         [24] 2569 	ljmp	00167$
      009143                       2570 00451$:
                                   2571 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009143 12 92 61         [24] 2572 	lcall	_ak820_outline_0000
      009146 12 43 C1         [24] 2573 	lcall	_eeprom_read_byte
      009149 AF 82            [24] 2574 	mov	r7, dpl
      00914B 90 0B 9E         [24] 2575 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      00914E EF               [12] 2576 	mov	a,r7
      00914F F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      009150 EF               [12] 2579 	mov	a,r7
      009151 70 03            [24] 2580 	jnz	00452$
      009153 02 90 35         [24] 2581 	ljmp	00167$
      009156                       2582 00452$:
                                   2583 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009156 90 0B 9D         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      009159 E0               [24] 2585 	movx	a,@dptr
      00915A FF               [12] 2586 	mov	r7,a
      00915B 90 0B 9E         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      00915E E0               [24] 2588 	movx	a,@dptr
      00915F FB               [12] 2589 	mov	r3,a
      009160 E4               [12] 2590 	clr	a
      009161 FC               [12] 2591 	mov	r4,a
      009162 FA               [12] 2592 	mov	r2,a
      009163 EF               [12] 2593 	mov	a,r7
      009164 42 04            [12] 2594 	orl	ar4,a
      009166 EA               [12] 2595 	mov	a,r2
      009167 42 03            [12] 2596 	orl	ar3,a
                                   2597 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      009169 12 46 D5         [24] 2598 	lcall	_ak820_outline_0185
      00916C C0 06            [24] 2599 	push	ar6
      00916E C0 05            [24] 2600 	push	ar5
      009170 12 8F 81         [24] 2601 	lcall	_decode_keycode
      009173 AC 82            [24] 2602 	mov	r4, dpl
      009175 AF 83            [24] 2603 	mov	r7, dph
      009177 D0 05            [24] 2604 	pop	ar5
      009179 D0 06            [24] 2605 	pop	ar6
                                   2606 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00917B 90 0B 9C         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00917E E0               [24] 2608 	movx	a,@dptr
      00917F FB               [12] 2609 	mov	r3,a
      009180 BB 05 03         [24] 2610 	cjne	r3,#0x05,00453$
      009183 D3               [12] 2611 	setb	c
      009184 80 01            [24] 2612 	sjmp	00454$
      009186                       2613 00453$:
      009186 C3               [12] 2614 	clr	c
      009187                       2615 00454$:
      009187 92 26            [24] 2616 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009189 90 09 E0         [24] 2617 	mov	dptr,#_ak820_macro_primitive
      00918C B3               [12] 2618 	cpl	c
      00918D E4               [12] 2619 	clr	a
      00918E 33               [12] 2620 	rlc	a
      00918F F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      009190 90 0B 9C         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      009193 E0               [24] 2624 	movx	a,@dptr
      009194 FB               [12] 2625 	mov	r3,a
      009195 BB 05 02         [24] 2626 	cjne	r3,#0x05,00455$
      009198 80 0A            [24] 2627 	sjmp	00126$
      00919A                       2628 00455$:
      00919A BB 06 02         [24] 2629 	cjne	r3,#0x06,00456$
      00919D 80 16            [24] 2630 	sjmp	00127$
      00919F                       2631 00456$:
                                   2632 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      00919F BB 07 33         [24] 2633 	cjne	r3,#0x07,00129$
      0091A2 80 22            [24] 2634 	sjmp	00128$
      0091A4                       2635 00126$:
                                   2636 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      0091A4 8C 82            [24] 2637 	mov	dpl, r4
      0091A6 8F 83            [24] 2638 	mov	dph, r7
      0091A8 C0 06            [24] 2639 	push	ar6
      0091AA C0 05            [24] 2640 	push	ar5
      0091AC 12 B6 2E         [24] 2641 	lcall	_vial_keycode_tap
      0091AF D0 05            [24] 2642 	pop	ar5
      0091B1 D0 06            [24] 2643 	pop	ar6
                                   2644 ;	quantum/dynamic_keymap.c:732: break;
                                   2645 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      0091B3 80 20            [24] 2646 	sjmp	00129$
      0091B5                       2647 00127$:
                                   2648 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      0091B5 8C 82            [24] 2649 	mov	dpl, r4
      0091B7 8F 83            [24] 2650 	mov	dph, r7
      0091B9 C0 06            [24] 2651 	push	ar6
      0091BB C0 05            [24] 2652 	push	ar5
      0091BD 12 B5 63         [24] 2653 	lcall	_vial_keycode_down
      0091C0 D0 05            [24] 2654 	pop	ar5
      0091C2 D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:735: break;
                                   2657 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      0091C4 80 0F            [24] 2658 	sjmp	00129$
      0091C6                       2659 00128$:
                                   2660 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      0091C6 8C 82            [24] 2661 	mov	dpl, r4
      0091C8 8F 83            [24] 2662 	mov	dph, r7
      0091CA C0 06            [24] 2663 	push	ar6
      0091CC C0 05            [24] 2664 	push	ar5
      0091CE 12 B5 C9         [24] 2665 	lcall	_vial_keycode_up
      0091D1 D0 05            [24] 2666 	pop	ar5
      0091D3 D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:739: }
      0091D5                       2669 00129$:
                                   2670 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      0091D5 12 92 C4         [24] 2671 	lcall	_ak820_outline_0167
      0091D8 02 90 35         [24] 2672 	ljmp	00167$
      0091DB                       2673 00147$:
                                   2674 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      0091DB 12 92 8B         [24] 2675 	lcall	_ak820_outline_0096
      0091DE BF 04 02         [24] 2676 	cjne	r7,#0x04,00458$
      0091E1 80 03            [24] 2677 	sjmp	00459$
      0091E3                       2678 00458$:
      0091E3 02 90 35         [24] 2679 	ljmp	00167$
      0091E6                       2680 00459$:
                                   2681 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091E6 12 92 61         [24] 2682 	lcall	_ak820_outline_0000
      0091E9 12 43 C1         [24] 2683 	lcall	_eeprom_read_byte
      0091EC AF 82            [24] 2684 	mov	r7, dpl
                                   2685 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091EE 90 0B 99         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0091F1 12 38 91         [24] 2687 	lcall	_ak820_outline_0124
      0091F4 90 0B 99         [24] 2688 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      0091F7 74 01            [12] 2689 	mov	a,#0x01
      0091F9 2B               [12] 2690 	add	a, r3
      0091FA F0               [24] 2691 	movx	@dptr,a
      0091FB E4               [12] 2692 	clr	a
      0091FC 3C               [12] 2693 	addc	a, r4
      0091FD A3               [24] 2694 	inc	dptr
      0091FE F0               [24] 2695 	movx	@dptr,a
      0091FF 7A 00            [12] 2696 	mov	r2,#0x00
      009201 12 33 FC         [24] 2697 	lcall	_ak820_outline_0125
      009204 8A F0            [24] 2698 	mov	b, r2
      009206 12 43 C1         [24] 2699 	lcall	_eeprom_read_byte
      009209 AC 82            [24] 2700 	mov	r4, dpl
                                   2701 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      00920B EF               [12] 2702 	mov	a,r7
      00920C 60 4B            [24] 2703 	jz	00169$
      00920E EC               [12] 2704 	mov	a,r4
      00920F 60 48            [24] 2705 	jz	00169$
                                   2706 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009211 1F               [12] 2707 	dec	r7
      009212 1C               [12] 2708 	dec	r4
      009213 EC               [12] 2709 	mov	a,r4
      009214 75 F0 FF         [24] 2710 	mov	b,#0xff
      009217 A4               [48] 2711 	mul	ab
      009218 FC               [12] 2712 	mov	r4,a
      009219 AB F0            [24] 2713 	mov	r3,b
      00921B 7A 00            [12] 2714 	mov	r2,#0x00
      00921D EC               [12] 2715 	mov	a,r4
      00921E 2F               [12] 2716 	add	a, r7
      00921F FC               [12] 2717 	mov	r4,a
      009220 EB               [12] 2718 	mov	a,r3
      009221 3A               [12] 2719 	addc	a, r2
      009222 FB               [12] 2720 	mov	r3,a
                                   2721 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      009223                       2722 00141$:
      009223 8C 02            [24] 2723 	mov	ar2,r4
      009225 8B 07            [24] 2724 	mov	ar7,r3
      009227 1C               [12] 2725 	dec	r4
      009228 BC FF 01         [24] 2726 	cjne	r4,#0xff,00462$
      00922B 1B               [12] 2727 	dec	r3
      00922C                       2728 00462$:
      00922C EA               [12] 2729 	mov	a,r2
      00922D 4F               [12] 2730 	orl	a,r7
      00922E 70 03            [24] 2731 	jnz	00463$
      009230 02 90 35         [24] 2732 	ljmp	00167$
      009233                       2733 00463$:
      009233 90 00 01         [24] 2734 	mov	dptr,#0x0001
      009236 12 5C 19         [24] 2735 	lcall	_mDelaymS
      009239 80 E8            [24] 2736 	sjmp	00141$
      00923B                       2737 00164$:
                                   2738 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      00923B 90 0B 9B         [24] 2739 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00923E E0               [24] 2740 	movx	a,@dptr
      00923F FF               [12] 2741 	mov	r7,a
      009240 BF 80 00         [24] 2742 	cjne	r7,#0x80,00464$
      009243                       2743 00464$:
      009243 50 14            [24] 2744 	jnc	00169$
                                   2745 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      009245 90 0B 9B         [24] 2746 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      009248 E0               [24] 2747 	movx	a,@dptr
      009249 F5 82            [12] 2748 	mov	dpl,a
      00924B C0 06            [24] 2749 	push	ar6
      00924D C0 05            [24] 2750 	push	ar5
      00924F 12 A8 D3         [24] 2751 	lcall	_send_char
      009252 D0 05            [24] 2752 	pop	ar5
      009254 D0 06            [24] 2753 	pop	ar6
                                   2754 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009256 02 90 35         [24] 2755 	ljmp	00167$
      009259                       2756 00169$:
                                   2757 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      009259 12 92 C4         [24] 2758 	lcall	_ak820_outline_0167
                                   2759 ;	quantum/dynamic_keymap.c:774: sending = false;
      00925C 90 0B 98         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      00925F F0               [24] 2761 	movx	@dptr,a
                                   2762 ;	quantum/dynamic_keymap.c:776: }
      009260 22               [24] 2763 	ret
                                   2764 	.area CSEG    (CODE)
                                   2765 	.area CONST   (CODE)
                                   2766 	.area XINIT   (CODE)
                                   2767 	.area CABS    (ABS,CODE)
                                   2768 
                                   2769 ; Experimental exact instruction outlining.
                                   2770 	.globl _ak820_outline_0000
                                   2771 	.globl _ak820_outline_0005
                                   2772 	.globl _ak820_outline_0009
                                   2773 	.globl _ak820_outline_0014
                                   2774 	.globl _ak820_outline_0022
                                   2775 	.globl _ak820_outline_0031
                                   2776 	.globl _ak820_outline_0034
                                   2777 	.globl _ak820_outline_0050
                                   2778 	.globl _ak820_outline_0051
                                   2779 	.globl _ak820_outline_0053
                                   2780 	.globl _ak820_outline_0060
                                   2781 	.globl _ak820_outline_0061
                                   2782 	.globl _ak820_outline_0072
                                   2783 	.globl _ak820_outline_0076
                                   2784 	.globl _ak820_outline_0078
                                   2785 	.globl _ak820_outline_0083
                                   2786 	.globl _ak820_outline_0087
                                   2787 	.globl _ak820_outline_0093
                                   2788 	.globl _ak820_outline_0095
                                   2789 	.globl _ak820_outline_0096
                                   2790 	.globl _ak820_outline_0102
                                   2791 	.globl _ak820_outline_0104
                                   2792 	.globl _ak820_outline_0105
                                   2793 	.globl _ak820_outline_0106
                                   2794 	.globl _ak820_outline_0110
                                   2795 	.globl _ak820_outline_0111
                                   2796 	.globl _ak820_outline_0114
                                   2797 	.globl _ak820_outline_0118
                                   2798 	.globl _ak820_outline_0120
                                   2799 	.globl _ak820_outline_0124
                                   2800 	.globl _ak820_outline_0125
                                   2801 	.globl _ak820_outline_0126
                                   2802 	.globl _ak820_outline_0127
                                   2803 	.globl _ak820_outline_0131
                                   2804 	.globl _ak820_outline_0136
                                   2805 	.globl _ak820_outline_0137
                                   2806 	.globl _ak820_outline_0138
                                   2807 	.globl _ak820_outline_0139
                                   2808 	.globl _ak820_outline_0144
                                   2809 	.globl _ak820_outline_0145
                                   2810 	.globl _ak820_outline_0146
                                   2811 	.globl _ak820_outline_0151
                                   2812 	.globl _ak820_outline_0154
                                   2813 	.globl _ak820_outline_0158
                                   2814 	.globl _ak820_outline_0162
                                   2815 	.globl _ak820_outline_0167
                                   2816 	.globl _ak820_outline_0178
                                   2817 	.globl _ak820_outline_0179
                                   2818 	.globl _ak820_outline_0182
                                   2819 	.globl _ak820_outline_0183
                                   2820 	.globl _ak820_outline_0184
                                   2821 	.globl _ak820_outline_0185
                                   2822 	.globl _ak820_outline_0188
                                   2823 	.globl _ak820_outline_0190
                                   2824 
                                   2825 	.area CSEG (CODE)
                                   2826 ; function ak820_outline_0000
      009261                       2827 _ak820_outline_0000:
      009261 90 0B 99         [24] 2828 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009264 E0               [24] 2829 	movx	a,@dptr
      009265 FC               [12] 2830 	mov	r4,a
      009266 A3               [24] 2831 	inc	dptr
      009267 E0               [24] 2832 	movx	a,@dptr
      009268 FF               [12] 2833 	mov	r7,a
      009269 90 0B 99         [24] 2834 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00926C 74 01            [12] 2835 	mov	a,#0x01
      00926E 2C               [12] 2836 	add	a,r4
      00926F F0               [24] 2837 	movx	@dptr,a
      009270 E4               [12] 2838 	clr	a
      009271 3F               [12] 2839 	addc	a,r7
      009272 A3               [24] 2840 	inc	dptr
      009273 F0               [24] 2841 	movx	@dptr,a
      009274 7B 00            [12] 2842 	mov	r3,#0x00
      009276 8C 82            [24] 2843 	mov	dpl,r4
      009278 8F 83            [24] 2844 	mov	dph,r7
      00927A 8B F0            [24] 2845 	mov	b,r3
      00927C 22               [24] 2846 	ret
                                   2847 
                                   2848 	.area CSEG (CODE)
                                   2849 ; function ak820_outline_0083
      00927D                       2850 _ak820_outline_0083:
      00927D ED               [12] 2851 	mov	a,r5
      00927E 75 F0 0A         [24] 2852 	mov	b,#0x0a
      009281 A4               [48] 2853 	mul	ab
      009282 24 58            [12] 2854 	add	a,#0x58
      009284 FC               [12] 2855 	mov	r4,a
      009285 74 06            [12] 2856 	mov	a,#0x06
      009287 35 F0            [12] 2857 	addc	a,b
      009289 FD               [12] 2858 	mov	r5,a
      00928A 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0096
      00928B                       2863 _ak820_outline_0096:
      00928B 90 0B 9C         [24] 2864 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      00928E E0               [24] 2865 	movx	a,@dptr
      00928F FF               [12] 2866 	mov	r7,a
      009290 22               [24] 2867 	ret
                                   2868 
                                   2869 	.area CSEG (CODE)
                                   2870 ; function ak820_outline_0102
      009291                       2871 _ak820_outline_0102:
      009291 90 0B 32         [24] 2872 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009294 EE               [12] 2873 	mov	a,r6
      009295 F0               [24] 2874 	movx	@dptr,a
      009296 90 0B 33         [24] 2875 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009299 ED               [12] 2876 	mov	a,r5
      00929A F0               [24] 2877 	movx	@dptr,a
      00929B 8F 82            [24] 2878 	mov	dpl,r7
      00929D 22               [24] 2879 	ret
                                   2880 
                                   2881 	.area CSEG (CODE)
                                   2882 ; function ak820_outline_0114
      00929E                       2883 _ak820_outline_0114:
      00929E 74 0A            [12] 2884 	mov	a,#0x0a
      0092A0 F0               [24] 2885 	movx	@dptr,a
      0092A1 E4               [12] 2886 	clr	a
      0092A2 A3               [24] 2887 	inc	dptr
      0092A3 F0               [24] 2888 	movx	@dptr,a
      0092A4 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0118
      0092A5                       2893 _ak820_outline_0118:
      0092A5 AD 82            [24] 2894 	mov	r5,dpl
      0092A7 AE 83            [24] 2895 	mov	r6,dph
      0092A9 AF F0            [24] 2896 	mov	r7,b
      0092AB 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0131
      0092AC                       2901 _ak820_outline_0131:
      0092AC 28               [12] 2902 	add	a,r0
      0092AD F5 82            [12] 2903 	mov	dpl,a
      0092AF EF               [12] 2904 	mov	a,r7
      0092B0 39               [12] 2905 	addc	a,r1
      0092B1 F5 83            [12] 2906 	mov	dph,a
      0092B3 74 FF            [12] 2907 	mov	a,#0xff
      0092B5 F0               [24] 2908 	movx	@dptr,a
      0092B6 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0138
      0092B7                       2913 _ak820_outline_0138:
      0092B7 2D               [12] 2914 	add	a,r5
      0092B8 F9               [12] 2915 	mov	r1,a
      0092B9 E4               [12] 2916 	clr	a
      0092BA 3E               [12] 2917 	addc	a,r6
      0092BB FA               [12] 2918 	mov	r2,a
      0092BC 22               [24] 2919 	ret
                                   2920 
                                   2921 	.area CSEG (CODE)
                                   2922 ; function ak820_outline_0154
      0092BD                       2923 _ak820_outline_0154:
      0092BD 90 0B 9D         [24] 2924 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      0092C0 E0               [24] 2925 	movx	a,@dptr
      0092C1 F5 82            [12] 2926 	mov	dpl,a
      0092C3 22               [24] 2927 	ret
                                   2928 
                                   2929 	.area CSEG (CODE)
                                   2930 ; function ak820_outline_0167
      0092C4                       2931 _ak820_outline_0167:
      0092C4 90 09 E0         [24] 2932 	mov	dptr,#_ak820_macro_primitive
      0092C7 E4               [12] 2933 	clr	a
      0092C8 F0               [24] 2934 	movx	@dptr,a
      0092C9 22               [24] 2935 	ret
                                   2936 
                                   2937 	.area CSEG (CODE)
                                   2938 ; function ak820_outline_0178
      0092CA                       2939 _ak820_outline_0178:
      0092CA 90 0B 42         [24] 2940 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0092CD E4               [12] 2941 	clr	a
      0092CE F0               [24] 2942 	movx	@dptr,a
      0092CF 90 0B 43         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0092D2 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0179
      0092D3                       2948 _ak820_outline_0179:
      0092D3 90 0B F8         [24] 2949 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0092D6 E4               [12] 2950 	clr	a
      0092D7 F0               [24] 2951 	movx	@dptr,a
      0092D8 90 0B F9         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0092DB 22               [24] 2953 	ret
                                   2954 
                                   2955 	.area CSEG (CODE)
                                   2956 ; function ak820_outline_0182
      0092DC                       2957 _ak820_outline_0182:
      0092DC AF 82            [24] 2958 	mov	r7,dpl
      0092DE 90 0B 9D         [24] 2959 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      0092E1 EF               [12] 2960 	mov	a,r7
      0092E2 F0               [24] 2961 	movx	@dptr,a
      0092E3 EF               [12] 2962 	mov	a,r7
      0092E4 22               [24] 2963 	ret
