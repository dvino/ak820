                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007F1                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007F1                        556 	.ds 1
      0007F2                        557 _add_key_byte_PARM_2:
      0007F2                        558 	.ds 1
      0007F3                        559 _add_key_byte_report_arg_10000_144:
      0007F3                        560 	.ds 3
      0007F6                        561 _add_key_byte_empty_10000_145:
      0007F6                        562 	.ds 1
      0007F7                        563 _del_key_byte_PARM_2:
      0007F7                        564 	.ds 1
      0007F8                        565 _del_key_byte_report_arg_10000_156:
      0007F8                        566 	.ds 3
      0007FB                        567 _add_key_bit_PARM_2:
      0007FB                        568 	.ds 1
      0007FC                        569 _add_key_bit_report_arg_10000_162:
      0007FC                        570 	.ds 3
      0007FF                        571 _del_key_bit_PARM_2:
      0007FF                        572 	.ds 1
      000800                        573 _del_key_bit_report_arg_10000_167:
      000800                        574 	.ds 3
      000803                        575 _add_key_to_report_PARM_2:
      000803                        576 	.ds 1
      000804                        577 _add_key_to_report_report_arg_10000_172:
      000804                        578 	.ds 3
      000807                        579 _del_key_from_report_PARM_2:
      000807                        580 	.ds 1
      000808                        581 _del_key_from_report_report_arg_10000_176:
      000808                        582 	.ds 3
      00080B                        583 _clear_keys_from_report_report_arg_10000_180:
      00080B                        584 	.ds 3
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006D9B                        636 _KEYCODE2CONSUMER:
      006D9B E5 82            [12]  637 	mov	a,dpl
      006D9D 90 07 F1         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006DA0 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006DA1 E0               [24]  641 	movx	a,@dptr
      006DA2 FF               [12]  642 	mov	r7,a
      006DA3 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006DA6                        644 00113$:
      006DA6 40 05            [24]  645 	jc	00101$
      006DA8 EF               [12]  646 	mov	a,r7
      006DA9 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006DAB 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006DAD                        650 00101$:
      006DAD 90 00 00         [24]  651 	mov	dptr,#0x0000
      006DB0 22               [24]  652 	ret
      006DB1                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      006DB1 EF               [12]  655 	mov	a,r7
      006DB2 24 58            [12]  656 	add	a,#0x58
      006DB4 FF               [12]  657 	mov	r7,a
      006DB5 C2 D5            [12]  658 	clr	F0
      006DB7 75 F0 02         [24]  659 	mov	b,#0x02
      006DBA EF               [12]  660 	mov	a,r7
      006DBB 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006DBE B2 D5            [12]  662 	cpl	F0
      006DC0 F4               [12]  663 	cpl	a
      006DC1 04               [12]  664 	inc	a
      006DC2                        665 00116$:
      006DC2 A4               [48]  666 	mul	ab
      006DC3 30 D5 03         [24]  667 	jnb	F0,00117$
      006DC6 12 6F C7         [24]  668 	lcall	_ak820_outline_0131
      006DC9                        669 00117$:
      006DC9 24 45            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006DCB F5 82            [12]  671 	mov	dpl,a
      006DCD 74 BA            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006DCF 12 57 17         [24]  673 	lcall	_ak820_outline_0111
      006DD2 FE               [12]  674 	mov	r6,a
      006DD3 A3               [24]  675 	inc	dptr
      006DD4 E4               [12]  676 	clr	a
      006DD5 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:54: }
      006DD6 8E 82            [24]  679 	mov	dpl,r6
      006DD8 F5 83            [12]  680 	mov	dph,a
      006DDA 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006DDB                        695 _add_key_byte:
      006DDB 12 43 15         [24]  696 	lcall	_ak820_outline_0036
      006DDE 90 07 F3         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006DE1 12 38 1F         [24]  698 	lcall	_ak820_outline_0016
                                    699 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006DE4 90 07 F3         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006DE7 12 38 41         [24]  701 	lcall	_ak820_outline_0052
                                    702 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      006DEA 90 07 F6         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006DED 74 FF            [12]  704 	mov	a,#0xff
      006DEF F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:209: }
      006DF0 7D 00            [12]  707 	mov	r5,#0x00
      006DF2                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006DF2 C3               [12]  710 	clr	c
      006DF3 ED               [12]  711 	mov	a,r5
      006DF4 64 80            [12]  712 	xrl	a,#0x80
      006DF6 94 86            [12]  713 	subb	a,#0x86
      006DF8 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      006DFA 12 6F D2         [24]  716 	lcall	_ak820_outline_0147
      006DFD F5 82            [12]  717 	mov	dpl,a
      006DFF E4               [12]  718 	clr	a
      006E00 3C               [12]  719 	addc	a, r4
      006E01 F5 83            [12]  720 	mov	dph,a
      006E03 E0               [24]  721 	movx	a,@dptr
      006E04 FC               [12]  722 	mov	r4,a
      006E05 90 07 F2         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      006E08 E0               [24]  724 	movx	a,@dptr
      006E09 FB               [12]  725 	mov	r3,a
      006E0A EC               [12]  726 	mov	a,r4
      006E0B B5 03 02         [24]  727 	cjne	a,ar3,00167$
      006E0E 80 13            [24]  728 	sjmp	00106$
      006E10                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006E10 90 07 F6         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      006E13 E0               [24]  732 	movx	a,@dptr
      006E14 FB               [12]  733 	mov	r3,a
      006E15 BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      006E18 EC               [12]  735 	mov	a,r4
      006E19 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:200: empty = i;
      006E1B 90 07 F6         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      006E1E ED               [12]  739 	mov	a,r5
      006E1F F0               [24]  740 	movx	@dptr,a
      006E20                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006E20 0D               [12]  743 	inc	r5
      006E21 80 CF            [24]  744 	sjmp	00112$
      006E23                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      006E23 BD 06 1D         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      006E26 90 07 F6         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      006E29 E0               [24]  750 	movx	a,@dptr
      006E2A FD               [12]  751 	mov	r5,a
      006E2B BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      006E2E 22               [24]  753 	ret
      006E2F                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      006E2F 74 02            [12]  756 	mov	a,#0x02
      006E31 12 43 5C         [24]  757 	lcall	_ak820_outline_0139
      006E34 ED               [12]  758 	mov	a,r5
      006E35 2E               [12]  759 	add	a, r6
      006E36 FD               [12]  760 	mov	r5,a
      006E37 E4               [12]  761 	clr	a
      006E38 3F               [12]  762 	addc	a, r7
      006E39 FC               [12]  763 	mov	r4,a
      006E3A 90 07 F2         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      006E3D E0               [24]  765 	movx	a,@dptr
      006E3E 8D 82            [24]  766 	mov	dpl,r5
      006E40 8C 83            [24]  767 	mov	dph,r4
      006E42 F0               [24]  768 	movx	@dptr,a
      006E43                        769 00114$:
                                    770 ;	tmk_core/protocol/report.c:209: }
      006E43 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'del_key_byte'
                                    774 ;------------------------------------------------------------
                                    775 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    776 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    777 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    778 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    779 ;------------------------------------------------------------
                                    780 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    781 ;	-----------------------------------------
                                    782 ;	 function del_key_byte
                                    783 ;	-----------------------------------------
      006E44                        784 _del_key_byte:
      006E44 12 43 15         [24]  785 	lcall	_ak820_outline_0036
      006E47 90 07 F8         [24]  786 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006E4A 12 38 1F         [24]  787 	lcall	_ak820_outline_0016
                                    788 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E4D 90 07 F8         [24]  789 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006E50 12 38 41         [24]  790 	lcall	_ak820_outline_0052
                                    791 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006E53 7D 00            [12]  792 	mov	r5,#0x00
      006E55                        793 00105$:
      006E55 BD 06 00         [24]  794 	cjne	r5,#0x06,00131$
      006E58                        795 00131$:
      006E58 50 1B            [24]  796 	jnc	00107$
                                    797 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      006E5A 12 6F D2         [24]  798 	lcall	_ak820_outline_0147
      006E5D FB               [12]  799 	mov	r3,a
      006E5E E4               [12]  800 	clr	a
      006E5F 3C               [12]  801 	addc	a, r4
      006E60 FC               [12]  802 	mov	r4,a
      006E61 12 48 99         [24]  803 	lcall	_ak820_outline_0065
      006E64 90 07 F7         [24]  804 	mov	dptr,#_del_key_byte_PARM_2
      006E67 E0               [24]  805 	movx	a,@dptr
      006E68 F9               [12]  806 	mov	r1,a
      006E69 EA               [12]  807 	mov	a,r2
      006E6A B5 01 05         [24]  808 	cjne	a,ar1,00106$
                                    809 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      006E6D 12 33 FC         [24]  810 	lcall	_ak820_outline_0125
      006E70 E4               [12]  811 	clr	a
      006E71 F0               [24]  812 	movx	@dptr,a
      006E72                        813 00106$:
                                    814 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006E72 0D               [12]  815 	inc	r5
      006E73 80 E0            [24]  816 	sjmp	00105$
      006E75                        817 00107$:
                                    818 ;	tmk_core/protocol/report.c:249: }
      006E75 22               [24]  819 	ret
                                    820 ;------------------------------------------------------------
                                    821 ;Allocation info for local variables in function 'add_key_bit'
                                    822 ;------------------------------------------------------------
                                    823 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    824 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    825 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    826 ;------------------------------------------------------------
                                    827 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function add_key_bit
                                    830 ;	-----------------------------------------
      006E76                        831 _add_key_bit:
      006E76 12 43 15         [24]  832 	lcall	_ak820_outline_0036
      006E79 90 07 FC         [24]  833 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006E7C 12 38 1F         [24]  834 	lcall	_ak820_outline_0016
                                    835 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006E7F 90 07 FC         [24]  836 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006E82 12 38 41         [24]  837 	lcall	_ak820_outline_0052
                                    838 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006E85 90 07 FB         [24]  839 	mov	dptr,#_add_key_bit_PARM_2
      006E88 E0               [24]  840 	movx	a,@dptr
      006E89 FD               [12]  841 	mov	r5,a
      006E8A 12 57 4D         [24]  842 	lcall	_ak820_outline_0190
      006E8D FC               [12]  843 	mov	r4,a
      006E8E BC 1E 00         [24]  844 	cjne	r4,#0x1e,00112$
      006E91                        845 00112$:
      006E91 50 16            [24]  846 	jnc	00103$
                                    847 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      006E93 12 6F A3         [24]  848 	lcall	_ak820_outline_0035
      006E96 80 02            [24]  849 	sjmp	00115$
      006E98                        850 00114$:
      006E98 25 E0            [12]  851 	add	a,acc
      006E9A                        852 00115$:
      006E9A D5 F0 FB         [24]  853 	djnz	b,00114$
      006E9D FF               [12]  854 	mov	r7,a
      006E9E 12 43 83         [24]  855 	lcall	_ak820_outline_0186
      006EA1 E0               [24]  856 	movx	a,@dptr
      006EA2 42 07            [12]  857 	orl	ar7,a
      006EA4 12 43 83         [24]  858 	lcall	_ak820_outline_0186
      006EA7 EF               [12]  859 	mov	a,r7
      006EA8 F0               [24]  860 	movx	@dptr,a
      006EA9                        861 00103$:
                                    862 ;	tmk_core/protocol/report.c:263: }
      006EA9 22               [24]  863 	ret
                                    864 ;------------------------------------------------------------
                                    865 ;Allocation info for local variables in function 'del_key_bit'
                                    866 ;------------------------------------------------------------
                                    867 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    868 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    869 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    870 ;------------------------------------------------------------
                                    871 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function del_key_bit
                                    874 ;	-----------------------------------------
      006EAA                        875 _del_key_bit:
      006EAA 12 43 15         [24]  876 	lcall	_ak820_outline_0036
      006EAD 90 08 00         [24]  877 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006EB0 12 38 1F         [24]  878 	lcall	_ak820_outline_0016
                                    879 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006EB3 90 08 00         [24]  880 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006EB6 12 38 41         [24]  881 	lcall	_ak820_outline_0052
                                    882 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006EB9 90 07 FF         [24]  883 	mov	dptr,#_del_key_bit_PARM_2
      006EBC E0               [24]  884 	movx	a,@dptr
      006EBD FD               [12]  885 	mov	r5,a
      006EBE 12 57 4D         [24]  886 	lcall	_ak820_outline_0190
      006EC1 FC               [12]  887 	mov	r4,a
      006EC2 BC 1E 00         [24]  888 	cjne	r4,#0x1e,00112$
      006EC5                        889 00112$:
      006EC5 50 17            [24]  890 	jnc	00103$
                                    891 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      006EC7 12 6F A3         [24]  892 	lcall	_ak820_outline_0035
      006ECA 80 02            [24]  893 	sjmp	00115$
      006ECC                        894 00114$:
      006ECC 25 E0            [12]  895 	add	a,acc
      006ECE                        896 00115$:
      006ECE D5 F0 FB         [24]  897 	djnz	b,00114$
      006ED1 F4               [12]  898 	cpl	a
      006ED2 FF               [12]  899 	mov	r7,a
      006ED3 12 43 83         [24]  900 	lcall	_ak820_outline_0186
      006ED6 E0               [24]  901 	movx	a,@dptr
      006ED7 52 07            [12]  902 	anl	ar7,a
      006ED9 12 43 83         [24]  903 	lcall	_ak820_outline_0186
      006EDC EF               [12]  904 	mov	a,r7
      006EDD F0               [24]  905 	movx	@dptr,a
      006EDE                        906 00103$:
                                    907 ;	tmk_core/protocol/report.c:276: }
      006EDE 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'add_key_to_report'
                                    911 ;------------------------------------------------------------
                                    912 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    913 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    914 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    915 ;------------------------------------------------------------
                                    916 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    917 ;	-----------------------------------------
                                    918 ;	 function add_key_to_report
                                    919 ;	-----------------------------------------
      006EDF                        920 _add_key_to_report:
      006EDF 12 43 15         [24]  921 	lcall	_ak820_outline_0036
      006EE2 90 08 04         [24]  922 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006EE5 12 38 1F         [24]  923 	lcall	_ak820_outline_0016
                                    924 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006EE8 90 08 04         [24]  925 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      006EEB 12 38 41         [24]  926 	lcall	_ak820_outline_0052
                                    927 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      006EEE 90 0D B9         [24]  928 	mov	dptr,#_keyboard_protocol
      006EF1 E0               [24]  929 	movx	a,@dptr
      006EF2 60 19            [24]  930 	jz	00102$
      006EF4 90 0A C5         [24]  931 	mov	dptr,#_keymap_config
      006EF7 E0               [24]  932 	movx	a,@dptr
      006EF8 30 E7 12         [24]  933 	jnb	acc.7,00102$
                                    934 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      006EFB 12 6F DC         [24]  935 	lcall	_ak820_outline_0153
      006EFE 90 08 03         [24]  936 	mov	dptr,#_add_key_to_report_PARM_2
      006F01 E0               [24]  937 	movx	a,@dptr
      006F02 90 07 FB         [24]  938 	mov	dptr,#_add_key_bit_PARM_2
      006F05 12 6F C1         [24]  939 	lcall	_ak820_outline_0103
      006F08 8D F0            [24]  940 	mov	b, r5
                                    941 ;	tmk_core/protocol/report.c:288: return;
      006F0A 02 6E 76         [24]  942 	ljmp	_add_key_bit
      006F0D                        943 00102$:
                                    944 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      006F0D 7D 00            [12]  945 	mov	r5,#0x00
      006F0F 90 08 03         [24]  946 	mov	dptr,#_add_key_to_report_PARM_2
      006F12 E0               [24]  947 	movx	a,@dptr
      006F13 90 07 F2         [24]  948 	mov	dptr,#_add_key_byte_PARM_2
      006F16 F0               [24]  949 	movx	@dptr,a
      006F17 12 6F BA         [24]  950 	lcall	_ak820_outline_0050
                                    951 ;	tmk_core/protocol/report.c:292: }
      006F1A 02 6D DB         [24]  952 	ljmp	_add_key_byte
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'del_key_from_report'
                                    955 ;------------------------------------------------------------
                                    956 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    957 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    958 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    959 ;------------------------------------------------------------
                                    960 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function del_key_from_report
                                    963 ;	-----------------------------------------
      006F1D                        964 _del_key_from_report:
      006F1D 12 43 15         [24]  965 	lcall	_ak820_outline_0036
      006F20 90 08 08         [24]  966 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006F23 12 38 1F         [24]  967 	lcall	_ak820_outline_0016
                                    968 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F26 90 08 08         [24]  969 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      006F29 12 38 41         [24]  970 	lcall	_ak820_outline_0052
                                    971 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      006F2C 90 0D B9         [24]  972 	mov	dptr,#_keyboard_protocol
      006F2F E0               [24]  973 	movx	a,@dptr
      006F30 60 19            [24]  974 	jz	00102$
      006F32 90 0A C5         [24]  975 	mov	dptr,#_keymap_config
      006F35 E0               [24]  976 	movx	a,@dptr
      006F36 30 E7 12         [24]  977 	jnb	acc.7,00102$
                                    978 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      006F39 12 6F DC         [24]  979 	lcall	_ak820_outline_0153
      006F3C 90 08 07         [24]  980 	mov	dptr,#_del_key_from_report_PARM_2
      006F3F E0               [24]  981 	movx	a,@dptr
      006F40 90 07 FF         [24]  982 	mov	dptr,#_del_key_bit_PARM_2
      006F43 12 6F C1         [24]  983 	lcall	_ak820_outline_0103
      006F46 8D F0            [24]  984 	mov	b, r5
                                    985 ;	tmk_core/protocol/report.c:303: return;
      006F48 02 6E AA         [24]  986 	ljmp	_del_key_bit
      006F4B                        987 00102$:
                                    988 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      006F4B 7D 00            [12]  989 	mov	r5,#0x00
      006F4D 90 08 07         [24]  990 	mov	dptr,#_del_key_from_report_PARM_2
      006F50 E0               [24]  991 	movx	a,@dptr
      006F51 90 07 F7         [24]  992 	mov	dptr,#_del_key_byte_PARM_2
      006F54 F0               [24]  993 	movx	@dptr,a
      006F55 12 6F BA         [24]  994 	lcall	_ak820_outline_0050
                                    995 ;	tmk_core/protocol/report.c:307: }
      006F58 02 6E 44         [24]  996 	ljmp	_del_key_byte
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    999 ;------------------------------------------------------------
                                   1000 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                   1001 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                   1002 ;------------------------------------------------------------
                                   1003 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1004 ;	-----------------------------------------
                                   1005 ;	 function clear_keys_from_report
                                   1006 ;	-----------------------------------------
      006F5B                       1007 _clear_keys_from_report:
      006F5B 12 43 15         [24] 1008 	lcall	_ak820_outline_0036
      006F5E 90 08 0B         [24] 1009 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006F61 12 38 1F         [24] 1010 	lcall	_ak820_outline_0016
                                   1011 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F64 90 08 0B         [24] 1012 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      006F67 12 38 41         [24] 1013 	lcall	_ak820_outline_0052
                                   1014 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      006F6A 90 0D B9         [24] 1015 	mov	dptr,#_keyboard_protocol
      006F6D E0               [24] 1016 	movx	a,@dptr
      006F6E 60 1E            [24] 1017 	jz	00102$
      006F70 90 0A C5         [24] 1018 	mov	dptr,#_keymap_config
      006F73 E0               [24] 1019 	movx	a,@dptr
      006F74 30 E7 17         [24] 1020 	jnb	acc.7,00102$
                                   1021 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      006F77 74 02            [12] 1022 	mov	a,#0x02
      006F79 12 43 72         [24] 1023 	lcall	_ak820_outline_0164
      006F7C 7B 00            [12] 1024 	mov	r3,#0x00
      006F7E 12 6F E3         [24] 1025 	lcall	_ak820_outline_0182
      006F81 74 1E            [12] 1026 	mov	a,#0x1e
      006F83 F0               [24] 1027 	movx	@dptr,a
      006F84 E4               [12] 1028 	clr	a
      006F85 A3               [24] 1029 	inc	dptr
      006F86 12 38 76         [24] 1030 	lcall	_ak820_outline_0101
      006F89 8B F0            [24] 1031 	mov	b, r3
                                   1032 ;	tmk_core/protocol/report.c:319: return;
      006F8B 02 B9 36         [24] 1033 	ljmp	_memset
      006F8E                       1034 00102$:
                                   1035 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      006F8E 74 02            [12] 1036 	mov	a,#0x02
      006F90 12 43 5C         [24] 1037 	lcall	_ak820_outline_0139
      006F93 7D 00            [12] 1038 	mov	r5,#0x00
      006F95 12 6F E3         [24] 1039 	lcall	_ak820_outline_0182
      006F98 74 06            [12] 1040 	mov	a,#0x06
      006F9A 12 38 A1         [24] 1041 	lcall	_ak820_outline_0137
      006F9D 12 6F BA         [24] 1042 	lcall	_ak820_outline_0050
                                   1043 ;	tmk_core/protocol/report.c:323: }
      006FA0 02 B9 36         [24] 1044 	ljmp	_memset
                                   1045 	.area CSEG    (CODE)
                                   1046 	.area CONST   (CODE)
                                   1047 	.area CONST   (CODE)
      00BA45                       1048 _KEYCODE2CONSUMER_usages_10000_118:
      00BA45 E2 00                 1049 	.byte #0xe2, #0x00	; 226
      00BA47 E9 00                 1050 	.byte #0xe9, #0x00	; 233
      00BA49 EA 00                 1051 	.byte #0xea, #0x00	; 234
      00BA4B B5 00                 1052 	.byte #0xb5, #0x00	; 181
      00BA4D B6 00                 1053 	.byte #0xb6, #0x00	; 182
      00BA4F B7 00                 1054 	.byte #0xb7, #0x00	; 183
      00BA51 CD 00                 1055 	.byte #0xcd, #0x00	; 205
      00BA53 83 01                 1056 	.byte #0x83, #0x01	; 387
      00BA55 CC 00                 1057 	.byte #0xcc, #0x00	; 204
      00BA57 8A 01                 1058 	.byte #0x8a, #0x01	; 394
      00BA59 92 01                 1059 	.byte #0x92, #0x01	; 402
      00BA5B 94 01                 1060 	.byte #0x94, #0x01	; 404
      00BA5D 21 02                 1061 	.byte #0x21, #0x02	; 545
      00BA5F 23 02                 1062 	.byte #0x23, #0x02	; 547
      00BA61 24 02                 1063 	.byte #0x24, #0x02	; 548
      00BA63 25 02                 1064 	.byte #0x25, #0x02	; 549
      00BA65 26 02                 1065 	.byte #0x26, #0x02	; 550
      00BA67 27 02                 1066 	.byte #0x27, #0x02	; 551
      00BA69 2A 02                 1067 	.byte #0x2a, #0x02	; 554
      00BA6B B3 00                 1068 	.byte #0xb3, #0x00	; 179
      00BA6D B4 00                 1069 	.byte #0xb4, #0x00	; 180
      00BA6F 6F 00                 1070 	.byte #0x6f, #0x00	; 111
      00BA71 70 00                 1071 	.byte #0x70, #0x00	; 112
      00BA73 9F 01                 1072 	.byte #0x9f, #0x01	; 415
      00BA75 CB 01                 1073 	.byte #0xcb, #0x01	; 459
      00BA77 9F 02                 1074 	.byte #0x9f, #0x02	; 671
      00BA79 A0 02                 1075 	.byte #0xa0, #0x02	; 672
                                   1076 	.area CSEG    (CODE)
                                   1077 	.area XINIT   (CODE)
                                   1078 	.area CABS    (ABS,CODE)
                                   1079 
                                   1080 ; Experimental exact instruction outlining.
                                   1081 	.globl _ak820_outline_0016
                                   1082 	.globl _ak820_outline_0035
                                   1083 	.globl _ak820_outline_0036
                                   1084 	.globl _ak820_outline_0050
                                   1085 	.globl _ak820_outline_0052
                                   1086 	.globl _ak820_outline_0065
                                   1087 	.globl _ak820_outline_0101
                                   1088 	.globl _ak820_outline_0103
                                   1089 	.globl _ak820_outline_0111
                                   1090 	.globl _ak820_outline_0125
                                   1091 	.globl _ak820_outline_0131
                                   1092 	.globl _ak820_outline_0137
                                   1093 	.globl _ak820_outline_0139
                                   1094 	.globl _ak820_outline_0147
                                   1095 	.globl _ak820_outline_0153
                                   1096 	.globl _ak820_outline_0164
                                   1097 	.globl _ak820_outline_0182
                                   1098 	.globl _ak820_outline_0186
                                   1099 	.globl _ak820_outline_0190
                                   1100 
                                   1101 	.area CSEG (CODE)
                                   1102 ; function ak820_outline_0035
      006FA3                       1103 _ak820_outline_0035:
      006FA3 74 02            [12] 1104 	mov	a,#0x02
      006FA5 2E               [12] 1105 	add	a,r6
      006FA6 FE               [12] 1106 	mov	r6,a
      006FA7 E4               [12] 1107 	clr	a
      006FA8 3F               [12] 1108 	addc	a,r7
      006FA9 FF               [12] 1109 	mov	r7,a
      006FAA EC               [12] 1110 	mov	a,r4
      006FAB 2E               [12] 1111 	add	a,r6
      006FAC FC               [12] 1112 	mov	r4,a
      006FAD E4               [12] 1113 	clr	a
      006FAE 3F               [12] 1114 	addc	a,r7
      006FAF FB               [12] 1115 	mov	r3,a
      006FB0 74 07            [12] 1116 	mov	a,#0x07
      006FB2 5D               [12] 1117 	anl	a,r5
      006FB3 F5 F0            [12] 1118 	mov	b,a
      006FB5 05 F0            [12] 1119 	inc	b
      006FB7 74 01            [12] 1120 	mov	a,#0x01
      006FB9 22               [24] 1121 	ret
                                   1122 
                                   1123 	.area CSEG (CODE)
                                   1124 ; function ak820_outline_0050
      006FBA                       1125 _ak820_outline_0050:
      006FBA 8E 82            [24] 1126 	mov	dpl,r6
      006FBC 8F 83            [24] 1127 	mov	dph,r7
      006FBE 8D F0            [24] 1128 	mov	b,r5
      006FC0 22               [24] 1129 	ret
                                   1130 
                                   1131 	.area CSEG (CODE)
                                   1132 ; function ak820_outline_0103
      006FC1                       1133 _ak820_outline_0103:
      006FC1 F0               [24] 1134 	movx	@dptr,a
      006FC2 8B 82            [24] 1135 	mov	dpl,r3
      006FC4 8C 83            [24] 1136 	mov	dph,r4
      006FC6 22               [24] 1137 	ret
                                   1138 
                                   1139 	.area CSEG (CODE)
                                   1140 ; function ak820_outline_0131
      006FC7                       1141 _ak820_outline_0131:
      006FC7 F4               [12] 1142 	cpl	a
      006FC8 24 01            [12] 1143 	add	a,#0x01
      006FCA C5 F0            [12] 1144 	xch	a,b
      006FCC F4               [12] 1145 	cpl	a
      006FCD 34 00            [12] 1146 	addc	a,#0x00
      006FCF C5 F0            [12] 1147 	xch	a,b
      006FD1 22               [24] 1148 	ret
                                   1149 
                                   1150 	.area CSEG (CODE)
                                   1151 ; function ak820_outline_0147
      006FD2                       1152 _ak820_outline_0147:
      006FD2 74 02            [12] 1153 	mov	a,#0x02
      006FD4 2E               [12] 1154 	add	a,r6
      006FD5 FB               [12] 1155 	mov	r3,a
      006FD6 E4               [12] 1156 	clr	a
      006FD7 3F               [12] 1157 	addc	a,r7
      006FD8 FC               [12] 1158 	mov	r4,a
      006FD9 ED               [12] 1159 	mov	a,r5
      006FDA 2B               [12] 1160 	add	a,r3
      006FDB 22               [24] 1161 	ret
                                   1162 
                                   1163 	.area CSEG (CODE)
                                   1164 ; function ak820_outline_0153
      006FDC                       1165 _ak820_outline_0153:
      006FDC 8E 03            [24] 1166 	mov	ar3,r6
      006FDE 8F 04            [24] 1167 	mov	ar4,r7
      006FE0 7D 00            [12] 1168 	mov	r5,#0x00
      006FE2 22               [24] 1169 	ret
                                   1170 
                                   1171 	.area CSEG (CODE)
                                   1172 ; function ak820_outline_0182
      006FE3                       1173 _ak820_outline_0182:
      006FE3 90 0D AF         [24] 1174 	mov	dptr,#_memset_PARM_2
      006FE6 E4               [12] 1175 	clr	a
      006FE7 F0               [24] 1176 	movx	@dptr,a
      006FE8 90 0D B0         [24] 1177 	mov	dptr,#_memset_PARM_3
      006FEB 22               [24] 1178 	ret
