                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000815                        616 _tp_buttons::
      000815                        617 	.ds 2
      000817                        618 _action_exec_PARM_1:
      000817                        619 	.ds 6
      00081D                        620 _action_exec_record_10001_625:
      00081D                        621 	.ds 9
      000826                        622 _ak820_action_exec_event_10000_629:
      000826                        623 	.ds 2
      000828                        624 _ak820_action_exec_snapshot_10000_630:
      000828                        625 	.ds 6
      00082E                        626 _process_record_record_10000_633:
      00082E                        627 	.ds 3
      000831                        628 _process_record_handler_record_argument_10000_641:
      000831                        629 	.ds 3
      000834                        630 _process_record_handler_action_10000_642:
      000834                        631 	.ds 2
      000836                        632 _process_action_PARM_2:
      000836                        633 	.ds 2
      000838                        634 _process_action_record_argument_10000_653:
      000838                        635 	.ds 3
      00083B                        636 _process_action_on_40000_676:
      00083B                        637 	.ds 1
      00083C                        638 _register_code_code_10000_710:
      00083C                        639 	.ds 1
      00083D                        640 _unregister_code_code_10000_724:
      00083D                        641 	.ds 1
      00083E                        642 _tap_code_delay_PARM_2:
      00083E                        643 	.ds 2
      000840                        644 _tap_code_delay_code_10000_737:
      000840                        645 	.ds 1
      000841                        646 _tap_code_code_10000_744:
      000841                        647 	.ds 1
      000842                        648 _register_mods_mods_10000_746:
      000842                        649 	.ds 1
      000843                        650 _unregister_mods_mods_10000_750:
      000843                        651 	.ds 1
      000844                        652 _register_weak_mods_mods_10000_754:
      000844                        653 	.ds 1
      000845                        654 _unregister_weak_mods_mods_10000_758:
      000845                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC7                        664 _disable_action_cache::
      000DC7                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      00704F                        709 _action_exec:
                                    710 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      00704F 90 08 19         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007052 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      007055 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      007058 90 08 17         [24]  715 	mov	dptr,#_action_exec_PARM_1
      00705B 12 44 4E         [24]  716 	lcall	_ak820_tapping_before
      00705E E5 82            [12]  717 	mov	a, dpl
      007060 70 01            [24]  718 	jnz	00102$
      007062 22               [24]  719 	ret
      007063                        720 00102$:
                                    721 ;	quantum/action.c:113: if (event.pressed) {
      007063 90 08 1C         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007066 E0               [24]  723 	movx	a,@dptr
      007067 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:115: clear_weak_mods();
      007069 12 81 14         [24]  726 	lcall	_clear_weak_mods
      00706C                        727 00104$:
                                    728 ;	quantum/action.c:127: record.event = event;
      00706C 90 0D A7         [24]  729 	mov	dptr,#___memcpy_PARM_2
      00706F 74 17            [12]  730 	mov	a,#_action_exec_PARM_1
      007071 F0               [24]  731 	movx	@dptr,a
      007072 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      007074 12 38 70         [24]  733 	lcall	_ak820_outline_0093
      007077 12 77 25         [24]  734 	lcall	_ak820_outline_0071
      00707A 90 08 1D         [24]  735 	mov	dptr,#_action_exec_record_10001_625
      00707D F5 F0            [12]  736 	mov	b,a
      00707F 12 B8 C0         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:129: record.tap.count = 0;
      007082 90 08 23         [24]  739 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      007085 E0               [24]  740 	movx	a,@dptr
      007086 54 0F            [12]  741 	anl	a,#0x0f
      007088 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:134: record.keycode = 0;
      007089 90 08 24         [24]  744 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      00708C 12 4F 53         [24]  745 	lcall	_ak820_outline_0184
                                    746 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00708F 90 08 21         [24]  747 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      007092 E0               [24]  748 	movx	a,@dptr
      007093 60 0D            [24]  749 	jz	00107$
      007095 90 08 1D         [24]  750 	mov	dptr,#_action_exec_record_10001_625
      007098 75 F0 00         [24]  751 	mov	b, #0x00
      00709B 12 9E F9         [24]  752 	lcall	_pre_process_record_quantum
      00709E E5 82            [12]  753 	mov	a, dpl
      0070A0 60 14            [24]  754 	jz	00110$
      0070A2                        755 00107$:
                                    756 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      0070A2 90 08 1D         [24]  757 	mov	dptr,#_action_exec_record_10001_625
      0070A5 12 45 2D         [24]  758 	lcall	_ak820_tapping_process
      0070A8 E5 82            [12]  759 	mov	a, dpl
      0070AA 70 01            [24]  760 	jnz	00106$
      0070AC 22               [24]  761 	ret
      0070AD                        762 00106$:
                                    763 ;	quantum/action.c:172: process_record(&record);
      0070AD 90 08 1D         [24]  764 	mov	dptr,#_action_exec_record_10001_625
      0070B0 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:182: }
      0070B3 02 70 F3         [24]  767 	ljmp	_process_record
      0070B6                        768 00110$:
      0070B6 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      0070B7                        780 _ak820_action_exec:
      0070B7 12 38 82         [24]  781 	lcall	_ak820_outline_0109
      0070BA 90 08 26         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      0070BD 12 38 87         [24]  783 	lcall	_ak820_outline_0110
                                    784 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      0070C0 90 08 26         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_629
      0070C3 12 38 6A         [24]  786 	lcall	_ak820_outline_0085
      0070C6 7F 00            [12]  787 	mov	r7,#0x00
      0070C8 90 0D A7         [24]  788 	mov	dptr,#___memcpy_PARM_2
      0070CB ED               [12]  789 	mov	a,r5
      0070CC 12 38 1F         [24]  790 	lcall	_ak820_outline_0016
      0070CF 12 77 25         [24]  791 	lcall	_ak820_outline_0071
      0070D2 90 08 28         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      0070D5 F5 F0            [12]  793 	mov	b,a
      0070D7 12 B8 C0         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:189: action_exec(snapshot);
      0070DA 90 0D A7         [24]  796 	mov	dptr,#___memcpy_PARM_2
      0070DD 74 28            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_630
      0070DF F0               [24]  798 	movx	@dptr,a
      0070E0 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      0070E2 12 38 70         [24]  800 	lcall	_ak820_outline_0093
      0070E5 12 77 25         [24]  801 	lcall	_ak820_outline_0071
      0070E8 90 08 17         [24]  802 	mov	dptr,#_action_exec_PARM_1
      0070EB F5 F0            [12]  803 	mov	b,a
      0070ED 12 B8 C0         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:190: }
      0070F0 02 70 4F         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      0070F3                        816 _process_record:
      0070F3 12 43 15         [24]  817 	lcall	_ak820_outline_0036
      0070F6 90 08 2E         [24]  818 	mov	dptr,#_process_record_record_10000_633
      0070F9 12 38 1F         [24]  819 	lcall	_ak820_outline_0016
                                    820 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      0070FC 90 08 2E         [24]  821 	mov	dptr,#_process_record_record_10000_633
      0070FF 12 4F 00         [24]  822 	lcall	_ak820_outline_0012
      007102 74 04            [12]  823 	mov	a,#0x04
      007104 12 76 F8         [24]  824 	lcall	_ak820_outline_0014
      007107 12 B9 99         [24]  825 	lcall	__gptrget
      00710A 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:330: return;
      00710C 22               [24]  828 	ret
      00710D                        829 00102$:
                                    830 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00710D 8D 02            [24]  831 	mov	ar2,r5
      00710F 8E 03            [24]  832 	mov	ar3,r6
      007111 8F 04            [24]  833 	mov	ar4,r7
      007113 90 0D A7         [24]  834 	mov	dptr,#___memcpy_PARM_2
      007116 EA               [12]  835 	mov	a,r2
      007117 12 77 6C         [24]  836 	lcall	_ak820_outline_0189
      00711A EC               [12]  837 	mov	a,r4
      00711B A3               [24]  838 	inc	dptr
      00711C F0               [24]  839 	movx	@dptr,a
      00711D 90 0D AA         [24]  840 	mov	dptr,#___memcpy_PARM_3
      007120 12 4F 45         [24]  841 	lcall	_ak820_outline_0112
      007123 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      007126 F5 F0            [12]  843 	mov	b,a
      007128 C0 07            [24]  844 	push	ar7
      00712A C0 06            [24]  845 	push	ar6
      00712C C0 05            [24]  846 	push	ar5
      00712E 12 B8 C0         [24]  847 	lcall	___memcpy
      007131 12 43 88         [24]  848 	lcall	_ak820_tapping_source
      007134 AC 82            [24]  849 	mov	r4, dpl
      007136 D0 05            [24]  850 	pop	ar5
      007138 D0 06            [24]  851 	pop	ar6
      00713A D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      00713C 74 05            [12]  854 	mov	a,#0x05
      00713E 12 76 EA         [24]  855 	lcall	_ak820_outline_0013
      007141 12 B9 99         [24]  856 	lcall	__gptrget
      007144 FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      007145 12 77 51         [24]  859 	lcall	_ak820_outline_0148
      007148 90 0B FE         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      00714B 74 01            [12]  861 	mov	a,#0x01
      00714D 12 4F 09         [24]  862 	lcall	_ak820_outline_0034
      007150 C0 04            [24]  863 	push	ar4
      007152 C0 03            [24]  864 	push	ar3
      007154 C0 02            [24]  865 	push	ar2
      007156 C0 01            [24]  866 	push	ar1
      007158 C0 00            [24]  867 	push	ar0
      00715A 12 9E BB         [24]  868 	lcall	_get_record_keycode
      00715D 12 43 57         [24]  869 	lcall	_ak820_outline_0136
      007160 D0 00            [24]  870 	pop	ar0
      007162 D0 01            [24]  871 	pop	ar1
      007164 D0 02            [24]  872 	pop	ar2
      007166 D0 03            [24]  873 	pop	ar3
      007168 D0 04            [24]  874 	pop	ar4
      00716A 12 48 C9         [24]  875 	lcall	_ak820_outline_0114
      00716D EE               [12]  876 	mov	a,r6
      00716E 12 B9 5E         [24]  877 	lcall	__gptrput
      007171 A3               [24]  878 	inc	dptr
      007172 EF               [12]  879 	mov	a,r7
      007173 12 B9 5E         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007176 90 08 2E         [24]  882 	mov	dptr,#_process_record_record_10000_633
      007179 12 4F 00         [24]  883 	lcall	_ak820_outline_0012
      00717C 12 77 51         [24]  884 	lcall	_ak820_outline_0148
      00717F 12 48 C9         [24]  885 	lcall	_ak820_outline_0114
      007182 12 B9 99         [24]  886 	lcall	__gptrget
      007185 F8               [12]  887 	mov	r0,a
      007186 A3               [24]  888 	inc	dptr
      007187 12 B9 99         [24]  889 	lcall	__gptrget
      00718A F9               [12]  890 	mov	r1,a
      00718B 90 06 34         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00718E EC               [12]  892 	mov	a,r4
      00718F F0               [24]  893 	movx	@dptr,a
      007190 90 06 35         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007193 EB               [12]  895 	mov	a,r3
      007194 F0               [24]  896 	movx	@dptr,a
      007195 12 38 B6         [24]  897 	lcall	_ak820_outline_0160
      007198 C0 07            [24]  898 	push	ar7
      00719A C0 06            [24]  899 	push	ar6
      00719C C0 05            [24]  900 	push	ar5
      00719E C0 04            [24]  901 	push	ar4
      0071A0 C0 03            [24]  902 	push	ar3
      0071A2 12 46 E6         [24]  903 	lcall	_ak820_oneshot_process
      0071A5 E5 82            [12]  904 	mov	a, dpl
      0071A7 D0 03            [24]  905 	pop	ar3
      0071A9 D0 04            [24]  906 	pop	ar4
      0071AB D0 05            [24]  907 	pop	ar5
      0071AD D0 06            [24]  908 	pop	ar6
      0071AF D0 07            [24]  909 	pop	ar7
      0071B1 70 01            [24]  910 	jnz	00104$
      0071B3 22               [24]  911 	ret
      0071B4                        912 00104$:
                                    913 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      0071B4 12 6D 94         [24]  914 	lcall	_ak820_outline_0059
      0071B7 C0 04            [24]  915 	push	ar4
      0071B9 C0 03            [24]  916 	push	ar3
      0071BB 12 9F 81         [24]  917 	lcall	_process_record_quantum
      0071BE E5 82            [12]  918 	mov	a, dpl
      0071C0 D0 03            [24]  919 	pop	ar3
      0071C2 D0 04            [24]  920 	pop	ar4
      0071C4 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0071C6 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0071C9 EB               [12]  924 	mov	a,r3
      0071CA F0               [24]  925 	movx	@dptr,a
      0071CB 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:352: return;
      0071CD 02 2E BB         [24]  928 	ljmp	_ak820_oneshot_post
      0071D0                        929 00106$:
                                    930 ;	quantum/action.c:358: process_record_handler(record);
      0071D0 90 08 2E         [24]  931 	mov	dptr,#_process_record_record_10000_633
      0071D3 12 4E DA         [24]  932 	lcall	_ak820_outline_0001
      0071D6 C0 04            [24]  933 	push	ar4
      0071D8 C0 03            [24]  934 	push	ar3
      0071DA 12 71 F4         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:362: post_process_record_quantum(record);
      0071DD 90 08 2E         [24]  937 	mov	dptr,#_process_record_record_10000_633
      0071E0 12 4E DA         [24]  938 	lcall	_ak820_outline_0001
      0071E3 12 9F 56         [24]  939 	lcall	_post_process_record_quantum
      0071E6 D0 03            [24]  940 	pop	ar3
      0071E8 D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0071EA 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0071ED EB               [12]  944 	mov	a,r3
      0071EE F0               [24]  945 	movx	@dptr,a
      0071EF 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:366: }
      0071F1 02 2E BB         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      0071F4                        960 _process_record_handler:
      0071F4 12 43 15         [24]  961 	lcall	_ak820_outline_0036
      0071F7 90 08 31         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0071FA 12 38 1F         [24]  963 	lcall	_ak820_outline_0016
                                    964 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071FD 90 08 31         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007200 12 37 FE         [24]  966 	lcall	_ak820_outline_0007
                                    967 ;	quantum/action.c:379: if (record->keycode) {
      007203 4C               [12]  968 	orl	a,r4
      007204 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      007206 12 38 97         [24]  971 	lcall	_ak820_outline_0126
      007209 C0 07            [24]  972 	push	ar7
      00720B C0 06            [24]  973 	push	ar6
      00720D 12 94 F8         [24]  974 	lcall	_action_for_keycode
      007210 12 43 68         [24]  975 	lcall	_ak820_outline_0151
      007213 D0 06            [24]  976 	pop	ar6
      007215 D0 07            [24]  977 	pop	ar7
      007217 90 08 34         [24]  978 	mov	dptr,#_process_record_handler_action_10000_642
      00721A 12 38 5E         [24]  979 	lcall	_ak820_outline_0072
      00721D 80 2B            [24]  980 	sjmp	00104$
      00721F                        981 00102$:
                                    982 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00721F 12 77 06         [24]  983 	lcall	_ak820_outline_0020
      007222 7A 00            [12]  984 	mov	r2,#0x00
      007224 12 43 62         [24]  985 	lcall	_ak820_outline_0144
      007227 12 43 03         [24]  986 	lcall	_ak820_outline_0011
      00722A E0               [24]  987 	movx	a,@dptr
      00722B 90 09 70         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      00722E F0               [24]  989 	movx	@dptr,a
      00722F 8D 82            [24]  990 	mov	dpl, r5
      007231 8C 83            [24]  991 	mov	dph, r4
      007233 C0 07            [24]  992 	push	ar7
      007235 C0 06            [24]  993 	push	ar6
      007237 12 7A AD         [24]  994 	lcall	_ak820_resolve_key
      00723A 12 94 F8         [24]  995 	lcall	_action_for_keycode
      00723D 12 43 68         [24]  996 	lcall	_ak820_outline_0151
      007240 D0 06            [24]  997 	pop	ar6
      007242 D0 07            [24]  998 	pop	ar7
      007244 90 08 34         [24]  999 	mov	dptr,#_process_record_handler_action_10000_642
      007247 12 38 5E         [24] 1000 	lcall	_ak820_outline_0072
                                   1001 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      00724A                       1002 00104$:
                                   1003 ;	quantum/action.c:403: process_action(record, action);
      00724A 7D 00            [12] 1004 	mov	r5,#0x00
      00724C 90 0D A7         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      00724F 74 34            [12] 1006 	mov	a,#_process_record_handler_action_10000_642
      007251 F0               [24] 1007 	movx	@dptr,a
      007252 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007254 12 38 70         [24] 1009 	lcall	_ak820_outline_0093
      007257 90 0D AA         [24] 1010 	mov	dptr,#___memcpy_PARM_3
      00725A 12 4F 45         [24] 1011 	lcall	_ak820_outline_0112
      00725D 90 08 36         [24] 1012 	mov	dptr,#_process_action_PARM_2
      007260 F5 F0            [12] 1013 	mov	b,a
      007262 C0 07            [24] 1014 	push	ar7
      007264 C0 06            [24] 1015 	push	ar6
      007266 C0 05            [24] 1016 	push	ar5
      007268 12 B8 C0         [24] 1017 	lcall	___memcpy
      00726B D0 05            [24] 1018 	pop	ar5
      00726D D0 06            [24] 1019 	pop	ar6
      00726F D0 07            [24] 1020 	pop	ar7
      007271 12 6F BA         [24] 1021 	lcall	_ak820_outline_0050
                                   1022 ;	quantum/action.c:404: }
      007274 02 72 77         [24] 1023 	ljmp	_process_action
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'register_mouse'
                                   1026 ;------------------------------------------------------------
                                   1027 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1028 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_action
                                   1033 ;	-----------------------------------------
      007277                       1034 _process_action:
      007277 12 43 15         [24] 1035 	lcall	_ak820_outline_0036
      00727A 90 08 38         [24] 1036 	mov	dptr,#_process_action_record_argument_10000_653
      00727D 12 38 1F         [24] 1037 	lcall	_ak820_outline_0016
                                   1038 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007280 90 08 38         [24] 1039 	mov	dptr,#_process_action_record_argument_10000_653
      007283 12 37 F4         [24] 1040 	lcall	_ak820_outline_0005
                                   1041 ;	quantum/action.c:475: pressed = record->event.pressed;
      007286 A3               [24] 1042 	inc	dptr
      007287 A3               [24] 1043 	inc	dptr
      007288 A3               [24] 1044 	inc	dptr
      007289 A3               [24] 1045 	inc	dptr
      00728A A3               [24] 1046 	inc	dptr
      00728B E0               [24] 1047 	movx	a,@dptr
      00728C F5 27            [12] 1048 	mov	_process_action_sloc0_1_0,a
                                   1049 ;	quantum/action.c:499: switch (action.kind.id) {
      00728E 90 08 37         [24] 1050 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007291 E0               [24] 1051 	movx	a,@dptr
      007292 C4               [12] 1052 	swap	a
      007293 54 0F            [12] 1053 	anl	a,#0x0f
      007295 FD               [12] 1054 	mov  r5,a
      007296 24 F4            [12] 1055 	add	a,#0xff - 0x0b
      007298 50 03            [24] 1056 	jnc	00434$
      00729A 02 75 18         [24] 1057 	ljmp	00181$
      00729D                       1058 00434$:
                                   1059 ;	free result
      00729D ED               [12] 1060 	mov	a,r5
      00729E 24 0A            [12] 1061 	add	a,#(00435$-3-.)
      0072A0 83               [24] 1062 	movc	a,@a+pc
      0072A1 F5 82            [12] 1063 	mov	dpl,a
      0072A3 ED               [12] 1064 	mov	a,r5
      0072A4 24 10            [12] 1065 	add	a,#(00436$-3-.)
      0072A6 83               [24] 1066 	movc	a,@a+pc
      0072A7 F5 83            [12] 1067 	mov	dph,a
      0072A9 E4               [12] 1068 	clr	a
      0072AA 73               [24] 1069 	jmp	@a+dptr
      0072AB                       1070 00435$:
      0072AB C3                    1071 	.db	00102$
      0072AC C3                    1072 	.db	00102$
      0072AD 18                    1073 	.db	00181$
      0072AE 18                    1074 	.db	00181$
      0072AF 4D                    1075 	.db	00123$
      0072B0 18                    1076 	.db	00181$
      0072B1 18                    1077 	.db	00181$
      0072B2 18                    1078 	.db	00181$
      0072B3 AD                    1079 	.db	00131$
      0072B4 7F                    1080 	.db	00147$
      0072B5 A5                    1081 	.db	00152$
      0072B6 A5                    1082 	.db	00152$
      0072B7                       1083 00436$:
      0072B7 72                    1084 	.db	00102$>>8
      0072B8 72                    1085 	.db	00102$>>8
      0072B9 75                    1086 	.db	00181$>>8
      0072BA 75                    1087 	.db	00181$>>8
      0072BB 73                    1088 	.db	00123$>>8
      0072BC 75                    1089 	.db	00181$>>8
      0072BD 75                    1090 	.db	00181$>>8
      0072BE 75                    1091 	.db	00181$>>8
      0072BF 73                    1092 	.db	00131$>>8
      0072C0 74                    1093 	.db	00147$>>8
      0072C1 74                    1094 	.db	00152$>>8
      0072C2 74                    1095 	.db	00152$>>8
                                   1096 ;	quantum/action.c:502: case ACT_RMODS: {
      0072C3                       1097 00102$:
                                   1098 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0072C3 90 08 37         [24] 1099 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072C6 E0               [24] 1100 	movx	a,@dptr
      0072C7 54 F0            [12] 1101 	anl	a,#0xf0
      0072C9 70 06            [24] 1102 	jnz	00194$
      0072CB 12 77 3F         [24] 1103 	lcall	_ak820_outline_0115
      0072CE FD               [12] 1104 	mov	r5,a
      0072CF 80 07            [24] 1105 	sjmp	00195$
      0072D1                       1106 00194$:
      0072D1 12 77 3F         [24] 1107 	lcall	_ak820_outline_0115
      0072D4 C4               [12] 1108 	swap	a
      0072D5 54 F0            [12] 1109 	anl	a,#0xf0
      0072D7 FD               [12] 1110 	mov	r5,a
      0072D8                       1111 00195$:
                                   1112 ;	quantum/action.c:505: if (pressed) {
      0072D8 E5 27            [12] 1113 	mov	a,_process_action_sloc0_1_0
      0072DA 60 35            [24] 1114 	jz	00119$
                                   1115 ;	quantum/action.c:506: if (mods) {
      0072DC ED               [12] 1116 	mov	a,r5
      0072DD 60 29            [24] 1117 	jz	00110$
                                   1118 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072DF 12 77 5B         [24] 1119 	lcall	_ak820_outline_0162
      0072E2 FC               [12] 1120 	mov	r4,a
      0072E3 BC E0 00         [24] 1121 	cjne	r4,#0xe0,00440$
      0072E6                       1122 00440$:
      0072E6 40 07            [24] 1123 	jc	00108$
      0072E8 12 77 5B         [24] 1124 	lcall	_ak820_outline_0162
      0072EB 24 18            [12] 1125 	add	a,#0xff - 0xe7
      0072ED 50 0A            [24] 1126 	jnc	00104$
                                   1127 ;	free result
      0072EF                       1128 00108$:
      0072EF 7B 36            [12] 1129 	mov	r3,#_process_action_PARM_2
      0072F1 7C 08            [12] 1130 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072F3 12 33 FC         [24] 1131 	lcall	_ak820_outline_0125
      0072F6 E0               [24] 1132 	movx	a,@dptr
      0072F7 70 07            [24] 1133 	jnz	00105$
      0072F9                       1134 00104$:
                                   1135 ;	quantum/action.c:511: add_owned_mods(mods);
      0072F9 8D 82            [24] 1136 	mov	dpl, r5
      0072FB 12 7D 17         [24] 1137 	lcall	_add_owned_mods
      0072FE 80 05            [24] 1138 	sjmp	00106$
      007300                       1139 00105$:
                                   1140 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007300 8D 82            [24] 1141 	mov	dpl, r5
      007302 12 7D 36         [24] 1142 	lcall	_add_owned_weak_mods
      007305                       1143 00106$:
                                   1144 ;	quantum/action.c:515: send_keyboard_report();
      007305 12 80 5B         [24] 1145 	lcall	_send_keyboard_report
      007308                       1146 00110$:
                                   1147 ;	quantum/action.c:517: register_code(action.key.code);
      007308 12 77 2F         [24] 1148 	lcall	_ak820_outline_0077
      00730B 12 75 2F         [24] 1149 	lcall	_register_code
      00730E 02 75 18         [24] 1150 	ljmp	00181$
      007311                       1151 00119$:
                                   1152 ;	quantum/action.c:519: unregister_code(action.key.code);
      007311 12 77 2F         [24] 1153 	lcall	_ak820_outline_0077
      007314 C0 05            [24] 1154 	push	ar5
      007316 12 75 9C         [24] 1155 	lcall	_unregister_code
      007319 D0 05            [24] 1156 	pop	ar5
                                   1157 ;	quantum/action.c:520: if (mods) {
      00731B ED               [12] 1158 	mov	a,r5
      00731C 70 03            [24] 1159 	jnz	00444$
      00731E 02 75 18         [24] 1160 	ljmp	00181$
      007321                       1161 00444$:
                                   1162 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007321 12 77 5B         [24] 1163 	lcall	_ak820_outline_0162
      007324 FC               [12] 1164 	mov	r4,a
      007325 BC E0 00         [24] 1165 	cjne	r4,#0xe0,00445$
      007328                       1166 00445$:
      007328 40 07            [24] 1167 	jc	00115$
      00732A 12 77 5B         [24] 1168 	lcall	_ak820_outline_0162
      00732D 24 18            [12] 1169 	add	a,#0xff - 0xe7
      00732F 50 0A            [24] 1170 	jnc	00111$
                                   1171 ;	free result
      007331                       1172 00115$:
      007331 7B 36            [12] 1173 	mov	r3,#_process_action_PARM_2
      007333 7C 08            [12] 1174 	mov	r4,#(_process_action_PARM_2 >> 8)
      007335 12 33 FC         [24] 1175 	lcall	_ak820_outline_0125
      007338 E0               [24] 1176 	movx	a,@dptr
      007339 70 07            [24] 1177 	jnz	00112$
      00733B                       1178 00111$:
                                   1179 ;	quantum/action.c:522: del_owned_mods(mods);
      00733B 8D 82            [24] 1180 	mov	dpl, r5
      00733D 12 7D 27         [24] 1181 	lcall	_del_owned_mods
      007340 80 05            [24] 1182 	sjmp	00113$
      007342                       1183 00112$:
                                   1184 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007342 8D 82            [24] 1185 	mov	dpl, r5
      007344 12 7D 46         [24] 1186 	lcall	_del_owned_weak_mods
      007347                       1187 00113$:
                                   1188 ;	quantum/action.c:526: send_keyboard_report();
      007347 12 80 5B         [24] 1189 	lcall	_send_keyboard_report
                                   1190 ;	quantum/action.c:529: } break;
      00734A 02 75 18         [24] 1191 	ljmp	00181$
                                   1192 ;	quantum/action.c:606: case ACT_USAGE:
      00734D                       1193 00123$:
                                   1194 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00734D 74 07            [12] 1195 	mov	a,#0x07
      00734F 12 38 31         [24] 1196 	lcall	_ak820_outline_0021
      007352 12 48 37         [24] 1197 	lcall	_ak820_outline_0008
      007355 C3               [12] 1198 	clr	c
      007356 EC               [12] 1199 	mov	a,r4
      007357 94 A5            [12] 1200 	subb	a,#0xa5
      007359 ED               [12] 1201 	mov	a,r5
      00735A 94 00            [12] 1202 	subb	a,#0x00
      00735C 40 15            [24] 1203 	jc	00125$
      00735E 74 C2            [12] 1204 	mov	a,#0xc2
      007360 9C               [12] 1205 	subb	a,r4
      007361 E4               [12] 1206 	clr	a
      007362 9D               [12] 1207 	subb	a,r5
      007363 40 0E            [24] 1208 	jc	00125$
                                   1209 ;	free result
                                   1210 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007365 90 0A 9A         [24] 1211 	mov	dptr,#_owned_usage_key_PARM_2
      007368 E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      00736A F0               [24] 1213 	movx	@dptr,a
      00736B 8E 82            [24] 1214 	mov	dpl, r6
      00736D 12 7F 06         [24] 1215 	lcall	_owned_usage_key
                                   1216 ;	quantum/action.c:614: break;
      007370 02 75 18         [24] 1217 	ljmp	00181$
      007373                       1218 00125$:
                                   1219 ;	quantum/action.c:617: switch (action.usage.page) {
      007373 12 77 36         [24] 1220 	lcall	_ak820_outline_0089
      007376 FF               [12] 1221 	mov	r7,a
      007377 60 08            [24] 1222 	jz	00127$
      007379 BF 01 02         [24] 1223 	cjne	r7,#0x01,00452$
      00737C 80 19            [24] 1224 	sjmp	00128$
      00737E                       1225 00452$:
      00737E 02 75 18         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007381                       1228 00127$:
                                   1229 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007381 E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      007383 60 05            [24] 1231 	jz	00196$
      007385 12 77 46         [24] 1232 	lcall	_ak820_outline_0132
      007388 80 04            [24] 1233 	sjmp	00197$
      00738A                       1234 00196$:
      00738A 7E 00            [12] 1235 	mov	r6,#0x00
      00738C 7F 00            [12] 1236 	mov	r7,#0x00
      00738E                       1237 00197$:
      00738E 12 38 8C         [24] 1238 	lcall	_ak820_outline_0120
      007391 12 6D 1E         [24] 1239 	lcall	_host_system_send
                                   1240 ;	quantum/action.c:620: break;
      007394 02 75 18         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:621: case PAGE_CONSUMER:
      007397                       1243 00128$:
                                   1244 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      007397 E5 27            [12] 1245 	mov	a,_process_action_sloc0_1_0
      007399 60 05            [24] 1246 	jz	00198$
      00739B 12 77 46         [24] 1247 	lcall	_ak820_outline_0132
      00739E 80 04            [24] 1248 	sjmp	00199$
      0073A0                       1249 00198$:
      0073A0 7E 00            [12] 1250 	mov	r6,#0x00
      0073A2 7F 00            [12] 1251 	mov	r7,#0x00
      0073A4                       1252 00199$:
      0073A4 12 38 8C         [24] 1253 	lcall	_ak820_outline_0120
      0073A7 12 6D 4E         [24] 1254 	lcall	_host_consumer_send
                                   1255 ;	quantum/action.c:625: break;
      0073AA 02 75 18         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:632: case ACT_LAYER: {
      0073AD                       1258 00131$:
                                   1259 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0073AD 90 08 37         [24] 1260 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073B0 E0               [24] 1261 	movx	a,@dptr
      0073B1 54 03            [12] 1262 	anl	a,#0x03
      0073B3 90 08 3B         [24] 1263 	mov	dptr,#_process_action_on_40000_676
      0073B6 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0073B7 E0               [24] 1266 	movx	a,@dptr
      0073B8 FF               [12] 1267 	mov	r7,a
      0073B9 60 11            [24] 1268 	jz	00200$
      0073BB E5 27            [12] 1269 	mov	a,_process_action_sloc0_1_0
      0073BD 60 07            [24] 1270 	jz	00202$
      0073BF 8F 06            [24] 1271 	mov	ar6,r7
      0073C1 53 06 01         [24] 1272 	anl	ar6,#0x01
      0073C4 80 10            [24] 1273 	sjmp	00201$
      0073C6                       1274 00202$:
      0073C6 74 02            [12] 1275 	mov	a,#0x02
      0073C8 5F               [12] 1276 	anl	a,r7
      0073C9 FE               [12] 1277 	mov	r6,a
      0073CA 80 0A            [24] 1278 	sjmp	00201$
      0073CC                       1279 00200$:
      0073CC E5 27            [12] 1280 	mov	a,_process_action_sloc0_1_0
      0073CE B4 01 00         [24] 1281 	cjne	a,#0x01,00457$
      0073D1                       1282 00457$:
      0073D1 92 1F            [24] 1283 	mov  _process_action_sloc1_1_0,c
      0073D3 E4               [12] 1284 	clr	a
      0073D4 33               [12] 1285 	rlc	a
      0073D5 FE               [12] 1286 	mov	r6,a
      0073D6                       1287 00201$:
      0073D6 EE               [12] 1288 	mov	a,r6
      0073D7 70 03            [24] 1289 	jnz	00458$
      0073D9 02 75 18         [24] 1290 	ljmp	00181$
      0073DC                       1291 00458$:
                                   1292 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      0073DC 12 77 5B         [24] 1293 	lcall	_ak820_outline_0162
      0073DF C4               [12] 1294 	swap	a
      0073E0 03               [12] 1295 	rr	a
      0073E1 54 07            [12] 1296 	anl	a,#0x07
      0073E3 25 E0            [12] 1297 	add	a,acc
      0073E5 25 E0            [12] 1298 	add	a,acc
      0073E7 FF               [12] 1299 	mov	r7,a
                                   1300 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0073E8 12 77 5B         [24] 1301 	lcall	_ak820_outline_0162
      0073EB 54 0F            [12] 1302 	anl	a,#0x0f
      0073ED FE               [12] 1303 	mov	r6,a
      0073EE 8F F0            [24] 1304 	mov	b,r7
      0073F0 05 F0            [12] 1305 	inc	b
      0073F2 EE               [12] 1306 	mov	a,r6
      0073F3 80 02            [24] 1307 	sjmp	00460$
      0073F5                       1308 00459$:
      0073F5 25 E0            [12] 1309 	add	a,acc
      0073F7                       1310 00460$:
      0073F7 D5 F0 FB         [24] 1311 	djnz	b,00459$
      0073FA FE               [12] 1312 	mov	r6,a
                                   1313 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0073FB 12 77 5B         [24] 1314 	lcall	_ak820_outline_0162
      0073FE 30 E4 11         [24] 1315 	jnb	acc.4,00204$
      007401 8F F0            [24] 1316 	mov	b,r7
      007403 05 F0            [12] 1317 	inc	b
      007405 74 0F            [12] 1318 	mov	a,#0x0f
      007407 80 02            [24] 1319 	sjmp	00463$
      007409                       1320 00462$:
      007409 25 E0            [12] 1321 	add	a,acc
      00740B                       1322 00463$:
      00740B D5 F0 FB         [24] 1323 	djnz	b,00462$
      00740E F4               [12] 1324 	cpl	a
      00740F FF               [12] 1325 	mov	r7,a
      007410 80 02            [24] 1326 	sjmp	00205$
      007412                       1327 00204$:
      007412 7F 00            [12] 1328 	mov	r7,#0x00
      007414                       1329 00205$:
                                   1330 ;	quantum/action.c:640: bits |= mask;
      007414 EE               [12] 1331 	mov	a,r6
      007415 42 07            [12] 1332 	orl	ar7,a
                                   1333 ;	quantum/action.c:641: if (!on) {
      007417 90 08 3B         [24] 1334 	mov	dptr,#_process_action_on_40000_676
      00741A E0               [24] 1335 	movx	a,@dptr
      00741B 70 31            [24] 1336 	jnz	00143$
                                   1337 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      00741D 12 77 36         [24] 1338 	lcall	_ak820_outline_0089
      007420 FE               [12] 1339 	mov	r6,a
      007421 2E               [12] 1340 	add	a,r6
                                   1341 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007422 90 74 26         [24] 1342 	mov	dptr,#00465$
      007425 73               [24] 1343 	jmp	@a+dptr
      007426                       1344 00465$:
      007426 80 06            [24] 1345 	sjmp	00132$
      007428 80 0C            [24] 1346 	sjmp	00133$
      00742A 80 12            [24] 1347 	sjmp	00134$
      00742C 80 18            [24] 1348 	sjmp	00135$
      00742E                       1349 00132$:
      00742E 8F 82            [24] 1350 	mov	dpl, r7
      007430 12 77 BB         [24] 1351 	lcall	_default_layer_and
      007433 02 75 18         [24] 1352 	ljmp	00181$
                                   1353 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      007436                       1354 00133$:
      007436 8F 82            [24] 1355 	mov	dpl, r7
      007438 12 77 AA         [24] 1356 	lcall	_default_layer_or
      00743B 02 75 18         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      00743E                       1359 00134$:
      00743E 8F 82            [24] 1360 	mov	dpl, r7
      007440 12 77 D1         [24] 1361 	lcall	_default_layer_xor
      007443 02 75 18         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      007446                       1364 00135$:
      007446 8F 82            [24] 1365 	mov	dpl, r7
      007448 12 77 9F         [24] 1366 	lcall	_default_layer_set
                                   1367 ;	quantum/action.c:647: }
      00744B 02 75 18         [24] 1368 	ljmp	00181$
      00744E                       1369 00143$:
                                   1370 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      00744E 12 77 36         [24] 1371 	lcall	_ak820_outline_0089
      007451 FE               [12] 1372 	mov	r6,a
      007452 2E               [12] 1373 	add	a,r6
                                   1374 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007453 90 74 57         [24] 1375 	mov	dptr,#00466$
      007456 73               [24] 1376 	jmp	@a+dptr
      007457                       1377 00466$:
      007457 80 06            [24] 1378 	sjmp	00137$
      007459 80 0C            [24] 1379 	sjmp	00138$
      00745B 80 12            [24] 1380 	sjmp	00139$
      00745D 80 18            [24] 1381 	sjmp	00140$
      00745F                       1382 00137$:
      00745F 8F 82            [24] 1383 	mov	dpl, r7
      007461 12 79 55         [24] 1384 	lcall	_layer_and
      007464 02 75 18         [24] 1385 	ljmp	00181$
                                   1386 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      007467                       1387 00138$:
      007467 8F 82            [24] 1388 	mov	dpl, r7
      007469 12 79 44         [24] 1389 	lcall	_layer_or
      00746C 02 75 18         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      00746F                       1392 00139$:
      00746F 8F 82            [24] 1393 	mov	dpl, r7
      007471 12 79 6B         [24] 1394 	lcall	_layer_xor
      007474 02 75 18         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007477                       1397 00140$:
      007477 8F 82            [24] 1398 	mov	dpl, r7
      007479 12 78 E1         [24] 1399 	lcall	_layer_state_set
                                   1400 ;	quantum/action.c:657: break;
      00747C 02 75 18         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      00747F                       1403 00147$:
                                   1404 ;	quantum/action.c:660: if (pressed) {
      00747F E5 27            [12] 1405 	mov	a,_process_action_sloc0_1_0
      007481 60 11            [24] 1406 	jz	00149$
                                   1407 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007483 12 77 3F         [24] 1408 	lcall	_ak820_outline_0115
      007486 F5 82            [12] 1409 	mov	dpl,a
      007488 12 78 41         [24] 1410 	lcall	_layer_hold_on
                                   1411 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      00748B 12 77 2F         [24] 1412 	lcall	_ak820_outline_0077
      00748E 12 76 52         [24] 1413 	lcall	_register_mods
      007491 02 75 18         [24] 1414 	ljmp	00181$
      007494                       1415 00149$:
                                   1416 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007494 12 77 2F         [24] 1417 	lcall	_ak820_outline_0077
      007497 12 76 66         [24] 1418 	lcall	_unregister_mods
                                   1419 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      00749A 12 77 3F         [24] 1420 	lcall	_ak820_outline_0115
      00749D F5 82            [12] 1421 	mov	dpl,a
      00749F 12 78 79         [24] 1422 	lcall	_layer_hold_off
                                   1423 ;	quantum/action.c:667: break;
      0074A2 02 75 18         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      0074A5                       1426 00152$:
                                   1427 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      0074A5 12 77 5B         [24] 1428 	lcall	_ak820_outline_0162
      0074A8 FF               [12] 1429 	mov	r7,a
      0074A9 BF F1 02         [24] 1430 	cjne	r7,#0xf1,00468$
      0074AC 80 0A            [24] 1431 	sjmp	00154$
      0074AE                       1432 00468$:
      0074AE BF F2 02         [24] 1433 	cjne	r7,#0xf2,00469$
      0074B1 80 19            [24] 1434 	sjmp	00155$
      0074B3                       1435 00469$:
                                   1436 ;	quantum/action.c:686: momentary_layer_action:
      0074B3 BF F3 3B         [24] 1437 	cjne	r7,#0xf3,00160$
      0074B6 80 28            [24] 1438 	sjmp	00156$
      0074B8                       1439 00154$:
                                   1440 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0074B8 E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      0074BA 60 08            [24] 1442 	jz	00206$
      0074BC 12 77 15         [24] 1443 	lcall	_ak820_outline_0042
      0074BF 12 78 41         [24] 1444 	lcall	_layer_hold_on
      0074C2 80 54            [24] 1445 	sjmp	00181$
      0074C4                       1446 00206$:
      0074C4 12 77 15         [24] 1447 	lcall	_ak820_outline_0042
      0074C7 12 78 79         [24] 1448 	lcall	_layer_hold_off
                                   1449 ;	quantum/action.c:688: break;
                                   1450 ;	quantum/action.c:689: case OP_OFF_ON:
      0074CA 80 4C            [24] 1451 	sjmp	00181$
      0074CC                       1452 00155$:
                                   1453 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0074CC E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      0074CE 60 08            [24] 1455 	jz	00208$
      0074D0 12 77 15         [24] 1456 	lcall	_ak820_outline_0042
      0074D3 12 79 26         [24] 1457 	lcall	_layer_off
      0074D6 80 40            [24] 1458 	sjmp	00181$
      0074D8                       1459 00208$:
      0074D8 12 77 15         [24] 1460 	lcall	_ak820_outline_0042
      0074DB 12 79 0B         [24] 1461 	lcall	_layer_on
                                   1462 ;	quantum/action.c:691: break;
                                   1463 ;	quantum/action.c:692: case OP_SET_CLEAR:
      0074DE 80 38            [24] 1464 	sjmp	00181$
      0074E0                       1465 00156$:
                                   1466 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0074E0 E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      0074E2 60 08            [24] 1468 	jz	00210$
      0074E4 12 77 15         [24] 1469 	lcall	_ak820_outline_0042
      0074E7 12 78 F5         [24] 1470 	lcall	_layer_move
      0074EA 80 2C            [24] 1471 	sjmp	00181$
      0074EC                       1472 00210$:
      0074EC 12 78 EF         [24] 1473 	lcall	_layer_clear
                                   1474 ;	quantum/action.c:694: break;
                                   1475 ;	quantum/action.c:740: default:
      0074EF 80 27            [24] 1476 	sjmp	00181$
      0074F1                       1477 00160$:
                                   1478 ;	quantum/action.c:747: if (pressed) {
      0074F1 E5 27            [12] 1479 	mov	a,_process_action_sloc0_1_0
      0074F3 60 08            [24] 1480 	jz	00163$
                                   1481 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      0074F5 12 77 2F         [24] 1482 	lcall	_ak820_outline_0077
      0074F8 12 75 2F         [24] 1483 	lcall	_register_code
                                   1484 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0074FB 80 1B            [24] 1485 	sjmp	00181$
      0074FD                       1486 00163$:
                                   1487 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      0074FD 12 77 5B         [24] 1488 	lcall	_ak820_outline_0162
      007500 FF               [12] 1489 	mov	r7,a
      007501 BF 39 0E         [24] 1490 	cjne	r7,#0x39,00175$
                                   1491 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007504 7F 50            [12] 1492 	mov	r7,#0x50
      007506                       1493 00187$:
      007506 EF               [12] 1494 	mov	a,r7
      007507 60 09            [24] 1495 	jz	00175$
      007509 90 00 01         [24] 1496 	mov	dptr,#0x0001
      00750C 12 58 CC         [24] 1497 	lcall	_mDelaymS
      00750F 1F               [12] 1498 	dec	r7
                                   1499 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007510 80 F4            [24] 1500 	sjmp	00187$
      007512                       1501 00175$:
                                   1502 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007512 12 77 2F         [24] 1503 	lcall	_ak820_outline_0077
      007515 12 75 9C         [24] 1504 	lcall	_unregister_code
                                   1505 ;	quantum/action.c:840: }
      007518                       1506 00181$:
                                   1507 ;	quantum/action.c:861: switch (action.kind.id) {
      007518 90 08 37         [24] 1508 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00751B E0               [24] 1509 	movx	a,@dptr
      00751C C4               [12] 1510 	swap	a
      00751D 54 0F            [12] 1511 	anl	a,#0x0f
      00751F FF               [12] 1512 	mov	r7,a
      007520 BF 08 02         [24] 1513 	cjne	r7,#0x08,00478$
      007523 80 03            [24] 1514 	sjmp	00183$
      007525                       1515 00478$:
      007525 BF 09 06         [24] 1516 	cjne	r7,#0x09,00192$
                                   1517 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      007528                       1518 00183$:
                                   1519 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      007528 12 6C 83         [24] 1520 	lcall	_host_keyboard_leds
                                   1521 ;	quantum/action.c:872: }
                                   1522 ;	quantum/action.c:925: }
      00752B 02 97 AD         [24] 1523 	ljmp	_led_set
      00752E                       1524 00192$:
      00752E 22               [24] 1525 	ret
                                   1526 ;------------------------------------------------------------
                                   1527 ;Allocation info for local variables in function 'register_code'
                                   1528 ;------------------------------------------------------------
                                   1529 ;code          Allocated with name '_register_code_code_10000_710'
                                   1530 ;------------------------------------------------------------
                                   1531 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1532 ;	-----------------------------------------
                                   1533 ;	 function register_code
                                   1534 ;	-----------------------------------------
      00752F                       1535 _register_code:
      00752F E5 82            [12] 1536 	mov	a,dpl
      007531 90 08 3C         [24] 1537 	mov	dptr,#_register_code_code_10000_710
      007534 F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/action.c:932: if (code == KC_NO) {
      007535 E0               [24] 1540 	movx	a,@dptr
      007536 FF               [12] 1541 	mov	r7,a
      007537 70 01            [24] 1542 	jnz	00123$
                                   1543 ;	quantum/action.c:933: return;
      007539 22               [24] 1544 	ret
      00753A                       1545 00123$:
                                   1546 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      00753A BF 04 00         [24] 1547 	cjne	r7,#0x04,00186$
      00753D                       1548 00186$:
      00753D 40 12            [24] 1549 	jc	00119$
      00753F EF               [12] 1550 	mov	a,r7
      007540 24 5B            [12] 1551 	add	a,#0xff - 0xa4
      007542 40 0D            [24] 1552 	jc	00119$
                                   1553 ;	free result
                                   1554 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007544 8F 82            [24] 1555 	mov	dpl, r7
      007546 12 7D BB         [24] 1556 	lcall	_add_owned_key
      007549 E5 82            [12] 1557 	mov	a, dpl
      00754B 70 01            [24] 1558 	jnz	00104$
      00754D 22               [24] 1559 	ret
      00754E                       1560 00104$:
                                   1561 ;	quantum/action.c:987: send_keyboard_report();
      00754E 02 80 5B         [24] 1562 	ljmp	_send_keyboard_report
      007551                       1563 00119$:
                                   1564 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007551 12 77 60         [24] 1565 	lcall	_ak820_outline_0170
      007554 BF E0 00         [24] 1566 	cjne	r7,#0xe0,00190$
      007557                       1567 00190$:
      007557 40 1A            [24] 1568 	jc	00115$
      007559 EF               [12] 1569 	mov	a,r7
      00755A 24 18            [12] 1570 	add	a,#0xff - 0xe7
      00755C 40 15            [24] 1571 	jc	00115$
                                   1572 ;	free result
                                   1573 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      00755E 74 07            [12] 1574 	mov	a,#0x07
      007560 5F               [12] 1575 	anl	a,r7
      007561 12 77 1E         [24] 1576 	lcall	_ak820_outline_0063
      007564 80 02            [24] 1577 	sjmp	00194$
      007566                       1578 00193$:
      007566 25 E0            [12] 1579 	add	a,acc
      007568                       1580 00194$:
      007568 D5 F0 FB         [24] 1581 	djnz	b,00193$
      00756B F5 82            [12] 1582 	mov	dpl,a
      00756D 12 7D 17         [24] 1583 	lcall	_add_owned_mods
                                   1584 ;	quantum/action.c:990: send_keyboard_report();
      007570 02 80 5B         [24] 1585 	ljmp	_send_keyboard_report
      007573                       1586 00115$:
                                   1587 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007573 12 77 60         [24] 1588 	lcall	_ak820_outline_0170
      007576 BF A5 00         [24] 1589 	cjne	r7,#0xa5,00195$
      007579                       1590 00195$:
      007579 40 05            [24] 1591 	jc	00113$
      00757B EF               [12] 1592 	mov	a,r7
      00757C 24 58            [12] 1593 	add	a,#0xff - 0xa7
      00757E 50 0D            [24] 1594 	jnc	00108$
                                   1595 ;	free result
      007580                       1596 00113$:
      007580 12 77 60         [24] 1597 	lcall	_ak820_outline_0170
      007583 BF A8 00         [24] 1598 	cjne	r7,#0xa8,00198$
      007586                       1599 00198$:
      007586 40 13            [24] 1600 	jc	00125$
      007588 EF               [12] 1601 	mov	a,r7
      007589 24 3D            [12] 1602 	add	a,#0xff - 0xc2
      00758B 40 0E            [24] 1603 	jc	00125$
                                   1604 ;	free result
      00758D                       1605 00108$:
                                   1606 ;	quantum/action.c:995: owned_usage_key(code, true);
      00758D 12 77 60         [24] 1607 	lcall	_ak820_outline_0170
      007590 90 0A 9A         [24] 1608 	mov	dptr,#_owned_usage_key_PARM_2
      007593 74 01            [12] 1609 	mov	a,#0x01
      007595 F0               [24] 1610 	movx	@dptr,a
      007596 8F 82            [24] 1611 	mov	dpl, r7
                                   1612 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1613 ;	quantum/action.c:1005: }
      007598 02 7F 06         [24] 1614 	ljmp	_owned_usage_key
      00759B                       1615 00125$:
      00759B 22               [24] 1616 	ret
                                   1617 ;------------------------------------------------------------
                                   1618 ;Allocation info for local variables in function 'unregister_code'
                                   1619 ;------------------------------------------------------------
                                   1620 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1621 ;------------------------------------------------------------
                                   1622 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1623 ;	-----------------------------------------
                                   1624 ;	 function unregister_code
                                   1625 ;	-----------------------------------------
      00759C                       1626 _unregister_code:
      00759C E5 82            [12] 1627 	mov	a,dpl
      00759E 90 08 3D         [24] 1628 	mov	dptr,#_unregister_code_code_10000_724
      0075A1 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action.c:1012: if (code == KC_NO) {
      0075A2 E0               [24] 1631 	movx	a,@dptr
      0075A3 FF               [12] 1632 	mov	r7,a
      0075A4 70 01            [24] 1633 	jnz	00121$
                                   1634 ;	quantum/action.c:1013: return;
      0075A6 22               [24] 1635 	ret
      0075A7                       1636 00121$:
                                   1637 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      0075A7 BF 04 00         [24] 1638 	cjne	r7,#0x04,00184$
      0075AA                       1639 00184$:
      0075AA 40 12            [24] 1640 	jc	00117$
      0075AC EF               [12] 1641 	mov	a,r7
      0075AD 24 5B            [12] 1642 	add	a,#0xff - 0xa4
      0075AF 40 0D            [24] 1643 	jc	00117$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      0075B1 8F 82            [24] 1646 	mov	dpl, r7
      0075B3 12 7E 38         [24] 1647 	lcall	_del_owned_key
      0075B6 E5 82            [12] 1648 	mov	a, dpl
      0075B8 70 01            [24] 1649 	jnz	00102$
      0075BA 22               [24] 1650 	ret
      0075BB                       1651 00102$:
                                   1652 ;	quantum/action.c:1054: send_keyboard_report();
      0075BB 02 80 5B         [24] 1653 	ljmp	_send_keyboard_report
      0075BE                       1654 00117$:
                                   1655 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      0075BE 12 77 66         [24] 1656 	lcall	_ak820_outline_0171
      0075C1 BF E0 00         [24] 1657 	cjne	r7,#0xe0,00188$
      0075C4                       1658 00188$:
      0075C4 40 1A            [24] 1659 	jc	00113$
      0075C6 EF               [12] 1660 	mov	a,r7
      0075C7 24 18            [12] 1661 	add	a,#0xff - 0xe7
      0075C9 40 15            [24] 1662 	jc	00113$
                                   1663 ;	free result
                                   1664 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      0075CB 74 07            [12] 1665 	mov	a,#0x07
      0075CD 5F               [12] 1666 	anl	a,r7
      0075CE 12 77 1E         [24] 1667 	lcall	_ak820_outline_0063
      0075D1 80 02            [24] 1668 	sjmp	00192$
      0075D3                       1669 00191$:
      0075D3 25 E0            [12] 1670 	add	a,acc
      0075D5                       1671 00192$:
      0075D5 D5 F0 FB         [24] 1672 	djnz	b,00191$
      0075D8 F5 82            [12] 1673 	mov	dpl,a
      0075DA 12 7D 27         [24] 1674 	lcall	_del_owned_mods
                                   1675 ;	quantum/action.c:1057: send_keyboard_report();
      0075DD 02 80 5B         [24] 1676 	ljmp	_send_keyboard_report
      0075E0                       1677 00113$:
                                   1678 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0075E0 12 77 66         [24] 1679 	lcall	_ak820_outline_0171
      0075E3 BF A5 00         [24] 1680 	cjne	r7,#0xa5,00193$
      0075E6                       1681 00193$:
      0075E6 40 05            [24] 1682 	jc	00111$
      0075E8 EF               [12] 1683 	mov	a,r7
      0075E9 24 58            [12] 1684 	add	a,#0xff - 0xa7
      0075EB 50 0D            [24] 1685 	jnc	00106$
                                   1686 ;	free result
      0075ED                       1687 00111$:
      0075ED 12 77 66         [24] 1688 	lcall	_ak820_outline_0171
      0075F0 BF A8 00         [24] 1689 	cjne	r7,#0xa8,00196$
      0075F3                       1690 00196$:
      0075F3 40 12            [24] 1691 	jc	00123$
      0075F5 EF               [12] 1692 	mov	a,r7
      0075F6 24 3D            [12] 1693 	add	a,#0xff - 0xc2
      0075F8 40 0D            [24] 1694 	jc	00123$
                                   1695 ;	free result
      0075FA                       1696 00106$:
                                   1697 ;	quantum/action.c:1062: owned_usage_key(code, false);
      0075FA 12 77 66         [24] 1698 	lcall	_ak820_outline_0171
      0075FD 90 0A 9A         [24] 1699 	mov	dptr,#_owned_usage_key_PARM_2
      007600 E4               [12] 1700 	clr	a
      007601 F0               [24] 1701 	movx	@dptr,a
      007602 8F 82            [24] 1702 	mov	dpl, r7
                                   1703 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1704 ;	quantum/action.c:1072: }
      007604 02 7F 06         [24] 1705 	ljmp	_owned_usage_key
      007607                       1706 00123$:
      007607 22               [24] 1707 	ret
                                   1708 ;------------------------------------------------------------
                                   1709 ;Allocation info for local variables in function 'tap_code_delay'
                                   1710 ;------------------------------------------------------------
                                   1711 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1712 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1715 ;------------------------------------------------------------
                                   1716 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1717 ;	-----------------------------------------
                                   1718 ;	 function tap_code_delay
                                   1719 ;	-----------------------------------------
      007608                       1720 _tap_code_delay:
      007608 E5 82            [12] 1721 	mov	a,dpl
      00760A 90 08 40         [24] 1722 	mov	dptr,#_tap_code_delay_code_10000_737
      00760D F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action.c:1080: register_code(code);
      00760E E0               [24] 1725 	movx	a,@dptr
      00760F FF               [12] 1726 	mov	r7,a
      007610 F5 82            [12] 1727 	mov	dpl,a
      007612 C0 07            [24] 1728 	push	ar7
      007614 12 75 2F         [24] 1729 	lcall	_register_code
      007617 D0 07            [24] 1730 	pop	ar7
                                   1731 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007619 90 08 3E         [24] 1732 	mov	dptr,#_tap_code_delay_PARM_2
      00761C 12 38 6A         [24] 1733 	lcall	_ak820_outline_0085
      00761F                       1734 00110$:
      00761F ED               [12] 1735 	mov	a,r5
      007620 4E               [12] 1736 	orl	a,r6
      007621 60 0D            [24] 1737 	jz	00105$
                                   1738 ;	quantum/action.c:1082: wait_ms(1);
      007623 90 00 01         [24] 1739 	mov	dptr,#0x0001
      007626 12 58 CC         [24] 1740 	lcall	_mDelaymS
                                   1741 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007629 1D               [12] 1742 	dec	r5
      00762A BD FF 01         [24] 1743 	cjne	r5,#0xff,00141$
      00762D 1E               [12] 1744 	dec	r6
      00762E                       1745 00141$:
      00762E 80 EF            [24] 1746 	sjmp	00110$
      007630                       1747 00105$:
                                   1748 ;	quantum/action.c:1084: unregister_code(code);
      007630 8F 82            [24] 1749 	mov	dpl, r7
                                   1750 ;	quantum/action.c:1085: }
      007632 02 75 9C         [24] 1751 	ljmp	_unregister_code
                                   1752 ;------------------------------------------------------------
                                   1753 ;Allocation info for local variables in function 'tap_code'
                                   1754 ;------------------------------------------------------------
                                   1755 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function tap_code
                                   1760 ;	-----------------------------------------
      007635                       1761 _tap_code:
      007635 E5 82            [12] 1762 	mov	a,dpl
      007637 90 08 41         [24] 1763 	mov	dptr,#_tap_code_code_10000_744
      00763A F0               [24] 1764 	movx	@dptr,a
                                   1765 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      00763B E0               [24] 1766 	movx	a,@dptr
      00763C FF               [12] 1767 	mov	r7,a
      00763D BF 39 04         [24] 1768 	cjne	r7,#0x39,00103$
      007640 7E 50            [12] 1769 	mov	r6,#0x50
      007642 80 02            [24] 1770 	sjmp	00104$
      007644                       1771 00103$:
      007644 7E 00            [12] 1772 	mov	r6,#0x00
      007646                       1773 00104$:
      007646 90 08 3E         [24] 1774 	mov	dptr,#_tap_code_delay_PARM_2
      007649 EE               [12] 1775 	mov	a,r6
      00764A 12 38 A1         [24] 1776 	lcall	_ak820_outline_0137
      00764D 8F 82            [24] 1777 	mov	dpl, r7
                                   1778 ;	quantum/action.c:1093: }
      00764F 02 76 08         [24] 1779 	ljmp	_tap_code_delay
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'register_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function register_mods
                                   1788 ;	-----------------------------------------
      007652                       1789 _register_mods:
      007652 E5 82            [12] 1790 	mov	a,dpl
      007654 90 08 42         [24] 1791 	mov	dptr,#_register_mods_mods_10000_746
      007657 F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action.c:1100: if (mods) {
      007658 E0               [24] 1794 	movx	a,@dptr
      007659 FF               [12] 1795 	mov	r7,a
      00765A E0               [24] 1796 	movx	a,@dptr
      00765B 60 08            [24] 1797 	jz	00103$
                                   1798 ;	quantum/action.c:1101: add_owned_mods(mods);
      00765D 8F 82            [24] 1799 	mov	dpl, r7
      00765F 12 7D 17         [24] 1800 	lcall	_add_owned_mods
                                   1801 ;	quantum/action.c:1102: send_keyboard_report();
                                   1802 ;	quantum/action.c:1104: }
      007662 02 80 5B         [24] 1803 	ljmp	_send_keyboard_report
      007665                       1804 00103$:
      007665 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'unregister_mods'
                                   1808 ;------------------------------------------------------------
                                   1809 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1810 ;------------------------------------------------------------
                                   1811 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1812 ;	-----------------------------------------
                                   1813 ;	 function unregister_mods
                                   1814 ;	-----------------------------------------
      007666                       1815 _unregister_mods:
      007666 E5 82            [12] 1816 	mov	a,dpl
      007668 90 08 43         [24] 1817 	mov	dptr,#_unregister_mods_mods_10000_750
      00766B F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	quantum/action.c:1111: if (mods) {
      00766C E0               [24] 1820 	movx	a,@dptr
      00766D FF               [12] 1821 	mov	r7,a
      00766E E0               [24] 1822 	movx	a,@dptr
      00766F 60 08            [24] 1823 	jz	00103$
                                   1824 ;	quantum/action.c:1112: del_owned_mods(mods);
      007671 8F 82            [24] 1825 	mov	dpl, r7
      007673 12 7D 27         [24] 1826 	lcall	_del_owned_mods
                                   1827 ;	quantum/action.c:1113: send_keyboard_report();
                                   1828 ;	quantum/action.c:1115: }
      007676 02 80 5B         [24] 1829 	ljmp	_send_keyboard_report
      007679                       1830 00103$:
      007679 22               [24] 1831 	ret
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'register_weak_mods'
                                   1834 ;------------------------------------------------------------
                                   1835 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function register_weak_mods
                                   1840 ;	-----------------------------------------
      00767A                       1841 _register_weak_mods:
      00767A E5 82            [12] 1842 	mov	a,dpl
      00767C 90 08 44         [24] 1843 	mov	dptr,#_register_weak_mods_mods_10000_754
      00767F F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	quantum/action.c:1122: if (mods) {
      007680 E0               [24] 1846 	movx	a,@dptr
      007681 FF               [12] 1847 	mov	r7,a
      007682 E0               [24] 1848 	movx	a,@dptr
      007683 60 08            [24] 1849 	jz	00103$
                                   1850 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007685 8F 82            [24] 1851 	mov	dpl, r7
      007687 12 7D 36         [24] 1852 	lcall	_add_owned_weak_mods
                                   1853 ;	quantum/action.c:1124: send_keyboard_report();
                                   1854 ;	quantum/action.c:1126: }
      00768A 02 80 5B         [24] 1855 	ljmp	_send_keyboard_report
      00768D                       1856 00103$:
      00768D 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function unregister_weak_mods
                                   1866 ;	-----------------------------------------
      00768E                       1867 _unregister_weak_mods:
      00768E E5 82            [12] 1868 	mov	a,dpl
      007690 90 08 45         [24] 1869 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      007693 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1133: if (mods) {
      007694 E0               [24] 1872 	movx	a,@dptr
      007695 FF               [12] 1873 	mov	r7,a
      007696 E0               [24] 1874 	movx	a,@dptr
      007697 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007699 8F 82            [24] 1877 	mov	dpl, r7
      00769B 12 7D 46         [24] 1878 	lcall	_del_owned_weak_mods
                                   1879 ;	quantum/action.c:1135: send_keyboard_report();
                                   1880 ;	quantum/action.c:1137: }
      00769E 02 80 5B         [24] 1881 	ljmp	_send_keyboard_report
      0076A1                       1882 00103$:
      0076A1 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard
                                   1890 ;	-----------------------------------------
      0076A2                       1891 _clear_keyboard:
                                   1892 ;	quantum/action.c:1144: clear_mods();
      0076A2 12 80 DF         [24] 1893 	lcall	_clear_mods
                                   1894 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1895 ;	quantum/action.c:1146: }
      0076A5 02 76 A8         [24] 1896 	ljmp	_clear_keyboard_but_mods
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods
                                   1903 ;	-----------------------------------------
      0076A8                       1904 _clear_keyboard_but_mods:
                                   1905 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0076A8 90 0D CC         [24] 1906 	mov	dptr,#_actual_keyboard_report
      0076AB 75 F0 00         [24] 1907 	mov	b, #0x00
      0076AE 12 6F 5B         [24] 1908 	lcall	_clear_keys_from_report
                                   1909 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1910 ;	quantum/action.c:1155: }
      0076B1 02 76 B4         [24] 1911 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function clear_keyboard_but_mods_and_keys
                                   1918 ;	-----------------------------------------
      0076B4                       1919 _clear_keyboard_but_mods_and_keys:
                                   1920 ;	quantum/action.c:1163: ak820_tapping_cancel();
      0076B4 12 46 BE         [24] 1921 	lcall	_ak820_tapping_cancel
                                   1922 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      0076B7 12 2E F0         [24] 1923 	lcall	_ak820_oneshot_cancel
                                   1924 ;	quantum/action.c:1174: ak820_combo_cancel();
      0076BA 12 35 70         [24] 1925 	lcall	_ak820_combo_cancel
                                   1926 ;	quantum/action.c:1177: repeat_key_cancel();
      0076BD 12 A2 15         [24] 1927 	lcall	_repeat_key_cancel
                                   1928 ;	quantum/action.c:1179: clear_owned_mods();
      0076C0 12 7D 56         [24] 1929 	lcall	_clear_owned_mods
                                   1930 ;	quantum/action.c:1180: clear_owned_keys();
      0076C3 12 7D 8E         [24] 1931 	lcall	_clear_owned_keys
                                   1932 ;	quantum/action.c:1181: clear_owned_usages();
      0076C6 12 7E CE         [24] 1933 	lcall	_clear_owned_usages
                                   1934 ;	quantum/action.c:1182: layer_hold_clear();
      0076C9 12 78 B2         [24] 1935 	lcall	_layer_hold_clear
                                   1936 ;	quantum/action.c:1184: clear_macro_tri_layer();
      0076CC 12 9C 62         [24] 1937 	lcall	_clear_macro_tri_layer
                                   1938 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0076CF 90 0D CC         [24] 1939 	mov	dptr,#_actual_keyboard_report
      0076D2 75 F0 00         [24] 1940 	mov	b, #0x00
      0076D5 12 6F 5B         [24] 1941 	lcall	_clear_keys_from_report
                                   1942 ;	quantum/action.c:1189: host_system_send(0);
      0076D8 90 00 00         [24] 1943 	mov	dptr,#0x0000
      0076DB 12 6D 1E         [24] 1944 	lcall	_host_system_send
                                   1945 ;	quantum/action.c:1190: host_consumer_send(0);
      0076DE 90 00 00         [24] 1946 	mov	dptr,#0x0000
      0076E1 12 6D 4E         [24] 1947 	lcall	_host_consumer_send
                                   1948 ;	quantum/action.c:1192: clear_weak_mods();
      0076E4 12 81 14         [24] 1949 	lcall	_clear_weak_mods
                                   1950 ;	quantum/action.c:1193: send_keyboard_report();
                                   1951 ;	quantum/action.c:1201: }
      0076E7 02 80 5B         [24] 1952 	ljmp	_send_keyboard_report
                                   1953 ;------------------------------------------------------------
                                   1954 ;Allocation info for local variables in function 'is_tap_record'
                                   1955 ;------------------------------------------------------------
                                   1956 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1957 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1960 ;	-----------------------------------------
                                   1961 	.area CSEG    (CODE)
                                   1962 	.area CONST   (CODE)
                                   1963 	.area XINIT   (CODE)
      00C190                       1964 __xinit__disable_action_cache:
      00C190 00                    1965 	.db #0x00	;  0
                                   1966 	.area CABS    (ABS,CODE)
                                   1967 
                                   1968 ; Experimental exact instruction outlining.
                                   1969 	.globl _ak820_outline_0001
                                   1970 	.globl _ak820_outline_0005
                                   1971 	.globl _ak820_outline_0007
                                   1972 	.globl _ak820_outline_0008
                                   1973 	.globl _ak820_outline_0011
                                   1974 	.globl _ak820_outline_0012
                                   1975 	.globl _ak820_outline_0013
                                   1976 	.globl _ak820_outline_0014
                                   1977 	.globl _ak820_outline_0016
                                   1978 	.globl _ak820_outline_0020
                                   1979 	.globl _ak820_outline_0021
                                   1980 	.globl _ak820_outline_0034
                                   1981 	.globl _ak820_outline_0036
                                   1982 	.globl _ak820_outline_0042
                                   1983 	.globl _ak820_outline_0050
                                   1984 	.globl _ak820_outline_0059
                                   1985 	.globl _ak820_outline_0063
                                   1986 	.globl _ak820_outline_0071
                                   1987 	.globl _ak820_outline_0072
                                   1988 	.globl _ak820_outline_0077
                                   1989 	.globl _ak820_outline_0085
                                   1990 	.globl _ak820_outline_0089
                                   1991 	.globl _ak820_outline_0093
                                   1992 	.globl _ak820_outline_0109
                                   1993 	.globl _ak820_outline_0110
                                   1994 	.globl _ak820_outline_0112
                                   1995 	.globl _ak820_outline_0114
                                   1996 	.globl _ak820_outline_0115
                                   1997 	.globl _ak820_outline_0120
                                   1998 	.globl _ak820_outline_0125
                                   1999 	.globl _ak820_outline_0126
                                   2000 	.globl _ak820_outline_0132
                                   2001 	.globl _ak820_outline_0136
                                   2002 	.globl _ak820_outline_0137
                                   2003 	.globl _ak820_outline_0144
                                   2004 	.globl _ak820_outline_0148
                                   2005 	.globl _ak820_outline_0151
                                   2006 	.globl _ak820_outline_0160
                                   2007 	.globl _ak820_outline_0162
                                   2008 	.globl _ak820_outline_0170
                                   2009 	.globl _ak820_outline_0171
                                   2010 	.globl _ak820_outline_0184
                                   2011 	.globl _ak820_outline_0189
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0013
      0076EA                       2015 _ak820_outline_0013:
      0076EA 2D               [12] 2016 	add	a,r5
      0076EB F9               [12] 2017 	mov	r1,a
      0076EC E4               [12] 2018 	clr	a
      0076ED 3E               [12] 2019 	addc	a,r6
      0076EE FA               [12] 2020 	mov	r2,a
      0076EF 8F 03            [24] 2021 	mov	ar3,r7
      0076F1 89 82            [24] 2022 	mov	dpl,r1
      0076F3 8A 83            [24] 2023 	mov	dph,r2
      0076F5 8B F0            [24] 2024 	mov	b,r3
      0076F7 22               [24] 2025 	ret
                                   2026 
                                   2027 	.area CSEG (CODE)
                                   2028 ; function ak820_outline_0014
      0076F8                       2029 _ak820_outline_0014:
      0076F8 2D               [12] 2030 	add	a,r5
      0076F9 FA               [12] 2031 	mov	r2,a
      0076FA E4               [12] 2032 	clr	a
      0076FB 3E               [12] 2033 	addc	a,r6
      0076FC FB               [12] 2034 	mov	r3,a
      0076FD 8F 04            [24] 2035 	mov	ar4,r7
      0076FF 8A 82            [24] 2036 	mov	dpl,r2
      007701 8B 83            [24] 2037 	mov	dph,r3
      007703 8C F0            [24] 2038 	mov	b,r4
      007705 22               [24] 2039 	ret
                                   2040 
                                   2041 	.area CSEG (CODE)
                                   2042 ; function ak820_outline_0020
      007706                       2043 _ak820_outline_0020:
      007706 8E 82            [24] 2044 	mov	dpl,r6
      007708 8F 83            [24] 2045 	mov	dph,r7
      00770A A3               [24] 2046 	inc	dptr
      00770B E0               [24] 2047 	movx	a,@dptr
      00770C FC               [12] 2048 	mov	r4,a
      00770D 7D 00            [12] 2049 	mov	r5,#0x00
      00770F 8E 82            [24] 2050 	mov	dpl,r6
      007711 8F 83            [24] 2051 	mov	dph,r7
      007713 E0               [24] 2052 	movx	a,@dptr
      007714 22               [24] 2053 	ret
                                   2054 
                                   2055 	.area CSEG (CODE)
                                   2056 ; function ak820_outline_0042
      007715                       2057 _ak820_outline_0042:
      007715 90 08 37         [24] 2058 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007718 E0               [24] 2059 	movx	a,@dptr
      007719 54 1F            [12] 2060 	anl	a,#0x1f
      00771B F5 82            [12] 2061 	mov	dpl,a
      00771D 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0063
      00771E                       2066 _ak820_outline_0063:
      00771E F5 F0            [12] 2067 	mov	b,a
      007720 05 F0            [12] 2068 	inc	b
      007722 74 01            [12] 2069 	mov	a,#0x01
      007724 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0071
      007725                       2074 _ak820_outline_0071:
      007725 90 0D AA         [24] 2075 	mov	dptr,#___memcpy_PARM_3
      007728 74 06            [12] 2076 	mov	a,#0x06
      00772A F0               [24] 2077 	movx	@dptr,a
      00772B E4               [12] 2078 	clr	a
      00772C A3               [24] 2079 	inc	dptr
      00772D F0               [24] 2080 	movx	@dptr,a
      00772E 22               [24] 2081 	ret
                                   2082 
                                   2083 	.area CSEG (CODE)
                                   2084 ; function ak820_outline_0077
      00772F                       2085 _ak820_outline_0077:
      00772F 90 08 36         [24] 2086 	mov	dptr,#_process_action_PARM_2
      007732 E0               [24] 2087 	movx	a,@dptr
      007733 F5 82            [12] 2088 	mov	dpl,a
      007735 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0089
      007736                       2093 _ak820_outline_0089:
      007736 90 08 37         [24] 2094 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007739 E0               [24] 2095 	movx	a,@dptr
      00773A 03               [12] 2096 	rr	a
      00773B 03               [12] 2097 	rr	a
      00773C 54 03            [12] 2098 	anl	a,#0x03
      00773E 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0115
      00773F                       2103 _ak820_outline_0115:
      00773F 90 08 37         [24] 2104 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007742 E0               [24] 2105 	movx	a,@dptr
      007743 54 0F            [12] 2106 	anl	a,#0x0f
      007745 22               [24] 2107 	ret
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0132
      007746                       2111 _ak820_outline_0132:
      007746 90 08 36         [24] 2112 	mov	dptr,#_process_action_PARM_2
      007749 E0               [24] 2113 	movx	a,@dptr
      00774A FE               [12] 2114 	mov	r6,a
      00774B A3               [24] 2115 	inc	dptr
      00774C E0               [24] 2116 	movx	a,@dptr
      00774D 54 03            [12] 2117 	anl	a,#0x03
      00774F FF               [12] 2118 	mov	r7,a
      007750 22               [24] 2119 	ret
                                   2120 
                                   2121 	.area CSEG (CODE)
                                   2122 ; function ak820_outline_0148
      007751                       2123 _ak820_outline_0148:
      007751 74 07            [12] 2124 	mov	a,#0x07
      007753 2D               [12] 2125 	add	a,r5
      007754 F8               [12] 2126 	mov	r0,a
      007755 E4               [12] 2127 	clr	a
      007756 3E               [12] 2128 	addc	a,r6
      007757 F9               [12] 2129 	mov	r1,a
      007758 8F 02            [24] 2130 	mov	ar2,r7
      00775A 22               [24] 2131 	ret
                                   2132 
                                   2133 	.area CSEG (CODE)
                                   2134 ; function ak820_outline_0162
      00775B                       2135 _ak820_outline_0162:
      00775B 90 08 36         [24] 2136 	mov	dptr,#_process_action_PARM_2
      00775E E0               [24] 2137 	movx	a,@dptr
      00775F 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0170
      007760                       2142 _ak820_outline_0170:
      007760 90 08 3C         [24] 2143 	mov	dptr,#_register_code_code_10000_710
      007763 E0               [24] 2144 	movx	a,@dptr
      007764 FF               [12] 2145 	mov	r7,a
      007765 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0171
      007766                       2150 _ak820_outline_0171:
      007766 90 08 3D         [24] 2151 	mov	dptr,#_unregister_code_code_10000_724
      007769 E0               [24] 2152 	movx	a,@dptr
      00776A FF               [12] 2153 	mov	r7,a
      00776B 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0189
      00776C                       2158 _ak820_outline_0189:
      00776C F0               [24] 2159 	movx	@dptr,a
      00776D EB               [12] 2160 	mov	a,r3
      00776E A3               [24] 2161 	inc	dptr
      00776F F0               [24] 2162 	movx	@dptr,a
      007770 22               [24] 2163 	ret
