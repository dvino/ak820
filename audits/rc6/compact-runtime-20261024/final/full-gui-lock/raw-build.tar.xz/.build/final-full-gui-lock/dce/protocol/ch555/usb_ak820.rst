                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_286:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_286:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_286:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_286:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      000765                        602 _D0SetupReqCode::
      000765                        603 	.ds 1
      000766                        604 _D0SetupLen::
      000766                        605 	.ds 2
      000768                        606 _pD0Descr::
      000768                        607 	.ds 3
      00076B                        608 _D0UsbConfig::
      00076B                        609 	.ds 1
      00076C                        610 _USB_EnumStatus::
      00076C                        611 	.ds 1
      00076D                        612 _USB_SleepStatus::
      00076D                        613 	.ds 1
      00076E                        614 _MCU_Sleep_Operate::
      00076E                        615 	.ds 1
      00076F                        616 _KB_USB_UpStatus::
      00076F                        617 	.ds 1
      000770                        618 _KB_USB_SetReport::
      000770                        619 	.ds 1
      000771                        620 _ak820_boot_stage::
      000771                        621 	.ds 1
      000772                        622 _ak820_main_heartbeat::
      000772                        623 	.ds 1
      000773                        624 _raw_state:
      000773                        625 	.ds 1
      000774                        626 _raw_buffer:
      000774                        627 	.ds 32
      000794                        628 _raw_reply_without_nvm:
      000794                        629 	.ds 1
      000795                        630 _keyboard_reset:
      000795                        631 	.ds 1
      000796                        632 _input_snapshot:
      000796                        633 	.ds 46
      0007C4                        634 _control_phase:
      0007C4                        635 	.ds 1
      0007C5                        636 _output_kind:
      0007C5                        637 	.ds 1
      0007C6                        638 _output_report_id:
      0007C6                        639 	.ds 1
      0007C7                        640 _control_zlp:
      0007C7                        641 	.ds 1
      0007C8                        642 _control_pointer:
      0007C8                        643 	.ds 2
      0007CA                        644 _descriptor_select_PARM_2:
      0007CA                        645 	.ds 1
      0007CB                        646 _descriptor_select_PARM_3:
      0007CB                        647 	.ds 2
      0007CD                        648 _descriptor_select_type_10000_268:
      0007CD                        649 	.ds 1
      0007CE                        650 _control_setup_length_10000_286:
      0007CE                        651 	.ds 2
      0007D0                        652 _control_setup_offset_10000_286:
      0007D0                        653 	.ds 1
      0007D1                        654 _ak820_usb_send_PARM_2:
      0007D1                        655 	.ds 2
      0007D3                        656 _ak820_usb_send_PARM_3:
      0007D3                        657 	.ds 1
      0007D4                        658 _ak820_usb_send_endpoint_10000_422:
      0007D4                        659 	.ds 1
      0007D5                        660 _ak820_usb_send_offset_10000_423:
      0007D5                        661 	.ds 1
      0007D6                        662 _ak820_usb_try_send_PARM_2:
      0007D6                        663 	.ds 2
      0007D8                        664 _ak820_usb_try_send_PARM_3:
      0007D8                        665 	.ds 1
      0007D9                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007D9                        667 	.ds 1
      0007DA                        668 _ak820_usb_try_send_sent_10000_444:
      0007DA                        669 	.ds 1
      0007DB                        670 _ak820_usb_raw_send_PARM_2:
      0007DB                        671 	.ds 1
      0007DC                        672 _ak820_usb_raw_send_report_10000_459:
      0007DC                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005A4F                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005A4F 90 07 73         [24]  727 	mov	dptr,#_raw_state
      005A52 E0               [24]  728 	movx	a,@dptr
      005A53 FF               [12]  729 	mov	r7,a
      005A54 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005A57 80 1C            [24]  731 	sjmp	00101$
      005A59                        732 00130$:
      005A59 90 07 73         [24]  733 	mov	dptr,#_raw_state
      005A5C E0               [24]  734 	movx	a,@dptr
      005A5D FF               [12]  735 	mov	r7,a
      005A5E BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005A61 80 12            [24]  737 	sjmp	00101$
      005A63                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005A63 90 07 73         [24]  740 	mov	dptr,#_raw_state
      005A66 E0               [24]  741 	movx	a,@dptr
      005A67 FF               [12]  742 	mov	r7,a
      005A68 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005A6B 80 08            [24]  744 	sjmp	00101$
      005A6D                        745 00132$:
      005A6D 90 07 73         [24]  746 	mov	dptr,#_raw_state
      005A70 E0               [24]  747 	movx	a,@dptr
      005A71 FF               [12]  748 	mov	r7,a
      005A72 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005A75                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      005A75 90 07 73         [24]  752 	mov	dptr,#_raw_state
      005A78 74 07            [12]  753 	mov	a,#0x07
      005A7A F0               [24]  754 	movx	@dptr,a
      005A7B 80 05            [24]  755 	sjmp	00103$
      005A7D                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      005A7D 90 07 73         [24]  758 	mov	dptr,#_raw_state
      005A80 E4               [12]  759 	clr	a
      005A81 F0               [24]  760 	movx	@dptr,a
      005A82                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      005A82 90 07 C5         [24]  763 	mov	dptr,#_output_kind
      005A85 E4               [12]  764 	clr	a
      005A86 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005A87 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005A88                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005A88 90 07 73         [24]  777 	mov	dptr,#_raw_state
      005A8B E0               [24]  778 	movx	a,@dptr
      005A8C FF               [12]  779 	mov	r7,a
      005A8D BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005A90 90 07 73         [24]  781 	mov	dptr,#_raw_state
      005A93 74 06            [12]  782 	mov	a,#0x06
      005A95 F0               [24]  783 	movx	@dptr,a
      005A96 22               [24]  784 	ret
      005A97                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005A97 90 07 73         [24]  787 	mov	dptr,#_raw_state
      005A9A E0               [24]  788 	movx	a,@dptr
      005A9B FF               [12]  789 	mov	r7,a
      005A9C BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005A9F 90 07 73         [24]  791 	mov	dptr,#_raw_state
      005AA2 E4               [12]  792 	clr	a
      005AA3 F0               [24]  793 	movx	@dptr,a
      005AA4                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005AA4 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005AA5                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005AA5 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005AA8 74 01            [12]  809 	mov	a,#0x01
      005AAA F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005AAB F5 82            [12]  812 	mov	dpl,a
      005AAD 74 12            [12]  813 	mov	a,#0x12
      005AAF F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005AB0 A3               [24]  816 	inc	dptr
      005AB1 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005AB2 A3               [24]  819 	inc	dptr
      005AB3 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005AB4 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005AB7 E4               [12]  823 	clr	a
      005AB8 F0               [24]  824 	movx	@dptr,a
      005AB9 15 82            [12]  825 	dec	dpl
      005ABB F0               [24]  826 	movx	@dptr,a
      005ABC 15 82            [12]  827 	dec	dpl
      005ABE F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005ABF FF               [12]  830 	mov	r7,a
      005AC0                        831 00103$:
      005AC0 EF               [12]  832 	mov	a,r7
      005AC1 24 96            [12]  833 	add	a, #_input_snapshot
      005AC3 F5 82            [12]  834 	mov	dpl,a
      005AC5 E4               [12]  835 	clr	a
      005AC6 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005AC8 F5 83            [12]  837 	mov	dph,a
      005ACA E4               [12]  838 	clr	a
      005ACB F0               [24]  839 	movx	@dptr,a
      005ACC 0F               [12]  840 	inc	r7
      005ACD BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      005AD0                        842 00139$:
      005AD0 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005AD2 90 07 9E         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005AD5 74 06            [12]  846 	mov	a,#0x06
      005AD7 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005AD8 90 07 BE         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005ADB 03               [12]  850 	rr	a
      005ADC F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005ADD 90 07 C1         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      005AE0 04               [12]  854 	inc	a
      005AE1 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005AE2 7F 00            [12]  857 	mov	r7,#0x00
      005AE4                        858 00105$:
      005AE4 8F 06            [24]  859 	mov	ar6,r7
      005AE6 74 C0            [12]  860 	mov	a,#0xc0
      005AE8 2E               [12]  861 	add	a, r6
      005AE9 F5 82            [12]  862 	mov	dpl,a
      005AEB 74 10            [12]  863 	mov	a,#0x10
      005AED 24 00            [12]  864 	add	a, #0x00
      005AEF F5 83            [12]  865 	mov	dph,a
      005AF1 E4               [12]  866 	clr	a
      005AF2 F0               [24]  867 	movx	@dptr,a
      005AF3 0F               [12]  868 	inc	r7
      005AF4 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005AF7                        870 00141$:
      005AF7 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005AF9 02 5A 4F         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005AFC                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005AFC 90 07 73         [24]  884 	mov	dptr,#_raw_state
      005AFF E0               [24]  885 	movx	a,@dptr
      005B00 FF               [12]  886 	mov	r7,a
      005B01 BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005B04 90 07 73         [24]  888 	mov	dptr,#_raw_state
      005B07 E4               [12]  889 	clr	a
      005B08 F0               [24]  890 	movx	@dptr,a
      005B09                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005B09 90 07 C5         [24]  893 	mov	dptr,#_output_kind
      005B0C E4               [12]  894 	clr	a
      005B0D F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      005B0E 90 07 C4         [24]  897 	mov	dptr,#_control_phase
      005B11 F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      005B12 90 07 65         [24]  900 	mov	dptr,#_D0SetupReqCode
      005B15 14               [12]  901 	dec	a
      005B16 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005B17 90 22 00         [24]  904 	mov	dptr,#0x2200
      005B1A 74 CF            [12]  905 	mov	a,#0xcf
      005B1C F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      005B1D 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      005B1E                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005B1E 90 07 66         [24]  921 	mov	dptr,#_D0SetupLen
      005B21 E0               [24]  922 	movx	a,@dptr
      005B22 FE               [12]  923 	mov	r6,a
      005B23 A3               [24]  924 	inc	dptr
      005B24 E0               [24]  925 	movx	a,@dptr
      005B25 FF               [12]  926 	mov	r7,a
      005B26 C3               [12]  927 	clr	c
      005B27 74 40            [12]  928 	mov	a,#0x40
      005B29 9E               [12]  929 	subb	a,r6
      005B2A E4               [12]  930 	clr	a
      005B2B 9F               [12]  931 	subb	a,r7
      005B2C 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      005B2E 7E 40            [12]  934 	mov	r6,#0x40
      005B30 80 07            [24]  935 	sjmp	00110$
      005B32                        936 00109$:
      005B32 90 07 66         [24]  937 	mov	dptr,#_D0SetupLen
      005B35 E0               [24]  938 	movx	a,@dptr
      005B36 FE               [12]  939 	mov	r6,a
      005B37 A3               [24]  940 	inc	dptr
      005B38 E0               [24]  941 	movx	a,@dptr
      005B39                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005B39 7F 00            [12]  944 	mov	r7,#0x00
      005B3B                        945 00105$:
      005B3B C3               [12]  946 	clr	c
      005B3C EF               [12]  947 	mov	a,r7
      005B3D 9E               [12]  948 	subb	a,r6
      005B3E 50 2A            [24]  949 	jnc	00101$
      005B40 8F 04            [24]  950 	mov	ar4,r7
      005B42 74 10            [12]  951 	mov	a,#0x10
      005B44 24 00            [12]  952 	add	a, #0x00
      005B46 FD               [12]  953 	mov	r5,a
      005B47 90 07 C8         [24]  954 	mov	dptr,#_control_pointer
      005B4A E0               [24]  955 	movx	a,@dptr
      005B4B FA               [12]  956 	mov	r2,a
      005B4C A3               [24]  957 	inc	dptr
      005B4D E0               [24]  958 	movx	a,@dptr
      005B4E FB               [12]  959 	mov	r3,a
      005B4F 8A 82            [24]  960 	mov	dpl,r2
      005B51 8B 83            [24]  961 	mov	dph,r3
      005B53 E4               [12]  962 	clr	a
      005B54 93               [24]  963 	movc	a,@a+dptr
      005B55 F9               [12]  964 	mov	r1,a
      005B56 90 07 C8         [24]  965 	mov	dptr,#_control_pointer
      005B59 74 01            [12]  966 	mov	a,#0x01
      005B5B 2A               [12]  967 	add	a, r2
      005B5C F0               [24]  968 	movx	@dptr,a
      005B5D E4               [12]  969 	clr	a
      005B5E 3B               [12]  970 	addc	a, r3
      005B5F A3               [24]  971 	inc	dptr
      005B60 F0               [24]  972 	movx	@dptr,a
      005B61 8C 82            [24]  973 	mov	dpl,r4
      005B63 8D 83            [24]  974 	mov	dph,r5
      005B65 E9               [12]  975 	mov	a,r1
      005B66 F0               [24]  976 	movx	@dptr,a
      005B67 0F               [12]  977 	inc	r7
      005B68 80 D1            [24]  978 	sjmp	00105$
      005B6A                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      005B6A 8E 05            [24]  981 	mov	ar5,r6
      005B6C 7F 00            [12]  982 	mov	r7,#0x00
      005B6E 90 07 66         [24]  983 	mov	dptr,#_D0SetupLen
      005B71 E0               [24]  984 	movx	a,@dptr
      005B72 FB               [12]  985 	mov	r3,a
      005B73 A3               [24]  986 	inc	dptr
      005B74 E0               [24]  987 	movx	a,@dptr
      005B75 FC               [12]  988 	mov	r4,a
      005B76 EB               [12]  989 	mov	a,r3
      005B77 C3               [12]  990 	clr	c
      005B78 9D               [12]  991 	subb	a,r5
      005B79 FB               [12]  992 	mov	r3,a
      005B7A EC               [12]  993 	mov	a,r4
      005B7B 9F               [12]  994 	subb	a,r7
      005B7C FC               [12]  995 	mov	r4,a
      005B7D 90 07 66         [24]  996 	mov	dptr,#_D0SetupLen
      005B80 EB               [12]  997 	mov	a,r3
      005B81 F0               [24]  998 	movx	@dptr,a
      005B82 EC               [12]  999 	mov	a,r4
      005B83 A3               [24] 1000 	inc	dptr
      005B84 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005B85 EE               [12] 1003 	mov	a,r6
      005B86 70 05            [24] 1004 	jnz	00103$
      005B88 90 07 C7         [24] 1005 	mov	dptr,#_control_zlp
      005B8B E4               [12] 1006 	clr	a
      005B8C F0               [24] 1007 	movx	@dptr,a
      005B8D                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005B8D 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005B90 EE               [12] 1011 	mov	a,r6
      005B91 F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005B92 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005B95 E0               [24] 1015 	movx	a,@dptr
      005B96 54 C0            [12] 1016 	anl	a,#0xc0
      005B98 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005B99 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005B9A                       1032 _descriptor_select:
      005B9A E5 82            [12] 1033 	mov	a,dpl
      005B9C 90 07 CD         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005B9F F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005BA0 E0               [24] 1037 	movx	a,@dptr
      005BA1 FF               [12] 1038 	mov	r7,a
      005BA2 BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005BA5 90 07 CA         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005BA8 E0               [24] 1041 	movx	a,@dptr
      005BA9 70 1A            [24] 1042 	jnz	00102$
      005BAB 90 07 CB         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005BAE E0               [24] 1044 	movx	a,@dptr
      005BAF F5 F0            [12] 1045 	mov	b,a
      005BB1 A3               [24] 1046 	inc	dptr
      005BB2 E0               [24] 1047 	movx	a,@dptr
      005BB3 45 F0            [12] 1048 	orl	a,b
      005BB5 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005BB7 90 07 C8         [24] 1051 	mov	dptr,#_control_pointer
      005BBA 74 B0            [12] 1052 	mov	a,#_DeviceDescriptor
      005BBC F0               [24] 1053 	movx	@dptr,a
      005BBD 74 C0            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005BBF A3               [24] 1055 	inc	dptr
      005BC0 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005BC1 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005BC4 22               [24] 1059 	ret
      005BC5                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005BC5 90 07 CD         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005BC8 E0               [24] 1063 	movx	a,@dptr
      005BC9 FF               [12] 1064 	mov	r7,a
      005BCA BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005BCD 90 07 CA         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005BD0 E0               [24] 1067 	movx	a,@dptr
      005BD1 70 1A            [24] 1068 	jnz	00106$
      005BD3 90 07 CB         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005BD6 E0               [24] 1070 	movx	a,@dptr
      005BD7 F5 F0            [12] 1071 	mov	b,a
      005BD9 A3               [24] 1072 	inc	dptr
      005BDA E0               [24] 1073 	movx	a,@dptr
      005BDB 45 F0            [12] 1074 	orl	a,b
      005BDD 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005BDF 90 07 C8         [24] 1077 	mov	dptr,#_control_pointer
      005BE2 74 C2            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005BE4 F0               [24] 1079 	movx	@dptr,a
      005BE5 74 C0            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005BE7 A3               [24] 1081 	inc	dptr
      005BE8 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005BE9 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005BEC 22               [24] 1085 	ret
      005BED                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005BED 90 07 CD         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005BF0 E0               [24] 1089 	movx	a,@dptr
      005BF1 FF               [12] 1090 	mov	r7,a
      005BF2 BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005BF5 80 03            [24] 1092 	sjmp	00239$
      005BF7                       1093 00238$:
      005BF7 02 5C 91         [24] 1094 	ljmp	00119$
      005BFA                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005BFA 90 07 CB         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005BFD E0               [24] 1098 	movx	a,@dptr
      005BFE FD               [12] 1099 	mov	r5,a
      005BFF A3               [24] 1100 	inc	dptr
      005C00 E0               [24] 1101 	movx	a,@dptr
      005C01 FE               [12] 1102 	mov	r6,a
      005C02 90 07 CB         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005C05 E0               [24] 1104 	movx	a,@dptr
      005C06 F5 F0            [12] 1105 	mov	b,a
      005C08 A3               [24] 1106 	inc	dptr
      005C09 E0               [24] 1107 	movx	a,@dptr
      005C0A 45 F0            [12] 1108 	orl	a,b
      005C0C 60 0C            [24] 1109 	jz	00110$
      005C0E BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005C11 BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005C14 80 04            [24] 1112 	sjmp	00110$
      005C16                       1113 00241$:
      005C16 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005C19 22               [24] 1115 	ret
      005C1A                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005C1A 90 07 CA         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005C1D E0               [24] 1119 	movx	a,@dptr
      005C1E FE               [12] 1120 	mov  r6,a
      005C1F 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005C21 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005C23 EE               [12] 1124 	mov	a,r6
      005C24 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005C25 90 5C 29         [24] 1127 	mov	dptr,#00243$
      005C28 73               [24] 1128 	jmp	@a+dptr
      005C29                       1129 00243$:
      005C29 80 06            [24] 1130 	sjmp	00112$
      005C2B 80 1B            [24] 1131 	sjmp	00113$
      005C2D 80 30            [24] 1132 	sjmp	00114$
      005C2F 80 45            [24] 1133 	sjmp	00115$
      005C31                       1134 00112$:
      005C31 90 07 C8         [24] 1135 	mov	dptr,#_control_pointer
      005C34 74 16            [12] 1136 	mov	a,#_LanguageString
      005C36 F0               [24] 1137 	movx	@dptr,a
      005C37 74 C1            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005C39 A3               [24] 1139 	inc	dptr
      005C3A F0               [24] 1140 	movx	@dptr,a
      005C3B 90 C1 16         [24] 1141 	mov	dptr,#_LanguageString
      005C3E E4               [12] 1142 	clr	a
      005C3F 93               [24] 1143 	movc	a,@a+dptr
      005C40 FE               [12] 1144 	mov	r6,a
      005C41 7D 00            [12] 1145 	mov	r5,#0x00
      005C43 8E 82            [24] 1146 	mov	dpl, r6
      005C45 8D 83            [24] 1147 	mov	dph, r5
      005C47 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005C48                       1150 00113$:
      005C48 90 07 C8         [24] 1151 	mov	dptr,#_control_pointer
      005C4B 74 1A            [12] 1152 	mov	a,#_ManufacturerString
      005C4D F0               [24] 1153 	movx	@dptr,a
      005C4E 74 C1            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005C50 A3               [24] 1155 	inc	dptr
      005C51 F0               [24] 1156 	movx	@dptr,a
      005C52 90 C1 1A         [24] 1157 	mov	dptr,#_ManufacturerString
      005C55 E4               [12] 1158 	clr	a
      005C56 93               [24] 1159 	movc	a,@a+dptr
      005C57 FE               [12] 1160 	mov	r6,a
      005C58 7D 00            [12] 1161 	mov	r5,#0x00
      005C5A 8E 82            [24] 1162 	mov	dpl, r6
      005C5C 8D 83            [24] 1163 	mov	dph, r5
      005C5E 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005C5F                       1166 00114$:
      005C5F 90 07 C8         [24] 1167 	mov	dptr,#_control_pointer
      005C62 74 28            [12] 1168 	mov	a,#_ProductString
      005C64 F0               [24] 1169 	movx	@dptr,a
      005C65 74 C1            [12] 1170 	mov	a,#(_ProductString >> 8)
      005C67 A3               [24] 1171 	inc	dptr
      005C68 F0               [24] 1172 	movx	@dptr,a
      005C69 90 C1 28         [24] 1173 	mov	dptr,#_ProductString
      005C6C E4               [12] 1174 	clr	a
      005C6D 93               [24] 1175 	movc	a,@a+dptr
      005C6E FE               [12] 1176 	mov	r6,a
      005C6F 7D 00            [12] 1177 	mov	r5,#0x00
      005C71 8E 82            [24] 1178 	mov	dpl, r6
      005C73 8D 83            [24] 1179 	mov	dph, r5
      005C75 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005C76                       1182 00115$:
      005C76 90 07 C8         [24] 1183 	mov	dptr,#_control_pointer
      005C79 74 60            [12] 1184 	mov	a,#_SerialNumberString
      005C7B F0               [24] 1185 	movx	@dptr,a
      005C7C 74 C1            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005C7E A3               [24] 1187 	inc	dptr
      005C7F F0               [24] 1188 	movx	@dptr,a
      005C80 90 C1 60         [24] 1189 	mov	dptr,#_SerialNumberString
      005C83 E4               [12] 1190 	clr	a
      005C84 93               [24] 1191 	movc	a,@a+dptr
      005C85 FE               [12] 1192 	mov	r6,a
      005C86 7D 00            [12] 1193 	mov	r5,#0x00
      005C88 8E 82            [24] 1194 	mov	dpl, r6
      005C8A 8D 83            [24] 1195 	mov	dph, r5
      005C8C 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005C8D                       1198 00116$:
      005C8D 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005C90 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005C91                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005C91 90 07 CA         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005C94 E0               [24] 1205 	movx	a,@dptr
      005C95 70 11            [24] 1206 	jnz	00120$
      005C97 90 07 CB         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005C9A E0               [24] 1208 	movx	a,@dptr
      005C9B FD               [12] 1209 	mov	r5,a
      005C9C A3               [24] 1210 	inc	dptr
      005C9D E0               [24] 1211 	movx	a,@dptr
      005C9E FE               [12] 1212 	mov	r6,a
      005C9F C3               [12] 1213 	clr	c
      005CA0 ED               [12] 1214 	mov	a,r5
      005CA1 94 03            [12] 1215 	subb	a,#0x03
      005CA3 EE               [12] 1216 	mov	a,r6
      005CA4 94 00            [12] 1217 	subb	a,#0x00
      005CA6 40 04            [24] 1218 	jc	00121$
      005CA8                       1219 00120$:
      005CA8 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005CAB 22               [24] 1221 	ret
      005CAC                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005CAC BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005CAF 80 03            [24] 1225 	sjmp	00127$
      005CB1                       1226 00246$:
      005CB1 BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005CB4                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005CB4 ED               [12] 1230 	mov	a,r5
      005CB5 75 F0 04         [24] 1231 	mov	b,#0x04
      005CB8 A4               [48] 1232 	mul	ab
      005CB9 24 39            [12] 1233 	add	a, #_interface_descriptors
      005CBB FE               [12] 1234 	mov	r6,a
      005CBC 74 BA            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005CBE 35 F0            [12] 1236 	addc	a, b
      005CC0 FF               [12] 1237 	mov	r7,a
      005CC1 8E 82            [24] 1238 	mov	dpl,r6
      005CC3 8F 83            [24] 1239 	mov	dph,r7
      005CC5 A3               [24] 1240 	inc	dptr
      005CC6 A3               [24] 1241 	inc	dptr
      005CC7 E4               [12] 1242 	clr	a
      005CC8 93               [24] 1243 	movc	a,@a+dptr
      005CC9 FC               [12] 1244 	mov	r4,a
      005CCA A3               [24] 1245 	inc	dptr
      005CCB E4               [12] 1246 	clr	a
      005CCC 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005CCD FD               [12] 1249 	mov	r5,a
      005CCE 4C               [12] 1250 	orl	a,r4
      005CCF 70 04            [24] 1251 	jnz	00124$
      005CD1 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005CD4 22               [24] 1253 	ret
      005CD5                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005CD5 90 07 CD         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005CD8 E0               [24] 1257 	movx	a,@dptr
      005CD9 FB               [12] 1258 	mov	r3,a
      005CDA BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005CDD 8E 82            [24] 1261 	mov	dpl,r6
      005CDF 8F 83            [24] 1262 	mov	dph,r7
      005CE1 E4               [12] 1263 	clr	a
      005CE2 93               [24] 1264 	movc	a,@a+dptr
      005CE3 FE               [12] 1265 	mov	r6,a
      005CE4 A3               [24] 1266 	inc	dptr
      005CE5 E4               [12] 1267 	clr	a
      005CE6 93               [24] 1268 	movc	a,@a+dptr
      005CE7 FF               [12] 1269 	mov	r7,a
      005CE8 90 07 C8         [24] 1270 	mov	dptr,#_control_pointer
      005CEB EE               [12] 1271 	mov	a,r6
      005CEC F0               [24] 1272 	movx	@dptr,a
      005CED EF               [12] 1273 	mov	a,r7
      005CEE A3               [24] 1274 	inc	dptr
      005CEF F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005CF0 74 07            [12] 1277 	mov	a,#0x07
      005CF2 2C               [12] 1278 	add	a, r4
      005CF3 F5 82            [12] 1279 	mov	dpl,a
      005CF5 E4               [12] 1280 	clr	a
      005CF6 3D               [12] 1281 	addc	a, r5
      005CF7 F5 83            [12] 1282 	mov	dph,a
      005CF9 E4               [12] 1283 	clr	a
      005CFA 93               [24] 1284 	movc	a,@a+dptr
      005CFB FE               [12] 1285 	mov	r6,a
      005CFC A3               [24] 1286 	inc	dptr
      005CFD E4               [12] 1287 	clr	a
      005CFE 93               [24] 1288 	movc	a,@a+dptr
      005CFF FF               [12] 1289 	mov	r7,a
      005D00 8E 82            [24] 1290 	mov	dpl, r6
      005D02 8F 83            [24] 1291 	mov	dph, r7
      005D04 22               [24] 1292 	ret
      005D05                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005D05 90 07 C8         [24] 1295 	mov	dptr,#_control_pointer
      005D08 EC               [12] 1296 	mov	a,r4
      005D09 F0               [24] 1297 	movx	@dptr,a
      005D0A ED               [12] 1298 	mov	a,r5
      005D0B A3               [24] 1299 	inc	dptr
      005D0C F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005D0D 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005D10 22               [24] 1303 	ret
      005D11                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005D11 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005D14 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005D15                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005D15 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005D18 E0               [24] 1331 	movx	a,@dptr
      005D19 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005D1A A3               [24] 1334 	inc	dptr
      005D1B A3               [24] 1335 	inc	dptr
      005D1C E0               [24] 1336 	movx	a,@dptr
      005D1D FE               [12] 1337 	mov	r6,a
      005D1E A3               [24] 1338 	inc	dptr
      005D1F E0               [24] 1339 	movx	a,@dptr
      005D20 FC               [12] 1340 	mov	r4,a
      005D21 7D 00            [12] 1341 	mov	r5,#0x00
      005D23 8E 03            [24] 1342 	mov	ar3,r6
      005D25 7E 00            [12] 1343 	mov	r6,#0x00
      005D27 ED               [12] 1344 	mov	a,r5
      005D28 4B               [12] 1345 	orl	a,r3
      005D29 FD               [12] 1346 	mov	r5,a
      005D2A EC               [12] 1347 	mov	a,r4
      005D2B 4E               [12] 1348 	orl	a,r6
      005D2C FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005D2D A3               [24] 1351 	inc	dptr
      005D2E E0               [24] 1352 	movx	a,@dptr
      005D2F FC               [12] 1353 	mov	r4,a
      005D30 A3               [24] 1354 	inc	dptr
      005D31 E0               [24] 1355 	movx	a,@dptr
      005D32 FA               [12] 1356 	mov	r2,a
      005D33 7B 00            [12] 1357 	mov	r3,#0x00
      005D35 8C 01            [24] 1358 	mov	ar1,r4
      005D37 7C 00            [12] 1359 	mov	r4,#0x00
      005D39 EB               [12] 1360 	mov	a,r3
      005D3A 49               [12] 1361 	orl	a,r1
      005D3B FB               [12] 1362 	mov	r3,a
      005D3C EA               [12] 1363 	mov	a,r2
      005D3D 4C               [12] 1364 	orl	a,r4
      005D3E FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005D3F C3               [12] 1367 	clr	c
      005D40 EB               [12] 1368 	mov	a,r3
      005D41 94 03            [12] 1369 	subb	a,#0x03
      005D43 EC               [12] 1370 	mov	a,r4
      005D44 94 00            [12] 1371 	subb	a,#0x00
      005D46 92 16            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005D48 EB               [12] 1374 	mov	a,r3
      005D49 4C               [12] 1375 	orl	a,r4
      005D4A B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005D4D                       1377 01201$:
      005D4D 92 17            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005D4F ED               [12] 1380 	mov	a,r5
      005D50 4E               [12] 1381 	orl	a,r6
      005D51 B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005D54                       1383 01202$:
                                   1384 ;	assignBit
      005D54 92 1A            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005D56 92 18            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005D58 90 07 D0         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005D5B E4               [12] 1389 	clr	a
      005D5C F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005D5D 90 07 73         [24] 1392 	mov	dptr,#_raw_state
      005D60 E0               [24] 1393 	movx	a,@dptr
      005D61 FA               [12] 1394 	mov	r2,a
      005D62 BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005D65 90 07 73         [24] 1396 	mov	dptr,#_raw_state
      005D68 E4               [12] 1397 	clr	a
      005D69 F0               [24] 1398 	movx	@dptr,a
      005D6A                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005D6A C0 07            [24] 1401 	push	ar7
      005D6C 90 07 C5         [24] 1402 	mov	dptr,#_output_kind
      005D6F E4               [12] 1403 	clr	a
      005D70 F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005D71 90 07 C4         [24] 1406 	mov	dptr,#_control_phase
      005D74 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005D75 90 07 C7         [24] 1409 	mov	dptr,#_control_zlp
      005D78 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005D79 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005D7C E0               [24] 1413 	movx	a,@dptr
      005D7D 90 07 65         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005D80 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005D81 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005D84 E0               [24] 1418 	movx	a,@dptr
      005D85 FA               [12] 1419 	mov	r2,a
      005D86 A3               [24] 1420 	inc	dptr
      005D87 E0               [24] 1421 	movx	a,@dptr
      005D88 F9               [12] 1422 	mov	r1,a
      005D89 78 00            [12] 1423 	mov	r0,#0x00
      005D8B 7F 00            [12] 1424 	mov	r7,#0x00
      005D8D 90 07 66         [24] 1425 	mov	dptr,#_D0SetupLen
      005D90 E8               [12] 1426 	mov	a,r0
      005D91 4A               [12] 1427 	orl	a,r2
      005D92 F0               [24] 1428 	movx	@dptr,a
      005D93 E9               [12] 1429 	mov	a,r1
      005D94 4F               [12] 1430 	orl	a,r7
      005D95 A3               [24] 1431 	inc	dptr
      005D96 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      005D97 90 07 66         [24] 1434 	mov	dptr,#_D0SetupLen
      005D9A E0               [24] 1435 	movx	a,@dptr
      005D9B FA               [12] 1436 	mov	r2,a
      005D9C A3               [24] 1437 	inc	dptr
      005D9D E0               [24] 1438 	movx	a,@dptr
      005D9E 4A               [12] 1439 	orl	a,r2
      005D9F B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005DA2                       1441 01205$:
      005DA2 92 19            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005DA4 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005DA7 74 C2            [12] 1445 	mov	a,#0xc2
      005DA9 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      005DAA 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005DAD E4               [12] 1449 	clr	a
      005DAE F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      005DAF 90 07 65         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005DB2 E0               [24] 1453 	movx	a,@dptr
      005DB3 F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005DB5 C3               [12] 1455 	clr	c
      005DB6 74 0B            [12] 1456 	mov	a,#0x0b
      005DB8 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005DBA D0 07            [24] 1458 	pop	ar7
      005DBC 50 03            [24] 1459 	jnc	01206$
      005DBE 02 5A FC         [24] 1460 	ljmp	_control_stall
      005DC1                       1461 01206$:
                                   1462 ;	free result
      005DC1 E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005DC3 F5 F0            [12] 1464 	mov	b,a
      005DC5 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005DC7 83               [24] 1466 	movc	a,@a+pc
      005DC8 F5 82            [12] 1467 	mov	dpl,a
      005DCA E5 F0            [12] 1468 	mov	a,b
      005DCC 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005DCE 83               [24] 1470 	movc	a,@a+pc
      005DCF F5 83            [12] 1471 	mov	dph,a
      005DD1 E4               [12] 1472 	clr	a
      005DD2 73               [24] 1473 	jmp	@a+dptr
      005DD3                       1474 01207$:
      005DD3 7B                    1475 	.db	00188$
      005DD4 21                    1476 	.db	00205$
      005DD5 64                    1477 	.db	00282$
      005DD6 21                    1478 	.db	00205$
      005DD7 A8                    1479 	.db	00290$
      005DD8 A5                    1480 	.db	00116$
      005DD9 EB                    1481 	.db	00103$
      005DDA A8                    1482 	.db	00290$
      005DDB AA                    1483 	.db	00150$
      005DDC CE                    1484 	.db	00123$
      005DDD DA                    1485 	.db	00157$
      005DDE 2D                    1486 	.db	00173$
      005DDF                       1487 01208$:
      005DDF 60                    1488 	.db	00188$>>8
      005DE0 61                    1489 	.db	00205$>>8
      005DE1 64                    1490 	.db	00282$>>8
      005DE2 61                    1491 	.db	00205$>>8
      005DE3 64                    1492 	.db	00290$>>8
      005DE4 5E                    1493 	.db	00116$>>8
      005DE5 5D                    1494 	.db	00103$>>8
      005DE6 64                    1495 	.db	00290$>>8
      005DE7 5F                    1496 	.db	00150$>>8
      005DE8 5E                    1497 	.db	00123$>>8
      005DE9 5F                    1498 	.db	00157$>>8
      005DEA 60                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      005DEB                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      005DEB BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005DEE 80 08            [24] 1504 	sjmp	00112$
      005DF0                       1505 01209$:
      005DF0 BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005DF3 80 03            [24] 1507 	sjmp	01211$
      005DF5                       1508 01210$:
      005DF5 02 5A FC         [24] 1509 	ljmp	_control_stall
      005DF8                       1510 01211$:
      005DF8                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005DF8 8E 01            [24] 1513 	mov	ar1,r6
      005DFA B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005DFD 80 09            [24] 1515 	sjmp	00301$
      005DFF                       1516 01212$:
      005DFF B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005E02 80 04            [24] 1518 	sjmp	00301$
      005E04                       1519 01213$:
                                   1520 ;	assignBit
      005E04 C2 1B            [12] 1521 	clr	_control_setup_sloc2_1_0
      005E06 80 02            [24] 1522 	sjmp	00302$
      005E08                       1523 00301$:
                                   1524 ;	assignBit
      005E08 D2 1B            [12] 1525 	setb	_control_setup_sloc2_1_0
      005E0A                       1526 00302$:
      005E0A E4               [12] 1527 	clr	a
      005E0B BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005E0E 04               [12] 1529 	inc	a
      005E0F                       1530 01214$:
      005E0F FA               [12] 1531 	mov	r2,a
      005E10 A2 1B            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005E12 E4               [12] 1533 	clr	a
      005E13 33               [12] 1534 	rlc	a
      005E14 B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005E17 80 03            [24] 1536 	sjmp	00105$
      005E19                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      005E19 02 5A FC         [24] 1539 	ljmp	_control_stall
      005E1C                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      005E1C 8E 02            [24] 1542 	mov	ar2,r6
      005E1E 90 07 CA         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005E21 ED               [12] 1544 	mov	a,r5
      005E22 F0               [24] 1545 	movx	@dptr,a
      005E23 90 07 CB         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005E26 EB               [12] 1547 	mov	a,r3
      005E27 F0               [24] 1548 	movx	@dptr,a
      005E28 EC               [12] 1549 	mov	a,r4
      005E29 A3               [24] 1550 	inc	dptr
      005E2A F0               [24] 1551 	movx	@dptr,a
      005E2B 8A 82            [24] 1552 	mov	dpl, r2
      005E2D 12 5B 9A         [24] 1553 	lcall	_descriptor_select
      005E30 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005E33 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      005E36 E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005E38 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005E3A 70 03            [24] 1559 	jnz	00107$
      005E3C 02 5A FC         [24] 1560 	ljmp	_control_stall
      005E3F                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005E3F 90 07 66         [24] 1563 	mov	dptr,#_D0SetupLen
      005E42 E0               [24] 1564 	movx	a,@dptr
      005E43 F8               [12] 1565 	mov	r0,a
      005E44 A3               [24] 1566 	inc	dptr
      005E45 E0               [24] 1567 	movx	a,@dptr
      005E46 FA               [12] 1568 	mov	r2,a
      005E47 C3               [12] 1569 	clr	c
      005E48 E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005E4A 98               [12] 1571 	subb	a,r0
      005E4B E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E4D 9A               [12] 1573 	subb	a,r2
      005E4E 50 06            [24] 1574 	jnc	00303$
      005E50 E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005E52 54 3F            [12] 1576 	anl	a,#0x3f
      005E54 60 04            [24] 1577 	jz	00304$
      005E56                       1578 00303$:
                                   1579 ;	assignBit
      005E56 C2 1B            [12] 1580 	clr	_control_setup_sloc2_1_0
      005E58 80 02            [24] 1581 	sjmp	00305$
      005E5A                       1582 00304$:
                                   1583 ;	assignBit
      005E5A D2 1B            [12] 1584 	setb	_control_setup_sloc2_1_0
      005E5C                       1585 00305$:
      005E5C 90 07 C7         [24] 1586 	mov	dptr,#_control_zlp
      005E5F A2 1B            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005E61 E4               [12] 1588 	clr	a
      005E62 33               [12] 1589 	rlc	a
      005E63 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      005E64 90 07 66         [24] 1592 	mov	dptr,#_D0SetupLen
      005E67 E0               [24] 1593 	movx	a,@dptr
      005E68 F9               [12] 1594 	mov	r1,a
      005E69 A3               [24] 1595 	inc	dptr
      005E6A E0               [24] 1596 	movx	a,@dptr
      005E6B FA               [12] 1597 	mov	r2,a
      005E6C C3               [12] 1598 	clr	c
      005E6D E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005E6F 99               [12] 1600 	subb	a,r1
      005E70 E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E72 9A               [12] 1602 	subb	a,r2
      005E73 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005E75 90 07 66         [24] 1605 	mov	dptr,#_D0SetupLen
      005E78 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005E7A F0               [24] 1607 	movx	@dptr,a
      005E7B E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005E7D A3               [24] 1609 	inc	dptr
      005E7E F0               [24] 1610 	movx	@dptr,a
      005E7F                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005E7F 90 07 66         [24] 1613 	mov	dptr,#_D0SetupLen
      005E82 E0               [24] 1614 	movx	a,@dptr
      005E83 F9               [12] 1615 	mov	r1,a
      005E84 A3               [24] 1616 	inc	dptr
      005E85 E0               [24] 1617 	movx	a,@dptr
      005E86 49               [12] 1618 	orl	a,r1
      005E87 60 04            [24] 1619 	jz	00306$
      005E89 7A 01            [12] 1620 	mov	r2,#0x01
      005E8B 80 02            [24] 1621 	sjmp	00307$
      005E8D                       1622 00306$:
      005E8D 7A 02            [12] 1623 	mov	r2,#0x02
      005E8F                       1624 00307$:
      005E8F 90 07 C4         [24] 1625 	mov	dptr,#_control_phase
      005E92 EA               [12] 1626 	mov	a,r2
      005E93 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      005E94 90 07 66         [24] 1629 	mov	dptr,#_D0SetupLen
      005E97 E0               [24] 1630 	movx	a,@dptr
      005E98 F9               [12] 1631 	mov	r1,a
      005E99 A3               [24] 1632 	inc	dptr
      005E9A E0               [24] 1633 	movx	a,@dptr
      005E9B 49               [12] 1634 	orl	a,r1
      005E9C 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      005E9E 02 5B 1E         [24] 1637 	ljmp	_control_next
      005EA1                       1638 00111$:
      005EA1 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      005EA2 02 5A FC         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      005EA5                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005EA5 EF               [12] 1645 	mov	a,r7
      005EA6 70 23            [24] 1646 	jnz	00118$
      005EA8 30 17 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      005EAB 30 19 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      005EAE 8D 01            [24] 1649 	mov	ar1,r5
      005EB0 8E 02            [24] 1650 	mov	ar2,r6
      005EB2 C3               [12] 1651 	clr	c
      005EB3 74 7F            [12] 1652 	mov	a,#0x7f
      005EB5 99               [12] 1653 	subb	a,r1
      005EB6 E4               [12] 1654 	clr	a
      005EB7 9A               [12] 1655 	subb	a,r2
      005EB8 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      005EBA 90 07 66         [24] 1659 	mov	dptr,#_D0SetupLen
      005EBD ED               [12] 1660 	mov	a,r5
      005EBE F0               [24] 1661 	movx	@dptr,a
      005EBF EE               [12] 1662 	mov	a,r6
      005EC0 A3               [24] 1663 	inc	dptr
      005EC1 F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      005EC2 90 07 C4         [24] 1666 	mov	dptr,#_control_phase
      005EC5 74 03            [12] 1667 	mov	a,#0x03
      005EC7 F0               [24] 1668 	movx	@dptr,a
      005EC8 02 64 AB         [24] 1669 	ljmp	00291$
      005ECB                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      005ECB 02 5A FC         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005ECE                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005ECE EF               [12] 1676 	mov	a,r7
      005ECF 70 3C            [24] 1677 	jnz	00145$
      005ED1 30 17 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      005ED4 30 19 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      005ED7 8D 01            [24] 1680 	mov	ar1,r5
      005ED9 8E 02            [24] 1681 	mov	ar2,r6
      005EDB C3               [12] 1682 	clr	c
      005EDC 74 01            [12] 1683 	mov	a,#0x01
      005EDE 99               [12] 1684 	subb	a,r1
      005EDF E4               [12] 1685 	clr	a
      005EE0 9A               [12] 1686 	subb	a,r2
      005EE1 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      005EE3 C0 06            [24] 1690 	push	ar6
      005EE5 C0 05            [24] 1691 	push	ar5
      005EE7 12 5A A5         [24] 1692 	lcall	_endpoints_reset
      005EEA D0 05            [24] 1693 	pop	ar5
      005EEC D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      005EEE 90 07 6B         [24] 1696 	mov	dptr,#_D0UsbConfig
      005EF1 ED               [12] 1697 	mov	a,r5
      005EF2 F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      005EF3 A2 1A            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005EF5 B3               [12] 1701 	cpl	c
      005EF6 92 1B            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005EF8 90 07 6C         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005EFB E4               [12] 1704 	clr	a
      005EFC 33               [12] 1705 	rlc	a
      005EFD F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      005EFE 90 07 95         [24] 1708 	mov	dptr,#_keyboard_reset
      005F01 74 01            [12] 1709 	mov	a,#0x01
      005F03 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      005F04 90 07 C4         [24] 1712 	mov	dptr,#_control_phase
      005F07 74 03            [12] 1713 	mov	a,#0x03
      005F09 F0               [24] 1714 	movx	@dptr,a
      005F0A 02 64 AB         [24] 1715 	ljmp	00291$
      005F0D                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      005F0D BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005F10 80 03            [24] 1719 	sjmp	01232$
      005F12                       1720 01231$:
      005F12 02 5A FC         [24] 1721 	ljmp	_control_stall
      005F15                       1722 01232$:
      005F15 90 07 6B         [24] 1723 	mov	dptr,#_D0UsbConfig
      005F18 E0               [24] 1724 	movx	a,@dptr
      005F19 70 03            [24] 1725 	jnz	01233$
      005F1B 02 5A FC         [24] 1726 	ljmp	_control_stall
      005F1E                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005F1E BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005F21 BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005F24 8D 01            [24] 1731 	mov	ar1,r5
      005F26 8E 02            [24] 1732 	mov	ar2,r6
      005F28 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005F2B BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005F2E 90 07 66         [24] 1735 	mov	dptr,#_D0SetupLen
      005F31 E0               [24] 1736 	movx	a,@dptr
      005F32 F9               [12] 1737 	mov	r1,a
      005F33 A3               [24] 1738 	inc	dptr
      005F34 E0               [24] 1739 	movx	a,@dptr
      005F35 FA               [12] 1740 	mov	r2,a
      005F36 B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      005F39 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      005F3C 90 07 73         [24] 1743 	mov	dptr,#_raw_state
      005F3F E0               [24] 1744 	movx	a,@dptr
      005F40 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      005F42 90 07 73         [24] 1747 	mov	dptr,#_raw_state
      005F45 74 01            [12] 1748 	mov	a,#0x01
      005F47 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      005F48 90 07 C5         [24] 1751 	mov	dptr,#_output_kind
      005F4B F0               [24] 1752 	movx	@dptr,a
      005F4C 80 52            [24] 1753 	sjmp	00136$
      005F4E                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005F4E EB               [12] 1756 	mov	a,r3
      005F4F 4C               [12] 1757 	orl	a,r4
      005F50 70 20            [24] 1758 	jnz	00130$
      005F52 8D 01            [24] 1759 	mov	ar1,r5
      005F54 8E 02            [24] 1760 	mov	ar2,r6
      005F56 B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      005F59 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      005F5C 90 07 66         [24] 1763 	mov	dptr,#_D0SetupLen
      005F5F E0               [24] 1764 	movx	a,@dptr
      005F60 F9               [12] 1765 	mov	r1,a
      005F61 A3               [24] 1766 	inc	dptr
      005F62 E0               [24] 1767 	movx	a,@dptr
      005F63 FA               [12] 1768 	mov	r2,a
      005F64 B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      005F67 BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      005F6A 90 07 C5         [24] 1772 	mov	dptr,#_output_kind
      005F6D 74 02            [12] 1773 	mov	a,#0x02
      005F6F F0               [24] 1774 	movx	@dptr,a
      005F70 80 2E            [24] 1775 	sjmp	00136$
      005F72                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005F72 BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      005F75 BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      005F78 8D 01            [24] 1780 	mov	ar1,r5
      005F7A 8E 02            [24] 1781 	mov	ar2,r6
      005F7C B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      005F7F BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      005F82 90 07 66         [24] 1784 	mov	dptr,#_D0SetupLen
      005F85 E0               [24] 1785 	movx	a,@dptr
      005F86 F9               [12] 1786 	mov	r1,a
      005F87 A3               [24] 1787 	inc	dptr
      005F88 E0               [24] 1788 	movx	a,@dptr
      005F89 FA               [12] 1789 	mov	r2,a
      005F8A B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      005F8D BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      005F90 90 07 C5         [24] 1793 	mov	dptr,#_output_kind
      005F93 74 03            [12] 1794 	mov	a,#0x03
      005F95 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      005F96 90 07 C6         [24] 1797 	mov	dptr,#_output_report_id
      005F99 23               [12] 1798 	rl	a
      005F9A F0               [24] 1799 	movx	@dptr,a
      005F9B 80 03            [24] 1800 	sjmp	00136$
      005F9D                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      005F9D 02 5A FC         [24] 1803 	ljmp	_control_stall
      005FA0                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      005FA0 90 07 C4         [24] 1806 	mov	dptr,#_control_phase
      005FA3 74 04            [12] 1807 	mov	a,#0x04
      005FA5 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      005FA6 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      005FA7 02 5A FC         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      005FAA                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005FAA BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      005FAD 30 17 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      005FB0 30 18 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      005FB3 90 07 66         [24] 1819 	mov	dptr,#_D0SetupLen
      005FB6 E0               [24] 1820 	movx	a,@dptr
      005FB7 F9               [12] 1821 	mov	r1,a
      005FB8 A3               [24] 1822 	inc	dptr
      005FB9 E0               [24] 1823 	movx	a,@dptr
      005FBA FA               [12] 1824 	mov	r2,a
      005FBB B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      005FBE BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      005FC1 90 07 6B         [24] 1828 	mov	dptr,#_D0UsbConfig
      005FC4 E0               [24] 1829 	movx	a,@dptr
      005FC5 90 10 00         [24] 1830 	mov	dptr,#0x1000
      005FC8 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      005FC9 90 22 08         [24] 1833 	mov	dptr,#0x2208
      005FCC 74 01            [12] 1834 	mov	a,#0x01
      005FCE F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      005FCF 90 07 C4         [24] 1837 	mov	dptr,#_control_phase
      005FD2 04               [12] 1838 	inc	a
      005FD3 F0               [24] 1839 	movx	@dptr,a
      005FD4 02 64 AB         [24] 1840 	ljmp	00291$
      005FD7                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      005FD7 02 5A FC         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005FDA                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005FDA BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      005FDD 30 16 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      005FE0 30 18 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      005FE3 90 07 66         [24] 1850 	mov	dptr,#_D0SetupLen
      005FE6 E0               [24] 1851 	movx	a,@dptr
      005FE7 F9               [12] 1852 	mov	r1,a
      005FE8 A3               [24] 1853 	inc	dptr
      005FE9 E0               [24] 1854 	movx	a,@dptr
      005FEA FA               [12] 1855 	mov	r2,a
      005FEB B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      005FEE BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      005FF1 90 07 6B         [24] 1858 	mov	dptr,#_D0UsbConfig
      005FF4 E0               [24] 1859 	movx	a,@dptr
      005FF5 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      005FF7 90 10 00         [24] 1862 	mov	dptr,#0x1000
      005FFA E4               [12] 1863 	clr	a
      005FFB F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      005FFC 90 22 08         [24] 1866 	mov	dptr,#0x2208
      005FFF 04               [12] 1867 	inc	a
      006000 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      006001 90 07 C4         [24] 1870 	mov	dptr,#_control_phase
      006004 04               [12] 1871 	inc	a
      006005 F0               [24] 1872 	movx	@dptr,a
      006006 02 64 AB         [24] 1873 	ljmp	00291$
      006009                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006009 30 16 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      00600C 90 07 6B         [24] 1877 	mov	dptr,#_D0UsbConfig
      00600F E0               [24] 1878 	movx	a,@dptr
      006010 60 18            [24] 1879 	jz	00161$
      006012 BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      006015 30 19 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006018 EB               [12] 1883 	mov	a,r3
      006019 4C               [12] 1884 	orl	a,r4
      00601A 70 05            [24] 1885 	jnz	00159$
      00601C 90 06 43         [24] 1886 	mov	dptr,#_keyboard_idle
      00601F EE               [12] 1887 	mov	a,r6
      006020 F0               [24] 1888 	movx	@dptr,a
      006021                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      006021 90 07 C4         [24] 1891 	mov	dptr,#_control_phase
      006024 74 03            [12] 1892 	mov	a,#0x03
      006026 F0               [24] 1893 	movx	@dptr,a
      006027 02 64 AB         [24] 1894 	ljmp	00291$
      00602A                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      00602A 02 5A FC         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00602D                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00602D BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      006030 30 16 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      006033 30 18 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      006036 30 19 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      006039 90 07 6B         [24] 1905 	mov	dptr,#_D0UsbConfig
      00603C E0               [24] 1906 	movx	a,@dptr
      00603D 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      00603F 90 07 C4         [24] 1909 	mov	dptr,#_control_phase
      006042 74 03            [12] 1910 	mov	a,#0x03
      006044 F0               [24] 1911 	movx	@dptr,a
      006045 02 64 AB         [24] 1912 	ljmp	00291$
      006048                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006048 EB               [12] 1915 	mov	a,r3
      006049 4C               [12] 1916 	orl	a,r4
      00604A 70 2C            [24] 1917 	jnz	00175$
      00604C 90 07 6B         [24] 1918 	mov	dptr,#_D0UsbConfig
      00604F E0               [24] 1919 	movx	a,@dptr
      006050 60 26            [24] 1920 	jz	00175$
      006052 BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      006055 30 19 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      006058 8D 01            [24] 1923 	mov	ar1,r5
      00605A 8E 02            [24] 1924 	mov	ar2,r6
      00605C C3               [12] 1925 	clr	c
      00605D 74 01            [12] 1926 	mov	a,#0x01
      00605F 99               [12] 1927 	subb	a,r1
      006060 E4               [12] 1928 	clr	a
      006061 9A               [12] 1929 	subb	a,r2
      006062 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      006064 90 0D B9         [24] 1933 	mov	dptr,#_keyboard_protocol
      006067 ED               [12] 1934 	mov	a,r5
      006068 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      006069 90 07 95         [24] 1937 	mov	dptr,#_keyboard_reset
      00606C 74 01            [12] 1938 	mov	a,#0x01
      00606E F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      00606F 90 07 C4         [24] 1941 	mov	dptr,#_control_phase
      006072 74 03            [12] 1942 	mov	a,#0x03
      006074 F0               [24] 1943 	movx	@dptr,a
      006075 02 64 AB         [24] 1944 	ljmp	00291$
      006078                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      006078 02 5A FC         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      00607B                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      00607B 20 18 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      00607E 02 5A FC         [24] 1952 	ljmp	_control_stall
      006081                       1953 01283$:
      006081 90 07 66         [24] 1954 	mov	dptr,#_D0SetupLen
      006084 E0               [24] 1955 	movx	a,@dptr
      006085 F9               [12] 1956 	mov	r1,a
      006086 A3               [24] 1957 	inc	dptr
      006087 E0               [24] 1958 	movx	a,@dptr
      006088 FA               [12] 1959 	mov	r2,a
      006089 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      00608C BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      00608F 80 03            [24] 1962 	sjmp	01285$
      006091                       1963 01284$:
      006091 02 5A FC         [24] 1964 	ljmp	_control_stall
      006094                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006094 E4               [12] 1967 	clr	a
      006095 BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      006098 04               [12] 1969 	inc	a
      006099                       1970 01286$:
      006099 FA               [12] 1971 	mov	r2,a
      00609A 60 03            [24] 1972 	jz	00196$
      00609C 20 17 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      00609F                       1974 00196$:
      00609F BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      0060A2 30 16 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      0060A5 90 07 6B         [24] 1977 	mov	dptr,#_D0UsbConfig
      0060A8 E0               [24] 1978 	movx	a,@dptr
      0060A9 70 29            [24] 1979 	jnz	00189$
      0060AB                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0060AB BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      0060AE 90 07 6B         [24] 1983 	mov	dptr,#_D0UsbConfig
      0060B1 E0               [24] 1984 	movx	a,@dptr
      0060B2 60 6A            [24] 1985 	jz	00190$
      0060B4 EB               [12] 1986 	mov	a,r3
      0060B5 4C               [12] 1987 	orl	a,r4
      0060B6 60 1C            [24] 1988 	jz	00189$
      0060B8 8B 00            [24] 1989 	mov	ar0,r3
      0060BA 8C 01            [24] 1990 	mov	ar1,r4
      0060BC B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      0060BF B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      0060C2 80 10            [24] 1993 	sjmp	00189$
      0060C4                       1994 01298$:
      0060C4 C3               [12] 1995 	clr	c
      0060C5 E8               [12] 1996 	mov	a,r0
      0060C6 94 81            [12] 1997 	subb	a,#0x81
      0060C8 E9               [12] 1998 	mov	a,r1
      0060C9 94 00            [12] 1999 	subb	a,#0x00
      0060CB 40 51            [24] 2000 	jc	00190$
      0060CD 74 83            [12] 2001 	mov	a,#0x83
      0060CF 98               [12] 2002 	subb	a,r0
      0060D0 E4               [12] 2003 	clr	a
      0060D1 99               [12] 2004 	subb	a,r1
      0060D2 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      0060D4                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      0060D4 8B 01            [24] 2009 	mov	ar1,r3
      0060D6 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0060D9 EA               [12] 2012 	mov	a,r2
      0060DA 60 0B            [24] 2013 	jz	00308$
      0060DC 90 07 6D         [24] 2014 	mov	dptr,#_USB_SleepStatus
      0060DF E0               [24] 2015 	movx	a,@dptr
      0060E0 54 01            [12] 2016 	anl	a,#0x01
      0060E2 25 E0            [12] 2017 	add	a,acc
      0060E4 FA               [12] 2018 	mov	r2,a
      0060E5 80 22            [24] 2019 	sjmp	00309$
      0060E7                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0060E7 BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      0060EA E9               [12] 2023 	mov	a,r1
      0060EB 60 18            [24] 2024 	jz	00310$
      0060ED 89 00            [24] 2025 	mov	ar0,r1
      0060EF 79 00            [12] 2026 	mov	r1,#0x00
      0060F1 74 22            [12] 2027 	mov	a,#0x22
      0060F3 29               [12] 2028 	add	a, r1
      0060F4 F9               [12] 2029 	mov	r1,a
      0060F5 88 82            [24] 2030 	mov	dpl,r0
      0060F7 89 83            [24] 2031 	mov	dph,r1
      0060F9 E0               [24] 2032 	movx	a,@dptr
      0060FA F9               [12] 2033 	mov	r1,a
      0060FB 53 01 03         [24] 2034 	anl	ar1,#0x03
      0060FE B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      006101 79 01            [12] 2036 	mov	r1,#0x01
      006103 80 02            [24] 2037 	sjmp	00311$
      006105                       2038 00310$:
      006105 79 00            [12] 2039 	mov	r1,#0x00
      006107                       2040 00311$:
      006107 89 02            [24] 2041 	mov	ar2,r1
      006109                       2042 00309$:
      006109 90 10 00         [24] 2043 	mov	dptr,#0x1000
      00610C EA               [12] 2044 	mov	a,r2
      00610D F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      00610E A3               [24] 2047 	inc	dptr
      00610F E4               [12] 2048 	clr	a
      006110 F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      006111 90 22 08         [24] 2051 	mov	dptr,#0x2208
      006114 74 02            [12] 2052 	mov	a,#0x02
      006116 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      006117 90 07 C4         [24] 2055 	mov	dptr,#_control_phase
      00611A F0               [24] 2056 	movx	@dptr,a
      00611B 02 64 AB         [24] 2057 	ljmp	00291$
      00611E                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      00611E 02 5A FC         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006121                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      006121 20 19 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      006124 02 61 B4         [24] 2065 	ljmp	00279$
      006127                       2066 01307$:
      006127 90 07 6B         [24] 2067 	mov	dptr,#_D0UsbConfig
      00612A E0               [24] 2068 	movx	a,@dptr
      00612B 70 03            [24] 2069 	jnz	01308$
      00612D 02 61 B4         [24] 2070 	ljmp	00279$
      006130                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      006130 EF               [12] 2073 	mov	a,r7
      006131 70 29            [24] 2074 	jnz	00218$
      006133 8D 01            [24] 2075 	mov	ar1,r5
      006135 8E 02            [24] 2076 	mov	ar2,r6
      006137 B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      00613A BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      00613D 30 17 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006140 90 07 65         [24] 2081 	mov	dptr,#_D0SetupReqCode
      006143 E0               [24] 2082 	movx	a,@dptr
      006144 FA               [12] 2083 	mov	r2,a
      006145 BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      006148 90 07 6D         [24] 2085 	mov	dptr,#_USB_SleepStatus
      00614B E0               [24] 2086 	movx	a,@dptr
      00614C 43 E0 01         [24] 2087 	orl	acc,#0x01
      00614F F0               [24] 2088 	movx	@dptr,a
      006150 80 59            [24] 2089 	sjmp	00219$
      006152                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      006152 90 07 6D         [24] 2092 	mov	dptr,#_USB_SleepStatus
      006155 E0               [24] 2093 	movx	a,@dptr
      006156 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      006159 F0               [24] 2095 	movx	@dptr,a
      00615A 80 4F            [24] 2096 	sjmp	00219$
      00615C                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00615C BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      00615F 30 18 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      006162 8B 01            [24] 2101 	mov	ar1,r3
      006164 8C 02            [24] 2102 	mov	ar2,r4
      006166 C3               [12] 2103 	clr	c
      006167 E9               [12] 2104 	mov	a,r1
      006168 94 81            [12] 2105 	subb	a,#0x81
      00616A EA               [12] 2106 	mov	a,r2
      00616B 94 00            [12] 2107 	subb	a,#0x00
      00616D 40 39            [24] 2108 	jc	00212$
      00616F 74 83            [12] 2109 	mov	a,#0x83
      006171 99               [12] 2110 	subb	a,r1
      006172 E4               [12] 2111 	clr	a
      006173 9A               [12] 2112 	subb	a,r2
      006174 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      006176 8B 02            [24] 2116 	mov	ar2,r3
      006178 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      00617B 8A 00            [24] 2119 	mov	ar0,r2
      00617D 79 00            [12] 2120 	mov	r1,#0x00
      00617F 74 22            [12] 2121 	mov	a,#0x22
      006181 29               [12] 2122 	add	a, r1
      006182 F9               [12] 2123 	mov	r1,a
      006183 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      006185 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006187 90 07 65         [24] 2126 	mov	dptr,#_D0SetupReqCode
      00618A E0               [24] 2127 	movx	a,@dptr
      00618B F9               [12] 2128 	mov	r1,a
      00618C B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      00618F 79 03            [12] 2130 	mov	r1,#0x03
      006191 80 02            [24] 2131 	sjmp	00319$
      006193                       2132 00318$:
      006193 79 02            [12] 2133 	mov	r1,#0x02
      006195                       2134 00319$:
      006195 43 01 10         [24] 2135 	orl	ar1,#0x10
      006198 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      00619B 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00619E E9               [12] 2138 	mov	a,r1
      00619F F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0061A0 BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      0061A3 12 5A 88         [24] 2142 	lcall	_raw_complete
      0061A6 80 03            [24] 2143 	sjmp	00219$
      0061A8                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      0061A8 02 5A FC         [24] 2146 	ljmp	_control_stall
      0061AB                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      0061AB 90 07 C4         [24] 2149 	mov	dptr,#_control_phase
      0061AE 74 03            [12] 2150 	mov	a,#0x03
      0061B0 F0               [24] 2151 	movx	@dptr,a
      0061B1 02 64 AB         [24] 2152 	ljmp	00291$
      0061B4                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0061B4 E4               [12] 2155 	clr	a
      0061B5 BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      0061B8 04               [12] 2157 	inc	a
      0061B9                       2158 01324$:
      0061B9 FA               [12] 2159 	mov	r2,a
      0061BA 70 03            [24] 2160 	jnz	01326$
      0061BC 02 64 26         [24] 2161 	ljmp	00273$
      0061BF                       2162 01326$:
      0061BF 90 07 65         [24] 2163 	mov	dptr,#_D0SetupReqCode
      0061C2 E0               [24] 2164 	movx	a,@dptr
      0061C3 F9               [12] 2165 	mov	r1,a
      0061C4 B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      0061C7 80 03            [24] 2167 	sjmp	01328$
      0061C9                       2168 01327$:
      0061C9 02 64 26         [24] 2169 	ljmp	00273$
      0061CC                       2170 01328$:
      0061CC 90 07 6B         [24] 2171 	mov	dptr,#_D0UsbConfig
      0061CF E0               [24] 2172 	movx	a,@dptr
      0061D0 70 03            [24] 2173 	jnz	01329$
      0061D2 02 64 26         [24] 2174 	ljmp	00273$
      0061D5                       2175 01329$:
      0061D5 90 07 66         [24] 2176 	mov	dptr,#_D0SetupLen
      0061D8 E0               [24] 2177 	movx	a,@dptr
      0061D9 F8               [12] 2178 	mov	r0,a
      0061DA A3               [24] 2179 	inc	dptr
      0061DB E0               [24] 2180 	movx	a,@dptr
      0061DC 48               [12] 2181 	orl	a,r0
      0061DD 70 03            [24] 2182 	jnz	01330$
      0061DF 02 64 26         [24] 2183 	ljmp	00273$
      0061E2                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      0061E2 C0 03            [24] 2186 	push	ar3
      0061E4 C0 04            [24] 2187 	push	ar4
      0061E6 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0061E8 8E 00            [24] 2190 	mov	ar0,r6
      0061EA B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      0061ED E8               [12] 2192 	mov	a,r0
      0061EE 80 01            [24] 2193 	sjmp	01332$
      0061F0                       2194 01331$:
      0061F0 E4               [12] 2195 	clr	a
      0061F1                       2196 01332$:
      0061F1 F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      0061F3 D0 04            [24] 2198 	pop	ar4
      0061F5 D0 03            [24] 2199 	pop	ar3
      0061F7 E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      0061F9 60 17            [24] 2201 	jz	00251$
      0061FB EB               [12] 2202 	mov	a,r3
      0061FC 4C               [12] 2203 	orl	a,r4
      0061FD 70 13            [24] 2204 	jnz	00251$
      0061FF E9               [12] 2205 	mov	a,r1
      006200 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      006202 90 07 CE         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      006205 74 08            [12] 2209 	mov	a,#0x08
      006207 F0               [24] 2210 	movx	@dptr,a
      006208 E4               [12] 2211 	clr	a
      006209 A3               [24] 2212 	inc	dptr
      00620A F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      00620B 90 07 D0         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      00620E F0               [24] 2216 	movx	@dptr,a
      00620F 02 63 96         [24] 2217 	ljmp	00252$
      006212                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006212 E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      006214 60 27            [24] 2221 	jz	00245$
      006216 BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      006219 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00621C B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      00621F                       2226 01339$:
      00621F 50 1C            [24] 2227 	jnc	00245$
      006221 E9               [12] 2228 	mov	a,r1
      006222 90 BA 32         [24] 2229 	mov	dptr,#_shared_lengths
      006225 93               [24] 2230 	movc	a,@a+dptr
      006226 F8               [12] 2231 	mov	r0,a
      006227 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      006229 90 07 CE         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      00622C E8               [12] 2235 	mov	a,r0
      00622D F0               [24] 2236 	movx	@dptr,a
      00622E E4               [12] 2237 	clr	a
      00622F A3               [24] 2238 	inc	dptr
      006230 F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      006231 E9               [12] 2241 	mov	a,r1
      006232 90 BA 2B         [24] 2242 	mov	dptr,#_shared_offsets
      006235 93               [24] 2243 	movc	a,@a+dptr
      006236 90 07 D0         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      006239 F0               [24] 2245 	movx	@dptr,a
      00623A 02 63 96         [24] 2246 	ljmp	00252$
      00623D                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00623D E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      00623F 60 7A            [24] 2250 	jz	00240$
      006241 BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      006244 BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      006247 E9               [12] 2253 	mov	a,r1
      006248 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00624A 90 07 66         [24] 2256 	mov	dptr,#_D0SetupLen
      00624D E0               [24] 2257 	movx	a,@dptr
      00624E F8               [12] 2258 	mov	r0,a
      00624F A3               [24] 2259 	inc	dptr
      006250 E0               [24] 2260 	movx	a,@dptr
      006251 F9               [12] 2261 	mov	r1,a
      006252 C3               [12] 2262 	clr	c
      006253 E8               [12] 2263 	mov	a,r0
      006254 94 20            [12] 2264 	subb	a,#0x20
      006256 E9               [12] 2265 	mov	a,r1
      006257 94 00            [12] 2266 	subb	a,#0x00
      006259 50 0A            [24] 2267 	jnc	00320$
      00625B 90 07 66         [24] 2268 	mov	dptr,#_D0SetupLen
      00625E E0               [24] 2269 	movx	a,@dptr
      00625F F8               [12] 2270 	mov	r0,a
      006260 A3               [24] 2271 	inc	dptr
      006261 E0               [24] 2272 	movx	a,@dptr
      006262 F9               [12] 2273 	mov	r1,a
      006263 80 04            [24] 2274 	sjmp	00321$
      006265                       2275 00320$:
      006265 78 20            [12] 2276 	mov	r0,#0x20
      006267 79 00            [12] 2277 	mov	r1,#0x00
      006269                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006269 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      00626C                       2281 00293$:
      00626C C0 03            [24] 2282 	push	ar3
      00626E C0 04            [24] 2283 	push	ar4
      006270 AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      006272 7C 00            [12] 2285 	mov	r4,#0x00
      006274 C3               [12] 2286 	clr	c
      006275 EB               [12] 2287 	mov	a,r3
      006276 98               [12] 2288 	subb	a,r0
      006277 EC               [12] 2289 	mov	a,r4
      006278 99               [12] 2290 	subb	a,r1
      006279 D0 04            [24] 2291 	pop	ar4
      00627B D0 03            [24] 2292 	pop	ar3
      00627D 50 32            [24] 2293 	jnc	00222$
      00627F C0 00            [24] 2294 	push	ar0
      006281 C0 01            [24] 2295 	push	ar1
      006283 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006286 74 10            [12] 2297 	mov	a,#0x10
      006288 24 00            [12] 2298 	add	a, #0x00
      00628A F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      00628C A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      00628E 79 00            [12] 2301 	mov	r1,#0x00
      006290 74 C0            [12] 2302 	mov	a,#0xc0
      006292 28               [12] 2303 	add	a, r0
      006293 F8               [12] 2304 	mov	r0,a
      006294 E4               [12] 2305 	clr	a
      006295 39               [12] 2306 	addc	a, r1
      006296 F9               [12] 2307 	mov	r1,a
      006297 88 82            [24] 2308 	mov	dpl,r0
      006299 74 10            [12] 2309 	mov	a,#0x10
      00629B 29               [12] 2310 	add	a, r1
      00629C F5 83            [12] 2311 	mov	dph,a
      00629E E0               [24] 2312 	movx	a,@dptr
      00629F 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      0062A2 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0062A5 F0               [24] 2315 	movx	@dptr,a
      0062A6 E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      0062A8 04               [12] 2317 	inc	a
      0062A9 F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      0062AB D0 01            [24] 2319 	pop	ar1
      0062AD D0 00            [24] 2320 	pop	ar0
      0062AF 80 BB            [24] 2321 	sjmp	00293$
      0062B1                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      0062B1 90 07 CE         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      0062B4 E4               [12] 2325 	clr	a
      0062B5 F0               [24] 2326 	movx	@dptr,a
      0062B6 A3               [24] 2327 	inc	dptr
      0062B7 F0               [24] 2328 	movx	@dptr,a
      0062B8 02 63 96         [24] 2329 	ljmp	00252$
      0062BB                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0062BB 8D 00            [24] 2332 	mov	ar0,r5
      0062BD 8E 01            [24] 2333 	mov	ar1,r6
      0062BF B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      0062C2 B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      0062C5 EB               [12] 2336 	mov	a,r3
      0062C6 4C               [12] 2337 	orl	a,r4
      0062C7 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0062C9 90 07 70         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      0062CC E0               [24] 2341 	movx	a,@dptr
      0062CD 90 10 00         [24] 2342 	mov	dptr,#0x1000
      0062D0 F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      0062D1 90 07 CE         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      0062D4 E4               [12] 2346 	clr	a
      0062D5 F0               [24] 2347 	movx	@dptr,a
      0062D6 A3               [24] 2348 	inc	dptr
      0062D7 F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      0062D8 90 07 66         [24] 2351 	mov	dptr,#_D0SetupLen
      0062DB 04               [12] 2352 	inc	a
      0062DC F0               [24] 2353 	movx	@dptr,a
      0062DD E4               [12] 2354 	clr	a
      0062DE A3               [24] 2355 	inc	dptr
      0062DF F0               [24] 2356 	movx	@dptr,a
      0062E0 02 63 96         [24] 2357 	ljmp	00252$
      0062E3                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0062E3 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      0062E6 B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      0062E9 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      0062EC BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0062EF C0 03            [24] 2365 	push	ar3
      0062F1 C0 04            [24] 2366 	push	ar4
      0062F3 90 10 00         [24] 2367 	mov	dptr,#0x1000
      0062F6 74 06            [12] 2368 	mov	a,#0x06
      0062F8 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0062F9 90 07 70         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      0062FC E0               [24] 2372 	movx	a,@dptr
      0062FD 90 10 01         [24] 2373 	mov	dptr,#0x1001
      006300 F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      006301 90 07 CE         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      006304 E4               [12] 2377 	clr	a
      006305 F0               [24] 2378 	movx	@dptr,a
      006306 A3               [24] 2379 	inc	dptr
      006307 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006308 90 07 66         [24] 2382 	mov	dptr,#_D0SetupLen
      00630B E0               [24] 2383 	movx	a,@dptr
      00630C FB               [12] 2384 	mov	r3,a
      00630D A3               [24] 2385 	inc	dptr
      00630E E0               [24] 2386 	movx	a,@dptr
      00630F FC               [12] 2387 	mov	r4,a
      006310 C3               [12] 2388 	clr	c
      006311 74 02            [12] 2389 	mov	a,#0x02
      006313 9B               [12] 2390 	subb	a,r3
      006314 E4               [12] 2391 	clr	a
      006315 9C               [12] 2392 	subb	a,r4
      006316 D0 04            [24] 2393 	pop	ar4
      006318 D0 03            [24] 2394 	pop	ar3
      00631A 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      00631C 90 07 66         [24] 2397 	mov	dptr,#_D0SetupLen
      00631F 74 02            [12] 2398 	mov	a,#0x02
      006321 F0               [24] 2399 	movx	@dptr,a
      006322 E4               [12] 2400 	clr	a
      006323 A3               [24] 2401 	inc	dptr
      006324 F0               [24] 2402 	movx	@dptr,a
      006325 80 6F            [24] 2403 	sjmp	00252$
      006327                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006327 B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      00632A B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      00632D BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      006330 BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      006333 90 10 00         [24] 2411 	mov	dptr,#0x1000
      006336 74 41            [12] 2412 	mov	a,#0x41
      006338 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      006339 A3               [24] 2415 	inc	dptr
      00633A 74 4B            [12] 2416 	mov	a,#0x4b
      00633C F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      00633D A3               [24] 2419 	inc	dptr
      00633E 74 42            [12] 2420 	mov	a,#0x42
      006340 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      006341 A3               [24] 2423 	inc	dptr
      006342 74 54            [12] 2424 	mov	a,#0x54
      006344 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      006345 A3               [24] 2427 	inc	dptr
      006346 74 01            [12] 2428 	mov	a,#0x01
      006348 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      006349 90 07 71         [24] 2431 	mov	dptr,#_ak820_boot_stage
      00634C E0               [24] 2432 	movx	a,@dptr
      00634D 90 10 05         [24] 2433 	mov	dptr,#0x1005
      006350 F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006351 90 07 72         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      006354 E0               [24] 2437 	movx	a,@dptr
      006355 90 10 06         [24] 2438 	mov	dptr,#0x1006
      006358 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006359 90 07 6C         [24] 2441 	mov	dptr,#_USB_EnumStatus
      00635C E0               [24] 2442 	movx	a,@dptr
      00635D 60 02            [24] 2443 	jz	00322$
      00635F 74 01            [12] 2444 	mov	a,#0x01
      006361                       2445 00322$:
      006361 F9               [12] 2446 	mov	r1,a
      006362 90 07 6D         [24] 2447 	mov	dptr,#_USB_SleepStatus
      006365 E0               [24] 2448 	movx	a,@dptr
      006366 54 02            [12] 2449 	anl	a,#0x02
      006368 F8               [12] 2450 	mov	r0,a
      006369 E9               [12] 2451 	mov	a,r1
      00636A 42 00            [12] 2452 	orl	ar0,a
      00636C 90 10 07         [24] 2453 	mov	dptr,#0x1007
      00636F E8               [12] 2454 	mov	a,r0
      006370 F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      006371 90 07 CE         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      006374 E4               [12] 2458 	clr	a
      006375 F0               [24] 2459 	movx	@dptr,a
      006376 A3               [24] 2460 	inc	dptr
      006377 F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      006378 90 07 66         [24] 2463 	mov	dptr,#_D0SetupLen
      00637B E0               [24] 2464 	movx	a,@dptr
      00637C F8               [12] 2465 	mov	r0,a
      00637D A3               [24] 2466 	inc	dptr
      00637E E0               [24] 2467 	movx	a,@dptr
      00637F F9               [12] 2468 	mov	r1,a
      006380 C3               [12] 2469 	clr	c
      006381 74 08            [12] 2470 	mov	a,#0x08
      006383 98               [12] 2471 	subb	a,r0
      006384 E4               [12] 2472 	clr	a
      006385 99               [12] 2473 	subb	a,r1
      006386 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006388 90 07 66         [24] 2476 	mov	dptr,#_D0SetupLen
      00638B 74 08            [12] 2477 	mov	a,#0x08
      00638D F0               [24] 2478 	movx	@dptr,a
      00638E E4               [12] 2479 	clr	a
      00638F A3               [24] 2480 	inc	dptr
      006390 F0               [24] 2481 	movx	@dptr,a
      006391 80 03            [24] 2482 	sjmp	00252$
      006393                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006393 02 5A FC         [24] 2485 	ljmp	_control_stall
      006396                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006396 90 07 CE         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      006399 E0               [24] 2489 	movx	a,@dptr
      00639A F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      00639C A3               [24] 2491 	inc	dptr
      00639D E0               [24] 2492 	movx	a,@dptr
      00639E F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      0063A0 E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      0063A2 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0063A4 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      0063A6 90 07 66         [24] 2498 	mov	dptr,#_D0SetupLen
      0063A9 E0               [24] 2499 	movx	a,@dptr
      0063AA F8               [12] 2500 	mov	r0,a
      0063AB A3               [24] 2501 	inc	dptr
      0063AC E0               [24] 2502 	movx	a,@dptr
      0063AD F9               [12] 2503 	mov	r1,a
      0063AE C3               [12] 2504 	clr	c
      0063AF E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      0063B1 98               [12] 2506 	subb	a,r0
      0063B2 E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0063B4 99               [12] 2508 	subb	a,r1
      0063B5 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      0063B7 90 07 66         [24] 2511 	mov	dptr,#_D0SetupLen
      0063BA E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      0063BC F0               [24] 2513 	movx	@dptr,a
      0063BD E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0063BF A3               [24] 2515 	inc	dptr
      0063C0 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0063C1                       2518 00559$:
      0063C1 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      0063C4                       2520 00296$:
      0063C4 90 07 66         [24] 2521 	mov	dptr,#_D0SetupLen
      0063C7 E0               [24] 2522 	movx	a,@dptr
      0063C8 F8               [12] 2523 	mov	r0,a
      0063C9 C3               [12] 2524 	clr	c
      0063CA E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      0063CC 98               [12] 2526 	subb	a,r0
      0063CD 50 46            [24] 2527 	jnc	00263$
      0063CF 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0063D2 74 10            [12] 2529 	mov	a,#0x10
      0063D4 24 00            [12] 2530 	add	a, #0x00
      0063D6 F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      0063D8 90 07 D0         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      0063DB E0               [24] 2533 	movx	a,@dptr
      0063DC 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      0063DE 24 96            [12] 2535 	add	a, #_input_snapshot
      0063E0 F5 82            [12] 2536 	mov	dpl,a
      0063E2 E4               [12] 2537 	clr	a
      0063E3 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      0063E5 F5 83            [12] 2539 	mov	dph,a
      0063E7 E0               [24] 2540 	movx	a,@dptr
      0063E8 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      0063EB 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0063EE F0               [24] 2543 	movx	@dptr,a
      0063EF E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      0063F1 04               [12] 2545 	inc	a
      0063F2 F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      0063F4 80 CE            [24] 2547 	sjmp	00296$
      0063F6                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0063F6 BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      0063F9 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      0063FC 90 07 66         [24] 2552 	mov	dptr,#_D0SetupLen
      0063FF E0               [24] 2553 	movx	a,@dptr
      006400 F8               [12] 2554 	mov	r0,a
      006401 A3               [24] 2555 	inc	dptr
      006402 E0               [24] 2556 	movx	a,@dptr
      006403 F9               [12] 2557 	mov	r1,a
      006404 C3               [12] 2558 	clr	c
      006405 74 20            [12] 2559 	mov	a,#0x20
      006407 98               [12] 2560 	subb	a,r0
      006408 E4               [12] 2561 	clr	a
      006409 99               [12] 2562 	subb	a,r1
      00640A 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      00640C 90 07 66         [24] 2565 	mov	dptr,#_D0SetupLen
      00640F 74 20            [12] 2566 	mov	a,#0x20
      006411 F0               [24] 2567 	movx	@dptr,a
      006412 E4               [12] 2568 	clr	a
      006413 A3               [24] 2569 	inc	dptr
      006414 F0               [24] 2570 	movx	@dptr,a
      006415                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006415 90 07 66         [24] 2573 	mov	dptr,#_D0SetupLen
      006418 E0               [24] 2574 	movx	a,@dptr
      006419 90 22 08         [24] 2575 	mov	dptr,#0x2208
      00641C F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      00641D 90 07 C4         [24] 2578 	mov	dptr,#_control_phase
      006420 74 02            [12] 2579 	mov	a,#0x02
      006422 F0               [24] 2580 	movx	@dptr,a
      006423 02 64 AB         [24] 2581 	ljmp	00291$
      006426                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006426 EB               [12] 2584 	mov	a,r3
      006427 4C               [12] 2585 	orl	a,r4
      006428 70 37            [24] 2586 	jnz	00265$
      00642A 90 07 6B         [24] 2587 	mov	dptr,#_D0UsbConfig
      00642D E0               [24] 2588 	movx	a,@dptr
      00642E 60 31            [24] 2589 	jz	00265$
      006430 EA               [12] 2590 	mov	a,r2
      006431 60 2E            [24] 2591 	jz	00265$
      006433 90 07 65         [24] 2592 	mov	dptr,#_D0SetupReqCode
      006436 E0               [24] 2593 	movx	a,@dptr
      006437 FA               [12] 2594 	mov	r2,a
      006438 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      00643B 30 18 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      00643E 90 07 66         [24] 2597 	mov	dptr,#_D0SetupLen
      006441 E0               [24] 2598 	movx	a,@dptr
      006442 F9               [12] 2599 	mov	r1,a
      006443 A3               [24] 2600 	inc	dptr
      006444 E0               [24] 2601 	movx	a,@dptr
      006445 FA               [12] 2602 	mov	r2,a
      006446 B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      006449 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      00644C 90 0D B9         [24] 2606 	mov	dptr,#_keyboard_protocol
      00644F E0               [24] 2607 	movx	a,@dptr
      006450 90 10 00         [24] 2608 	mov	dptr,#0x1000
      006453 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      006454 90 22 08         [24] 2611 	mov	dptr,#0x2208
      006457 74 01            [12] 2612 	mov	a,#0x01
      006459 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      00645A 90 07 C4         [24] 2615 	mov	dptr,#_control_phase
      00645D 04               [12] 2616 	inc	a
      00645E F0               [24] 2617 	movx	@dptr,a
      00645F 80 4A            [24] 2618 	sjmp	00291$
      006461                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      006461 02 5A FC         [24] 2622 	ljmp	_control_stall
      006464                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006464 30 16 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      006467 90 07 6B         [24] 2626 	mov	dptr,#_D0UsbConfig
      00646A E0               [24] 2627 	movx	a,@dptr
      00646B 60 38            [24] 2628 	jz	00284$
      00646D BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      006470 8E 05            [24] 2630 	mov	ar5,r6
      006472 7E 00            [12] 2631 	mov	r6,#0x00
      006474 ED               [12] 2632 	mov	a,r5
      006475 4E               [12] 2633 	orl	a,r6
      006476 70 2D            [24] 2634 	jnz	00284$
      006478 90 07 66         [24] 2635 	mov	dptr,#_D0SetupLen
      00647B E0               [24] 2636 	movx	a,@dptr
      00647C FE               [12] 2637 	mov	r6,a
      00647D A3               [24] 2638 	inc	dptr
      00647E E0               [24] 2639 	movx	a,@dptr
      00647F FF               [12] 2640 	mov	r7,a
      006480 BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006483 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006486 EB               [12] 2644 	mov	a,r3
      006487 4C               [12] 2645 	orl	a,r4
      006488 70 07            [24] 2646 	jnz	00324$
      00648A 90 06 43         [24] 2647 	mov	dptr,#_keyboard_idle
      00648D E0               [24] 2648 	movx	a,@dptr
      00648E FF               [12] 2649 	mov	r7,a
      00648F 80 02            [24] 2650 	sjmp	00325$
      006491                       2651 00324$:
      006491 7F 00            [12] 2652 	mov	r7,#0x00
      006493                       2653 00325$:
      006493 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006496 EF               [12] 2655 	mov	a,r7
      006497 F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006498 90 22 08         [24] 2658 	mov	dptr,#0x2208
      00649B 74 01            [12] 2659 	mov	a,#0x01
      00649D F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      00649E 90 07 C4         [24] 2662 	mov	dptr,#_control_phase
      0064A1 04               [12] 2663 	inc	a
      0064A2 F0               [24] 2664 	movx	@dptr,a
      0064A3 80 06            [24] 2665 	sjmp	00291$
      0064A5                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      0064A5 02 5A FC         [24] 2669 	ljmp	_control_stall
      0064A8                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      0064A8 02 5A FC         [24] 2672 	ljmp	_control_stall
      0064AB                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0064AB 90 22 00         [24] 2675 	mov	dptr,#0x2200
      0064AE 74 C0            [12] 2676 	mov	a,#0xc0
      0064B0 F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      0064B1 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      0064B2                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0064B2 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      0064B5 E0               [24] 2692 	movx	a,@dptr
      0064B6 20 E6 01         [24] 2693 	jb	acc.6,00102$
      0064B9 22               [24] 2694 	ret
      0064BA                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0064BA 90 07 C4         [24] 2697 	mov	dptr,#_control_phase
      0064BD E0               [24] 2698 	movx	a,@dptr
      0064BE FF               [12] 2699 	mov	r7,a
      0064BF BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      0064C2 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      0064C5 E0               [24] 2702 	movx	a,@dptr
      0064C6 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      0064C8 90 07 C4         [24] 2705 	mov	dptr,#_control_phase
      0064CB E4               [12] 2706 	clr	a
      0064CC F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0064CD 90 22 00         [24] 2709 	mov	dptr,#0x2200
      0064D0 74 02            [12] 2710 	mov	a,#0x02
      0064D2 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      0064D3 22               [24] 2713 	ret
      0064D4                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0064D4 BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      0064D7 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      0064DA E0               [24] 2718 	movx	a,@dptr
      0064DB FF               [12] 2719 	mov	r7,a
      0064DC 90 07 66         [24] 2720 	mov	dptr,#_D0SetupLen
      0064DF E0               [24] 2721 	movx	a,@dptr
      0064E0 FD               [12] 2722 	mov	r5,a
      0064E1 A3               [24] 2723 	inc	dptr
      0064E2 E0               [24] 2724 	movx	a,@dptr
      0064E3 FE               [12] 2725 	mov	r6,a
      0064E4 7C 00            [12] 2726 	mov	r4,#0x00
      0064E6 EF               [12] 2727 	mov	a,r7
      0064E7 B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      0064EA EC               [12] 2729 	mov	a,r4
      0064EB B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      0064EE 80 03            [24] 2731 	sjmp	00107$
      0064F0                       2732 00209$:
      0064F0                       2733 00106$:
      0064F0 02 5A FC         [24] 2734 	ljmp	_control_stall
      0064F3                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0064F3 90 07 C5         [24] 2737 	mov	dptr,#_output_kind
      0064F6 E0               [24] 2738 	movx	a,@dptr
      0064F7 FF               [12] 2739 	mov	r7,a
      0064F8 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      0064FB 90 07 73         [24] 2741 	mov	dptr,#_raw_state
      0064FE E0               [24] 2742 	movx	a,@dptr
      0064FF FE               [12] 2743 	mov	r6,a
      006500 BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006503 7E 00            [12] 2746 	mov	r6,#0x00
      006505                       2747 00121$:
      006505 EE               [12] 2748 	mov	a,r6
      006506 24 74            [12] 2749 	add	a, #_raw_buffer
      006508 FC               [12] 2750 	mov	r4,a
      006509 E4               [12] 2751 	clr	a
      00650A 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      00650C FD               [12] 2753 	mov	r5,a
      00650D 8E 82            [24] 2754 	mov	dpl,r6
      00650F 74 10            [12] 2755 	mov	a,#0x10
      006511 24 00            [12] 2756 	add	a, #0x00
      006513 F5 83            [12] 2757 	mov	dph,a
      006515 E0               [24] 2758 	movx	a,@dptr
      006516 8C 82            [24] 2759 	mov	dpl,r4
      006518 8D 83            [24] 2760 	mov	dph,r5
      00651A F0               [24] 2761 	movx	@dptr,a
      00651B 0E               [12] 2762 	inc	r6
      00651C BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      00651F                       2764 00214$:
      00651F 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006521 90 07 73         [24] 2767 	mov	dptr,#_raw_state
      006524 74 02            [12] 2768 	mov	a,#0x02
      006526 F0               [24] 2769 	movx	@dptr,a
      006527 80 2B            [24] 2770 	sjmp	00119$
      006529                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      006529 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      00652C 90 10 00         [24] 2775 	mov	dptr,#0x1000
      00652F E0               [24] 2776 	movx	a,@dptr
      006530 90 07 70         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      006533 F0               [24] 2778 	movx	@dptr,a
      006534 80 1E            [24] 2779 	sjmp	00119$
      006536                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006536 BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      006539 90 10 00         [24] 2783 	mov	dptr,#0x1000
      00653C E0               [24] 2784 	movx	a,@dptr
      00653D FF               [12] 2785 	mov	r7,a
      00653E 90 07 C6         [24] 2786 	mov	dptr,#_output_report_id
      006541 E0               [24] 2787 	movx	a,@dptr
      006542 FE               [12] 2788 	mov	r6,a
      006543 EF               [12] 2789 	mov	a,r7
      006544 B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      006547 90 10 01         [24] 2792 	mov	dptr,#0x1001
      00654A E0               [24] 2793 	movx	a,@dptr
      00654B 90 07 70         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      00654E F0               [24] 2795 	movx	@dptr,a
      00654F 80 03            [24] 2796 	sjmp	00119$
      006551                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      006551 02 5A FC         [24] 2799 	ljmp	_control_stall
      006554                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      006554 90 07 C5         [24] 2802 	mov	dptr,#_output_kind
      006557 E4               [12] 2803 	clr	a
      006558 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      006559 90 07 66         [24] 2806 	mov	dptr,#_D0SetupLen
      00655C F0               [24] 2807 	movx	@dptr,a
      00655D A3               [24] 2808 	inc	dptr
      00655E F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      00655F 90 07 C4         [24] 2811 	mov	dptr,#_control_phase
      006562 74 03            [12] 2812 	mov	a,#0x03
      006564 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      006565 90 22 08         [24] 2815 	mov	dptr,#0x2208
      006568 E4               [12] 2816 	clr	a
      006569 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00656A F5 82            [12] 2819 	mov	dpl,a
      00656C 74 48            [12] 2820 	mov	a,#0x48
      00656E F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      00656F 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      006570                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      006570 90 07 C4         [24] 2833 	mov	dptr,#_control_phase
      006573 E0               [24] 2834 	movx	a,@dptr
      006574 FF               [12] 2835 	mov	r7,a
      006575 BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      006578 90 07 66         [24] 2838 	mov	dptr,#_D0SetupLen
      00657B E0               [24] 2839 	movx	a,@dptr
      00657C FD               [12] 2840 	mov	r5,a
      00657D A3               [24] 2841 	inc	dptr
      00657E E0               [24] 2842 	movx	a,@dptr
      00657F 4D               [12] 2843 	orl	a,r5
      006580 70 06            [24] 2844 	jnz	00101$
      006582 90 07 C7         [24] 2845 	mov	dptr,#_control_zlp
      006585 E0               [24] 2846 	movx	a,@dptr
      006586 60 0A            [24] 2847 	jz	00102$
      006588                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006588 90 22 00         [24] 2850 	mov	dptr,#0x2200
      00658B E0               [24] 2851 	movx	a,@dptr
      00658C 64 40            [12] 2852 	xrl	a,#0x40
      00658E F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      00658F 02 5B 1E         [24] 2856 	ljmp	_control_next
      006592                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      006592 90 07 C4         [24] 2859 	mov	dptr,#_control_phase
      006595 74 02            [12] 2860 	mov	a,#0x02
      006597 F0               [24] 2861 	movx	@dptr,a
      006598 80 18            [24] 2862 	sjmp	00110$
      00659A                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      00659A BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00659D 90 07 65         [24] 2867 	mov	dptr,#_D0SetupReqCode
      0065A0 E0               [24] 2868 	movx	a,@dptr
      0065A1 FF               [12] 2869 	mov	r7,a
      0065A2 BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      0065A5 90 07 66         [24] 2871 	mov	dptr,#_D0SetupLen
      0065A8 E0               [24] 2872 	movx	a,@dptr
      0065A9 90 22 07         [24] 2873 	mov	dptr,#0x2207
      0065AC F0               [24] 2874 	movx	@dptr,a
      0065AD                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      0065AD 90 07 C4         [24] 2877 	mov	dptr,#_control_phase
      0065B0 E4               [12] 2878 	clr	a
      0065B1 F0               [24] 2879 	movx	@dptr,a
      0065B2                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065B2 90 22 00         [24] 2882 	mov	dptr,#0x2200
      0065B5 74 82            [12] 2883 	mov	a,#0x82
      0065B7 F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      0065B8 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      0065B9                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      0065B9                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      0065B9 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      0065BC E0               [24] 2902 	movx	a,@dptr
      0065BD 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      0065C0 12 5A A5         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      0065C3 90 22 07         [24] 2907 	mov	dptr,#0x2207
      0065C6 E4               [12] 2908 	clr	a
      0065C7 F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0065C8 90 07 6D         [24] 2911 	mov	dptr,#_USB_SleepStatus
      0065CB F0               [24] 2912 	movx	@dptr,a
      0065CC 90 07 6C         [24] 2913 	mov	dptr,#_USB_EnumStatus
      0065CF F0               [24] 2914 	movx	@dptr,a
      0065D0 90 07 6B         [24] 2915 	mov	dptr,#_D0UsbConfig
      0065D3 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      0065D4 90 07 70         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      0065D7 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      0065D8 90 0D B9         [24] 2921 	mov	dptr,#_keyboard_protocol
      0065DB 04               [12] 2922 	inc	a
      0065DC F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      0065DD 90 06 43         [24] 2925 	mov	dptr,#_keyboard_idle
      0065E0 E4               [12] 2926 	clr	a
      0065E1 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      0065E2 90 07 95         [24] 2929 	mov	dptr,#_keyboard_reset
      0065E5 04               [12] 2930 	inc	a
      0065E6 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      0065E7 90 07 65         [24] 2933 	mov	dptr,#_D0SetupReqCode
      0065EA 74 FF            [12] 2934 	mov	a,#0xff
      0065EC F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      0065ED 90 07 66         [24] 2937 	mov	dptr,#_D0SetupLen
      0065F0 E4               [12] 2938 	clr	a
      0065F1 F0               [24] 2939 	movx	@dptr,a
      0065F2 A3               [24] 2940 	inc	dptr
      0065F3 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      0065F4 90 07 C4         [24] 2943 	mov	dptr,#_control_phase
      0065F7 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065F8 90 22 00         [24] 2946 	mov	dptr,#0x2200
      0065FB 74 02            [12] 2947 	mov	a,#0x02
      0065FD F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      0065FE 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      006601 E4               [12] 2951 	clr	a
      006602 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006603 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006606 04               [12] 2955 	inc	a
      006607 F0               [24] 2956 	movx	@dptr,a
      006608 02 66 9E         [24] 2957 	ljmp	00130$
      00660B                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      00660B 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      00660E E0               [24] 2961 	movx	a,@dptr
      00660F 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      006612 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006615 E0               [24] 2965 	movx	a,@dptr
      006616 FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006617 74 07            [12] 2968 	mov	a,#0x07
      006619 5F               [12] 2969 	anl	a,r7
      00661A FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      00661B EF               [12] 2972 	mov	a,r7
      00661C 54 18            [12] 2973 	anl	a,#0x18
      00661E 70 08            [24] 2974 	jnz	00115$
      006620 EE               [12] 2975 	mov	a,r6
      006621 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      006623 12 64 B2         [24] 2978 	lcall	_control_out
      006626 80 43            [24] 2979 	sjmp	00116$
      006628                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006628 8F 05            [24] 2982 	mov	ar5,r7
      00662A 74 18            [12] 2983 	mov	a,#0x18
      00662C 5D               [12] 2984 	anl	a,r5
      00662D FC               [12] 2985 	mov	r4,a
      00662E BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      006631 EE               [12] 2988 	mov	a,r6
      006632 70 05            [24] 2989 	jnz	00106$
      006634 12 65 70         [24] 2990 	lcall	_control_in
      006637 80 32            [24] 2991 	sjmp	00116$
      006639                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      006639 EE               [12] 2994 	mov	a,r6
      00663A 24 FC            [12] 2995 	add	a,#0xff - 0x03
      00663C 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00663E 8E 04            [24] 2999 	mov	ar4,r6
      006640 7B 00            [12] 3000 	mov	r3,#0x00
      006642 74 22            [12] 3001 	mov	a,#0x22
      006644 2B               [12] 3002 	add	a, r3
      006645 FB               [12] 3003 	mov	r3,a
      006646 8C 82            [24] 3004 	mov	dpl,r4
      006648 8B 83            [24] 3005 	mov	dph,r3
      00664A E0               [24] 3006 	movx	a,@dptr
      00664B FA               [12] 3007 	mov	r2,a
      00664C 74 FC            [12] 3008 	mov	a,#0xfc
      00664E 5A               [12] 3009 	anl	a,r2
      00664F 44 02            [12] 3010 	orl	a,#0x02
      006651 8C 82            [24] 3011 	mov	dpl,r4
      006653 8B 83            [24] 3012 	mov	dph,r3
      006655 F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006656 BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      006659 12 5A 88         [24] 3016 	lcall	_raw_complete
      00665C 80 0D            [24] 3017 	sjmp	00116$
      00665E                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00665E 53 05 18         [24] 3020 	anl	ar5,#0x18
      006661 BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      006664 EF               [12] 3022 	mov	a,r7
      006665 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      006668 12 5D 15         [24] 3025 	lcall	_control_setup
      00666B                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      00666B 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      00666E E4               [12] 3029 	clr	a
      00666F F0               [24] 3030 	movx	@dptr,a
      006670 80 2C            [24] 3031 	sjmp	00130$
      006672                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      006672 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      006675 E0               [24] 3035 	movx	a,@dptr
      006676 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006679 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      00667C E0               [24] 3039 	movx	a,@dptr
      00667D 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      006680 90 07 6D         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006683 E0               [24] 3042 	movx	a,@dptr
      006684 43 E0 02         [24] 3043 	orl	acc,#0x02
      006687 F0               [24] 3044 	movx	@dptr,a
      006688 80 0E            [24] 3045 	sjmp	00120$
      00668A                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      00668A 90 07 6D         [24] 3048 	mov	dptr,#_USB_SleepStatus
      00668D E0               [24] 3049 	movx	a,@dptr
      00668E 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      006691 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      006692 90 07 95         [24] 3053 	mov	dptr,#_keyboard_reset
      006695 74 01            [12] 3054 	mov	a,#0x01
      006697 F0               [24] 3055 	movx	@dptr,a
      006698                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006698 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      00669B 74 04            [12] 3059 	mov	a,#0x04
      00669D F0               [24] 3060 	movx	@dptr,a
      00669E                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      00669E 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      0066A1 E0               [24] 3064 	movx	a,@dptr
      0066A2 54 25            [12] 3065 	anl	a,#0x25
      0066A4 60 03            [24] 3066 	jz	00242$
      0066A6 02 65 B9         [24] 3067 	ljmp	00129$
      0066A9                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      0066A9 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      0066AA                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3080 ;	assignBit
      0066AA C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      0066AC 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      0066AF E4               [12] 3084 	clr	a
      0066B0 F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      0066B1 90 07 73         [24] 3087 	mov	dptr,#_raw_state
      0066B4 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      0066B5 12 5A A5         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0066B8 90 07 6D         [24] 3092 	mov	dptr,#_USB_SleepStatus
      0066BB E4               [12] 3093 	clr	a
      0066BC F0               [24] 3094 	movx	@dptr,a
      0066BD 90 07 6C         [24] 3095 	mov	dptr,#_USB_EnumStatus
      0066C0 F0               [24] 3096 	movx	@dptr,a
      0066C1 90 07 6B         [24] 3097 	mov	dptr,#_D0UsbConfig
      0066C4 F0               [24] 3098 	movx	@dptr,a
      0066C5 90 22 07         [24] 3099 	mov	dptr,#0x2207
      0066C8 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0066C9 90 07 6E         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      0066CC F0               [24] 3103 	movx	@dptr,a
      0066CD 90 07 6F         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      0066D0 F0               [24] 3105 	movx	@dptr,a
      0066D1 90 07 70         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      0066D4 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      0066D5 90 0D B9         [24] 3109 	mov	dptr,#_keyboard_protocol
      0066D8 04               [12] 3110 	inc	a
      0066D9 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      0066DA 90 06 43         [24] 3113 	mov	dptr,#_keyboard_idle
      0066DD E4               [12] 3114 	clr	a
      0066DE F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      0066DF 90 07 95         [24] 3117 	mov	dptr,#_keyboard_reset
      0066E2 F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      0066E3 90 07 C4         [24] 3120 	mov	dptr,#_control_phase
      0066E6 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      0066E7 90 07 65         [24] 3123 	mov	dptr,#_D0SetupReqCode
      0066EA 14               [12] 3124 	dec	a
      0066EB F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      0066EC 90 07 66         [24] 3127 	mov	dptr,#_D0SetupLen
      0066EF E4               [12] 3128 	clr	a
      0066F0 F0               [24] 3129 	movx	@dptr,a
      0066F1 A3               [24] 3130 	inc	dptr
      0066F2 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066F3 90 22 00         [24] 3133 	mov	dptr,#0x2200
      0066F6 74 02            [12] 3134 	mov	a,#0x02
      0066F8 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      0066F9 90 22 37         [24] 3137 	mov	dptr,#0x2237
      0066FC 74 7F            [12] 3138 	mov	a,#0x7f
      0066FE F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      0066FF 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      006702 74 FF            [12] 3142 	mov	a,#0xff
      006704 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006705 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      006708 74 07            [12] 3146 	mov	a,#0x07
      00670A F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      00670B A3               [24] 3149 	inc	dptr
      00670C 74 80            [12] 3150 	mov	a,#0x80
      00670E F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3153 ;	assignBit
      00670F D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      006711 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      006712                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      006712 90 07 6D         [24] 3169 	mov	dptr,#_USB_SleepStatus
      006715 E0               [24] 3170 	movx	a,@dptr
      006716 FF               [12] 3171 	mov	r7,a
      006717 BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      00671A 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      00671D E0               [24] 3175 	movx	a,@dptr
      00671E FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      00671F E0               [24] 3178 	movx	a,@dptr
      006720 FE               [12] 3179 	mov	r6,a
      006721 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      006724 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      006727 EE               [12] 3182 	mov	a,r6
      006728 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      006729 7E 0A            [12] 3185 	mov	r6,#0x0a
      00672B                       3186 00108$:
      00672B EE               [12] 3187 	mov	a,r6
      00672C 60 09            [24] 3188 	jz	00105$
      00672E 90 00 01         [24] 3189 	mov	dptr,#0x0001
      006731 12 58 CC         [24] 3190 	lcall	_mDelaymS
      006734 1E               [12] 3191 	dec	r6
      006735 80 F4            [24] 3192 	sjmp	00108$
      006737                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      006737 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      00673A EF               [12] 3196 	mov	a,r7
      00673B F0               [24] 3197 	movx	@dptr,a
      00673C                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      00673C 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      00673D                       3220 _ak820_usb_send:
      00673D E5 82            [12] 3221 	mov	a,dpl
      00673F 90 07 D4         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006742 F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      006743 90 07 D5         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006746 74 2E            [12] 3226 	mov	a,#0x2e
      006748 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006749 90 07 D4         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00674C E0               [24] 3230 	movx	a,@dptr
      00674D FF               [12] 3231 	mov	r7,a
      00674E BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      006751                       3233 00306$:
      006751 40 14            [24] 3234 	jc	00101$
      006753 EF               [12] 3235 	mov	a,r7
      006754 24 FC            [12] 3236 	add	a,#0xff - 0x03
      006756 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      006758 90 07 D3         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      00675B E0               [24] 3240 	movx	a,@dptr
      00675C FE               [12] 3241 	mov  r6,a
      00675D 24 BF            [12] 3242 	add	a,#0xff - 0x40
      00675F 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      006761 90 07 6C         [24] 3245 	mov	dptr,#_USB_EnumStatus
      006764 E0               [24] 3246 	movx	a,@dptr
      006765 70 04            [24] 3247 	jnz	00102$
      006767                       3248 00101$:
      006767 75 82 00         [24] 3249 	mov	dpl, #0x00
      00676A 22               [24] 3250 	ret
      00676B                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      00676B BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      00676E BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      006771 80 04            [24] 3256 	sjmp	00107$
      006773                       3257 00313$:
      006773 75 82 00         [24] 3258 	mov	dpl, #0x00
      006776 22               [24] 3259 	ret
      006777                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      006777 90 07 D5         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00677A E4               [12] 3263 	clr	a
      00677B F0               [24] 3264 	movx	@dptr,a
      00677C 80 3C            [24] 3265 	sjmp	00119$
      00677E                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      00677E BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      006781 90 07 D1         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006784 E0               [24] 3271 	movx	a,@dptr
      006785 FD               [12] 3272 	mov	r5,a
      006786 A3               [24] 3273 	inc	dptr
      006787 E0               [24] 3274 	movx	a,@dptr
      006788 FF               [12] 3275 	mov	r7,a
      006789 8D 82            [24] 3276 	mov	dpl,r5
      00678B 8F 83            [24] 3277 	mov	dph,r7
      00678D E0               [24] 3278 	movx	a,@dptr
      00678E FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      00678F BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      006792                       3282 00316$:
      006792 50 0E            [24] 3283 	jnc	00108$
      006794 EF               [12] 3284 	mov	a,r7
      006795 90 BA 32         [24] 3285 	mov	dptr,#_shared_lengths
      006798 93               [24] 3286 	movc	a,@a+dptr
      006799 FD               [12] 3287 	mov	r5,a
      00679A 60 06            [24] 3288 	jz	00108$
      00679C EE               [12] 3289 	mov	a,r6
      00679D B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      0067A0 80 04            [24] 3291 	sjmp	00109$
      0067A2                       3292 00319$:
      0067A2                       3293 00108$:
      0067A2 75 82 00         [24] 3294 	mov	dpl, #0x00
      0067A5 22               [24] 3295 	ret
      0067A6                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      0067A6 EF               [12] 3298 	mov	a,r7
      0067A7 90 BA 2B         [24] 3299 	mov	dptr,#_shared_offsets
      0067AA 93               [24] 3300 	movc	a,@a+dptr
      0067AB 90 07 D5         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0067AE F0               [24] 3302 	movx	@dptr,a
      0067AF 80 09            [24] 3303 	sjmp	00119$
      0067B1                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      0067B1 BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      0067B4 80 04            [24] 3307 	sjmp	00119$
      0067B6                       3308 00320$:
      0067B6 75 82 00         [24] 3309 	mov	dpl, #0x00
      0067B9 22               [24] 3310 	ret
      0067BA                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      0067BA 90 07 6D         [24] 3313 	mov	dptr,#_USB_SleepStatus
      0067BD E0               [24] 3314 	movx	a,@dptr
      0067BE 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      0067C1 12 67 12         [24] 3316 	lcall	_USB_WakeUp_PC
      0067C4 75 82 00         [24] 3317 	mov	dpl, #0x00
      0067C7 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      0067C8                       3320 00184$:
      0067C8 7F FA            [12] 3321 	mov	r7,#0xfa
      0067CA                       3322 00127$:
      0067CA 90 07 D4         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0067CD E0               [24] 3324 	movx	a,@dptr
      0067CE FC               [12] 3325 	mov	r4,a
      0067CF 7D 00            [12] 3326 	mov	r5,#0x00
      0067D1 8C 02            [24] 3327 	mov	ar2,r4
      0067D3 74 22            [12] 3328 	mov	a,#0x22
      0067D5 2D               [12] 3329 	add	a, r5
      0067D6 FB               [12] 3330 	mov	r3,a
      0067D7 8A 82            [24] 3331 	mov	dpl,r2
      0067D9 8B 83            [24] 3332 	mov	dph,r3
      0067DB E0               [24] 3333 	movx	a,@dptr
      0067DC 54 03            [12] 3334 	anl	a,#0x03
      0067DE 70 20            [24] 3335 	jnz	00129$
      0067E0 8F 03            [24] 3336 	mov	ar3,r7
      0067E2 1F               [12] 3337 	dec	r7
      0067E3 EB               [12] 3338 	mov	a,r3
      0067E4 60 1A            [24] 3339 	jz	00129$
      0067E6 7B 28            [12] 3340 	mov	r3,#0x28
      0067E8                       3341 00141$:
      0067E8 EB               [12] 3342 	mov	a,r3
      0067E9 60 DF            [24] 3343 	jz	00127$
      0067EB 90 00 01         [24] 3344 	mov	dptr,#0x0001
      0067EE C0 07            [24] 3345 	push	ar7
      0067F0 C0 06            [24] 3346 	push	ar6
      0067F2 C0 03            [24] 3347 	push	ar3
      0067F4 12 58 90         [24] 3348 	lcall	_mDelayuS
      0067F7 D0 03            [24] 3349 	pop	ar3
      0067F9 D0 06            [24] 3350 	pop	ar6
      0067FB D0 07            [24] 3351 	pop	ar7
      0067FD 1B               [12] 3352 	dec	r3
      0067FE 80 E8            [24] 3353 	sjmp	00141$
      006800                       3354 00129$:
                                   3355 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006800 A2 AF            [12] 3356 	mov	c,_EA
      006802 E4               [12] 3357 	clr	a
      006803 33               [12] 3358 	rlc	a
      006804 FF               [12] 3359 	mov	r7,a
                                   3360 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3361 ;	assignBit
      006805 C2 AF            [12] 3362 	clr	_EA
                                   3363 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006807 90 07 6C         [24] 3364 	mov	dptr,#_USB_EnumStatus
      00680A E0               [24] 3365 	movx	a,@dptr
      00680B 60 25            [24] 3366 	jz	00130$
      00680D 90 07 D4         [24] 3367 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006810 E0               [24] 3368 	movx	a,@dptr
      006811 FB               [12] 3369 	mov	r3,a
      006812 F9               [12] 3370 	mov	r1,a
      006813 7A 00            [12] 3371 	mov	r2,#0x00
      006815 74 22            [12] 3372 	mov	a,#0x22
      006817 2A               [12] 3373 	add	a, r2
      006818 FA               [12] 3374 	mov	r2,a
      006819 89 82            [24] 3375 	mov	dpl,r1
      00681B 8A 83            [24] 3376 	mov	dph,r2
      00681D E0               [24] 3377 	movx	a,@dptr
      00681E FA               [12] 3378 	mov	r2,a
      00681F 53 02 03         [24] 3379 	anl	ar2,#0x03
      006822 BA 02 0D         [24] 3380 	cjne	r2,#0x02,00130$
                                   3381 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006825 BB 03 13         [24] 3382 	cjne	r3,#0x03,00192$
      006828 90 07 73         [24] 3383 	mov	dptr,#_raw_state
      00682B E0               [24] 3384 	movx	a,@dptr
      00682C FB               [12] 3385 	mov	r3,a
      00682D BB 03 02         [24] 3386 	cjne	r3,#0x03,00331$
      006830 80 09            [24] 3387 	sjmp	00192$
      006832                       3388 00331$:
      006832                       3389 00130$:
                                   3390 ;	assignBit
      006832 EF               [12] 3391 	mov	a,r7
      006833 24 FF            [12] 3392 	add	a,#0xff
      006835 92 AF            [24] 3393 	mov	_EA,c
      006837 75 82 00         [24] 3394 	mov	dpl, #0x00
      00683A 22               [24] 3395 	ret
                                   3396 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      00683B                       3397 00192$:
      00683B 7B 00            [12] 3398 	mov	r3,#0x00
      00683D                       3399 00144$:
      00683D C3               [12] 3400 	clr	c
      00683E EB               [12] 3401 	mov	a,r3
      00683F 9E               [12] 3402 	subb	a,r6
      006840 50 67            [24] 3403 	jnc	00137$
                                   3404 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006842 C0 07            [24] 3405 	push	ar7
      006844 90 07 D4         [24] 3406 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006847 E0               [24] 3407 	movx	a,@dptr
      006848 F9               [12] 3408 	mov	r1,a
      006849 E4               [12] 3409 	clr	a
      00684A C3               [12] 3410 	clr	c
      00684B C9               [12] 3411 	xch	a,r1
      00684C 13               [12] 3412 	rrc	a
      00684D C9               [12] 3413 	xch	a,r1
      00684E 13               [12] 3414 	rrc	a
      00684F A2 E0            [12] 3415 	mov	c,acc.0
      006851 C9               [12] 3416 	xch	a,r1
      006852 13               [12] 3417 	rrc	a
      006853 C9               [12] 3418 	xch	a,r1
      006854 13               [12] 3419 	rrc	a
      006855 C9               [12] 3420 	xch	a,r1
      006856 FA               [12] 3421 	mov	r2,a
      006857 8B 00            [24] 3422 	mov	ar0,r3
      006859 7F 00            [12] 3423 	mov	r7,#0x00
      00685B E8               [12] 3424 	mov	a,r0
      00685C 29               [12] 3425 	add	a, r1
      00685D F9               [12] 3426 	mov	r1,a
      00685E EF               [12] 3427 	mov	a,r7
      00685F 3A               [12] 3428 	addc	a, r2
      006860 24 10            [12] 3429 	add	a,#0x10
      006862 FA               [12] 3430 	mov	r2,a
      006863 90 07 D1         [24] 3431 	mov	dptr,#_ak820_usb_send_PARM_2
      006866 E0               [24] 3432 	movx	a,@dptr
      006867 F8               [12] 3433 	mov	r0,a
      006868 A3               [24] 3434 	inc	dptr
      006869 E0               [24] 3435 	movx	a,@dptr
      00686A FF               [12] 3436 	mov	r7,a
      00686B EB               [12] 3437 	mov	a,r3
      00686C 28               [12] 3438 	add	a, r0
      00686D F5 1B            [12] 3439 	mov	_ak820_usb_send_sloc0_1_0,a
      00686F E4               [12] 3440 	clr	a
      006870 3F               [12] 3441 	addc	a, r7
      006871 F5 1C            [12] 3442 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006873 85 1B 82         [24] 3443 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006876 85 1C 83         [24] 3444 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006879 E0               [24] 3445 	movx	a,@dptr
      00687A 89 82            [24] 3446 	mov	dpl,r1
      00687C 8A 83            [24] 3447 	mov	dph,r2
      00687E F0               [24] 3448 	movx	@dptr,a
                                   3449 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00687F 90 07 D5         [24] 3450 	mov	dptr,#_ak820_usb_send_offset_10000_423
      006882 E0               [24] 3451 	movx	a,@dptr
      006883 F5 1D            [12] 3452 	mov	_ak820_usb_send_sloc1_1_0,a
      006885 74 2E            [12] 3453 	mov	a,#0x2e
      006887 B5 1D 04         [24] 3454 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      00688A D0 07            [24] 3455 	pop	ar7
      00688C 80 18            [24] 3456 	sjmp	00145$
      00688E                       3457 00333$:
      00688E D0 07            [24] 3458 	pop	ar7
      006890 EB               [12] 3459 	mov	a,r3
      006891 25 1D            [12] 3460 	add	a, _ak820_usb_send_sloc1_1_0
      006893 24 96            [12] 3461 	add	a, #_input_snapshot
      006895 F9               [12] 3462 	mov	r1,a
      006896 E4               [12] 3463 	clr	a
      006897 34 07            [12] 3464 	addc	a,#(_input_snapshot >> 8)
      006899 FA               [12] 3465 	mov	r2,a
      00689A 85 1B 82         [24] 3466 	mov	dpl,_ak820_usb_send_sloc0_1_0
      00689D 85 1C 83         [24] 3467 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      0068A0 E0               [24] 3468 	movx	a,@dptr
      0068A1 89 82            [24] 3469 	mov	dpl,r1
      0068A3 8A 83            [24] 3470 	mov	dph,r2
      0068A5 F0               [24] 3471 	movx	@dptr,a
      0068A6                       3472 00145$:
                                   3473 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      0068A6 0B               [12] 3474 	inc	r3
      0068A7 80 94            [24] 3475 	sjmp	00144$
      0068A9                       3476 00137$:
                                   3477 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      0068A9 90 07 D4         [24] 3478 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0068AC E0               [24] 3479 	movx	a,@dptr
      0068AD FB               [12] 3480 	mov	r3,a
      0068AE F9               [12] 3481 	mov	r1,a
      0068AF 7A 00            [12] 3482 	mov	r2,#0x00
      0068B1 74 08            [12] 3483 	mov	a,#0x08
      0068B3 29               [12] 3484 	add	a, r1
      0068B4 F9               [12] 3485 	mov	r1,a
      0068B5 74 22            [12] 3486 	mov	a,#0x22
      0068B7 3A               [12] 3487 	addc	a, r2
      0068B8 FA               [12] 3488 	mov	r2,a
      0068B9 89 82            [24] 3489 	mov	dpl,r1
      0068BB 8A 83            [24] 3490 	mov	dph,r2
      0068BD EE               [12] 3491 	mov	a,r6
      0068BE F0               [24] 3492 	movx	@dptr,a
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      0068BF BB 03 06         [24] 3494 	cjne	r3,#0x03,00139$
      0068C2 90 07 73         [24] 3495 	mov	dptr,#_raw_state
      0068C5 74 04            [12] 3496 	mov	a,#0x04
      0068C7 F0               [24] 3497 	movx	@dptr,a
      0068C8                       3498 00139$:
                                   3499 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0068C8 74 22            [12] 3500 	mov	a,#0x22
      0068CA 2D               [12] 3501 	add	a, r5
      0068CB FD               [12] 3502 	mov	r5,a
      0068CC 8C 82            [24] 3503 	mov	dpl,r4
      0068CE 8D 83            [24] 3504 	mov	dph,r5
      0068D0 E0               [24] 3505 	movx	a,@dptr
      0068D1 FE               [12] 3506 	mov	r6,a
      0068D2 53 06 FC         [24] 3507 	anl	ar6,#0xfc
      0068D5 8C 82            [24] 3508 	mov	dpl,r4
      0068D7 8D 83            [24] 3509 	mov	dph,r5
      0068D9 EE               [12] 3510 	mov	a,r6
      0068DA F0               [24] 3511 	movx	@dptr,a
                                   3512 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3513 ;	assignBit
      0068DB EF               [12] 3514 	mov	a,r7
      0068DC 24 FF            [12] 3515 	add	a,#0xff
      0068DE 92 AF            [24] 3516 	mov	_EA,c
                                   3517 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      0068E0 75 82 01         [24] 3518 	mov	dpl, #0x01
                                   3519 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      0068E3 22               [24] 3520 	ret
                                   3521 ;------------------------------------------------------------
                                   3522 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3523 ;------------------------------------------------------------
                                   3524 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3525 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3526 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3527 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3528 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3529 ;------------------------------------------------------------
                                   3530 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3531 ;	-----------------------------------------
                                   3532 ;	 function ak820_usb_try_send
                                   3533 ;	-----------------------------------------
      0068E4                       3534 _ak820_usb_try_send:
      0068E4 E5 82            [12] 3535 	mov	a,dpl
      0068E6 90 07 D9         [24] 3536 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068E9 F0               [24] 3537 	movx	@dptr,a
                                   3538 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3539 ;	assignBit
      0068EA A2 AF            [12] 3540 	mov	c,_EA
      0068EC 92 1C            [24] 3541 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3542 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      0068EE 90 07 DA         [24] 3543 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0068F1 E4               [12] 3544 	clr	a
      0068F2 F0               [24] 3545 	movx	@dptr,a
                                   3546 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3547 ;	assignBit
      0068F3 C2 AF            [12] 3548 	clr	_EA
                                   3549 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      0068F5 90 07 D9         [24] 3550 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      0068F8 E0               [24] 3551 	movx	a,@dptr
      0068F9 FF               [12] 3552 	mov	r7,a
      0068FA BF 01 00         [24] 3553 	cjne	r7,#0x01,00152$
      0068FD                       3554 00152$:
      0068FD 40 4E            [24] 3555 	jc	00102$
      0068FF EF               [12] 3556 	mov	a,r7
      006900 24 FD            [12] 3557 	add	a,#0xff - 0x02
      006902 40 49            [24] 3558 	jc	00102$
                                   3559 ;	free result
      006904 90 07 6C         [24] 3560 	mov	dptr,#_USB_EnumStatus
      006907 E0               [24] 3561 	movx	a,@dptr
      006908 60 43            [24] 3562 	jz	00102$
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      00690A 90 07 6D         [24] 3564 	mov	dptr,#_USB_SleepStatus
      00690D E0               [24] 3565 	movx	a,@dptr
      00690E 20 E1 3C         [24] 3566 	jb	acc.1,00102$
      006911 90 07 95         [24] 3567 	mov	dptr,#_keyboard_reset
      006914 E0               [24] 3568 	movx	a,@dptr
                                   3569 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006915 70 36            [24] 3570 	jnz	00102$
      006917 8F 06            [24] 3571 	mov	ar6,r7
      006919 24 22            [12] 3572 	add	a,#0x22
      00691B FD               [12] 3573 	mov	r5,a
      00691C 8E 82            [24] 3574 	mov	dpl,r6
      00691E 8D 83            [24] 3575 	mov	dph,r5
      006920 E0               [24] 3576 	movx	a,@dptr
      006921 FE               [12] 3577 	mov	r6,a
      006922 53 06 03         [24] 3578 	anl	ar6,#0x03
      006925 BE 02 25         [24] 3579 	cjne	r6,#0x02,00102$
                                   3580 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006928 90 07 D6         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_2
      00692B E0               [24] 3582 	movx	a,@dptr
      00692C FD               [12] 3583 	mov	r5,a
      00692D A3               [24] 3584 	inc	dptr
      00692E E0               [24] 3585 	movx	a,@dptr
      00692F FE               [12] 3586 	mov	r6,a
      006930 90 07 D8         [24] 3587 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006933 E0               [24] 3588 	movx	a,@dptr
      006934 FC               [12] 3589 	mov	r4,a
      006935 90 07 D1         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_2
      006938 ED               [12] 3591 	mov	a,r5
      006939 F0               [24] 3592 	movx	@dptr,a
      00693A EE               [12] 3593 	mov	a,r6
      00693B A3               [24] 3594 	inc	dptr
      00693C F0               [24] 3595 	movx	@dptr,a
      00693D 90 07 D3         [24] 3596 	mov	dptr,#_ak820_usb_send_PARM_3
      006940 EC               [12] 3597 	mov	a,r4
      006941 F0               [24] 3598 	movx	@dptr,a
      006942 8F 82            [24] 3599 	mov	dpl, r7
      006944 12 67 3D         [24] 3600 	lcall	_ak820_usb_send
      006947 E5 82            [12] 3601 	mov	a, dpl
      006949 90 07 DA         [24] 3602 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      00694C F0               [24] 3603 	movx	@dptr,a
      00694D                       3604 00102$:
                                   3605 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3606 ;	assignBit
      00694D A2 1C            [12] 3607 	mov	c,_ak820_usb_try_send_sloc0_1_0
      00694F 92 AF            [24] 3608 	mov	_EA,c
                                   3609 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      006951 90 07 DA         [24] 3610 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006954 E0               [24] 3611 	movx	a,@dptr
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      006955 F5 82            [12] 3613 	mov	dpl,a
      006957 22               [24] 3614 	ret
                                   3615 ;------------------------------------------------------------
                                   3616 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3617 ;------------------------------------------------------------
                                   3618 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3619 ;	-----------------------------------------
                                   3620 ;	 function raw_request_is_nonpersistent
                                   3621 ;	-----------------------------------------
      006958                       3622 _raw_request_is_nonpersistent:
                                   3623 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      006958 90 07 74         [24] 3624 	mov	dptr,#_raw_buffer
      00695B E0               [24] 3625 	movx	a,@dptr
      00695C FF               [12] 3626 	mov	r7,a
      00695D BF 01 02         [24] 3627 	cjne	r7,#0x01,00302$
      006960 80 35            [24] 3628 	sjmp	00108$
      006962                       3629 00302$:
      006962 BF 02 02         [24] 3630 	cjne	r7,#0x02,00303$
      006965 80 34            [24] 3631 	sjmp	00109$
      006967                       3632 00303$:
      006967 BF 04 02         [24] 3633 	cjne	r7,#0x04,00304$
      00696A 80 2B            [24] 3634 	sjmp	00108$
      00696C                       3635 00304$:
      00696C BF 08 02         [24] 3636 	cjne	r7,#0x08,00305$
      00696F 80 47            [24] 3637 	sjmp	00116$
      006971                       3638 00305$:
      006971 BF 0B 02         [24] 3639 	cjne	r7,#0x0b,00306$
      006974 80 21            [24] 3640 	sjmp	00108$
      006976                       3641 00306$:
      006976 BF 0C 02         [24] 3642 	cjne	r7,#0x0c,00307$
      006979 80 1C            [24] 3643 	sjmp	00108$
      00697B                       3644 00307$:
      00697B BF 0D 02         [24] 3645 	cjne	r7,#0x0d,00308$
      00697E 80 17            [24] 3646 	sjmp	00108$
      006980                       3647 00308$:
      006980 BF 0E 02         [24] 3648 	cjne	r7,#0x0e,00309$
      006983 80 12            [24] 3649 	sjmp	00108$
      006985                       3650 00309$:
      006985 BF 11 02         [24] 3651 	cjne	r7,#0x11,00310$
      006988 80 0D            [24] 3652 	sjmp	00108$
      00698A                       3653 00310$:
      00698A BF 12 02         [24] 3654 	cjne	r7,#0x12,00311$
      00698D 80 08            [24] 3655 	sjmp	00108$
      00698F                       3656 00311$:
      00698F BF FE 02         [24] 3657 	cjne	r7,#0xfe,00312$
      006992 80 46            [24] 3658 	sjmp	00124$
      006994                       3659 00312$:
      006994 02 6A 2F         [24] 3660 	ljmp	00144$
                                   3661 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006997                       3662 00108$:
                                   3663 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006997 75 82 01         [24] 3664 	mov	dpl, #0x01
      00699A 22               [24] 3665 	ret
                                   3666 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      00699B                       3667 00109$:
                                   3668 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      00699B 12 6C 61         [24] 3669 	lcall	_ak820_outline_0167
      00699E BF 01 02         [24] 3670 	cjne	r7,#0x01,00313$
      0069A1 80 0D            [24] 3671 	sjmp	00113$
      0069A3                       3672 00313$:
      0069A3 BF 02 02         [24] 3673 	cjne	r7,#0x02,00314$
      0069A6 80 08            [24] 3674 	sjmp	00113$
      0069A8                       3675 00314$:
      0069A8 BF 03 02         [24] 3676 	cjne	r7,#0x03,00315$
      0069AB 80 03            [24] 3677 	sjmp	00113$
      0069AD                       3678 00315$:
      0069AD BF 04 04         [24] 3679 	cjne	r7,#0x04,00114$
                                   3680 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      0069B0                       3681 00113$:
                                   3682 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      0069B0 75 82 01         [24] 3683 	mov	dpl, #0x01
      0069B3 22               [24] 3684 	ret
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      0069B4                       3686 00114$:
      0069B4 75 82 00         [24] 3687 	mov	dpl, #0x00
      0069B7 22               [24] 3688 	ret
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      0069B8                       3690 00116$:
                                   3691 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      0069B8 12 6C 61         [24] 3692 	lcall	_ak820_outline_0167
      0069BB BF 40 02         [24] 3693 	cjne	r7,#0x40,00318$
      0069BE 80 12            [24] 3694 	sjmp	00121$
      0069C0                       3695 00318$:
      0069C0 BF 41 02         [24] 3696 	cjne	r7,#0x41,00319$
      0069C3 80 0D            [24] 3697 	sjmp	00121$
      0069C5                       3698 00319$:
      0069C5 BF 42 02         [24] 3699 	cjne	r7,#0x42,00320$
      0069C8 80 08            [24] 3700 	sjmp	00121$
      0069CA                       3701 00320$:
      0069CA BF 43 02         [24] 3702 	cjne	r7,#0x43,00321$
      0069CD 80 03            [24] 3703 	sjmp	00121$
      0069CF                       3704 00321$:
      0069CF BF 44 04         [24] 3705 	cjne	r7,#0x44,00122$
                                   3706 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      0069D2                       3707 00121$:
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      0069D2 75 82 01         [24] 3709 	mov	dpl, #0x01
                                   3710 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      0069D5 22               [24] 3711 	ret
      0069D6                       3712 00122$:
      0069D6 75 82 00         [24] 3713 	mov	dpl, #0x00
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      0069D9 22               [24] 3715 	ret
      0069DA                       3716 00124$:
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      0069DA 12 6C 61         [24] 3718 	lcall	_ak820_outline_0167
      0069DD 24 F2            [12] 3719 	add	a,#0xff - 0x0d
      0069DF 40 4A            [24] 3720 	jc	00142$
                                   3721 ;	free result
      0069E1 EF               [12] 3722 	mov	a,r7
      0069E2 24 0A            [12] 3723 	add	a,#(00325$-3-.)
      0069E4 83               [24] 3724 	movc	a,@a+pc
      0069E5 F5 82            [12] 3725 	mov	dpl,a
      0069E7 EF               [12] 3726 	mov	a,r7
      0069E8 24 12            [12] 3727 	add	a,#(00326$-3-.)
      0069EA 83               [24] 3728 	movc	a,@a+pc
      0069EB F5 83            [12] 3729 	mov	dph,a
      0069ED E4               [12] 3730 	clr	a
      0069EE 73               [24] 3731 	jmp	@a+dptr
      0069EF                       3732 00325$:
      0069EF 0B                    3733 	.db	00134$
      0069F0 0B                    3734 	.db	00134$
      0069F1 0B                    3735 	.db	00134$
      0069F2 0B                    3736 	.db	00134$
      0069F3 2B                    3737 	.db	00142$
      0069F4 0B                    3738 	.db	00134$
      0069F5 0B                    3739 	.db	00134$
      0069F6 0B                    3740 	.db	00134$
      0069F7 0B                    3741 	.db	00134$
      0069F8 0B                    3742 	.db	00134$
      0069F9 0B                    3743 	.db	00134$
      0069FA 2B                    3744 	.db	00142$
      0069FB 2B                    3745 	.db	00142$
      0069FC 0F                    3746 	.db	00135$
      0069FD                       3747 00326$:
      0069FD 6A                    3748 	.db	00134$>>8
      0069FE 6A                    3749 	.db	00134$>>8
      0069FF 6A                    3750 	.db	00134$>>8
      006A00 6A                    3751 	.db	00134$>>8
      006A01 6A                    3752 	.db	00142$>>8
      006A02 6A                    3753 	.db	00134$>>8
      006A03 6A                    3754 	.db	00134$>>8
      006A04 6A                    3755 	.db	00134$>>8
      006A05 6A                    3756 	.db	00134$>>8
      006A06 6A                    3757 	.db	00134$>>8
      006A07 6A                    3758 	.db	00134$>>8
      006A08 6A                    3759 	.db	00142$>>8
      006A09 6A                    3760 	.db	00142$>>8
      006A0A 6A                    3761 	.db	00135$>>8
                                   3762 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      006A0B                       3763 00134$:
                                   3764 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      006A0B 75 82 01         [24] 3765 	mov	dpl, #0x01
                                   3766 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      006A0E 22               [24] 3767 	ret
      006A0F                       3768 00135$:
                                   3769 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006A0F 90 07 76         [24] 3770 	mov	dptr,#(_raw_buffer + 0x0002)
      006A12 E0               [24] 3771 	movx	a,@dptr
      006A13 FF               [12] 3772 	mov	r7,a
      006A14 60 0D            [24] 3773 	jz	00139$
      006A16 BF 01 02         [24] 3774 	cjne	r7,#0x01,00328$
      006A19 80 08            [24] 3775 	sjmp	00139$
      006A1B                       3776 00328$:
      006A1B BF 03 02         [24] 3777 	cjne	r7,#0x03,00329$
      006A1E 80 03            [24] 3778 	sjmp	00139$
      006A20                       3779 00329$:
      006A20 BF 05 04         [24] 3780 	cjne	r7,#0x05,00140$
                                   3781 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006A23                       3782 00139$:
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006A23 75 82 01         [24] 3784 	mov	dpl, #0x01
                                   3785 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006A26 22               [24] 3786 	ret
      006A27                       3787 00140$:
      006A27 75 82 00         [24] 3788 	mov	dpl, #0x00
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      006A2A 22               [24] 3790 	ret
      006A2B                       3791 00142$:
      006A2B 75 82 00         [24] 3792 	mov	dpl, #0x00
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      006A2E 22               [24] 3794 	ret
      006A2F                       3795 00144$:
      006A2F 75 82 00         [24] 3796 	mov	dpl, #0x00
                                   3797 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3798 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      006A32 22               [24] 3799 	ret
                                   3800 ;------------------------------------------------------------
                                   3801 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3802 ;------------------------------------------------------------
                                   3803 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3804 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3805 ;------------------------------------------------------------
                                   3806 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3807 ;	-----------------------------------------
                                   3808 ;	 function ak820_usb_raw_send
                                   3809 ;	-----------------------------------------
      006A33                       3810 _ak820_usb_raw_send:
      006A33 12 43 15         [24] 3811 	lcall	_ak820_outline_0036
      006A36 90 07 DC         [24] 3812 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006A39 12 38 1F         [24] 3813 	lcall	_ak820_outline_0016
                                   3814 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      006A3C 90 07 DB         [24] 3815 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006A3F E0               [24] 3816 	movx	a,@dptr
      006A40 FF               [12] 3817 	mov	r7,a
      006A41 BF 20 2B         [24] 3818 	cjne	r7,#0x20,00106$
                                   3819 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      006A44 C0 07            [24] 3820 	push	ar7
      006A46 12 3E 2B         [24] 3821 	lcall	_ak820_nvm_flush
      006A49 D0 07            [24] 3822 	pop	ar7
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006A4B 90 07 94         [24] 3824 	mov	dptr,#_raw_reply_without_nvm
      006A4E E0               [24] 3825 	movx	a,@dptr
      006A4F 70 07            [24] 3826 	jnz	00103$
      006A51 12 3E 1C         [24] 3827 	lcall	_ak820_nvm_ok
      006A54 E5 82            [12] 3828 	mov	a, dpl
      006A56 60 17            [24] 3829 	jz	00106$
      006A58                       3830 00103$:
      006A58 90 07 DC         [24] 3831 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      006A5B 12 38 6A         [24] 3832 	lcall	_ak820_outline_0085
      006A5E 90 07 D1         [24] 3833 	mov	dptr,#_ak820_usb_send_PARM_2
      006A61 12 43 78         [24] 3834 	lcall	_ak820_outline_0165
      006A64 90 07 D3         [24] 3835 	mov	dptr,#_ak820_usb_send_PARM_3
      006A67 EF               [12] 3836 	mov	a,r7
      006A68 F0               [24] 3837 	movx	@dptr,a
      006A69 75 82 03         [24] 3838 	mov	dpl, #0x03
                                   3839 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      006A6C 02 67 3D         [24] 3840 	ljmp	_ak820_usb_send
      006A6F                       3841 00106$:
      006A6F 22               [24] 3842 	ret
                                   3843 ;------------------------------------------------------------
                                   3844 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3845 ;------------------------------------------------------------
                                   3846 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3847 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3848 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3849 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3850 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3851 ;------------------------------------------------------------
                                   3852 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3853 ;	-----------------------------------------
                                   3854 ;	 function ak820_usb_raw_task
                                   3855 ;	-----------------------------------------
      006A70                       3856 _ak820_usb_raw_task:
                                   3857 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      006A70 A2 AF            [12] 3858 	mov	c,_EA
      006A72 E4               [12] 3859 	clr	a
      006A73 33               [12] 3860 	rlc	a
      006A74 FF               [12] 3861 	mov	r7,a
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3863 ;	assignBit
      006A75 C2 AF            [12] 3864 	clr	_EA
                                   3865 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006A77 90 07 6C         [24] 3866 	mov	dptr,#_USB_EnumStatus
      006A7A E0               [24] 3867 	movx	a,@dptr
      006A7B 60 0A            [24] 3868 	jz	00101$
      006A7D 90 07 73         [24] 3869 	mov	dptr,#_raw_state
      006A80 E0               [24] 3870 	movx	a,@dptr
      006A81 FE               [12] 3871 	mov	r6,a
      006A82 BE 02 02         [24] 3872 	cjne	r6,#0x02,00270$
      006A85 80 06            [24] 3873 	sjmp	00102$
      006A87                       3874 00270$:
      006A87                       3875 00101$:
                                   3876 ;	assignBit
      006A87 EF               [12] 3877 	mov	a,r7
      006A88 24 FF            [12] 3878 	add	a,#0xff
      006A8A 92 AF            [24] 3879 	mov	_EA,c
      006A8C 22               [24] 3880 	ret
      006A8D                       3881 00102$:
                                   3882 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      006A8D 90 07 73         [24] 3883 	mov	dptr,#_raw_state
      006A90 74 03            [12] 3884 	mov	a,#0x03
      006A92 F0               [24] 3885 	movx	@dptr,a
                                   3886 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3887 ;	assignBit
      006A93 EF               [12] 3888 	mov	a,r7
      006A94 24 FF            [12] 3889 	add	a,#0xff
      006A96 92 AF            [24] 3890 	mov	_EA,c
                                   3891 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006A98 90 07 74         [24] 3892 	mov	dptr,#_raw_buffer
      006A9B E0               [24] 3893 	movx	a,@dptr
      006A9C FF               [12] 3894 	mov	r7,a
      006A9D E4               [12] 3895 	clr	a
      006A9E BF FD 01         [24] 3896 	cjne	r7,#0xfd,00271$
      006AA1 04               [12] 3897 	inc	a
      006AA2                       3898 00271$:
      006AA2 FF               [12] 3899 	mov	r7,a
      006AA3 70 03            [24] 3900 	jnz	00273$
      006AA5 02 6B 45         [24] 3901 	ljmp	00118$
      006AA8                       3902 00273$:
      006AA8 90 07 75         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0001)
      006AAB E0               [24] 3904 	movx	a,@dptr
      006AAC 60 03            [24] 3905 	jz	00274$
      006AAE 02 6B 45         [24] 3906 	ljmp	00118$
      006AB1                       3907 00274$:
                                   3908 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006AB1 90 07 76         [24] 3909 	mov	dptr,#(_raw_buffer + 0x0002)
      006AB4 E0               [24] 3910 	movx	a,@dptr
      006AB5 FD               [12] 3911 	mov	r5,a
      006AB6 7E 00            [12] 3912 	mov	r6,#0x00
      006AB8 90 07 77         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0003)
      006ABB E0               [24] 3914 	movx	a,@dptr
      006ABC 7B 00            [12] 3915 	mov	r3,#0x00
      006ABE 42 06            [12] 3916 	orl	ar6,a
      006AC0 EB               [12] 3917 	mov	a,r3
      006AC1 42 05            [12] 3918 	orl	ar5,a
                                   3919 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006AC3 90 07 78         [24] 3920 	mov	dptr,#(_raw_buffer + 0x0004)
      006AC6 E0               [24] 3921 	movx	a,@dptr
      006AC7 FC               [12] 3922 	mov	r4,a
                                   3923 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006AC8 7B 05            [12] 3924 	mov	r3,#0x05
      006ACA                       3925 00128$:
      006ACA EB               [12] 3926 	mov	a,r3
      006ACB 12 6C 4F         [24] 3927 	lcall	_ak820_outline_0106
      006ACE 0B               [12] 3928 	inc	r3
      006ACF BB 20 00         [24] 3929 	cjne	r3,#0x20,00275$
      006AD2                       3930 00275$:
      006AD2 40 F6            [24] 3931 	jc	00128$
                                   3932 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006AD4 EC               [12] 3933 	mov	a,r4
      006AD5 24 E4            [12] 3934 	add	a,#0xff - 0x1b
      006AD7 40 1C            [24] 3935 	jc	00106$
                                   3936 ;	free result
      006AD9 EC               [12] 3937 	mov	a,r4
      006ADA 60 26            [24] 3938 	jz	00165$
      006ADC 8C 03            [24] 3939 	mov	ar3,r4
      006ADE 1B               [12] 3940 	dec	r3
      006ADF 7A 00            [12] 3941 	mov	r2,#0x00
      006AE1 74 FF            [12] 3942 	mov	a,#0xff
      006AE3 C3               [12] 3943 	clr	c
      006AE4 9B               [12] 3944 	subb	a,r3
      006AE5 FB               [12] 3945 	mov	r3,a
      006AE6 74 FF            [12] 3946 	mov	a,#0xff
      006AE8 9A               [12] 3947 	subb	a,r2
      006AE9 FA               [12] 3948 	mov	r2,a
      006AEA 8E 00            [24] 3949 	mov	ar0,r6
      006AEC 8D 01            [24] 3950 	mov	ar1,r5
      006AEE C3               [12] 3951 	clr	c
      006AEF EB               [12] 3952 	mov	a,r3
      006AF0 98               [12] 3953 	subb	a,r0
      006AF1 EA               [12] 3954 	mov	a,r2
      006AF2 99               [12] 3955 	subb	a,r1
      006AF3 50 0D            [24] 3956 	jnc	00165$
                                   3957 ;	free result
      006AF5                       3958 00106$:
                                   3959 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006AF5 90 07 75         [24] 3960 	mov	dptr,#(_raw_buffer + 0x0001)
      006AF8 74 FF            [12] 3961 	mov	a,#0xff
      006AFA F0               [24] 3962 	movx	@dptr,a
                                   3963 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      006AFB 90 07 78         [24] 3964 	mov	dptr,#(_raw_buffer + 0x0004)
      006AFE E4               [12] 3965 	clr	a
      006AFF F0               [24] 3966 	movx	@dptr,a
                                   3967 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006B00 80 3A            [24] 3968 	sjmp	00108$
      006B02                       3969 00165$:
      006B02 7B 00            [12] 3970 	mov	r3,#0x00
      006B04                       3971 00131$:
      006B04 C3               [12] 3972 	clr	c
      006B05 EB               [12] 3973 	mov	a,r3
      006B06 9C               [12] 3974 	subb	a,r4
      006B07 50 33            [24] 3975 	jnc	00108$
      006B09 C0 04            [24] 3976 	push	ar4
      006B0B 8B 02            [24] 3977 	mov	ar2,r3
      006B0D 74 05            [12] 3978 	mov	a,#0x05
      006B0F 2A               [12] 3979 	add	a, r2
      006B10 F9               [12] 3980 	mov	r1,a
      006B11 33               [12] 3981 	rlc	a
      006B12 95 E0            [12] 3982 	subb	a,acc
      006B14 FA               [12] 3983 	mov	r2,a
      006B15 E9               [12] 3984 	mov	a,r1
      006B16 24 74            [12] 3985 	add	a, #_raw_buffer
      006B18 F9               [12] 3986 	mov	r1,a
      006B19 EA               [12] 3987 	mov	a,r2
      006B1A 34 07            [12] 3988 	addc	a, #(_raw_buffer >> 8)
      006B1C FA               [12] 3989 	mov	r2,a
      006B1D 8B 1E            [24] 3990 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006B1F 75 1F 00         [24] 3991 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006B22 8E 00            [24] 3992 	mov	ar0,r6
      006B24 8D 04            [24] 3993 	mov	ar4,r5
      006B26 E5 1E            [12] 3994 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006B28 28               [12] 3995 	add	a, r0
      006B29 F8               [12] 3996 	mov	r0,a
      006B2A E5 1F            [12] 3997 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006B2C 3C               [12] 3998 	addc	a, r4
      006B2D FC               [12] 3999 	mov	r4,a
      006B2E 88 82            [24] 4000 	mov	dpl,r0
      006B30 8C 83            [24] 4001 	mov	dph,r4
      006B32 E4               [12] 4002 	clr	a
      006B33 93               [24] 4003 	movc	a,@a+dptr
      006B34 12 6C 5B         [24] 4004 	lcall	_ak820_outline_0141
      006B37 0B               [12] 4005 	inc	r3
      006B38 D0 04            [24] 4006 	pop	ar4
      006B3A 80 C8            [24] 4007 	sjmp	00131$
      006B3C                       4008 00108$:
                                   4009 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006B3C 12 6C 3B         [24] 4010 	lcall	_ak820_outline_0045
      006B3F 12 67 3D         [24] 4011 	lcall	_ak820_usb_send
      006B42 02 6B EB         [24] 4012 	ljmp	00119$
      006B45                       4013 00118$:
                                   4014 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006B45 EF               [12] 4015 	mov	a,r7
      006B46 70 03            [24] 4016 	jnz	00281$
      006B48 02 6B C8         [24] 4017 	ljmp	00114$
      006B4B                       4018 00281$:
      006B4B 12 6C 61         [24] 4019 	lcall	_ak820_outline_0167
      006B4E BF 01 02         [24] 4020 	cjne	r7,#0x01,00282$
      006B51 80 03            [24] 4021 	sjmp	00283$
      006B53                       4022 00282$:
      006B53 02 6B C8         [24] 4023 	ljmp	00114$
      006B56                       4024 00283$:
                                   4025 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006B56 7F 02            [12] 4026 	mov	r7,#0x02
      006B58                       4027 00133$:
      006B58 EF               [12] 4028 	mov	a,r7
      006B59 12 6C 4F         [24] 4029 	lcall	_ak820_outline_0106
      006B5C 0F               [12] 4030 	inc	r7
      006B5D BF 20 00         [24] 4031 	cjne	r7,#0x20,00284$
      006B60                       4032 00284$:
      006B60 40 F6            [24] 4033 	jc	00133$
                                   4034 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      006B62 90 07 76         [24] 4035 	mov	dptr,#(_raw_buffer + 0x0002)
      006B65 74 01            [12] 4036 	mov	a,#0x01
      006B67 F0               [24] 4037 	movx	@dptr,a
                                   4038 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      006B68 90 07 77         [24] 4039 	mov	dptr,#(_raw_buffer + 0x0003)
      006B6B 74 A8            [12] 4040 	mov	a,#0xa8
      006B6D F0               [24] 4041 	movx	@dptr,a
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      006B6E 90 07 78         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0004)
      006B71 12 3B 97         [24] 4044 	lcall	_ak820_nvm_diagnostic
                                   4045 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006B74 7F 00            [12] 4046 	mov	r7,#0x00
      006B76                       4047 00135$:
      006B76 8F 06            [24] 4048 	mov	ar6,r7
      006B78 74 0B            [12] 4049 	mov	a,#0x0b
      006B7A 2E               [12] 4050 	add	a, r6
      006B7B 24 74            [12] 4051 	add	a,#_raw_buffer
      006B7D FE               [12] 4052 	mov	r6,a
      006B7E E4               [12] 4053 	clr	a
      006B7F 34 07            [12] 4054 	addc	a, #(_raw_buffer >> 8)
      006B81 FD               [12] 4055 	mov	r5,a
      006B82 EF               [12] 4056 	mov	a,r7
      006B83 24 64            [12] 4057 	add	a, #_ak820_flash_diagnostic
      006B85 F5 82            [12] 4058 	mov	dpl,a
      006B87 E4               [12] 4059 	clr	a
      006B88 34 04            [12] 4060 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006B8A F5 83            [12] 4061 	mov	dph,a
      006B8C E0               [24] 4062 	movx	a,@dptr
      006B8D 8E 82            [24] 4063 	mov	dpl,r6
      006B8F 8D 83            [24] 4064 	mov	dph,r5
      006B91 F0               [24] 4065 	movx	@dptr,a
      006B92 0F               [12] 4066 	inc	r7
      006B93 BF 06 00         [24] 4067 	cjne	r7,#0x06,00286$
      006B96                       4068 00286$:
      006B96 40 DE            [24] 4069 	jc	00135$
                                   4070 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006B98 90 0E 27         [24] 4071 	mov	dptr,#_vial_unlocked
      006B9B E0               [24] 4072 	movx	a,@dptr
      006B9C 90 07 85         [24] 4073 	mov	dptr,#(_raw_buffer + 0x0011)
      006B9F F0               [24] 4074 	movx	@dptr,a
                                   4075 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006BA0 90 0E 28         [24] 4076 	mov	dptr,#_vial_unlock_in_progress
      006BA3 E0               [24] 4077 	movx	a,@dptr
      006BA4 90 07 86         [24] 4078 	mov	dptr,#(_raw_buffer + 0x0012)
      006BA7 F0               [24] 4079 	movx	@dptr,a
                                   4080 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006BA8 90 07 6C         [24] 4081 	mov	dptr,#_USB_EnumStatus
      006BAB E0               [24] 4082 	movx	a,@dptr
      006BAC 90 07 87         [24] 4083 	mov	dptr,#(_raw_buffer + 0x0013)
      006BAF F0               [24] 4084 	movx	@dptr,a
                                   4085 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006BB0 90 07 6D         [24] 4086 	mov	dptr,#_USB_SleepStatus
      006BB3 E0               [24] 4087 	movx	a,@dptr
      006BB4 90 07 88         [24] 4088 	mov	dptr,#(_raw_buffer + 0x0014)
      006BB7 F0               [24] 4089 	movx	@dptr,a
                                   4090 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006BB8 90 07 73         [24] 4091 	mov	dptr,#_raw_state
      006BBB E0               [24] 4092 	movx	a,@dptr
      006BBC 90 07 89         [24] 4093 	mov	dptr,#(_raw_buffer + 0x0015)
      006BBF F0               [24] 4094 	movx	@dptr,a
                                   4095 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006BC0 12 6C 3B         [24] 4096 	lcall	_ak820_outline_0045
      006BC3 12 67 3D         [24] 4097 	lcall	_ak820_usb_send
      006BC6 80 23            [24] 4098 	sjmp	00119$
      006BC8                       4099 00114$:
                                   4100 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006BC8 12 69 58         [24] 4101 	lcall	_raw_request_is_nonpersistent
      006BCB E5 82            [12] 4102 	mov	a, dpl
      006BCD 90 07 94         [24] 4103 	mov	dptr,#_raw_reply_without_nvm
      006BD0 F0               [24] 4104 	movx	@dptr,a
                                   4105 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006BD1 12 3F 7E         [24] 4106 	lcall	_ak820_nvm_begin
                                   4107 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006BD4 90 0C 59         [24] 4108 	mov	dptr,#_raw_hid_receive_PARM_2
      006BD7 74 20            [12] 4109 	mov	a,#0x20
      006BD9 F0               [24] 4110 	movx	@dptr,a
      006BDA 90 07 74         [24] 4111 	mov	dptr,#_raw_buffer
      006BDD 75 F0 00         [24] 4112 	mov	b, #0x00
      006BE0 12 A7 5D         [24] 4113 	lcall	_raw_hid_receive
                                   4114 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006BE3 12 3F 93         [24] 4115 	lcall	_ak820_nvm_end
                                   4116 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006BE6 90 07 94         [24] 4117 	mov	dptr,#_raw_reply_without_nvm
      006BE9 E4               [12] 4118 	clr	a
      006BEA F0               [24] 4119 	movx	@dptr,a
      006BEB                       4120 00119$:
                                   4121 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4122 ;	assignBit
      006BEB A2 AF            [12] 4123 	mov	c,_EA
      006BED 92 1D            [24] 4124 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4126 ;	assignBit
      006BEF C2 AF            [12] 4127 	clr	_EA
                                   4128 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006BF1 12 6C 67         [24] 4129 	lcall	_ak820_outline_0169
      006BF4 BF 04 08         [24] 4130 	cjne	r7,#0x04,00126$
      006BF7 90 07 73         [24] 4131 	mov	dptr,#_raw_state
      006BFA 74 05            [12] 4132 	mov	a,#0x05
      006BFC F0               [24] 4133 	movx	@dptr,a
      006BFD 80 1B            [24] 4134 	sjmp	00127$
      006BFF                       4135 00126$:
                                   4136 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006BFF 12 6C 67         [24] 4137 	lcall	_ak820_outline_0169
      006C02 BF 03 02         [24] 4138 	cjne	r7,#0x03,00290$
      006C05 80 0E            [24] 4139 	sjmp	00121$
      006C07                       4140 00290$:
      006C07 12 6C 67         [24] 4141 	lcall	_ak820_outline_0169
      006C0A BF 06 02         [24] 4142 	cjne	r7,#0x06,00291$
      006C0D 80 06            [24] 4143 	sjmp	00121$
      006C0F                       4144 00291$:
      006C0F 12 6C 67         [24] 4145 	lcall	_ak820_outline_0169
      006C12 BF 07 05         [24] 4146 	cjne	r7,#0x07,00127$
      006C15                       4147 00121$:
      006C15 90 07 73         [24] 4148 	mov	dptr,#_raw_state
      006C18 E4               [12] 4149 	clr	a
      006C19 F0               [24] 4150 	movx	@dptr,a
      006C1A                       4151 00127$:
                                   4152 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4153 ;	assignBit
      006C1A A2 1D            [12] 4154 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006C1C 92 AF            [24] 4155 	mov	_EA,c
                                   4156 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006C1E 22               [24] 4157 	ret
                                   4158 ;------------------------------------------------------------
                                   4159 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4160 ;------------------------------------------------------------
                                   4161 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4162 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4163 ;------------------------------------------------------------
                                   4164 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4165 ;	-----------------------------------------
                                   4166 ;	 function ak820_usb_take_keyboard_reset
                                   4167 ;	-----------------------------------------
      006C1F                       4168 _ak820_usb_take_keyboard_reset:
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4170 ;	assignBit
      006C1F A2 AF            [12] 4171 	mov	c,_EA
      006C21 92 1E            [24] 4172 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4174 ;	assignBit
      006C23 C2 AF            [12] 4175 	clr	_EA
                                   4176 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006C25 90 07 95         [24] 4177 	mov	dptr,#_keyboard_reset
      006C28 E0               [24] 4178 	movx	a,@dptr
      006C29 FF               [12] 4179 	mov	r7,a
                                   4180 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006C2A E4               [12] 4181 	clr	a
      006C2B F0               [24] 4182 	movx	@dptr,a
                                   4183 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4184 ;	assignBit
      006C2C A2 1E            [12] 4185 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006C2E 92 AF            [24] 4186 	mov	_EA,c
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006C30 EF               [12] 4188 	mov	a,r7
      006C31 B4 01 00         [24] 4189 	cjne	a,#0x01,00103$
      006C34                       4190 00103$:
      006C34 B3               [12] 4191 	cpl	c
      006C35 92 1E            [24] 4192 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006C37 12 38 B1         [24] 4193 	lcall	_ak820_outline_0159
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006C3A 22               [24] 4195 	ret
                                   4196 	.area CSEG    (CODE)
                                   4197 	.area CONST   (CODE)
                                   4198 	.area CONST   (CODE)
      00BA2B                       4199 _shared_offsets:
      00BA2B 00                    4200 	.db #0x00	; 0
      00BA2C 00                    4201 	.db #0x00	; 0
      00BA2D 28                    4202 	.db #0x28	; 40
      00BA2E 28                    4203 	.db #0x28	; 40
      00BA2F 2B                    4204 	.db #0x2b	; 43
      00BA30 00                    4205 	.db #0x00	; 0
      00BA31 08                    4206 	.db #0x08	; 8
                                   4207 	.area CSEG    (CODE)
                                   4208 	.area CONST   (CODE)
      00BA32                       4209 _shared_lengths:
      00BA32 00                    4210 	.db #0x00	; 0
      00BA33 00                    4211 	.db #0x00	; 0
      00BA34 00                    4212 	.db #0x00	; 0
      00BA35 03                    4213 	.db #0x03	; 3
      00BA36 03                    4214 	.db #0x03	; 3
      00BA37 00                    4215 	.db #0x00	; 0
      00BA38 20                    4216 	.db #0x20	; 32
                                   4217 	.area CSEG    (CODE)
                                   4218 	.area CONST   (CODE)
      00BA39                       4219 _interface_descriptors:
      00BA39 D4 BF                 4220 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BA3B D4 C0                 4221 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BA3D 87 C0                 4222 	.byte _RawReport, (_RawReport >> 8)
      00BA3F ED C0                 4223 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BA41 19 C0                 4224 	.byte _SharedReport, (_SharedReport >> 8)
      00BA43 06 C1                 4225 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4226 	.area CSEG    (CODE)
                                   4227 	.area XINIT   (CODE)
                                   4228 	.area CABS    (ABS,CODE)
                                   4229 
                                   4230 ; Experimental exact instruction outlining.
                                   4231 	.globl _ak820_outline_0016
                                   4232 	.globl _ak820_outline_0036
                                   4233 	.globl _ak820_outline_0045
                                   4234 	.globl _ak820_outline_0085
                                   4235 	.globl _ak820_outline_0106
                                   4236 	.globl _ak820_outline_0141
                                   4237 	.globl _ak820_outline_0159
                                   4238 	.globl _ak820_outline_0165
                                   4239 	.globl _ak820_outline_0167
                                   4240 	.globl _ak820_outline_0169
                                   4241 
                                   4242 	.area CSEG (CODE)
                                   4243 ; function ak820_outline_0045
      006C3B                       4244 _ak820_outline_0045:
      006C3B 90 07 D1         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_2
      006C3E 74 74            [12] 4246 	mov	a,#_raw_buffer
      006C40 F0               [24] 4247 	movx	@dptr,a
      006C41 74 07            [12] 4248 	mov	a,#(_raw_buffer>>8)
      006C43 A3               [24] 4249 	inc	dptr
      006C44 F0               [24] 4250 	movx	@dptr,a
      006C45 90 07 D3         [24] 4251 	mov	dptr,#_ak820_usb_send_PARM_3
      006C48 74 20            [12] 4252 	mov	a,#0x20
      006C4A F0               [24] 4253 	movx	@dptr,a
      006C4B 75 82 03         [24] 4254 	mov	dpl,#0x03
      006C4E 22               [24] 4255 	ret
                                   4256 
                                   4257 	.area CSEG (CODE)
                                   4258 ; function ak820_outline_0106
      006C4F                       4259 _ak820_outline_0106:
      006C4F 24 74            [12] 4260 	add	a,#_raw_buffer
      006C51 F5 82            [12] 4261 	mov	dpl,a
      006C53 E4               [12] 4262 	clr	a
      006C54 34 07            [12] 4263 	addc	a,#(_raw_buffer>>8)
      006C56 F5 83            [12] 4264 	mov	dph,a
      006C58 E4               [12] 4265 	clr	a
      006C59 F0               [24] 4266 	movx	@dptr,a
      006C5A 22               [24] 4267 	ret
                                   4268 
                                   4269 	.area CSEG (CODE)
                                   4270 ; function ak820_outline_0141
      006C5B                       4271 _ak820_outline_0141:
      006C5B 89 82            [24] 4272 	mov	dpl,r1
      006C5D 8A 83            [24] 4273 	mov	dph,r2
      006C5F F0               [24] 4274 	movx	@dptr,a
      006C60 22               [24] 4275 	ret
                                   4276 
                                   4277 	.area CSEG (CODE)
                                   4278 ; function ak820_outline_0167
      006C61                       4279 _ak820_outline_0167:
      006C61 90 07 75         [24] 4280 	mov	dptr,#(_raw_buffer+0x0001)
      006C64 E0               [24] 4281 	movx	a,@dptr
      006C65 FF               [12] 4282 	mov	r7,a
      006C66 22               [24] 4283 	ret
                                   4284 
                                   4285 	.area CSEG (CODE)
                                   4286 ; function ak820_outline_0169
      006C67                       4287 _ak820_outline_0169:
      006C67 90 07 73         [24] 4288 	mov	dptr,#_raw_state
      006C6A E0               [24] 4289 	movx	a,@dptr
      006C6B FF               [12] 4290 	mov	r7,a
      006C6C 22               [24] 4291 	ret
