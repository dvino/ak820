ak820_tapping.o: keyboards/ajazz/ak820/ak820_tapping.c \
 keyboards/ajazz/ak820/config.h \
 .build/final-full-gui-lock/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h quantum/quantum.h \
 platforms/mcs51/platform_deps.h platforms/wait.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/inttypes.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 platforms/mcs51/_wait.h lib/ch555/hal.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdio.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdarg.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/sdcc-lib.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/asm/mcs51/features.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h \
 lib/ch555/ch555.h quantum/matrix.h platforms/sdcc_dummy_macros.h \
 tmk_core/protocol/ch555/usb_device.h lib/ch555/ch555.h \
 tmk_core/protocol/ch555/usb.h tmk_core/protocol/usb_descriptor.h \
 tmk_core/protocol/ch555/lufa_utils/LUFA/Drivers/USB/USB.h \
 platforms/progmem.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h \
 lib/lufa/LUFA/Common/Architectures.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/StdDescriptors.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/USBMode.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/Events.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDParser.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDReportData.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/CDCClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/MIDIClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBController.h \
 lib/lufa/LUFA/Drivers/USB/Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBMode.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 platforms/gpio.h platforms/pin_defs.h platforms/mcs51/_pin_defs.h \
 platforms/mcs51/gpio.h quantum/keyboard.h platforms/timer.h \
 platforms/mcs51/_timer.h platforms/mcs51/atomic_util.h \
 quantum/rgb_matrix/rgb_matrix.h quantum/rgb_matrix/rgb_matrix_types.h \
 quantum/color.h quantum/rgb_matrix/animations/rgb_matrix_effects.inc \
 quantum/rgb_matrix/animations/solid_color_anim.h \
 quantum/rgb_matrix/animations/alpha_mods_anim.h \
 quantum/rgb_matrix/animations/gradient_up_down_anim.h \
 quantum/rgb_matrix/animations/gradient_left_right_anim.h \
 quantum/rgb_matrix/animations/breathing_anim.h \
 quantum/rgb_matrix/animations/colorband_sat_anim.h \
 quantum/rgb_matrix/animations/colorband_val_anim.h \
 quantum/rgb_matrix/animations/colorband_pinwheel_sat_anim.h \
 quantum/rgb_matrix/animations/colorband_pinwheel_val_anim.h \
 quantum/rgb_matrix/animations/colorband_spiral_sat_anim.h \
 quantum/rgb_matrix/animations/colorband_spiral_val_anim.h \
 quantum/rgb_matrix/animations/cycle_all_anim.h \
 quantum/rgb_matrix/animations/cycle_left_right_anim.h \
 quantum/rgb_matrix/animations/cycle_up_down_anim.h \
 quantum/rgb_matrix/animations/rainbow_moving_chevron_anim.h \
 quantum/rgb_matrix/animations/cycle_out_in_anim.h \
 quantum/rgb_matrix/animations/cycle_out_in_dual_anim.h \
 quantum/rgb_matrix/animations/cycle_pinwheel_anim.h \
 quantum/rgb_matrix/animations/cycle_spiral_anim.h \
 quantum/rgb_matrix/animations/dual_beacon_anim.h \
 quantum/rgb_matrix/animations/rainbow_beacon_anim.h \
 quantum/rgb_matrix/animations/rainbow_pinwheels_anim.h \
 quantum/rgb_matrix/animations/raindrops_anim.h \
 quantum/rgb_matrix/animations/jellybean_raindrops_anim.h \
 quantum/rgb_matrix/animations/hue_breathing_anim.h \
 quantum/rgb_matrix/animations/hue_pendulum_anim.h \
 quantum/rgb_matrix/animations/hue_wave_anim.h \
 quantum/rgb_matrix/animations/pixel_rain_anim.h \
 quantum/rgb_matrix/animations/pixel_flow_anim.h \
 quantum/rgb_matrix/animations/pixel_fractal_anim.h \
 quantum/rgb_matrix/animations/typing_heatmap_anim.h \
 quantum/rgb_matrix/animations/digital_rain_anim.h \
 quantum/rgb_matrix/animations/solid_reactive_simple_anim.h \
 quantum/rgb_matrix/animations/solid_reactive_anim.h \
 quantum/rgb_matrix/animations/solid_reactive_wide.h \
 quantum/rgb_matrix/animations/solid_reactive_cross.h \
 quantum/rgb_matrix/animations/solid_reactive_nexus.h \
 quantum/rgb_matrix/animations/splash_anim.h \
 quantum/rgb_matrix/animations/solid_splash_anim.h \
 quantum/rgb_matrix/animations/vialrgb_direct_anim.h \
 quantum/keymap_common.h quantum/quantum_keycodes.h quantum/keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 quantum/quantum_keycodes_legacy.h quantum/keycode_config.h \
 quantum/eeconfig.h quantum/keycode.h quantum/modifiers.h \
 quantum/action_code.h quantum/action_layer.h quantum/action.h \
 quantum/bitwise.h platforms/bootloader.h quantum/bootmagic/bootmagic.h \
 quantum/bootmagic/bootmagic_lite.h quantum/sync_timer.h \
 platforms/atomic_util.h tmk_core/protocol/host.h \
 tmk_core/protocol/report.h tmk_core/protocol/host_driver.h quantum/led.h \
 quantum/action_util.h quantum/action_tapping.h quantum/logging/print.h \
 quantum/util.h quantum/logging/sendchar.h quantum/logging/debug.h \
 platforms/suspend.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdlib.h \
 quantum/send_string/send_string.h \
 quantum/send_string/send_string_keycodes.h quantum/dynamic_keymap.h \
 quantum/vial.h platforms/eeprom.h quantum/via.h quantum/encoder.h \
 quantum/caps_word.h quantum/process_keycode/process_caps_word.h \
 quantum/tri_layer.h quantum/repeat_key.h \
 quantum/process_keycode/process_repeat_key.h \
 keyboards/ajazz/ak820/ak820_tapping.h
