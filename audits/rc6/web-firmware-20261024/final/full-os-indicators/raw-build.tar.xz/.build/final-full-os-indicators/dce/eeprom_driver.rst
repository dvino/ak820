                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000687                         85 _eeprom_read_word_addr_10000_91:
      000687                         86 	.ds 3
      00068A                         87 _eeprom_read_word_ret_10000_92:
      00068A                         88 	.ds 2
      00068C                         89 _eeprom_read_dword_addr_10000_93:
      00068C                         90 	.ds 3
      00068F                         91 _eeprom_read_dword_ret_10000_94:
      00068F                         92 	.ds 4
      000693                         93 _eeprom_write_byte_PARM_2:
      000693                         94 	.ds 1
      000694                         95 _eeprom_write_byte_addr_10000_95:
      000694                         96 	.ds 3
      000697                         97 _eeprom_write_word_PARM_2:
      000697                         98 	.ds 2
      000699                         99 _eeprom_write_word_addr_10000_97:
      000699                        100 	.ds 3
      00069C                        101 _eeprom_write_dword_PARM_2:
      00069C                        102 	.ds 4
      0006A0                        103 _eeprom_write_dword_addr_10000_99:
      0006A0                        104 	.ds 3
      0006A3                        105 _eeprom_update_byte_PARM_2:
      0006A3                        106 	.ds 1
      0006A4                        107 _eeprom_update_byte_addr_10000_107:
      0006A4                        108 	.ds 3
      0006A7                        109 _eeprom_update_word_PARM_2:
      0006A7                        110 	.ds 2
      0006A9                        111 _eeprom_update_word_addr_10000_111:
      0006A9                        112 	.ds 3
      0006AC                        113 _eeprom_update_dword_PARM_2:
      0006AC                        114 	.ds 4
      0006B0                        115 _eeprom_update_dword_addr_10000_115:
      0006B0                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004E5F                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004E5F 12 43 7C         [24]  170 	lcall	_ak820_outline_0038
      004E62 90 06 87         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E65 12 38 29         [24]  172 	lcall	_ak820_outline_0018
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004E68 90 06 8A         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E6B 12 50 6A         [24]  175 	lcall	_ak820_outline_0182
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004E6E 90 06 87         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004E71 12 50 17         [24]  178 	lcall	_ak820_outline_0013
      004E74 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004E77 ED               [12]  180 	mov	a,r5
      004E78 12 38 29         [24]  181 	lcall	_ak820_outline_0018
      004E7B 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004E7E 12 50 5C         [24]  183 	lcall	_ak820_outline_0110
      004E81 90 06 8A         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E84 12 41 18         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004E87 90 06 8A         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004E8A 12 50 53         [24]  188 	lcall	_ak820_outline_0093
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004E8D 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004E8E                        201 _eeprom_read_dword:
      004E8E 12 43 7C         [24]  202 	lcall	_ak820_outline_0038
      004E91 90 06 8C         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004E94 12 38 29         [24]  204 	lcall	_ak820_outline_0018
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004E97 90 06 8F         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E9A 12 50 28         [24]  207 	lcall	_ak820_outline_0051
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004E9D 90 06 8C         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004EA0 12 50 17         [24]  210 	lcall	_ak820_outline_0013
      004EA3 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004EA6 ED               [12]  212 	mov	a,r5
      004EA7 12 38 29         [24]  213 	lcall	_ak820_outline_0018
      004EAA 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004EAD 74 04            [12]  215 	mov	a,#0x04
      004EAF 12 38 9C         [24]  216 	lcall	_ak820_outline_0134
      004EB2 90 06 8F         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004EB5 12 41 18         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004EB8 90 06 8F         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004EBB 12 50 31         [24]  221 	lcall	_ak820_outline_0055
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004EBE 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004EBF                        234 _eeprom_write_byte:
      004EBF 12 43 7C         [24]  235 	lcall	_ak820_outline_0038
      004EC2 90 06 94         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004EC5 12 38 29         [24]  237 	lcall	_ak820_outline_0018
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004EC8 90 06 94         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004ECB 12 50 00         [24]  240 	lcall	_ak820_outline_0004
      004ECE 74 01            [12]  241 	mov	a,#0x01
      004ED0 12 38 9C         [24]  242 	lcall	_ak820_outline_0134
      004ED3 90 06 93         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004ED6 02 41 A4         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004ED9                        256 _eeprom_write_word:
      004ED9 12 43 7C         [24]  257 	lcall	_ak820_outline_0038
      004EDC 90 06 99         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EDF 12 38 29         [24]  259 	lcall	_ak820_outline_0018
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004EE2 90 06 99         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004EE5 12 50 00         [24]  262 	lcall	_ak820_outline_0004
      004EE8 12 50 5C         [24]  263 	lcall	_ak820_outline_0110
      004EEB 90 06 97         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004EEE 02 41 A4         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004EF1                        277 _eeprom_write_dword:
      004EF1 12 43 7C         [24]  278 	lcall	_ak820_outline_0038
      004EF4 90 06 A0         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EF7 12 38 29         [24]  280 	lcall	_ak820_outline_0018
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004EFA 90 06 A0         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004EFD 12 50 00         [24]  283 	lcall	_ak820_outline_0004
      004F00 74 04            [12]  284 	mov	a,#0x04
      004F02 12 38 9C         [24]  285 	lcall	_ak820_outline_0134
      004F05 90 06 9C         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004F08 02 41 A4         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004F0B                        307 _eeprom_update_byte:
      004F0B C0 07            [24]  308 	push	ar7
      004F0D C0 06            [24]  309 	push	ar6
      004F0F C0 05            [24]  310 	push	ar5
      004F11 C0 04            [24]  311 	push	ar4
      004F13 12 43 7C         [24]  312 	lcall	_ak820_outline_0038
      004F16 90 06 A4         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F19 12 38 29         [24]  314 	lcall	_ak820_outline_0018
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004F1C 90 06 A4         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F1F 12 4F F1         [24]  317 	lcall	_ak820_outline_0001
      004F22 12 40 DD         [24]  318 	lcall	_eeprom_read_byte
      004F25 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004F27 90 06 A3         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004F2A E0               [24]  322 	movx	a,@dptr
      004F2B FE               [12]  323 	mov	r6,a
      004F2C EF               [12]  324 	mov	a,r7
      004F2D B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004F30 80 35            [24]  326 	sjmp	00103$
      004F32                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004F32 90 06 A4         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004F35 12 38 58         [24]  330 	lcall	_ak820_outline_0060
      004F38 A3               [24]  331 	inc	dptr
      004F39 E0               [24]  332 	movx	a,@dptr
      004F3A FF               [12]  333 	mov	r7,a
      004F3B 90 06 93         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004F3E EE               [12]  335 	mov	a,r6
      004F3F 12 38 76         [24]  336 	lcall	_ak820_outline_0102
      004F42 8F F0            [24]  337 	mov	b, r7
      004F44 C0 07            [24]  338 	push	ar7
      004F46 C0 06            [24]  339 	push	ar6
      004F48 C0 05            [24]  340 	push	ar5
      004F4A C0 04            [24]  341 	push	ar4
      004F4C C0 03            [24]  342 	push	ar3
      004F4E C0 02            [24]  343 	push	ar2
      004F50 C0 01            [24]  344 	push	ar1
      004F52 C0 00            [24]  345 	push	ar0
      004F54 12 4E BF         [24]  346 	lcall	_eeprom_write_byte
      004F57 D0 00            [24]  347 	pop	ar0
      004F59 D0 01            [24]  348 	pop	ar1
      004F5B D0 02            [24]  349 	pop	ar2
      004F5D D0 03            [24]  350 	pop	ar3
      004F5F D0 04            [24]  351 	pop	ar4
      004F61 D0 05            [24]  352 	pop	ar5
      004F63 D0 06            [24]  353 	pop	ar6
      004F65 D0 07            [24]  354 	pop	ar7
      004F67                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004F67 D0 04            [24]  357 	pop	ar4
      004F69 D0 05            [24]  358 	pop	ar5
      004F6B D0 06            [24]  359 	pop	ar6
      004F6D D0 07            [24]  360 	pop	ar7
      004F6F 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004F70                        373 _eeprom_update_word:
      004F70 12 43 7C         [24]  374 	lcall	_ak820_outline_0038
      004F73 90 06 A9         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F76 12 38 29         [24]  376 	lcall	_ak820_outline_0018
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004F79 90 06 A9         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F7C 12 4F F1         [24]  379 	lcall	_ak820_outline_0001
      004F7F 12 4E 5F         [24]  380 	lcall	_eeprom_read_word
      004F82 12 43 C5         [24]  381 	lcall	_ak820_outline_0133
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004F85 90 06 A7         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004F88 12 38 58         [24]  384 	lcall	_ak820_outline_0060
      004F8B EE               [12]  385 	mov	a,r6
      004F8C B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004F8F EF               [12]  387 	mov	a,r7
      004F90 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004F93 22               [24]  389 	ret
      004F94                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004F94 90 06 A9         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004F97 E0               [24]  393 	movx	a,@dptr
      004F98 FB               [12]  394 	mov	r3,a
      004F99 A3               [24]  395 	inc	dptr
      004F9A 12 38 41         [24]  396 	lcall	_ak820_outline_0052
      004F9D 90 06 97         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004FA0 12 38 5E         [24]  398 	lcall	_ak820_outline_0073
      004FA3 8B 82            [24]  399 	mov	dpl, r3
      004FA5 8E 83            [24]  400 	mov	dph, r6
      004FA7 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004FA9 02 4E D9         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004FAC                        415 _eeprom_update_dword:
      004FAC 12 43 7C         [24]  416 	lcall	_ak820_outline_0038
      004FAF 90 06 B0         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FB2 12 38 29         [24]  418 	lcall	_ak820_outline_0018
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004FB5 90 06 B0         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FB8 12 4F F1         [24]  421 	lcall	_ak820_outline_0001
      004FBB 12 4E 8E         [24]  422 	lcall	_eeprom_read_dword
      004FBE 12 50 42         [24]  423 	lcall	_ak820_outline_0057
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004FC1 90 06 AC         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004FC4 E0               [24]  426 	movx	a,@dptr
      004FC5 F8               [12]  427 	mov	r0,a
      004FC6 A3               [24]  428 	inc	dptr
      004FC7 12 50 4A         [24]  429 	lcall	_ak820_outline_0092
      004FCA EC               [12]  430 	mov	a,r4
      004FCB B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004FCE ED               [12]  432 	mov	a,r5
      004FCF B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004FD2 EE               [12]  434 	mov	a,r6
      004FD3 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004FD6 EF               [12]  436 	mov	a,r7
      004FD7 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004FDA 22               [24]  438 	ret
      004FDB                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004FDB 90 06 B0         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004FDE 12 50 17         [24]  442 	lcall	_ak820_outline_0013
      004FE1 90 06 9C         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004FE4 E8               [12]  444 	mov	a,r0
      004FE5 F0               [24]  445 	movx	@dptr,a
      004FE6 E9               [12]  446 	mov	a,r1
      004FE7 A3               [24]  447 	inc	dptr
      004FE8 12 50 63         [24]  448 	lcall	_ak820_outline_0155
      004FEB 12 50 20         [24]  449 	lcall	_ak820_outline_0035
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004FEE 02 4E F1         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0013
                                    461 	.globl _ak820_outline_0018
                                    462 	.globl _ak820_outline_0035
                                    463 	.globl _ak820_outline_0038
                                    464 	.globl _ak820_outline_0051
                                    465 	.globl _ak820_outline_0052
                                    466 	.globl _ak820_outline_0055
                                    467 	.globl _ak820_outline_0057
                                    468 	.globl _ak820_outline_0060
                                    469 	.globl _ak820_outline_0073
                                    470 	.globl _ak820_outline_0092
                                    471 	.globl _ak820_outline_0093
                                    472 	.globl _ak820_outline_0102
                                    473 	.globl _ak820_outline_0110
                                    474 	.globl _ak820_outline_0133
                                    475 	.globl _ak820_outline_0134
                                    476 	.globl _ak820_outline_0155
                                    477 	.globl _ak820_outline_0182
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004FF1                        481 _ak820_outline_0001:
      004FF1 E0               [24]  482 	movx	a,@dptr
      004FF2 FD               [12]  483 	mov	r5,a
      004FF3 A3               [24]  484 	inc	dptr
      004FF4 E0               [24]  485 	movx	a,@dptr
      004FF5 FE               [12]  486 	mov	r6,a
      004FF6 A3               [24]  487 	inc	dptr
      004FF7 E0               [24]  488 	movx	a,@dptr
      004FF8 FF               [12]  489 	mov	r7,a
      004FF9 8D 82            [24]  490 	mov	dpl,r5
      004FFB 8E 83            [24]  491 	mov	dph,r6
      004FFD 8F F0            [24]  492 	mov	b,r7
      004FFF 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      005000                        497 _ak820_outline_0004:
      005000 E0               [24]  498 	movx	a,@dptr
      005001 FD               [12]  499 	mov	r5,a
      005002 A3               [24]  500 	inc	dptr
      005003 E0               [24]  501 	movx	a,@dptr
      005004 FE               [12]  502 	mov	r6,a
      005005 A3               [24]  503 	inc	dptr
      005006 E0               [24]  504 	movx	a,@dptr
      005007 FF               [12]  505 	mov	r7,a
      005008 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00500B ED               [12]  507 	mov	a,r5
      00500C F0               [24]  508 	movx	@dptr,a
      00500D EE               [12]  509 	mov	a,r6
      00500E A3               [24]  510 	inc	dptr
      00500F F0               [24]  511 	movx	@dptr,a
      005010 EF               [12]  512 	mov	a,r7
      005011 A3               [24]  513 	inc	dptr
      005012 F0               [24]  514 	movx	@dptr,a
      005013 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005016 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0013
      005017                        520 _ak820_outline_0013:
      005017 E0               [24]  521 	movx	a,@dptr
      005018 FD               [12]  522 	mov	r5,a
      005019 A3               [24]  523 	inc	dptr
      00501A E0               [24]  524 	movx	a,@dptr
      00501B FE               [12]  525 	mov	r6,a
      00501C A3               [24]  526 	inc	dptr
      00501D E0               [24]  527 	movx	a,@dptr
      00501E FF               [12]  528 	mov	r7,a
      00501F 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0035
      005020                        533 _ak820_outline_0035:
      005020 F0               [24]  534 	movx	@dptr,a
      005021 8D 82            [24]  535 	mov	dpl,r5
      005023 8E 83            [24]  536 	mov	dph,r6
      005025 8F F0            [24]  537 	mov	b,r7
      005027 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0051
      005028                        542 _ak820_outline_0051:
      005028 E4               [12]  543 	clr	a
      005029 F0               [24]  544 	movx	@dptr,a
      00502A A3               [24]  545 	inc	dptr
      00502B F0               [24]  546 	movx	@dptr,a
      00502C A3               [24]  547 	inc	dptr
      00502D F0               [24]  548 	movx	@dptr,a
      00502E A3               [24]  549 	inc	dptr
      00502F F0               [24]  550 	movx	@dptr,a
      005030 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0055
      005031                        555 _ak820_outline_0055:
      005031 E0               [24]  556 	movx	a,@dptr
      005032 FC               [12]  557 	mov	r4,a
      005033 A3               [24]  558 	inc	dptr
      005034 E0               [24]  559 	movx	a,@dptr
      005035 FD               [12]  560 	mov	r5,a
      005036 A3               [24]  561 	inc	dptr
      005037 E0               [24]  562 	movx	a,@dptr
      005038 FE               [12]  563 	mov	r6,a
      005039 A3               [24]  564 	inc	dptr
      00503A E0               [24]  565 	movx	a,@dptr
      00503B 8C 82            [24]  566 	mov	dpl,r4
      00503D 8D 83            [24]  567 	mov	dph,r5
      00503F 8E F0            [24]  568 	mov	b,r6
      005041 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0057
      005042                        573 _ak820_outline_0057:
      005042 AC 82            [24]  574 	mov	r4,dpl
      005044 AD 83            [24]  575 	mov	r5,dph
      005046 AE F0            [24]  576 	mov	r6,b
      005048 FF               [12]  577 	mov	r7,a
      005049 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0092
      00504A                        582 _ak820_outline_0092:
      00504A E0               [24]  583 	movx	a,@dptr
      00504B F9               [12]  584 	mov	r1,a
      00504C A3               [24]  585 	inc	dptr
      00504D E0               [24]  586 	movx	a,@dptr
      00504E FA               [12]  587 	mov	r2,a
      00504F A3               [24]  588 	inc	dptr
      005050 E0               [24]  589 	movx	a,@dptr
      005051 FB               [12]  590 	mov	r3,a
      005052 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0093
      005053                        595 _ak820_outline_0093:
      005053 E0               [24]  596 	movx	a,@dptr
      005054 FE               [12]  597 	mov	r6,a
      005055 A3               [24]  598 	inc	dptr
      005056 E0               [24]  599 	movx	a,@dptr
      005057 8E 82            [24]  600 	mov	dpl,r6
      005059 F5 83            [12]  601 	mov	dph,a
      00505B 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0110
      00505C                        606 _ak820_outline_0110:
      00505C 74 02            [12]  607 	mov	a,#0x02
      00505E F0               [24]  608 	movx	@dptr,a
      00505F E4               [12]  609 	clr	a
      005060 A3               [24]  610 	inc	dptr
      005061 F0               [24]  611 	movx	@dptr,a
      005062 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0155
      005063                        616 _ak820_outline_0155:
      005063 F0               [24]  617 	movx	@dptr,a
      005064 EA               [12]  618 	mov	a,r2
      005065 A3               [24]  619 	inc	dptr
      005066 F0               [24]  620 	movx	@dptr,a
      005067 EB               [12]  621 	mov	a,r3
      005068 A3               [24]  622 	inc	dptr
      005069 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0182
      00506A                        627 _ak820_outline_0182:
      00506A E4               [12]  628 	clr	a
      00506B F0               [24]  629 	movx	@dptr,a
      00506C A3               [24]  630 	inc	dptr
      00506D F0               [24]  631 	movx	@dptr,a
      00506E 22               [24]  632 	ret
