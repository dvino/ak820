                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BED                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BED E5 82            [12]  215 	mov	a,dpl
      003BEF 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BF2 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BF3 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003BF6 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BF9 E0               [24]  221 	movx	a,@dptr
      003BFA 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003BFD F0               [24]  223 	movx	@dptr,a
      003BFE                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003BFE D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003C00 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003C01                        239 _ak820_nvm_diagnostic:
      003C01 12 38 82         [24]  240 	lcall	_ak820_outline_0107
      003C04 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C07 12 38 87         [24]  242 	lcall	_ak820_outline_0108
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003C0A 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C0D 12 38 41         [24]  245 	lcall	_ak820_outline_0052
      003C10 A2 0B            [12]  246 	mov	c,_storage_failed
      003C12 E4               [12]  247 	clr	a
      003C13 33               [12]  248 	rlc	a
      003C14 12 38 8C         [24]  249 	lcall	_ak820_outline_0118
      003C17 12 43 A7         [24]  250 	lcall	_ak820_outline_0072
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003C1A A3               [24]  252 	inc	dptr
      003C1B A2 09            [12]  253 	mov	c,_page_valid
      003C1D E4               [12]  254 	clr	a
      003C1E 33               [12]  255 	rlc	a
      003C1F 12 43 74         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003C22 A2 0A            [12]  258 	mov	c,_page_dirty
      003C24 E4               [12]  259 	clr	a
      003C25 33               [12]  260 	rlc	a
      003C26 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003C27 74 03            [12]  263 	mov	a,#0x03
      003C29 12 43 E0         [24]  264 	lcall	_ak820_outline_0161
      003C2C 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003C2F E0               [24]  266 	movx	a,@dptr
      003C30 12 38 97         [24]  267 	lcall	_ak820_outline_0124
      003C33 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003C34 74 04            [12]  270 	mov	a,#0x04
      003C36 12 43 E0         [24]  271 	lcall	_ak820_outline_0161
      003C39 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003C3C E0               [24]  273 	movx	a,@dptr
      003C3D 12 38 97         [24]  274 	lcall	_ak820_outline_0124
      003C40 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C41 12 43 6A         [24]  277 	lcall	_ak820_outline_0012
      003C44 E4               [12]  278 	clr	a
      003C45 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C46 74 06            [12]  281 	mov	a,#0x06
      003C48 12 43 CA         [24]  282 	lcall	_ak820_outline_0137
      003C4B 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003C4E E0               [24]  284 	movx	a,@dptr
      003C4F 12 38 8C         [24]  285 	lcall	_ak820_outline_0118
      003C52 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C53 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C54                        300 _crc_byte:
      003C54 12 38 82         [24]  301 	lcall	_ak820_outline_0107
      003C57 90 05 64         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C5A 12 38 87         [24]  303 	lcall	_ak820_outline_0108
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C5D 90 05 63         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C60 E0               [24]  306 	movx	a,@dptr
      003C61 FF               [12]  307 	mov	r7,a
      003C62 7E 00            [12]  308 	mov	r6,#0x00
      003C64 90 05 64         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C67 E0               [24]  310 	movx	a,@dptr
      003C68 6E               [12]  311 	xrl	a,r6
      003C69 F0               [24]  312 	movx	@dptr,a
      003C6A A3               [24]  313 	inc	dptr
      003C6B E0               [24]  314 	movx	a,@dptr
      003C6C 6F               [12]  315 	xrl	a,r7
      003C6D F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C6E 7F 00            [12]  318 	mov	r7,#0x00
      003C70                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C70 90 05 64         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C73 12 38 64         [24]  322 	lcall	_ak820_outline_0080
      003C76 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C79 ED               [12]  324 	mov	a,r5
      003C7A 2D               [12]  325 	add	a,r5
      003C7B FB               [12]  326 	mov	r3,a
      003C7C EE               [12]  327 	mov	a,r6
      003C7D 33               [12]  328 	rlc	a
      003C7E FC               [12]  329 	mov	r4,a
      003C7F 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C82 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C85 80 06            [24]  332 	sjmp	00107$
      003C87                        333 00106$:
      003C87 ED               [12]  334 	mov	a,r5
      003C88 2D               [12]  335 	add	a,r5
      003C89 FB               [12]  336 	mov	r3,a
      003C8A EE               [12]  337 	mov	a,r6
      003C8B 33               [12]  338 	rlc	a
      003C8C FC               [12]  339 	mov	r4,a
      003C8D                        340 00107$:
      003C8D 90 05 64         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C90 12 38 6A         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C93 0F               [12]  344 	inc	r7
      003C94 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C97 12 33 FC         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C9A 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C9B                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C9B 90 05 66         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C9E 74 FF            [12]  363 	mov	a,#0xff
      003CA0 F0               [24]  364 	movx	@dptr,a
      003CA1 A3               [24]  365 	inc	dptr
      003CA2 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003CA3 7F 00            [12]  368 	mov	r7,#0x00
      003CA5                        369 00102$:
      003CA5 90 05 66         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003CA8 12 38 64         [24]  371 	lcall	_ak820_outline_0080
      003CAB 12 43 B9         [24]  372 	lcall	_ak820_outline_0105
      003CAE 90 05 63         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003CB1 F0               [24]  374 	movx	@dptr,a
      003CB2 12 38 A1         [24]  375 	lcall	_ak820_outline_0135
      003CB5 C0 07            [24]  376 	push	ar7
      003CB7 12 3C 54         [24]  377 	lcall	_crc_byte
      003CBA AD 82            [24]  378 	mov	r5, dpl
      003CBC AE 83            [24]  379 	mov	r6, dph
      003CBE D0 07            [24]  380 	pop	ar7
      003CC0 90 05 66         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003CC3 12 43 E6         [24]  382 	lcall	_ak820_outline_0162
      003CC6 0F               [12]  383 	inc	r7
      003CC7 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003CCA 12 38 A1         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003CCD 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003CCE                        399 _write_page:
      003CCE 12 38 82         [24]  400 	lcall	_ak820_outline_0107
      003CD1 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003CD4 12 38 87         [24]  402 	lcall	_ak820_outline_0108
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003CD7 90 05 68         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003CDA 12 37 F4         [24]  405 	lcall	_ak820_outline_0005
      003CDD C0 07            [24]  406 	push	ar7
      003CDF C0 06            [24]  407 	push	ar6
      003CE1 12 39 FC         [24]  408 	lcall	_ak820_flash_erase
      003CE4 E5 82            [12]  409 	mov	a, dpl
      003CE6 D0 06            [24]  410 	pop	ar6
      003CE8 D0 07            [24]  411 	pop	ar7
      003CEA 70 03            [24]  412 	jnz	00102$
      003CEC F5 82            [12]  413 	mov	dpl,a
      003CEE 22               [24]  414 	ret
      003CEF                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CEF 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CF2 74 1D            [12]  418 	mov	a,#_page_data
      003CF4 F0               [24]  419 	movx	@dptr,a
      003CF5 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CF7 A3               [24]  421 	inc	dptr
      003CF8 12 43 A7         [24]  422 	lcall	_ak820_outline_0072
      003CFB 12 3B 10         [24]  423 	lcall	_ak820_flash_program_page
      003CFE E5 82            [12]  424 	mov	a, dpl
      003D00 70 03            [24]  425 	jnz	00120$
      003D02 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D04 22               [24]  428 	ret
      003D05                        429 00120$:
      003D05 7F 00            [12]  430 	mov	r7,#0x00
      003D07                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003D07 8F 05            [24]  433 	mov	ar5,r7
      003D09 7E 00            [12]  434 	mov	r6,#0x00
      003D0B 90 05 68         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003D0E 12 38 91         [24]  436 	lcall	_ak820_outline_0123
      003D11 ED               [12]  437 	mov	a,r5
      003D12 2B               [12]  438 	add	a, r3
      003D13 FB               [12]  439 	mov	r3,a
      003D14 EE               [12]  440 	mov	a,r6
      003D15 3C               [12]  441 	addc	a, r4
      003D16 FC               [12]  442 	mov	r4,a
      003D17 12 33 FC         [24]  443 	lcall	_ak820_outline_0121
      003D1A 12 38 EF         [24]  444 	lcall	_ak820_flash_read
      003D1D AE 82            [24]  445 	mov	r6, dpl
      003D1F 12 43 B9         [24]  446 	lcall	_ak820_outline_0105
      003D22 FD               [12]  447 	mov	r5,a
      003D23 EE               [12]  448 	mov	a,r6
      003D24 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003D27 80 04            [24]  450 	sjmp	00109$
      003D29                        451 00149$:
      003D29 75 82 00         [24]  452 	mov	dpl, #0x00
      003D2C 22               [24]  453 	ret
      003D2D                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D2D 0F               [12]  456 	inc	r7
      003D2E BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003D31 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003D34 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003D35                        472 _journal_header_valid:
      003D35 12 38 82         [24]  473 	lcall	_ak820_outline_0107
      003D38 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003D3B 12 38 87         [24]  475 	lcall	_ak820_outline_0108
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D3E 90 05 6A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D41 12 37 F4         [24]  478 	lcall	_ak820_outline_0005
      003D44 E0               [24]  479 	movx	a,@dptr
      003D45 FD               [12]  480 	mov	r5,a
      003D46 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D49 80 04            [24]  482 	sjmp	00116$
      003D4B                        483 00138$:
      003D4B 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D4E 22               [24]  486 	ret
      003D4F                        487 00116$:
      003D4F 7D 01            [12]  488 	mov	r5,#0x01
      003D51                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D51 ED               [12]  491 	mov	a,r5
      003D52 12 38 31         [24]  492 	lcall	_ak820_outline_0023
      003D55 E0               [24]  493 	movx	a,@dptr
      003D56 FC               [12]  494 	mov	r4,a
      003D57 8D 02            [24]  495 	mov	ar2,r5
      003D59 7B 00            [12]  496 	mov	r3,#0x00
      003D5B 74 04            [12]  497 	mov	a,#0x04
      003D5D 2A               [12]  498 	add	a, r2
      003D5E FA               [12]  499 	mov	r2,a
      003D5F E4               [12]  500 	clr	a
      003D60 3B               [12]  501 	addc	a, r3
      003D61 FB               [12]  502 	mov	r3,a
      003D62 EA               [12]  503 	mov	a,r2
      003D63 2E               [12]  504 	add	a, r6
      003D64 F5 82            [12]  505 	mov	dpl,a
      003D66 EB               [12]  506 	mov	a,r3
      003D67 3F               [12]  507 	addc	a, r7
      003D68 F5 83            [12]  508 	mov	dph,a
      003D6A E0               [24]  509 	movx	a,@dptr
      003D6B 62 04            [12]  510 	xrl	ar4,a
      003D6D BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003D70 80 04            [24]  512 	sjmp	00107$
      003D72                        513 00139$:
      003D72 75 82 00         [24]  514 	mov	dpl, #0x00
      003D75 22               [24]  515 	ret
      003D76                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D76 0D               [12]  518 	inc	r5
      003D77 BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D7A 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D7D 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D7E                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D7E 7F 00            [12]  538 	mov	r7,#0x00
      003D80                        539 00115$:
      003D80 EF               [12]  540 	mov	a,r7
      003D81 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D83 FD               [12]  542 	mov	r5,a
      003D84 E4               [12]  543 	clr	a
      003D85 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D87 FE               [12]  545 	mov	r6,a
      003D88 8F 04            [24]  546 	mov	ar4,r7
      003D8A 7B 00            [12]  547 	mov	r3,#0x00
      003D8C 74 40            [12]  548 	mov	a,#0x40
      003D8E 2C               [12]  549 	add	a, r4
      003D8F FC               [12]  550 	mov	r4,a
      003D90 74 EF            [12]  551 	mov	a,#0xef
      003D92 3B               [12]  552 	addc	a, r3
      003D93 FB               [12]  553 	mov	r3,a
      003D94 12 43 F1         [24]  554 	lcall	_ak820_outline_0184
      003D97 12 38 EF         [24]  555 	lcall	_ak820_flash_read
      003D9A AC 82            [24]  556 	mov	r4, dpl
      003D9C 12 43 A0         [24]  557 	lcall	_ak820_outline_0064
      003D9F 0F               [12]  558 	inc	r7
      003DA0 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003DA3 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003DA6 12 3D 35         [24]  562 	lcall	_journal_header_valid
      003DA9 E5 82            [12]  563 	mov	a, dpl
      003DAB 70 01            [24]  564 	jnz	00103$
      003DAD 22               [24]  565 	ret
      003DAE                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003DAE 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003DB1 E0               [24]  569 	movx	a,@dptr
      003DB2 FF               [12]  570 	mov	r7,a
      003DB3 7E 00            [12]  571 	mov	r6,#0x00
      003DB5 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003DB8 E0               [24]  573 	movx	a,@dptr
      003DB9 FC               [12]  574 	mov	r4,a
      003DBA E4               [12]  575 	clr	a
      003DBB 42 07            [12]  576 	orl	ar7,a
      003DBD EC               [12]  577 	mov	a,r4
      003DBE 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003DC0 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003DC3 E0               [24]  581 	movx	a,@dptr
      003DC4 FD               [12]  582 	mov	r5,a
      003DC5 7C 00            [12]  583 	mov	r4,#0x00
      003DC7 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003DCA E0               [24]  585 	movx	a,@dptr
      003DCB FA               [12]  586 	mov	r2,a
      003DCC E4               [12]  587 	clr	a
      003DCD 12 43 D0         [24]  588 	lcall	_ak820_outline_0142
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003DD0 C3               [12]  590 	clr	c
      003DD1 EF               [12]  591 	mov	a,r7
      003DD2 94 A0            [12]  592 	subb	a,#0xa0
      003DD4 EE               [12]  593 	mov	a,r6
      003DD5 94 00            [12]  594 	subb	a,#0x00
      003DD7 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003DD9 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DDC 02 3B ED         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DDF                        601 00134$:
      003DDF 7B 00            [12]  602 	mov	r3,#0x00
      003DE1                        603 00117$:
      003DE1 C0 05            [24]  604 	push	ar5
      003DE3 C0 04            [24]  605 	push	ar4
      003DE5 EB               [12]  606 	mov	a,r3
      003DE6 24 1D            [12]  607 	add	a, #_page_data
      003DE8 F9               [12]  608 	mov	r1,a
      003DE9 E4               [12]  609 	clr	a
      003DEA 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003DEC FA               [12]  611 	mov	r2,a
      003DED 8B 00            [24]  612 	mov	ar0,r3
      003DEF 7D 00            [12]  613 	mov	r5,#0x00
      003DF1 74 EF            [12]  614 	mov	a,#0xef
      003DF3 2D               [12]  615 	add	a, r5
      003DF4 FD               [12]  616 	mov	r5,a
      003DF5 88 82            [24]  617 	mov	dpl, r0
      003DF7 8D 83            [24]  618 	mov	dph, r5
      003DF9 12 38 EF         [24]  619 	lcall	_ak820_flash_read
      003DFC AD 82            [24]  620 	mov	r5, dpl
      003DFE 12 43 EC         [24]  621 	lcall	_ak820_outline_0183
      003E01 ED               [12]  622 	mov	a,r5
      003E02 F0               [24]  623 	movx	@dptr,a
      003E03 0B               [12]  624 	inc	r3
      003E04 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003E07 80 06            [24]  626 	sjmp	00191$
      003E09                        627 00190$:
      003E09 D0 04            [24]  628 	pop	ar4
      003E0B D0 05            [24]  629 	pop	ar5
      003E0D 80 D2            [24]  630 	sjmp	00117$
      003E0F                        631 00191$:
      003E0F D0 04            [24]  632 	pop	ar4
      003E11 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003E13 C0 07            [24]  635 	push	ar7
      003E15 C0 06            [24]  636 	push	ar6
      003E17 C0 05            [24]  637 	push	ar5
      003E19 C0 04            [24]  638 	push	ar4
      003E1B 12 3C 9B         [24]  639 	lcall	_page_crc
      003E1E AA 82            [24]  640 	mov	r2, dpl
      003E20 AB 83            [24]  641 	mov	r3, dph
      003E22 D0 04            [24]  642 	pop	ar4
      003E24 D0 05            [24]  643 	pop	ar5
      003E26 D0 06            [24]  644 	pop	ar6
      003E28 D0 07            [24]  645 	pop	ar7
      003E2A EA               [12]  646 	mov	a,r2
      003E2B B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003E2E EB               [12]  648 	mov	a,r3
      003E2F B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003E32 80 06            [24]  650 	sjmp	00113$
      003E34                        651 00192$:
      003E34 75 82 02         [24]  652 	mov	dpl, #0x02
      003E37 02 3B ED         [24]  653 	ljmp	_nvm_fail
      003E3A                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E3A EE               [12]  656 	mov	a,r6
      003E3B 54 03            [12]  657 	anl	a,#0x03
      003E3D A2 E0            [12]  658 	mov	c,acc.0
      003E3F CF               [12]  659 	xch	a,r7
      003E40 13               [12]  660 	rrc	a
      003E41 CF               [12]  661 	xch	a,r7
      003E42 13               [12]  662 	rrc	a
      003E43 A2 E0            [12]  663 	mov	c,acc.0
      003E45 CF               [12]  664 	xch	a,r7
      003E46 13               [12]  665 	rrc	a
      003E47 CF               [12]  666 	xch	a,r7
      003E48 13               [12]  667 	rrc	a
      003E49 CF               [12]  668 	xch	a,r7
      003E4A 24 C7            [12]  669 	add	a,#0xc7
      003E4C FE               [12]  670 	mov	r6,a
      003E4D 12 43 DB         [24]  671 	lcall	_ak820_outline_0158
      003E50 12 3C CE         [24]  672 	lcall	_write_page
      003E53 E5 82            [12]  673 	mov	a, dpl
      003E55 70 06            [24]  674 	jnz	00110$
      003E57 75 82 03         [24]  675 	mov	dpl, #0x03
      003E5A 02 3B ED         [24]  676 	ljmp	_nvm_fail
      003E5D                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E5D 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003E60 12 39 FC         [24]  680 	lcall	_ak820_flash_erase
      003E63 E5 82            [12]  681 	mov	a, dpl
      003E65 70 06            [24]  682 	jnz	00119$
      003E67 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E6A 02 3B ED         [24]  685 	ljmp	_nvm_fail
      003E6D                        686 00119$:
      003E6D 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003E6E                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003E6E C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E70 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003E73 E4               [12]  701 	clr	a
      003E74 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003E75 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E77 C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E79 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E7C E4               [12]  710 	clr	a
      003E7D F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E7E 12 3D 7E         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E81 02 2A 6B         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E84                        724 _ak820_nvm_ok:
      003E84 A2 0B            [12]  725 	mov	c,_storage_failed
      003E86 B3               [12]  726 	cpl	c
      003E87 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E89 12 38 B1         [24]  728 	lcall	_ak820_outline_0156
      003E8C 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E8D                        737 _ak820_nvm_schema_fault:
      003E8D 75 82 10         [24]  738 	mov	dpl, #0x10
      003E90 02 3B ED         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E93                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E93 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E96 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E99                        756 00101$:
      003E99 22               [24]  757 	ret
      003E9A                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E9A 12 3C 9B         [24]  760 	lcall	_page_crc
      003E9D 12 43 C5         [24]  761 	lcall	_ak820_outline_0133
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003EA0 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EA3 74 A5            [12]  764 	mov	a,#0xa5
      003EA5 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003EA6 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003EA9 E0               [24]  768 	movx	a,@dptr
      003EAA 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003EAD F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003EAE 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003EB1 E4               [12]  773 	clr	a
      003EB2 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003EB3 8E 05            [24]  776 	mov	ar5,r6
      003EB5 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003EB8 ED               [12]  778 	mov	a,r5
      003EB9 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003EBA 8F 06            [24]  781 	mov	ar6,r7
      003EBC 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003EBF EE               [12]  783 	mov	a,r6
      003EC0 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003EC1 7F 01            [12]  786 	mov	r7,#0x01
      003EC3                        787 00128$:
      003EC3 8F 06            [24]  788 	mov	ar6,r7
      003EC5 EE               [12]  789 	mov	a,r6
      003EC6 24 04            [12]  790 	add	a,#0x04
      003EC8 FE               [12]  791 	mov	r6,a
      003EC9 33               [12]  792 	rlc	a
      003ECA 95 E0            [12]  793 	subb	a,acc
      003ECC FD               [12]  794 	mov	r5,a
      003ECD EE               [12]  795 	mov	a,r6
      003ECE 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003ED0 FE               [12]  797 	mov	r6,a
      003ED1 ED               [12]  798 	mov	a,r5
      003ED2 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003ED4 FD               [12]  800 	mov	r5,a
      003ED5 12 43 83         [24]  801 	lcall	_ak820_outline_0045
      003ED8 FC               [12]  802 	mov	r4,a
      003ED9 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003EDC 8E 82            [24]  804 	mov	dpl,r6
      003EDE 8D 83            [24]  805 	mov	dph,r5
      003EE0 EC               [12]  806 	mov	a,r4
      003EE1 F0               [24]  807 	movx	@dptr,a
      003EE2 0F               [12]  808 	inc	r7
      003EE3 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EE6 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE9 74 05            [12]  812 	mov	a,#0x05
      003EEB F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EEC 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003EEF 12 39 FC         [24]  816 	lcall	_ak820_flash_erase
      003EF2 E5 82            [12]  817 	mov	a, dpl
      003EF4 70 03            [24]  818 	jnz	00269$
      003EF6 02 3F DC         [24]  819 	ljmp	00127$
      003EF9                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EF9 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFC 74 06            [12]  823 	mov	a,#0x06
      003EFE F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EFF 7F 00            [12]  826 	mov	r7,#0x00
      003F01                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003F01 12 43 8F         [24]  829 	lcall	_ak820_outline_0053
      003F04 12 38 EF         [24]  830 	lcall	_ak820_flash_read
      003F07 E5 82            [12]  831 	mov	a, dpl
      003F09 60 03            [24]  832 	jz	00270$
      003F0B 02 3F DC         [24]  833 	ljmp	00127$
      003F0E                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F0E 0F               [12]  836 	inc	r7
      003F0F BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003F12 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F15 74 07            [12]  840 	mov	a,#0x07
      003F17 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003F18 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003F1B 12 3C CE         [24]  844 	lcall	_write_page
      003F1E E5 82            [12]  845 	mov	a, dpl
      003F20 70 03            [24]  846 	jnz	00273$
      003F22 02 3F DC         [24]  847 	ljmp	00127$
      003F25                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003F25 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F28 74 08            [12]  851 	mov	a,#0x08
      003F2A F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F2B 7F 01            [12]  854 	mov	r7,#0x01
      003F2D                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003F2D 12 43 83         [24]  857 	lcall	_ak820_outline_0045
      003F30 FE               [12]  858 	mov	r6,a
      003F31 60 22            [24]  859 	jz	00133$
      003F33 8F 05            [24]  860 	mov	ar5,r7
      003F35 7C 00            [12]  861 	mov	r4,#0x00
      003F37 74 40            [12]  862 	mov	a,#0x40
      003F39 2D               [12]  863 	add	a, r5
      003F3A FD               [12]  864 	mov	r5,a
      003F3B 74 EF            [12]  865 	mov	a,#0xef
      003F3D 3C               [12]  866 	addc	a, r4
      003F3E FC               [12]  867 	mov	r4,a
      003F3F 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003F42 EE               [12]  869 	mov	a,r6
      003F43 F0               [24]  870 	movx	@dptr,a
      003F44 12 43 F6         [24]  871 	lcall	_ak820_outline_0189
      003F47 C0 07            [24]  872 	push	ar7
      003F49 12 3A 5C         [24]  873 	lcall	_ak820_flash_program
      003F4C E5 82            [12]  874 	mov	a, dpl
      003F4E D0 07            [24]  875 	pop	ar7
      003F50 70 03            [24]  876 	jnz	00275$
      003F52 02 3F DC         [24]  877 	ljmp	00127$
      003F55                        878 00275$:
      003F55                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F55 0F               [12]  881 	inc	r7
      003F56 BF 09 D4         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F59 90 05 7E         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F5C 74 09            [12]  885 	mov	a,#0x09
      003F5E F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F5F 7F 01            [12]  888 	mov	r7,#0x01
      003F61                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F61 12 43 8F         [24]  891 	lcall	_ak820_outline_0053
      003F64 12 38 EF         [24]  892 	lcall	_ak820_flash_read
      003F67 AE 82            [24]  893 	mov	r6, dpl
      003F69 12 43 83         [24]  894 	lcall	_ak820_outline_0045
      003F6C FD               [12]  895 	mov	r5,a
      003F6D EE               [12]  896 	mov	a,r6
      003F6E B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F71 0F               [12]  899 	inc	r7
      003F72 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F75 90 05 7E         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F78 74 0A            [12]  903 	mov	a,#0x0a
      003F7A F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F7B 90 05 75         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F7E E0               [24]  907 	movx	a,@dptr
      003F7F 90 04 F6         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      003F82 F0               [24]  909 	movx	@dptr,a
      003F83 90 EF 40         [24]  910 	mov	dptr,#0xef40
      003F86 12 3A 5C         [24]  911 	lcall	_ak820_flash_program
      003F89 E5 82            [12]  912 	mov	a, dpl
      003F8B 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F8D 90 05 7E         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F90 74 0B            [12]  916 	mov	a,#0x0b
      003F92 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F93 90 EF 40         [24]  919 	mov	dptr,#0xef40
      003F96 12 38 EF         [24]  920 	lcall	_ak820_flash_read
      003F99 AF 82            [24]  921 	mov	r7, dpl
      003F9B 90 05 75         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F9E E0               [24]  923 	movx	a,@dptr
      003F9F FE               [12]  924 	mov	r6,a
      003FA0 EF               [12]  925 	mov	a,r7
      003FA1 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003FA4 90 05 7E         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FA7 74 0C            [12]  929 	mov	a,#0x0c
      003FA9 F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003FAA 90 05 5D         [24]  932 	mov	dptr,#_cached_page
      003FAD E0               [24]  933 	movx	a,@dptr
      003FAE FE               [12]  934 	mov	r6,a
      003FAF E4               [12]  935 	clr	a
      003FB0 C3               [12]  936 	clr	c
      003FB1 CE               [12]  937 	xch	a,r6
      003FB2 13               [12]  938 	rrc	a
      003FB3 CE               [12]  939 	xch	a,r6
      003FB4 13               [12]  940 	rrc	a
      003FB5 A2 E0            [12]  941 	mov	c,acc.0
      003FB7 CE               [12]  942 	xch	a,r6
      003FB8 13               [12]  943 	rrc	a
      003FB9 CE               [12]  944 	xch	a,r6
      003FBA 13               [12]  945 	rrc	a
      003FBB CE               [12]  946 	xch	a,r6
      003FBC 24 C7            [12]  947 	add	a,#0xc7
      003FBE FF               [12]  948 	mov	r7,a
      003FBF 12 38 8C         [24]  949 	lcall	_ak820_outline_0118
      003FC2 12 3C CE         [24]  950 	lcall	_write_page
      003FC5 E5 82            [12]  951 	mov	a, dpl
      003FC7 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003FC9 90 05 7E         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FCC 74 0D            [12]  955 	mov	a,#0x0d
      003FCE F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003FCF 90 EF 40         [24]  958 	mov	dptr,#0xef40
      003FD2 12 39 FC         [24]  959 	lcall	_ak820_flash_erase
      003FD5 E5 82            [12]  960 	mov	a, dpl
      003FD7 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      003FD9 C2 0A            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003FDB 22               [24]  967 	ret
      003FDC                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FDC 90 05 7E         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FDF E0               [24]  971 	movx	a,@dptr
      003FE0 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FE2 02 3B ED         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      003FE5                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FE5 90 05 5E         [24]  984 	mov	dptr,#_batch_depth
      003FE8 E0               [24]  985 	movx	a,@dptr
      003FE9 FF               [12]  986 	mov	r7,a
      003FEA BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      003FED 75 82 0F         [24]  988 	mov	dpl, #0x0f
      003FF0 02 3B ED         [24]  989 	ljmp	_nvm_fail
      003FF3                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FF3 90 05 5E         [24]  992 	mov	dptr,#_batch_depth
      003FF6 EF               [12]  993 	mov	a,r7
      003FF7 04               [12]  994 	inc	a
      003FF8 F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FF9 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      003FFA                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FFA 90 05 5E         [24] 1007 	mov	dptr,#_batch_depth
      003FFD E0               [24] 1008 	movx	a,@dptr
      003FFE FF               [12] 1009 	mov	r7,a
      003FFF E0               [24] 1010 	movx	a,@dptr
      004000 60 06            [24] 1011 	jz	00102$
      004002 EF               [12] 1012 	mov	a,r7
      004003 14               [12] 1013 	dec	a
      004004 90 05 5E         [24] 1014 	mov	dptr,#_batch_depth
      004007 F0               [24] 1015 	movx	@dptr,a
      004008                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004008 90 05 5E         [24] 1018 	mov	dptr,#_batch_depth
      00400B E0               [24] 1019 	movx	a,@dptr
      00400C 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      00400E 02 3E 93         [24] 1022 	ljmp	_ak820_nvm_flush
      004011                       1023 00105$:
      004011 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      004012                       1035 _load_page:
      004012 E5 82            [12] 1036 	mov	a,dpl
      004014 90 05 7F         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      004017 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004018 30 09 17         [24] 1040 	jnb	_page_valid,00102$
      00401B 90 05 5D         [24] 1041 	mov	dptr,#_cached_page
      00401E E0               [24] 1042 	movx	a,@dptr
      00401F FF               [12] 1043 	mov	r7,a
      004020 90 05 7F         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      004023 E0               [24] 1045 	movx	a,@dptr
      004024 FE               [12] 1046 	mov	r6,a
      004025 EF               [12] 1047 	mov	a,r7
      004026 B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      004029 A2 0B            [12] 1049 	mov	c,_storage_failed
      00402B B3               [12] 1050 	cpl	c
      00402C 92 0D            [24] 1051 	mov  _load_page_sloc0_1_0,c
      00402E 12 38 B1         [24] 1052 	lcall	_ak820_outline_0156
      004031 22               [24] 1053 	ret
      004032                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004032 12 3E 93         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004035 30 0B 04         [24] 1058 	jnb	_storage_failed,00119$
      004038 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00403B 22               [24] 1061 	ret
      00403C                       1062 00119$:
      00403C 7F 00            [12] 1063 	mov	r7,#0x00
      00403E                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      00403E EF               [12] 1066 	mov	a,r7
      00403F 24 1D            [12] 1067 	add	a, #_page_data
      004041 FD               [12] 1068 	mov	r5,a
      004042 E4               [12] 1069 	clr	a
      004043 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      004045 FE               [12] 1071 	mov	r6,a
      004046 90 05 7F         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      004049 E0               [24] 1073 	movx	a,@dptr
      00404A FC               [12] 1074 	mov	r4,a
      00404B FA               [12] 1075 	mov	r2,a
      00404C E4               [12] 1076 	clr	a
      00404D C3               [12] 1077 	clr	c
      00404E CA               [12] 1078 	xch	a,r2
      00404F 13               [12] 1079 	rrc	a
      004050 CA               [12] 1080 	xch	a,r2
      004051 13               [12] 1081 	rrc	a
      004052 A2 E0            [12] 1082 	mov	c,acc.0
      004054 CA               [12] 1083 	xch	a,r2
      004055 13               [12] 1084 	rrc	a
      004056 CA               [12] 1085 	xch	a,r2
      004057 13               [12] 1086 	rrc	a
      004058 CA               [12] 1087 	xch	a,r2
      004059 24 C7            [12] 1088 	add	a,#0xc7
      00405B FB               [12] 1089 	mov	r3,a
      00405C 8F 01            [24] 1090 	mov	ar1,r7
      00405E 89 00            [24] 1091 	mov	ar0,r1
      004060 79 00            [12] 1092 	mov	r1,#0x00
      004062 E8               [12] 1093 	mov	a,r0
      004063 2A               [12] 1094 	add	a, r2
      004064 FA               [12] 1095 	mov	r2,a
      004065 E9               [12] 1096 	mov	a,r1
      004066 3B               [12] 1097 	addc	a, r3
      004067 FB               [12] 1098 	mov	r3,a
      004068 12 38 AC         [24] 1099 	lcall	_ak820_outline_0143
      00406B 12 38 EF         [24] 1100 	lcall	_ak820_flash_read
      00406E AB 82            [24] 1101 	mov	r3, dpl
      004070 12 38 A1         [24] 1102 	lcall	_ak820_outline_0135
      004073 EB               [12] 1103 	mov	a,r3
      004074 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004075 0F               [12] 1106 	inc	r7
      004076 BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004079 90 05 5D         [24] 1109 	mov	dptr,#_cached_page
      00407C EC               [12] 1110 	mov	a,r4
      00407D F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      00407E D2 09            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004080 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004083 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004084                       1128 _read_offset:
      004084 12 38 82         [24] 1129 	lcall	_ak820_outline_0107
      004087 90 05 80         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      00408A 12 38 87         [24] 1131 	lcall	_ak820_outline_0108
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00408D 90 05 80         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004090 12 38 41         [24] 1134 	lcall	_ak820_outline_0052
      004093 C3               [12] 1135 	clr	c
      004094 94 28            [12] 1136 	subb	a,#0x28
      004096 40 04            [24] 1137 	jc	00102$
      004098 75 82 00         [24] 1138 	mov	dpl, #0x00
      00409B 22               [24] 1139 	ret
      00409C                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00409C 30 09 34         [24] 1142 	jnb	_page_valid,00104$
      00409F 8E 04            [24] 1143 	mov	ar4,r6
      0040A1 EF               [12] 1144 	mov	a,r7
      0040A2 A2 E7            [12] 1145 	mov	c,acc.7
      0040A4 CC               [12] 1146 	xch	a,r4
      0040A5 33               [12] 1147 	rlc	a
      0040A6 CC               [12] 1148 	xch	a,r4
      0040A7 33               [12] 1149 	rlc	a
      0040A8 A2 E7            [12] 1150 	mov	c,acc.7
      0040AA CC               [12] 1151 	xch	a,r4
      0040AB 33               [12] 1152 	rlc	a
      0040AC CC               [12] 1153 	xch	a,r4
      0040AD 33               [12] 1154 	rlc	a
      0040AE CC               [12] 1155 	xch	a,r4
      0040AF 54 03            [12] 1156 	anl	a,#0x03
      0040B1 FD               [12] 1157 	mov	r5,a
      0040B2 90 05 5D         [24] 1158 	mov	dptr,#_cached_page
      0040B5 E0               [24] 1159 	movx	a,@dptr
      0040B6 FA               [12] 1160 	mov	r2,a
      0040B7 7B 00            [12] 1161 	mov	r3,#0x00
      0040B9 EC               [12] 1162 	mov	a,r4
      0040BA B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      0040BD ED               [12] 1164 	mov	a,r5
      0040BE B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0040C1 74 3F            [12] 1167 	mov	a,#0x3f
      0040C3 5E               [12] 1168 	anl	a,r6
      0040C4 7D 00            [12] 1169 	mov	r5,#0x00
      0040C6 24 1D            [12] 1170 	add	a, #_page_data
      0040C8 F5 82            [12] 1171 	mov	dpl,a
      0040CA ED               [12] 1172 	mov	a,r5
      0040CB 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      0040CD F5 83            [12] 1174 	mov	dph,a
      0040CF E0               [24] 1175 	movx	a,@dptr
      0040D0 F5 82            [12] 1176 	mov	dpl,a
      0040D2 22               [24] 1177 	ret
      0040D3                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0040D3 74 C7            [12] 1180 	mov	a,#0xc7
      0040D5 2F               [12] 1181 	add	a, r7
      0040D6 FF               [12] 1182 	mov	r7,a
      0040D7 12 38 8C         [24] 1183 	lcall	_ak820_outline_0118
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0040DA 02 38 EF         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      0040DD                       1195 _eeprom_read_byte:
      0040DD C0 07            [24] 1196 	push	ar7
      0040DF C0 06            [24] 1197 	push	ar6
      0040E1 12 43 7C         [24] 1198 	lcall	_ak820_outline_0038
      0040E4 90 05 82         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040E7 12 38 29         [24] 1200 	lcall	_ak820_outline_0018
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040EA 90 05 82         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040ED 12 37 F4         [24] 1203 	lcall	_ak820_outline_0005
      0040F0 C0 06            [24] 1204 	push	ar6
      0040F2 C0 05            [24] 1205 	push	ar5
      0040F4 C0 04            [24] 1206 	push	ar4
      0040F6 C0 03            [24] 1207 	push	ar3
      0040F8 C0 02            [24] 1208 	push	ar2
      0040FA C0 01            [24] 1209 	push	ar1
      0040FC C0 00            [24] 1210 	push	ar0
      0040FE 12 40 84         [24] 1211 	lcall	_read_offset
      004101 AF 82            [24] 1212 	mov	r7, dpl
      004103 D0 00            [24] 1213 	pop	ar0
      004105 D0 01            [24] 1214 	pop	ar1
      004107 D0 02            [24] 1215 	pop	ar2
      004109 D0 03            [24] 1216 	pop	ar3
      00410B D0 04            [24] 1217 	pop	ar4
      00410D D0 05            [24] 1218 	pop	ar5
      00410F D0 06            [24] 1219 	pop	ar6
      004111 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004113 D0 06            [24] 1222 	pop	ar6
      004115 D0 07            [24] 1223 	pop	ar7
      004117 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      004118                       1238 _ak820_eeprom_read_block_xdata:
      004118 12 38 82         [24] 1239 	lcall	_ak820_outline_0107
      00411B 90 05 8A         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00411E 12 38 87         [24] 1241 	lcall	_ak820_outline_0108
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004121 90 05 85         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004124 12 38 41         [24] 1244 	lcall	_ak820_outline_0052
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004127 90 05 8A         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00412A 12 38 58         [24] 1247 	lcall	_ak820_outline_0060
      00412D 90 05 8C         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004130 12 38 5E         [24] 1249 	lcall	_ak820_outline_0073
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004133 90 05 88         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004136 12 38 58         [24] 1252 	lcall	_ak820_outline_0060
      004139                       1253 00103$:
      004139 8C 02            [24] 1254 	mov	ar2,r4
      00413B 8D 03            [24] 1255 	mov	ar3,r5
      00413D 1C               [12] 1256 	dec	r4
      00413E BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      004141 1D               [12] 1258 	dec	r5
      004142                       1259 00130$:
      004142 EA               [12] 1260 	mov	a,r2
      004143 4B               [12] 1261 	orl	a,r3
      004144 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004146 8E 02            [24] 1264 	mov	ar2,r6
      004148 8F 03            [24] 1265 	mov	ar3,r7
      00414A 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      00414C 2B               [12] 1267 	add	a,r3
      00414D 50 17            [24] 1268 	jnc	00102$
      00414F 90 05 8C         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004152 12 43 B3         [24] 1270 	lcall	_ak820_outline_0104
      004155 12 38 AC         [24] 1271 	lcall	_ak820_outline_0143
      004158 E4               [12] 1272 	clr	a
      004159 F0               [24] 1273 	movx	@dptr,a
      00415A 90 05 8C         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00415D 04               [12] 1275 	inc	a
      00415E 2A               [12] 1276 	add	a, r2
      00415F F0               [24] 1277 	movx	@dptr,a
      004160 E4               [12] 1278 	clr	a
      004161 3B               [12] 1279 	addc	a, r3
      004162 A3               [24] 1280 	inc	dptr
      004163 F0               [24] 1281 	movx	@dptr,a
      004164 80 D3            [24] 1282 	sjmp	00103$
      004166                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004166 90 05 8C         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004169 12 43 B3         [24] 1286 	lcall	_ak820_outline_0104
      00416C 12 38 8C         [24] 1287 	lcall	_ak820_outline_0118
      00416F C0 07            [24] 1288 	push	ar7
      004171 C0 06            [24] 1289 	push	ar6
      004173 C0 05            [24] 1290 	push	ar5
      004175 C0 04            [24] 1291 	push	ar4
      004177 C0 03            [24] 1292 	push	ar3
      004179 C0 02            [24] 1293 	push	ar2
      00417B 12 40 84         [24] 1294 	lcall	_read_offset
      00417E A9 82            [24] 1295 	mov	r1, dpl
      004180 D0 02            [24] 1296 	pop	ar2
      004182 D0 03            [24] 1297 	pop	ar3
      004184 D0 04            [24] 1298 	pop	ar4
      004186 D0 05            [24] 1299 	pop	ar5
      004188 D0 06            [24] 1300 	pop	ar6
      00418A D0 07            [24] 1301 	pop	ar7
      00418C 12 38 AC         [24] 1302 	lcall	_ak820_outline_0143
      00418F E9               [12] 1303 	mov	a,r1
      004190 F0               [24] 1304 	movx	@dptr,a
      004191 90 05 8C         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004194 74 01            [12] 1306 	mov	a,#0x01
      004196 2A               [12] 1307 	add	a, r2
      004197 F0               [24] 1308 	movx	@dptr,a
      004198 E4               [12] 1309 	clr	a
      004199 3B               [12] 1310 	addc	a, r3
      00419A A3               [24] 1311 	inc	dptr
      00419B F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00419C 0E               [12] 1314 	inc	r6
      00419D BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      0041A0 0F               [12] 1316 	inc	r7
      0041A1 80 96            [24] 1317 	sjmp	00103$
      0041A3                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0041A3 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      0041A4                       1336 _ak820_eeprom_write_block_xdata:
      0041A4 12 38 82         [24] 1337 	lcall	_ak820_outline_0107
      0041A7 90 05 93         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041AA 12 38 87         [24] 1339 	lcall	_ak820_outline_0108
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041AD 90 05 8E         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0041B0 12 38 41         [24] 1342 	lcall	_ak820_outline_0052
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0041B3 90 05 93         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041B6 12 38 58         [24] 1345 	lcall	_ak820_outline_0060
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0041B9 8E 02            [24] 1347 	mov	ar2,r6
      0041BB 8F 03            [24] 1348 	mov	ar3,r7
      0041BD C3               [12] 1349 	clr	c
      0041BE E4               [12] 1350 	clr	a
      0041BF 9A               [12] 1351 	subb	a,r2
      0041C0 74 28            [12] 1352 	mov	a,#0x28
      0041C2 9B               [12] 1353 	subb	a,r3
      0041C3 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      0041C5 E4               [12] 1356 	clr	a
      0041C6 C3               [12] 1357 	clr	c
      0041C7 9E               [12] 1358 	subb	a,r6
      0041C8 FA               [12] 1359 	mov	r2,a
      0041C9 74 28            [12] 1360 	mov	a,#0x28
      0041CB 9F               [12] 1361 	subb	a,r7
      0041CC FB               [12] 1362 	mov	r3,a
      0041CD 90 05 91         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041D0 12 38 7C         [24] 1364 	lcall	_ak820_outline_0103
      0041D3 C3               [12] 1365 	clr	c
      0041D4 EA               [12] 1366 	mov	a,r2
      0041D5 98               [12] 1367 	subb	a,r0
      0041D6 EB               [12] 1368 	mov	a,r3
      0041D7 99               [12] 1369 	subb	a,r1
      0041D8 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      0041DA                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0041DA 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041DD 02 3B ED         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041E0                       1378 00125$:
      0041E0 90 05 91         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041E3 12 43 B3         [24] 1380 	lcall	_ak820_outline_0104
      0041E6                       1381 00108$:
      0041E6 8A 00            [24] 1382 	mov	ar0,r2
      0041E8 8B 01            [24] 1383 	mov	ar1,r3
      0041EA 1A               [12] 1384 	dec	r2
      0041EB BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      0041EE 1B               [12] 1386 	dec	r3
      0041EF                       1387 00159$:
      0041EF E8               [12] 1388 	mov	a,r0
      0041F0 49               [12] 1389 	orl	a,r1
      0041F1 70 03            [24] 1390 	jnz	00160$
      0041F3 02 42 7D         [24] 1391 	ljmp	00110$
      0041F6                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041F6 C0 02            [24] 1394 	push	ar2
      0041F8 C0 03            [24] 1395 	push	ar3
      0041FA 12 43 AD         [24] 1396 	lcall	_ak820_outline_0096
      0041FD F9               [12] 1397 	mov	r1,a
      0041FE A3               [24] 1398 	inc	dptr
      0041FF 12 43 D6         [24] 1399 	lcall	_ak820_outline_0149
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004202 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004204 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004206 A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004208 E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00420A A2 E7            [12] 1405 	mov	c,acc.7
      00420C C8               [12] 1406 	xch	a,r0
      00420D 33               [12] 1407 	rlc	a
      00420E C8               [12] 1408 	xch	a,r0
      00420F 33               [12] 1409 	rlc	a
      004210 A2 E7            [12] 1410 	mov	c,acc.7
      004212 C8               [12] 1411 	xch	a,r0
      004213 33               [12] 1412 	rlc	a
      004214 C8               [12] 1413 	xch	a,r0
      004215 33               [12] 1414 	rlc	a
      004216 C8               [12] 1415 	xch	a,r0
      004217 54 03            [12] 1416 	anl	a,#0x03
      004219 FB               [12] 1417 	mov	r3,a
      00421A 88 82            [24] 1418 	mov	dpl, r0
      00421C C0 07            [24] 1419 	push	ar7
      00421E C0 06            [24] 1420 	push	ar6
      004220 C0 05            [24] 1421 	push	ar5
      004222 C0 04            [24] 1422 	push	ar4
      004224 C0 03            [24] 1423 	push	ar3
      004226 C0 02            [24] 1424 	push	ar2
      004228 C0 01            [24] 1425 	push	ar1
      00422A 12 40 12         [24] 1426 	lcall	_load_page
      00422D E5 82            [12] 1427 	mov	a, dpl
      00422F D0 01            [24] 1428 	pop	ar1
      004231 D0 02            [24] 1429 	pop	ar2
      004233 D0 03            [24] 1430 	pop	ar3
      004235 D0 04            [24] 1431 	pop	ar4
      004237 D0 05            [24] 1432 	pop	ar5
      004239 D0 06            [24] 1433 	pop	ar6
      00423B D0 07            [24] 1434 	pop	ar7
      00423D D0 03            [24] 1435 	pop	ar3
      00423F D0 02            [24] 1436 	pop	ar2
      004241 70 01            [24] 1437 	jnz	00105$
      004243 22               [24] 1438 	ret
      004244                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004244 C0 06            [24] 1441 	push	ar6
      004246 C0 07            [24] 1442 	push	ar7
      004248 74 3F            [12] 1443 	mov	a,#0x3f
      00424A 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00424C 7F 00            [12] 1445 	mov	r7,#0x00
      00424E 24 1D            [12] 1446 	add	a, #_page_data
      004250 F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004252 EF               [12] 1448 	mov	a,r7
      004253 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      004255 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004257 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00425A 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00425D E0               [24] 1453 	movx	a,@dptr
      00425E B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      004261 D0 07            [24] 1455 	pop	ar7
      004263 D0 06            [24] 1456 	pop	ar6
      004265 80 0E            [24] 1457 	sjmp	00107$
      004267                       1458 00162$:
      004267 D0 07            [24] 1459 	pop	ar7
      004269 D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00426B 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00426E 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004271 E9               [12] 1464 	mov	a,r1
      004272 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004273 D2 0A            [12] 1468 	setb	_page_dirty
      004275                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004275 0E               [12] 1471 	inc	r6
      004276 BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      004279 0F               [12] 1473 	inc	r7
      00427A                       1474 00163$:
      00427A 02 41 E6         [24] 1475 	ljmp	00108$
      00427D                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00427D 90 05 5E         [24] 1478 	mov	dptr,#_batch_depth
      004280 E0               [24] 1479 	movx	a,@dptr
      004281 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004283 02 3E 93         [24] 1482 	ljmp	_ak820_nvm_flush
      004286                       1483 00113$:
      004286 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      004287                       1502 _ak820_eeprom_update_block_xdata:
      004287 12 38 82         [24] 1503 	lcall	_ak820_outline_0107
      00428A 90 05 9A         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00428D 12 38 87         [24] 1505 	lcall	_ak820_outline_0108
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004290 90 05 9A         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004293 12 38 41         [24] 1508 	lcall	_ak820_outline_0052
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004296 90 05 95         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004299 E0               [24] 1511 	movx	a,@dptr
      00429A F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00429C A3               [24] 1513 	inc	dptr
      00429D E0               [24] 1514 	movx	a,@dptr
      00429E F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0042A0 A3               [24] 1516 	inc	dptr
      0042A1 E0               [24] 1517 	movx	a,@dptr
      0042A2 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0042A4 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042A6 AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042A8 E4               [12] 1522 	clr	a
      0042A9 F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0042AB F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0042AD                       1525 00105$:
      0042AD 90 05 98         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0042B0 E0               [24] 1527 	movx	a,@dptr
      0042B1 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0042B3 A3               [24] 1529 	inc	dptr
      0042B4 E0               [24] 1530 	movx	a,@dptr
      0042B5 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0042B7 C3               [12] 1532 	clr	c
      0042B8 E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042BA 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042BC E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042BE 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042C0 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0042C2 89 00            [24] 1539 	mov	ar0,r1
      0042C4 8A 05            [24] 1540 	mov	ar5,r2
      0042C6 E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042C8 28               [12] 1542 	add	a, r0
      0042C9 F8               [12] 1543 	mov	r0,a
      0042CA E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042CC 3D               [12] 1545 	addc	a, r5
      0042CD FD               [12] 1546 	mov	r5,a
      0042CE 88 82            [24] 1547 	mov	dpl, r0
      0042D0 8D 83            [24] 1548 	mov	dph, r5
      0042D2 C0 07            [24] 1549 	push	ar7
      0042D4 C0 06            [24] 1550 	push	ar6
      0042D6 C0 02            [24] 1551 	push	ar2
      0042D8 C0 01            [24] 1552 	push	ar1
      0042DA 12 40 84         [24] 1553 	lcall	_read_offset
      0042DD AD 82            [24] 1554 	mov	r5, dpl
      0042DF D0 01            [24] 1555 	pop	ar1
      0042E1 D0 02            [24] 1556 	pop	ar2
      0042E3 D0 06            [24] 1557 	pop	ar6
      0042E5 D0 07            [24] 1558 	pop	ar7
      0042E7 E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042E9 2E               [12] 1560 	add	a, r6
      0042EA F5 82            [12] 1561 	mov	dpl,a
      0042EC E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042EE 3F               [12] 1563 	addc	a, r7
      0042EF F5 83            [12] 1564 	mov	dph,a
      0042F1 E0               [24] 1565 	movx	a,@dptr
      0042F2 FC               [12] 1566 	mov	r4,a
      0042F3 ED               [12] 1567 	mov	a,r5
      0042F4 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      0042F7 80 27            [24] 1569 	sjmp	00106$
      0042F9                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042F9 90 05 9A         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0042FC E0               [24] 1573 	movx	a,@dptr
      0042FD F8               [12] 1574 	mov	r0,a
      0042FE A3               [24] 1575 	inc	dptr
      0042FF E0               [24] 1576 	movx	a,@dptr
      004300 FD               [12] 1577 	mov	r5,a
      004301 90 05 8E         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004304 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004306 F0               [24] 1580 	movx	@dptr,a
      004307 E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004309 A3               [24] 1582 	inc	dptr
      00430A F0               [24] 1583 	movx	@dptr,a
      00430B E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00430D A3               [24] 1585 	inc	dptr
      00430E F0               [24] 1586 	movx	@dptr,a
      00430F 90 05 91         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004312 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004314 F0               [24] 1589 	movx	@dptr,a
      004315 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004317 A3               [24] 1591 	inc	dptr
      004318 F0               [24] 1592 	movx	@dptr,a
      004319 88 82            [24] 1593 	mov	dpl, r0
      00431B 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00431D 02 41 A4         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      004320                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004320 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004322 E4               [12] 1600 	clr	a
      004323 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004326 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004328 80 83            [24] 1603 	sjmp	00105$
      00432A                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00432A 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      00432B                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00432B 12 3E 93         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00432E 7F 00            [12] 1621 	mov	r7,#0x00
      004330                       1622 00111$:
      004330 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      004333 22               [24] 1624 	ret
      004334                       1625 00165$:
      004334 20 0B 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004337 8F 82            [24] 1628 	mov	dpl, r7
      004339 C0 07            [24] 1629 	push	ar7
      00433B 12 40 12         [24] 1630 	lcall	_load_page
      00433E E5 82            [12] 1631 	mov	a, dpl
      004340 D0 07            [24] 1632 	pop	ar7
      004342 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004344 22               [24] 1635 	ret
      004345                       1636 00126$:
      004345 7E 00            [12] 1637 	mov	r6,#0x00
      004347                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004347 EE               [12] 1640 	mov	a,r6
      004348 24 1D            [12] 1641 	add	a, #_page_data
      00434A FC               [12] 1642 	mov	r4,a
      00434B E4               [12] 1643 	clr	a
      00434C 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      00434E FD               [12] 1645 	mov	r5,a
      00434F 12 43 AD         [24] 1646 	lcall	_ak820_outline_0096
      004352 60 07            [24] 1647 	jz	00108$
      004354 12 38 97         [24] 1648 	lcall	_ak820_outline_0124
      004357 E4               [12] 1649 	clr	a
      004358 F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      004359 D2 0A            [12] 1652 	setb	_page_dirty
      00435B                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00435B 0E               [12] 1655 	inc	r6
      00435C BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00435F C0 07            [24] 1658 	push	ar7
      004361 12 3E 93         [24] 1659 	lcall	_ak820_nvm_flush
      004364 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004366 0F               [12] 1662 	inc	r7
      004367 80 C7            [24] 1663 	sjmp	00111$
      004369                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004369 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0005
                                   1674 	.globl _ak820_outline_0012
                                   1675 	.globl _ak820_outline_0018
                                   1676 	.globl _ak820_outline_0023
                                   1677 	.globl _ak820_outline_0032
                                   1678 	.globl _ak820_outline_0038
                                   1679 	.globl _ak820_outline_0045
                                   1680 	.globl _ak820_outline_0052
                                   1681 	.globl _ak820_outline_0053
                                   1682 	.globl _ak820_outline_0060
                                   1683 	.globl _ak820_outline_0064
                                   1684 	.globl _ak820_outline_0072
                                   1685 	.globl _ak820_outline_0073
                                   1686 	.globl _ak820_outline_0080
                                   1687 	.globl _ak820_outline_0086
                                   1688 	.globl _ak820_outline_0096
                                   1689 	.globl _ak820_outline_0103
                                   1690 	.globl _ak820_outline_0104
                                   1691 	.globl _ak820_outline_0105
                                   1692 	.globl _ak820_outline_0107
                                   1693 	.globl _ak820_outline_0108
                                   1694 	.globl _ak820_outline_0118
                                   1695 	.globl _ak820_outline_0121
                                   1696 	.globl _ak820_outline_0123
                                   1697 	.globl _ak820_outline_0124
                                   1698 	.globl _ak820_outline_0133
                                   1699 	.globl _ak820_outline_0135
                                   1700 	.globl _ak820_outline_0137
                                   1701 	.globl _ak820_outline_0142
                                   1702 	.globl _ak820_outline_0143
                                   1703 	.globl _ak820_outline_0149
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0158
                                   1706 	.globl _ak820_outline_0161
                                   1707 	.globl _ak820_outline_0162
                                   1708 	.globl _ak820_outline_0183
                                   1709 	.globl _ak820_outline_0184
                                   1710 	.globl _ak820_outline_0189
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0012
      00436A                       1714 _ak820_outline_0012:
      00436A 8E 82            [24] 1715 	mov	dpl,r6
      00436C 8F 83            [24] 1716 	mov	dph,r7
      00436E A3               [24] 1717 	inc	dptr
      00436F A3               [24] 1718 	inc	dptr
      004370 A3               [24] 1719 	inc	dptr
      004371 A3               [24] 1720 	inc	dptr
      004372 A3               [24] 1721 	inc	dptr
      004373 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0032
      004374                       1726 _ak820_outline_0032:
      004374 F0               [24] 1727 	movx	@dptr,a
      004375 8E 82            [24] 1728 	mov	dpl,r6
      004377 8F 83            [24] 1729 	mov	dph,r7
      004379 A3               [24] 1730 	inc	dptr
      00437A A3               [24] 1731 	inc	dptr
      00437B 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0038
      00437C                       1736 _ak820_outline_0038:
      00437C AF F0            [24] 1737 	mov	r7,b
      00437E AE 83            [24] 1738 	mov	r6,dph
      004380 E5 82            [12] 1739 	mov	a,dpl
      004382 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0045
      004383                       1744 _ak820_outline_0045:
      004383 EF               [12] 1745 	mov	a,r7
      004384 24 75            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004386 F5 82            [12] 1747 	mov	dpl,a
      004388 E4               [12] 1748 	clr	a
      004389 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00438B F5 83            [12] 1750 	mov	dph,a
      00438D E0               [24] 1751 	movx	a,@dptr
      00438E 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      00438F                       1756 _ak820_outline_0053:
      00438F 8F 06            [24] 1757 	mov	ar6,r7
      004391 7D 00            [12] 1758 	mov	r5,#0x00
      004393 74 40            [12] 1759 	mov	a,#0x40
      004395 2E               [12] 1760 	add	a,r6
      004396 FE               [12] 1761 	mov	r6,a
      004397 74 EF            [12] 1762 	mov	a,#0xef
      004399 3D               [12] 1763 	addc	a,r5
      00439A FD               [12] 1764 	mov	r5,a
      00439B 8E 82            [24] 1765 	mov	dpl,r6
      00439D 8D 83            [24] 1766 	mov	dph,r5
      00439F 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0064
      0043A0                       1771 _ak820_outline_0064:
      0043A0 8D 82            [24] 1772 	mov	dpl,r5
      0043A2 8E 83            [24] 1773 	mov	dph,r6
      0043A4 EC               [12] 1774 	mov	a,r4
      0043A5 F0               [24] 1775 	movx	@dptr,a
      0043A6 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0072
      0043A7                       1780 _ak820_outline_0072:
      0043A7 F0               [24] 1781 	movx	@dptr,a
      0043A8 8E 82            [24] 1782 	mov	dpl,r6
      0043AA 8F 83            [24] 1783 	mov	dph,r7
      0043AC 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0096
      0043AD                       1788 _ak820_outline_0096:
      0043AD 8C 82            [24] 1789 	mov	dpl,r4
      0043AF 8D 83            [24] 1790 	mov	dph,r5
      0043B1 E0               [24] 1791 	movx	a,@dptr
      0043B2 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0104
      0043B3                       1796 _ak820_outline_0104:
      0043B3 E0               [24] 1797 	movx	a,@dptr
      0043B4 FA               [12] 1798 	mov	r2,a
      0043B5 A3               [24] 1799 	inc	dptr
      0043B6 E0               [24] 1800 	movx	a,@dptr
      0043B7 FB               [12] 1801 	mov	r3,a
      0043B8 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0105
      0043B9                       1806 _ak820_outline_0105:
      0043B9 EF               [12] 1807 	mov	a,r7
      0043BA 24 1D            [12] 1808 	add	a,#_page_data
      0043BC F5 82            [12] 1809 	mov	dpl,a
      0043BE E4               [12] 1810 	clr	a
      0043BF 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0043C1 F5 83            [12] 1812 	mov	dph,a
      0043C3 E0               [24] 1813 	movx	a,@dptr
      0043C4 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0133
      0043C5                       1818 _ak820_outline_0133:
      0043C5 AE 82            [24] 1819 	mov	r6,dpl
      0043C7 AF 83            [24] 1820 	mov	r7,dph
      0043C9 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0137
      0043CA                       1825 _ak820_outline_0137:
      0043CA 2E               [12] 1826 	add	a,r6
      0043CB FE               [12] 1827 	mov	r6,a
      0043CC E4               [12] 1828 	clr	a
      0043CD 3F               [12] 1829 	addc	a,r7
      0043CE FF               [12] 1830 	mov	r7,a
      0043CF 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0142
      0043D0                       1835 _ak820_outline_0142:
      0043D0 42 05            [12] 1836 	orl	ar5,a
      0043D2 EA               [12] 1837 	mov	a,r2
      0043D3 42 04            [12] 1838 	orl	ar4,a
      0043D5 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0149
      0043D6                       1843 _ak820_outline_0149:
      0043D6 AC 82            [24] 1844 	mov	r4,dpl
      0043D8 AD 83            [24] 1845 	mov	r5,dph
      0043DA 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0158
      0043DB                       1850 _ak820_outline_0158:
      0043DB 8F 82            [24] 1851 	mov	dpl,r7
      0043DD 8E 83            [24] 1852 	mov	dph,r6
      0043DF 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0161
      0043E0                       1857 _ak820_outline_0161:
      0043E0 2E               [12] 1858 	add	a,r6
      0043E1 FC               [12] 1859 	mov	r4,a
      0043E2 E4               [12] 1860 	clr	a
      0043E3 3F               [12] 1861 	addc	a,r7
      0043E4 FD               [12] 1862 	mov	r5,a
      0043E5 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0162
      0043E6                       1867 _ak820_outline_0162:
      0043E6 ED               [12] 1868 	mov	a,r5
      0043E7 F0               [24] 1869 	movx	@dptr,a
      0043E8 EE               [12] 1870 	mov	a,r6
      0043E9 A3               [24] 1871 	inc	dptr
      0043EA F0               [24] 1872 	movx	@dptr,a
      0043EB 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0183
      0043EC                       1877 _ak820_outline_0183:
      0043EC 89 82            [24] 1878 	mov	dpl,r1
      0043EE 8A 83            [24] 1879 	mov	dph,r2
      0043F0 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0184
      0043F1                       1884 _ak820_outline_0184:
      0043F1 8C 82            [24] 1885 	mov	dpl,r4
      0043F3 8B 83            [24] 1886 	mov	dph,r3
      0043F5 22               [24] 1887 	ret
                                   1888 
                                   1889 	.area CSEG (CODE)
                                   1890 ; function ak820_outline_0189
      0043F6                       1891 _ak820_outline_0189:
      0043F6 8D 82            [24] 1892 	mov	dpl,r5
      0043F8 8C 83            [24] 1893 	mov	dph,r4
      0043FA 22               [24] 1894 	ret
