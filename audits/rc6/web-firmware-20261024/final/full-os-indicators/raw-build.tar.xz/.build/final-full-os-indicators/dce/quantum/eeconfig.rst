                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeconfig
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeconfig_init_via
                                     12 	.globl _via_eeprom_set_valid
                                     13 	.globl _via_eeprom_is_valid
                                     14 	.globl _eeprom_driver_erase
                                     15 	.globl _ak820_eeprom_update_block_xdata
                                     16 	.globl _eeprom_update_dword
                                     17 	.globl _eeprom_update_word
                                     18 	.globl _eeprom_update_byte
                                     19 	.globl _eeprom_read_dword
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_byte
                                     22 	.globl _ADC_START
                                     23 	.globl _S0_R_FIFO
                                     24 	.globl _S0_T_FIFO
                                     25 	.globl _S0_FREE
                                     26 	.globl _S0_IF_BYTE
                                     27 	.globl _S0_IF_FIRST
                                     28 	.globl _S0_IF_OV
                                     29 	.globl _S0_FST_ACT
                                     30 	.globl _CP_RL2
                                     31 	.globl _C_T2
                                     32 	.globl _TR2
                                     33 	.globl _EXEN2
                                     34 	.globl _TCLK
                                     35 	.globl _RCLK
                                     36 	.globl _EXF2
                                     37 	.globl _CAP1F
                                     38 	.globl _TF2
                                     39 	.globl _RI
                                     40 	.globl _TI
                                     41 	.globl _RB8
                                     42 	.globl _TB8
                                     43 	.globl _REN
                                     44 	.globl _SM2
                                     45 	.globl _SM1
                                     46 	.globl _SM0
                                     47 	.globl _IT0
                                     48 	.globl _IE0
                                     49 	.globl _IT1
                                     50 	.globl _IE1
                                     51 	.globl _TR0
                                     52 	.globl _TF0
                                     53 	.globl _TR1
                                     54 	.globl _TF1
                                     55 	.globl _P4_0
                                     56 	.globl _P4_1
                                     57 	.globl _P4_2
                                     58 	.globl _P4_3
                                     59 	.globl _P4_4
                                     60 	.globl _P4_5
                                     61 	.globl _P4_6
                                     62 	.globl _RXD
                                     63 	.globl _TXD
                                     64 	.globl _INT0
                                     65 	.globl _INT1
                                     66 	.globl _T0
                                     67 	.globl _T1
                                     68 	.globl _MOSI1
                                     69 	.globl _MISO1
                                     70 	.globl _SCK1
                                     71 	.globl _P3_0
                                     72 	.globl _P3_1
                                     73 	.globl _P3_2
                                     74 	.globl _P3_3
                                     75 	.globl _P3_4
                                     76 	.globl _P3_5
                                     77 	.globl _P3_6
                                     78 	.globl _P3_7
                                     79 	.globl _CAP1_
                                     80 	.globl _T2_
                                     81 	.globl _CAP2_
                                     82 	.globl _T2EX_
                                     83 	.globl _RXD1
                                     84 	.globl _TXD1
                                     85 	.globl _P2_0
                                     86 	.globl _P2_1
                                     87 	.globl _P2_2
                                     88 	.globl _P2_3
                                     89 	.globl _P2_4
                                     90 	.globl _P2_5
                                     91 	.globl _P2_6
                                     92 	.globl _P2_7
                                     93 	.globl _AIN0
                                     94 	.globl _AIN1
                                     95 	.globl _AIN2
                                     96 	.globl _AIN3
                                     97 	.globl _AIN4
                                     98 	.globl _AIN5
                                     99 	.globl _AIN6
                                    100 	.globl _AIN7
                                    101 	.globl _CAP1
                                    102 	.globl _T2
                                    103 	.globl _CAP2
                                    104 	.globl _T2EX
                                    105 	.globl _INT0_
                                    106 	.globl _SCS
                                    107 	.globl _MOSI
                                    108 	.globl _MISO
                                    109 	.globl _SCK
                                    110 	.globl _RXD1_
                                    111 	.globl _TXD1_
                                    112 	.globl _P1_0
                                    113 	.globl _P1_1
                                    114 	.globl _P1_2
                                    115 	.globl _P1_3
                                    116 	.globl _P1_4
                                    117 	.globl _P1_5
                                    118 	.globl _P1_6
                                    119 	.globl _P1_7
                                    120 	.globl _AIN8
                                    121 	.globl _AIN9
                                    122 	.globl _AIN10
                                    123 	.globl _AIN11
                                    124 	.globl _AIN12
                                    125 	.globl _AIN13
                                    126 	.globl _RXD_
                                    127 	.globl _TXD_
                                    128 	.globl _SCL0
                                    129 	.globl _SDA0
                                    130 	.globl _P0_0
                                    131 	.globl _P0_1
                                    132 	.globl _P0_2
                                    133 	.globl _P0_3
                                    134 	.globl _P0_4
                                    135 	.globl _P0_5
                                    136 	.globl _P0_6
                                    137 	.globl _P0_7
                                    138 	.globl _IE_SPI0
                                    139 	.globl _IE_USB
                                    140 	.globl _IE_ADC
                                    141 	.globl _IE_UART1
                                    142 	.globl _IE_PWM_I2C
                                    143 	.globl _IE_GPIO
                                    144 	.globl _IE_WDOG
                                    145 	.globl _PX0
                                    146 	.globl _PT0
                                    147 	.globl _PX1
                                    148 	.globl _PT1
                                    149 	.globl _PS
                                    150 	.globl _PT2
                                    151 	.globl _PL_FLAG
                                    152 	.globl _PH_FLAG
                                    153 	.globl _EX0
                                    154 	.globl _ET0
                                    155 	.globl _EX1
                                    156 	.globl _ET1
                                    157 	.globl _ES
                                    158 	.globl _ET2
                                    159 	.globl _E_DIS
                                    160 	.globl _EA
                                    161 	.globl _P
                                    162 	.globl _F1
                                    163 	.globl _OV
                                    164 	.globl _RS0
                                    165 	.globl _RS1
                                    166 	.globl _F0
                                    167 	.globl _AC
                                    168 	.globl _CY
                                    169 	.globl _I2CS_INT_ST
                                    170 	.globl _I2CX_INT
                                    171 	.globl _LED_STATUS
                                    172 	.globl _LED_DMA_H
                                    173 	.globl _LED_DMA_L
                                    174 	.globl _LED_DMA
                                    175 	.globl _LED_PWM_OE
                                    176 	.globl _LED_COMMON
                                    177 	.globl _ADC_CHAN
                                    178 	.globl _ADC_DAT_H
                                    179 	.globl _ADC_DAT_L
                                    180 	.globl _ADC_DAT
                                    181 	.globl _ADC_CTRL
                                    182 	.globl _SPI1_CK_SE
                                    183 	.globl _SPI1_CTRL
                                    184 	.globl _SPI1_DATA
                                    185 	.globl _SPI1_STAT
                                    186 	.globl _SIF1
                                    187 	.globl _SBAUD1
                                    188 	.globl _SBUF1
                                    189 	.globl _SCON1
                                    190 	.globl _SPI0_SETUP
                                    191 	.globl _SPI0_CK_SE
                                    192 	.globl _SPI0_CTRL
                                    193 	.globl _SPI0_DATA
                                    194 	.globl _SPI0_STAT
                                    195 	.globl _T2CAP1H
                                    196 	.globl _T2CAP1L
                                    197 	.globl _T2CAP1
                                    198 	.globl _TH2
                                    199 	.globl _TL2
                                    200 	.globl _T2COUNT
                                    201 	.globl _RCAP2H
                                    202 	.globl _RCAP2L
                                    203 	.globl _RCAP2
                                    204 	.globl _T2MOD
                                    205 	.globl _T2CON
                                    206 	.globl _SBUF
                                    207 	.globl _SCON
                                    208 	.globl _TH1
                                    209 	.globl _TH0
                                    210 	.globl _TL1
                                    211 	.globl _TL0
                                    212 	.globl _TMOD
                                    213 	.globl _TCON
                                    214 	.globl _XBUS_AUX
                                    215 	.globl _P7
                                    216 	.globl _P6_DIR
                                    217 	.globl _P6_OUT_PU
                                    218 	.globl _P6_IN
                                    219 	.globl _P5_DIR
                                    220 	.globl _P5_OUT_PU
                                    221 	.globl _P5_IN
                                    222 	.globl _P4_LED_KEY
                                    223 	.globl _P4_DIR_PU
                                    224 	.globl _P4_MOD_OC
                                    225 	.globl _P4
                                    226 	.globl _P3_DIR_PU
                                    227 	.globl _P3_MOD_OC
                                    228 	.globl _P3
                                    229 	.globl _P2_DIR_PU
                                    230 	.globl _P2_MOD_OC
                                    231 	.globl _P2
                                    232 	.globl _P1_DIR_PU
                                    233 	.globl _P1_MOD_OC
                                    234 	.globl _P1
                                    235 	.globl _P0_DIR_PU
                                    236 	.globl _P0_MOD_OC
                                    237 	.globl _P0
                                    238 	.globl _ROM_CTRL
                                    239 	.globl _ROM_DATA_HH
                                    240 	.globl _ROM_DATA_HL
                                    241 	.globl _ROM_DATA_HI
                                    242 	.globl _ROM_ADDR_H
                                    243 	.globl _ROM_ADDR_L
                                    244 	.globl _ROM_ADDR
                                    245 	.globl _GPIO_IE
                                    246 	.globl _IP_EX
                                    247 	.globl _IE_EX
                                    248 	.globl _IP
                                    249 	.globl _IE
                                    250 	.globl _WDOG_COUNT
                                    251 	.globl _RESET_KEEP
                                    252 	.globl _WAKE_CTRL
                                    253 	.globl _CLOCK_CFG
                                    254 	.globl _POWER_CFG
                                    255 	.globl _PCON
                                    256 	.globl _GLOBAL_CFG
                                    257 	.globl _SAFE_MOD
                                    258 	.globl _DPH
                                    259 	.globl _DPL
                                    260 	.globl _SP
                                    261 	.globl _A_INV
                                    262 	.globl _B
                                    263 	.globl _ACC
                                    264 	.globl _PSW
                                    265 	.globl _eeconfig_init_user
                                    266 	.globl _eeconfig_init_kb
                                    267 	.globl _eeconfig_init_quantum
                                    268 	.globl _eeconfig_init
                                    269 	.globl _eeconfig_disable
                                    270 	.globl _eeconfig_is_enabled
                                    271 	.globl _eeconfig_read_debug
                                    272 	.globl _eeconfig_read_default_layer
                                    273 	.globl _eeconfig_read_keymap
                                    274 	.globl _eeconfig_update_kb
                                    275 	.globl _eeconfig_update_user
                                    276 ;--------------------------------------------------------
                                    277 ; special function registers
                                    278 ;--------------------------------------------------------
                                    279 	.area RSEG    (ABS,DATA)
      000000                        280 	.org 0x0000
                           0000D0   281 _PSW	=	0x00d0
                           0000E0   282 _ACC	=	0x00e0
                           0000F0   283 _B	=	0x00f0
                           0000FD   284 _A_INV	=	0x00fd
                           000081   285 _SP	=	0x0081
                           000082   286 _DPL	=	0x0082
                           000083   287 _DPH	=	0x0083
                           0000A1   288 _SAFE_MOD	=	0x00a1
                           0000B1   289 _GLOBAL_CFG	=	0x00b1
                           000087   290 _PCON	=	0x0087
                           0000BA   291 _POWER_CFG	=	0x00ba
                           0000B9   292 _CLOCK_CFG	=	0x00b9
                           0000A9   293 _WAKE_CTRL	=	0x00a9
                           0000FE   294 _RESET_KEEP	=	0x00fe
                           0000FF   295 _WDOG_COUNT	=	0x00ff
                           0000A8   296 _IE	=	0x00a8
                           0000B8   297 _IP	=	0x00b8
                           0000E8   298 _IE_EX	=	0x00e8
                           0000E9   299 _IP_EX	=	0x00e9
                           0000B2   300 _GPIO_IE	=	0x00b2
                           008584   301 _ROM_ADDR	=	0x8584
                           000084   302 _ROM_ADDR_L	=	0x0084
                           000085   303 _ROM_ADDR_H	=	0x0085
                           008F8E   304 _ROM_DATA_HI	=	0x8f8e
                           00008E   305 _ROM_DATA_HL	=	0x008e
                           00008F   306 _ROM_DATA_HH	=	0x008f
                           000086   307 _ROM_CTRL	=	0x0086
                           000080   308 _P0	=	0x0080
                           0000C4   309 _P0_MOD_OC	=	0x00c4
                           0000C5   310 _P0_DIR_PU	=	0x00c5
                           000090   311 _P1	=	0x0090
                           000092   312 _P1_MOD_OC	=	0x0092
                           000093   313 _P1_DIR_PU	=	0x0093
                           0000A0   314 _P2	=	0x00a0
                           000094   315 _P2_MOD_OC	=	0x0094
                           000095   316 _P2_DIR_PU	=	0x0095
                           0000B0   317 _P3	=	0x00b0
                           000096   318 _P3_MOD_OC	=	0x0096
                           000097   319 _P3_DIR_PU	=	0x0097
                           0000C0   320 _P4	=	0x00c0
                           0000C2   321 _P4_MOD_OC	=	0x00c2
                           0000C3   322 _P4_DIR_PU	=	0x00c3
                           0000C1   323 _P4_LED_KEY	=	0x00c1
                           0000AA   324 _P5_IN	=	0x00aa
                           0000AB   325 _P5_OUT_PU	=	0x00ab
                           0000AC   326 _P5_DIR	=	0x00ac
                           0000AD   327 _P6_IN	=	0x00ad
                           0000AE   328 _P6_OUT_PU	=	0x00ae
                           0000AF   329 _P6_DIR	=	0x00af
                           0000F1   330 _P7	=	0x00f1
                           0000A2   331 _XBUS_AUX	=	0x00a2
                           000088   332 _TCON	=	0x0088
                           000089   333 _TMOD	=	0x0089
                           00008A   334 _TL0	=	0x008a
                           00008B   335 _TL1	=	0x008b
                           00008C   336 _TH0	=	0x008c
                           00008D   337 _TH1	=	0x008d
                           000098   338 _SCON	=	0x0098
                           000099   339 _SBUF	=	0x0099
                           0000C8   340 _T2CON	=	0x00c8
                           0000C9   341 _T2MOD	=	0x00c9
                           00CBCA   342 _RCAP2	=	0xcbca
                           0000CA   343 _RCAP2L	=	0x00ca
                           0000CB   344 _RCAP2H	=	0x00cb
                           00CDCC   345 _T2COUNT	=	0xcdcc
                           0000CC   346 _TL2	=	0x00cc
                           0000CD   347 _TH2	=	0x00cd
                           00CFCE   348 _T2CAP1	=	0xcfce
                           0000CE   349 _T2CAP1L	=	0x00ce
                           0000CF   350 _T2CAP1H	=	0x00cf
                           0000F8   351 _SPI0_STAT	=	0x00f8
                           0000F9   352 _SPI0_DATA	=	0x00f9
                           0000FA   353 _SPI0_CTRL	=	0x00fa
                           0000FB   354 _SPI0_CK_SE	=	0x00fb
                           0000FC   355 _SPI0_SETUP	=	0x00fc
                           0000BC   356 _SCON1	=	0x00bc
                           0000BD   357 _SBUF1	=	0x00bd
                           0000BE   358 _SBAUD1	=	0x00be
                           0000BF   359 _SIF1	=	0x00bf
                           0000B4   360 _SPI1_STAT	=	0x00b4
                           0000B5   361 _SPI1_DATA	=	0x00b5
                           0000B6   362 _SPI1_CTRL	=	0x00b6
                           0000B7   363 _SPI1_CK_SE	=	0x00b7
                           0000F3   364 _ADC_CTRL	=	0x00f3
                           00F5F4   365 _ADC_DAT	=	0xf5f4
                           0000F4   366 _ADC_DAT_L	=	0x00f4
                           0000F5   367 _ADC_DAT_H	=	0x00f5
                           0000F6   368 _ADC_CHAN	=	0x00f6
                           0000A6   369 _LED_COMMON	=	0x00a6
                           0000A7   370 _LED_PWM_OE	=	0x00a7
                           00C7C6   371 _LED_DMA	=	0xc7c6
                           0000C6   372 _LED_DMA_L	=	0x00c6
                           0000C7   373 _LED_DMA_H	=	0x00c7
                           0000F7   374 _LED_STATUS	=	0x00f7
                           0000B3   375 _I2CX_INT	=	0x00b3
                           0000BB   376 _I2CS_INT_ST	=	0x00bb
                                    377 ;--------------------------------------------------------
                                    378 ; special function bits
                                    379 ;--------------------------------------------------------
                                    380 	.area RSEG    (ABS,DATA)
      000000                        381 	.org 0x0000
                           0000D7   382 _CY	=	0x00d7
                           0000D6   383 _AC	=	0x00d6
                           0000D5   384 _F0	=	0x00d5
                           0000D4   385 _RS1	=	0x00d4
                           0000D3   386 _RS0	=	0x00d3
                           0000D2   387 _OV	=	0x00d2
                           0000D1   388 _F1	=	0x00d1
                           0000D0   389 _P	=	0x00d0
                           0000AF   390 _EA	=	0x00af
                           0000AE   391 _E_DIS	=	0x00ae
                           0000AD   392 _ET2	=	0x00ad
                           0000AC   393 _ES	=	0x00ac
                           0000AB   394 _ET1	=	0x00ab
                           0000AA   395 _EX1	=	0x00aa
                           0000A9   396 _ET0	=	0x00a9
                           0000A8   397 _EX0	=	0x00a8
                           0000BF   398 _PH_FLAG	=	0x00bf
                           0000BE   399 _PL_FLAG	=	0x00be
                           0000BD   400 _PT2	=	0x00bd
                           0000BC   401 _PS	=	0x00bc
                           0000BB   402 _PT1	=	0x00bb
                           0000BA   403 _PX1	=	0x00ba
                           0000B9   404 _PT0	=	0x00b9
                           0000B8   405 _PX0	=	0x00b8
                           0000EF   406 _IE_WDOG	=	0x00ef
                           0000EE   407 _IE_GPIO	=	0x00ee
                           0000ED   408 _IE_PWM_I2C	=	0x00ed
                           0000EC   409 _IE_UART1	=	0x00ec
                           0000EB   410 _IE_ADC	=	0x00eb
                           0000E9   411 _IE_USB	=	0x00e9
                           0000E8   412 _IE_SPI0	=	0x00e8
                           000087   413 _P0_7	=	0x0087
                           000086   414 _P0_6	=	0x0086
                           000085   415 _P0_5	=	0x0085
                           000084   416 _P0_4	=	0x0084
                           000083   417 _P0_3	=	0x0083
                           000082   418 _P0_2	=	0x0082
                           000081   419 _P0_1	=	0x0081
                           000080   420 _P0_0	=	0x0080
                           000081   421 _SDA0	=	0x0081
                           000080   422 _SCL0	=	0x0080
                           000083   423 _TXD_	=	0x0083
                           000082   424 _RXD_	=	0x0082
                           000085   425 _AIN13	=	0x0085
                           000084   426 _AIN12	=	0x0084
                           000083   427 _AIN11	=	0x0083
                           000082   428 _AIN10	=	0x0082
                           000081   429 _AIN9	=	0x0081
                           000080   430 _AIN8	=	0x0080
                           000097   431 _P1_7	=	0x0097
                           000096   432 _P1_6	=	0x0096
                           000095   433 _P1_5	=	0x0095
                           000094   434 _P1_4	=	0x0094
                           000093   435 _P1_3	=	0x0093
                           000092   436 _P1_2	=	0x0092
                           000091   437 _P1_1	=	0x0091
                           000090   438 _P1_0	=	0x0090
                           000097   439 _TXD1_	=	0x0097
                           000096   440 _RXD1_	=	0x0096
                           000097   441 _SCK	=	0x0097
                           000096   442 _MISO	=	0x0096
                           000095   443 _MOSI	=	0x0095
                           000094   444 _SCS	=	0x0094
                           000092   445 _INT0_	=	0x0092
                           000091   446 _T2EX	=	0x0091
                           000091   447 _CAP2	=	0x0091
                           000090   448 _T2	=	0x0090
                           000090   449 _CAP1	=	0x0090
                           000097   450 _AIN7	=	0x0097
                           000096   451 _AIN6	=	0x0096
                           000095   452 _AIN5	=	0x0095
                           000094   453 _AIN4	=	0x0094
                           000093   454 _AIN3	=	0x0093
                           000092   455 _AIN2	=	0x0092
                           000091   456 _AIN1	=	0x0091
                           000090   457 _AIN0	=	0x0090
                           0000A7   458 _P2_7	=	0x00a7
                           0000A6   459 _P2_6	=	0x00a6
                           0000A5   460 _P2_5	=	0x00a5
                           0000A4   461 _P2_4	=	0x00a4
                           0000A3   462 _P2_3	=	0x00a3
                           0000A2   463 _P2_2	=	0x00a2
                           0000A1   464 _P2_1	=	0x00a1
                           0000A0   465 _P2_0	=	0x00a0
                           0000A7   466 _TXD1	=	0x00a7
                           0000A6   467 _RXD1	=	0x00a6
                           0000A5   468 _T2EX_	=	0x00a5
                           0000A5   469 _CAP2_	=	0x00a5
                           0000A4   470 _T2_	=	0x00a4
                           0000A4   471 _CAP1_	=	0x00a4
                           0000B7   472 _P3_7	=	0x00b7
                           0000B6   473 _P3_6	=	0x00b6
                           0000B5   474 _P3_5	=	0x00b5
                           0000B4   475 _P3_4	=	0x00b4
                           0000B3   476 _P3_3	=	0x00b3
                           0000B2   477 _P3_2	=	0x00b2
                           0000B1   478 _P3_1	=	0x00b1
                           0000B0   479 _P3_0	=	0x00b0
                           0000B7   480 _SCK1	=	0x00b7
                           0000B6   481 _MISO1	=	0x00b6
                           0000B5   482 _MOSI1	=	0x00b5
                           0000B5   483 _T1	=	0x00b5
                           0000B4   484 _T0	=	0x00b4
                           0000B3   485 _INT1	=	0x00b3
                           0000B2   486 _INT0	=	0x00b2
                           0000B1   487 _TXD	=	0x00b1
                           0000B0   488 _RXD	=	0x00b0
                           0000C6   489 _P4_6	=	0x00c6
                           0000C5   490 _P4_5	=	0x00c5
                           0000C4   491 _P4_4	=	0x00c4
                           0000C3   492 _P4_3	=	0x00c3
                           0000C2   493 _P4_2	=	0x00c2
                           0000C1   494 _P4_1	=	0x00c1
                           0000C0   495 _P4_0	=	0x00c0
                           00008F   496 _TF1	=	0x008f
                           00008E   497 _TR1	=	0x008e
                           00008D   498 _TF0	=	0x008d
                           00008C   499 _TR0	=	0x008c
                           00008B   500 _IE1	=	0x008b
                           00008A   501 _IT1	=	0x008a
                           000089   502 _IE0	=	0x0089
                           000088   503 _IT0	=	0x0088
                           00009F   504 _SM0	=	0x009f
                           00009E   505 _SM1	=	0x009e
                           00009D   506 _SM2	=	0x009d
                           00009C   507 _REN	=	0x009c
                           00009B   508 _TB8	=	0x009b
                           00009A   509 _RB8	=	0x009a
                           000099   510 _TI	=	0x0099
                           000098   511 _RI	=	0x0098
                           0000CF   512 _TF2	=	0x00cf
                           0000CF   513 _CAP1F	=	0x00cf
                           0000CE   514 _EXF2	=	0x00ce
                           0000CD   515 _RCLK	=	0x00cd
                           0000CC   516 _TCLK	=	0x00cc
                           0000CB   517 _EXEN2	=	0x00cb
                           0000CA   518 _TR2	=	0x00ca
                           0000C9   519 _C_T2	=	0x00c9
                           0000C8   520 _CP_RL2	=	0x00c8
                           0000FF   521 _S0_FST_ACT	=	0x00ff
                           0000FE   522 _S0_IF_OV	=	0x00fe
                           0000FD   523 _S0_IF_FIRST	=	0x00fd
                           0000FC   524 _S0_IF_BYTE	=	0x00fc
                           0000FB   525 _S0_FREE	=	0x00fb
                           0000FA   526 _S0_T_FIFO	=	0x00fa
                           0000F8   527 _S0_R_FIFO	=	0x00f8
                           0000F7   528 _ADC_START	=	0x00f7
                                    529 ;--------------------------------------------------------
                                    530 ; overlayable register banks
                                    531 ;--------------------------------------------------------
                                    532 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        533 	.ds 8
                                    534 ;--------------------------------------------------------
                                    535 ; internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area DSEG    (DATA)
      000034                        538 _eeconfig_is_enabled_sloc0_1_0:
      000034                        539 	.ds 1
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable items in internal ram
                                    542 ;--------------------------------------------------------
                                    543 ;--------------------------------------------------------
                                    544 ; indirectly addressable internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area ISEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; absolute internal ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area IABS    (ABS,DATA)
                                    551 	.area IABS    (ABS,DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; bit data
                                    554 ;--------------------------------------------------------
                                    555 	.area BSEG    (BIT)
                                    556 ;--------------------------------------------------------
                                    557 ; paged external ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area PSEG    (PAG,XDATA)
                                    560 ;--------------------------------------------------------
                                    561 ; uninitialized external ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area XSEG    (XDATA)
      000B4B                        564 _eeconfig_init_quantum_dummy_10001_258:
      000B4B                        565 	.ds 8
      000B53                        566 _eeconfig_is_enabled_is_eeprom_enabled_10000_266:
      000B53                        567 	.ds 1
      000B54                        568 _eeconfig_update_kb_val_10000_291:
      000B54                        569 	.ds 4
      000B58                        570 _eeconfig_update_user_val_10000_295:
      000B58                        571 	.ds 4
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
                                    580 	.area HOME    (CODE)
                                    581 	.area GSINIT0 (CODE)
                                    582 	.area GSINIT1 (CODE)
                                    583 	.area GSINIT2 (CODE)
                                    584 	.area GSINIT3 (CODE)
                                    585 	.area GSINIT4 (CODE)
                                    586 	.area GSINIT5 (CODE)
                                    587 	.area GSINIT  (CODE)
                                    588 	.area GSFINAL (CODE)
                                    589 	.area CSEG    (CODE)
                                    590 ;--------------------------------------------------------
                                    591 ; global & static initialisations
                                    592 ;--------------------------------------------------------
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT  (CODE)
                                    595 	.area GSFINAL (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 ;--------------------------------------------------------
                                    598 ; Home
                                    599 ;--------------------------------------------------------
                                    600 	.area HOME    (CODE)
                                    601 	.area HOME    (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; code
                                    604 ;--------------------------------------------------------
                                    605 	.area CSEG    (CODE)
                                    606 ;------------------------------------------------------------
                                    607 ;Allocation info for local variables in function 'eeconfig_init_user'
                                    608 ;------------------------------------------------------------
                                    609 ;	quantum/eeconfig.c:30: __attribute__((weak)) void eeconfig_init_user(void) {
                                    610 ;	-----------------------------------------
                                    611 ;	 function eeconfig_init_user
                                    612 ;	-----------------------------------------
      009042                        613 _eeconfig_init_user:
                           000007   614 	ar7 = 0x07
                           000006   615 	ar6 = 0x06
                           000005   616 	ar5 = 0x05
                           000004   617 	ar4 = 0x04
                           000003   618 	ar3 = 0x03
                           000002   619 	ar2 = 0x02
                           000001   620 	ar1 = 0x01
                           000000   621 	ar0 = 0x00
                                    622 ;	quantum/eeconfig.c:33: eeconfig_update_user(0);
      009042 12 91 E2         [24]  623 	lcall	_ak820_outline_0152
                                    624 ;	quantum/eeconfig.c:35: }
      009045 02 91 9B         [24]  625 	ljmp	_eeconfig_update_user
                                    626 ;------------------------------------------------------------
                                    627 ;Allocation info for local variables in function 'eeconfig_init_kb'
                                    628 ;------------------------------------------------------------
                                    629 ;	quantum/eeconfig.c:37: __attribute__((weak)) void eeconfig_init_kb(void) {
                                    630 ;	-----------------------------------------
                                    631 ;	 function eeconfig_init_kb
                                    632 ;	-----------------------------------------
      009048                        633 _eeconfig_init_kb:
                                    634 ;	quantum/eeconfig.c:40: eeconfig_update_kb(0);
      009048 12 91 E2         [24]  635 	lcall	_ak820_outline_0152
      00904B 12 91 7A         [24]  636 	lcall	_eeconfig_update_kb
                                    637 ;	quantum/eeconfig.c:43: eeconfig_init_user();
                                    638 ;	quantum/eeconfig.c:44: }
      00904E 02 90 42         [24]  639 	ljmp	_eeconfig_init_user
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'eeconfig_init_quantum'
                                    642 ;------------------------------------------------------------
                                    643 ;dummy         Allocated with name '_eeconfig_init_quantum_dummy_10001_258'
                                    644 ;------------------------------------------------------------
                                    645 ;	quantum/eeconfig.c:49: void eeconfig_init_quantum(void) {
                                    646 ;	-----------------------------------------
                                    647 ;	 function eeconfig_init_quantum
                                    648 ;	-----------------------------------------
      009051                        649 _eeconfig_init_quantum:
                                    650 ;	quantum/eeconfig.c:51: eeprom_driver_erase();
      009051 12 43 2B         [24]  651 	lcall	_eeprom_driver_erase
                                    652 ;	quantum/eeconfig.c:54: eeprom_update_word(EECONFIG_MAGIC, EECONFIG_MAGIC_NUMBER);
      009054 90 06 A7         [24]  653 	mov	dptr,#_eeprom_update_word_PARM_2
      009057 74 E6            [12]  654 	mov	a,#0xe6
      009059 F0               [24]  655 	movx	@dptr,a
      00905A 74 FE            [12]  656 	mov	a,#0xfe
      00905C A3               [24]  657 	inc	dptr
      00905D F0               [24]  658 	movx	@dptr,a
      00905E 12 91 E9         [24]  659 	lcall	_ak820_outline_0153
      009061 12 4F 70         [24]  660 	lcall	_eeprom_update_word
                                    661 ;	quantum/eeconfig.c:55: eeprom_update_byte(EECONFIG_DEBUG, 0);
      009064 12 91 D4         [24]  662 	lcall	_ak820_outline_0101
      009067 90 00 02         [24]  663 	mov	dptr,#0x0002
      00906A F5 F0            [12]  664 	mov	b,a
      00906C 12 4F 0B         [24]  665 	lcall	_eeprom_update_byte
                                    666 ;	quantum/eeconfig.c:56: eeprom_update_byte(EECONFIG_DEFAULT_LAYER, 0);
      00906F 12 91 D4         [24]  667 	lcall	_ak820_outline_0101
      009072 90 00 03         [24]  668 	mov	dptr,#0x0003
      009075 F5 F0            [12]  669 	mov	b,a
      009077 12 4F 0B         [24]  670 	lcall	_eeprom_update_byte
                                    671 ;	quantum/eeconfig.c:57: default_layer_state = 0;
      00907A 90 0D C7         [24]  672 	mov	dptr,#_default_layer_state
      00907D E4               [12]  673 	clr	a
      00907E F0               [24]  674 	movx	@dptr,a
                                    675 ;	quantum/eeconfig.c:59: eeprom_update_word(EECONFIG_KEYMAP, 0x1400);
      00907F 90 06 A7         [24]  676 	mov	dptr,#_eeprom_update_word_PARM_2
      009082 F0               [24]  677 	movx	@dptr,a
      009083 74 14            [12]  678 	mov	a,#0x14
      009085 A3               [24]  679 	inc	dptr
      009086 F0               [24]  680 	movx	@dptr,a
      009087 90 00 04         [24]  681 	mov	dptr,#0x0004
      00908A 75 F0 00         [24]  682 	mov	b, #0x00
      00908D 12 4F 70         [24]  683 	lcall	_eeprom_update_word
                                    684 ;	quantum/eeconfig.c:60: eeprom_update_byte(EECONFIG_BACKLIGHT, 0);
      009090 12 91 D4         [24]  685 	lcall	_ak820_outline_0101
      009093 90 00 06         [24]  686 	mov	dptr,#0x0006
      009096 F5 F0            [12]  687 	mov	b,a
      009098 12 4F 0B         [24]  688 	lcall	_eeprom_update_byte
                                    689 ;	quantum/eeconfig.c:61: eeprom_update_byte(EECONFIG_AUDIO, 0xFF); // On by default
      00909B 90 06 A3         [24]  690 	mov	dptr,#_eeprom_update_byte_PARM_2
      00909E 74 FF            [12]  691 	mov	a,#0xff
      0090A0 F0               [24]  692 	movx	@dptr,a
      0090A1 90 00 07         [24]  693 	mov	dptr,#0x0007
      0090A4 75 F0 00         [24]  694 	mov	b, #0x00
      0090A7 12 4F 0B         [24]  695 	lcall	_eeprom_update_byte
                                    696 ;	quantum/eeconfig.c:62: eeprom_update_dword(EECONFIG_RGBLIGHT, 0);
      0090AA 90 06 AC         [24]  697 	mov	dptr,#_eeprom_update_dword_PARM_2
      0090AD 12 50 28         [24]  698 	lcall	_ak820_outline_0051
      0090B0 90 00 08         [24]  699 	mov	dptr,#0x0008
      0090B3 F5 F0            [12]  700 	mov	b,a
      0090B5 12 4F AC         [24]  701 	lcall	_eeprom_update_dword
                                    702 ;	quantum/eeconfig.c:63: eeprom_update_byte(EECONFIG_RGBLIGHT_EXTENDED, 0);
      0090B8 12 91 D4         [24]  703 	lcall	_ak820_outline_0101
      0090BB 90 00 24         [24]  704 	mov	dptr,#0x0024
      0090BE F5 F0            [12]  705 	mov	b,a
      0090C0 12 4F 0B         [24]  706 	lcall	_eeprom_update_byte
                                    707 ;	quantum/eeconfig.c:64: eeprom_update_byte(EECONFIG_VELOCIKEY, 0);
      0090C3 12 91 D4         [24]  708 	lcall	_ak820_outline_0101
      0090C6 90 00 17         [24]  709 	mov	dptr,#0x0017
      0090C9 F5 F0            [12]  710 	mov	b,a
      0090CB 12 4F 0B         [24]  711 	lcall	_eeprom_update_byte
                                    712 ;	quantum/eeconfig.c:65: eeprom_update_byte(EECONFIG_UNICODEMODE, 0);
      0090CE 12 91 D4         [24]  713 	lcall	_ak820_outline_0101
      0090D1 90 00 0C         [24]  714 	mov	dptr,#0x000c
      0090D4 F5 F0            [12]  715 	mov	b,a
      0090D6 12 4F 0B         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/eeconfig.c:66: eeprom_update_byte(EECONFIG_STENOMODE, 0);
      0090D9 12 91 D4         [24]  718 	lcall	_ak820_outline_0101
      0090DC 90 00 0D         [24]  719 	mov	dptr,#0x000d
      0090DF F5 F0            [12]  720 	mov	b,a
      0090E1 12 4F 0B         [24]  721 	lcall	_eeprom_update_byte
                                    722 ;	quantum/eeconfig.c:67: uint64_t dummy = 0;
      0090E4 90 0B 4B         [24]  723 	mov	dptr,#_eeconfig_init_quantum_dummy_10001_258
      0090E7 12 50 28         [24]  724 	lcall	_ak820_outline_0051
      0090EA A3               [24]  725 	inc	dptr
      0090EB F0               [24]  726 	movx	@dptr,a
      0090EC A3               [24]  727 	inc	dptr
      0090ED F0               [24]  728 	movx	@dptr,a
      0090EE A3               [24]  729 	inc	dptr
      0090EF F0               [24]  730 	movx	@dptr,a
      0090F0 A3               [24]  731 	inc	dptr
      0090F1 F0               [24]  732 	movx	@dptr,a
                                    733 ;	quantum/eeconfig.c:69: ak820_eeprom_update_block_xdata(&dummy, EECONFIG_RGB_MATRIX, sizeof(uint64_t));
      0090F2 90 05 95         [24]  734 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0090F5 12 58 25         [24]  735 	lcall	_ak820_outline_0087
      0090F8 90 05 98         [24]  736 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0090FB 74 08            [12]  737 	mov	a,#0x08
      0090FD 12 38 9C         [24]  738 	lcall	_ak820_outline_0134
      009100 90 0B 4B         [24]  739 	mov	dptr,#_eeconfig_init_quantum_dummy_10001_258
      009103 12 42 87         [24]  740 	lcall	_ak820_eeprom_update_block_xdata
                                    741 ;	quantum/eeconfig.c:73: eeprom_update_dword(EECONFIG_HAPTIC, 0);
      009106 90 06 AC         [24]  742 	mov	dptr,#_eeprom_update_dword_PARM_2
      009109 12 50 28         [24]  743 	lcall	_ak820_outline_0051
      00910C 90 00 20         [24]  744 	mov	dptr,#0x0020
      00910F F5 F0            [12]  745 	mov	b,a
      009111 12 4F AC         [24]  746 	lcall	_eeprom_update_dword
                                    747 ;	quantum/eeconfig.c:90: via_eeprom_set_valid(false);
      009114 75 82 00         [24]  748 	mov	dpl, #0x00
      009117 12 A7 36         [24]  749 	lcall	_via_eeprom_set_valid
                                    750 ;	quantum/eeconfig.c:91: eeconfig_init_via();
      00911A 12 A7 98         [24]  751 	lcall	_eeconfig_init_via
                                    752 ;	quantum/eeconfig.c:94: eeconfig_init_kb();
                                    753 ;	quantum/eeconfig.c:95: }
      00911D 02 90 48         [24]  754 	ljmp	_eeconfig_init_kb
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'eeconfig_init'
                                    757 ;------------------------------------------------------------
                                    758 ;	quantum/eeconfig.c:101: void eeconfig_init(void) {
                                    759 ;	-----------------------------------------
                                    760 ;	 function eeconfig_init
                                    761 ;	-----------------------------------------
      009120                        762 _eeconfig_init:
                                    763 ;	quantum/eeconfig.c:102: eeconfig_init_quantum();
                                    764 ;	quantum/eeconfig.c:103: }
      009120 02 90 51         [24]  765 	ljmp	_eeconfig_init_quantum
                                    766 ;------------------------------------------------------------
                                    767 ;Allocation info for local variables in function 'eeconfig_enable'
                                    768 ;------------------------------------------------------------
                                    769 ;	quantum/eeconfig.c:109: void eeconfig_enable(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function eeconfig_disable
                                    772 ;	-----------------------------------------
      009123                        773 _eeconfig_disable:
                                    774 ;	quantum/eeconfig.c:119: eeprom_driver_erase();
      009123 12 43 2B         [24]  775 	lcall	_eeprom_driver_erase
                                    776 ;	quantum/eeconfig.c:121: eeprom_update_word(EECONFIG_MAGIC, EECONFIG_MAGIC_NUMBER_OFF);
      009126 90 06 A7         [24]  777 	mov	dptr,#_eeprom_update_word_PARM_2
      009129 74 FF            [12]  778 	mov	a,#0xff
      00912B F0               [24]  779 	movx	@dptr,a
      00912C A3               [24]  780 	inc	dptr
      00912D F0               [24]  781 	movx	@dptr,a
      00912E 12 91 E9         [24]  782 	lcall	_ak820_outline_0153
                                    783 ;	quantum/eeconfig.c:122: }
      009131 02 4F 70         [24]  784 	ljmp	_eeprom_update_word
                                    785 ;------------------------------------------------------------
                                    786 ;Allocation info for local variables in function 'eeconfig_is_enabled'
                                    787 ;------------------------------------------------------------
                                    788 ;sloc0         Allocated with name '_eeconfig_is_enabled_sloc0_1_0'
                                    789 ;is_eeprom_enabled Allocated with name '_eeconfig_is_enabled_is_eeprom_enabled_10000_266'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/eeconfig.c:128: __xdata bool eeconfig_is_enabled(void) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function eeconfig_is_enabled
                                    794 ;	-----------------------------------------
      009134                        795 _eeconfig_is_enabled:
                                    796 ;	quantum/eeconfig.c:129: __xdata bool is_eeprom_enabled = (eeprom_read_word(EECONFIG_MAGIC) == EECONFIG_MAGIC_NUMBER);
      009134 12 91 E9         [24]  797 	lcall	_ak820_outline_0153
      009137 12 4E 5F         [24]  798 	lcall	_eeprom_read_word
      00913A 12 43 C5         [24]  799 	lcall	_ak820_outline_0133
      00913D E4               [12]  800 	clr	a
      00913E BE E6 04         [24]  801 	cjne	r6,#0xe6,00112$
      009141 BF FE 01         [24]  802 	cjne	r7,#0xfe,00112$
      009144 04               [12]  803 	inc	a
      009145                        804 00112$:
      009145 F5 34            [12]  805 	mov	_eeconfig_is_enabled_sloc0_1_0,a
      009147 90 0B 53         [24]  806 	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
      00914A F0               [24]  807 	movx	@dptr,a
                                    808 ;	quantum/eeconfig.c:131: if (is_eeprom_enabled) {
      00914B E5 34            [12]  809 	mov	a,_eeconfig_is_enabled_sloc0_1_0
      00914D 60 09            [24]  810 	jz	00102$
                                    811 ;	quantum/eeconfig.c:132: is_eeprom_enabled = via_eeprom_is_valid();
      00914F 12 A6 FE         [24]  812 	lcall	_via_eeprom_is_valid
      009152 E5 82            [12]  813 	mov	a, dpl
      009154 90 0B 53         [24]  814 	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
      009157 F0               [24]  815 	movx	@dptr,a
      009158                        816 00102$:
                                    817 ;	quantum/eeconfig.c:135: return is_eeprom_enabled;
      009158 90 0B 53         [24]  818 	mov	dptr,#_eeconfig_is_enabled_is_eeprom_enabled_10000_266
      00915B E0               [24]  819 	movx	a,@dptr
                                    820 ;	quantum/eeconfig.c:136: }
      00915C F5 82            [12]  821 	mov	dpl,a
      00915E 22               [24]  822 	ret
                                    823 ;------------------------------------------------------------
                                    824 ;Allocation info for local variables in function 'eeconfig_is_disabled'
                                    825 ;------------------------------------------------------------
                                    826 ;sloc0         Allocated with name '_eeconfig_is_disabled_sloc0_1_0'
                                    827 ;is_eeprom_disabled Allocated with name '_eeconfig_is_disabled_is_eeprom_disabled_10000_270'
                                    828 ;------------------------------------------------------------
                                    829 ;	quantum/eeconfig.c:142: __xdata bool eeconfig_is_disabled(void) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function eeconfig_read_debug
                                    832 ;	-----------------------------------------
      00915F                        833 _eeconfig_read_debug:
                                    834 ;	quantum/eeconfig.c:157: return eeprom_read_byte(EECONFIG_DEBUG);
      00915F 90 00 02         [24]  835 	mov	dptr,#0x0002
      009162 75 F0 00         [24]  836 	mov	b, #0x00
                                    837 ;	quantum/eeconfig.c:158: }
      009165 02 40 DD         [24]  838 	ljmp	_eeprom_read_byte
                                    839 ;------------------------------------------------------------
                                    840 ;Allocation info for local variables in function 'eeconfig_update_debug'
                                    841 ;------------------------------------------------------------
                                    842 ;val           Allocated with name '_eeconfig_update_debug_val_10000_275'
                                    843 ;------------------------------------------------------------
                                    844 ;	quantum/eeconfig.c:163: void eeconfig_update_debug(uint8_t val) {
                                    845 ;	-----------------------------------------
                                    846 ;	 function eeconfig_read_default_layer
                                    847 ;	-----------------------------------------
      009168                        848 _eeconfig_read_default_layer:
                                    849 ;	quantum/eeconfig.c:172: return eeprom_read_byte(EECONFIG_DEFAULT_LAYER);
      009168 90 00 03         [24]  850 	mov	dptr,#0x0003
      00916B 75 F0 00         [24]  851 	mov	b, #0x00
                                    852 ;	quantum/eeconfig.c:173: }
      00916E 02 40 DD         [24]  853 	ljmp	_eeprom_read_byte
                                    854 ;------------------------------------------------------------
                                    855 ;Allocation info for local variables in function 'eeconfig_update_default_layer'
                                    856 ;------------------------------------------------------------
                                    857 ;val           Allocated with name '_eeconfig_update_default_layer_val_10000_279'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/eeconfig.c:178: void eeconfig_update_default_layer(uint8_t val) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function eeconfig_read_keymap
                                    862 ;	-----------------------------------------
      009171                        863 _eeconfig_read_keymap:
                                    864 ;	quantum/eeconfig.c:187: return eeprom_read_word(EECONFIG_KEYMAP);
      009171 90 00 04         [24]  865 	mov	dptr,#0x0004
      009174 75 F0 00         [24]  866 	mov	b, #0x00
                                    867 ;	quantum/eeconfig.c:188: }
      009177 02 4E 5F         [24]  868 	ljmp	_eeprom_read_word
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'eeconfig_update_keymap'
                                    871 ;------------------------------------------------------------
                                    872 ;val           Allocated with name '_eeconfig_update_keymap_val_10000_283'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/eeconfig.c:193: void eeconfig_update_keymap(uint16_t val) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function eeconfig_update_kb
                                    877 ;	-----------------------------------------
      00917A                        878 _eeconfig_update_kb:
      00917A 12 91 DA         [24]  879 	lcall	_ak820_outline_0120
      00917D 90 0B 54         [24]  880 	mov	dptr,#_eeconfig_update_kb_val_10000_291
      009180 12 91 C8         [24]  881 	lcall	_ak820_outline_0046
                                    882 ;	quantum/eeconfig.c:225: eeprom_update_dword(EECONFIG_KEYBOARD, val);
      009183 90 0B 54         [24]  883 	mov	dptr,#_eeconfig_update_kb_val_10000_291
      009186 E0               [24]  884 	movx	a,@dptr
      009187 FC               [12]  885 	mov	r4,a
      009188 A3               [24]  886 	inc	dptr
      009189 12 50 17         [24]  887 	lcall	_ak820_outline_0013
      00918C 90 06 AC         [24]  888 	mov	dptr,#_eeprom_update_dword_PARM_2
      00918F 12 91 BC         [24]  889 	lcall	_ak820_outline_0006
      009192 90 00 0F         [24]  890 	mov	dptr,#0x000f
      009195 75 F0 00         [24]  891 	mov	b, #0x00
                                    892 ;	quantum/eeconfig.c:226: }
      009198 02 4F AC         [24]  893 	ljmp	_eeprom_update_dword
                                    894 ;------------------------------------------------------------
                                    895 ;Allocation info for local variables in function 'eeconfig_read_user'
                                    896 ;------------------------------------------------------------
                                    897 ;	quantum/eeconfig.c:234: uint32_t eeconfig_read_user(void) {
                                    898 ;	-----------------------------------------
                                    899 ;	 function eeconfig_update_user
                                    900 ;	-----------------------------------------
      00919B                        901 _eeconfig_update_user:
      00919B 12 91 DA         [24]  902 	lcall	_ak820_outline_0120
      00919E 90 0B 58         [24]  903 	mov	dptr,#_eeconfig_update_user_val_10000_295
      0091A1 12 91 C8         [24]  904 	lcall	_ak820_outline_0046
                                    905 ;	quantum/eeconfig.c:242: eeprom_update_dword(EECONFIG_USER, val);
      0091A4 90 0B 58         [24]  906 	mov	dptr,#_eeconfig_update_user_val_10000_295
      0091A7 E0               [24]  907 	movx	a,@dptr
      0091A8 FC               [12]  908 	mov	r4,a
      0091A9 A3               [24]  909 	inc	dptr
      0091AA 12 50 17         [24]  910 	lcall	_ak820_outline_0013
      0091AD 90 06 AC         [24]  911 	mov	dptr,#_eeprom_update_dword_PARM_2
      0091B0 12 91 BC         [24]  912 	lcall	_ak820_outline_0006
      0091B3 90 00 13         [24]  913 	mov	dptr,#0x0013
      0091B6 75 F0 00         [24]  914 	mov	b, #0x00
                                    915 ;	quantum/eeconfig.c:243: }
      0091B9 02 4F AC         [24]  916 	ljmp	_eeprom_update_dword
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'eeconfig_read_haptic'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/eeconfig.c:250: uint32_t eeconfig_read_haptic(void) {
                                    921 ;	-----------------------------------------
                                    922 	.area CSEG    (CODE)
                                    923 	.area CONST   (CODE)
                                    924 	.area XINIT   (CODE)
                                    925 	.area CABS    (ABS,CODE)
                                    926 
                                    927 ; Experimental exact instruction outlining.
                                    928 	.globl _ak820_outline_0006
                                    929 	.globl _ak820_outline_0013
                                    930 	.globl _ak820_outline_0046
                                    931 	.globl _ak820_outline_0051
                                    932 	.globl _ak820_outline_0087
                                    933 	.globl _ak820_outline_0101
                                    934 	.globl _ak820_outline_0120
                                    935 	.globl _ak820_outline_0133
                                    936 	.globl _ak820_outline_0134
                                    937 	.globl _ak820_outline_0152
                                    938 	.globl _ak820_outline_0153
                                    939 
                                    940 	.area CSEG (CODE)
                                    941 ; function ak820_outline_0006
      0091BC                        942 _ak820_outline_0006:
      0091BC EC               [12]  943 	mov	a,r4
      0091BD F0               [24]  944 	movx	@dptr,a
      0091BE ED               [12]  945 	mov	a,r5
      0091BF A3               [24]  946 	inc	dptr
      0091C0 F0               [24]  947 	movx	@dptr,a
      0091C1 EE               [12]  948 	mov	a,r6
      0091C2 A3               [24]  949 	inc	dptr
      0091C3 F0               [24]  950 	movx	@dptr,a
      0091C4 EF               [12]  951 	mov	a,r7
      0091C5 A3               [24]  952 	inc	dptr
      0091C6 F0               [24]  953 	movx	@dptr,a
      0091C7 22               [24]  954 	ret
                                    955 
                                    956 	.area CSEG (CODE)
                                    957 ; function ak820_outline_0046
      0091C8                        958 _ak820_outline_0046:
      0091C8 EF               [12]  959 	mov	a,r7
      0091C9 F0               [24]  960 	movx	@dptr,a
      0091CA EE               [12]  961 	mov	a,r6
      0091CB A3               [24]  962 	inc	dptr
      0091CC F0               [24]  963 	movx	@dptr,a
      0091CD ED               [12]  964 	mov	a,r5
      0091CE A3               [24]  965 	inc	dptr
      0091CF F0               [24]  966 	movx	@dptr,a
      0091D0 EC               [12]  967 	mov	a,r4
      0091D1 A3               [24]  968 	inc	dptr
      0091D2 F0               [24]  969 	movx	@dptr,a
      0091D3 22               [24]  970 	ret
                                    971 
                                    972 	.area CSEG (CODE)
                                    973 ; function ak820_outline_0101
      0091D4                        974 _ak820_outline_0101:
      0091D4 90 06 A3         [24]  975 	mov	dptr,#_eeprom_update_byte_PARM_2
      0091D7 E4               [12]  976 	clr	a
      0091D8 F0               [24]  977 	movx	@dptr,a
      0091D9 22               [24]  978 	ret
                                    979 
                                    980 	.area CSEG (CODE)
                                    981 ; function ak820_outline_0120
      0091DA                        982 _ak820_outline_0120:
      0091DA AF 82            [24]  983 	mov	r7,dpl
      0091DC AE 83            [24]  984 	mov	r6,dph
      0091DE AD F0            [24]  985 	mov	r5,b
      0091E0 FC               [12]  986 	mov	r4,a
      0091E1 22               [24]  987 	ret
                                    988 
                                    989 	.area CSEG (CODE)
                                    990 ; function ak820_outline_0152
      0091E2                        991 _ak820_outline_0152:
      0091E2 90 00 00         [24]  992 	mov	dptr,#0x0000
      0091E5 E4               [12]  993 	clr	a
      0091E6 F5 F0            [12]  994 	mov	b,a
      0091E8 22               [24]  995 	ret
                                    996 
                                    997 	.area CSEG (CODE)
                                    998 ; function ak820_outline_0153
      0091E9                        999 _ak820_outline_0153:
      0091E9 90 00 00         [24] 1000 	mov	dptr,#0x0000
      0091EC 75 F0 00         [24] 1001 	mov	b,#0x00
      0091EF 22               [24] 1002 	ret
