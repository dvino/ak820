                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000817                        616 _tp_buttons::
      000817                        617 	.ds 2
      000819                        618 _action_exec_PARM_1:
      000819                        619 	.ds 6
      00081F                        620 _action_exec_record_10001_624:
      00081F                        621 	.ds 9
      000828                        622 _ak820_action_exec_event_10000_628:
      000828                        623 	.ds 2
      00082A                        624 _ak820_action_exec_snapshot_10000_629:
      00082A                        625 	.ds 6
      000830                        626 _process_record_record_10000_632:
      000830                        627 	.ds 3
      000833                        628 _process_record_handler_record_argument_10000_640:
      000833                        629 	.ds 3
      000836                        630 _process_record_handler_action_10000_641:
      000836                        631 	.ds 2
      000838                        632 _process_action_PARM_2:
      000838                        633 	.ds 2
      00083A                        634 _process_action_record_argument_10000_652:
      00083A                        635 	.ds 3
      00083D                        636 _process_action_on_40000_675:
      00083D                        637 	.ds 1
      00083E                        638 _register_code_code_10000_709:
      00083E                        639 	.ds 1
      00083F                        640 _unregister_code_code_10000_723:
      00083F                        641 	.ds 1
      000840                        642 _tap_code_delay_PARM_2:
      000840                        643 	.ds 2
      000842                        644 _tap_code_delay_code_10000_736:
      000842                        645 	.ds 1
      000843                        646 _tap_code_code_10000_743:
      000843                        647 	.ds 1
      000844                        648 _register_mods_mods_10000_745:
      000844                        649 	.ds 1
      000845                        650 _unregister_mods_mods_10000_749:
      000845                        651 	.ds 1
      000846                        652 _register_weak_mods_mods_10000_753:
      000846                        653 	.ds 1
      000847                        654 _unregister_weak_mods_mods_10000_757:
      000847                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC6                        664 _disable_action_cache::
      000DC6                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      007209                        709 _action_exec:
                                    710 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      007209 90 08 1B         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00720C 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      00720F 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      007212 90 08 19         [24]  715 	mov	dptr,#_action_exec_PARM_1
      007215 12 45 81         [24]  716 	lcall	_ak820_tapping_before
      007218 E5 82            [12]  717 	mov	a, dpl
      00721A 70 01            [24]  718 	jnz	00102$
      00721C 22               [24]  719 	ret
      00721D                        720 00102$:
                                    721 ;	quantum/action.c:116: if (event.pressed) {
      00721D 90 08 1E         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007220 E0               [24]  723 	movx	a,@dptr
      007221 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:118: clear_weak_mods();
      007223 12 82 64         [24]  726 	lcall	_clear_weak_mods
      007226                        727 00104$:
                                    728 ;	quantum/action.c:130: record.event = event;
      007226 90 0D A6         [24]  729 	mov	dptr,#___memcpy_PARM_2
      007229 74 19            [12]  730 	mov	a,#_action_exec_PARM_1
      00722B F0               [24]  731 	movx	@dptr,a
      00722C 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      00722E 12 38 70         [24]  733 	lcall	_ak820_outline_0094
      007231 12 78 D8         [24]  734 	lcall	_ak820_outline_0071
      007234 90 08 1F         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      007237 F5 F0            [12]  736 	mov	b,a
      007239 12 B9 9B         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:132: record.tap.count = 0;
      00723C 90 08 25         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      00723F E0               [24]  740 	movx	a,@dptr
      007240 54 0F            [12]  741 	anl	a,#0x0f
      007242 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:137: record.keycode = 0;
      007243 90 08 26         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      007246 12 50 6A         [24]  745 	lcall	_ak820_outline_0182
                                    746 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007249 90 08 23         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      00724C E0               [24]  748 	movx	a,@dptr
      00724D 60 0D            [24]  749 	jz	00107$
      00724F 90 08 1F         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      007252 75 F0 00         [24]  751 	mov	b, #0x00
      007255 12 A0 43         [24]  752 	lcall	_pre_process_record_quantum
      007258 E5 82            [12]  753 	mov	a, dpl
      00725A 60 14            [24]  754 	jz	00110$
      00725C                        755 00107$:
                                    756 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      00725C 90 08 1F         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      00725F 12 46 68         [24]  758 	lcall	_ak820_tapping_process
      007262 E5 82            [12]  759 	mov	a, dpl
      007264 70 01            [24]  760 	jnz	00106$
      007266 22               [24]  761 	ret
      007267                        762 00106$:
                                    763 ;	quantum/action.c:175: process_record(&record);
      007267 90 08 1F         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      00726A 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:190: }
      00726D 02 72 AD         [24]  767 	ljmp	_process_record
      007270                        768 00110$:
      007270 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      007271                        780 _ak820_action_exec:
      007271 12 38 82         [24]  781 	lcall	_ak820_outline_0107
      007274 90 08 28         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      007277 12 38 87         [24]  783 	lcall	_ak820_outline_0108
                                    784 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      00727A 90 08 28         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      00727D 12 38 64         [24]  786 	lcall	_ak820_outline_0080
      007280 7F 00            [12]  787 	mov	r7,#0x00
      007282 90 0D A6         [24]  788 	mov	dptr,#___memcpy_PARM_2
      007285 ED               [12]  789 	mov	a,r5
      007286 12 38 29         [24]  790 	lcall	_ak820_outline_0018
      007289 12 78 D8         [24]  791 	lcall	_ak820_outline_0071
      00728C 90 08 2A         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      00728F F5 F0            [12]  793 	mov	b,a
      007291 12 B9 9B         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:197: action_exec(snapshot);
      007294 90 0D A6         [24]  796 	mov	dptr,#___memcpy_PARM_2
      007297 74 2A            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      007299 F0               [24]  798 	movx	@dptr,a
      00729A 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      00729C 12 38 70         [24]  800 	lcall	_ak820_outline_0094
      00729F 12 78 D8         [24]  801 	lcall	_ak820_outline_0071
      0072A2 90 08 19         [24]  802 	mov	dptr,#_action_exec_PARM_1
      0072A5 F5 F0            [12]  803 	mov	b,a
      0072A7 12 B9 9B         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:198: }
      0072AA 02 72 09         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      0072AD                        816 _process_record:
      0072AD 12 43 7C         [24]  817 	lcall	_ak820_outline_0038
      0072B0 90 08 30         [24]  818 	mov	dptr,#_process_record_record_10000_632
      0072B3 12 38 29         [24]  819 	lcall	_ak820_outline_0018
                                    820 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      0072B6 90 08 30         [24]  821 	mov	dptr,#_process_record_record_10000_632
      0072B9 12 50 17         [24]  822 	lcall	_ak820_outline_0013
      0072BC 74 04            [12]  823 	mov	a,#0x04
      0072BE 12 78 AB         [24]  824 	lcall	_ak820_outline_0015
      0072C1 12 BA 74         [24]  825 	lcall	__gptrget
      0072C4 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:338: return;
      0072C6 22               [24]  828 	ret
      0072C7                        829 00102$:
                                    830 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0072C7 8D 02            [24]  831 	mov	ar2,r5
      0072C9 8E 03            [24]  832 	mov	ar3,r6
      0072CB 8F 04            [24]  833 	mov	ar4,r7
      0072CD 90 0D A6         [24]  834 	mov	dptr,#___memcpy_PARM_2
      0072D0 EA               [12]  835 	mov	a,r2
      0072D1 12 79 1F         [24]  836 	lcall	_ak820_outline_0187
      0072D4 EC               [12]  837 	mov	a,r4
      0072D5 A3               [24]  838 	inc	dptr
      0072D6 F0               [24]  839 	movx	@dptr,a
      0072D7 90 0D A9         [24]  840 	mov	dptr,#___memcpy_PARM_3
      0072DA 12 50 5C         [24]  841 	lcall	_ak820_outline_0110
      0072DD 90 06 2C         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      0072E0 F5 F0            [12]  843 	mov	b,a
      0072E2 C0 07            [24]  844 	push	ar7
      0072E4 C0 06            [24]  845 	push	ar6
      0072E6 C0 05            [24]  846 	push	ar5
      0072E8 12 B9 9B         [24]  847 	lcall	___memcpy
      0072EB 12 44 BB         [24]  848 	lcall	_ak820_tapping_source
      0072EE AC 82            [24]  849 	mov	r4, dpl
      0072F0 D0 05            [24]  850 	pop	ar5
      0072F2 D0 06            [24]  851 	pop	ar6
      0072F4 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0072F6 74 05            [12]  854 	mov	a,#0x05
      0072F8 12 78 9D         [24]  855 	lcall	_ak820_outline_0014
      0072FB 12 BA 74         [24]  856 	lcall	__gptrget
      0072FE FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      0072FF 12 79 04         [24]  859 	lcall	_ak820_outline_0146
      007302 90 0B FD         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      007305 74 01            [12]  861 	mov	a,#0x01
      007307 12 50 20         [24]  862 	lcall	_ak820_outline_0035
      00730A C0 04            [24]  863 	push	ar4
      00730C C0 03            [24]  864 	push	ar3
      00730E C0 02            [24]  865 	push	ar2
      007310 C0 01            [24]  866 	push	ar1
      007312 C0 00            [24]  867 	push	ar0
      007314 12 A0 06         [24]  868 	lcall	_get_record_keycode
      007317 12 43 C5         [24]  869 	lcall	_ak820_outline_0133
      00731A D0 00            [24]  870 	pop	ar0
      00731C D0 01            [24]  871 	pop	ar1
      00731E D0 02            [24]  872 	pop	ar2
      007320 D0 03            [24]  873 	pop	ar3
      007322 D0 04            [24]  874 	pop	ar4
      007324 12 49 E0         [24]  875 	lcall	_ak820_outline_0112
      007327 EE               [12]  876 	mov	a,r6
      007328 12 BA 39         [24]  877 	lcall	__gptrput
      00732B A3               [24]  878 	inc	dptr
      00732C EF               [12]  879 	mov	a,r7
      00732D 12 BA 39         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007330 90 08 30         [24]  882 	mov	dptr,#_process_record_record_10000_632
      007333 12 50 17         [24]  883 	lcall	_ak820_outline_0013
      007336 12 79 04         [24]  884 	lcall	_ak820_outline_0146
      007339 12 49 E0         [24]  885 	lcall	_ak820_outline_0112
      00733C 12 BA 74         [24]  886 	lcall	__gptrget
      00733F F8               [12]  887 	mov	r0,a
      007340 A3               [24]  888 	inc	dptr
      007341 12 BA 74         [24]  889 	lcall	__gptrget
      007344 F9               [12]  890 	mov	r1,a
      007345 90 06 3C         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007348 EC               [12]  892 	mov	a,r4
      007349 F0               [24]  893 	movx	@dptr,a
      00734A 90 06 3D         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00734D EB               [12]  895 	mov	a,r3
      00734E F0               [24]  896 	movx	@dptr,a
      00734F 12 38 B6         [24]  897 	lcall	_ak820_outline_0157
      007352 C0 07            [24]  898 	push	ar7
      007354 C0 06            [24]  899 	push	ar6
      007356 C0 05            [24]  900 	push	ar5
      007358 C0 04            [24]  901 	push	ar4
      00735A C0 03            [24]  902 	push	ar3
      00735C 12 48 1A         [24]  903 	lcall	_ak820_oneshot_process
      00735F E5 82            [12]  904 	mov	a, dpl
      007361 D0 03            [24]  905 	pop	ar3
      007363 D0 04            [24]  906 	pop	ar4
      007365 D0 05            [24]  907 	pop	ar5
      007367 D0 06            [24]  908 	pop	ar6
      007369 D0 07            [24]  909 	pop	ar7
      00736B 70 01            [24]  910 	jnz	00104$
      00736D 22               [24]  911 	ret
      00736E                        912 00104$:
                                    913 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      00736E 12 6F 6D         [24]  914 	lcall	_ak820_outline_0058
      007371 C0 04            [24]  915 	push	ar4
      007373 C0 03            [24]  916 	push	ar3
      007375 12 A0 CF         [24]  917 	lcall	_process_record_quantum
      007378 E5 82            [12]  918 	mov	a, dpl
      00737A D0 03            [24]  919 	pop	ar3
      00737C D0 04            [24]  920 	pop	ar4
      00737E 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007380 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007383 EB               [12]  924 	mov	a,r3
      007384 F0               [24]  925 	movx	@dptr,a
      007385 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:360: return;
      007387 02 2E 6F         [24]  928 	ljmp	_ak820_oneshot_post
      00738A                        929 00106$:
                                    930 ;	quantum/action.c:366: process_record_handler(record);
      00738A 90 08 30         [24]  931 	mov	dptr,#_process_record_record_10000_632
      00738D 12 4F F1         [24]  932 	lcall	_ak820_outline_0001
      007390 C0 04            [24]  933 	push	ar4
      007392 C0 03            [24]  934 	push	ar3
      007394 12 73 AE         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:370: post_process_record_quantum(record);
      007397 90 08 30         [24]  937 	mov	dptr,#_process_record_record_10000_632
      00739A 12 4F F1         [24]  938 	lcall	_ak820_outline_0001
      00739D 12 A0 A4         [24]  939 	lcall	_post_process_record_quantum
      0073A0 D0 03            [24]  940 	pop	ar3
      0073A2 D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073A4 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073A7 EB               [12]  944 	mov	a,r3
      0073A8 F0               [24]  945 	movx	@dptr,a
      0073A9 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:374: }
      0073AB 02 2E 6F         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      0073AE                        960 _process_record_handler:
      0073AE 12 43 7C         [24]  961 	lcall	_ak820_outline_0038
      0073B1 90 08 33         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0073B4 12 38 29         [24]  963 	lcall	_ak820_outline_0018
                                    964 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073B7 90 08 33         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0073BA 12 37 FE         [24]  966 	lcall	_ak820_outline_0008
                                    967 ;	quantum/action.c:387: if (record->keycode) {
      0073BD 4C               [12]  968 	orl	a,r4
      0073BE 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      0073C0 12 38 97         [24]  971 	lcall	_ak820_outline_0124
      0073C3 C0 07            [24]  972 	push	ar7
      0073C5 C0 06            [24]  973 	push	ar6
      0073C7 12 96 43         [24]  974 	lcall	_action_for_keycode
      0073CA 12 43 D6         [24]  975 	lcall	_ak820_outline_0149
      0073CD D0 06            [24]  976 	pop	ar6
      0073CF D0 07            [24]  977 	pop	ar7
      0073D1 90 08 36         [24]  978 	mov	dptr,#_process_record_handler_action_10000_641
      0073D4 12 38 5E         [24]  979 	lcall	_ak820_outline_0073
      0073D7 80 2A            [24]  980 	sjmp	00104$
      0073D9                        981 00102$:
                                    982 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0073D9 12 78 B9         [24]  983 	lcall	_ak820_outline_0022
      0073DC 7A 00            [12]  984 	mov	r2,#0x00
      0073DE 12 43 D0         [24]  985 	lcall	_ak820_outline_0142
      0073E1 12 43 6A         [24]  986 	lcall	_ak820_outline_0012
      0073E4 E0               [24]  987 	movx	a,@dptr
      0073E5 90 09 72         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      0073E8 F0               [24]  989 	movx	@dptr,a
      0073E9 12 43 F6         [24]  990 	lcall	_ak820_outline_0189
      0073EC C0 07            [24]  991 	push	ar7
      0073EE C0 06            [24]  992 	push	ar6
      0073F0 12 7C 60         [24]  993 	lcall	_ak820_resolve_key
      0073F3 12 96 43         [24]  994 	lcall	_action_for_keycode
      0073F6 12 43 D6         [24]  995 	lcall	_ak820_outline_0149
      0073F9 D0 06            [24]  996 	pop	ar6
      0073FB D0 07            [24]  997 	pop	ar7
      0073FD 90 08 36         [24]  998 	mov	dptr,#_process_record_handler_action_10000_641
      007400 12 38 5E         [24]  999 	lcall	_ak820_outline_0073
                                   1000 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007403                       1001 00104$:
                                   1002 ;	quantum/action.c:411: process_action(record, action);
      007403 7D 00            [12] 1003 	mov	r5,#0x00
      007405 90 0D A6         [24] 1004 	mov	dptr,#___memcpy_PARM_2
      007408 74 36            [12] 1005 	mov	a,#_process_record_handler_action_10000_641
      00740A F0               [24] 1006 	movx	@dptr,a
      00740B 74 08            [12] 1007 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      00740D 12 38 70         [24] 1008 	lcall	_ak820_outline_0094
      007410 90 0D A9         [24] 1009 	mov	dptr,#___memcpy_PARM_3
      007413 12 50 5C         [24] 1010 	lcall	_ak820_outline_0110
      007416 90 08 38         [24] 1011 	mov	dptr,#_process_action_PARM_2
      007419 F5 F0            [12] 1012 	mov	b,a
      00741B C0 07            [24] 1013 	push	ar7
      00741D C0 06            [24] 1014 	push	ar6
      00741F C0 05            [24] 1015 	push	ar5
      007421 12 B9 9B         [24] 1016 	lcall	___memcpy
      007424 D0 05            [24] 1017 	pop	ar5
      007426 D0 06            [24] 1018 	pop	ar6
      007428 D0 07            [24] 1019 	pop	ar7
      00742A 12 71 81         [24] 1020 	lcall	_ak820_outline_0065
                                   1021 ;	quantum/action.c:412: }
      00742D 02 74 30         [24] 1022 	ljmp	_process_action
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'register_mouse'
                                   1025 ;------------------------------------------------------------
                                   1026 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1027 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function process_action
                                   1032 ;	-----------------------------------------
      007430                       1033 _process_action:
      007430 12 43 7C         [24] 1034 	lcall	_ak820_outline_0038
      007433 90 08 3A         [24] 1035 	mov	dptr,#_process_action_record_argument_10000_652
      007436 12 38 29         [24] 1036 	lcall	_ak820_outline_0018
                                   1037 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007439 90 08 3A         [24] 1038 	mov	dptr,#_process_action_record_argument_10000_652
      00743C 12 37 F4         [24] 1039 	lcall	_ak820_outline_0005
                                   1040 ;	quantum/action.c:483: pressed = record->event.pressed;
      00743F A3               [24] 1041 	inc	dptr
      007440 A3               [24] 1042 	inc	dptr
      007441 A3               [24] 1043 	inc	dptr
      007442 A3               [24] 1044 	inc	dptr
      007443 A3               [24] 1045 	inc	dptr
      007444 E0               [24] 1046 	movx	a,@dptr
      007445 F5 27            [12] 1047 	mov	_process_action_sloc0_1_0,a
                                   1048 ;	quantum/action.c:507: switch (action.kind.id) {
      007447 90 08 39         [24] 1049 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00744A E0               [24] 1050 	movx	a,@dptr
      00744B C4               [12] 1051 	swap	a
      00744C 54 0F            [12] 1052 	anl	a,#0x0f
      00744E FD               [12] 1053 	mov  r5,a
      00744F 24 F4            [12] 1054 	add	a,#0xff - 0x0b
      007451 50 03            [24] 1055 	jnc	00434$
      007453 02 76 D1         [24] 1056 	ljmp	00181$
      007456                       1057 00434$:
                                   1058 ;	free result
      007456 ED               [12] 1059 	mov	a,r5
      007457 24 0A            [12] 1060 	add	a,#(00435$-3-.)
      007459 83               [24] 1061 	movc	a,@a+pc
      00745A F5 82            [12] 1062 	mov	dpl,a
      00745C ED               [12] 1063 	mov	a,r5
      00745D 24 10            [12] 1064 	add	a,#(00436$-3-.)
      00745F 83               [24] 1065 	movc	a,@a+pc
      007460 F5 83            [12] 1066 	mov	dph,a
      007462 E4               [12] 1067 	clr	a
      007463 73               [24] 1068 	jmp	@a+dptr
      007464                       1069 00435$:
      007464 7C                    1070 	.db	00102$
      007465 7C                    1071 	.db	00102$
      007466 D1                    1072 	.db	00181$
      007467 D1                    1073 	.db	00181$
      007468 06                    1074 	.db	00123$
      007469 D1                    1075 	.db	00181$
      00746A D1                    1076 	.db	00181$
      00746B D1                    1077 	.db	00181$
      00746C 66                    1078 	.db	00131$
      00746D 38                    1079 	.db	00147$
      00746E 5E                    1080 	.db	00152$
      00746F 5E                    1081 	.db	00152$
      007470                       1082 00436$:
      007470 74                    1083 	.db	00102$>>8
      007471 74                    1084 	.db	00102$>>8
      007472 76                    1085 	.db	00181$>>8
      007473 76                    1086 	.db	00181$>>8
      007474 75                    1087 	.db	00123$>>8
      007475 76                    1088 	.db	00181$>>8
      007476 76                    1089 	.db	00181$>>8
      007477 76                    1090 	.db	00181$>>8
      007478 75                    1091 	.db	00131$>>8
      007479 76                    1092 	.db	00147$>>8
      00747A 76                    1093 	.db	00152$>>8
      00747B 76                    1094 	.db	00152$>>8
                                   1095 ;	quantum/action.c:510: case ACT_RMODS: {
      00747C                       1096 00102$:
                                   1097 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00747C 90 08 39         [24] 1098 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00747F E0               [24] 1099 	movx	a,@dptr
      007480 54 F0            [12] 1100 	anl	a,#0xf0
      007482 70 06            [24] 1101 	jnz	00194$
      007484 12 78 F2         [24] 1102 	lcall	_ak820_outline_0113
      007487 FD               [12] 1103 	mov	r5,a
      007488 80 07            [24] 1104 	sjmp	00195$
      00748A                       1105 00194$:
      00748A 12 78 F2         [24] 1106 	lcall	_ak820_outline_0113
      00748D C4               [12] 1107 	swap	a
      00748E 54 F0            [12] 1108 	anl	a,#0xf0
      007490 FD               [12] 1109 	mov	r5,a
      007491                       1110 00195$:
                                   1111 ;	quantum/action.c:513: if (pressed) {
      007491 E5 27            [12] 1112 	mov	a,_process_action_sloc0_1_0
      007493 60 35            [24] 1113 	jz	00119$
                                   1114 ;	quantum/action.c:514: if (mods) {
      007495 ED               [12] 1115 	mov	a,r5
      007496 60 29            [24] 1116 	jz	00110$
                                   1117 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007498 12 79 0E         [24] 1118 	lcall	_ak820_outline_0159
      00749B FC               [12] 1119 	mov	r4,a
      00749C BC E0 00         [24] 1120 	cjne	r4,#0xe0,00440$
      00749F                       1121 00440$:
      00749F 40 07            [24] 1122 	jc	00108$
      0074A1 12 79 0E         [24] 1123 	lcall	_ak820_outline_0159
      0074A4 24 18            [12] 1124 	add	a,#0xff - 0xe7
      0074A6 50 0A            [24] 1125 	jnc	00104$
                                   1126 ;	free result
      0074A8                       1127 00108$:
      0074A8 7B 38            [12] 1128 	mov	r3,#_process_action_PARM_2
      0074AA 7C 08            [12] 1129 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074AC 12 33 FC         [24] 1130 	lcall	_ak820_outline_0121
      0074AF E0               [24] 1131 	movx	a,@dptr
      0074B0 70 07            [24] 1132 	jnz	00105$
      0074B2                       1133 00104$:
                                   1134 ;	quantum/action.c:519: add_owned_mods(mods);
      0074B2 8D 82            [24] 1135 	mov	dpl, r5
      0074B4 12 7E 7A         [24] 1136 	lcall	_add_owned_mods
      0074B7 80 05            [24] 1137 	sjmp	00106$
      0074B9                       1138 00105$:
                                   1139 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0074B9 8D 82            [24] 1140 	mov	dpl, r5
      0074BB 12 7E 99         [24] 1141 	lcall	_add_owned_weak_mods
      0074BE                       1142 00106$:
                                   1143 ;	quantum/action.c:523: send_keyboard_report();
      0074BE 12 81 B4         [24] 1144 	lcall	_send_keyboard_report
      0074C1                       1145 00110$:
                                   1146 ;	quantum/action.c:525: register_code(action.key.code);
      0074C1 12 78 E2         [24] 1147 	lcall	_ak820_outline_0079
      0074C4 12 76 E8         [24] 1148 	lcall	_register_code
      0074C7 02 76 D1         [24] 1149 	ljmp	00181$
      0074CA                       1150 00119$:
                                   1151 ;	quantum/action.c:527: unregister_code(action.key.code);
      0074CA 12 78 E2         [24] 1152 	lcall	_ak820_outline_0079
      0074CD C0 05            [24] 1153 	push	ar5
      0074CF 12 77 55         [24] 1154 	lcall	_unregister_code
      0074D2 D0 05            [24] 1155 	pop	ar5
                                   1156 ;	quantum/action.c:528: if (mods) {
      0074D4 ED               [12] 1157 	mov	a,r5
      0074D5 70 03            [24] 1158 	jnz	00444$
      0074D7 02 76 D1         [24] 1159 	ljmp	00181$
      0074DA                       1160 00444$:
                                   1161 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074DA 12 79 0E         [24] 1162 	lcall	_ak820_outline_0159
      0074DD FC               [12] 1163 	mov	r4,a
      0074DE BC E0 00         [24] 1164 	cjne	r4,#0xe0,00445$
      0074E1                       1165 00445$:
      0074E1 40 07            [24] 1166 	jc	00115$
      0074E3 12 79 0E         [24] 1167 	lcall	_ak820_outline_0159
      0074E6 24 18            [12] 1168 	add	a,#0xff - 0xe7
      0074E8 50 0A            [24] 1169 	jnc	00111$
                                   1170 ;	free result
      0074EA                       1171 00115$:
      0074EA 7B 38            [12] 1172 	mov	r3,#_process_action_PARM_2
      0074EC 7C 08            [12] 1173 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074EE 12 33 FC         [24] 1174 	lcall	_ak820_outline_0121
      0074F1 E0               [24] 1175 	movx	a,@dptr
      0074F2 70 07            [24] 1176 	jnz	00112$
      0074F4                       1177 00111$:
                                   1178 ;	quantum/action.c:530: del_owned_mods(mods);
      0074F4 8D 82            [24] 1179 	mov	dpl, r5
      0074F6 12 7E 8A         [24] 1180 	lcall	_del_owned_mods
      0074F9 80 05            [24] 1181 	sjmp	00113$
      0074FB                       1182 00112$:
                                   1183 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      0074FB 8D 82            [24] 1184 	mov	dpl, r5
      0074FD 12 7E A9         [24] 1185 	lcall	_del_owned_weak_mods
      007500                       1186 00113$:
                                   1187 ;	quantum/action.c:534: send_keyboard_report();
      007500 12 81 B4         [24] 1188 	lcall	_send_keyboard_report
                                   1189 ;	quantum/action.c:537: } break;
      007503 02 76 D1         [24] 1190 	ljmp	00181$
                                   1191 ;	quantum/action.c:614: case ACT_USAGE:
      007506                       1192 00123$:
                                   1193 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007506 74 07            [12] 1194 	mov	a,#0x07
      007508 12 38 31         [24] 1195 	lcall	_ak820_outline_0023
      00750B 12 49 54         [24] 1196 	lcall	_ak820_outline_0009
      00750E C3               [12] 1197 	clr	c
      00750F EC               [12] 1198 	mov	a,r4
      007510 94 A5            [12] 1199 	subb	a,#0xa5
      007512 ED               [12] 1200 	mov	a,r5
      007513 94 00            [12] 1201 	subb	a,#0x00
      007515 40 15            [24] 1202 	jc	00125$
      007517 74 C2            [12] 1203 	mov	a,#0xc2
      007519 9C               [12] 1204 	subb	a,r4
      00751A E4               [12] 1205 	clr	a
      00751B 9D               [12] 1206 	subb	a,r5
      00751C 40 0E            [24] 1207 	jc	00125$
                                   1208 ;	free result
                                   1209 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      00751E 90 0A 99         [24] 1210 	mov	dptr,#_owned_usage_key_PARM_2
      007521 E5 27            [12] 1211 	mov	a,_process_action_sloc0_1_0
      007523 F0               [24] 1212 	movx	@dptr,a
      007524 8E 82            [24] 1213 	mov	dpl, r6
      007526 12 80 5F         [24] 1214 	lcall	_owned_usage_key
                                   1215 ;	quantum/action.c:622: break;
      007529 02 76 D1         [24] 1216 	ljmp	00181$
      00752C                       1217 00125$:
                                   1218 ;	quantum/action.c:625: switch (action.usage.page) {
      00752C 12 78 E9         [24] 1219 	lcall	_ak820_outline_0090
      00752F FF               [12] 1220 	mov	r7,a
      007530 60 08            [24] 1221 	jz	00127$
      007532 BF 01 02         [24] 1222 	cjne	r7,#0x01,00452$
      007535 80 19            [24] 1223 	sjmp	00128$
      007537                       1224 00452$:
      007537 02 76 D1         [24] 1225 	ljmp	00181$
                                   1226 ;	quantum/action.c:626: case PAGE_SYSTEM:
      00753A                       1227 00127$:
                                   1228 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      00753A E5 27            [12] 1229 	mov	a,_process_action_sloc0_1_0
      00753C 60 05            [24] 1230 	jz	00196$
      00753E 12 78 F9         [24] 1231 	lcall	_ak820_outline_0130
      007541 80 04            [24] 1232 	sjmp	00197$
      007543                       1233 00196$:
      007543 7E 00            [12] 1234 	mov	r6,#0x00
      007545 7F 00            [12] 1235 	mov	r7,#0x00
      007547                       1236 00197$:
      007547 12 38 8C         [24] 1237 	lcall	_ak820_outline_0118
      00754A 12 6E F7         [24] 1238 	lcall	_host_system_send
                                   1239 ;	quantum/action.c:628: break;
      00754D 02 76 D1         [24] 1240 	ljmp	00181$
                                   1241 ;	quantum/action.c:629: case PAGE_CONSUMER:
      007550                       1242 00128$:
                                   1243 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      007550 E5 27            [12] 1244 	mov	a,_process_action_sloc0_1_0
      007552 60 05            [24] 1245 	jz	00198$
      007554 12 78 F9         [24] 1246 	lcall	_ak820_outline_0130
      007557 80 04            [24] 1247 	sjmp	00199$
      007559                       1248 00198$:
      007559 7E 00            [12] 1249 	mov	r6,#0x00
      00755B 7F 00            [12] 1250 	mov	r7,#0x00
      00755D                       1251 00199$:
      00755D 12 38 8C         [24] 1252 	lcall	_ak820_outline_0118
      007560 12 6F 27         [24] 1253 	lcall	_host_consumer_send
                                   1254 ;	quantum/action.c:633: break;
      007563 02 76 D1         [24] 1255 	ljmp	00181$
                                   1256 ;	quantum/action.c:640: case ACT_LAYER: {
      007566                       1257 00131$:
                                   1258 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      007566 90 08 39         [24] 1259 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007569 E0               [24] 1260 	movx	a,@dptr
      00756A 54 03            [12] 1261 	anl	a,#0x03
      00756C 90 08 3D         [24] 1262 	mov	dptr,#_process_action_on_40000_675
      00756F F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007570 E0               [24] 1265 	movx	a,@dptr
      007571 FF               [12] 1266 	mov	r7,a
      007572 60 11            [24] 1267 	jz	00200$
      007574 E5 27            [12] 1268 	mov	a,_process_action_sloc0_1_0
      007576 60 07            [24] 1269 	jz	00202$
      007578 8F 06            [24] 1270 	mov	ar6,r7
      00757A 53 06 01         [24] 1271 	anl	ar6,#0x01
      00757D 80 10            [24] 1272 	sjmp	00201$
      00757F                       1273 00202$:
      00757F 74 02            [12] 1274 	mov	a,#0x02
      007581 5F               [12] 1275 	anl	a,r7
      007582 FE               [12] 1276 	mov	r6,a
      007583 80 0A            [24] 1277 	sjmp	00201$
      007585                       1278 00200$:
      007585 E5 27            [12] 1279 	mov	a,_process_action_sloc0_1_0
      007587 B4 01 00         [24] 1280 	cjne	a,#0x01,00457$
      00758A                       1281 00457$:
      00758A 92 1F            [24] 1282 	mov  _process_action_sloc1_1_0,c
      00758C E4               [12] 1283 	clr	a
      00758D 33               [12] 1284 	rlc	a
      00758E FE               [12] 1285 	mov	r6,a
      00758F                       1286 00201$:
      00758F EE               [12] 1287 	mov	a,r6
      007590 70 03            [24] 1288 	jnz	00458$
      007592 02 76 D1         [24] 1289 	ljmp	00181$
      007595                       1290 00458$:
                                   1291 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      007595 12 79 0E         [24] 1292 	lcall	_ak820_outline_0159
      007598 C4               [12] 1293 	swap	a
      007599 03               [12] 1294 	rr	a
      00759A 54 07            [12] 1295 	anl	a,#0x07
      00759C 25 E0            [12] 1296 	add	a,acc
      00759E 25 E0            [12] 1297 	add	a,acc
      0075A0 FF               [12] 1298 	mov	r7,a
                                   1299 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0075A1 12 79 0E         [24] 1300 	lcall	_ak820_outline_0159
      0075A4 54 0F            [12] 1301 	anl	a,#0x0f
      0075A6 FE               [12] 1302 	mov	r6,a
      0075A7 8F F0            [24] 1303 	mov	b,r7
      0075A9 05 F0            [12] 1304 	inc	b
      0075AB EE               [12] 1305 	mov	a,r6
      0075AC 80 02            [24] 1306 	sjmp	00460$
      0075AE                       1307 00459$:
      0075AE 25 E0            [12] 1308 	add	a,acc
      0075B0                       1309 00460$:
      0075B0 D5 F0 FB         [24] 1310 	djnz	b,00459$
      0075B3 FE               [12] 1311 	mov	r6,a
                                   1312 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0075B4 12 79 0E         [24] 1313 	lcall	_ak820_outline_0159
      0075B7 30 E4 11         [24] 1314 	jnb	acc.4,00204$
      0075BA 8F F0            [24] 1315 	mov	b,r7
      0075BC 05 F0            [12] 1316 	inc	b
      0075BE 74 0F            [12] 1317 	mov	a,#0x0f
      0075C0 80 02            [24] 1318 	sjmp	00463$
      0075C2                       1319 00462$:
      0075C2 25 E0            [12] 1320 	add	a,acc
      0075C4                       1321 00463$:
      0075C4 D5 F0 FB         [24] 1322 	djnz	b,00462$
      0075C7 F4               [12] 1323 	cpl	a
      0075C8 FF               [12] 1324 	mov	r7,a
      0075C9 80 02            [24] 1325 	sjmp	00205$
      0075CB                       1326 00204$:
      0075CB 7F 00            [12] 1327 	mov	r7,#0x00
      0075CD                       1328 00205$:
                                   1329 ;	quantum/action.c:648: bits |= mask;
      0075CD EE               [12] 1330 	mov	a,r6
      0075CE 42 07            [12] 1331 	orl	ar7,a
                                   1332 ;	quantum/action.c:649: if (!on) {
      0075D0 90 08 3D         [24] 1333 	mov	dptr,#_process_action_on_40000_675
      0075D3 E0               [24] 1334 	movx	a,@dptr
      0075D4 70 31            [24] 1335 	jnz	00143$
                                   1336 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0075D6 12 78 E9         [24] 1337 	lcall	_ak820_outline_0090
      0075D9 FE               [12] 1338 	mov	r6,a
      0075DA 2E               [12] 1339 	add	a,r6
                                   1340 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0075DB 90 75 DF         [24] 1341 	mov	dptr,#00465$
      0075DE 73               [24] 1342 	jmp	@a+dptr
      0075DF                       1343 00465$:
      0075DF 80 06            [24] 1344 	sjmp	00132$
      0075E1 80 0C            [24] 1345 	sjmp	00133$
      0075E3 80 12            [24] 1346 	sjmp	00134$
      0075E5 80 18            [24] 1347 	sjmp	00135$
      0075E7                       1348 00132$:
      0075E7 8F 82            [24] 1349 	mov	dpl, r7
      0075E9 12 79 6E         [24] 1350 	lcall	_default_layer_and
      0075EC 02 76 D1         [24] 1351 	ljmp	00181$
                                   1352 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      0075EF                       1353 00133$:
      0075EF 8F 82            [24] 1354 	mov	dpl, r7
      0075F1 12 79 5D         [24] 1355 	lcall	_default_layer_or
      0075F4 02 76 D1         [24] 1356 	ljmp	00181$
                                   1357 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      0075F7                       1358 00134$:
      0075F7 8F 82            [24] 1359 	mov	dpl, r7
      0075F9 12 79 84         [24] 1360 	lcall	_default_layer_xor
      0075FC 02 76 D1         [24] 1361 	ljmp	00181$
                                   1362 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      0075FF                       1363 00135$:
      0075FF 8F 82            [24] 1364 	mov	dpl, r7
      007601 12 79 52         [24] 1365 	lcall	_default_layer_set
                                   1366 ;	quantum/action.c:655: }
      007604 02 76 D1         [24] 1367 	ljmp	00181$
      007607                       1368 00143$:
                                   1369 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007607 12 78 E9         [24] 1370 	lcall	_ak820_outline_0090
      00760A FE               [12] 1371 	mov	r6,a
      00760B 2E               [12] 1372 	add	a,r6
                                   1373 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      00760C 90 76 10         [24] 1374 	mov	dptr,#00466$
      00760F 73               [24] 1375 	jmp	@a+dptr
      007610                       1376 00466$:
      007610 80 06            [24] 1377 	sjmp	00137$
      007612 80 0C            [24] 1378 	sjmp	00138$
      007614 80 12            [24] 1379 	sjmp	00139$
      007616 80 18            [24] 1380 	sjmp	00140$
      007618                       1381 00137$:
      007618 8F 82            [24] 1382 	mov	dpl, r7
      00761A 12 7B 08         [24] 1383 	lcall	_layer_and
      00761D 02 76 D1         [24] 1384 	ljmp	00181$
                                   1385 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007620                       1386 00138$:
      007620 8F 82            [24] 1387 	mov	dpl, r7
      007622 12 7A F7         [24] 1388 	lcall	_layer_or
      007625 02 76 D1         [24] 1389 	ljmp	00181$
                                   1390 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007628                       1391 00139$:
      007628 8F 82            [24] 1392 	mov	dpl, r7
      00762A 12 7B 1E         [24] 1393 	lcall	_layer_xor
      00762D 02 76 D1         [24] 1394 	ljmp	00181$
                                   1395 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007630                       1396 00140$:
      007630 8F 82            [24] 1397 	mov	dpl, r7
      007632 12 7A 94         [24] 1398 	lcall	_layer_state_set
                                   1399 ;	quantum/action.c:665: break;
      007635 02 76 D1         [24] 1400 	ljmp	00181$
                                   1401 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007638                       1402 00147$:
                                   1403 ;	quantum/action.c:668: if (pressed) {
      007638 E5 27            [12] 1404 	mov	a,_process_action_sloc0_1_0
      00763A 60 11            [24] 1405 	jz	00149$
                                   1406 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      00763C 12 78 F2         [24] 1407 	lcall	_ak820_outline_0113
      00763F F5 82            [12] 1408 	mov	dpl,a
      007641 12 79 F4         [24] 1409 	lcall	_layer_hold_on
                                   1410 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007644 12 78 E2         [24] 1411 	lcall	_ak820_outline_0079
      007647 12 78 0B         [24] 1412 	lcall	_register_mods
      00764A 02 76 D1         [24] 1413 	ljmp	00181$
      00764D                       1414 00149$:
                                   1415 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      00764D 12 78 E2         [24] 1416 	lcall	_ak820_outline_0079
      007650 12 78 1F         [24] 1417 	lcall	_unregister_mods
                                   1418 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007653 12 78 F2         [24] 1419 	lcall	_ak820_outline_0113
      007656 F5 82            [12] 1420 	mov	dpl,a
      007658 12 7A 2C         [24] 1421 	lcall	_layer_hold_off
                                   1422 ;	quantum/action.c:675: break;
      00765B 02 76 D1         [24] 1423 	ljmp	00181$
                                   1424 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      00765E                       1425 00152$:
                                   1426 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      00765E 12 79 0E         [24] 1427 	lcall	_ak820_outline_0159
      007661 FF               [12] 1428 	mov	r7,a
      007662 BF F1 02         [24] 1429 	cjne	r7,#0xf1,00468$
      007665 80 0A            [24] 1430 	sjmp	00154$
      007667                       1431 00468$:
      007667 BF F2 02         [24] 1432 	cjne	r7,#0xf2,00469$
      00766A 80 19            [24] 1433 	sjmp	00155$
      00766C                       1434 00469$:
                                   1435 ;	quantum/action.c:694: momentary_layer_action:
      00766C BF F3 3B         [24] 1436 	cjne	r7,#0xf3,00160$
      00766F 80 28            [24] 1437 	sjmp	00156$
      007671                       1438 00154$:
                                   1439 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007671 E5 27            [12] 1440 	mov	a,_process_action_sloc0_1_0
      007673 60 08            [24] 1441 	jz	00206$
      007675 12 78 C8         [24] 1442 	lcall	_ak820_outline_0043
      007678 12 79 F4         [24] 1443 	lcall	_layer_hold_on
      00767B 80 54            [24] 1444 	sjmp	00181$
      00767D                       1445 00206$:
      00767D 12 78 C8         [24] 1446 	lcall	_ak820_outline_0043
      007680 12 7A 2C         [24] 1447 	lcall	_layer_hold_off
                                   1448 ;	quantum/action.c:696: break;
                                   1449 ;	quantum/action.c:697: case OP_OFF_ON:
      007683 80 4C            [24] 1450 	sjmp	00181$
      007685                       1451 00155$:
                                   1452 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007685 E5 27            [12] 1453 	mov	a,_process_action_sloc0_1_0
      007687 60 08            [24] 1454 	jz	00208$
      007689 12 78 C8         [24] 1455 	lcall	_ak820_outline_0043
      00768C 12 7A D9         [24] 1456 	lcall	_layer_off
      00768F 80 40            [24] 1457 	sjmp	00181$
      007691                       1458 00208$:
      007691 12 78 C8         [24] 1459 	lcall	_ak820_outline_0043
      007694 12 7A BE         [24] 1460 	lcall	_layer_on
                                   1461 ;	quantum/action.c:699: break;
                                   1462 ;	quantum/action.c:700: case OP_SET_CLEAR:
      007697 80 38            [24] 1463 	sjmp	00181$
      007699                       1464 00156$:
                                   1465 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007699 E5 27            [12] 1466 	mov	a,_process_action_sloc0_1_0
      00769B 60 08            [24] 1467 	jz	00210$
      00769D 12 78 C8         [24] 1468 	lcall	_ak820_outline_0043
      0076A0 12 7A A8         [24] 1469 	lcall	_layer_move
      0076A3 80 2C            [24] 1470 	sjmp	00181$
      0076A5                       1471 00210$:
      0076A5 12 7A A2         [24] 1472 	lcall	_layer_clear
                                   1473 ;	quantum/action.c:702: break;
                                   1474 ;	quantum/action.c:748: default:
      0076A8 80 27            [24] 1475 	sjmp	00181$
      0076AA                       1476 00160$:
                                   1477 ;	quantum/action.c:755: if (pressed) {
      0076AA E5 27            [12] 1478 	mov	a,_process_action_sloc0_1_0
      0076AC 60 08            [24] 1479 	jz	00163$
                                   1480 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0076AE 12 78 E2         [24] 1481 	lcall	_ak820_outline_0079
      0076B1 12 76 E8         [24] 1482 	lcall	_register_code
                                   1483 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0076B4 80 1B            [24] 1484 	sjmp	00181$
      0076B6                       1485 00163$:
                                   1486 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0076B6 12 79 0E         [24] 1487 	lcall	_ak820_outline_0159
      0076B9 FF               [12] 1488 	mov	r7,a
      0076BA BF 39 0E         [24] 1489 	cjne	r7,#0x39,00175$
                                   1490 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0076BD 7F 50            [12] 1491 	mov	r7,#0x50
      0076BF                       1492 00187$:
      0076BF EF               [12] 1493 	mov	a,r7
      0076C0 60 09            [24] 1494 	jz	00175$
      0076C2 90 00 01         [24] 1495 	mov	dptr,#0x0001
      0076C5 12 59 EB         [24] 1496 	lcall	_mDelaymS
      0076C8 1F               [12] 1497 	dec	r7
                                   1498 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0076C9 80 F4            [24] 1499 	sjmp	00187$
      0076CB                       1500 00175$:
                                   1501 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0076CB 12 78 E2         [24] 1502 	lcall	_ak820_outline_0079
      0076CE 12 77 55         [24] 1503 	lcall	_unregister_code
                                   1504 ;	quantum/action.c:848: }
      0076D1                       1505 00181$:
                                   1506 ;	quantum/action.c:869: switch (action.kind.id) {
      0076D1 90 08 39         [24] 1507 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076D4 E0               [24] 1508 	movx	a,@dptr
      0076D5 C4               [12] 1509 	swap	a
      0076D6 54 0F            [12] 1510 	anl	a,#0x0f
      0076D8 FF               [12] 1511 	mov	r7,a
      0076D9 BF 08 02         [24] 1512 	cjne	r7,#0x08,00478$
      0076DC 80 03            [24] 1513 	sjmp	00183$
      0076DE                       1514 00478$:
      0076DE BF 09 06         [24] 1515 	cjne	r7,#0x09,00192$
                                   1516 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      0076E1                       1517 00183$:
                                   1518 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      0076E1 12 6E 5C         [24] 1519 	lcall	_host_keyboard_leds
                                   1520 ;	quantum/action.c:880: }
                                   1521 ;	quantum/action.c:933: }
      0076E4 02 98 F8         [24] 1522 	ljmp	_led_set
      0076E7                       1523 00192$:
      0076E7 22               [24] 1524 	ret
                                   1525 ;------------------------------------------------------------
                                   1526 ;Allocation info for local variables in function 'register_code'
                                   1527 ;------------------------------------------------------------
                                   1528 ;code          Allocated with name '_register_code_code_10000_709'
                                   1529 ;------------------------------------------------------------
                                   1530 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1531 ;	-----------------------------------------
                                   1532 ;	 function register_code
                                   1533 ;	-----------------------------------------
      0076E8                       1534 _register_code:
      0076E8 E5 82            [12] 1535 	mov	a,dpl
      0076EA 90 08 3E         [24] 1536 	mov	dptr,#_register_code_code_10000_709
      0076ED F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/action.c:940: if (code == KC_NO) {
      0076EE E0               [24] 1539 	movx	a,@dptr
      0076EF FF               [12] 1540 	mov	r7,a
      0076F0 70 01            [24] 1541 	jnz	00123$
                                   1542 ;	quantum/action.c:941: return;
      0076F2 22               [24] 1543 	ret
      0076F3                       1544 00123$:
                                   1545 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      0076F3 BF 04 00         [24] 1546 	cjne	r7,#0x04,00186$
      0076F6                       1547 00186$:
      0076F6 40 12            [24] 1548 	jc	00119$
      0076F8 EF               [12] 1549 	mov	a,r7
      0076F9 24 5B            [12] 1550 	add	a,#0xff - 0xa4
      0076FB 40 0D            [24] 1551 	jc	00119$
                                   1552 ;	free result
                                   1553 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      0076FD 8F 82            [24] 1554 	mov	dpl, r7
      0076FF 12 7F 1E         [24] 1555 	lcall	_add_owned_key
      007702 E5 82            [12] 1556 	mov	a, dpl
      007704 70 01            [24] 1557 	jnz	00104$
      007706 22               [24] 1558 	ret
      007707                       1559 00104$:
                                   1560 ;	quantum/action.c:995: send_keyboard_report();
      007707 02 81 B4         [24] 1561 	ljmp	_send_keyboard_report
      00770A                       1562 00119$:
                                   1563 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      00770A 12 79 13         [24] 1564 	lcall	_ak820_outline_0167
      00770D BF E0 00         [24] 1565 	cjne	r7,#0xe0,00190$
      007710                       1566 00190$:
      007710 40 1A            [24] 1567 	jc	00115$
      007712 EF               [12] 1568 	mov	a,r7
      007713 24 18            [12] 1569 	add	a,#0xff - 0xe7
      007715 40 15            [24] 1570 	jc	00115$
                                   1571 ;	free result
                                   1572 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007717 74 07            [12] 1573 	mov	a,#0x07
      007719 5F               [12] 1574 	anl	a,r7
      00771A 12 78 D1         [24] 1575 	lcall	_ak820_outline_0062
      00771D 80 02            [24] 1576 	sjmp	00194$
      00771F                       1577 00193$:
      00771F 25 E0            [12] 1578 	add	a,acc
      007721                       1579 00194$:
      007721 D5 F0 FB         [24] 1580 	djnz	b,00193$
      007724 F5 82            [12] 1581 	mov	dpl,a
      007726 12 7E 7A         [24] 1582 	lcall	_add_owned_mods
                                   1583 ;	quantum/action.c:998: send_keyboard_report();
      007729 02 81 B4         [24] 1584 	ljmp	_send_keyboard_report
      00772C                       1585 00115$:
                                   1586 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00772C 12 79 13         [24] 1587 	lcall	_ak820_outline_0167
      00772F BF A5 00         [24] 1588 	cjne	r7,#0xa5,00195$
      007732                       1589 00195$:
      007732 40 05            [24] 1590 	jc	00113$
      007734 EF               [12] 1591 	mov	a,r7
      007735 24 58            [12] 1592 	add	a,#0xff - 0xa7
      007737 50 0D            [24] 1593 	jnc	00108$
                                   1594 ;	free result
      007739                       1595 00113$:
      007739 12 79 13         [24] 1596 	lcall	_ak820_outline_0167
      00773C BF A8 00         [24] 1597 	cjne	r7,#0xa8,00198$
      00773F                       1598 00198$:
      00773F 40 13            [24] 1599 	jc	00125$
      007741 EF               [12] 1600 	mov	a,r7
      007742 24 3D            [12] 1601 	add	a,#0xff - 0xc2
      007744 40 0E            [24] 1602 	jc	00125$
                                   1603 ;	free result
      007746                       1604 00108$:
                                   1605 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007746 12 79 13         [24] 1606 	lcall	_ak820_outline_0167
      007749 90 0A 99         [24] 1607 	mov	dptr,#_owned_usage_key_PARM_2
      00774C 74 01            [12] 1608 	mov	a,#0x01
      00774E F0               [24] 1609 	movx	@dptr,a
      00774F 8F 82            [24] 1610 	mov	dpl, r7
                                   1611 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1612 ;	quantum/action.c:1013: }
      007751 02 80 5F         [24] 1613 	ljmp	_owned_usage_key
      007754                       1614 00125$:
      007754 22               [24] 1615 	ret
                                   1616 ;------------------------------------------------------------
                                   1617 ;Allocation info for local variables in function 'unregister_code'
                                   1618 ;------------------------------------------------------------
                                   1619 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1620 ;------------------------------------------------------------
                                   1621 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1622 ;	-----------------------------------------
                                   1623 ;	 function unregister_code
                                   1624 ;	-----------------------------------------
      007755                       1625 _unregister_code:
      007755 E5 82            [12] 1626 	mov	a,dpl
      007757 90 08 3F         [24] 1627 	mov	dptr,#_unregister_code_code_10000_723
      00775A F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	quantum/action.c:1020: if (code == KC_NO) {
      00775B E0               [24] 1630 	movx	a,@dptr
      00775C FF               [12] 1631 	mov	r7,a
      00775D 70 01            [24] 1632 	jnz	00121$
                                   1633 ;	quantum/action.c:1021: return;
      00775F 22               [24] 1634 	ret
      007760                       1635 00121$:
                                   1636 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007760 BF 04 00         [24] 1637 	cjne	r7,#0x04,00184$
      007763                       1638 00184$:
      007763 40 12            [24] 1639 	jc	00117$
      007765 EF               [12] 1640 	mov	a,r7
      007766 24 5B            [12] 1641 	add	a,#0xff - 0xa4
      007768 40 0D            [24] 1642 	jc	00117$
                                   1643 ;	free result
                                   1644 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      00776A 8F 82            [24] 1645 	mov	dpl, r7
      00776C 12 7F 98         [24] 1646 	lcall	_del_owned_key
      00776F E5 82            [12] 1647 	mov	a, dpl
      007771 70 01            [24] 1648 	jnz	00102$
      007773 22               [24] 1649 	ret
      007774                       1650 00102$:
                                   1651 ;	quantum/action.c:1062: send_keyboard_report();
      007774 02 81 B4         [24] 1652 	ljmp	_send_keyboard_report
      007777                       1653 00117$:
                                   1654 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007777 12 79 19         [24] 1655 	lcall	_ak820_outline_0168
      00777A BF E0 00         [24] 1656 	cjne	r7,#0xe0,00188$
      00777D                       1657 00188$:
      00777D 40 1A            [24] 1658 	jc	00113$
      00777F EF               [12] 1659 	mov	a,r7
      007780 24 18            [12] 1660 	add	a,#0xff - 0xe7
      007782 40 15            [24] 1661 	jc	00113$
                                   1662 ;	free result
                                   1663 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      007784 74 07            [12] 1664 	mov	a,#0x07
      007786 5F               [12] 1665 	anl	a,r7
      007787 12 78 D1         [24] 1666 	lcall	_ak820_outline_0062
      00778A 80 02            [24] 1667 	sjmp	00192$
      00778C                       1668 00191$:
      00778C 25 E0            [12] 1669 	add	a,acc
      00778E                       1670 00192$:
      00778E D5 F0 FB         [24] 1671 	djnz	b,00191$
      007791 F5 82            [12] 1672 	mov	dpl,a
      007793 12 7E 8A         [24] 1673 	lcall	_del_owned_mods
                                   1674 ;	quantum/action.c:1065: send_keyboard_report();
      007796 02 81 B4         [24] 1675 	ljmp	_send_keyboard_report
      007799                       1676 00113$:
                                   1677 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007799 12 79 19         [24] 1678 	lcall	_ak820_outline_0168
      00779C BF A5 00         [24] 1679 	cjne	r7,#0xa5,00193$
      00779F                       1680 00193$:
      00779F 40 05            [24] 1681 	jc	00111$
      0077A1 EF               [12] 1682 	mov	a,r7
      0077A2 24 58            [12] 1683 	add	a,#0xff - 0xa7
      0077A4 50 0D            [24] 1684 	jnc	00106$
                                   1685 ;	free result
      0077A6                       1686 00111$:
      0077A6 12 79 19         [24] 1687 	lcall	_ak820_outline_0168
      0077A9 BF A8 00         [24] 1688 	cjne	r7,#0xa8,00196$
      0077AC                       1689 00196$:
      0077AC 40 12            [24] 1690 	jc	00123$
      0077AE EF               [12] 1691 	mov	a,r7
      0077AF 24 3D            [12] 1692 	add	a,#0xff - 0xc2
      0077B1 40 0D            [24] 1693 	jc	00123$
                                   1694 ;	free result
      0077B3                       1695 00106$:
                                   1696 ;	quantum/action.c:1070: owned_usage_key(code, false);
      0077B3 12 79 19         [24] 1697 	lcall	_ak820_outline_0168
      0077B6 90 0A 99         [24] 1698 	mov	dptr,#_owned_usage_key_PARM_2
      0077B9 E4               [12] 1699 	clr	a
      0077BA F0               [24] 1700 	movx	@dptr,a
      0077BB 8F 82            [24] 1701 	mov	dpl, r7
                                   1702 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1703 ;	quantum/action.c:1080: }
      0077BD 02 80 5F         [24] 1704 	ljmp	_owned_usage_key
      0077C0                       1705 00123$:
      0077C0 22               [24] 1706 	ret
                                   1707 ;------------------------------------------------------------
                                   1708 ;Allocation info for local variables in function 'tap_code_delay'
                                   1709 ;------------------------------------------------------------
                                   1710 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1711 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1712 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1714 ;------------------------------------------------------------
                                   1715 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1716 ;	-----------------------------------------
                                   1717 ;	 function tap_code_delay
                                   1718 ;	-----------------------------------------
      0077C1                       1719 _tap_code_delay:
      0077C1 E5 82            [12] 1720 	mov	a,dpl
      0077C3 90 08 42         [24] 1721 	mov	dptr,#_tap_code_delay_code_10000_736
      0077C6 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action.c:1088: register_code(code);
      0077C7 E0               [24] 1724 	movx	a,@dptr
      0077C8 FF               [12] 1725 	mov	r7,a
      0077C9 F5 82            [12] 1726 	mov	dpl,a
      0077CB C0 07            [24] 1727 	push	ar7
      0077CD 12 76 E8         [24] 1728 	lcall	_register_code
      0077D0 D0 07            [24] 1729 	pop	ar7
                                   1730 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0077D2 90 08 40         [24] 1731 	mov	dptr,#_tap_code_delay_PARM_2
      0077D5 12 38 64         [24] 1732 	lcall	_ak820_outline_0080
      0077D8                       1733 00110$:
      0077D8 ED               [12] 1734 	mov	a,r5
      0077D9 4E               [12] 1735 	orl	a,r6
      0077DA 60 0D            [24] 1736 	jz	00105$
                                   1737 ;	quantum/action.c:1090: wait_ms(1);
      0077DC 90 00 01         [24] 1738 	mov	dptr,#0x0001
      0077DF 12 59 EB         [24] 1739 	lcall	_mDelaymS
                                   1740 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0077E2 1D               [12] 1741 	dec	r5
      0077E3 BD FF 01         [24] 1742 	cjne	r5,#0xff,00141$
      0077E6 1E               [12] 1743 	dec	r6
      0077E7                       1744 00141$:
      0077E7 80 EF            [24] 1745 	sjmp	00110$
      0077E9                       1746 00105$:
                                   1747 ;	quantum/action.c:1092: unregister_code(code);
      0077E9 8F 82            [24] 1748 	mov	dpl, r7
                                   1749 ;	quantum/action.c:1093: }
      0077EB 02 77 55         [24] 1750 	ljmp	_unregister_code
                                   1751 ;------------------------------------------------------------
                                   1752 ;Allocation info for local variables in function 'tap_code'
                                   1753 ;------------------------------------------------------------
                                   1754 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1755 ;------------------------------------------------------------
                                   1756 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1757 ;	-----------------------------------------
                                   1758 ;	 function tap_code
                                   1759 ;	-----------------------------------------
      0077EE                       1760 _tap_code:
      0077EE E5 82            [12] 1761 	mov	a,dpl
      0077F0 90 08 43         [24] 1762 	mov	dptr,#_tap_code_code_10000_743
      0077F3 F0               [24] 1763 	movx	@dptr,a
                                   1764 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0077F4 E0               [24] 1765 	movx	a,@dptr
      0077F5 FF               [12] 1766 	mov	r7,a
      0077F6 BF 39 04         [24] 1767 	cjne	r7,#0x39,00103$
      0077F9 7E 50            [12] 1768 	mov	r6,#0x50
      0077FB 80 02            [24] 1769 	sjmp	00104$
      0077FD                       1770 00103$:
      0077FD 7E 00            [12] 1771 	mov	r6,#0x00
      0077FF                       1772 00104$:
      0077FF 90 08 40         [24] 1773 	mov	dptr,#_tap_code_delay_PARM_2
      007802 EE               [12] 1774 	mov	a,r6
      007803 12 38 9C         [24] 1775 	lcall	_ak820_outline_0134
      007806 8F 82            [24] 1776 	mov	dpl, r7
                                   1777 ;	quantum/action.c:1101: }
      007808 02 77 C1         [24] 1778 	ljmp	_tap_code_delay
                                   1779 ;------------------------------------------------------------
                                   1780 ;Allocation info for local variables in function 'register_mods'
                                   1781 ;------------------------------------------------------------
                                   1782 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1783 ;------------------------------------------------------------
                                   1784 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1785 ;	-----------------------------------------
                                   1786 ;	 function register_mods
                                   1787 ;	-----------------------------------------
      00780B                       1788 _register_mods:
      00780B E5 82            [12] 1789 	mov	a,dpl
      00780D 90 08 44         [24] 1790 	mov	dptr,#_register_mods_mods_10000_745
      007810 F0               [24] 1791 	movx	@dptr,a
                                   1792 ;	quantum/action.c:1108: if (mods) {
      007811 E0               [24] 1793 	movx	a,@dptr
      007812 FF               [12] 1794 	mov	r7,a
      007813 E0               [24] 1795 	movx	a,@dptr
      007814 60 08            [24] 1796 	jz	00103$
                                   1797 ;	quantum/action.c:1109: add_owned_mods(mods);
      007816 8F 82            [24] 1798 	mov	dpl, r7
      007818 12 7E 7A         [24] 1799 	lcall	_add_owned_mods
                                   1800 ;	quantum/action.c:1110: send_keyboard_report();
                                   1801 ;	quantum/action.c:1112: }
      00781B 02 81 B4         [24] 1802 	ljmp	_send_keyboard_report
      00781E                       1803 00103$:
      00781E 22               [24] 1804 	ret
                                   1805 ;------------------------------------------------------------
                                   1806 ;Allocation info for local variables in function 'unregister_mods'
                                   1807 ;------------------------------------------------------------
                                   1808 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1809 ;------------------------------------------------------------
                                   1810 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1811 ;	-----------------------------------------
                                   1812 ;	 function unregister_mods
                                   1813 ;	-----------------------------------------
      00781F                       1814 _unregister_mods:
      00781F E5 82            [12] 1815 	mov	a,dpl
      007821 90 08 45         [24] 1816 	mov	dptr,#_unregister_mods_mods_10000_749
      007824 F0               [24] 1817 	movx	@dptr,a
                                   1818 ;	quantum/action.c:1119: if (mods) {
      007825 E0               [24] 1819 	movx	a,@dptr
      007826 FF               [12] 1820 	mov	r7,a
      007827 E0               [24] 1821 	movx	a,@dptr
      007828 60 08            [24] 1822 	jz	00103$
                                   1823 ;	quantum/action.c:1120: del_owned_mods(mods);
      00782A 8F 82            [24] 1824 	mov	dpl, r7
      00782C 12 7E 8A         [24] 1825 	lcall	_del_owned_mods
                                   1826 ;	quantum/action.c:1121: send_keyboard_report();
                                   1827 ;	quantum/action.c:1123: }
      00782F 02 81 B4         [24] 1828 	ljmp	_send_keyboard_report
      007832                       1829 00103$:
      007832 22               [24] 1830 	ret
                                   1831 ;------------------------------------------------------------
                                   1832 ;Allocation info for local variables in function 'register_weak_mods'
                                   1833 ;------------------------------------------------------------
                                   1834 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1835 ;------------------------------------------------------------
                                   1836 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1837 ;	-----------------------------------------
                                   1838 ;	 function register_weak_mods
                                   1839 ;	-----------------------------------------
      007833                       1840 _register_weak_mods:
      007833 E5 82            [12] 1841 	mov	a,dpl
      007835 90 08 46         [24] 1842 	mov	dptr,#_register_weak_mods_mods_10000_753
      007838 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	quantum/action.c:1130: if (mods) {
      007839 E0               [24] 1845 	movx	a,@dptr
      00783A FF               [12] 1846 	mov	r7,a
      00783B E0               [24] 1847 	movx	a,@dptr
      00783C 60 08            [24] 1848 	jz	00103$
                                   1849 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      00783E 8F 82            [24] 1850 	mov	dpl, r7
      007840 12 7E 99         [24] 1851 	lcall	_add_owned_weak_mods
                                   1852 ;	quantum/action.c:1132: send_keyboard_report();
                                   1853 ;	quantum/action.c:1134: }
      007843 02 81 B4         [24] 1854 	ljmp	_send_keyboard_report
      007846                       1855 00103$:
      007846 22               [24] 1856 	ret
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1859 ;------------------------------------------------------------
                                   1860 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1861 ;------------------------------------------------------------
                                   1862 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1863 ;	-----------------------------------------
                                   1864 ;	 function unregister_weak_mods
                                   1865 ;	-----------------------------------------
      007847                       1866 _unregister_weak_mods:
      007847 E5 82            [12] 1867 	mov	a,dpl
      007849 90 08 47         [24] 1868 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      00784C F0               [24] 1869 	movx	@dptr,a
                                   1870 ;	quantum/action.c:1141: if (mods) {
      00784D E0               [24] 1871 	movx	a,@dptr
      00784E FF               [12] 1872 	mov	r7,a
      00784F E0               [24] 1873 	movx	a,@dptr
      007850 60 08            [24] 1874 	jz	00103$
                                   1875 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007852 8F 82            [24] 1876 	mov	dpl, r7
      007854 12 7E A9         [24] 1877 	lcall	_del_owned_weak_mods
                                   1878 ;	quantum/action.c:1143: send_keyboard_report();
                                   1879 ;	quantum/action.c:1145: }
      007857 02 81 B4         [24] 1880 	ljmp	_send_keyboard_report
      00785A                       1881 00103$:
      00785A 22               [24] 1882 	ret
                                   1883 ;------------------------------------------------------------
                                   1884 ;Allocation info for local variables in function 'clear_keyboard'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function clear_keyboard
                                   1889 ;	-----------------------------------------
      00785B                       1890 _clear_keyboard:
                                   1891 ;	quantum/action.c:1152: clear_mods();
      00785B 12 82 2F         [24] 1892 	lcall	_clear_mods
                                   1893 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1894 ;	quantum/action.c:1154: }
      00785E 02 78 61         [24] 1895 	ljmp	_clear_keyboard_but_mods
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1898 ;------------------------------------------------------------
                                   1899 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1900 ;	-----------------------------------------
                                   1901 ;	 function clear_keyboard_but_mods
                                   1902 ;	-----------------------------------------
      007861                       1903 _clear_keyboard_but_mods:
                                   1904 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007861 90 0D CB         [24] 1905 	mov	dptr,#_actual_keyboard_report
      007864 12 71 22         [24] 1906 	lcall	_clear_keys_from_report
                                   1907 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1908 ;	quantum/action.c:1163: }
      007867 02 78 6A         [24] 1909 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1910 ;------------------------------------------------------------
                                   1911 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1912 ;------------------------------------------------------------
                                   1913 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1914 ;	-----------------------------------------
                                   1915 ;	 function clear_keyboard_but_mods_and_keys
                                   1916 ;	-----------------------------------------
      00786A                       1917 _clear_keyboard_but_mods_and_keys:
                                   1918 ;	quantum/action.c:1171: ak820_tapping_cancel();
      00786A 12 47 F9         [24] 1919 	lcall	_ak820_tapping_cancel
                                   1920 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      00786D 12 2E A4         [24] 1921 	lcall	_ak820_oneshot_cancel
                                   1922 ;	quantum/action.c:1185: ak820_combo_cancel();
      007870 12 35 70         [24] 1923 	lcall	_ak820_combo_cancel
                                   1924 ;	quantum/action.c:1188: repeat_key_cancel();
      007873 12 A2 EC         [24] 1925 	lcall	_repeat_key_cancel
                                   1926 ;	quantum/action.c:1190: clear_owned_mods();
      007876 12 7E B9         [24] 1927 	lcall	_clear_owned_mods
                                   1928 ;	quantum/action.c:1191: clear_owned_keys();
      007879 12 7E F1         [24] 1929 	lcall	_clear_owned_keys
                                   1930 ;	quantum/action.c:1192: clear_owned_usages();
      00787C 12 80 27         [24] 1931 	lcall	_clear_owned_usages
                                   1932 ;	quantum/action.c:1193: layer_hold_clear();
      00787F 12 7A 65         [24] 1933 	lcall	_layer_hold_clear
                                   1934 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007882 12 9D AD         [24] 1935 	lcall	_clear_macro_tri_layer
                                   1936 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007885 90 0D CB         [24] 1937 	mov	dptr,#_actual_keyboard_report
      007888 12 71 22         [24] 1938 	lcall	_clear_keys_from_report
                                   1939 ;	quantum/action.c:1200: host_system_send(0);
      00788B 90 00 00         [24] 1940 	mov	dptr,#0x0000
      00788E 12 6E F7         [24] 1941 	lcall	_host_system_send
                                   1942 ;	quantum/action.c:1201: host_consumer_send(0);
      007891 90 00 00         [24] 1943 	mov	dptr,#0x0000
      007894 12 6F 27         [24] 1944 	lcall	_host_consumer_send
                                   1945 ;	quantum/action.c:1203: clear_weak_mods();
      007897 12 82 64         [24] 1946 	lcall	_clear_weak_mods
                                   1947 ;	quantum/action.c:1204: send_keyboard_report();
                                   1948 ;	quantum/action.c:1212: }
      00789A 02 81 B4         [24] 1949 	ljmp	_send_keyboard_report
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'is_tap_record'
                                   1952 ;------------------------------------------------------------
                                   1953 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1954 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1957 ;	-----------------------------------------
                                   1958 	.area CSEG    (CODE)
                                   1959 	.area CONST   (CODE)
                                   1960 	.area XINIT   (CODE)
      00C26B                       1961 __xinit__disable_action_cache:
      00C26B 00                    1962 	.db #0x00	;  0
                                   1963 	.area CABS    (ABS,CODE)
                                   1964 
                                   1965 ; Experimental exact instruction outlining.
                                   1966 	.globl _ak820_outline_0001
                                   1967 	.globl _ak820_outline_0005
                                   1968 	.globl _ak820_outline_0008
                                   1969 	.globl _ak820_outline_0009
                                   1970 	.globl _ak820_outline_0012
                                   1971 	.globl _ak820_outline_0013
                                   1972 	.globl _ak820_outline_0014
                                   1973 	.globl _ak820_outline_0015
                                   1974 	.globl _ak820_outline_0018
                                   1975 	.globl _ak820_outline_0022
                                   1976 	.globl _ak820_outline_0023
                                   1977 	.globl _ak820_outline_0035
                                   1978 	.globl _ak820_outline_0038
                                   1979 	.globl _ak820_outline_0043
                                   1980 	.globl _ak820_outline_0058
                                   1981 	.globl _ak820_outline_0062
                                   1982 	.globl _ak820_outline_0065
                                   1983 	.globl _ak820_outline_0071
                                   1984 	.globl _ak820_outline_0073
                                   1985 	.globl _ak820_outline_0079
                                   1986 	.globl _ak820_outline_0080
                                   1987 	.globl _ak820_outline_0090
                                   1988 	.globl _ak820_outline_0094
                                   1989 	.globl _ak820_outline_0107
                                   1990 	.globl _ak820_outline_0108
                                   1991 	.globl _ak820_outline_0110
                                   1992 	.globl _ak820_outline_0112
                                   1993 	.globl _ak820_outline_0113
                                   1994 	.globl _ak820_outline_0118
                                   1995 	.globl _ak820_outline_0121
                                   1996 	.globl _ak820_outline_0124
                                   1997 	.globl _ak820_outline_0130
                                   1998 	.globl _ak820_outline_0133
                                   1999 	.globl _ak820_outline_0134
                                   2000 	.globl _ak820_outline_0142
                                   2001 	.globl _ak820_outline_0146
                                   2002 	.globl _ak820_outline_0149
                                   2003 	.globl _ak820_outline_0157
                                   2004 	.globl _ak820_outline_0159
                                   2005 	.globl _ak820_outline_0167
                                   2006 	.globl _ak820_outline_0168
                                   2007 	.globl _ak820_outline_0182
                                   2008 	.globl _ak820_outline_0187
                                   2009 	.globl _ak820_outline_0189
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0014
      00789D                       2013 _ak820_outline_0014:
      00789D 2D               [12] 2014 	add	a,r5
      00789E F9               [12] 2015 	mov	r1,a
      00789F E4               [12] 2016 	clr	a
      0078A0 3E               [12] 2017 	addc	a,r6
      0078A1 FA               [12] 2018 	mov	r2,a
      0078A2 8F 03            [24] 2019 	mov	ar3,r7
      0078A4 89 82            [24] 2020 	mov	dpl,r1
      0078A6 8A 83            [24] 2021 	mov	dph,r2
      0078A8 8B F0            [24] 2022 	mov	b,r3
      0078AA 22               [24] 2023 	ret
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0015
      0078AB                       2027 _ak820_outline_0015:
      0078AB 2D               [12] 2028 	add	a,r5
      0078AC FA               [12] 2029 	mov	r2,a
      0078AD E4               [12] 2030 	clr	a
      0078AE 3E               [12] 2031 	addc	a,r6
      0078AF FB               [12] 2032 	mov	r3,a
      0078B0 8F 04            [24] 2033 	mov	ar4,r7
      0078B2 8A 82            [24] 2034 	mov	dpl,r2
      0078B4 8B 83            [24] 2035 	mov	dph,r3
      0078B6 8C F0            [24] 2036 	mov	b,r4
      0078B8 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0022
      0078B9                       2041 _ak820_outline_0022:
      0078B9 8E 82            [24] 2042 	mov	dpl,r6
      0078BB 8F 83            [24] 2043 	mov	dph,r7
      0078BD A3               [24] 2044 	inc	dptr
      0078BE E0               [24] 2045 	movx	a,@dptr
      0078BF FC               [12] 2046 	mov	r4,a
      0078C0 7D 00            [12] 2047 	mov	r5,#0x00
      0078C2 8E 82            [24] 2048 	mov	dpl,r6
      0078C4 8F 83            [24] 2049 	mov	dph,r7
      0078C6 E0               [24] 2050 	movx	a,@dptr
      0078C7 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0043
      0078C8                       2055 _ak820_outline_0043:
      0078C8 90 08 39         [24] 2056 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0078CB E0               [24] 2057 	movx	a,@dptr
      0078CC 54 1F            [12] 2058 	anl	a,#0x1f
      0078CE F5 82            [12] 2059 	mov	dpl,a
      0078D0 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0062
      0078D1                       2064 _ak820_outline_0062:
      0078D1 F5 F0            [12] 2065 	mov	b,a
      0078D3 05 F0            [12] 2066 	inc	b
      0078D5 74 01            [12] 2067 	mov	a,#0x01
      0078D7 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0071
      0078D8                       2072 _ak820_outline_0071:
      0078D8 90 0D A9         [24] 2073 	mov	dptr,#___memcpy_PARM_3
      0078DB 74 06            [12] 2074 	mov	a,#0x06
      0078DD F0               [24] 2075 	movx	@dptr,a
      0078DE E4               [12] 2076 	clr	a
      0078DF A3               [24] 2077 	inc	dptr
      0078E0 F0               [24] 2078 	movx	@dptr,a
      0078E1 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0079
      0078E2                       2083 _ak820_outline_0079:
      0078E2 90 08 38         [24] 2084 	mov	dptr,#_process_action_PARM_2
      0078E5 E0               [24] 2085 	movx	a,@dptr
      0078E6 F5 82            [12] 2086 	mov	dpl,a
      0078E8 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0090
      0078E9                       2091 _ak820_outline_0090:
      0078E9 90 08 39         [24] 2092 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0078EC E0               [24] 2093 	movx	a,@dptr
      0078ED 03               [12] 2094 	rr	a
      0078EE 03               [12] 2095 	rr	a
      0078EF 54 03            [12] 2096 	anl	a,#0x03
      0078F1 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0113
      0078F2                       2101 _ak820_outline_0113:
      0078F2 90 08 39         [24] 2102 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0078F5 E0               [24] 2103 	movx	a,@dptr
      0078F6 54 0F            [12] 2104 	anl	a,#0x0f
      0078F8 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0130
      0078F9                       2109 _ak820_outline_0130:
      0078F9 90 08 38         [24] 2110 	mov	dptr,#_process_action_PARM_2
      0078FC E0               [24] 2111 	movx	a,@dptr
      0078FD FE               [12] 2112 	mov	r6,a
      0078FE A3               [24] 2113 	inc	dptr
      0078FF E0               [24] 2114 	movx	a,@dptr
      007900 54 03            [12] 2115 	anl	a,#0x03
      007902 FF               [12] 2116 	mov	r7,a
      007903 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0146
      007904                       2121 _ak820_outline_0146:
      007904 74 07            [12] 2122 	mov	a,#0x07
      007906 2D               [12] 2123 	add	a,r5
      007907 F8               [12] 2124 	mov	r0,a
      007908 E4               [12] 2125 	clr	a
      007909 3E               [12] 2126 	addc	a,r6
      00790A F9               [12] 2127 	mov	r1,a
      00790B 8F 02            [24] 2128 	mov	ar2,r7
      00790D 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0159
      00790E                       2133 _ak820_outline_0159:
      00790E 90 08 38         [24] 2134 	mov	dptr,#_process_action_PARM_2
      007911 E0               [24] 2135 	movx	a,@dptr
      007912 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0167
      007913                       2140 _ak820_outline_0167:
      007913 90 08 3E         [24] 2141 	mov	dptr,#_register_code_code_10000_709
      007916 E0               [24] 2142 	movx	a,@dptr
      007917 FF               [12] 2143 	mov	r7,a
      007918 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0168
      007919                       2148 _ak820_outline_0168:
      007919 90 08 3F         [24] 2149 	mov	dptr,#_unregister_code_code_10000_723
      00791C E0               [24] 2150 	movx	a,@dptr
      00791D FF               [12] 2151 	mov	r7,a
      00791E 22               [24] 2152 	ret
                                   2153 
                                   2154 	.area CSEG (CODE)
                                   2155 ; function ak820_outline_0187
      00791F                       2156 _ak820_outline_0187:
      00791F F0               [24] 2157 	movx	@dptr,a
      007920 EB               [12] 2158 	mov	a,r3
      007921 A3               [24] 2159 	inc	dptr
      007922 F0               [24] 2160 	movx	@dptr,a
      007923 22               [24] 2161 	ret
