                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      00080E                        616 _tp_buttons::
      00080E                        617 	.ds 2
      000810                        618 _action_exec_PARM_1:
      000810                        619 	.ds 6
      000816                        620 _action_exec_record_10001_624:
      000816                        621 	.ds 9
      00081F                        622 _ak820_action_exec_event_10000_628:
      00081F                        623 	.ds 2
      000821                        624 _ak820_action_exec_snapshot_10000_629:
      000821                        625 	.ds 6
      000827                        626 _process_record_record_10000_632:
      000827                        627 	.ds 3
      00082A                        628 _process_record_handler_record_argument_10000_640:
      00082A                        629 	.ds 3
      00082D                        630 _process_record_handler_action_10000_641:
      00082D                        631 	.ds 2
      00082F                        632 _process_action_PARM_2:
      00082F                        633 	.ds 2
      000831                        634 _process_action_record_argument_10000_652:
      000831                        635 	.ds 3
      000834                        636 _process_action_on_40000_675:
      000834                        637 	.ds 1
      000835                        638 _register_code_code_10000_709:
      000835                        639 	.ds 1
      000836                        640 _unregister_code_code_10000_723:
      000836                        641 	.ds 1
      000837                        642 _tap_code_delay_PARM_2:
      000837                        643 	.ds 2
      000839                        644 _tap_code_delay_code_10000_736:
      000839                        645 	.ds 1
      00083A                        646 _tap_code_code_10000_743:
      00083A                        647 	.ds 1
      00083B                        648 _register_mods_mods_10000_745:
      00083B                        649 	.ds 1
      00083C                        650 _unregister_mods_mods_10000_749:
      00083C                        651 	.ds 1
      00083D                        652 _register_weak_mods_mods_10000_753:
      00083D                        653 	.ds 1
      00083E                        654 _unregister_weak_mods_mods_10000_757:
      00083E                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DB8                        664 _disable_action_cache::
      000DB8                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      006FF6                        709 _action_exec:
                                    710 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      006FF6 90 08 12         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006FF9 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      006FFC 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      006FFF 90 08 10         [24]  715 	mov	dptr,#_action_exec_PARM_1
      007002 12 44 53         [24]  716 	lcall	_ak820_tapping_before
      007005 E5 82            [12]  717 	mov	a, dpl
      007007 70 01            [24]  718 	jnz	00102$
      007009 22               [24]  719 	ret
      00700A                        720 00102$:
                                    721 ;	quantum/action.c:116: if (event.pressed) {
      00700A 90 08 15         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00700D E0               [24]  723 	movx	a,@dptr
      00700E 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:118: clear_weak_mods();
      007010 12 80 52         [24]  726 	lcall	_clear_weak_mods
      007013                        727 00104$:
                                    728 ;	quantum/action.c:130: record.event = event;
      007013 90 0D 98         [24]  729 	mov	dptr,#___memcpy_PARM_2
      007016 74 10            [12]  730 	mov	a,#_action_exec_PARM_1
      007018 F0               [24]  731 	movx	@dptr,a
      007019 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      00701B 12 38 70         [24]  733 	lcall	_ak820_outline_0093
      00701E 12 76 C6         [24]  734 	lcall	_ak820_outline_0070
      007021 90 08 16         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      007024 F5 F0            [12]  736 	mov	b,a
      007026 12 B7 00         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:132: record.tap.count = 0;
      007029 90 08 1C         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      00702C E0               [24]  740 	movx	a,@dptr
      00702D 54 0F            [12]  741 	anl	a,#0x0f
      00702F F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:137: record.keycode = 0;
      007030 90 08 1D         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      007033 12 4F 3C         [24]  745 	lcall	_ak820_outline_0182
                                    746 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007036 90 08 1A         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      007039 E0               [24]  748 	movx	a,@dptr
      00703A 60 0D            [24]  749 	jz	00107$
      00703C 90 08 16         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      00703F 75 F0 00         [24]  751 	mov	b, #0x00
      007042 12 9E 33         [24]  752 	lcall	_pre_process_record_quantum
      007045 E5 82            [12]  753 	mov	a, dpl
      007047 60 14            [24]  754 	jz	00110$
      007049                        755 00107$:
                                    756 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      007049 90 08 16         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      00704C 12 45 3A         [24]  758 	lcall	_ak820_tapping_process
      00704F E5 82            [12]  759 	mov	a, dpl
      007051 70 01            [24]  760 	jnz	00106$
      007053 22               [24]  761 	ret
      007054                        762 00106$:
                                    763 ;	quantum/action.c:175: process_record(&record);
      007054 90 08 16         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      007057 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:190: }
      00705A 02 70 9A         [24]  767 	ljmp	_process_record
      00705D                        768 00110$:
      00705D 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      00705E                        780 _ak820_action_exec:
      00705E 12 38 82         [24]  781 	lcall	_ak820_outline_0107
      007061 90 08 1F         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      007064 12 38 87         [24]  783 	lcall	_ak820_outline_0108
                                    784 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      007067 90 08 1F         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      00706A 12 38 64         [24]  786 	lcall	_ak820_outline_0079
      00706D 7F 00            [12]  787 	mov	r7,#0x00
      00706F 90 0D 98         [24]  788 	mov	dptr,#___memcpy_PARM_2
      007072 ED               [12]  789 	mov	a,r5
      007073 12 38 29         [24]  790 	lcall	_ak820_outline_0017
      007076 12 76 C6         [24]  791 	lcall	_ak820_outline_0070
      007079 90 08 21         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      00707C F5 F0            [12]  793 	mov	b,a
      00707E 12 B7 00         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:197: action_exec(snapshot);
      007081 90 0D 98         [24]  796 	mov	dptr,#___memcpy_PARM_2
      007084 74 21            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      007086 F0               [24]  798 	movx	@dptr,a
      007087 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      007089 12 38 70         [24]  800 	lcall	_ak820_outline_0093
      00708C 12 76 C6         [24]  801 	lcall	_ak820_outline_0070
      00708F 90 08 10         [24]  802 	mov	dptr,#_action_exec_PARM_1
      007092 F5 F0            [12]  803 	mov	b,a
      007094 12 B7 00         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:198: }
      007097 02 6F F6         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      00709A                        816 _process_record:
      00709A 12 43 13         [24]  817 	lcall	_ak820_outline_0037
      00709D 90 08 27         [24]  818 	mov	dptr,#_process_record_record_10000_632
      0070A0 12 38 29         [24]  819 	lcall	_ak820_outline_0017
                                    820 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      0070A3 90 08 27         [24]  821 	mov	dptr,#_process_record_record_10000_632
      0070A6 12 4E E9         [24]  822 	lcall	_ak820_outline_0011
      0070A9 74 04            [12]  823 	mov	a,#0x04
      0070AB 12 76 99         [24]  824 	lcall	_ak820_outline_0013
      0070AE 12 B7 D9         [24]  825 	lcall	__gptrget
      0070B1 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:338: return;
      0070B3 22               [24]  828 	ret
      0070B4                        829 00102$:
                                    830 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0070B4 8D 02            [24]  831 	mov	ar2,r5
      0070B6 8E 03            [24]  832 	mov	ar3,r6
      0070B8 8F 04            [24]  833 	mov	ar4,r7
      0070BA 90 0D 98         [24]  834 	mov	dptr,#___memcpy_PARM_2
      0070BD EA               [12]  835 	mov	a,r2
      0070BE 12 77 0D         [24]  836 	lcall	_ak820_outline_0187
      0070C1 EC               [12]  837 	mov	a,r4
      0070C2 A3               [24]  838 	inc	dptr
      0070C3 F0               [24]  839 	movx	@dptr,a
      0070C4 90 0D 9B         [24]  840 	mov	dptr,#___memcpy_PARM_3
      0070C7 12 4F 2E         [24]  841 	lcall	_ak820_outline_0110
      0070CA 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      0070CD F5 F0            [12]  843 	mov	b,a
      0070CF C0 07            [24]  844 	push	ar7
      0070D1 C0 06            [24]  845 	push	ar6
      0070D3 C0 05            [24]  846 	push	ar5
      0070D5 12 B7 00         [24]  847 	lcall	___memcpy
      0070D8 12 43 8D         [24]  848 	lcall	_ak820_tapping_source
      0070DB AC 82            [24]  849 	mov	r4, dpl
      0070DD D0 05            [24]  850 	pop	ar5
      0070DF D0 06            [24]  851 	pop	ar6
      0070E1 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      0070E3 74 05            [12]  854 	mov	a,#0x05
      0070E5 12 76 8B         [24]  855 	lcall	_ak820_outline_0012
      0070E8 12 B7 D9         [24]  856 	lcall	__gptrget
      0070EB FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      0070EC 12 76 F2         [24]  859 	lcall	_ak820_outline_0146
      0070EF 90 0B F4         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      0070F2 74 01            [12]  861 	mov	a,#0x01
      0070F4 12 4E F2         [24]  862 	lcall	_ak820_outline_0034
      0070F7 C0 04            [24]  863 	push	ar4
      0070F9 C0 03            [24]  864 	push	ar3
      0070FB C0 02            [24]  865 	push	ar2
      0070FD C0 01            [24]  866 	push	ar1
      0070FF C0 00            [24]  867 	push	ar0
      007101 12 9D F5         [24]  868 	lcall	_get_record_keycode
      007104 12 43 5C         [24]  869 	lcall	_ak820_outline_0133
      007107 D0 00            [24]  870 	pop	ar0
      007109 D0 01            [24]  871 	pop	ar1
      00710B D0 02            [24]  872 	pop	ar2
      00710D D0 03            [24]  873 	pop	ar3
      00710F D0 04            [24]  874 	pop	ar4
      007111 12 48 B2         [24]  875 	lcall	_ak820_outline_0112
      007114 EE               [12]  876 	mov	a,r6
      007115 12 B7 9E         [24]  877 	lcall	__gptrput
      007118 A3               [24]  878 	inc	dptr
      007119 EF               [12]  879 	mov	a,r7
      00711A 12 B7 9E         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00711D 90 08 27         [24]  882 	mov	dptr,#_process_record_record_10000_632
      007120 12 4E E9         [24]  883 	lcall	_ak820_outline_0011
      007123 12 76 F2         [24]  884 	lcall	_ak820_outline_0146
      007126 12 48 B2         [24]  885 	lcall	_ak820_outline_0112
      007129 12 B7 D9         [24]  886 	lcall	__gptrget
      00712C F8               [12]  887 	mov	r0,a
      00712D A3               [24]  888 	inc	dptr
      00712E 12 B7 D9         [24]  889 	lcall	__gptrget
      007131 F9               [12]  890 	mov	r1,a
      007132 90 06 34         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007135 EC               [12]  892 	mov	a,r4
      007136 F0               [24]  893 	movx	@dptr,a
      007137 90 06 35         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00713A EB               [12]  895 	mov	a,r3
      00713B F0               [24]  896 	movx	@dptr,a
      00713C 12 38 B6         [24]  897 	lcall	_ak820_outline_0157
      00713F C0 07            [24]  898 	push	ar7
      007141 C0 06            [24]  899 	push	ar6
      007143 C0 05            [24]  900 	push	ar5
      007145 C0 04            [24]  901 	push	ar4
      007147 C0 03            [24]  902 	push	ar3
      007149 12 46 EC         [24]  903 	lcall	_ak820_oneshot_process
      00714C E5 82            [12]  904 	mov	a, dpl
      00714E D0 03            [24]  905 	pop	ar3
      007150 D0 04            [24]  906 	pop	ar4
      007152 D0 05            [24]  907 	pop	ar5
      007154 D0 06            [24]  908 	pop	ar6
      007156 D0 07            [24]  909 	pop	ar7
      007158 70 01            [24]  910 	jnz	00104$
      00715A 22               [24]  911 	ret
      00715B                        912 00104$:
                                    913 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      00715B 12 6D 59         [24]  914 	lcall	_ak820_outline_0057
      00715E C0 04            [24]  915 	push	ar4
      007160 C0 03            [24]  916 	push	ar3
      007162 12 9E BF         [24]  917 	lcall	_process_record_quantum
      007165 E5 82            [12]  918 	mov	a, dpl
      007167 D0 03            [24]  919 	pop	ar3
      007169 D0 04            [24]  920 	pop	ar4
      00716B 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00716D 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007170 EB               [12]  924 	mov	a,r3
      007171 F0               [24]  925 	movx	@dptr,a
      007172 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:360: return;
      007174 02 2E BB         [24]  928 	ljmp	_ak820_oneshot_post
      007177                        929 00106$:
                                    930 ;	quantum/action.c:366: process_record_handler(record);
      007177 90 08 27         [24]  931 	mov	dptr,#_process_record_record_10000_632
      00717A 12 4E C3         [24]  932 	lcall	_ak820_outline_0001
      00717D C0 04            [24]  933 	push	ar4
      00717F C0 03            [24]  934 	push	ar3
      007181 12 71 9B         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:370: post_process_record_quantum(record);
      007184 90 08 27         [24]  937 	mov	dptr,#_process_record_record_10000_632
      007187 12 4E C3         [24]  938 	lcall	_ak820_outline_0001
      00718A 12 9E 94         [24]  939 	lcall	_post_process_record_quantum
      00718D D0 03            [24]  940 	pop	ar3
      00718F D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007191 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007194 EB               [12]  944 	mov	a,r3
      007195 F0               [24]  945 	movx	@dptr,a
      007196 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:374: }
      007198 02 2E BB         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      00719B                        960 _process_record_handler:
      00719B 12 43 13         [24]  961 	lcall	_ak820_outline_0037
      00719E 90 08 2A         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0071A1 12 38 29         [24]  963 	lcall	_ak820_outline_0017
                                    964 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071A4 90 08 2A         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0071A7 12 37 FE         [24]  966 	lcall	_ak820_outline_0007
                                    967 ;	quantum/action.c:387: if (record->keycode) {
      0071AA 4C               [12]  968 	orl	a,r4
      0071AB 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      0071AD 12 38 97         [24]  971 	lcall	_ak820_outline_0124
      0071B0 C0 07            [24]  972 	push	ar7
      0071B2 C0 06            [24]  973 	push	ar6
      0071B4 12 94 31         [24]  974 	lcall	_action_for_keycode
      0071B7 12 43 6D         [24]  975 	lcall	_ak820_outline_0149
      0071BA D0 06            [24]  976 	pop	ar6
      0071BC D0 07            [24]  977 	pop	ar7
      0071BE 90 08 2D         [24]  978 	mov	dptr,#_process_record_handler_action_10000_641
      0071C1 12 38 5E         [24]  979 	lcall	_ak820_outline_0072
      0071C4 80 2B            [24]  980 	sjmp	00104$
      0071C6                        981 00102$:
                                    982 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0071C6 12 76 A7         [24]  983 	lcall	_ak820_outline_0021
      0071C9 7A 00            [12]  984 	mov	r2,#0x00
      0071CB 12 43 67         [24]  985 	lcall	_ak820_outline_0142
      0071CE 12 43 01         [24]  986 	lcall	_ak820_outline_0010
      0071D1 E0               [24]  987 	movx	a,@dptr
      0071D2 90 09 69         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      0071D5 F0               [24]  989 	movx	@dptr,a
      0071D6 8D 82            [24]  990 	mov	dpl, r5
      0071D8 8C 83            [24]  991 	mov	dph, r4
      0071DA C0 07            [24]  992 	push	ar7
      0071DC C0 06            [24]  993 	push	ar6
      0071DE 12 7A 4E         [24]  994 	lcall	_ak820_resolve_key
      0071E1 12 94 31         [24]  995 	lcall	_action_for_keycode
      0071E4 12 43 6D         [24]  996 	lcall	_ak820_outline_0149
      0071E7 D0 06            [24]  997 	pop	ar6
      0071E9 D0 07            [24]  998 	pop	ar7
      0071EB 90 08 2D         [24]  999 	mov	dptr,#_process_record_handler_action_10000_641
      0071EE 12 38 5E         [24] 1000 	lcall	_ak820_outline_0072
                                   1001 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      0071F1                       1002 00104$:
                                   1003 ;	quantum/action.c:411: process_action(record, action);
      0071F1 7D 00            [12] 1004 	mov	r5,#0x00
      0071F3 90 0D 98         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      0071F6 74 2D            [12] 1006 	mov	a,#_process_record_handler_action_10000_641
      0071F8 F0               [24] 1007 	movx	@dptr,a
      0071F9 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      0071FB 12 38 70         [24] 1009 	lcall	_ak820_outline_0093
      0071FE 90 0D 9B         [24] 1010 	mov	dptr,#___memcpy_PARM_3
      007201 12 4F 2E         [24] 1011 	lcall	_ak820_outline_0110
      007204 90 08 2F         [24] 1012 	mov	dptr,#_process_action_PARM_2
      007207 F5 F0            [12] 1013 	mov	b,a
      007209 C0 07            [24] 1014 	push	ar7
      00720B C0 06            [24] 1015 	push	ar6
      00720D C0 05            [24] 1016 	push	ar5
      00720F 12 B7 00         [24] 1017 	lcall	___memcpy
      007212 D0 05            [24] 1018 	pop	ar5
      007214 D0 06            [24] 1019 	pop	ar6
      007216 D0 07            [24] 1020 	pop	ar7
      007218 12 6F 6E         [24] 1021 	lcall	_ak820_outline_0064
                                   1022 ;	quantum/action.c:412: }
      00721B 02 72 1E         [24] 1023 	ljmp	_process_action
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'register_mouse'
                                   1026 ;------------------------------------------------------------
                                   1027 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1028 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_action
                                   1033 ;	-----------------------------------------
      00721E                       1034 _process_action:
      00721E 12 43 13         [24] 1035 	lcall	_ak820_outline_0037
      007221 90 08 31         [24] 1036 	mov	dptr,#_process_action_record_argument_10000_652
      007224 12 38 29         [24] 1037 	lcall	_ak820_outline_0017
                                   1038 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007227 90 08 31         [24] 1039 	mov	dptr,#_process_action_record_argument_10000_652
      00722A 12 37 F4         [24] 1040 	lcall	_ak820_outline_0005
                                   1041 ;	quantum/action.c:483: pressed = record->event.pressed;
      00722D A3               [24] 1042 	inc	dptr
      00722E A3               [24] 1043 	inc	dptr
      00722F A3               [24] 1044 	inc	dptr
      007230 A3               [24] 1045 	inc	dptr
      007231 A3               [24] 1046 	inc	dptr
      007232 E0               [24] 1047 	movx	a,@dptr
      007233 F5 27            [12] 1048 	mov	_process_action_sloc0_1_0,a
                                   1049 ;	quantum/action.c:507: switch (action.kind.id) {
      007235 90 08 30         [24] 1050 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007238 E0               [24] 1051 	movx	a,@dptr
      007239 C4               [12] 1052 	swap	a
      00723A 54 0F            [12] 1053 	anl	a,#0x0f
      00723C FD               [12] 1054 	mov  r5,a
      00723D 24 F4            [12] 1055 	add	a,#0xff - 0x0b
      00723F 50 03            [24] 1056 	jnc	00434$
      007241 02 74 BF         [24] 1057 	ljmp	00181$
      007244                       1058 00434$:
                                   1059 ;	free result
      007244 ED               [12] 1060 	mov	a,r5
      007245 24 0A            [12] 1061 	add	a,#(00435$-3-.)
      007247 83               [24] 1062 	movc	a,@a+pc
      007248 F5 82            [12] 1063 	mov	dpl,a
      00724A ED               [12] 1064 	mov	a,r5
      00724B 24 10            [12] 1065 	add	a,#(00436$-3-.)
      00724D 83               [24] 1066 	movc	a,@a+pc
      00724E F5 83            [12] 1067 	mov	dph,a
      007250 E4               [12] 1068 	clr	a
      007251 73               [24] 1069 	jmp	@a+dptr
      007252                       1070 00435$:
      007252 6A                    1071 	.db	00102$
      007253 6A                    1072 	.db	00102$
      007254 BF                    1073 	.db	00181$
      007255 BF                    1074 	.db	00181$
      007256 F4                    1075 	.db	00123$
      007257 BF                    1076 	.db	00181$
      007258 BF                    1077 	.db	00181$
      007259 BF                    1078 	.db	00181$
      00725A 54                    1079 	.db	00131$
      00725B 26                    1080 	.db	00147$
      00725C 4C                    1081 	.db	00152$
      00725D 4C                    1082 	.db	00152$
      00725E                       1083 00436$:
      00725E 72                    1084 	.db	00102$>>8
      00725F 72                    1085 	.db	00102$>>8
      007260 74                    1086 	.db	00181$>>8
      007261 74                    1087 	.db	00181$>>8
      007262 72                    1088 	.db	00123$>>8
      007263 74                    1089 	.db	00181$>>8
      007264 74                    1090 	.db	00181$>>8
      007265 74                    1091 	.db	00181$>>8
      007266 73                    1092 	.db	00131$>>8
      007267 74                    1093 	.db	00147$>>8
      007268 74                    1094 	.db	00152$>>8
      007269 74                    1095 	.db	00152$>>8
                                   1096 ;	quantum/action.c:510: case ACT_RMODS: {
      00726A                       1097 00102$:
                                   1098 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00726A 90 08 30         [24] 1099 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00726D E0               [24] 1100 	movx	a,@dptr
      00726E 54 F0            [12] 1101 	anl	a,#0xf0
      007270 70 06            [24] 1102 	jnz	00194$
      007272 12 76 E0         [24] 1103 	lcall	_ak820_outline_0113
      007275 FD               [12] 1104 	mov	r5,a
      007276 80 07            [24] 1105 	sjmp	00195$
      007278                       1106 00194$:
      007278 12 76 E0         [24] 1107 	lcall	_ak820_outline_0113
      00727B C4               [12] 1108 	swap	a
      00727C 54 F0            [12] 1109 	anl	a,#0xf0
      00727E FD               [12] 1110 	mov	r5,a
      00727F                       1111 00195$:
                                   1112 ;	quantum/action.c:513: if (pressed) {
      00727F E5 27            [12] 1113 	mov	a,_process_action_sloc0_1_0
      007281 60 35            [24] 1114 	jz	00119$
                                   1115 ;	quantum/action.c:514: if (mods) {
      007283 ED               [12] 1116 	mov	a,r5
      007284 60 29            [24] 1117 	jz	00110$
                                   1118 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007286 12 76 FC         [24] 1119 	lcall	_ak820_outline_0159
      007289 FC               [12] 1120 	mov	r4,a
      00728A BC E0 00         [24] 1121 	cjne	r4,#0xe0,00440$
      00728D                       1122 00440$:
      00728D 40 07            [24] 1123 	jc	00108$
      00728F 12 76 FC         [24] 1124 	lcall	_ak820_outline_0159
      007292 24 18            [12] 1125 	add	a,#0xff - 0xe7
      007294 50 0A            [24] 1126 	jnc	00104$
                                   1127 ;	free result
      007296                       1128 00108$:
      007296 7B 2F            [12] 1129 	mov	r3,#_process_action_PARM_2
      007298 7C 08            [12] 1130 	mov	r4,#(_process_action_PARM_2 >> 8)
      00729A 12 33 FC         [24] 1131 	lcall	_ak820_outline_0123
      00729D E0               [24] 1132 	movx	a,@dptr
      00729E 70 07            [24] 1133 	jnz	00105$
      0072A0                       1134 00104$:
                                   1135 ;	quantum/action.c:519: add_owned_mods(mods);
      0072A0 8D 82            [24] 1136 	mov	dpl, r5
      0072A2 12 7C 68         [24] 1137 	lcall	_add_owned_mods
      0072A5 80 05            [24] 1138 	sjmp	00106$
      0072A7                       1139 00105$:
                                   1140 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0072A7 8D 82            [24] 1141 	mov	dpl, r5
      0072A9 12 7C 87         [24] 1142 	lcall	_add_owned_weak_mods
      0072AC                       1143 00106$:
                                   1144 ;	quantum/action.c:523: send_keyboard_report();
      0072AC 12 7F A2         [24] 1145 	lcall	_send_keyboard_report
      0072AF                       1146 00110$:
                                   1147 ;	quantum/action.c:525: register_code(action.key.code);
      0072AF 12 76 D0         [24] 1148 	lcall	_ak820_outline_0078
      0072B2 12 74 D6         [24] 1149 	lcall	_register_code
      0072B5 02 74 BF         [24] 1150 	ljmp	00181$
      0072B8                       1151 00119$:
                                   1152 ;	quantum/action.c:527: unregister_code(action.key.code);
      0072B8 12 76 D0         [24] 1153 	lcall	_ak820_outline_0078
      0072BB C0 05            [24] 1154 	push	ar5
      0072BD 12 75 43         [24] 1155 	lcall	_unregister_code
      0072C0 D0 05            [24] 1156 	pop	ar5
                                   1157 ;	quantum/action.c:528: if (mods) {
      0072C2 ED               [12] 1158 	mov	a,r5
      0072C3 70 03            [24] 1159 	jnz	00444$
      0072C5 02 74 BF         [24] 1160 	ljmp	00181$
      0072C8                       1161 00444$:
                                   1162 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072C8 12 76 FC         [24] 1163 	lcall	_ak820_outline_0159
      0072CB FC               [12] 1164 	mov	r4,a
      0072CC BC E0 00         [24] 1165 	cjne	r4,#0xe0,00445$
      0072CF                       1166 00445$:
      0072CF 40 07            [24] 1167 	jc	00115$
      0072D1 12 76 FC         [24] 1168 	lcall	_ak820_outline_0159
      0072D4 24 18            [12] 1169 	add	a,#0xff - 0xe7
      0072D6 50 0A            [24] 1170 	jnc	00111$
                                   1171 ;	free result
      0072D8                       1172 00115$:
      0072D8 7B 2F            [12] 1173 	mov	r3,#_process_action_PARM_2
      0072DA 7C 08            [12] 1174 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072DC 12 33 FC         [24] 1175 	lcall	_ak820_outline_0123
      0072DF E0               [24] 1176 	movx	a,@dptr
      0072E0 70 07            [24] 1177 	jnz	00112$
      0072E2                       1178 00111$:
                                   1179 ;	quantum/action.c:530: del_owned_mods(mods);
      0072E2 8D 82            [24] 1180 	mov	dpl, r5
      0072E4 12 7C 78         [24] 1181 	lcall	_del_owned_mods
      0072E7 80 05            [24] 1182 	sjmp	00113$
      0072E9                       1183 00112$:
                                   1184 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      0072E9 8D 82            [24] 1185 	mov	dpl, r5
      0072EB 12 7C 97         [24] 1186 	lcall	_del_owned_weak_mods
      0072EE                       1187 00113$:
                                   1188 ;	quantum/action.c:534: send_keyboard_report();
      0072EE 12 7F A2         [24] 1189 	lcall	_send_keyboard_report
                                   1190 ;	quantum/action.c:537: } break;
      0072F1 02 74 BF         [24] 1191 	ljmp	00181$
                                   1192 ;	quantum/action.c:614: case ACT_USAGE:
      0072F4                       1193 00123$:
                                   1194 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0072F4 74 07            [12] 1195 	mov	a,#0x07
      0072F6 12 38 31         [24] 1196 	lcall	_ak820_outline_0022
      0072F9 12 48 26         [24] 1197 	lcall	_ak820_outline_0008
      0072FC C3               [12] 1198 	clr	c
      0072FD EC               [12] 1199 	mov	a,r4
      0072FE 94 A5            [12] 1200 	subb	a,#0xa5
      007300 ED               [12] 1201 	mov	a,r5
      007301 94 00            [12] 1202 	subb	a,#0x00
      007303 40 15            [24] 1203 	jc	00125$
      007305 74 C2            [12] 1204 	mov	a,#0xc2
      007307 9C               [12] 1205 	subb	a,r4
      007308 E4               [12] 1206 	clr	a
      007309 9D               [12] 1207 	subb	a,r5
      00730A 40 0E            [24] 1208 	jc	00125$
                                   1209 ;	free result
                                   1210 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      00730C 90 0A 90         [24] 1211 	mov	dptr,#_owned_usage_key_PARM_2
      00730F E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      007311 F0               [24] 1213 	movx	@dptr,a
      007312 8E 82            [24] 1214 	mov	dpl, r6
      007314 12 7E 4D         [24] 1215 	lcall	_owned_usage_key
                                   1216 ;	quantum/action.c:622: break;
      007317 02 74 BF         [24] 1217 	ljmp	00181$
      00731A                       1218 00125$:
                                   1219 ;	quantum/action.c:625: switch (action.usage.page) {
      00731A 12 76 D7         [24] 1220 	lcall	_ak820_outline_0089
      00731D FF               [12] 1221 	mov	r7,a
      00731E 60 08            [24] 1222 	jz	00127$
      007320 BF 01 02         [24] 1223 	cjne	r7,#0x01,00452$
      007323 80 19            [24] 1224 	sjmp	00128$
      007325                       1225 00452$:
      007325 02 74 BF         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007328                       1228 00127$:
                                   1229 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007328 E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      00732A 60 05            [24] 1231 	jz	00196$
      00732C 12 76 E7         [24] 1232 	lcall	_ak820_outline_0130
      00732F 80 04            [24] 1233 	sjmp	00197$
      007331                       1234 00196$:
      007331 7E 00            [12] 1235 	mov	r6,#0x00
      007333 7F 00            [12] 1236 	mov	r7,#0x00
      007335                       1237 00197$:
      007335 12 38 8C         [24] 1238 	lcall	_ak820_outline_0118
      007338 12 6C E3         [24] 1239 	lcall	_host_system_send
                                   1240 ;	quantum/action.c:628: break;
      00733B 02 74 BF         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:629: case PAGE_CONSUMER:
      00733E                       1243 00128$:
                                   1244 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      00733E E5 27            [12] 1245 	mov	a,_process_action_sloc0_1_0
      007340 60 05            [24] 1246 	jz	00198$
      007342 12 76 E7         [24] 1247 	lcall	_ak820_outline_0130
      007345 80 04            [24] 1248 	sjmp	00199$
      007347                       1249 00198$:
      007347 7E 00            [12] 1250 	mov	r6,#0x00
      007349 7F 00            [12] 1251 	mov	r7,#0x00
      00734B                       1252 00199$:
      00734B 12 38 8C         [24] 1253 	lcall	_ak820_outline_0118
      00734E 12 6D 13         [24] 1254 	lcall	_host_consumer_send
                                   1255 ;	quantum/action.c:633: break;
      007351 02 74 BF         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:640: case ACT_LAYER: {
      007354                       1258 00131$:
                                   1259 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      007354 90 08 30         [24] 1260 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007357 E0               [24] 1261 	movx	a,@dptr
      007358 54 03            [12] 1262 	anl	a,#0x03
      00735A 90 08 34         [24] 1263 	mov	dptr,#_process_action_on_40000_675
      00735D F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00735E E0               [24] 1266 	movx	a,@dptr
      00735F FF               [12] 1267 	mov	r7,a
      007360 60 11            [24] 1268 	jz	00200$
      007362 E5 27            [12] 1269 	mov	a,_process_action_sloc0_1_0
      007364 60 07            [24] 1270 	jz	00202$
      007366 8F 06            [24] 1271 	mov	ar6,r7
      007368 53 06 01         [24] 1272 	anl	ar6,#0x01
      00736B 80 10            [24] 1273 	sjmp	00201$
      00736D                       1274 00202$:
      00736D 74 02            [12] 1275 	mov	a,#0x02
      00736F 5F               [12] 1276 	anl	a,r7
      007370 FE               [12] 1277 	mov	r6,a
      007371 80 0A            [24] 1278 	sjmp	00201$
      007373                       1279 00200$:
      007373 E5 27            [12] 1280 	mov	a,_process_action_sloc0_1_0
      007375 B4 01 00         [24] 1281 	cjne	a,#0x01,00457$
      007378                       1282 00457$:
      007378 92 1F            [24] 1283 	mov  _process_action_sloc1_1_0,c
      00737A E4               [12] 1284 	clr	a
      00737B 33               [12] 1285 	rlc	a
      00737C FE               [12] 1286 	mov	r6,a
      00737D                       1287 00201$:
      00737D EE               [12] 1288 	mov	a,r6
      00737E 70 03            [24] 1289 	jnz	00458$
      007380 02 74 BF         [24] 1290 	ljmp	00181$
      007383                       1291 00458$:
                                   1292 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      007383 12 76 FC         [24] 1293 	lcall	_ak820_outline_0159
      007386 C4               [12] 1294 	swap	a
      007387 03               [12] 1295 	rr	a
      007388 54 07            [12] 1296 	anl	a,#0x07
      00738A 25 E0            [12] 1297 	add	a,acc
      00738C 25 E0            [12] 1298 	add	a,acc
      00738E FF               [12] 1299 	mov	r7,a
                                   1300 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00738F 12 76 FC         [24] 1301 	lcall	_ak820_outline_0159
      007392 54 0F            [12] 1302 	anl	a,#0x0f
      007394 FE               [12] 1303 	mov	r6,a
      007395 8F F0            [24] 1304 	mov	b,r7
      007397 05 F0            [12] 1305 	inc	b
      007399 EE               [12] 1306 	mov	a,r6
      00739A 80 02            [24] 1307 	sjmp	00460$
      00739C                       1308 00459$:
      00739C 25 E0            [12] 1309 	add	a,acc
      00739E                       1310 00460$:
      00739E D5 F0 FB         [24] 1311 	djnz	b,00459$
      0073A1 FE               [12] 1312 	mov	r6,a
                                   1313 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0073A2 12 76 FC         [24] 1314 	lcall	_ak820_outline_0159
      0073A5 30 E4 11         [24] 1315 	jnb	acc.4,00204$
      0073A8 8F F0            [24] 1316 	mov	b,r7
      0073AA 05 F0            [12] 1317 	inc	b
      0073AC 74 0F            [12] 1318 	mov	a,#0x0f
      0073AE 80 02            [24] 1319 	sjmp	00463$
      0073B0                       1320 00462$:
      0073B0 25 E0            [12] 1321 	add	a,acc
      0073B2                       1322 00463$:
      0073B2 D5 F0 FB         [24] 1323 	djnz	b,00462$
      0073B5 F4               [12] 1324 	cpl	a
      0073B6 FF               [12] 1325 	mov	r7,a
      0073B7 80 02            [24] 1326 	sjmp	00205$
      0073B9                       1327 00204$:
      0073B9 7F 00            [12] 1328 	mov	r7,#0x00
      0073BB                       1329 00205$:
                                   1330 ;	quantum/action.c:648: bits |= mask;
      0073BB EE               [12] 1331 	mov	a,r6
      0073BC 42 07            [12] 1332 	orl	ar7,a
                                   1333 ;	quantum/action.c:649: if (!on) {
      0073BE 90 08 34         [24] 1334 	mov	dptr,#_process_action_on_40000_675
      0073C1 E0               [24] 1335 	movx	a,@dptr
      0073C2 70 31            [24] 1336 	jnz	00143$
                                   1337 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0073C4 12 76 D7         [24] 1338 	lcall	_ak820_outline_0089
      0073C7 FE               [12] 1339 	mov	r6,a
      0073C8 2E               [12] 1340 	add	a,r6
                                   1341 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0073C9 90 73 CD         [24] 1342 	mov	dptr,#00465$
      0073CC 73               [24] 1343 	jmp	@a+dptr
      0073CD                       1344 00465$:
      0073CD 80 06            [24] 1345 	sjmp	00132$
      0073CF 80 0C            [24] 1346 	sjmp	00133$
      0073D1 80 12            [24] 1347 	sjmp	00134$
      0073D3 80 18            [24] 1348 	sjmp	00135$
      0073D5                       1349 00132$:
      0073D5 8F 82            [24] 1350 	mov	dpl, r7
      0073D7 12 77 5C         [24] 1351 	lcall	_default_layer_and
      0073DA 02 74 BF         [24] 1352 	ljmp	00181$
                                   1353 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      0073DD                       1354 00133$:
      0073DD 8F 82            [24] 1355 	mov	dpl, r7
      0073DF 12 77 4B         [24] 1356 	lcall	_default_layer_or
      0073E2 02 74 BF         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      0073E5                       1359 00134$:
      0073E5 8F 82            [24] 1360 	mov	dpl, r7
      0073E7 12 77 72         [24] 1361 	lcall	_default_layer_xor
      0073EA 02 74 BF         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      0073ED                       1364 00135$:
      0073ED 8F 82            [24] 1365 	mov	dpl, r7
      0073EF 12 77 40         [24] 1366 	lcall	_default_layer_set
                                   1367 ;	quantum/action.c:655: }
      0073F2 02 74 BF         [24] 1368 	ljmp	00181$
      0073F5                       1369 00143$:
                                   1370 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      0073F5 12 76 D7         [24] 1371 	lcall	_ak820_outline_0089
      0073F8 FE               [12] 1372 	mov	r6,a
      0073F9 2E               [12] 1373 	add	a,r6
                                   1374 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      0073FA 90 73 FE         [24] 1375 	mov	dptr,#00466$
      0073FD 73               [24] 1376 	jmp	@a+dptr
      0073FE                       1377 00466$:
      0073FE 80 06            [24] 1378 	sjmp	00137$
      007400 80 0C            [24] 1379 	sjmp	00138$
      007402 80 12            [24] 1380 	sjmp	00139$
      007404 80 18            [24] 1381 	sjmp	00140$
      007406                       1382 00137$:
      007406 8F 82            [24] 1383 	mov	dpl, r7
      007408 12 78 F6         [24] 1384 	lcall	_layer_and
      00740B 02 74 BF         [24] 1385 	ljmp	00181$
                                   1386 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      00740E                       1387 00138$:
      00740E 8F 82            [24] 1388 	mov	dpl, r7
      007410 12 78 E5         [24] 1389 	lcall	_layer_or
      007413 02 74 BF         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007416                       1392 00139$:
      007416 8F 82            [24] 1393 	mov	dpl, r7
      007418 12 79 0C         [24] 1394 	lcall	_layer_xor
      00741B 02 74 BF         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      00741E                       1397 00140$:
      00741E 8F 82            [24] 1398 	mov	dpl, r7
      007420 12 78 82         [24] 1399 	lcall	_layer_state_set
                                   1400 ;	quantum/action.c:665: break;
      007423 02 74 BF         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007426                       1403 00147$:
                                   1404 ;	quantum/action.c:668: if (pressed) {
      007426 E5 27            [12] 1405 	mov	a,_process_action_sloc0_1_0
      007428 60 11            [24] 1406 	jz	00149$
                                   1407 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      00742A 12 76 E0         [24] 1408 	lcall	_ak820_outline_0113
      00742D F5 82            [12] 1409 	mov	dpl,a
      00742F 12 77 E2         [24] 1410 	lcall	_layer_hold_on
                                   1411 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007432 12 76 D0         [24] 1412 	lcall	_ak820_outline_0078
      007435 12 75 F9         [24] 1413 	lcall	_register_mods
      007438 02 74 BF         [24] 1414 	ljmp	00181$
      00743B                       1415 00149$:
                                   1416 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      00743B 12 76 D0         [24] 1417 	lcall	_ak820_outline_0078
      00743E 12 76 0D         [24] 1418 	lcall	_unregister_mods
                                   1419 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007441 12 76 E0         [24] 1420 	lcall	_ak820_outline_0113
      007444 F5 82            [12] 1421 	mov	dpl,a
      007446 12 78 1A         [24] 1422 	lcall	_layer_hold_off
                                   1423 ;	quantum/action.c:675: break;
      007449 02 74 BF         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      00744C                       1426 00152$:
                                   1427 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      00744C 12 76 FC         [24] 1428 	lcall	_ak820_outline_0159
      00744F FF               [12] 1429 	mov	r7,a
      007450 BF F1 02         [24] 1430 	cjne	r7,#0xf1,00468$
      007453 80 0A            [24] 1431 	sjmp	00154$
      007455                       1432 00468$:
      007455 BF F2 02         [24] 1433 	cjne	r7,#0xf2,00469$
      007458 80 19            [24] 1434 	sjmp	00155$
      00745A                       1435 00469$:
                                   1436 ;	quantum/action.c:694: momentary_layer_action:
      00745A BF F3 3B         [24] 1437 	cjne	r7,#0xf3,00160$
      00745D 80 28            [24] 1438 	sjmp	00156$
      00745F                       1439 00154$:
                                   1440 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00745F E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      007461 60 08            [24] 1442 	jz	00206$
      007463 12 76 B6         [24] 1443 	lcall	_ak820_outline_0042
      007466 12 77 E2         [24] 1444 	lcall	_layer_hold_on
      007469 80 54            [24] 1445 	sjmp	00181$
      00746B                       1446 00206$:
      00746B 12 76 B6         [24] 1447 	lcall	_ak820_outline_0042
      00746E 12 78 1A         [24] 1448 	lcall	_layer_hold_off
                                   1449 ;	quantum/action.c:696: break;
                                   1450 ;	quantum/action.c:697: case OP_OFF_ON:
      007471 80 4C            [24] 1451 	sjmp	00181$
      007473                       1452 00155$:
                                   1453 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007473 E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      007475 60 08            [24] 1455 	jz	00208$
      007477 12 76 B6         [24] 1456 	lcall	_ak820_outline_0042
      00747A 12 78 C7         [24] 1457 	lcall	_layer_off
      00747D 80 40            [24] 1458 	sjmp	00181$
      00747F                       1459 00208$:
      00747F 12 76 B6         [24] 1460 	lcall	_ak820_outline_0042
      007482 12 78 AC         [24] 1461 	lcall	_layer_on
                                   1462 ;	quantum/action.c:699: break;
                                   1463 ;	quantum/action.c:700: case OP_SET_CLEAR:
      007485 80 38            [24] 1464 	sjmp	00181$
      007487                       1465 00156$:
                                   1466 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007487 E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      007489 60 08            [24] 1468 	jz	00210$
      00748B 12 76 B6         [24] 1469 	lcall	_ak820_outline_0042
      00748E 12 78 96         [24] 1470 	lcall	_layer_move
      007491 80 2C            [24] 1471 	sjmp	00181$
      007493                       1472 00210$:
      007493 12 78 90         [24] 1473 	lcall	_layer_clear
                                   1474 ;	quantum/action.c:702: break;
                                   1475 ;	quantum/action.c:748: default:
      007496 80 27            [24] 1476 	sjmp	00181$
      007498                       1477 00160$:
                                   1478 ;	quantum/action.c:755: if (pressed) {
      007498 E5 27            [12] 1479 	mov	a,_process_action_sloc0_1_0
      00749A 60 08            [24] 1480 	jz	00163$
                                   1481 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      00749C 12 76 D0         [24] 1482 	lcall	_ak820_outline_0078
      00749F 12 74 D6         [24] 1483 	lcall	_register_code
                                   1484 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0074A2 80 1B            [24] 1485 	sjmp	00181$
      0074A4                       1486 00163$:
                                   1487 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0074A4 12 76 FC         [24] 1488 	lcall	_ak820_outline_0159
      0074A7 FF               [12] 1489 	mov	r7,a
      0074A8 BF 39 0E         [24] 1490 	cjne	r7,#0x39,00175$
                                   1491 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0074AB 7F 50            [12] 1492 	mov	r7,#0x50
      0074AD                       1493 00187$:
      0074AD EF               [12] 1494 	mov	a,r7
      0074AE 60 09            [24] 1495 	jz	00175$
      0074B0 90 00 01         [24] 1496 	mov	dptr,#0x0001
      0074B3 12 58 BD         [24] 1497 	lcall	_mDelaymS
      0074B6 1F               [12] 1498 	dec	r7
                                   1499 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0074B7 80 F4            [24] 1500 	sjmp	00187$
      0074B9                       1501 00175$:
                                   1502 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0074B9 12 76 D0         [24] 1503 	lcall	_ak820_outline_0078
      0074BC 12 75 43         [24] 1504 	lcall	_unregister_code
                                   1505 ;	quantum/action.c:848: }
      0074BF                       1506 00181$:
                                   1507 ;	quantum/action.c:869: switch (action.kind.id) {
      0074BF 90 08 30         [24] 1508 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074C2 E0               [24] 1509 	movx	a,@dptr
      0074C3 C4               [12] 1510 	swap	a
      0074C4 54 0F            [12] 1511 	anl	a,#0x0f
      0074C6 FF               [12] 1512 	mov	r7,a
      0074C7 BF 08 02         [24] 1513 	cjne	r7,#0x08,00478$
      0074CA 80 03            [24] 1514 	sjmp	00183$
      0074CC                       1515 00478$:
      0074CC BF 09 06         [24] 1516 	cjne	r7,#0x09,00192$
                                   1517 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      0074CF                       1518 00183$:
                                   1519 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      0074CF 12 6C 48         [24] 1520 	lcall	_host_keyboard_leds
                                   1521 ;	quantum/action.c:880: }
                                   1522 ;	quantum/action.c:933: }
      0074D2 02 96 E6         [24] 1523 	ljmp	_led_set
      0074D5                       1524 00192$:
      0074D5 22               [24] 1525 	ret
                                   1526 ;------------------------------------------------------------
                                   1527 ;Allocation info for local variables in function 'register_code'
                                   1528 ;------------------------------------------------------------
                                   1529 ;code          Allocated with name '_register_code_code_10000_709'
                                   1530 ;------------------------------------------------------------
                                   1531 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1532 ;	-----------------------------------------
                                   1533 ;	 function register_code
                                   1534 ;	-----------------------------------------
      0074D6                       1535 _register_code:
      0074D6 E5 82            [12] 1536 	mov	a,dpl
      0074D8 90 08 35         [24] 1537 	mov	dptr,#_register_code_code_10000_709
      0074DB F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/action.c:940: if (code == KC_NO) {
      0074DC E0               [24] 1540 	movx	a,@dptr
      0074DD FF               [12] 1541 	mov	r7,a
      0074DE 70 01            [24] 1542 	jnz	00123$
                                   1543 ;	quantum/action.c:941: return;
      0074E0 22               [24] 1544 	ret
      0074E1                       1545 00123$:
                                   1546 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      0074E1 BF 04 00         [24] 1547 	cjne	r7,#0x04,00186$
      0074E4                       1548 00186$:
      0074E4 40 12            [24] 1549 	jc	00119$
      0074E6 EF               [12] 1550 	mov	a,r7
      0074E7 24 5B            [12] 1551 	add	a,#0xff - 0xa4
      0074E9 40 0D            [24] 1552 	jc	00119$
                                   1553 ;	free result
                                   1554 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      0074EB 8F 82            [24] 1555 	mov	dpl, r7
      0074ED 12 7D 0C         [24] 1556 	lcall	_add_owned_key
      0074F0 E5 82            [12] 1557 	mov	a, dpl
      0074F2 70 01            [24] 1558 	jnz	00104$
      0074F4 22               [24] 1559 	ret
      0074F5                       1560 00104$:
                                   1561 ;	quantum/action.c:995: send_keyboard_report();
      0074F5 02 7F A2         [24] 1562 	ljmp	_send_keyboard_report
      0074F8                       1563 00119$:
                                   1564 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      0074F8 12 77 01         [24] 1565 	lcall	_ak820_outline_0167
      0074FB BF E0 00         [24] 1566 	cjne	r7,#0xe0,00190$
      0074FE                       1567 00190$:
      0074FE 40 1A            [24] 1568 	jc	00115$
      007500 EF               [12] 1569 	mov	a,r7
      007501 24 18            [12] 1570 	add	a,#0xff - 0xe7
      007503 40 15            [24] 1571 	jc	00115$
                                   1572 ;	free result
                                   1573 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007505 74 07            [12] 1574 	mov	a,#0x07
      007507 5F               [12] 1575 	anl	a,r7
      007508 12 76 BF         [24] 1576 	lcall	_ak820_outline_0061
      00750B 80 02            [24] 1577 	sjmp	00194$
      00750D                       1578 00193$:
      00750D 25 E0            [12] 1579 	add	a,acc
      00750F                       1580 00194$:
      00750F D5 F0 FB         [24] 1581 	djnz	b,00193$
      007512 F5 82            [12] 1582 	mov	dpl,a
      007514 12 7C 68         [24] 1583 	lcall	_add_owned_mods
                                   1584 ;	quantum/action.c:998: send_keyboard_report();
      007517 02 7F A2         [24] 1585 	ljmp	_send_keyboard_report
      00751A                       1586 00115$:
                                   1587 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00751A 12 77 01         [24] 1588 	lcall	_ak820_outline_0167
      00751D BF A5 00         [24] 1589 	cjne	r7,#0xa5,00195$
      007520                       1590 00195$:
      007520 40 05            [24] 1591 	jc	00113$
      007522 EF               [12] 1592 	mov	a,r7
      007523 24 58            [12] 1593 	add	a,#0xff - 0xa7
      007525 50 0D            [24] 1594 	jnc	00108$
                                   1595 ;	free result
      007527                       1596 00113$:
      007527 12 77 01         [24] 1597 	lcall	_ak820_outline_0167
      00752A BF A8 00         [24] 1598 	cjne	r7,#0xa8,00198$
      00752D                       1599 00198$:
      00752D 40 13            [24] 1600 	jc	00125$
      00752F EF               [12] 1601 	mov	a,r7
      007530 24 3D            [12] 1602 	add	a,#0xff - 0xc2
      007532 40 0E            [24] 1603 	jc	00125$
                                   1604 ;	free result
      007534                       1605 00108$:
                                   1606 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007534 12 77 01         [24] 1607 	lcall	_ak820_outline_0167
      007537 90 0A 90         [24] 1608 	mov	dptr,#_owned_usage_key_PARM_2
      00753A 74 01            [12] 1609 	mov	a,#0x01
      00753C F0               [24] 1610 	movx	@dptr,a
      00753D 8F 82            [24] 1611 	mov	dpl, r7
                                   1612 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1613 ;	quantum/action.c:1013: }
      00753F 02 7E 4D         [24] 1614 	ljmp	_owned_usage_key
      007542                       1615 00125$:
      007542 22               [24] 1616 	ret
                                   1617 ;------------------------------------------------------------
                                   1618 ;Allocation info for local variables in function 'unregister_code'
                                   1619 ;------------------------------------------------------------
                                   1620 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1621 ;------------------------------------------------------------
                                   1622 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1623 ;	-----------------------------------------
                                   1624 ;	 function unregister_code
                                   1625 ;	-----------------------------------------
      007543                       1626 _unregister_code:
      007543 E5 82            [12] 1627 	mov	a,dpl
      007545 90 08 36         [24] 1628 	mov	dptr,#_unregister_code_code_10000_723
      007548 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action.c:1020: if (code == KC_NO) {
      007549 E0               [24] 1631 	movx	a,@dptr
      00754A FF               [12] 1632 	mov	r7,a
      00754B 70 01            [24] 1633 	jnz	00121$
                                   1634 ;	quantum/action.c:1021: return;
      00754D 22               [24] 1635 	ret
      00754E                       1636 00121$:
                                   1637 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      00754E BF 04 00         [24] 1638 	cjne	r7,#0x04,00184$
      007551                       1639 00184$:
      007551 40 12            [24] 1640 	jc	00117$
      007553 EF               [12] 1641 	mov	a,r7
      007554 24 5B            [12] 1642 	add	a,#0xff - 0xa4
      007556 40 0D            [24] 1643 	jc	00117$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      007558 8F 82            [24] 1646 	mov	dpl, r7
      00755A 12 7D 86         [24] 1647 	lcall	_del_owned_key
      00755D E5 82            [12] 1648 	mov	a, dpl
      00755F 70 01            [24] 1649 	jnz	00102$
      007561 22               [24] 1650 	ret
      007562                       1651 00102$:
                                   1652 ;	quantum/action.c:1062: send_keyboard_report();
      007562 02 7F A2         [24] 1653 	ljmp	_send_keyboard_report
      007565                       1654 00117$:
                                   1655 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007565 12 77 07         [24] 1656 	lcall	_ak820_outline_0168
      007568 BF E0 00         [24] 1657 	cjne	r7,#0xe0,00188$
      00756B                       1658 00188$:
      00756B 40 1A            [24] 1659 	jc	00113$
      00756D EF               [12] 1660 	mov	a,r7
      00756E 24 18            [12] 1661 	add	a,#0xff - 0xe7
      007570 40 15            [24] 1662 	jc	00113$
                                   1663 ;	free result
                                   1664 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      007572 74 07            [12] 1665 	mov	a,#0x07
      007574 5F               [12] 1666 	anl	a,r7
      007575 12 76 BF         [24] 1667 	lcall	_ak820_outline_0061
      007578 80 02            [24] 1668 	sjmp	00192$
      00757A                       1669 00191$:
      00757A 25 E0            [12] 1670 	add	a,acc
      00757C                       1671 00192$:
      00757C D5 F0 FB         [24] 1672 	djnz	b,00191$
      00757F F5 82            [12] 1673 	mov	dpl,a
      007581 12 7C 78         [24] 1674 	lcall	_del_owned_mods
                                   1675 ;	quantum/action.c:1065: send_keyboard_report();
      007584 02 7F A2         [24] 1676 	ljmp	_send_keyboard_report
      007587                       1677 00113$:
                                   1678 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007587 12 77 07         [24] 1679 	lcall	_ak820_outline_0168
      00758A BF A5 00         [24] 1680 	cjne	r7,#0xa5,00193$
      00758D                       1681 00193$:
      00758D 40 05            [24] 1682 	jc	00111$
      00758F EF               [12] 1683 	mov	a,r7
      007590 24 58            [12] 1684 	add	a,#0xff - 0xa7
      007592 50 0D            [24] 1685 	jnc	00106$
                                   1686 ;	free result
      007594                       1687 00111$:
      007594 12 77 07         [24] 1688 	lcall	_ak820_outline_0168
      007597 BF A8 00         [24] 1689 	cjne	r7,#0xa8,00196$
      00759A                       1690 00196$:
      00759A 40 12            [24] 1691 	jc	00123$
      00759C EF               [12] 1692 	mov	a,r7
      00759D 24 3D            [12] 1693 	add	a,#0xff - 0xc2
      00759F 40 0D            [24] 1694 	jc	00123$
                                   1695 ;	free result
      0075A1                       1696 00106$:
                                   1697 ;	quantum/action.c:1070: owned_usage_key(code, false);
      0075A1 12 77 07         [24] 1698 	lcall	_ak820_outline_0168
      0075A4 90 0A 90         [24] 1699 	mov	dptr,#_owned_usage_key_PARM_2
      0075A7 E4               [12] 1700 	clr	a
      0075A8 F0               [24] 1701 	movx	@dptr,a
      0075A9 8F 82            [24] 1702 	mov	dpl, r7
                                   1703 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1704 ;	quantum/action.c:1080: }
      0075AB 02 7E 4D         [24] 1705 	ljmp	_owned_usage_key
      0075AE                       1706 00123$:
      0075AE 22               [24] 1707 	ret
                                   1708 ;------------------------------------------------------------
                                   1709 ;Allocation info for local variables in function 'tap_code_delay'
                                   1710 ;------------------------------------------------------------
                                   1711 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1712 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1715 ;------------------------------------------------------------
                                   1716 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1717 ;	-----------------------------------------
                                   1718 ;	 function tap_code_delay
                                   1719 ;	-----------------------------------------
      0075AF                       1720 _tap_code_delay:
      0075AF E5 82            [12] 1721 	mov	a,dpl
      0075B1 90 08 39         [24] 1722 	mov	dptr,#_tap_code_delay_code_10000_736
      0075B4 F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action.c:1088: register_code(code);
      0075B5 E0               [24] 1725 	movx	a,@dptr
      0075B6 FF               [12] 1726 	mov	r7,a
      0075B7 F5 82            [12] 1727 	mov	dpl,a
      0075B9 C0 07            [24] 1728 	push	ar7
      0075BB 12 74 D6         [24] 1729 	lcall	_register_code
      0075BE D0 07            [24] 1730 	pop	ar7
                                   1731 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0075C0 90 08 37         [24] 1732 	mov	dptr,#_tap_code_delay_PARM_2
      0075C3 12 38 64         [24] 1733 	lcall	_ak820_outline_0079
      0075C6                       1734 00110$:
      0075C6 ED               [12] 1735 	mov	a,r5
      0075C7 4E               [12] 1736 	orl	a,r6
      0075C8 60 0D            [24] 1737 	jz	00105$
                                   1738 ;	quantum/action.c:1090: wait_ms(1);
      0075CA 90 00 01         [24] 1739 	mov	dptr,#0x0001
      0075CD 12 58 BD         [24] 1740 	lcall	_mDelaymS
                                   1741 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0075D0 1D               [12] 1742 	dec	r5
      0075D1 BD FF 01         [24] 1743 	cjne	r5,#0xff,00141$
      0075D4 1E               [12] 1744 	dec	r6
      0075D5                       1745 00141$:
      0075D5 80 EF            [24] 1746 	sjmp	00110$
      0075D7                       1747 00105$:
                                   1748 ;	quantum/action.c:1092: unregister_code(code);
      0075D7 8F 82            [24] 1749 	mov	dpl, r7
                                   1750 ;	quantum/action.c:1093: }
      0075D9 02 75 43         [24] 1751 	ljmp	_unregister_code
                                   1752 ;------------------------------------------------------------
                                   1753 ;Allocation info for local variables in function 'tap_code'
                                   1754 ;------------------------------------------------------------
                                   1755 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function tap_code
                                   1760 ;	-----------------------------------------
      0075DC                       1761 _tap_code:
      0075DC E5 82            [12] 1762 	mov	a,dpl
      0075DE 90 08 3A         [24] 1763 	mov	dptr,#_tap_code_code_10000_743
      0075E1 F0               [24] 1764 	movx	@dptr,a
                                   1765 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0075E2 E0               [24] 1766 	movx	a,@dptr
      0075E3 FF               [12] 1767 	mov	r7,a
      0075E4 BF 39 04         [24] 1768 	cjne	r7,#0x39,00103$
      0075E7 7E 50            [12] 1769 	mov	r6,#0x50
      0075E9 80 02            [24] 1770 	sjmp	00104$
      0075EB                       1771 00103$:
      0075EB 7E 00            [12] 1772 	mov	r6,#0x00
      0075ED                       1773 00104$:
      0075ED 90 08 37         [24] 1774 	mov	dptr,#_tap_code_delay_PARM_2
      0075F0 EE               [12] 1775 	mov	a,r6
      0075F1 12 38 9C         [24] 1776 	lcall	_ak820_outline_0134
      0075F4 8F 82            [24] 1777 	mov	dpl, r7
                                   1778 ;	quantum/action.c:1101: }
      0075F6 02 75 AF         [24] 1779 	ljmp	_tap_code_delay
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'register_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function register_mods
                                   1788 ;	-----------------------------------------
      0075F9                       1789 _register_mods:
      0075F9 E5 82            [12] 1790 	mov	a,dpl
      0075FB 90 08 3B         [24] 1791 	mov	dptr,#_register_mods_mods_10000_745
      0075FE F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action.c:1108: if (mods) {
      0075FF E0               [24] 1794 	movx	a,@dptr
      007600 FF               [12] 1795 	mov	r7,a
      007601 E0               [24] 1796 	movx	a,@dptr
      007602 60 08            [24] 1797 	jz	00103$
                                   1798 ;	quantum/action.c:1109: add_owned_mods(mods);
      007604 8F 82            [24] 1799 	mov	dpl, r7
      007606 12 7C 68         [24] 1800 	lcall	_add_owned_mods
                                   1801 ;	quantum/action.c:1110: send_keyboard_report();
                                   1802 ;	quantum/action.c:1112: }
      007609 02 7F A2         [24] 1803 	ljmp	_send_keyboard_report
      00760C                       1804 00103$:
      00760C 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'unregister_mods'
                                   1808 ;------------------------------------------------------------
                                   1809 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1810 ;------------------------------------------------------------
                                   1811 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1812 ;	-----------------------------------------
                                   1813 ;	 function unregister_mods
                                   1814 ;	-----------------------------------------
      00760D                       1815 _unregister_mods:
      00760D E5 82            [12] 1816 	mov	a,dpl
      00760F 90 08 3C         [24] 1817 	mov	dptr,#_unregister_mods_mods_10000_749
      007612 F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	quantum/action.c:1119: if (mods) {
      007613 E0               [24] 1820 	movx	a,@dptr
      007614 FF               [12] 1821 	mov	r7,a
      007615 E0               [24] 1822 	movx	a,@dptr
      007616 60 08            [24] 1823 	jz	00103$
                                   1824 ;	quantum/action.c:1120: del_owned_mods(mods);
      007618 8F 82            [24] 1825 	mov	dpl, r7
      00761A 12 7C 78         [24] 1826 	lcall	_del_owned_mods
                                   1827 ;	quantum/action.c:1121: send_keyboard_report();
                                   1828 ;	quantum/action.c:1123: }
      00761D 02 7F A2         [24] 1829 	ljmp	_send_keyboard_report
      007620                       1830 00103$:
      007620 22               [24] 1831 	ret
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'register_weak_mods'
                                   1834 ;------------------------------------------------------------
                                   1835 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function register_weak_mods
                                   1840 ;	-----------------------------------------
      007621                       1841 _register_weak_mods:
      007621 E5 82            [12] 1842 	mov	a,dpl
      007623 90 08 3D         [24] 1843 	mov	dptr,#_register_weak_mods_mods_10000_753
      007626 F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	quantum/action.c:1130: if (mods) {
      007627 E0               [24] 1846 	movx	a,@dptr
      007628 FF               [12] 1847 	mov	r7,a
      007629 E0               [24] 1848 	movx	a,@dptr
      00762A 60 08            [24] 1849 	jz	00103$
                                   1850 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      00762C 8F 82            [24] 1851 	mov	dpl, r7
      00762E 12 7C 87         [24] 1852 	lcall	_add_owned_weak_mods
                                   1853 ;	quantum/action.c:1132: send_keyboard_report();
                                   1854 ;	quantum/action.c:1134: }
      007631 02 7F A2         [24] 1855 	ljmp	_send_keyboard_report
      007634                       1856 00103$:
      007634 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function unregister_weak_mods
                                   1866 ;	-----------------------------------------
      007635                       1867 _unregister_weak_mods:
      007635 E5 82            [12] 1868 	mov	a,dpl
      007637 90 08 3E         [24] 1869 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      00763A F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1141: if (mods) {
      00763B E0               [24] 1872 	movx	a,@dptr
      00763C FF               [12] 1873 	mov	r7,a
      00763D E0               [24] 1874 	movx	a,@dptr
      00763E 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007640 8F 82            [24] 1877 	mov	dpl, r7
      007642 12 7C 97         [24] 1878 	lcall	_del_owned_weak_mods
                                   1879 ;	quantum/action.c:1143: send_keyboard_report();
                                   1880 ;	quantum/action.c:1145: }
      007645 02 7F A2         [24] 1881 	ljmp	_send_keyboard_report
      007648                       1882 00103$:
      007648 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard
                                   1890 ;	-----------------------------------------
      007649                       1891 _clear_keyboard:
                                   1892 ;	quantum/action.c:1152: clear_mods();
      007649 12 80 1D         [24] 1893 	lcall	_clear_mods
                                   1894 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1895 ;	quantum/action.c:1154: }
      00764C 02 76 4F         [24] 1896 	ljmp	_clear_keyboard_but_mods
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods
                                   1903 ;	-----------------------------------------
      00764F                       1904 _clear_keyboard_but_mods:
                                   1905 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00764F 90 0D BD         [24] 1906 	mov	dptr,#_actual_keyboard_report
      007652 12 6F 0F         [24] 1907 	lcall	_clear_keys_from_report
                                   1908 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1909 ;	quantum/action.c:1163: }
      007655 02 76 58         [24] 1910 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1911 ;------------------------------------------------------------
                                   1912 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1913 ;------------------------------------------------------------
                                   1914 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1915 ;	-----------------------------------------
                                   1916 ;	 function clear_keyboard_but_mods_and_keys
                                   1917 ;	-----------------------------------------
      007658                       1918 _clear_keyboard_but_mods_and_keys:
                                   1919 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007658 12 46 CB         [24] 1920 	lcall	_ak820_tapping_cancel
                                   1921 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      00765B 12 2E F0         [24] 1922 	lcall	_ak820_oneshot_cancel
                                   1923 ;	quantum/action.c:1185: ak820_combo_cancel();
      00765E 12 35 70         [24] 1924 	lcall	_ak820_combo_cancel
                                   1925 ;	quantum/action.c:1188: repeat_key_cancel();
      007661 12 A0 51         [24] 1926 	lcall	_repeat_key_cancel
                                   1927 ;	quantum/action.c:1190: clear_owned_mods();
      007664 12 7C A7         [24] 1928 	lcall	_clear_owned_mods
                                   1929 ;	quantum/action.c:1191: clear_owned_keys();
      007667 12 7C DF         [24] 1930 	lcall	_clear_owned_keys
                                   1931 ;	quantum/action.c:1192: clear_owned_usages();
      00766A 12 7E 15         [24] 1932 	lcall	_clear_owned_usages
                                   1933 ;	quantum/action.c:1193: layer_hold_clear();
      00766D 12 78 53         [24] 1934 	lcall	_layer_hold_clear
                                   1935 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007670 12 9B 9B         [24] 1936 	lcall	_clear_macro_tri_layer
                                   1937 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007673 90 0D BD         [24] 1938 	mov	dptr,#_actual_keyboard_report
      007676 12 6F 0F         [24] 1939 	lcall	_clear_keys_from_report
                                   1940 ;	quantum/action.c:1200: host_system_send(0);
      007679 90 00 00         [24] 1941 	mov	dptr,#0x0000
      00767C 12 6C E3         [24] 1942 	lcall	_host_system_send
                                   1943 ;	quantum/action.c:1201: host_consumer_send(0);
      00767F 90 00 00         [24] 1944 	mov	dptr,#0x0000
      007682 12 6D 13         [24] 1945 	lcall	_host_consumer_send
                                   1946 ;	quantum/action.c:1203: clear_weak_mods();
      007685 12 80 52         [24] 1947 	lcall	_clear_weak_mods
                                   1948 ;	quantum/action.c:1204: send_keyboard_report();
                                   1949 ;	quantum/action.c:1212: }
      007688 02 7F A2         [24] 1950 	ljmp	_send_keyboard_report
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'is_tap_record'
                                   1953 ;------------------------------------------------------------
                                   1954 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1955 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1956 ;------------------------------------------------------------
                                   1957 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1958 ;	-----------------------------------------
                                   1959 	.area CSEG    (CODE)
                                   1960 	.area CONST   (CODE)
                                   1961 	.area XINIT   (CODE)
      00BFD0                       1962 __xinit__disable_action_cache:
      00BFD0 00                    1963 	.db #0x00	;  0
                                   1964 	.area CABS    (ABS,CODE)
                                   1965 
                                   1966 ; Experimental exact instruction outlining.
                                   1967 	.globl _ak820_outline_0001
                                   1968 	.globl _ak820_outline_0005
                                   1969 	.globl _ak820_outline_0007
                                   1970 	.globl _ak820_outline_0008
                                   1971 	.globl _ak820_outline_0010
                                   1972 	.globl _ak820_outline_0011
                                   1973 	.globl _ak820_outline_0012
                                   1974 	.globl _ak820_outline_0013
                                   1975 	.globl _ak820_outline_0017
                                   1976 	.globl _ak820_outline_0021
                                   1977 	.globl _ak820_outline_0022
                                   1978 	.globl _ak820_outline_0034
                                   1979 	.globl _ak820_outline_0037
                                   1980 	.globl _ak820_outline_0042
                                   1981 	.globl _ak820_outline_0057
                                   1982 	.globl _ak820_outline_0061
                                   1983 	.globl _ak820_outline_0064
                                   1984 	.globl _ak820_outline_0070
                                   1985 	.globl _ak820_outline_0072
                                   1986 	.globl _ak820_outline_0078
                                   1987 	.globl _ak820_outline_0079
                                   1988 	.globl _ak820_outline_0089
                                   1989 	.globl _ak820_outline_0093
                                   1990 	.globl _ak820_outline_0107
                                   1991 	.globl _ak820_outline_0108
                                   1992 	.globl _ak820_outline_0110
                                   1993 	.globl _ak820_outline_0112
                                   1994 	.globl _ak820_outline_0113
                                   1995 	.globl _ak820_outline_0118
                                   1996 	.globl _ak820_outline_0123
                                   1997 	.globl _ak820_outline_0124
                                   1998 	.globl _ak820_outline_0130
                                   1999 	.globl _ak820_outline_0133
                                   2000 	.globl _ak820_outline_0134
                                   2001 	.globl _ak820_outline_0142
                                   2002 	.globl _ak820_outline_0146
                                   2003 	.globl _ak820_outline_0149
                                   2004 	.globl _ak820_outline_0157
                                   2005 	.globl _ak820_outline_0159
                                   2006 	.globl _ak820_outline_0167
                                   2007 	.globl _ak820_outline_0168
                                   2008 	.globl _ak820_outline_0182
                                   2009 	.globl _ak820_outline_0187
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0012
      00768B                       2013 _ak820_outline_0012:
      00768B 2D               [12] 2014 	add	a,r5
      00768C F9               [12] 2015 	mov	r1,a
      00768D E4               [12] 2016 	clr	a
      00768E 3E               [12] 2017 	addc	a,r6
      00768F FA               [12] 2018 	mov	r2,a
      007690 8F 03            [24] 2019 	mov	ar3,r7
      007692 89 82            [24] 2020 	mov	dpl,r1
      007694 8A 83            [24] 2021 	mov	dph,r2
      007696 8B F0            [24] 2022 	mov	b,r3
      007698 22               [24] 2023 	ret
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0013
      007699                       2027 _ak820_outline_0013:
      007699 2D               [12] 2028 	add	a,r5
      00769A FA               [12] 2029 	mov	r2,a
      00769B E4               [12] 2030 	clr	a
      00769C 3E               [12] 2031 	addc	a,r6
      00769D FB               [12] 2032 	mov	r3,a
      00769E 8F 04            [24] 2033 	mov	ar4,r7
      0076A0 8A 82            [24] 2034 	mov	dpl,r2
      0076A2 8B 83            [24] 2035 	mov	dph,r3
      0076A4 8C F0            [24] 2036 	mov	b,r4
      0076A6 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0021
      0076A7                       2041 _ak820_outline_0021:
      0076A7 8E 82            [24] 2042 	mov	dpl,r6
      0076A9 8F 83            [24] 2043 	mov	dph,r7
      0076AB A3               [24] 2044 	inc	dptr
      0076AC E0               [24] 2045 	movx	a,@dptr
      0076AD FC               [12] 2046 	mov	r4,a
      0076AE 7D 00            [12] 2047 	mov	r5,#0x00
      0076B0 8E 82            [24] 2048 	mov	dpl,r6
      0076B2 8F 83            [24] 2049 	mov	dph,r7
      0076B4 E0               [24] 2050 	movx	a,@dptr
      0076B5 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0042
      0076B6                       2055 _ak820_outline_0042:
      0076B6 90 08 30         [24] 2056 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076B9 E0               [24] 2057 	movx	a,@dptr
      0076BA 54 1F            [12] 2058 	anl	a,#0x1f
      0076BC F5 82            [12] 2059 	mov	dpl,a
      0076BE 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0061
      0076BF                       2064 _ak820_outline_0061:
      0076BF F5 F0            [12] 2065 	mov	b,a
      0076C1 05 F0            [12] 2066 	inc	b
      0076C3 74 01            [12] 2067 	mov	a,#0x01
      0076C5 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0070
      0076C6                       2072 _ak820_outline_0070:
      0076C6 90 0D 9B         [24] 2073 	mov	dptr,#___memcpy_PARM_3
      0076C9 74 06            [12] 2074 	mov	a,#0x06
      0076CB F0               [24] 2075 	movx	@dptr,a
      0076CC E4               [12] 2076 	clr	a
      0076CD A3               [24] 2077 	inc	dptr
      0076CE F0               [24] 2078 	movx	@dptr,a
      0076CF 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0078
      0076D0                       2083 _ak820_outline_0078:
      0076D0 90 08 2F         [24] 2084 	mov	dptr,#_process_action_PARM_2
      0076D3 E0               [24] 2085 	movx	a,@dptr
      0076D4 F5 82            [12] 2086 	mov	dpl,a
      0076D6 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0089
      0076D7                       2091 _ak820_outline_0089:
      0076D7 90 08 30         [24] 2092 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076DA E0               [24] 2093 	movx	a,@dptr
      0076DB 03               [12] 2094 	rr	a
      0076DC 03               [12] 2095 	rr	a
      0076DD 54 03            [12] 2096 	anl	a,#0x03
      0076DF 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0113
      0076E0                       2101 _ak820_outline_0113:
      0076E0 90 08 30         [24] 2102 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076E3 E0               [24] 2103 	movx	a,@dptr
      0076E4 54 0F            [12] 2104 	anl	a,#0x0f
      0076E6 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0130
      0076E7                       2109 _ak820_outline_0130:
      0076E7 90 08 2F         [24] 2110 	mov	dptr,#_process_action_PARM_2
      0076EA E0               [24] 2111 	movx	a,@dptr
      0076EB FE               [12] 2112 	mov	r6,a
      0076EC A3               [24] 2113 	inc	dptr
      0076ED E0               [24] 2114 	movx	a,@dptr
      0076EE 54 03            [12] 2115 	anl	a,#0x03
      0076F0 FF               [12] 2116 	mov	r7,a
      0076F1 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0146
      0076F2                       2121 _ak820_outline_0146:
      0076F2 74 07            [12] 2122 	mov	a,#0x07
      0076F4 2D               [12] 2123 	add	a,r5
      0076F5 F8               [12] 2124 	mov	r0,a
      0076F6 E4               [12] 2125 	clr	a
      0076F7 3E               [12] 2126 	addc	a,r6
      0076F8 F9               [12] 2127 	mov	r1,a
      0076F9 8F 02            [24] 2128 	mov	ar2,r7
      0076FB 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0159
      0076FC                       2133 _ak820_outline_0159:
      0076FC 90 08 2F         [24] 2134 	mov	dptr,#_process_action_PARM_2
      0076FF E0               [24] 2135 	movx	a,@dptr
      007700 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0167
      007701                       2140 _ak820_outline_0167:
      007701 90 08 35         [24] 2141 	mov	dptr,#_register_code_code_10000_709
      007704 E0               [24] 2142 	movx	a,@dptr
      007705 FF               [12] 2143 	mov	r7,a
      007706 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0168
      007707                       2148 _ak820_outline_0168:
      007707 90 08 36         [24] 2149 	mov	dptr,#_unregister_code_code_10000_723
      00770A E0               [24] 2150 	movx	a,@dptr
      00770B FF               [12] 2151 	mov	r7,a
      00770C 22               [24] 2152 	ret
                                   2153 
                                   2154 	.area CSEG (CODE)
                                   2155 ; function ak820_outline_0187
      00770D                       2156 _ak820_outline_0187:
      00770D F0               [24] 2157 	movx	@dptr,a
      00770E EB               [12] 2158 	mov	a,r3
      00770F A3               [24] 2159 	inc	dptr
      007710 F0               [24] 2160 	movx	@dptr,a
      007711 22               [24] 2161 	ret
